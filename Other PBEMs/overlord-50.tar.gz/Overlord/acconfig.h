/* Define if sys_errlist is defined in standard includes.  */
#undef HAVE_SYS_ERRLIST

