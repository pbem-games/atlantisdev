/* $Id: fx.c,v 1.16 1999/11/21 15:46:13 archer Exp $
 *	Special effects here
 */
#include "turn.h"
#include "fx.h"
#include "parser.h"
#include "battle.h"
#include "command_u.h"


/**
 ** Special type
 **/
typedef int	(*suitable_locale)(location_s *);
typedef int	(*resource_valid)(item_s *);


/**
 ** Private variables
 **/
static location_s	*targeted_locale;
static item_s		*targeted_item;


/**
 ** MATCH_TARGET
 **	Simple comparator
 **/
static int match_target(location_s *here)
{
	if (here == targeted_locale)
		return 1;
	return 0;
}


/**
 ** MATCH_RESOURCE
 **	Simple resource comparator
 **/
static int match_resource(location_s *here)
{
resource_s	*items;
	for (items = here->resources; items; items = items->next)
		if (items->type == targeted_item && items->amount)
			return 1;
	return 0;
}


/**
 ** SEARCH_FOR_LOCATION
 **	Common sub-routine, searching for the nearest location that satisfy a
 **	criteria, and is within a specified range. Various FX uses this.
 **/
static int search_for_location(location_s *starting_point, int days, int max, suitable_locale check,
				location_s **found, location_s **toward)
{
location_s	*sublocation;
location_s	*match, *ignore;
direction_s	*dir;
int		try, best;
/*
 * Use recursion
 */
	if (days >= max)
		return 0;
/*
 * Already visited, and maybe even faster!
 */
	if (starting_point->distance <= days)
		return 0;
	starting_point->distance = days;
	if ((*check)(starting_point)) {
		*found = starting_point;
		*toward = starting_point;
		return days;
	}
/*
 * Best check
 */
	best = 0;
/*
 * Search toward a direction
 */
	for (dir = starting_point->exits; dir; dir = dir->next) {
		if (dir->days <= 0)
			continue;
		try = search_for_location(dir->toward, days + dir->days, max, check, &match, &ignore);
		if (try) {
			max  = try;
			best = try;
			*found  = match;
			*toward = dir->toward;
		}
	}
/*
 * Seek outer locations
 */
	if ((sublocation = starting_point->outer) != 0) {
		try = search_for_location(sublocation, days+1, max, check, &match, &ignore);
		if (try) {
			max  = try;
			best = try;
			*found  = match;
			*toward = sublocation;
		}
	}
/*
 * Seek inner locations
 */
	for (sublocation = starting_point->inner; sublocation; sublocation = sublocation->next_inner) {
		try = search_for_location(sublocation, days+1, max, check, &match, &ignore);
		if (try) {
			max  = try;
			best = try;
			*found  = match;
			*toward = sublocation;
		}
	}
	return best;
}


/**
 ** MAX_DISTANCE
 **	Maxes the distance before a spread calculation
 **/
static void max_distance(void)
{
location_s	*local;
	for (local = location_list; local; local = local->next)
		local->distance = 9999999;
}


/**
 ** FX_AVAILABLE_IN_STACK
 **	One unit has the skill, or the object, or whatever it takes
 **/
static int fx_available_in_stack(unit_s *stack, faction_s *faction, int fx)
{
carry_s		*owns;
experience_s	*knows;
/*
 * Loop on stack
 */
	while (stack) {
		if (faction == 0 || stack->faction == faction) {
			for (owns = stack->carrying; owns; owns = owns->next)
				if (owns->item->special_effects == fx)
					return 1;
			for (knows = stack->skilled; knows; knows = knows->next)
				if (knows->effective && knows->effective->special_effects == fx)
					return 1;
			if (fx_available_in_stack(stack->stack, faction, fx))
				return 1;
		}
		stack = stack->next_location;
	}
	return 0;
}


/**
 ** FX_AVAILABLE_HERE_FOR
 **	One unit has the skill, or the object, or whatever it takes
 **/
int fx_available_here_for(location_s *here, faction_s *faction, int fx)
{
location_s	*structures;
/*
 * First, check main
 */
	if (fx_available_in_stack(here->present, faction, fx))
		return 1;
	for (structures = here->inner; structures; structures = structures->next_inner)
		if (fx_available_in_stack(structures->present, faction, fx))
			return 1;
	return 0;
}


/**
 ** FX_INCREASE_RESOURCES
 **	Resource increases
 **/
static void fx_increase_resources(location_s *local, item_s *item, int amount)
{
resource_s	*that;
resource_s	*prev;
/*
 * Scan for resources
 */
	prev = 0;
	for (that = local->resources; that; that = that->next)
		if (that->type == item)
			break;
		else
			prev = that;
/*
 * New resource?
 */
	if (!that) {
		that = new_resource_instance();
		that->type = item;
		if (prev)
			prev->next = that;
		else
			local->resources = that;
	}
	that->amount += amount;
	that->remains += amount * that->type->token_multiplier;
}


/********************************* FX ROUTINES *******************************/


#ifdef FX_FAR_EYE
/**
 ** FX_FAR_EYE
 **	User casts the FAR EYE
 **/
static void fx_far_eye(unit_s *unit, skill_s *effective)
{
location_s	*location;
location_s	*current;
direction_s	*dir;
/*
 * Caster must have specified a location, which is forgotten
 */
	if (unit->target_type != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Forgot to specify far eye's target");
		return;
	}
	location = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;
/*
 * In range?
 */
	current = unit->true_location;
	if (location != current) {
		for (dir = current->exits; dir; dir = dir->next)
			if (dir->toward == location)
				break;
		if (dir == 0) {
			current = current->outer;
			if (current != location && current) {
				for (dir = current->exits; dir; dir = dir->next)
					if (dir->toward == location)
						break;
				if (!dir)
					current = 0;
			}
		}
	}
	if (!current) {
		unit_personal_event(unit, today_number, "Target out of range");
		return;
	}
/*
 * We are observing at our observation, today, 
 */
#ifdef STEALTH_STATS
	observer_present(unit->faction, location, today_number, unit->vital.observation);
#else
	observer_present(unit->faction, location, today_number);
#endif
	sprintf(work, "Seen %s [%s]", location->name, location->id.text);
	unit_personal_event(unit, today_number, work);
}
#endif /* FX_FAR_EYE */


#ifdef FX_WATERY_VISION
/**
 ** DO_WATER_VISION
 **	This is recursive
 **/
static void do_water_vision(location_s *location, unit_s *viewer, int range)
{
direction_s	*dir;
/*
 * Check
 */
	if (range < 0)
		return;
/*
 * We saw here...
 */
#ifdef STEALTH_STATS
	observer_present(viewer->faction, location, today_number, viewer->vital.observation);
#else
	observer_present(viewer->faction, location, today_number);
#endif
/*
 * Apply on all exits
 */
	for (dir = location->exits; dir; dir = dir->next)
		if (dir->days >= 0 && dir->mode == 3)
			do_water_vision(dir->toward, viewer, range - dir->days);
	if (location->outer)
		do_water_vision(location->outer, viewer, range-1);
}


/**
 ** FX_WATER_SEEING
 **	User casts the water vision
 **/
static void fx_water_seeing(unit_s *unit)
{
/*
 * In range?
 */
	do_water_vision(unit->true_location, unit, 20);
/*
 * Report
 */
	unit_personal_event(unit, today_number, "Seen over the waters...");
}
#endif /* FX_WATERY_VISION */


#ifdef FX_WIZARD_WALKING
/**
 ** FX_WIZARD_WALK
 **	The wizard (and stack) moves instantaneously to the target destination,
 ** if the move is legal and less than 60 days away.
 **/
static int fx_wizard_walk(unit_s *invoker)
{
location_s	*ignore;
/*
 * Last-minute check
 */
	if (invoker->target_type != ARGUMENT_IS_LOCATION_ID) {
		printf("Pre-flight check for LOCATION target failed!\n");
		unit_personal_event(invoker, today_number, "No target specified! Fizzle!");
		return 1;
	}
	invoker->target_type = 0;
/*
 * In range?
 */
	targeted_locale = invoker->target.location;
	max_distance();
	if (search_for_location(invoker->true_location, 0, 61, match_target, &ignore, &ignore) <= 0) {
		unit_personal_event(invoker, today_number, "Destination out of range!");
		return 1;
	}
/*
 * Vanishing
 */
	sprintf(work, "%s [%s] vanishes", invoker->name, invoker->id.text);
	location_global_event(invoker, today_number, work);
/*
 * Appearance
 */
	move_to_location(invoker, targeted_locale);
	sprintf(work, "%s [%s] appears in %s [%s]", invoker->name, invoker->id.text,
				targeted_locale->name, targeted_locale->id.text);
	unit_personal_event(invoker, today_number, work);
	location_global_event(invoker, today_number, work);
	return 1;
}
#endif


#ifdef FX_RAISE_TO_HERO
/**
 ** FX_HERO_RAISE
 **	Raise a normal leader to hero status
 **/
static int fx_hero_raise(unit_s *invoker, int percent)
{
unit_s	*target;
/*
 * Last-minute check
 */
	if (invoker->target_type != ARGUMENT_IS_UNIT_ID) {
		printf("Pre-flight check for UNIT target failed!\n");
		unit_personal_event(invoker, today_number, "No target specified! Fizzle!");
		return 1;
	}
	target = invoker->target.unit;
	if (strcmp(target->race->tag.text, "ldr")) {
		unit_personal_event(invoker, today_number, "Target is not a leader");
		return 1;
	}
/*
 * Raise attempted
 */
	percent *= 2;
	if (roll_1Dx(100) >= percent)
		return 0;
/*
 * Success!
 */
	synthetic_tag("hero");
	target->race = race_from_tag(0);
	unit_personal_event(target, today_number, "You feel heroic!");
	sprintf(work, "You find heroism in %s [%s]", target->name, target->id.text);
	unit_personal_event(invoker, today_number, work);
	invoker->target_type = 0;
	return 1;
}
#endif


#ifdef FX_MINERAL_SCRY
/**
 ** FX_MINERAL_SCRYING
 **	Locate an area with the specific resources
 **/
static void fx_mineral_scrying(unit_s *invoker)
{
location_s	*found, *walk;
/*
 * Resource must be a mineral
 */
	targeted_item = invoker->target.item;
	invoker->target_type = 0;
	if (targeted_item->item_live || !targeted_item->token_multiplier) {
		unit_personal_event(invoker, today_number, "Target is not a mineral resource");
		return;
	}
/*
 * Scan at 60 days
 */
	max_distance();
	if (search_for_location(invoker->true_location, 0, 61, match_resource, &found, &walk) <= 0) {
		unit_personal_event(invoker, today_number, "None found nearby");
		return;
	}
	sprintf(work, "%s found in %s [%s], toward %s [%s]", targeted_item->name,
				found->name, found->id.text, walk->name, walk->id.text);
	unit_personal_event(invoker, today_number, work);
#ifdef STEALTH_STATS
	observer_present(invoker->faction, found, today_number, invoker->vital.observation);
#else
	observer_present(invoker->faction, found, today_number);
#endif
}
#endif


#ifdef FX_RANDOM_MOUNT
/**
 ** FX_SUMMON_MOUNT
 **	A mount appear (prompt the GM for decision now). If no mount equipped,
 ** if will be equipped.
 **/
static void fx_summon_mount(unit_s *invoker, item_s *fx)
{
carry_s	*owns, *mounts;
int	mounted;
/*
 * Decisions, decisions
 */
	printf("Summoning %s: ", fx->tag.text);
	fflush(stdout);
	fgets(work, sizeof(work), stdin);
	synthetic_tag(work);
	owns = unit_possessions(invoker, item_from_tag(0), 1);
/*
 * Report now
 */
	sprintf(work, "One %s appears", owns->item->name);
	owns->amount++;
	mounted = 0;
	for (mounts = invoker->carrying; mounts; mounts = mounts->next)
		if (mounts->equipped && mounts->item->equip_category == 2)
			break;
	if (!mounts) {
		strcat(work, ", and you jump into saddle");
		owns->equipped = 1;
	}
	unit_personal_event(invoker, today_number, work);
}
#endif


#if defined(FX_SUMMONING) || defined(FX_SINGLE_SUMMONING)
/**
 ** FX_INVOCATION
 **	A creature is invoked
 **/
static int fx_invocation(unit_s *invoker, skill_s *effective, int amount, int max)
{
/*
 * If max is 1, the target must not have more than one
 */
	if (max && invoker->target.unit->size) {
		unit_personal_event(invoker, today_number, "Fizzle, the target is not a new unit");
		return 1;
	}
/*
 * First, make sure we either have a local target of same race, or a new target
 */
	if (will_recruit_now(invoker, invoker->target.unit, effective->specific, amount)) {
		unit_personal_event(invoker, today_number, "Summoning wrong creature type");
		return 1;
	}
/*
 * Report success
 */
	sprintf(work, "%d %s summoned", amount, amount > 1 ? effective->specific->plural
							   : effective->specific->name);
	unit_personal_event(invoker->target.unit, today_number, work);
	return max;
}
#endif


#ifdef FX_CORPSE_RAISING
/**
 ** FX_RAISING
 **	Some zombies or skeletons return from the dead
 **/
static int fx_raising(unit_s *invoker, skill_s *effective, int amount)
{
resource_s	*corpses;
/*
 * First, make sure we either have a local target of same race, or a new target
 */
	if (will_recruit_now(invoker, invoker->target.unit, effective->specific, amount)) {
		unit_personal_event(invoker, today_number, "Raising wrong type of corpse");
		return 1;
	}
/*
 * We do have a summoning. Now, destroy the token associated with it
 */
	corpses = location_has_resource(invoker->current, effective->harvests, 0);
	if (corpses) {
		corpses->amount -= amount;
		if (corpses->amount < 0)
			corpses->amount = 0;
	} else {
		corpses = location_has_resource(invoker->true_location, effective->harvests, 0);
		if (corpses) {
			corpses->amount -= amount;
			if (corpses->amount < 0)
				corpses->amount = 0;
		}
	}
	sprintf(work, "Raised %d %s", amount, amount > 1 ? effective->specific->plural :
							   effective->specific->name);
	unit_personal_event(invoker->target.unit, today_number, work);
	return 0;
}
#endif


#ifdef FX_METAMORPHOSIS
/**
 ** FX_RACE_CHANGE
 **	The unit changes shape
 **/
static void fx_race_change(unit_s *changed, race_s *specie)
{
experience_s	*intrinsic, *obtained;
int		amount;
/*
 * Alter race
 */
	changed->race = specie;
	for (intrinsic = specie->skilled; intrinsic; intrinsic = intrinsic->next) {
		obtained = unit_experiences(changed, intrinsic->skill, 1);
		amount = intrinsic->points * changed->size;
		if (obtained->points < amount) {
			obtained->points = amount;
			obtained->effective = intrinsic->effective;
#ifdef USES_SKILL_LEVELS
			obtained->level = intrinsic->level;
#endif
		}
	}
/*
 * Recompute characteristics
 */
	compute_unit_stats(changed);
	compute_overall_stealth(changed);
/*
 * Report change
 */
	sprintf(work, "%s [%s] is now ", changed->name, changed->id.text);
	if (changed->size == 1) {
		strcat(work, "a ");
		strcat(work, specie->name);
	} else {
		strcat(work, "composed of ");
		strcat(work, specie->plural);
	}
	unit_personal_event(changed, today_number, work);
}
#endif


#ifdef FX_BEAST_CALL
/**
 ** FX_BEAST_CALL
 **	Call a number of beasts into the new unit
 **/
static void fx_beast_call(unit_s *invoker)
{
race_s	*beasts, *calling;
int	amount;
int	value;
/*
 * Select a beast
 */
	amount = 0;
	for (beasts = race_list; beasts; beasts = beasts->next)
		if (beasts->type == 3) {
			if (beasts->intrinsic.melee < 0 || beasts->intrinsic.defense < 0)
				continue;
			amount++;
			if (amount == 1 || roll_1Dx(amount) == 1)
				calling = beasts;
		}
	if (!calling)
		abort();
	value = calling->intrinsic.melee + calling->intrinsic.defense;
	value *= calling->intrinsic.damage + calling->intrinsic.hits;
	amount = 250 + value / 2;
	amount /= value;
	if (amount < 1)
		amount = 1;
/*
 * Must have a unit target
 */
	if (will_recruit_now(invoker, invoker->target.unit, calling, amount))
		unit_personal_event(invoker, today_number, "Beast mixing forbidden");
	else {
		sprintf(work, "%d %s came forth", amount, amount > 1 ? calling->plural : calling->name);
		unit_personal_event(invoker, today_number, work);
	}
}
#endif


#ifdef FX_MOUNT_CLONING
/**
 ** FX_ITEM_COPY
 **	Add 1 to equipped item count
 **/
static int fx_copy_item(unit_s *unit, int type)
{
carry_s	*owns;
/*
 * Go for it
 */
	for (owns = unit->carrying; owns; owns = owns->next)
		if (owns->equipped && owns->item->equip_category == type) {
			owns->amount++;
			return 0;
		}
	unit_personal_event(unit, today_number, "None equipped!");
	return 1;
}
#endif


#ifdef FX_MIND_SWAPPING
/**
 ** FX_MIND_SWAP
 **	Swap one's mind with the target unit
 **/
static void fx_mind_swap(unit_s *invoker, order_s *order)
{
unit_s		*target;
faction_s	*swp_faction;
experience_s	*exp;
carry_s		*mana_1, *mana_2;
int		mana_0;
event_s		*swp_events;
/*
 * Both must be a single-figure leader
 */
	target = invoker->target.unit;
	if (target->size != 1 || target->race->type != RACE_LEADER) {
		unit_personal_event(invoker, today_number, "Target must be a leader");
		return;
	}
/*
 * If differing factions, the target must allow you
 */
	if ((swp_faction = target->faction) != invoker->faction) {
		if (target->target_type != ARGUMENT_IS_UNIT_ID ||
		    target->target.unit != invoker) {
			unit_personal_event(invoker, today_number, "Target must think of you");
			return;
		}
	}
/*
 * Swap skills
 */
	exp = target->skilled;
	target->skilled = invoker->skilled;
	invoker->skilled = exp;
	compute_unit_stats(invoker);
	compute_unit_stats(target);
/*
 * Re-equip things
 */
/*** HACK ***/
/*
 * Swap order stacks. Must execute the order first
 */
	order_is_complete(invoker, order);
	order = invoker->orders;
	invoker->orders = target->orders;
	target->orders = order;
	invoker->full_day = target->full_day;
	target->full_day = 1;
/*
 * Swap loyalty
 */
	target->faction = invoker->faction;
	invoker->faction = swp_faction;
/*
 * Swap mana
 */
	mana_1 = unit_possessions(invoker, item_mana, 1);
	mana_2 = unit_possessions(target, item_mana, 1);
	mana_0 = mana_1->amount;
	mana_1->amount = mana_2->amount;
	mana_2->amount = mana_0;
/*
 * Swap events
 */
	swp_events = target->events;
	target->events = invoker->events;
	invoker->events = swp_events;
/*
 * Swap the ANNOUNCE flag?
 */
	mana_0 = target->setting_advert;
	target->setting_advert = invoker->setting_advert;
	invoker->setting_advert = mana_0;
/*
 * Finally, report
 */
	sprintf(work, "You are now in %s [%s]'s body!", target->name, target->id.text);
	unit_personal_event(target, today_number, work);
	sprintf(work, "You are now in %s [%s]'s body!", invoker->name, invoker->id.text);
	unit_personal_event(invoker, today_number, work);
}
#endif


#ifdef FX_LIFT_COINS
/**
 ** FX_PICK_PURSE
 **	Lift some cash from the target unit
 **/
static void fx_picking_purse(unit_s *thief)
{
unit_s	*target;
carry_s	*purse;
int	chance, i, wage;
/*
 * The thief
 */
	compute_unit_stats(thief);
	chance = 2 * thief->vital.stealth;
	target = thief->target.unit;
	chance += target->size / 2;
	if (thief->true_location != target->true_location || (chance < 100 && roll_1Dx(100) >= chance)) {
		unit_personal_event(thief, today_number, "Failed to lift coins");
		return;
	}
	chance = 0;
	for (i = 0; i < thief->vital.stealth; i++) {
		chance += 1 + roll_1Dx(10);
	}
/*
 * Pick coins...
 */
	if ((purse = target->coins) == 0)
		target->coins = purse = unit_possessions(target, item_cash, 1);
	i = chance;
	if (purse->amount >= chance) {
		purse->amount -= chance;
		chance = 0;
	} else {
		i = purse->amount;
		purse->amount = 0;
		chance -= i;
	}
/*
 * Pick wages, then
 */
	if (chance) {
		wage  = chance * 30;
		wage /= target->true_location->wages;
		if (wage <= target->wages) {
			i += chance;
			target->wages -= wage;
		} else {
			wage = target->wages;
			if (wage) {
				target->wages = 0;
				wage *= target->true_location->wages;
				wage /= 30;
				i += wage;
			}
		}
	}
/*
 * Final accouting?
 */
	if (!i)
		unit_personal_event(thief, today_number, "No coin to steal!");
	else {
		if ((purse = thief->coins) == 0)
			thief->coins = purse = unit_possessions(thief, item_cash, 1);
		purse->amount += i;
		sprintf(work, "Stole $%d from %s [%s]", i, target->name, target->id.text);
		unit_personal_event(thief, today_number, work);
		sprintf(work, "Hep! Somebody stole $%d from us!", i);
		unit_personal_event(target, today_number, work);
	}
}
#endif


#ifdef FX_PICK_POCKETS
/**
 ** FX_PICKING_POCKET
 **	Lift some items from the target unit
 **/
static void fx_picking_pocket(unit_s *thief, skill_s *skill)
{
unit_s	*target;
carry_s	*purse, *picked;
int	chance;
/*
 * The thief
 */
	compute_unit_stats(thief);
	chance = 5 * thief->vital.stealth;
	if (skill->tokens_required < 5)
		chance += thief->vital.stealth;
	target = thief->target.unit;
/*
 * Select one item. The smallest non-coin item will be picked
 */
	picked = 0;
	for (purse = target->carrying; purse; purse = purse->next) {
		if (purse->item->item_type != ITEM_ITEM || purse->amount == 0)
			continue;
		if (purse->item == item_cash && picked)
			continue;
		if (picked) {
			if (picked->equipped && !purse->equipped)
				picked = 0;
			else
				if (!picked->equipped && purse->equipped)
					continue;
		}
		if (!picked)
			picked = purse;
		else
			if (purse->item->weight*25 - purse->item->suggested_price <
			    picked->item->weight*25 - picked->item->suggested_price)
				picked = purse;
	}
/*
 * No items?
 */
	if (!picked) {
		unit_personal_event(thief, today_number, "Failed to find anything in pockets");
		return;
	}
	if (thief->true_location != target->true_location) {
		unit_personal_event(thief, today_number, "Failed to find target");
		return;
	}
	chance += picked->item->weight * 2;
	chance -= picked->item->weight * skill->tokens_required;
	if (picked->equipped >= picked->amount)
		chance -= 20;
	if (chance <= 0 || (chance < 100 && roll_1Dx(100) >= chance)) {
		sprintf(work, "Failed to lift %s [%s]", picked->item->name, picked->item->tag.text);
		unit_personal_event(thief, today_number, work);
		return;
	}
/*
 * Pick coins...
 */
	purse = unit_possessions(thief, picked->item, 1);
	purse->amount ++;
	picked->amount --;
	if (picked->equipped > picked->amount)
		picked->equipped = picked->amount;
	sprintf(work, "Stole %s [%s] from %s [%s]", picked->item->name, picked->item->tag.text,
						target->name, target->id.text);
	unit_personal_event(thief, today_number, work);
	sprintf(work, "Hep! Somebody stole some %s [%s] from us!", picked->item->plural, picked->item->tag.text);
	unit_personal_event(target, today_number, work);
}
#endif


#ifdef FX_WILD_GROWTH
/**
 ** FX_WILD_GROWTH
 **	Locate an area with the specific resources
 **/
static void fx_wild_growth(unit_s *invoker)
{
resource_s	*life;
item_s		*type;
int		amt;
int		total;
/*
 * All local resources increase
 */
	total = 0;
	for (life = invoker->true_location->resources; life; life = life->next)
		if ((type = life->type)->item_live && life->amount) {
			amt = (life->amount + 5) / 10;
			if (amt == 0 && roll_1Dx(5) < life->amount)
				amt = 1;
			if (amt) {
				life->amount += amt;
				life->remains += amt * type->token_multiplier;
				sprintf(work, "%d additional %s...", amt, amt > 1 ? type->plural : type->name);
				unit_personal_event(invoker, today_number, work);
				total += amt;
			}
		}
	if (total)
		location_visible_event(invoker->true_location, today_number, "A sudden spur of growth occurs in the area!");
}
#endif


#ifdef FX_DEVASTATION
/**
 ** FX_DEVTASTATE
 **	Locate an area with the specific resources
 **/
static void fx_devastate(unit_s *invoker)
{
location_s	*target;
resource_s	*life;
item_s		*type;
int		amt;
int		total;
/*
 * All local resources increase
 */
	total = 0;
	target = invoker->target.location;
	for (life = target->resources; life; life = life->next)
		if ((type = life->type)->item_live && life->amount) {
			amt = ((life->amount * 3) + 9) / 10;
			if (amt) {
				life->amount -= amt;
				life->remains -= amt * type->token_multiplier;
				sprintf(work, "%d %s die off...", amt, amt > 1 ? type->plural : type->name);
				unit_personal_event(invoker, today_number, work);
				total += amt;
			}
		}
	if (total)
		location_visible_event(target, today_number, "A great die-off occurs in the area!");
}
#endif


#ifdef FX_SACRIFICE
/**
 ** FX_SACRIFY
 **	Perform a ritual sacrifice. Produce a corpse resource
 **/
static int fx_sacrify(unit_s *invoker, int amount, skill_s *effective)
{
resource_s	*deads;
unit_s		*target;
/*
 * Sacrifice is limited to number in unit
 */
	if (target->race == 0 || target->size == 0) {
		unit_personal_event(invoker, today_number, "No one in target unit");
		return 1;
	}
	target = invoker->target.unit;
	if (target->size < amount)
		amount = target->size;
	target->size -= amount;
	sprintf(work, "%d %s sacrificed", amount, amount > 1 ? target->race->plural : target->race->name);
	unit_personal_event(target, today_number, work);
	if (target->size && roll_1Dx(2) == 1) {
		unit_personal_event(target, today_number, "1 desertion");
		target->size--;
	}
/*
 * Litter the corpses around...
 */
	deads = location_has_resource(invoker->true_location, item_dead, 1);
	deads->amount += amount;
	deads->remains += amount * item_dead->token_multiplier;
	return 0;
}
#endif


#ifdef FX_MEETING_MIND
/**
 ** FX_DISTANT_TEACHING
 **	The target gets an enhancement in its studies
 **/
static void fx_distant_teaching(unit_s *invoker)
{
unit_s		*target;
experience_s	*knows, *impressed;
/*
 * Target must be studying
 */
	target = invoker->target.unit;
/*
 * Target unit must study some skill
 */
	if (target->is_guarding || target->inactive || target->dead || target->size == 0)
		return;
	invoker->full_day = 1;
	if (!target->full_day)
		full_day_order_by_unit(target);
/*
 * Target unit must be studying a skill. Else, we're not going to impress much.
 * Check against keyword, else, the study order might not be stored in
 * executing.routine anymore...
 */
	if (!target->full_day || !target->executing ||
	    strcmp(target->executing->executing.keyword, "study"))
		return;
	impressed = unit_experiences(target, target->executing->arguments[0].skill, 0);
	knows = unit_experiences(invoker, target->executing->arguments[0].skill, 0);
	if (!impressed || !knows || impressed->level >= knows->level)
		return;
/*
 * Add appropriate % of teaching
 */
	if (add_to_experience(target, impressed, target->executing->arguments[0].skill, SKILL_POINTS_PER_DAY/2)) {
/*
 * At least one level was achieved
 */
		compute_unit_stats(target);
#ifdef STEALTH_STATS
		compute_overall_stealth(target);
#endif
	}
}
#endif


#ifdef FX_FORTRESS
/**
 ** FX_CREATE_STRUCTURE
 **	Instant structure
 **/
static void fx_create_structure(unit_s *invoker, char *tname, char *title)
{
location_s	*inner;
location_s	*last;
terrain_s	*terrain;
/*
 * Find tail
 */
	last = 0;
	for (inner = invoker->true_location->inner; inner; inner = inner->next_inner)
		last = inner;
/*
 * Structure appears
 */
	inner = random_location_id();
	if (last)
		last->next_inner = inner;
	else
		invoker->true_location->inner = inner;
	inner->outer = invoker->true_location;
/*
 * Structure defines
 */
	synthetic_tag(tname);
	terrain = terrain_from_tag(0);
	inner->type = terrain;
	inner->name = strdup(terrain->name);
	if (title) {
		synthetic_tag(title);
		inner->title = title_from_tag(0);
	}
/*
 * Invoker is moved into the structure
 */
	move_to_location(invoker, inner);
}
#endif


#ifdef FX_WEATHER_FAIR
/**
 ** FX_CHANGE_WEATHER
 **	Weather changes
 **/
static void fx_change_weather(location_s *local, int conditions)
{
direction_s	*dir;
/*
 * Move outward
 */
	while (local->outer)
		local = local->outer;
	local->next_climate = conditions;
	switch (conditions) {
	    case 5:
		for (dir = local->exits; dir; dir = dir->next)
			if (dir->toward->next_climate < 3)
				dir->toward->next_climate += 2;
		break;
	    case 3:
		for (dir = local->exits; dir; dir = dir->next)
			if (dir->toward->next_climate == 2)
				dir->toward->next_climate = 1;
	}
}
#endif


#ifdef FX_CALL_SEA
/**
 ** FX_DRAIN_SEA
 **	Drain all the resources in sailing hexes around
 **/
static int fx_drain_sea(unit_s *invoker)
{
location_s	*local;
direction_s	*dir;
resource_s	*origin, *drained;
int		total, amount;
/*
 * Call of the sea occurs outward
 */
	local = invoker->current;
	while (local->outer)
		local = local->outer;
/*
 * Drain from all directions. A random 5-10% amount is drained. At least 1 for each!
 */
	total = 0;
	for (dir = local->exits; dir; dir = dir->next)
		if (dir->mode == 3)
			for (origin = dir->toward->resources; origin; origin = origin->next) {
				if (origin->amount == 0)
					continue;
				amount = origin->amount * (5 + roll_1Dx(6));
				amount += 50;
				amount /= 100;
				if (!amount)
					amount = 1;
				origin->amount -= amount;
				total += amount;
				drained = location_has_resource(local, origin->type, 1);
				drained->amount += amount;
			}
/*
 * Any resource drained?
 */
	if (!total) {
		unit_personal_event(invoker, today_number, "Nothing to call upon!");
		return 1;
	}
	return 0;
}
#endif


#ifdef FX_BEAST_GATHERING
/**
 ** FX_GATHER_BEASTS
 **	Drain all the cattle or horses in hexes around
 **/
static int fx_gather_beasts(unit_s *invoker)
{
location_s	*local;
direction_s	*dir;
resource_s	*origin, *drained;
int		total;
/*
 * Call of the sea occurs outward
 */
	local = invoker->current;
	while (local->outer)
		local = local->outer;
/*
 * Drain from all directions. 1 is drained.
 */
	total = 0;
	for (dir = local->exits; dir; dir = dir->next)
		if (dir->mode == 3)
			for (origin = dir->toward->resources; origin; origin = origin->next) {
				if (origin->amount == 0)
					continue;
				if (strcmp(origin->type->tag.text, "catt") && strcmp(origin->type->tag.text, "hrse"))
					continue;
				origin->amount--;
				total++;
				drained = location_has_resource(local, origin->type, 1);
				drained->amount++;
			}
/*
 * Any resource drained?
 */
	if (!total) {
		unit_personal_event(invoker, today_number, "Nothing to gather around!");
		return 1;
	}
	location_global_event(invoker, today_number, "Beasts wander into the area");
	return 0;
}
#endif


#ifdef FX_CHASM_OPENS
/**
 ** SET_TRUE_LOCATION
 **	Sets true location to be equal to current (current changed from
 ** structure to full location)
 **/
static void set_true_location(unit_s *unit)
{
	while (unit) {
		unit->true_location = unit->current;
		set_true_location(unit->stack);
		unit = unit->next_location;
	}
}


/**
 ** FX_CHASM_OPENS
 **	Open a deep chasm into the bowels of earth...
 **/
static void fx_chasm_opens(unit_s *invoker)
{
/*
 * In a structure? The structure becomes the chasm. Else, a new location is created
 */
	if (invoker->true_location == invoker->current)
		fx_create_structure(invoker, "chsm", 0);
	synthetic_tag("chsm");
	invoker->current->type = terrain_from_tag(0);
	invoker->current->name = strdup("Deep crevice");
	location_global_event(invoker, today_number, "A deep chasm opens into the bowels of earth!");
/*** HACK ***/
/*
 * All units end up in a separate location
 */
	set_true_location(invoker->current->present);
}
#endif


#ifdef FX_ASSASSINATION
/**
 ** FX_MURDER
 **	Stealthily attempt murder
 **/
static int fx_murder(unit_s *invoker, skill_s *murder)
{
unit_s	*target;
int	delta;
/*
 * Murderous intent
 */
	target = invoker->target.unit;
	if (target->dead || !target->size) {
		unit_personal_event(invoker, today_number, "Seem you have your job already done");
		return 1;
	}
	delta = invoker->vital.stealth - target->vital.observation;
	delta *= 20 - murder->tokens_required;
	if (delta <= 0 || roll_1Dx(200) >= delta) {
		unit_personal_event(invoker, today_number, "Failed, could not sneak upon your target");
		return 0;
	}
	unit_personal_event(invoker, today_number, "Spotted your mark!");
	battle_assassination(invoker, target, (12 - murder->tokens_required) / 2);
	if (target->dead || target->size == 0)
		return 1;
	return 0;
}
#endif


#ifdef FX_MOSS_POLLUTION
/**
 ** FX_MOSS
 **	Mossy growth, destory one weapon or armor. Magic items are safe
 **/
static int fx_moss(unit_s *invoker, int amount)
{
unit_s	*target;
carry_s	*equip;
item_s	*type;
int	total;
/*
 * Go
 */
	target = invoker->target.unit;
	for (equip = target->carrying; equip; equip = equip->next)
		if ((total = equip->equipped) != 0) {
			if ((type = equip->item)->item_special)
				continue;
			if (type->equip_category < EQUIP_CATEGORY_WEAPON)
				continue;
			if (type->equip_category > EQUIP_CATEGORY_GLOVES)
				continue;
			if (total >= amount) {
				sprintf(work, "Moss corroded %d %s", amount, amount == 1 ? type->name : type->plural);
				unit_personal_event(target, today_number, work);
				equip->amount -= amount;
				equip->equipped -= amount;
				return 0;
			}
			sprintf(work, "Moss corroded %d %s", equip->equipped, equip->equipped == 1 ? type->name : type->plural);
			unit_personal_event(target, today_number, work);
			amount -= total;
			equip->amount -= total;
			equip->equipped = 0;
		}
/*
 * No more moss
 */
	unit_personal_event(invoker, today_number, "Moss finds no toehold");
	return 1;
}
#endif


#ifdef FX_CAPTURE_BEAST
/**
 ** FX_CAPTURE_ATTEMPT
 **	Capture a unit of creature type. Capture must occur in wilderness
 **/
static int fx_capture_attempt(unit_s *invoker, int type)
{
unit_s	*target;
int	chance;
/*
 * Capture attempt
 */
	target = invoker->target.unit;
	if (target->leader) {
		unit_personal_event(invoker, today_number, "The target is already loyal to a faction!");
		return 1;
	}
	if (!target->race || type+3 != target->race->type) {
		unit_personal_event(invoker, today_number, "Wrong target type!");
		return 1;
	}
/*
 * Compute chances
 */
	chance = 11;
	if (type != 0)
		chance -= target->size;
	else
		chance --;
	if (chance < 1)
		chance = 1;
	if (roll_1Dx(100) >= chance)
		return 0;
/*
 * Success!
 */
	target->faction = invoker->faction;
	stack_under(invoker, target);
	sprintf(work, "You master %s [%s]", target->name, target->id.text);
	unit_personal_event(invoker, today_number, work);
	return 1;
}
#endif

#if defined(FX_PORTAL_OF_AIR) || defined(FX_PORTAL_OF_EARTH) || defined(FX_PORTAL_OF_FIRE) || defined(FX_PORTAL_OF_VOID) || defined(FX_PORTAL_OF_WATER)
/**
 ** FX_OPEN_PORTAL
 **	Open a portal the elemental planes
 **/
static void fx_open_portal(unit_s *invoker, skill_s *element)
{
location_s	*circ, *plane;
direction_s	*direction;
unit_s		*mages;
experience_s	*has;
/*
 * Unit must be standing in a mage circle
 */
	circ = invoker->current;
	if (strcmp(circ->type->tag.text, "mcir")) {
		unit_personal_event(invoker, today_number, "The gate cannot latch onto a mage circle and collapse");
		return;
	}
	circ = circ->outer;
/*
 * Now ask for the portal location
 */
	plane = 0;
	while (!plane) {
		printf("[%s] open a portal of %s to:", invoker->id.text, element->name);
		fgets(work, sizeof(work), stdin);
		synthetic_tag(work);
		plane = location_from_id(0);
	}
/*
 * Now, create the portal
 */
	direction = new_direction_from_location();
	direction->toward = plane;
	direction->days = 1;
	direction->name = "Portal";
	direction->skill = element;
#ifdef USES_SKILL_LEVELS
	direction->level = 3;
#endif
	direction->next = circ->exits;
	circ->exits = direction;
/*
 * Reverse portal exists
 */
	direction = new_direction_from_location();
	direction->toward = circ;
	direction->days = 1;
	direction->name = "Portal";
	direction->skill = element;
#ifdef USES_SKILL_LEVELS
	direction->level = 3;
#endif
	direction->next = plane->exits;
	plane->exits = direction;
/*
 * All mages experience the opening
 */
	for (mages = unit_list; mages; mages = mages->next)
		if (mages->size == 1 && mages->vital.mana &&
		    (has = unit_experiences(mages, element, 0)) != 0 &&
		    has->effective)
			unit_personal_event(mages, today_number, "You feel a sudden wrenching in the fabric of reality");
/*
 * All units at location witness the event
 */
	location_global_event(invoker, today_number, "A portal suddendly opens!");
}
#endif


#ifdef FX_ARMAGEDDON
/**
 ** FX_LAUNCH_ARMAGEDDON
 **	Use tactical nuke to clean up ground
 **/
static void fx_launch_armageddon(unit_s *invoker, skill_s *armageddon)
{
location_s	*location;
resource_s	*living;
unit_s		*collateral, *mages;
experience_s	*has;
int		did;
static int	armageddons;
/*
 * Target is done
 */
	armageddons++;
	if (armageddons == 5) {
		printf("5 armageddons!\n");
		abort();
	}
	location = invoker->target.location;
	printf(">>>> Armageddon strike #%d at %s\n", armageddons, location->id.text);
	if (strcasecmp(location->id.text, "L1") == 0) {
		unit_personal_event(invoker, today_number, "Target is protected! A backlash wipes the spell from your mind!");
		has = unit_experiences(invoker, armageddon, 0);
		if (has) {
			has->effective = 0;
			has->points = 0;
			has->level = 0;
		}
		did = 0;
	} else {
		location->economy = -9000;
		location->population = 0;
		location->wages--;
		for (living = location->resources; living; living = living->next)
			if (living->type->item_live) {
				living->amount = 0;
				living->remains = 0;
				living->tokens = 0;
		}
		did = 1;
	}
	for (collateral = unit_list; collateral; collateral = collateral->next)
		if ((collateral->true_location == location || collateral->current == location) &&
		    collateral->size) {
			if (did) {
				collateral->size = 0;
				collateral->dead = 1;
				unit_is_now_dead(collateral, 1);
				unit_personal_event(collateral, today_number, "Agonising seizures wrack you!");
			} else
				unit_personal_event(collateral, today_number, "You feel a fluttering of your heart, as if it stopped for one beat");
		}
/*
 * All mages experience the opening
 */
	if (!did)
		for (mages = unit_list; mages; mages = mages->next)
			if (mages->size == 1 && mages->vital.mana &&
			    (has = unit_experiences(mages, armageddon, 0)) != 0 &&
			    has->effective && !mages->dead)
				unit_personal_event(mages, today_number, "You feel a fluttering of your heart, as if it stopped for one beat");
}
#endif


#ifdef FX_LURE_OTHER
/**
 ** FX_LURE_UNIT
 **	Kitty, kitty, come here
 **/
static int fx_lure_unit(unit_s *invoker, skill_s *lure)
{
unit_s		*target;
location_s	*location, *bait;
direction_s	*toward;
order_s		*tapeworm, *has;
/*
 * Target is done
 */
	target = invoker->target.unit;
	location = target->true_location;
	bait = invoker->true_location;
/*
 * Validity?
 */
	if (location == bait) {
		unit_personal_event(invoker, today_number, "Already here!");
		return 1;
	}
	if (bait->outer != location && location->outer != bait) {
		for (toward = location->exits; toward; toward = toward->next)
			if (toward->toward == bait)
				break;
		if (!toward) {
			unit_personal_event(invoker, today_number, "Target is too far!");
			return 0;
		}
	}
/*
 * Good! Insert a move order!
 */
	tapeworm = new_order_instance();
	tapeworm->executing.keyword = "move";
	tapeworm->executing.routine = execute_move;
	tapeworm->executing.full_day_order = 1;
	tapeworm->executing.types[0] = ARGUMENT_IS_LOCATION_ID;
	tapeworm->arguments[0].location = bait;
	has = target->orders;
	if (has)
		has->prev = tapeworm;
	tapeworm->next = has;
	target->orders = tapeworm;
/*
 * Report
 */
	sprintf(work, "You feel compelled to go check what's at %s [%s]", bait->name, bait->id.text);
	unit_personal_event(target, today_number, work);
	unit_personal_event(invoker, today_number, "You feel a resonnance with your target");
	return 1;
}
#endif


#ifdef FX_OPEN_THE_WAY
/**
 ** FX_OPEN_WAY
 **/
static void fx_open_way(unit_s *invoker)
{
location_s	*bridge, *from, *toward;
unit_s		*target;
direction_s	*added;
int		days;
/*
 * Fast opening
 */
	target = invoker->target.unit;
	if (target->faction != invoker->faction) {
		unit_personal_event(invoker, today_number, "Target must be of your faction!");
		return;
	}
	from = invoker->true_location;
	toward = target->true_location;
	if (from == toward) {
		unit_personal_event(invoker, today_number, "Target present!");
		return;
	}
/*
 * Do the thing
 */
	bridge = random_location_id();
	bridge->name = "Astral plane";
	synthetic_tag("astr");
	bridge->type = terrain_from_tag(0);
/*
 * mage-only directions
 */
	days = roll_1Dx(6) + roll_1Dx(6) + roll_1Dx(6) + 3;
	added = new_direction_from_location();
	added->toward = bridge;
	added->days = days;
	added->name = "Way";
	added->skill = magecraft;
#ifdef USES_SKILL_LEVELS
	added->level = 1;
#endif
	added->next = from->exits;
	from->exits = added;
	added = new_direction_from_location();
	added->toward = from;
	added->days = days;
	added->name = "Way";
	added->skill = magecraft;
#ifdef USES_SKILL_LEVELS
	added->level = 1;
#endif
	added->next = bridge->exits;
	bridge->exits = added;
/*
 * mage-only directions
 */
	days = roll_1Dx(6) + roll_1Dx(6) + roll_1Dx(6) + 3;
	added = new_direction_from_location();
	added->toward = toward;
	added->days = days;
	added->name = "Way";
	added->skill = magecraft;
#ifdef USES_SKILL_LEVELS
	added->level = 1;
#endif
	added->next = bridge->exits;
	bridge->exits = added;
	added = new_direction_from_location();
	added->toward = bridge;
	added->days = days;
	added->name = "Way";
	added->skill = magecraft;
#ifdef USES_SKILL_LEVELS
	added->level = 1;
#endif
	added->next = toward->exits;
	toward->exits = added;
/*
 * Now report
 */
	location_global_event(invoker, today_number, "The sky suddendly rips open!");
	location_global_event(target, today_number, "The sky suddendly rips open!");
}
#endif


#ifdef FX_ONDINS
/**
 ** FX_ADD_ONDIN_TRANSFORM
 **	A two-stage transform. Once size equals added transforms, the metamorphosis
 ** takes place.
 **/
static int fx_add_ondin_transform(unit_s *invoker, skill_s *transform)
{
unit_s	*target;
carry_s	*tokens;
/*
 * Target must be > 0
 */
	target = invoker->target.unit;
	if (target->size < 1) {
		unit_personal_event(invoker, today_number, "Transformation fizzles");
		return 1;
	}
	if (target->race == transform->specific) {
		unit_personal_event(invoker, today_number, "Transformation fails to take hold");
		return 1;
	}
/*
 * Add transformation pending
 */
	tokens = unit_possessions(target, transform->end_product, 1);
	tokens->amount++;
/*
 * If critical size is reached, effect occurs
 */
	if (target->size <= tokens->amount) {
		unit_personal_event(target, today_number, "A startling transformation occurs!");
		target->race = transform->specific;
		tokens->amount = 0;
		return 1;
	}
/*
 * Greater size requires greater amounts
 */
printf("Ondin effects! %d tokens, size %d\n", tokens->amount, target->size);
	unit_personal_event(target, today_number, "You feel a growing dislocation");
	return 0;
}
#endif


/**
 ** FX_EXECUTE_EVENT
 **	Execute special effects
 **/
int fx_execute_event(item_s *fx, int amount, unit_s *invoker, skill_s *effective, order_s *current)
{
	switch (fx->special_effects) {
#ifdef FX_FAR_EYE
	    case FX_FAR_EYE:
		fx_far_eye(invoker, effective);
		return 1;
#endif
#ifdef FX_SPEEDUP_STRUCTURE
	    case FX_SPEEDUP_STRUCTURE:
		if (invoker->target.location)
			invoker->target.location->speedup = 1;
		break;
#endif
#ifdef FX_SPEEDUP_HARVEST
	    case FX_SPEEDUP_HARVEST:
		invoker->true_location->speedup = 1;
		break;
#endif
#ifdef FX_MIND_READING
	    case FX_MIND_READING:
		fx_mind_reading(invoker, 150);
		break;
#endif
#ifdef FX_WIZARD_WALKING
	    case FX_WIZARD_WALKING:
		return fx_wizard_walk(invoker);
#endif
#ifdef FX_BREED_CATTLE
	    case FX_BREED_CATTLE:
		if (invoker->true_location->outer) {
			unit_personal_event(invoker, today_number, "Breeding must occur outdoors");
			return 1;
		}
		synthetic_tag("catt");
		fx_increase_resources(invoker->true_location, item_from_tag(0), amount);
		break;
#endif
#ifdef FX_GRAIN_PLANT
	    case FX_GRAIN_PLANT:
		if (invoker->true_location->outer) {
			unit_personal_event(invoker, today_number, "Planting must occur outdoors");
			return 1;
		}
		synthetic_tag("grai");
		fx_increase_resources(invoker->true_location, item_from_tag(0), amount);
		break;
#endif
#ifdef FX_RAISE_TO_HERO
	    case FX_RAISE_TO_HERO:
		return fx_hero_raise(invoker, amount);
#endif
#ifdef FX_RANDOM_MOUNT
	    case FX_RANDOM_MOUNT:
		fx_summon_mount(invoker, fx);
		break;
#endif
#ifdef FX_MINERAL_SCRY
	    case FX_MINERAL_SCRY:
		fx_mineral_scrying(invoker);
		return 1;
#endif
#ifdef FX_SUMMONING
	    case FX_SUMMONING:
		return fx_invocation(invoker, effective, amount, 0);
#endif
#ifdef FX_SINGLE_SUMMONING
	    case FX_SINGLE_SUMMONING:
		return fx_invocation(invoker, effective, amount, 1);
#endif
#ifdef FX_CORPSE_RAISING
	    case FX_CORPSE_RAISING:
		return fx_raising(invoker, effective, amount);
#endif
#ifdef FX_FAIR_WEATHER
	    case FX_FAIR_WEATHER:
		if (invoker->true_location->outer)
			invoker->true_location->outer->next_climate = 1;
		else
			invoker->true_location->next_climate = 1;
		return 1;
#endif
#ifdef FX_METAMORPHOSIS
	    case FX_METAMORPHOSIS:
		fx_race_change(invoker, effective->specific);
		return 1;
#endif
#ifdef FX_MOUNT_CLONING
	    case FX_MOUNT_CLONING:
		return fx_copy_item(invoker, 2);
#endif
#ifdef FX_BEAST_CALL
	    case FX_BEAST_CALL:
		fx_beast_call(invoker);
		return 1;
#endif
#ifdef FX_MIND_SWAPPING
	    case FX_MIND_SWAPPING:
		fx_mind_swap(invoker, current);
		return 1;
#endif
#ifdef FX_LIFT_COINS
	    case FX_LIFT_COINS:
		fx_picking_purse(invoker);
		return 0;
#endif
#ifdef FX_PICK_POCKETS
	    case FX_PICK_POCKETS:
		fx_picking_pocket(invoker, effective);
		return 0;
#endif
#ifdef FX_WATERY_VISION
	    case FX_WATERY_VISION:
		fx_water_seeing(invoker);
		return 1;
#endif
#ifdef FX_ALTERED_UNIT
	    case FX_ALTERED_UNIT:
		synthetic_tag("ldr");
		invoker->altered = race_from_tag(0);
		unit_personal_event(invoker, today_number, "Your aura dampens...");
		return 1;
#endif
#ifdef FX_WILD_GROWTH
	    case FX_WILD_GROWTH:
		fx_wild_growth(invoker);
		break;
#endif
#ifdef FX_SACRIFICE
	    case FX_SACRIFICE:
		return fx_sacrify(invoker, amount, effective);
#endif
#ifdef FX_MEETING_MIND
	    case FX_MEETING_MIND:
		fx_distant_teaching(invoker);
		break;
#endif
#ifdef FX_FORTRESS
	    case FX_FORTRESS:
		fx_create_structure(invoker, "fort", "lord");
		return 1;
#endif
#ifdef FX_WEATHER_FAIR
	    case FX_WEATHER_FAIR:
#ifdef FX_WEATHER_SUNNY
	    case FX_WEATHER_SUNNY:
#endif
#ifdef FX_WEATHER_RAINY
	    case FX_WEATHER_RAINY:
#endif
#ifdef FX_WEATHER_WINDY
	    case FX_WEATHER_WINDY:
#endif
#ifdef FX_WEATHER_STORM
	    case FX_WEATHER_STORM:
#endif
		fx_change_weather(invoker->current, (fx->special_effects-FX_WEATHER_FAIR)+1);
		return 1;
#endif
#ifdef FX_CALL_SEA
	    case FX_CALL_SEA:
		return fx_drain_sea(invoker);
#endif
#ifdef FX_BEAST_GATHERING
	    case FX_BEAST_GATHERING:
		return fx_gather_beasts(invoker);
#endif
#ifdef FX_CHASM_OPENS
	    case FX_CHASM_OPENS:
		fx_chasm_opens(invoker);
		return 1;
#endif
#ifdef FX_ASSASSINATION
	    case FX_ASSASSINATION:
		return fx_murder(invoker, effective);
#endif
#ifdef FX_MOSS_POLLUTION
	    case FX_MOSS_POLLUTION:
		return fx_moss(invoker, amount);
#endif
#ifdef FX_CAPTURE_BEAST
	    case FX_CAPTURE_BEAST:
#ifdef FX_CAPTURE_CREATURE
	    case FX_CAPTURE_CREATURE:
#endif
#ifdef FX_CAPTURE_MONSTER
	    case FX_CAPTURE_MONSTER:
#endif
		return fx_capture_attempt(invoker, (fx->special_effects-FX_CAPTURE_BEAST));
#endif
#ifdef FX_DEVASTATION
	    case FX_DEVASTATION:
		fx_devastate(invoker);
		return 0;
#endif
#ifdef FX_PORTAL_OF_AIR
	    case FX_PORTAL_OF_AIR:
		fx_open_portal(invoker, air_skill);
		return 1;
#endif
#ifdef FX_PORTAL_OF_EARTH
	    case FX_PORTAL_OF_EARTH:
		fx_open_portal(invoker, earth_skill);
		return 1;
#endif
#ifdef FX_PORTAL_OF_FIRE
	    case FX_PORTAL_OF_FIRE:
		fx_open_portal(invoker, fire_skill);
		return 1;
#endif
#ifdef FX_PORTAL_OF_VOID
	    case FX_PORTAL_OF_VOID:
		fx_open_portal(invoker, void_skill);
		return 1;
#endif
#ifdef FX_PORTAL_OF_WATER
	    case FX_PORTAL_OF_WATER:
		fx_open_portal(invoker, water_skill);
		return 1;
#endif
#ifdef FX_ARMAGEDDON
	    case FX_ARMAGEDDON:
		fx_launch_armageddon(invoker, effective);
		return 1;
#endif
#ifdef FX_LURE_OTHER
	    case FX_LURE_OTHER:
		return fx_lure_unit(invoker, effective);
#endif
#ifdef FX_OPEN_THE_WAY
	    case FX_OPEN_THE_WAY:
		fx_open_way(invoker);
		return 1;
#endif
#ifdef FX_ONDINS
	    case FX_ONDINS:
		return fx_add_ondin_transform(invoker, effective);
#endif
	    default:
		printf("Unimplemented FX %d for [%s]\n", fx->special_effects, fx->tag.text);
	    case 0:
		break;
	}
	return 0;
}


/******************************************************************************/
/**
 ** FX_DUPLICATE_RESOURCE
 **	Increase the amount of resource available
 **/
static void fx_duplicate_resource(location_s *location, location_s *outer, resource_valid cmp, int max)
{
resource_s	*resource;
resource_s	*token;
/*
 * Each ressource may yield a new amount of tokens
 */
	for (resource = outer->resources; resource; resource = resource->next)
		if ((*cmp)(resource->type)) {
			token = new_resource_instance();
			token->next = location->resources;
			location->resources = token;
			token->type = resource->type;
			token->remains = resource->remains / 2;
			if (max && token->remains > max)
				token->remains *= max;
		}
}


#ifdef FX_CONTAINS_MINERALS
/**
 ** ITEM_IS_UNLIVING
 **	Predicates for mineral products
 **/
static int item_is_unliving(item_s *item)
{
	if (item->item_live)
		return 0;
	return 1;
}
#endif


#ifdef FX_CONTAINS_LIVE
/**
 ** ITEM_IS_LIVING
 **	Predicates for live products
 **/
static int item_is_living(item_s *item)
{
	if (item->item_live)
		return 1;
	return 0;
}
#endif


/**
 ** ITEM_IS_SPECIFIC
 **	Predicates for specific products
 **/
static int item_is_specific(item_s *item)
{
	if (item == targeted_item)
		return 1;
	return 0;
}


/**
 ** FX_LOCATION_INIT
 **	Some locations have special properties
 **/
void fx_location_init(location_s *location)
{
	switch (location->type->special_effect) {
#ifdef FX_CONTAINS_MINERALS
	    case FX_CONTAINS_MINERALS:
		fx_duplicate_resource(location, location->outer, item_is_unliving, 0);
		break;
#endif
#ifdef FX_CONTAINS_FISH
	    case FX_CONTAINS_FISH:
		targeted_item = item_fish;
		fx_duplicate_resource(location, location->outer, item_is_specific, 0);
		break;
#endif
#ifdef FX_CONTAINS_LIVE
	    case FX_CONTAINS_LIVE:
		fx_duplicate_resource(location, location->outer, item_is_living, 0);
		break;
#endif
#ifdef FX_ABSORB_SKILL_0
	    case FX_ABSORB_SKILL_0:
		break;
#endif
#ifdef FX_ABSORB_SKILL_1
	    case FX_ABSORB_SKILL_1:
		break;
#endif
#ifdef FX_ABSORB_SKILL_2
	    case FX_ABSORB_SKILL_2:
		break;
#endif
#ifdef FX_ABSORB_SKILL_3
	    case FX_ABSORB_SKILL_3:
		break;
#endif
#ifdef FX_CONTAINS_ENTERTAINERS
	    case FX_CONTAINS_ENTERTAINERS:
		targeted_item = token_entertain;
		fx_duplicate_resource(location, location->outer, item_is_specific, 0);
		break;
#endif
#ifdef FX_CEMETARY
	    case FX_CEMETARY:
		break;
#endif
	    default:
		printf("Unimplemented FX %d for [%s]\n", location->type->special_effect, location->type->tag.text);
	    case 0:
		break;
	}
}



/******************************************************************************/


#ifdef FX_SEEK_CITY
/**
 ** MATCH_CITY
 **/
static int match_city(location_s *here)
{
	if (here->type == terrain_city)
		return 1;
	return 0;
}


/**
 ** FX_SEEKING_CITY
 **	Seek the nearest city, within X days move. Use the generalise search.
 **/
static void fx_seeking_city(unit_s *user)
{
location_s	*starting_point;
location_s	*city, *toward;
/*
 * First check
 */
	if ((starting_point = user->true_location)->type->type != TERRAIN_COUNTRY)
		return;
	max_distance();
	if (!search_for_location(starting_point, 0, 60, match_city, &city, &toward))
		return;
	sprintf(work, "Compass indicates that the nearest city is %s [%s], toward %s [%s]",
				city->name, city->id.text, toward->name, toward->id.text);
	unit_personal_event(user, 30, work);
}
#endif


#ifdef FX_WAYFINDER
/**
 ** FX_USE_WAYFINDER
 **	Special: search for any target, over really wide ranges!
 **/
static void fx_use_wayfinder(unit_s *owner)
{
location_s	*found, *walk;
/*
 * Search for current target
 */
	switch (owner->target_type) {
	    case ARGUMENT_IS_ITEM_TAG:
		targeted_item = owner->target.item;
		if (search_for_location(owner->true_location, 0, 181, match_resource, &found, &walk) <= 0)
			return;
		break;
	    default:
		return;
	}
	sprintf(work, "Wayfinder indicates toward %s [%s]", walk->name, walk->id.text);
	unit_personal_event(owner, 30, work);
}
#endif


#ifdef FX_SCROLL_XXXX
/**
 ** FX_SCROLL_XXXX
 **	Special: gain experience in a skill
 **/
static void fx_scroll(unit_s *owner, carry_s *item)
{
experience_s	*gained;
/*
 * Add to experience
 */
	gained = unit_experiences(owner, item->item->use_skill, 1);
	(void)add_to_experience(owner, gained, item->item->use_skill, item->equipped * 30 * SKILL_POINTS_PER_DAY);
	item->amount -= item->equipped;
	item->equipped = 0;
}
#endif


/**
 ** FX_END_OF_TURN
 **	Triggers on end-of-turn special FX
 **/
void fx_end_of_turn(unit_s *unit, carry_s *item)
{
	switch (item->item->special_effects) {
#ifdef FX_SEEK_CITY
	    case FX_SEEK_CITY:
		fx_seeking_city(unit);
		return;
#endif
#ifdef FX_WAYFINDER
	    case FX_WAYFINDER:
		if (item->equipped == 0)
			return;
		fx_use_wayfinder(unit);
		return;
#endif
#ifdef FX_SCROLL_XXXX
	    case FX_SCROLL_XXXX:
		if (item->equipped == 0)
			return;
		fx_scroll(unit, item);
		return;
#endif
	    default:
		break;
	}
}
