/* $Id: command_u.h,v 1.6 1999/04/05 08:56:29 archer Exp $
 *	Lists the valid orders
 */

/**
 ** No execution occurs there
 **/
#ifdef MAP_EDITOR
#define	unexecutable		0
#define execute_accept		0
#define execute_at		0
#define execute_attack		0
#define execute_bestow		0
#define execute_buy		0
#define execute_caravan		0
#define execute_capacity	0
#define execute_christen	0
#define execute_claim		0
#define execute_combat		0
#define execute_day		0
#define execute_describe	0
#define execute_disband		0
#define execute_drop		0
#define execute_eject		0
#define execute_enter		0
#define execute_equip		0
#define execute_fate		0
#define execute_forget		0
#define execute_guard		0
#define execute_get		0
#define execute_give		0
#define execute_id		0
#define execute_have		0
#define execute_leader		0
#define execute_leading		0
#define execute_leave		0
#define execute_merge		0
#define execute_move		0
#define execute_name		0
#define execute_oath		0
#define execute_patrol		0
#define execute_pillage		0
#define execute_promote		0
#define execute_retreat		0
#define execute_recruit		0
#define execute_see		0
#define execute_sell		0
#define execute_setting		0
#define execute_size		0
#define execute_skill		0
#define execute_split		0
#define execute_stack		0
#define execute_stance		0
#define execute_stay		0
#define execute_study		0
#define execute_swap		0
#define execute_synchro		0
#define execute_tactic		0
#define execute_target		0
#define execute_teach		0
#define execute_unstack		0
#define execute_use		0
#define execute_withdraw	0
#define execute_work		0
#define execute_yield		0
#define order_was_executed	0
#else
/**
 ** Prototypes
 **/
extern int		execute_accept(unit_s *,order_s *);
extern int		execute_at(unit_s *,order_s *);
extern int		execute_attack(unit_s *,order_s *);
extern int		execute_bestow(unit_s *,order_s *);
extern int		execute_buy(unit_s *,order_s *);
extern int		execute_capacity(unit_s *,order_s *);
extern int		execute_caravan(unit_s *,order_s *);
extern int		execute_christen(unit_s *,order_s *);
extern int		execute_claim(unit_s *,order_s *);
extern int		execute_combat(unit_s *,order_s *);
extern int		execute_day(unit_s *,order_s *);
extern int		execute_describe(unit_s *,order_s *);
extern int		execute_disband(unit_s *,order_s *);
extern int		execute_drop(unit_s *,order_s *);
extern int		execute_eject(unit_s *,order_s *);
extern int		execute_enter(unit_s *,order_s *);
extern int		execute_equip(unit_s *,order_s *);
extern int		execute_fate(unit_s *,order_s *);
extern int		execute_forget(unit_s *,order_s *);
extern int		execute_guard(unit_s *,order_s *);
extern int		execute_get(unit_s *,order_s *);
extern int		execute_give(unit_s *,order_s *);
extern int		execute_have(unit_s *,order_s *);
extern int		execute_id(unit_s *,order_s *);
extern int		execute_leader(unit_s *,order_s *);
extern int		execute_leading(unit_s *,order_s *);
extern int		execute_leave(unit_s *,order_s *);
extern int		execute_move(unit_s *,order_s *);
extern int		execute_merge(unit_s *,order_s *);
extern int		execute_name(unit_s *,order_s *);
extern int		execute_oath(unit_s *,order_s *);
extern int		execute_patrol(unit_s *,order_s *);
extern int		execute_pillage(unit_s *,order_s *);
extern int		execute_promote(unit_s *,order_s *);
extern int		execute_retreat(unit_s *,order_s *);
extern int		execute_recruit(unit_s *,order_s *);
extern int		execute_see(unit_s *,order_s *);
extern int		execute_sell(unit_s *,order_s *);
extern int		execute_setting(unit_s *,order_s *);
extern int		execute_size(unit_s *,order_s *);
extern int		execute_skill(unit_s *,order_s *);
extern int		execute_split(unit_s *,order_s *);
extern int		execute_stack(unit_s *,order_s *);
extern int		execute_stance(unit_s *,order_s *);
extern int		execute_stay(unit_s *,order_s *);
extern int		execute_study(unit_s *,order_s *);
extern int		execute_swap(unit_s *,order_s *);
extern int		execute_synchro(unit_s *,order_s *);
extern int		execute_tactic(unit_s *,order_s *);
extern int		execute_target(unit_s *,order_s *);
extern int		execute_teach(unit_s *,order_s *);
extern int		execute_unstack(unit_s *,order_s *);
extern int		execute_use(unit_s *,order_s *);
extern int		execute_withdraw(unit_s *,order_s *);
extern int		execute_work(unit_s *,order_s *);
extern int		execute_yield(unit_s *,order_s *);
extern int		order_was_executed(unit_s *, order_s *);
extern int		unexecutable(unit_s *,order_s *);
#endif
