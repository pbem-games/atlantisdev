/* $Id: checker_u.c,v 1.25 1999/04/05 08:56:29 archer Exp $
 *	Commands checking module
 */
#include "checker.h"
#include "command_e.h"
#include "command_u.h"


/**
 ** Cache
 **/
skill_s		*magecraft;


/**
 ** Strings pulled from report module
 **/
#include "enumstxt.c"


/**
 ** ORDER_WAS_EXECUTED
 **	Unit just finished
 **/
int order_was_executed(unit_s *unit, order_s *current)
{
	if (days < 0)
		fprintf(current_report, "; Infinite wait!!!\n");
	else
		if (--days < 1)
			fprintf(current_report, "; No-op\n");
		else
			fprintf(current_report, "; Waits %d day%s_n", days, days > 1 ? "s" : "");
	return 0;
}


/**
 ** UNEXECUTABLE
 **	Default call for orders
 **/
int unexecutable(unit_s *unit, order_s *current)
{
	fprintf(current_report, "; command not yet implemented. The GM will be notified\n");
	return 0;
}


/**
 ** EXECUTE_COMBAT
 **	Unit selects a combat setting
 **/
int execute_combat(unit_s *unit, order_s *current)
{
combat_set_s	settings[MAX_COMBAT_SETTING];
item_s		*item;
skill_s		*skill;
int		i, j;
char		sep;
/*
 * Checker 1
 */
	for (i = 0; i < MAX_COMBAT_SETTING; i++) {
		if (keyword("MELEE")) {
			settings[i].option = COMBAT_SET_MELEE;
			continue;
		}
		if (keyword("PARRY")) {
			settings[i].option = COMBAT_SET_PARRY;
			continue;
		}
		if (!*string_ptr)
			break;
		if (!separate_tag()) {
			fprintf(current_report, ">>> Invalid tag\n");
			return 1;
		}
		if ((item = item_from_tag(0)) != 0) {
			if (!item->combat_action.effect) {
				fprintf(current_report, ">>> %s cannot be used in combat\n", item->name);
				return 1;
			}
			settings[i].option = COMBAT_SET_ITEM;
			settings[i].u.use_item = item;
			continue;
		}
		if ((skill = skill_from_tag(0)) != 0) {
			if (!skill->combat_action.effect) {
				fprintf(current_report, ">>> %s cannot be used in combat\n", skill->name);
				return 1;
			}
			settings[i].option = COMBAT_SET_SKILL;
			settings[i].u.use_skill = skill;
			continue;
		}
		fprintf(current_report, ">>> Invalid combat setting, skill or item not found\n");
		return 1;
	}
/*
 * Summarise settings
 */
	fprintf(current_report, "; combat actions");
	sep = ':';
	for (j = 0; j < i; j++) {
		switch (settings[j].option) {
		    case COMBAT_SET_MELEE:
			fprintf(current_report, "%c melee", sep);
			break;
		    case COMBAT_SET_PARRY:
			fprintf(current_report, "%c parry", sep);
			break;
		    case COMBAT_SET_SKILL:
			fprintf(current_report, "%c %s", sep, settings[j].u.use_skill->name);
			break;
		    case COMBAT_SET_ITEM:
			fprintf(current_report, "%c use %s", sep, settings[j].u.use_item->name);
			break;
		}
		sep = ',';
	}
	putc('\n', current_report);
	return 0;
}


/**
 ** EXECUTE_BUY
 **	Unit wants to buy
 **/
int execute_buy(unit_s *unit, order_s *current)
{
int		amount, price;
item_s		*item;
market_s	*market;
/*
 * amount
 */
	separate_token();
	amount = atoi(token_keyword);
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Must be leader to buy\n");
		return 1;
	}
	separate_token();
	price = atoi(token_keyword);
/*
 * Try to purchase
 */
	if (unit->true_location) {
		for (market = unit->true_location->markets; market; market = market->next)
			if (market->type == item && market->offered.initial_amount)
				break;
	} else
		market = 0;
	if (!market)
		fprintf(current_report, "; beware: not sold on the market, do you know marketing?\n");
	else
		if (price && market->offered.negociated_price > price)
			fprintf(current_report, "; beware: price asked is higher\n");
	fprintf(current_report, "; buys ");
	if (amount)
		fprintf(current_report, "as many");
	else
		fprintf(current_report, "%d", amount);
	fprintf(current_report, " %s at the price of ", amount == 1 ? item->name : item->plural);
	if (price == 0)
		fprintf(current_report, "the market\n");
	else
		fprintf(current_report, "$%d\n", price);
	return 0;
}


/**
 ** EXECUTE_SELL
 **	Unit wants to sell
 **/
int execute_sell(unit_s *unit, order_s *current)
{
int		amount, price;
item_s		*item;
carry_s		*owns;
market_s	*market;
/*
 * amount
 */
	separate_token();
	amount = atoi(token_keyword);
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Must be leader to sell\n");
		return 1;
	}
	separate_token();
	price = atoi(token_keyword);
/*
 * Do you have anything to sell?
 */
	if ((owns = unit_possessions(unit, item, 0)) == 0 || owns->amount < amount)
		fprintf(current_report, "; beware: you don't have that many\n");
/*
 * Try to purchase
 */
	if (unit->true_location) {
		for (market = unit->true_location->markets; market; market = market->next)
			if (market->type == item && market->wanted.initial_amount)
				break;
	} else
		market = 0;
	if (!market)
		fprintf(current_report, "; beware: not sold on the market, do you know marketing?\n");
	else
		if (price && market->wanted.negociated_price < price)
			fprintf(current_report, "; beware: price offered is lower\n");
	fprintf(current_report, "; sells ");
	if (amount)
		fprintf(current_report, "as many");
	else
		fprintf(current_report, "%d", amount);
	fprintf(current_report, " %s at the price of ", amount == 1 ? item->name : item->plural);
	if (price == 0)
		fprintf(current_report, "the market\n");
	else
		fprintf(current_report, "$%d\n", price);
	return 0;
}


/**
 ** EXECUTE_GUARD
 **	Unit switch to GUARD mode
 **/
int execute_guard(unit_s *unit, order_s *current)
{
experience_s	*exp;
/*
 * Must be at least combat-1
 */
	string_ptr = "cmbt";
	separate_tag();
	if ((exp = unit_experiences(unit, skill_from_tag(0), 0)) == 0 ||
	    exp->level < 1) {
		fprintf(current_report, ">>> Must have 1st combat\n");
		return 0;
	}
	unit->is_guarding = 1;
	unit->was_guarding = 1;
	fprintf(current_report, "; guard mode\n");
	return 0;
}


/**
 ** EXECUTE_DISBAND
 **	Unit disbands
 **/
int execute_disband(unit_s *unit, order_s *current)
{
/*
 * Must be at least combat-1
 */
	unit->size = 0;
	unit->race = 0;
	fprintf(current_report, "; disbands\n");
	return 0;
}


/**
 ** EXECUTE_PILLAGE
 **	Unit will pillage
 **/
int execute_pillage(unit_s *unit, order_s *current)
{
experience_s	*exp;
/*
 * Must be at least combat-2
 */
	string_ptr = "cmbt";
	separate_tag();
	if ((exp = unit_experiences(unit, skill_from_tag(0), 0)) == 0 ||
	    exp->level < 2) {
		fprintf(current_report, ">>> Must have 2nd combat\n");
		return 0;
	}
	if (unit->true_location &&
	    unit->size * 60 < unit->true_location->taxes)
		fprintf(current_report, "; beware: may not have enough figures to pillage\n");
	fprintf(current_report, "; pillage region\n");
	return 0;
}


/**
 ** EXECUTE_TARGET
 **	Unit selects a target
 **/
int execute_target(unit_s *unit, order_s *current)
{
location_s	*location;
terrain_s	*terrain;
unit_s		*target;
item_s		*item;
skill_s		*skill;
/*
 * Checker
 */
	if (!separate_tag()) {
		fprintf(current_report, ">>> Invalid target\n");
		return 1;
	}
/*
 * Go parse
 */
	if ((target = potential_unit_id(0)) != 0) {
		unit->target.unit = target;
		fprintf(current_report, "; target is now unit [%s]\n", target->id.text);
		return 0;
	}
	if ((location = location_from_id(0)) != 0) {
		unit->target.location = location;
		fprintf(current_report, "; target is now location %s [%s]\n", location->name, location->id.text);
		return 0;
	}
	if ((terrain = terrain_from_tag(0)) != 0) {
		unit->target.terrain = terrain;
		fprintf(current_report, "; target is now structure type %s\n", terrain->name);
		return 0;
	}
	if ((item = item_from_tag(0)) != 0) {
		unit->target.item = item;
		fprintf(current_report, "; target is now item type %s\n", item->name);
		return 0;
	}
	if ((skill = skill_from_tag(0)) != 0) {
		unit->target.skill = skill;
		fprintf(current_report, "; target is now skill %s\n", skill->name);
		return 0;
	}
	fprintf(current_report, ">>> Unknown target\n");
	return 1;
}


/**
 ** EXECUTE_STANCE
 **	Faction changes. Driven by units, to use conditions
 **/
int execute_stance(unit_s *unit, order_s *current)
{
faction_s	*diplomacy;
/*
 * Checker 1
 */
	separate_token();
	if (parsed_enum(token_keyword, stance_arguments) < 0) {
		fprintf(current_report, ">>> Invalid stance\n");
		return 1;
	}
/*
 * Go parse
 */
	if (!separate_tag() || (diplomacy = faction_from_id(0)) == 0) {
		fprintf(current_report, ">>> Invalid faction ID\n");
		return 1;
	}
	if (diplomacy == current_faction)
		fprintf(current_report, "; changed default stance\n");
	else
		fprintf(current_report, "; changed stance toward %s\n", diplomacy->name);
	return 0;
}


/**
 ** EXECUTE_TACTIC
 **	Tactical settings.
 **/
int execute_tactic(unit_s *unit, order_s *current)
{
/*
 * Checker 1
 */
	separate_token();
	if (parsed_enum(token_keyword, participate_modes) < 0) {
		fprintf(current_report, ">>> Invalid participation\n");
		return 1;
	}
	separate_token();
	if (parsed_enum(token_keyword, battlefield_ranks) < 0) {
		fprintf(current_report, ">>> Invalid rank\n");
		return 1;
	}
	separate_token();
	if (parsed_enum(token_keyword, battlefield_files) < 0) {
		fprintf(current_report, ">>> Invalid file\n");
		return 1;
	}
	separate_token();
	if (parsed_enum(token_keyword, battlefield_moves) < 0) {
		fprintf(current_report, ">>> Invalid movement\n");
		return 1;
	}
	fprintf(current_report, "; changed tactics\n");
	return 0;
}


/**
 ** EXECUTE_SETTING
 **	Unit state change.
 **/
int execute_setting(unit_s *unit, order_s *current)
{
char	*s;
/*
 * Checker 1
 */
	separate_token();
	switch (parsed_enum(token_keyword, possible_settings)) {
	    case 0: /* advertise */
		s = "unit faction visibility";
		break;
	    case 1: /* announce */
		s = "unit visibility";
		break;
	    case 2: /* html */
		s = "html reports";
		break;
	    case 3: /* miser */
		s = "fund saving";
		break;
	    case 4: /* silent */
		s = "unit activity silence";
		break;
	    case 5: /* support */
		s = "unit fund support";
		break;
	    case 6: /* terse */
		s = "battle short reports";
		break;
	    default:
		fprintf(current_report, ">>> Invalid setting\n");
		return 1;
	}
/*
 * Go parse
 */
	separate_token();
	switch (parsed_enum(token_keyword, "on\noff")) {
	    case 0:
		fprintf(current_report, "; sets %s to on\n", s);
		break;
	    case 1:
		fprintf(current_report, "; clears %s\n", s);
		break;
	    default:
		fprintf(current_report, ">>> Must be ON or OFF\n");
		return 1;
	}
	return 0;
}


/**
 ** EXECUTE_RECRUIT
 **	Unit wants to recruit. Only leaders do that.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed!
 **/
int execute_recruit(unit_s *unit, order_s *current)
{
unit_s	*created;
race_s	*race;
int	amount;
/*
 * Checker 1
 */
	if (unit->race && unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Only leaders recruit\n");
		return 1;
	}
/*
 * Go parse
 */
	if (!separate_tag() || (created = potential_unit_id(current_faction)) == 0 || created->faction != current_faction) {
		fprintf(current_report, ">>> Invalid unit ID, or not of your faction\n");
		return 1;
	}
	separate_token();
	if (!isdigit(token_keyword[0])) {
		fprintf(current_report, ">>> Missing amount of recruits\n");
		return 1;
	}
	amount = atoi(token_keyword);
	if (!separate_tag() || (race = race_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid race tag\n");
		return 1;
	}
	separate_token();
	if (token_keyword[0] && !isdigit(token_keyword[0]))
		fprintf(current_report, "; beware: price will be ignored\n");
	if (created->race && created->race != race) 
		fprintf(current_report, ">>> Differing races between recruit and unit\n");
	if (!created->race)
		created->race = race;
	if (created->true_location && created->true_location != unit->true_location)
		fprintf(current_report, "; beware: must meet created unit to add figures to it\n");
/*
 * Emulation (quick'n dirty)
 */
	fprintf(current_report, "; recruiting %d %s\n", amount, amount > 1 ? race->plural : race->name);
	created->size += amount;
	if (created->inactive) {
		created->inactive = 0;
		created->current = unit->current;
		created->true_location = unit->true_location;
		created->leader = unit;
		created->next_location = unit->stack;
		unit->stack = created;
	}
	return 0;
}


/**
 ** EXECUTE_GET
 **	Unit gets something from another unit of the same.
 **/
int execute_get(unit_s *unit, order_s *current)
{
unit_s	*recipient;
item_s	*item;
carry_s	*owns;
int	amount;
int	left;
	if (!separate_tag() || (recipient = potential_unit_id(current_faction)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (recipient->faction != current_faction) {
		fprintf(current_report, ">>> Target unit must be of your faction\n");
		return 1;
	}
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	separate_token();
	amount = left = 0;
	if (isdigit(token_keyword[0])) {
		amount = atoi(token_keyword);
		separate_token();
			left = atoi(token_keyword);
	} else
		fprintf(current_report, "; beware: grabbing all items\n");
	owns = unit_possessions(recipient, item, 0);
	if (owns && amount == 0)
		amount = owns->amount - left;
	if (!owns || owns->amount < amount+left)
		fprintf(current_report, "; beware: will wait until it has the quantities\n");
	if (unit->true_location != recipient->true_location)
		fprintf(current_report, "; beware: will wait until you meet holder\n");
	fprintf(current_report, "; gets %d %s from [%s]\n", amount, amount > 1 ? item->plural : item->name, recipient->id.text);
	if (owns)
		owns->amount -= amount;
	owns = unit_possessions(unit, item, 1);
	owns->amount += amount;
	return 0;
}


/**
 ** EXECUTE_DROP
 **	Unit drops something in a stockpile.
 **/
int execute_drop(unit_s *unit, order_s *current)
{
item_s	*item;
carry_s	*owns;
int	amount;
int	left;
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	separate_token();
	amount = left = 0;
	if (isdigit(token_keyword[0])) {
		amount = atoi(token_keyword);
		separate_token();
			left = atoi(token_keyword);
	} else
		fprintf(current_report, "; beware: dropping all items\n");
	owns = unit_possessions(unit, item, 0);
	if (owns && amount == 0)
		amount = owns->amount - left;
	if (!owns || owns->amount < amount+left)
		fprintf(current_report, "; beware: will wait until you have the quantities\n");
	fprintf(current_report, "; drops %d %s\n", amount, amount > 1 ? item->plural : item->name);
	if (owns)
		owns->amount -= amount;
	return 0;
}


/**
 ** EXECUTE_GIVE
 **	Unit gives something to another unit. Both must be at the same location
 ** and the other must treat the first as friendly.
 **/
int execute_give(unit_s *unit, order_s *current)
{
unit_s	*recipient;
item_s	*item;
carry_s	*owns;
int	amount;
int	left;
	if (!separate_tag() || (recipient = potential_unit_id(current_faction)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	separate_token();
	amount = left = 0;
	if (isdigit(token_keyword[0])) {
		amount = atoi(token_keyword);
		separate_token();
			left = atoi(token_keyword);
	} else
		fprintf(current_report, "; beware: handing all items\n");
	owns = unit_possessions(unit, item, 0);
	if (owns && amount == 0)
		amount = owns->amount - left;
	if (!owns || owns->amount < amount+left)
		fprintf(current_report, "; beware: will wait until you have the quantities\n");
	if (unit->true_location != recipient->true_location)
		fprintf(current_report, "; beware: will wait until you meet  recipient\n");
	fprintf(current_report, "; hands %d %s to [%s]\n", amount, amount > 1 ? item->plural : item->name, recipient->id.text);
	if (owns)
		owns->amount -= amount;
	owns = unit_possessions(recipient, item, 1);
	owns->amount += amount;
	return 0;
}


/**
 ** EXECUTE_EQUIP
 **	Unit marks equipment as used.
 **/
int execute_equip(unit_s *unit, order_s *current)
{
item_s	*item;
carry_s	*owns;
int	amount;
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item tag\n");
		return 1;
	}
	separate_token();
	amount = 0;
	amount = atoi(token_keyword);
	if (amount > unit->size)
		fprintf(current_report, "; beware: more items than figures\n");
	owns = unit_possessions(unit, item, 0);
	if (owns && amount > owns->amount)
		fprintf(current_report, "; beware: equip more items than might have\n");
/*** HACK ***/
	if (owns)
		owns->equipped = amount;
	if (!isdigit(token_keyword[0]))
		fprintf(current_report, "; equip all %s\n", item->plural);
	else
		if (!amount)
			fprintf(current_report, "; unequip all %s\n", item->plural);
		else
			fprintf(current_report, "; now equipped %d %s\n", amount, amount > 1 ? item->plural : item->name);
	return 0;
}


/**
 ** EXECUTE_WITHDRAW
 **	Withdraw from faction fund.
 **/
int execute_withdraw(unit_s *unit, order_s *current)
{
int	amount;
	separate_token();
	if ((amount = atoi(token_keyword)) < 1) {
		fprintf(current_report, ">>> Withdraw invalid amount\n");
		return 1;
	}
	if (!unit->true_location || strcmp(unit->true_location->type->name, "city"))
		fprintf(current_report, "; beware: withdraw may fail if you're not in a city\n");
	if (amount > current_faction->faction_fund)
		fprintf(current_report, "; beware: you need a reward, or your fund will be exhausted\n");
	fprintf(current_report, "; withdrawing %d coin%s from faction fund\n", amount, amount > 1 ? "s" : "");
	current_faction->faction_fund -= amount;
	if (current_faction->faction_fund < 0)
		current_faction->faction_fund = 0;
	return 0;
}


/**
 ** EXECUTING_CHRISTEN
 **	The unit is attempting to rename a location
 **/
int execute_christen(unit_s *unit, order_s *current)
{
	separate_token();
	if (!token_keyword[0]) {
		fprintf(current_report, ">>> Missing name\n");	
		return 1;
	}
	if (!unit->current || unit->current->type->type != TERRAIN_STRUCTURE)
		fprintf(current_report, "; beware: only structures may be christened at will\n");
	else
		if (unit->current->present != unit)
			fprintf(current_report, "; beware: must be the owner of the structure, are you PROMOTED?\n");
	fprintf(current_report, "; rename structure to `%s'\n", token_keyword);
	return 0;
}


/**
 ** EXECUTING_RETREAT
 **	The unit is attempting to cancel the movement
 **/
int execute_retreat(unit_s *unit, order_s *current)
{
	if (!unit->toward) {
		fprintf(current_report, ">>> Must be moving\n");	
		return 1;
	}
	fprintf(current_report, "; cancel move and go back in %d days\n", unit->already_moved);
	return 0;
}


/**
 ** EXECUTING_HAVE
 **	Wait for the location
 **/
int execute_have(unit_s *unit, order_s *current)
{
carry_s	*owns;
item_s	*item;
int	amount;
	if (!separate_tag() || (item = item_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid item type\n");
		return 1;
	}
	separate_token();
	amount = atoi(token_keyword);
	if (amount <= 0)
		amount = 1;
	fprintf(current_report, "; wait until you have %d %s\n", amount, amount > 1 ? item->plural : item->name);
	owns = unit_possessions(unit, item, 1);
	if (owns->amount < amount)
		owns->amount = amount;
	return 0;
}


/**
 ** EXECUTING_ATTACK
 **	Wait for the unit's presence
 **/
int execute_attack(unit_s *unit, order_s *current)
{
unit_s	*target;
	if (!separate_tag() || !(target = potential_unit_id(0))){
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (unit->faction == target->faction) {
		fprintf(current_report, ">>> Can't attack your own units!\n");
		return 1;
	}
	if (unit->true_location != target->true_location)
		fprintf(current_report, "; warning: wait until you can see [%s] in the area\n", target->id.text);
	fprintf(current_report, "; attack [%s]\n", target->id.text);
	return 0;
}


/**
 ** EXECUTING_SYNCHRO
 **	Wait for the unit's synchro
 **/
int execute_synchro(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !potential_unit_id(0)) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you get synchronised with [%s]", id_token.text);
	separate_token();
	if (isnumber(token_keyword[0]))
		fprintf(current_report, " on post ID %s\n", token_keyword);
	else
		putc('\n', current_report);
	return 0;
}


/**
 ** EXECUTING_SWAP
 **	Swap with someone
 **/
int execute_swap(unit_s *unit, order_s *current)
{
unit_s	*target;
item_s	*mine, *yours;
carry_s	*has;
int	give, get;
/*
 * Target
 */
	if (!separate_tag() || !(target = potential_unit_id(0))) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
/*
 * Items
 */
	separate_token();
	give = atoi(token_keyword);
	if (!separate_tag() || !(mine = item_from_tag(0))) {
		fprintf(current_report, ">>> Invalid item TAG\n");
		return 1;
	}
/*
 * Received
 */
	separate_token();
	get = atoi(token_keyword);
	if (!separate_tag() || !(yours = item_from_tag(0))) {
		fprintf(current_report, ">>> Invalid item TAG\n");
		return 1;
	}
/*
 * Now check validity
 */
	has = unit_possessions(unit, mine, 0);
	if (!has || has->amount < give) {
		fprintf(current_report, "; beware: you lack the %d %s\n", give, mine->plural);
		if (has)
			has->amount = 0;
	} else
		has->amount -= give;
	has = unit_possessions(unit, yours, 1);
	has->amount += get;
	fprintf(current_report, "; trade your %d %s for %s's %d %s\n", give, mine->plural,
			target->id.text, get, yours->plural);
	return 0;
}


/**
 ** EXECUTE_ACCEPT
 **	Unit accepts another
 **/
int execute_accept(unit_s *unit, order_s *current)
{
unit_s		*target;
/*
 * Checker
 */
	if (!separate_tag() || (target = potential_unit_id(0)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
/*
 * Go parse
 */
	if (target->faction == unit->faction)
		fprintf(current_report, "; beware: accept ignored for same faction units\n");
	fprintf(current_report, "; accept [%s]'s stacking\n", unit->id.text);
	return 0;
}


/**
 ** EXECUTE_CAPACITY
 **	Unit may use the following capacity
 **/
int execute_capacity(unit_s *unit, order_s *current)
{
int	i, excess;
/*
 * Checker
 */
	separate_token();
	if ((i = parsed_enum(token_keyword, movement_modes)) < 0) {
		fprintf(current_report, ">>> Invalid movement mode\n");
		return 1;
	}
	excess = atoi(string_ptr);
/*
 * Report
 */
	fprintf(current_report, "; wait until you can go %s", token_keyword);
	if (excess < 0)
		fprintf(current_report, " with %d units margin\n", -excess);
	else
		if (excess > 0)
			fprintf(current_report, " with %d units overload\n", excess);
		else
			putc('\n', current_report);
	return 0;
}


/**
 ** EXECUTING_OATH
 **	Declare for unit's faction
 **/
int execute_oath(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Validate target
 */
	if (!separate_tag() || !(target = unit_from_id(0))) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
/*
 * Report oathing
 */
	if (target->true_location != unit->true_location)
		fprintf(current_report, "; beware: will wait until you meet your new role model\n");
	fprintf(current_report, "; oath to [%s]'s faction\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_SEE
 **	Wait for the unit's presence
 **/
int execute_see(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !unit_from_id(0)) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you can see [%s] in the area\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_ID
 **	Wait for the unit's newest ID
 **/
int execute_id(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !unit_from_id(0)) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you have the ID [%s]\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_LEADER
 **	Wait for the unit's leadership
 **/
int execute_leader(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !unit_from_id(0)) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you are led by [%s]\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_LEADING
 **	Wait for the unit's following
 **/
int execute_leading(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !unit_from_id(0)) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you are leading [%s]\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_SIZE
 **	Wait for the unit's presence
 **/
int execute_size(unit_s *unit, order_s *current)
{
int	n;
	n = atoi(string_ptr);
	fprintf(current_report, "; wait until you have %d figures\n", n);
	return 0;
}


/**
 ** EXECUTING_SKILL
 **	Wait for the unit to become skilled enough
 **/
int execute_skill(unit_s *unit, order_s *current)
{
skill_s		*skill;
int		points;
	if (!separate_tag() || (skill = skill_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid skill tag\n");
		return 1;
	}
	separate_token();
	points = atoi(token_keyword);
	separate_token();
	if (strcasecmp(token_keyword, "days") == 0)
		fprintf(current_report, "; wait until you have %d days of experience in %s\n", points, skill->name);
	else
		fprintf(current_report, "; wait until you have level %d in %s\n", points, skill->name);
	return 0;
}


/**
 ** EXECUTING_AT
 **	Wait for the location
 **/
int execute_at(unit_s *unit, order_s *current)
{
	if (!separate_tag() || !location_from_id(0)) {
		fprintf(current_report, ">>> Invalid location ID\n");
		return 1;
	}
	fprintf(current_report, "; wait until you");
	if (--days > 0)
		fprintf(current_report, " have spend %d day%s", days, days > 1 ? "s" : "");
	else
		fprintf(current_report, " are");
	fprintf(current_report, " at [%s]\n", id_token.text);
	return 0;
}


/**
 ** EXECUTING_STAY
 **	Just stay there, if the unit moves
 **/
int execute_stay(unit_s *unit, order_s *current)
{
	if (!unit->leader)
		fprintf(current_report, "; beware: stay is meaningless unless stacked\n");
	fprintf(current_report, "; stay in place in case leader moves\n");
	return 0;
}


/**
 ** EXECUTING_DAY
 **	Wait for the specific day of the month
 **/
int execute_day(unit_s *unit, order_s *current)
{
int	number;
	separate_token();
	number = atoi(token_keyword);
	if (number < 1 || number > 30) {
		fprintf(current_report, ">>> Invalid day number\n");
		return 1;
	}
	days--;
	fprintf(current_report, "; wait until day %d", number);
	if (--days < 1)
		fprintf(current_report, " of the month\n");
	else
		fprintf(current_report, " in %d month%s\n", days, days > 1 ? "s" : "");
	return 0;
}


/**
 ** EXECUTING_MERGE
 **	The unit is attempting to merge into another unit
 **/
int execute_merge(unit_s *unit, order_s *current)
{
unit_s	*recipient;
int	amount;
	separate_token();
	amount = atoi(token_keyword);
	if (amount == 0)
		amount = unit->size;
	if (!separate_tag() || (recipient = potential_unit_id(current_faction)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (recipient->faction != current_faction) {
		fprintf(current_report, ">>> Target must be one of your units\n");
		return 1;
	}
	if (recipient->race && recipient->race != unit->race) {
		fprintf(current_report, ">>> Target must be of the same race\n");
		return 1;
	}
	if (amount > unit->size)
		fprintf(current_report, "; beware: may lack the amount of figures\n");
	if (recipient->true_location && recipient->true_location != unit->true_location)
		fprintf(current_report, "; beware: units must meet first\n");
	fprintf(current_report, "; merged into unit %s of %d %s\n", recipient->id.text, amount, amount > 1 ? unit->race->plural : unit->race->name);
/*
 * Quick'n dirty emulation
 */
	recipient->race = unit->race;
	recipient->size += amount;
	if (amount > unit->size)
		unit->size = 0;
	else
		unit->size -= amount;
	if (unit->size == 0)
		fprintf(current_report, "; beware: leaves a stockpile\n");
	if (recipient->inactive) {
		recipient->inactive = 0;
		recipient->current = unit->current;
		recipient->true_location = unit->true_location;
		recipient->leader = unit;
		recipient->next_location = unit->next_location;
		unit->next_location = recipient;
	}
	return 0;
}


/**
 ** EXECUTING_SPLIT
 **	The unit is attempting to split in differing parts
 **/
int execute_split(unit_s *unit, order_s *current)
{
unit_s	*recipient;
int	amount;
	separate_token();
	amount = atoi(token_keyword);
	if (amount < 1 || amount >= unit->size) {
		fprintf(current_report, ">>> Invalid amount of recruits\n");
		return 1;
	}
	if (!separate_tag() || (recipient = potential_unit_id(current_faction)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (recipient->faction != current_faction || !recipient->inactive) {
		fprintf(current_report, ">>> Target must be one of your new units\n");
		return 1;
	}
	fprintf(current_report, "; created a new unit of %d %s\n", amount, amount > 1 ? unit->race->plural : unit->race->name);
/*
 * Quick'n dirty emulation
 */
	recipient->race = unit->race;
	recipient->size += amount;
	recipient->inactive = 0;
	unit->size -= amount;
	recipient->current = unit->current;
	recipient->true_location = unit->true_location;
	recipient->leader = unit;
	recipient->next_location = unit->next_location;
	unit->next_location = recipient;
	return 0;
}


/**
 ** EXECUTING_PROMOTE
 **	The unit is attempting to promote someone
 **/
int execute_promote(unit_s *unit, order_s *current)
{
unit_s	*recipient;
/*
 * Will unstack or not?
 */
	if (!separate_tag() || (recipient = potential_unit_id(0)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (unit->leader != recipient->leader)
		fprintf(current_report, "; beware: must be at the same stack level\n");
	fprintf(current_report, "; promotes [%s] in front of you\n", recipient->id.text);
	return 0;
}


/**
 ** EXECUTING_FATE
 **	The unit calls upon the GM
 **/
int execute_fate(unit_s *unit, order_s *current)
{
carry_s	*fate;
/*
 * Must either have a fate item, or have fate in cash
 */
	synthetic_tag("fate");
	fate = unit_possessions(unit, item_from_tag(0), 0);
	if ((!fate || !fate->amount ) && !unit->faction->fate_points)
		fprintf(current_report, "; beware: you don't have fate points handy (yet)\n");
	if (fate && fate->amount)
		fate->amount--;
	fprintf(current_report, "; calls upon fate\n");
	return 0;
}


/**
 ** EXECUTING_STACK
 **	The unit is attempting to enter the stack
 **/
int execute_stack(unit_s *unit, order_s *current)
{
unit_s	*recipient;
/*
 * Will unstack or not?
 */
	if (!separate_tag() || (recipient = potential_unit_id(0)) == 0)
		return execute_unstack(unit,current);
	if (recipient->race && recipient->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Unit must be a leader\n");
		return 1;
	}
	if (unit->leader)
		fprintf(current_report, "; beware: will unstack first\n");
	if (recipient->true_location != unit->true_location)
		fprintf(current_report, "; beware: must meet the leader first\n");
	fprintf(current_report, "; stacks under [%s]'s leadership\n", recipient->id.text);
	return 0;
}


/**
 ** EXECUTING_UNSTACK
 **	The unit is attempting to leave the stack
 **/
int execute_unstack(unit_s *unit, order_s *current)
{
	if (!unit->leader)
		fprintf(current_report, "; beware: must stack first\n");
	fprintf(current_report, "; leaves the stack\n");
	unstack_unit(unit);
	return 0;
}


/**
 ** EXECUTING_EJECT
 **	The unit is attempting to leave the stack
 **/
int execute_eject(unit_s *unit, order_s *current)
{
unit_s	*recipient;
/*
 * Will unstack or not?
 */
	if (!separate_tag() || (recipient = potential_unit_id(0)) == 0) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if (recipient->leader != unit)
		fprintf(current_report, "; beware: %s must be stacked first\n", recipient->id.text);
	else
		unstack_unit(recipient);
	fprintf(current_report, "; ejects %s from the stack\n", recipient->id.text);
	return 0;
}


/**
 ** EXECUTING_LEAVE
 **	The unit is attempting to get out of the location
 **/
int execute_leave(unit_s *unit, order_s *current)
{
	if (!unit->current || unit->current->type->type != TERRAIN_STRUCTURE)
		fprintf(current_report, "; beware: leave only structures; did you ENTER first?\n");
	fprintf(current_report, "; leaves structure\n");
	return 0;
}


/**
 ** EXECUTING_ENTER
 **	The unit is attempting to move into a location.
 **/
int execute_enter(unit_s *unit, order_s *current)
{
location_s	*location;
	if (!separate_tag() || (location = location_from_id(0)) == 0) {
		fprintf(current_report, ">>> Invalid location id\n");
		return 1;
	}
	if (location->type->type != TERRAIN_STRUCTURE)
		fprintf(current_report, ">>> Enter only in structures\n");
	else
		fprintf(current_report, "; enters [%s]\n", id_token.text);
	return 0;
}


/**
 ** EXECUTE_FORGET
 **	Unit wants to forget a skill.
 **/
int execute_forget(unit_s *unit, order_s *current)
{
experience_s	*exp;
skill_s		*skill;

	if (!separate_tag() || (skill = skill_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Invalid skill tag\n");
		return 1;
	}
	for (exp = unit->skilled; exp; exp = exp->next)
		if (exp->skill == skill)
			break;
	if (!exp || exp->points == 0)
		fprintf(current_report, "; beware: you might not have that skill, are you sure you've gained it?\n");
	fprintf(current_report, "; forget all about skill %s\n", skill->name);
	if (exp)
		exp->points = 0;
	return 0;
}


/**
 ** EXECUTE_DESCRIBE
 **	Unit changes its description
 **/
int execute_describe(unit_s *unit, order_s *current)
{
	separate_token();
	if (!token_keyword[0])
		fprintf(current_report, "; no more description\n");
	else
		fprintf(current_report, "; unit now describes itself as `%s'\n", token_keyword);
	return 0;
}


/**
 ** EXECUTE_NAME
 **	Unit changes its name
 **/
int execute_name(unit_s *unit, order_s *current)
{
	separate_token();
	if (!token_keyword[0]) {
		fprintf(current_report, ">>> Missing name\n");
		return 1;
	}
	fprintf(current_report, "; unit is now called `%s'\n", token_keyword);
	return 0;
}


/**
 ** EXECUTE_YIELD
 **	Unit wants to yield a title.
 **/
int execute_yield(unit_s *unit, order_s *current)
{
	if (unit->race && unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Only leaders hold titles\n");
		return 1;
	}
	if (!unit->title)
		fprintf(current_report, "; beware: no title yet, are you sure you'll get one?\n");
	fprintf(current_report, "; yield the current title\n");
	unit->title = 0;
	return 0;
}


/**
 ** EXECUTE_CLAIM
 **	Unit wants to claim a title. A challenge is thrown.
 **/
int execute_claim(unit_s *unit, order_s *current)
{
title_s		*title;
location_s	*location;

	if (unit->race && unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Only leaders hold titles\n");
		return 1;
	}
	if (!separate_tag() || (title = title_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Illegal title tag\n");
		return 1;
	}
	if (!separate_tag() || (location = location_from_id(0)) == 0) {
		fprintf(current_report, ">>> No such location\n");
		return 1;
	}
	if (unit->title)
		fprintf(current_report, "; beware: you'll yield your current title\n");
	if (location->title != title)
		fprintf(current_report, "; beware: no title here\n");
	else
		if (unit->current->holder) {
			separate_token();
			if (!token_keyword[0])
				fprintf(current_report, "; beware: you are challenging the holder\n");
		}
	if (location != unit->current)
		fprintf(current_report, "; beware: not at location, did you remember to MOVE there?\n");
	fprintf(current_report, "; claim the title of %s\n", title->name);
	if (unit->title)
		unit->title->holder = 0; 
	unit->title = location;
	location->holder = unit;
	return 0;
}


/**
 ** EXECUTE_BESTOW
 **	Unit wants to give up its title.
 **/
int execute_bestow(unit_s *unit, order_s *current)
{
title_s		*title;
location_s	*location;
unit_s		*successor;

	if (unit->race && unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Only leaders hold titles\n");
		return 1;
	}
	if (!separate_tag() || (successor = unit_from_id(0)) == 0) {
		fprintf(current_report, ">>> Illegal unit tag\n");
		return 1;
	}
	if (!(location = unit->title))
		fprintf(current_report, "; beware: you are not holding a title!\n");
	else {
		if (successor->title) {
			fprintf(current_report, "; beware: the recipient is already holding a title\n");
			successor->title->holder = 0;
		}
		fprintf(current_report, "; confer the title of %s to [%s]\n",
				location->title->name, successor->id.text);
		location->holder = successor;
		successor->title = location;
		unit->title = 0;
	}
	return 0;
}


/**
 ** EXECUTE_PATROL
 **	Unit wants to move into patrol position
 **/
int execute_patrol(unit_s *unit, order_s *current)
{
	if (days > 0)
		fprintf(current_report, "; patrol the area for %d days\n", days);
	else
		fprintf(current_report, "; patrol until recalled\n");
	return 0;
}

/**
 ** EXECUTING_MOVE
 **	The unit is attempting to move.
 **/
int execute_move(unit_s *unit, order_s *current)
{
location_s	*toward;
direction_s	*dir;
char		*old;

	old = string_ptr;
	dir = 0;
	if (!separate_tag() || (toward = location_from_id(0)) == 0) {
		string_ptr = old;
		separate_token();
		if (!unit->true_location) {
			fprintf(current_report, ">>> Unit not located anywhere\n");
			return 1;
		}
		if (strcasecmp(token_keyword, "OUT") == 0)
			toward = unit->current->outer;
		else {
			for (dir = unit->true_location->exits; dir; dir = dir->next)
				if (strcasecmp(dir->name, token_keyword) == 0)
					break;
			if (!dir)
				for (dir = unit->true_location->exits; dir; dir = dir->next)
					if (abbreviated_keyword(dir->name, token_keyword))
						break;
			if (dir)
				toward = dir->toward;
			else
				toward =0;
		}
		if (!toward)
			fprintf(current_report, "; beware: direction doesn't seem to exist here\n");
	}
	if (dir) {
		if (dir->mode)
			fprintf(current_report, "; beware: movement requires travel mode\n");
		if (dir->days < 0 || dir->skill)
			fprintf(current_report, "; beware: direction seems impassable\n");
	}
	if (unit->race && unit->race->type == RACE_FOLLOWER)
		fprintf(current_report, "; beware: follower must be scouting\n");
	if (toward)
		fprintf(current_report, "; move to [%s]\n", toward->id.text);
	else
		fprintf(current_report, "; move toward %s\n", token_keyword);
	return 0;
}


/**
 ** EXECUTE_CARAVAN
 **/
int execute_caravan(unit_s *unit, order_s *current)
{
int		n;
int		here;
location_s	*toward;
/*
 * Search
 */
	n = 0;
	here = 0;
	while (separate_tag()) {
		if ((toward = location_from_id(0)) == 0) {
			if (n)
				putc('\n', current_report);
			fprintf(current_report, ">>> invalid location ID\n");
			return 1;
		}
		if (n == 0)
			fprintf(current_report, "; caravan from");
		else
			fprintf(current_report, ", to");
		fprintf(current_report, " [%s]", toward->id.text);
		n++;
		if (unit->true_location == toward)
			here = n;
	}
	putc('\n', current_report);
	if (n < 2) {
		fprintf(current_report, ">>> CARAVAN require at least two locations\n");
		return 1;
	}
	if (!here)
		fprintf(current_report, "; beware: currently not in caravan trail\n");
	return 0;
}


/**
 ** EXECUTING_STUDY
 **	The unit is attempting to study a skill. Allow that to proceed
 **/
int execute_study(unit_s *unit, order_s *current)
{
skill_s		*skill;
skill_s		*required;
experience_s	*exp;
experience_s	*bonus;
unit_s		*leader;
long		earns;
int		level, max;

	if (unit->race && unit->race->type >= RACE_CREATURE) {
		fprintf(current_report, ">>> Creatures cannot study\n");
		return 1;
	}
	if (!separate_tag() || (skill = skill_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Illegal skill tag or unknown skill\n");
		return 1;
	}
	if (skill->student && unit->race && unit->race->type != skill->student) {
		fprintf(current_report, ">>> Unit type cannot study that skill\n");
		return 1;
	}
	if (skill->required_skill) {
		exp = unit_experiences(unit, skill->required_skill, 0);
		if (!exp || exp->level < skill->required_at_level)
			fprintf(current_report, "; beware: unit may lack the required skill level\n");
	}
	exp = unit_experiences(unit, skill, 1);
	separate_token();
	max = atoi(token_keyword);
	if (max <= 0)
		max = 99;
	if (days < 0 && max == 99) {
		fprintf(current_report, "; study %s until max level\n", skill->name);
		earns = 30 * SKILL_POINTS_PER_DAY;
	} else
		if (days > 1 || max == 99) {
			fprintf(current_report, "; study %s for %d days\n", skill->name, days);
			earns = days * SKILL_POINTS_PER_DAY;
		} else {
			level = max;
			earns = 0;
			for (required = skill; max-- && required; required = required->next_level)
				earns = required->for_level;
			if (unit->size)
				earns -= exp->points / unit->size;
			if (earns <= 0) {
				fprintf(current_report, "; betware: you seem to have reached the maximum level already\n");
				fprintf(current_report, "; study %s\n", skill->name);
			} else {
/*
 * Effects of location
 */
				if (unit->current) {
					for (bonus = unit->current->skills; bonus; bonus = bonus->next)
						if (bonus->skill == skill)
							break;
				} else
					bonus = 0;
				if (bonus && bonus->level <= max) {
					earns *= 4;
					earns += 4;
					earns /= 5;
				}
/*
 * Effects of leadership
 */
				for (leader = unit->leader; leader; leader = leader->leader) {
					for (bonus = leader->skilled; bonus; bonus = bonus->next)
						if (bonus->skill == skill)
							break;
					if (bonus && bonus->level > exp->level)
						break;
				}
				if (leader) {
					earns *= 9;
					earns += 9;
					earns /= 10;
				}
/*
 * Magic skill?
 */
				if (!magecraft) {
					string_ptr = "mage";
					separate_tag();
					magecraft = skill_from_tag(0);
				}
				if (skill->type == 2 || skill->required_skill == magecraft) {
					for (required = skill; required; required = required->required_skill)
						if (required->required_skill == magecraft)
							break;
					if (required)
						switch (game_turn_number % 12) {
						    case 0:
						    case 1:
						    case 2:
							if (strcmp(required->tag.text, "eart"))
								required = 0;
							break;
						    case 3:
						    case 4:
						    case 5:
							if (strcmp(required->tag.text, "fire"))
								required = 0;
							break;
						    case 6:
						    case 7:
						    case 8:
							if (strcmp(required->tag.text, "wate"))
								required = 0;
							break;
						    case 9:
						    case 10:
						    case 11:
							if (strcmp(required->tag.text, "airs"))
								required = 0;
							break;
						}
					if (required) {
						earns *= 9;
						earns += 9;
						earns /= 10;
					}
				}
				earns += SKILL_POINTS_PER_DAY-1;
				earns /= SKILL_POINTS_PER_DAY;
				fprintf(current_report, "; study %s about %ld day", skill->name, earns);
				if (earns > 1)
					putc('s', current_report);
				fprintf(current_report, " until level %d\n", level - ++max);
				earns *= SKILL_POINTS_PER_DAY;
			}
		}
	exp->points += earns * unit->size;
	adjust_experience(exp, unit->size);
	return 0;
}


/**
 ** EXECUTE_TEACH
 **	Unit teaches another, if that other studies
 **/
int execute_teach(unit_s *unit, order_s *current)
{
experience_s	*level, *target;
location_s	*guild;
unit_s		*student;
skill_s		*skill;
int		i;
static int	factor[7] = { 100, 60, 40, 30, 25, 20, 0 };
	if (unit->race && unit->race->type != RACE_LEADER) {
		fprintf(current_report, ">>> Only leaders may teach\n");
		return 1;
	}
	if (!separate_tag()) {
		fprintf(current_report, ">>> Invalid unit ID\n");
		return 1;
	}
	if ((student = potential_unit_id(0)) == 0) {
		if ((guild = location_from_id(0)) == 0) {
			fprintf(current_report, ">>> Invalid unit ID\n");
			return 1;
		}
		if (guild->type->special_effect < FX_ABSORB_SKILL_0 || guild->type->special_effect > FX_ABSORB_SKILL_3) {
			fprintf(current_report, ">>> Invalid guild ID\n");
			return 1;
		}
	} else
		guild = 0;
	if (!separate_tag() || (skill = skill_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Illegal skill tag or unknown skill\n");
		return 1;
	}
	if (!student && guild && guild->type->special_effect - FX_ABSORB_SKILL_0 != skill->type) {
		fprintf(current_report, ">>> Skill incompatible with guild type\n");
		return 1;
	}
	if ((level = unit_experiences(unit, skill, 0)) == 0 || level->level < 1)
		fprintf(current_report, "; beware: teacher doesn't seem to have this skill\n");
	if (guild && unit->title != guild && unit->current != guild)
		fprintf(current_report, "; beware: teacher must be owner or head of guild\n");
	if (student) {
		target = unit_experiences(student, skill, 1);
		if (level && level->level <= target->level)
			fprintf(current_report, "; beware: teacher may have lower level than student\n");
		fprintf(current_report, "; teaches [%s] skill %s", student->id.text, skill->name);
	} else {
		target = location_experiences(guild, skill, 1);
		if (level && level->level <= target->level)
			fprintf(current_report, "; beware: teacher may have lower level than guild\n");
		fprintf(current_report, "; imbues [%s] skill %s", guild->id.text, skill->name);
	}
	if (days < 0) {
		fprintf(current_report, " until");
		if (level && level->level)
			fprintf(current_report, " teacher's level %d\n", level->level);
		else
			fprintf(current_report, " max level\n");
	} else
		fprintf(current_report, " for %d day%s\n", days, days > 1 ? "s" : "");
	if (student) {
		for (i = 0; i < 5; i++) {
			if (!separate_tag())
				break;
			if ((student = potential_unit_id(0)) == 0) {
				fprintf(current_report, ">>> Invalid secondary unit ID\n");
				return 1;
			}
			if (student->race && student->race->type != 1) {
				fprintf(current_report, ">>> Multiple students must be leaders\n");
				return 1;
			}
			fprintf(current_report, "; other student [%s]\n", student->id.text);
		}
		if (i > 0)
			fprintf(current_report, "; beware: teaching will bring +%d%% skill\n", factor[i]);
	}
	return 0;
}


/**
 ** EXECUTE_USE
 **	Using skills is the most complicated thing there is
 **/
int execute_use(unit_s *unit, order_s *current)
{
experience_s	*level;
skill_s		*skill;
int		amount;
	if (!separate_tag() || (skill = skill_from_tag(0)) == 0) {
		fprintf(current_report, ">>> Illegal skill tag or unknown skill\n");
		return 1;
	}
	if (!skill->end_product) {
		fprintf(current_report, ">>> Skill does not produce anything\n");
		return 1;
	}
	if ((level = unit_experiences(unit, skill, 0)) == 0 || !level->effective)
		fprintf(current_report, "; beware: did you study the skill first?\n");
	fprintf(current_report, "; use %s", skill->name);
	if (days > 0) {
		fprintf(current_report, " for %d day", days);
		if (days > 1)
			putc('s', current_report);
	}
	separate_token();
	if ((amount = atoi(token_keyword)) > 0)
		fprintf(current_report, " until %d results produced\n", amount);
	else
		putc('\n', current_report);
	return 0;
}


/**
 ** EXECUTE_WORK
 **	This is the default order. It might be called with an order pointer
 **/
int execute_work(unit_s *unit, order_s *current)
{
	if (days < 0)
		fprintf(current_report, "; work until end of turn\n");
	else
		fprintf(current_report, "; work for %d day%s\n", days, days > 1 ? "s" : "");
	return 0;
}
