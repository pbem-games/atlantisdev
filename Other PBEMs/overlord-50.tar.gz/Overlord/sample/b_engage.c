/* $Id: b_engage.c,v 1.6 1999/11/21 15:46:11 archer Exp $
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "parser.h"


/**
 ** Locally set variables
 **/
static figure_s	*recycle_units;
static skill_s	*tact_cache,
		*stra_cache,
		*fana_cache,
		*ambu_cache;
item_s		*tired_cache,
		*wariness_cache;
figure_s	*acting_units;
side_s		attackers, defenders;
square_s	battlefield[6][3];


/**
 ** ALLOCATE_NEW_FIGURE
 **	Pull from previous battle recycle, or allocate new
 **/
static figure_s *allocate_new_figure(void)
{
figure_s	*newest;
/*
 * Anything in cache?
 */
	if ((newest = recycle_units) != 0) {
		recycle_units = newest->same_side;
		memset(newest, 0, sizeof(*newest));
	} else
		newest = mallocator(figure_s);
	return newest;
}


/**
 ** FREE_ALL_SOLDIERS
 **	The battle is over
 **/
void free_all_soldiers(void)
{
figure_s	*unit;
/*
 * Free all
 */
	while ((unit = attackers.units) != 0) {
		attackers.units = unit->same_side;
		unit->same_side = recycle_units;
		recycle_units = unit;
	}
	while ((unit = defenders.units) != 0) {
		defenders.units = unit->same_side;
		unit->same_side = recycle_units;
		recycle_units = unit;
	}
}


/**
 ** REPORT_SIDE
 **	Report one side's forces
 **/
static void report_side(FILE *report, side_s *side, char *name)
{
figure_s	*forces;
unit_s		*unit;
char		*sep;
carry_s		*equipment;
/*
 * Which side?
 */
	fprintf(report, "%s:\n", name);
	for (forces = side->units; forces; forces = forces->same_side) {
		unit = forces->unit;
		start_fold_string(unit->name);
		add_fold_tag(&unit->id);
		add_fold_string(", ");
		add_fold_integer(unit->size);
		add_fold_char(' ');
		if (unit->size > 1)
			add_fold_string(unit->race->plural);
		else
			add_fold_string(unit->race->name);
		add_fold_string(comma);
		add_fold_string(visual_enum(forces->rank, battlefield_ranks));
		add_fold_char(' ');
		add_fold_string(visual_enum(forces->file, battlefield_files));
		if (forces->flying)
			add_fold_string(", flying");
		if (report == full_report) {
			sep = ", equipment: ";
			for (equipment = forces->using; equipment; equipment = equipment->next)
				if (equipment->item->item_type == ITEM_ITEM) {
					if (equipment->equipped) {
						add_fold_string(sep);
						add_fold_item_amount(equipment->equipped, equipment->item);
						sep = comma;
					}
				} else {
					add_fold_string(sep);
					if (strncmp(equipment->item->name, "day of ", 7) == 0)
						add_fold_string(equipment->item->name + 7);
					else
						add_fold_string(equipment->item->name);
					sep = comma;
				}
/*
 * Full report also includes unit stats
 */
			report_stats(&forces->vital, 0);
			if (forces->fanatic)
				add_fold_string(", fanatic");
		}
		add_fold_char('.');
		print_folded(report, 8);
	}
/*
 * Report, tactics, strategy ambush!
 */
	if (side->tactician)
		fprintf(report, "    Tactician advantage of %d!!!\n", side->tactician);
	if (side->strategist)
		fprintf(report, "    Strategist advantage of %d!!!\n", side->strategist);
	if (side->ambush)
		fprintf(report, "    Ambushing (%d squares shuffle)!!!\n", side->ambush);
	putc('\n', report);
}


/**
 ** REPORT_ENGAGMENT
 **/
static void report_engagment(FILE *report)
{
	report_side(report, &attackers, "Attacking");
	report_side(report, &defenders, "Defending");
}


/**
 ** RECURSIVE_ATTACKERS
 **	All units with 'fight' setting in the stack are attackers
 **/
static void recursive_attackers(unit_s *stack)
{
	if (stack->participate == 2)
		stack->is_attacking = 1;
	for (stack = stack->stack; stack; stack = stack->next_location)
		recursive_attackers(stack);
}


/**
 ** RECURSIVE_DEFENDERS
 **	All units with 'defend' or higher setting in the stack are defenders
 **/
static void recursive_defenders(unit_s *stack)
{
	if (stack->participate > 0)
		stack->is_defending = 1;
	for (stack = stack->stack; stack; stack = stack->next_location)
		recursive_defenders(stack);
}


/**
 ** SIDE_FACTORS
 **	Determine tactician, strategist, ambush
 **/
static void side_factors(side_s *side)
{
figure_s	*figure;
unit_s		*unit;
experience_s	*skill;
skill_s		*ambush;
int		level;
/*
 * Loop on all units
 */
	for (figure = side->units; figure; figure = figure->same_side) {
		unit = figure->unit;
		side->stealth += unit->size * unit->vital.stealth;
		side->observe += unit->size * unit->vital.observation;
/*
 * Figure out skills
 */
		if ((skill = unit_experiences(unit, tact_cache, 0)) != 0 &&
		    skill->level > side->tactician)
			side->tactician = skill->level;
		if ((skill = unit_experiences(unit, stra_cache, 0)) != 0 &&
		    skill->level > side->strategist)
			side->strategist = skill->level;
		if ((skill = unit_experiences(unit, ambu_cache, 0)) != 0)
			side->ambush += skill->points;
#ifdef USES_FATE_POINTS
/*
 * Check for fate possibility
 */
		if (unit->faction->fate_points)
			side->fate = 1;
#endif
	}
/*
 * Now, get the averages
 */
	side->stealth /= side->size;
	side->observe /= side->size;
	side->ambush  /= side->size;
	level = 0;
	for (ambush = ambu_cache; ambush; ambush = ambush->next_level)
		if (side->ambush < ambush->for_level)
			break;
		else
			level++;
	side->ambush = level;
}


/**
 ** AMBUSH_SHUFFLE
 **	When ambushed, files and ranks may suffer
 **/
static void ambush_shuffle(side_s *side, int ambush_surprise)
{
figure_s	*forces;
/*
 * Avoid
 */
	if (ambush_surprise <= 0)
		return;
/*
 * Go!
 */
	for (forces = side->units; forces; forces = forces->same_side) {
/*
 * Shuffle 1 file for ambush 1 & 2, 2 files for higher
 */
		if (ambush_surprise > 2 || forces->file == 1)
			forces->file = roll_1Dx(3);
		else
			if (roll_1Dx(2) == 0)
				forces->file = 1;
/*
 * Shuffle 1 rank for ambush 2 & 3, 2 ranks for higher
 */
		switch(ambush_surprise) {
		    case 2:
		    case 3:
			if (forces->rank != 1) {
				if (roll_1Dx(2) == 0)
					forces->rank = 1;
				break;
			}
		    default:
			forces->rank = roll_1Dx(3);
		    case 0:
		    case 1:
			break;
		}
	}
}


/**
 ** BATTLE_ENGAGEMENT
 **	The forces engage each other.
 **/
void battle_engagement(unit_s *attacker, unit_s *target, int duel)
{
unit_s		*unit;
unit_s		*allied;
figure_s	*figure;
square_s	*square;
experience_s	*skill;
carry_s		*equipment, *using;
combat_s	*doing;
faction_s	*faction;
int		i;
/*
 * Skill cache
 */
	if (!tact_cache) {
		synthetic_tag("tact");
		tact_cache = skill_from_tag(0);
		synthetic_tag("stra");
		stra_cache = skill_from_tag(0);
		synthetic_tag("ambu");
		ambu_cache = skill_from_tag(0);
		synthetic_tag("fana");
		fana_cache = skill_from_tag(0);
		synthetic_tag("efftird");
		tired_cache = item_from_tag(0);
		synthetic_tag("effwary");
		wariness_cache = item_from_tag(0);
	}
/*
 * Prepare
 */
	memset(battlefield, 0, sizeof(battlefield));
	memset(&attackers, 0, sizeof(attackers));
	memset(&defenders, 0, sizeof(defenders));
	attackers.opposing = &defenders;
	defenders.opposing = &attackers;
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
		unit->is_attacking = 0;
		unit->is_defending = 0;
	}
/*
 * Pull in all units that are: guarding, allies of guards or involved units
 */
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
		if (unit->participate == 2 && attitude_vs(unit->faction, attacker) == ATTITUDE_IS_ALLY)
			unit->is_attacking = 1;
		if (unit->participate >= 1 && attitude_vs(unit->faction, target) == ATTITUDE_IS_ALLY)
			unit->is_defending = 1;
	}
/*
 * Guards? Allies of guards?
 */
	if (battle_location->guarded) {
		for (unit = battle_location->interacting; unit; unit = unit->next_visible)
			if (unit->is_guarding &&
			    attitude_vs(unit->faction, target) <= ATTITUDE_IS_NEUTRAL &&
			    !unit->is_attacking) {
				unit->is_defending = 1;
				for (allied = battle_location->interacting; allied;
								allied = allied->next_visible)
					if (allied->participate >= 1 &&
					    attitude_vs(allied->faction, unit) == ATTITUDE_IS_ALLY)
						allied->is_defending = 1;
			}
	}
/*
 * Pull in sub-stack of attacker
 */
	recursive_attackers(attacker);
/*
 * Pull in full stack of defender
 */
	unit = target;
	while (unit->leader)
		unit = unit->leader;
	recursive_defenders(unit);
/*
 * Duel(aka assassination)
 */
	if (duel) {
		for (unit = battle_location->interacting; unit; unit = unit->next_visible)
			if (unit->vital.observation < attacker->vital.stealth)
				unit->is_defending = unit->is_attacking = 0;
	}
/*
 * Involve attacker & defender last; they *ALWAYS* are involved! Also,
 * attacking faction is never defending, and defending faction never attacks.
 */
	attacker->is_attacking = 1;
	attacker->is_defending = 0;
	target->is_defending = 1;
	target->is_attacking = 0;
	attackers.overall_strength = 0;
	defenders.overall_strength = 0;
/*
 * A last sweep to insure that a faction has no units on both sides of the battlefield
 */
	for (faction = faction_list; faction; faction = faction->next) {
		faction->attacking = 0;
		faction->defending = 0;
	}
	for (unit = battle_location->interacting; unit; unit = unit->next_visible)
		if (unit->is_attacking != unit->is_defending)
			if (unit->is_attacking)
				unit->faction->attacking = 1;
			else
				unit->faction->defending = 1;
	attacker->faction->defending = 0;
	target->faction->attacking = 0;
/*
 * Finally: Seed the battlefield. The attacking/defending faction will not join
 * the opposite side, ever.
 */
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
		faction = unit->faction;
		if (faction == attacker->faction)
			unit->is_defending = 0;
		if (faction == target->faction)
			unit->is_attacking = 0;
		if (unit->is_attacking == unit->is_defending)
			continue;
		if (unit->is_attacking && faction->defending)
			continue;
		if (unit->is_defending && faction->attacking)
			continue;
		if (unit->size == 0)
			continue;
		unit->full_day = 1;
		figure = allocate_new_figure();
		figure->unit = unit;
		figure->race = unit->race;
		if (unit->is_attacking) {
			figure->side = &attackers;
			figure->offense = 1;
		} else
			figure->side = &defenders;
		figure->same_side = figure->side->units;
		figure->side->units = figure;
		figure->side->size += unit->size;
		figure->rank = unit->rank;
		figure->file = unit->file;
		figure->movement = unit->movement;
		figure->living = unit->size;
		if (!unit->name || strcasecmp(unit->name, "unit") == 0)
			figure->simplename = 1;
		skill = unit_experiences(unit, fana_cache, 0);
		if (skill && skill->effective)
			figure->fanatic = 1;
		compute_stack_capacity(unit);
		figure->bonus = unit->current->type->local_conditions;
#ifdef BATTLE_INITIATIVE
		if (unit->is_guarding || unit->is_patrolling)
			figure->bonus.initiative++;
#endif
		if (unit->capacity[2] >= unit->weight)
			figure->flying = 1;
		else
			figure->flying = 0;
/*
 * Complete actions with the defaults
 */
		memcpy(figure->actions, unit->combat, sizeof(unit->combat));
		for (i = 0; i < MAX_COMBAT_SETTING-1; i++)
			if (figure->actions[i].option == COMBAT_SET_NONE)
				break;
		figure->actions[i++].option = COMBAT_SET_MELEE;
		figure->actions[i++].option = COMBAT_SET_PARRY;
		figure->actions[i].option = COMBAT_SET_NONE;
/*
 * Copy any equipment (equipment may be modified during combat)
 */
		for (equipment = unit->carrying; equipment; equipment = equipment->next)
			if (equipment->equipped || (equipment->amount && equipment->item->item_type == ITEM_DAYS)) {
				using = new_carry_instance();
				*using = *equipment;
				using->amount = using->equipped;
				using->next = figure->using;
				figure->using = using;
#ifdef FX_SHIELDBREAKER
				if (equipment->item->special_effects == FX_SHIELDBREAKER)
					figure->shield_breaker = 1;
#endif
#ifdef FX_COINSPINNER
				if (equipment->item->special_effects == FX_SHIELDBREAKER)
					figure->side->fate = 1;
#endif
			}
		figure->active = figure->living;
		compute_battle_stats(figure, 1);
/*
 * Figure out relative strength
 */
		i = figure->vital.melee * figure->vital.hits * figure->vital.damage;
		switch (figure->actions[0].option) {
		    default:
			doing = 0;
			break;
		    case COMBAT_SET_ITEM:
			doing = &figure->actions[0].u.use_item->combat_action;
			break;
		    case COMBAT_SET_SKILL:
			doing = &figure->actions[0].u.use_skill->combat_action;
			break;
		}
		if (doing) {
			if (doing->action.hits)
				i = doing->action.hits;
			else
				i = doing->bonus.hits + figure->vital.melee;
			if (doing->action.damage)
				i *= doing->action.damage;
			else
				i *= doing->bonus.damage + figure->vital.damage;
			switch (doing->effect) {
			    case COMBAT_EFFECT_MELEE:
				if (doing->action.melee)
					i *= doing->action.melee;
				else
					i *= doing->bonus.melee + figure->vital.melee;
				break;
			    case COMBAT_EFFECT_RANGED:
				if (doing->action.missile)
					i *= doing->action.missile;
				else
					i *= doing->bonus.missile + figure->vital.missile;
				i += i / 2;	/* ranged attacks are assumed to be 50% more efficient */
				break;
			    case COMBAT_EFFECT_SPECIAL:
				i = 0;
			}
		}
		figure->side->overall_strength += i;
	}
/*
 * Evaluate ambush, tactics and strategy
 */
	side_factors(&attackers);
	side_factors(&defenders);
/*
 * Duel (aka assassination)
 */
	attackers.ambush += attackers.stealth;
	defenders.ambush += defenders.stealth;
	if (duel) {
		attackers.ambush = 4;
		defenders.ambush = 0;
		attackers.tactician++;
	}
/*
 * Tactics difference
 */
	if (attackers.tactician > defenders.tactician) {
		attackers.tactician -= defenders.tactician;
		attackers.tactician *= 2;
		defenders.tactician  = 0;
	} else {
		defenders.tactician -= attackers.tactician;
		attackers.tactician  = 0;
		defenders.tactician *= 2;
	}
/*
 * Who ambushes the other?
 */
	i = defenders.ambush + defenders.observe;
	if (attackers.ambush >= i) {
		attackers.ambush -= i;
		defenders.ambush  = 0;
		ambush_shuffle(&defenders, attackers.ambush);
	} else {
		attackers.ambush /= 2;
		defenders.ambush /= 2;
		i = attackers.ambush + attackers.observe;
		if (defenders.ambush > i)
			defenders.ambush -= i;
		else
			defenders.ambush = 0;
		attackers.ambush  = 0;
		ambush_shuffle(&attackers, defenders.ambush);
	}
#ifdef USES_FATE_POINTS
/*
 * Fate doesn't intervene if less than 30 figures are involved in
 * battle.
 */
	if (attackers.size < 30 || defenders.size < 30) {
		attackers.fate = 0;
		defenders.fate = 0;
	}
/*
 * Consume fate?
 */
	if (attackers.fate || defenders.fate) {
		if (attackers.fate > defenders.fate) {
			attackers.fate -= defenders.fate;
			defenders.fate = 0;
		} else {
			defenders.fate -= attackers.fate;
			attackers.fate = 0;
		}
		if (attackers.overall_strength > defenders.overall_strength) {
			attackers.fate = 0;
			printf("fate isn't necessary in battle for attackers\n");
		}
		if (defenders.overall_strength > attackers.overall_strength) {
			defenders.fate = 0;
			printf("fate isn't necessary in battle for defenders\n");
		}
		if (attackers.fate)
			printf("attacks have fate with them! (%d str vs %d)\n", attackers.overall_strength, defenders.overall_strength);
		else
			if (defenders.fate)
				printf("defenders have fate with them (%d str vs %d)!\n", defenders.overall_strength, attackers.overall_strength);
	}
#endif
/*
 * Report involved figures
 */
	report_engagment(full_report);
	report_engagment(long_report);
	report_engagment(terse_report);
/*
 * Place on battlefield
 */
	for (figure = attackers.units; figure; figure = figure->same_side) {
		square = &battlefield[figure->rank][figure->file];
		figure->same_square = square->attackers;
		square->attackers = figure;
	}
	for (figure = defenders.units; figure; figure = figure->same_side) {
		figure->rank = 5 - figure->rank;
		figure->file = 2 - figure->file;
		square = &battlefield[figure->rank][figure->file];
		figure->same_square = square->defenders;
		square->defenders = figure;
	}
/*
 * Finally, how many units may be routed?
 */
#if defined(END_OF_WORLD) && END_OF_WORLD == 4
	attackers.rout = attackers.size * 2;
	defenders.rout = defenders.size * 2;
#else
	attackers.rout = attackers.size / 2;
	defenders.rout = defenders.size / 2;
#endif
}


#ifdef FX_FIREWALL
/**
 ** BATTLE_GENERATE_FIREWALL
 **	Firewall is created, and is special
 **/
void battle_generate_firewall(figure_s *unit, char *name, race_s *firewall)
{
figure_s	*figure;
/*
 * Add a new unit at the battle... A special move is used...
 */
	figure = allocate_new_figure();
	figure->unit = virtual_unit(firewall, 1);
	figure->race = firewall;
	figure->unit->name = strdup("fire wall");
	figure->side = unit->side;
	figure->offense = unit->offense;
	figure->same_side = figure->side->units;
	figure->side->units = figure;
	figure->side->size++;
	figure->rank = unit->rank;
	figure->file = unit->file;
	figure->movement = BATTLEFIELD_MOVE_FIREWALL;
	figure->living = 1;
	figure->fanatic = 1;
	figure->simplename = 1;
	figure->actions[0].option = COMBAT_SET_SKILL;
	figure->actions[0].u.use_skill = firewall->skilled->skill;
	figure->actions[1].option = COMBAT_SET_MELEE;
	figure->actions[2].option = COMBAT_SET_NONE;
	figure->permanent_effects = FX_BIT_WALKTHRU;
/*
 * Firewall is at the same location
 */
	figure->same_square = unit->same_square;
	unit->same_square = figure;
/*
 * Report
 */
	start_fold_unit_segment(unit);
	add_fold_string("spawns a ");
	add_fold_string(firewall->name);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_SWIRLINGVORTEX
/**
 ** BATTLE_GENERATE_VORTEX
 **	Swirling vortex is created, and is special
 **/
void battle_generate_vortex(figure_s *unit, char *name, race_s *vortex)
{
figure_s	*figure;
/*
 * Add a new unit at the battle... A special move is used...
 */
	figure = allocate_new_figure();
	figure->unit = virtual_unit(vortex, 1);
	figure->race = vortex;
	figure->unit->name = strdup("swirling vortex");
	figure->side = unit->side;
	figure->offense = unit->offense;
	figure->same_side = figure->side->units;
	figure->side->units = figure;
	figure->side->size++;
	figure->rank = unit->rank;
	figure->file = unit->file;
	figure->movement = BATTLEFIELD_MOVE_RANDOM;
	figure->living = 1;
	figure->fanatic = 1;
	figure->simplename = 1;
	figure->actions[0].option = COMBAT_SET_SKILL;
	figure->actions[0].u.use_skill = vortex->skilled->skill;
	figure->actions[1].option = COMBAT_SET_MELEE;
	figure->actions[2].option = COMBAT_SET_NONE;
/*
 * Firewall is at the same location
 */
	figure->same_square = unit->same_square;
	unit->same_square = figure;
/*
 * Report
 */
	start_fold_unit_segment(unit);
	add_fold_string("spawns a ");
	add_fold_string(vortex->name);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_CALL_HELP
/**
 ** BATTLE_GENERATE_BEASTS
 **	Protecting beast is created, and is special
 **/
void battle_generate_beasts(figure_s *unit, char *name, race_s *beasts)
{
figure_s	*figure;
int		size, val;
/*
 * Add a new unit at the battle... A special move is used...
 */
	figure = allocate_new_figure();
	size = roll_1Dx(6);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
	val = roll_1Dx(6);
	if (val > size)
		size = val;
#endif
	size += 5;
	figure->unit = virtual_unit(beasts, size);
	figure->race = beasts;
	figure->unit->name = strdup("protecting beast");
	figure->side = unit->side;
	figure->offense = unit->offense;
	figure->same_side = figure->side->units;
	figure->side->units = figure;
	figure->side->size += size;
	figure->rank = unit->rank;
	figure->file = unit->file;
	figure->movement = BATTLEFIELD_MOVE_FIRE;
	figure->living = size;
	figure->fanatic = 1;
	figure->simplename = 1;
	figure->actions[0].option = COMBAT_SET_SKILL;
	figure->actions[0].u.use_skill = beasts->skilled->skill;
	figure->actions[1].option = COMBAT_SET_MELEE;
	figure->actions[2].option = COMBAT_SET_NONE;
/*
 * Firewall is at the same location
 */
	figure->same_square = unit->same_square;
	unit->same_square = figure;
/*
 * Report
 */
	start_fold_unit_segment(unit);
	add_fold_string("calls ");
	add_fold_integer(size);
	add_fold_string(beasts->plural);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_ANGEL_OF_DEATH
/**
 ** BATTLE_GENERATE_ANGEL
 **	Death angel manifests
 **/
void battle_generate_angel(figure_s *unit, char *name, race_s *angel)
{
figure_s	*figure;
/*
 * Add a new unit at the battle... A special move is used...
 */
	figure = allocate_new_figure();
	figure->unit = virtual_unit(angel, 1);
	figure->race = angel;
	figure->unit->name = strdup("angel of death");
	figure->side = unit->side;
	figure->offense = unit->offense;
	figure->same_side = figure->side->units;
	figure->side->units = figure;
	figure->side->size++;
	figure->rank = unit->rank;
	figure->file = unit->file;
	figure->movement = BATTLEFIELD_MOVE_LEADER;
	figure->living = 1;
	figure->fanatic = 1;
	figure->flying = 1;
	figure->simplename = 1;
	figure->actions[0].option = COMBAT_SET_SKILL;
	figure->actions[0].u.use_skill = angel->skilled->skill;
	figure->actions[1].option = COMBAT_SET_MELEE;
	figure->actions[2].option = COMBAT_SET_NONE;
/*
 * Firewall is at the same location
 */
	figure->same_square = unit->same_square;
	unit->same_square = figure;
/*
 * Report
 */
	start_fold_unit_segment(unit);
	add_fold_string("invokes an ");
	add_fold_string(angel->name);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_FIRE_PILLAR
/**
 ** BATTLE_GENERATE_PILLAR
 **	Pillar of fire burns
 **/
void battle_generate_pillar(figure_s *unit, char *name, race_s *pillar)
{
figure_s	*figure;
/*
 * Add a new unit at the battle... A special move is used...
 */
	figure = allocate_new_figure();
	figure->unit = virtual_unit(pillar, 1);
	figure->race = pillar;
	figure->unit->name = strdup("pillar of fire");
	figure->side = unit->side;
	figure->offense = unit->offense;
	figure->same_side = figure->side->units;
	figure->side->units = figure;
	figure->side->size++;
	figure->rank = unit->rank;
	figure->file = unit->file;
	figure->movement = BATTLEFIELD_MOVE_RANDOM;
	figure->living = 1;
	figure->fanatic = 1;
	figure->flying = 1;
	figure->simplename = 1;
	figure->actions[0].option = COMBAT_SET_SKILL;
	figure->actions[0].u.use_skill = pillar->skilled->skill;
	figure->actions[1].option = COMBAT_SET_MELEE;
	figure->actions[2].option = COMBAT_SET_NONE;
/*
 * Firewall is at the same location
 */
	figure->same_square = unit->same_square;
	unit->same_square = figure;
/*
 * Report
 */
	start_fold_unit_segment(unit);
	add_fold_string("calls down a ");
	add_fold_string(pillar->name);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif
