/* $Id: b_fx.c,v 1.5 1999/11/21 15:46:11 archer Exp $
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "fxdef.h"


/**
 ** Special prototypes
 **/
extern void battle_generate_firewall(figure_s *, char *, race_s *);
extern void battle_generate_vortex(figure_s *, char *, race_s *);


#ifdef FX_CAPTURE_BEAST
/**
 ** CHANGE_SIDES
 **	Unit changes sides
 **/
static void change_sides(figure_s *turncoat, figure_s *recruiter)
{
side_s		*side;
figure_s	*prev, *next;
square_s	*move_to;
/*
 * Already done
 */
	if (turncoat->side == (side = recruiter->side))
		return;
/*
 * Unlink in side list
 */
	prev = 0;
	for (next = turncoat->side->units; next; next = next->same_side)
		if (next == turncoat)
			break;
		else
			prev = next;
	if (next) {
		if (prev)
			prev->same_side = next->same_side;
		else
			turncoat->side->units = next->same_side;
	}
/*
 * Unplace on battlefield
 */
	unit_away(turncoat);
	turncoat->side->size -= turncoat->living;
/*
 * Link in recruited list and put back on ground
 */
	turncoat->same_side = side->units;
	side->units = turncoat;
	side->size += turncoat->living;
	turncoat->side = side;
	turncoat->offense = recruiter->offense;
/*
 * Where do we move to?
 */
	move_to = &battlefield[turncoat->rank][turncoat->file];
	if (turncoat->offense) {
		turncoat->same_square = move_to->attackers;
		move_to->attackers = turncoat;
	} else {
		turncoat->same_square = move_to->defenders;
		move_to->defenders = turncoat;
	}
/*
 * Done
 */
}
#endif


/**
 ** REPORT_SPELL
 **	Spell or item was used
 **/
static void report_spell(figure_s *unit, char *name, figure_s *target)
{
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	if (target) {
		add_fold_string(" against ");
		add_fold_string(target->unit->name);
		if (target->simplename)
			add_fold_tag(&target->unit->id);
	}
	print_folded(terse_report, 5);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}


#ifdef FX_STONE_HAND
/**
 ** TARGET_USES_ITEM
 **	Returns true if no equipment of that category is used right now
 **/
static int target_uses_item(figure_s *target, char category)
{
carry_s	*using;
/*
 * Now, what
 */
	for (using = target->using; using; using = using->next)
		if (using->equipped && using->item->equip_category == category)
			return 0;
	return 1;
}
#endif


/**
 ** BATTLE_FX_TARGET_CHECK
 **	Check targets according to the FX restriction
 **/
int battle_fx_target_check(figure_s *unit, int fx)
{
carry_s	*uses;
/*
 * Use equipment?
 */
	switch (fx) {
#ifdef FX_BATTLE_QUAGMIRE
	    case FX_BATTLE_QUAGMIRE:
		if (unit->current_init < 0)
			return 1;
		return 0;
#endif
#ifdef FX_BATTLE_PRESSURE
	    case FX_BATTLE_PRESSURE:
		if (unit->has_acted)
			return 1;
		return 0;
#endif
#ifdef FX_BATTLE_DRAINLIFE
	    case FX_BATTLE_DRAINLIFE:
		if (unit->modified.life <= 2)
			return 1;
		return 0;
#endif
#ifdef FX_STONE_HAND
	    case FX_STONE_HAND:
		return target_uses_item(unit, EQUIP_CATEGORY_WEAPON);
#endif
#ifdef FX_BATTLE_MISHAP
	    case FX_BATTLE_MISHAP:
		if (unit->vital.defense >= 20)
			return 1;
		for (uses = unit->using; uses; uses = uses->next)
			if (uses->equipped)
				return 0;
		return 1;
#endif
#ifdef FX_MIND_CONFUSION
	    case FX_MIND_CONFUSION:
		if (!unit->has_acted)
			return 0;
		return 1;
#endif
#ifdef FX_DRAGONSLICER
	    case FX_DRAGONSLICER:
		if (unit->race->type >= RACE_CREATURE)
			return 0;
		return 1;
#endif
#ifdef FX_BATTLE_DROWN
	    case FX_BATTLE_DROWN:
		if (unit->modified.life <= 1)
			return 1;
		return 0;
#endif
#ifdef FX_CAPTURE_BEAST
	    case FX_CAPTURE_BEAST:
		if (unit->race->type != RACE_CREATURE)
			return 1;
		if (unit->unit->leader)
			return 1;
		return 0;
#endif
#ifdef FX_CAPTURE_CREATURE
	    case FX_CAPTURE_CREATURE:
		if (unit->race->type != RACE_CREATURE + 1)
			return 1;
		if (unit->unit->leader)
			return 1;
		return 0;
#endif
#ifdef FX_CAPTURE_MONSTER
	    case FX_CAPTURE_MONSTER:
		if (unit->race->type != RACE_CREATURE + 2)
			return 1;
		if (unit->unit->leader)
			return 1;
		return 0;
#endif
#ifdef FX_BATTLE_FLOW
	    case FX_BATTLE_FLOW:
		if (unit->movement != BATTLEFIELD_MOVE_CHARGE)
			return 1;
		if (unit->has_acted)
			return 1;
		return 0;
#endif
#ifdef FX_HEALING
	    case FX_HEALING:
		if (unit->wounded || unit->hits)
			return 0;
		return 1;
#endif
#ifdef FX_HEAVINESS
	    case FX_HEAVINESS:
		if (unit->heavy)
			return 1;
		return 0;
#endif
#ifdef FX_BATTLE_CONFUSED
	    case FX_BATTLE_CONFUSED:
		if (unit->friend_or_foe || unit->has_acted)
			return 1;
		return 0;
#endif
#ifdef FX_TERRIFY
	    case FX_TERRIFY:
		if (unit->race->type != RACE_LEADER)
			return 1;
		if (unit->movement == BATTLEFIELD_MOVE_FLEE)
			return 1;
		return 0;
#endif
	    default:
		break;
	}
	return 0;
}


#ifdef FX_BATTLE_QUAGMIRE
/**
 ** BATTLE_QUAGMIRE
 **	Causes quagmire on the battlefield
 **/
static void battle_quagmire(figure_s *unit, char *name)
{
figure_s	*target;
int		n;
/*
 * "Strike"
 */
	target = unit->target;
	report_spell(unit, name, target);
	target->current_init -= 5;
	target->tactical_bonus -= 5;
	for (n = 0; n <= MAX_COMBAT_SETTING; n++)
		target->actions[n].initiative -= 5;
	target->mandated.initiative -= 5;
	battle_delay_processing(target);
}
#endif


#ifdef FX_BATTLE_PRESSURE
/**
 ** BATTLE_PRESSURE
 **	Causes leader to delay
 **/
static void battle_pressure(figure_s *unit, char *name)
{
figure_s	*target;
int		n;
/*
 * "Strike"
 */
	target = unit->target;
	report_spell(unit, name, target);
	target->current_init -= 15;
	for (n = 0; n <= MAX_COMBAT_SETTING; n++)
		target->actions[n].initiative -= 15;
	target->mandated.initiative -= 15;
	battle_delay_processing(target);
}
#endif


#ifdef FX_STONE_HAND
/**
 ** BATTLE_DISARM
 **	Drains part of the unit's life
 **/
static void battle_disarm(figure_s *unit, char *name)
{
figure_s	*target;
carry_s		*weapons;
stats_s		before;
int		roll;
int		amount;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	if (target->living > 20) {
		roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll >= 20 && unit->side->fate)
			roll = roll_1Dx(target->living);
		if (roll < 20 && target->side->fate)
			roll = roll_1Dx(target->living);
#endif
		if (roll >= 20) {
			add_fold_string(" and fails");
			target = 0;
		}
	}
	if (target) {
		amount = 0;
		for (weapons = target->using; weapons; weapons = weapons->next)
			if (weapons->equipped && weapons->item->equip_category == EQUIP_CATEGORY_WEAPON) {
				amount += weapons->equipped;
				weapons->equipped = 0;
			}
		before = target->vital;
		compute_battle_stats(target, 0);
		target->modified.melee   += target->vital.melee - before.melee;
		target->modified.missile += target->vital.missile - before.missile;
		target->modified.defense += target->vital.defense - before.defense;
		target->modified.damage  += target->vital.damage - before.damage;
		target->modified.hits    += target->vital.hits - before.hits;
		add_fold_string(", causing it to drop ");
		add_fold_integer(amount);
		add_fold_string(" weapons");
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_BATTLE_MISHAP
/**
 ** BATTLE_MISHAP
 **	Cause equipment to be dropped
 **/
static void battle_mishap(figure_s *unit, char *name)
{
figure_s	*target;
carry_s		*equipment;
stats_s		before;
int		roll, against;
int		amount;
int		checks;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	amount = 0;
	against = 20 - target->vital.defense;
	for (equipment = target->using; equipment; equipment = equipment->next)
		for (checks = equipment->equipped; checks > 0; checks--) {
			roll = roll_1Dx(100);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
			if (roll >= against && unit->side->fate)
				roll = roll_1Dx(100);
			if (roll < against && target->side->fate)
				roll = roll_1Dx(100);
#endif
			if (roll < against) {
				equipment->equipped--;
				equipment->amount--;
				amount++;
			}
		}
/*
 * Ok go
 */
	if (amount) {
		before = target->vital;
		compute_battle_stats(target, 0);
		target->modified.melee   += target->vital.melee - before.melee;
		target->modified.missile += target->vital.missile - before.missile;
		target->modified.defense += target->vital.defense - before.defense;
		target->modified.damage  += target->vital.damage - before.damage;
		target->modified.hits    += target->vital.hits - before.hits;
		add_fold_string(", causing it to lose ");
		add_fold_integer(amount);
		add_fold_string(" piece");
		if (amount > 1)
			add_fold_char('s');
		add_fold_string(" of equipment");
	} else
		add_fold_string(" and fails to get results");
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_BATTLE_DRAINLIFE
/**
 ** BATTLE_DRAINLIFE
 **	Drains part of the unit's life
 **/
static void battle_drainlife(figure_s *unit, char *name)
{
figure_s	*target;
int		roll;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	if (target->living > 20) {
		roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll >= 20 && unit->side->fate)
			roll = roll_1Dx(target->living);
		if (roll < 20 && target->side->fate)
			roll = roll_1Dx(target->living);
#endif
		if (roll >= 20) {
			add_fold_string(" and fails");
			target = 0;
		}
	}
	if (target) {
		target->vital.life++;
		target->vital.life /= 2;
		roll  = target->modified.life + 1;
		roll /= 2;
/*
 * Keep track of the reduction for next stats calculations
 */
		target->bonus.life += roll - target->modified.life;
		target->modified.life = roll;
		add_fold_string(", reducing its life to ");
		add_fold_integer(roll);
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_BATTLE_DROWN
/**
 ** BATTLE_DROWN
 **	Drains part of the unit's life
 **/
static void battle_drown(figure_s *unit, char *name)
{
figure_s	*target;
int		roll;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	if (target->living > 40) {
		roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll >= 40 && unit->side->fate)
			roll = roll_1Dx(target->living);
		if (roll < 40 && target->side->fate)
			roll = roll_1Dx(target->living);
#endif
		if (roll >= 40) {
			add_fold_string(" and fails");
			target = 0;
		}
	}
	if (target) {
		target->vital.life--;
/*
 * Keep track of the reduction for next stats calculations
 */
		target->modified.life--;
		add_fold_string(", reducing its life by 1");
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_TIDAL_WAVE
/**
 ** BATTLE_TIDAL_APPLY
 **	Apply the tides on the battlefield
 **/
static void battle_tidal_apply(figure_s *unit, char *name)
{
figure_s	*target;
char		*separator;
int		d;
/*
 * Report first thing
 */
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	separator = ", enhancing ";
/*
 * Apply on all targets
 */
	for (target = unit->target; target; target = target->next_target) {
		if (target == unit)
			continue;
		if (target->file > unit->file)
			d = target->file - unit->file;
		else
			d = unit->file - target->file;
		if (target->rank > unit->rank)
			d += target->rank - unit->rank;
		else
			d += unit->rank - target->rank;
		if (d & 1) {
			target->modified.melee++;
			target->modified.missile++;
			target->modified.defense++;
			add_fold_string(separator);
			add_fold_string(target->unit->name);
			if (target->simplename)
				add_fold_tag(&target->unit->id);
			separator = comma;
		}
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_BATTLE_FIRE_CLOAK
/**
 ** BATTLE_FIRECLOAK
 **	Set the unit's fire cloak bit, then drop 2 to all initiative
 **/
static void battle_firecloak(figure_s *unit, char *name, skill_s *effective)
{
combat_set_s 	*next;
experience_s	*exp;
/*
 * Report
 */
	report_spell(unit, name, 0);
	unit->pending_effects |= FX_BIT_FIRE_CLOAK;
	for (next = unit->considered + 1; next->option; next++)
		next->initiative -= 2;
/*
 * Substract mana and add experience
 */
	(void)battle_components_away(unit->unit, effective, 1);
	if ((exp = unit_experiences(unit->unit, effective, 0)) != 0)
		exp->points += (SKILL_POINTS_PER_DAY / 2);
	unit->considered->skill_used = 1;
	unit->considered->avoid_action = 1;
}
#endif


#ifdef FX_CATCH_SOUL
/**
 ** BATTLE_SOUL_CATCHER
 **	Catch the departing soul of a leader
 **/
static int battle_soul_catcher(figure_s *necromant, char *name, race_s *ulrd)
{
figure_s	*target;
unit_s		*unit;
experience_s	*added, *intrinsic;
/*
 * Check for a dying leader
 */
	for (target = necromant->side->units; target; target = target->same_side)
		if (target->living <= 0 && target->fleeing <= 1 && (unit = target->unit)->race->type == RACE_LEADER) {
			report_spell(necromant, name, target);
			print_folded(full_report, 5);
			print_folded(long_report, 5);
			target->living = 1;
			target->fleeing = 100;
			target->fled = 100;
/*
 * Leader forgest half its skills
 */
/*** HACK ***/
/*
 * Make the soul an undead lord
 */
			unit->race = ulrd;
			for (intrinsic = ulrd->skilled; intrinsic; intrinsic = intrinsic->next) {
				added = unit_experiences(unit, intrinsic->skill, 1);
				added->points += intrinsic->points;
				adjust_experience(added, 1);
			}
		}
	return 1;
}
#endif


#ifdef FX_EARTH_CLEAVING
/**
 ** SWALLOWED
 **	One unit has to evade the earth crevices
 **/
static int swallowed(figure_s *unit)
{
int	losses, i, rolled;
/*
 * Roll for all living
 */
	losses = 0;
	for (i = 0; i < unit->living; i++) {
		rolled = roll_1Dx(20);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (!rolled && unit->side->fate)
			rolled = roll_1Dx(20);
#endif
		if (!rolled)
			losses++;
	}
/*
 * Losses? Hits are reduced
 */
	if (losses) {
		if (losses < unit->living)
			unit->hits = proportional(unit->hits, unit->living, unit->living - losses);
		else
			unit->hits = 0;
		unit->living -= losses;
		if (unit->wounded > unit->living)
			unit->wounded = unit->living;
	}
	return losses;
}


/**
 ** BATTLE_OPEN_EARTH
 **	Pick a target. All figures at the target suffer a cleave
 ** attack
 **/
static void battle_open_earth(figure_s *unit, char *name)
{
int		total;
figure_s	*target;
square_s	*locale;
/*
 * Casualties
 */
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	total = 0;
/*
 * Go for a rampaging
 */
	locale = &battlefield[unit->target->rank][unit->target->file];
	for (target = locale->attackers; target; target = target->same_square)
		total += swallowed(target);
	for (target = locale->defenders; target; target = target->same_square)
		total += swallowed(target);
	if (total == 0)
		add_fold_string(", and all escape");
	else {
		add_fold_string(", swallowing ");
		add_fold_integer(total);
		add_fold_string(" figure");
		if (total > 1)
			add_fold_char('s');
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_MIND_CONFUSION
/**
 ** BATTLE_SEED_CONFUSION
 **	Cause a unit to either move, or shuffle orders
 **/
static void battle_seed_confusion(figure_s *unit, char *name)
{
figure_s	*target;
combat_set_s	*actions;
int		roll;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	if (target->living > 20) {
		roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll >= 20 && unit->side->fate)
			roll = roll_1Dx(target->living);
		if (roll < 20 && target->side->fate)
			roll = roll_1Dx(target->living);
#endif
		if (roll >= 20) {
			add_fold_string(" and fails");
			target = 0;
		}
	}
/*** HACK ***/
	if (target) {
		if (!target->has_moved)
			move_at_random(target);
		else {
			for (actions = unit->actions; actions->option; actions++)
				if (!actions->skill_used) {
					actions->skill_used = 1;
					break;
				}
		}
	}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_INSTANT_FORTRESS
/**
 ** BATTLE_FORTRESS
 **	Cause a unit to either move, or shuffle orders
 **/
static void battle_fortress(figure_s *unit, char *name)
{
int	i, j, d;
/*
 * "Strike"
 */
	report_spell(unit, name, 0);
	if (unit->side == &defenders)
		d = 3;
	else
		d = 0;
	for (i = 0; i < 3; i++)
		for (j = 0; j < 3; j++) {
			battlefield[i+d][j].local_modifiers.defense = 1;
			battlefield[i+d][j].local_modifiers.missile = 1;
		}
	unit->side->fortress = 1;
}
#endif


#ifdef FX_INSTANT_MOVEMENT
/**
 ** BATTLE_FAST_MOVE
 **	Returns true if we reduced the tactical advantage, or moved any unit
 ** Skip spell otherwise.
 **/
static int battle_instant_move(figure_s *unit, char *name)
{
figure_s	*ally;
int		used;
int		om;
/*
 * Used for tactical advantage
 */
	if (unit->side->opposing->tactician > 0) {
		report_spell(unit, name, 0);
		used = 0;
		unit->side->opposing->tactician--;
	} else
		used = 1;
/*
 * Used for any movement
 */
	for (ally = unit->side->units; ally; ally = ally->same_side) {
		if (ally == unit)
			continue;
		om = ally->has_moved;
		if (move_soldier(ally)) {
			ally->has_moved = om;
			if (used) {
				report_spell(unit, name, 0);
				used = 0;
			}
		}
	}
/*
 * Skill was used in battle
 */
	return used;
}
#endif


#ifdef FX_HEAVINESS
/**
 ** BATTLE_HEAVINESS
 **	Unit is locked in place
 **/
static int battle_heaviness(figure_s *unit, int amount, char * name)
{
figure_s	*target;
int		total;
carry_s		*using;
/*
 * Targets
 */
	amount *= 5;
	for (target = unit->target; target; target = target->next_target)
		if (target->living <= amount && target->living)
			break;
	if (!target)
		return 1;
/*
 * Heaviness strikes!
 */
	report_spell(unit, name, target);
	target->heavy = 4;
	target->has_moved = 1;
	total = 0;
	for (using = unit->using; using; using = using->next)
		total += using->equipped;
	total += target->living / 2;
	total /= target->living;
	target->heavy_penalty = total;
	compute_battle_stats(target, 0);
	return 0;
}
#endif


#ifdef FX_COUNTER_WINDS
/**
 ** BATTLE_WINDS
 **/
static void battle_winds(figure_s *unit, char *name)
{
figure_s	*ally;
/*
 * Used for any allies
 */
	for (ally = unit->side->units; ally; ally = ally->same_side) {
		ally->modified.missile++;
		ally->bonus.missile++;
	}
/*
 * Enemies get a penalty
 */
	if (unit->side == &defenders)
		ally = attackers.units;
	else
		ally = defenders.units;
	while (ally) {
		ally->modified.missile--;
		ally->bonus.missile--;
		ally = ally->same_side;
	}
/*
 * Skill was used in battle
 */
	report_spell(unit, name, 0);
}
#endif


#ifdef FX_CAPTURE_BEAST
/**
 ** BATTLE_TAME
 **	Monster joins on the opposite side
 **/
static void battle_tame(figure_s *unit, char *name)
{
figure_s	*target;
int		chance, roll;
unit_s		*beast, *tamer;
/*
 * "Strike"
 */
	target = unit->target;
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" against ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	chance = 90 - 10 * target->living;
	roll = roll_1Dx(100);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
	if (roll >= chance && unit->side->fate)
		roll = roll_1Dx(100);
#endif
	if (roll >= chance) {
		add_fold_string(" and fails");
		target = 0;
	}
/*
 * Target is now loyal to caster
 */
	beast = target->unit;
	tamer = unit->unit;
	beast->faction = tamer->faction;
	stack_under(tamer, beast);
	change_sides(target, unit);
/*
 * Unit switches sides on the battlefield
 */
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif

#ifdef FX_RESHAPE_EQUIPMENT
/**
 ** BATTLE_RESHAPE
 **	Reshape a piece of equipment
 **/
static void battle_reshape(figure_s *unit, char *name, skill_s *effective)
{
carry_s		*using;
item_s		*shape;
experience_s	*exp;
int		n;
/*
 * Shape into?
 */
	shape = effective->end_product;
	for (using = unit->using; using; using = using->next) {
		if (using->item == shape)
			return;
		if (using->item->equip_category == shape->equip_category)
			break;
	}
	if (!using)
		return;
/*
 * Uses an item of the category, but not the specified item
 */
	report_spell(unit, name, 0);
	using->item = shape;
	compute_battle_stats(unit, 0);
/*
 * Substract mana and add experience
 */
	(void)battle_components_away(unit->unit, effective, 1);
	if ((exp = unit_experiences(unit->unit, effective, 0)) != 0)
		exp->points += (SKILL_POINTS_PER_DAY / 2);
	unit->considered->skill_used = 1;
	unit->considered->avoid_action = 1;
/*
 * Next actions have 2 init penalties
 */
	for (n = 0; n <= MAX_COMBAT_SETTING; n++)
		unit->actions[n].initiative -= 2;
	unit->mandated.initiative -= 2;
}
#endif


#ifdef FX_STONE_HEADS
/**
 ** BATTLE_STONE_HEAD
 **	Units are stoned
 **/
static void battle_stonehead(figure_s *unit, char *name)
{
figure_s	*ennemies;
side_s		*affected;
int		n;
/*
 * Spell executes
 */
	report_spell(unit, name, 0);
	affected = unit->side->opposing;
	affected->stone_headed = 1;
	for (ennemies = affected->units; ennemies; ennemies = ennemies->same_side) {
		if (ennemies->has_acted)
			continue;
/*
 * Unit suffers initiative penalty
 */
		for (n = 0; n <= MAX_COMBAT_SETTING; n++)
			ennemies->actions[n].initiative -= 2;
		ennemies->mandated.initiative -= 2;
/*
 * If current initiative is lower than current round, reshuffle initiative
 */
		if (ennemies->current_init < initiative_level) {
			unit->current_init -= 2;
			battle_delay_processing(unit);
		}
	}
}
#endif


#ifdef FX_BATTLE_FLOW
/**
 ** BATTLE_SPEEDUP
 **	Allow one target to move
 **/
static int battle_speedup_one(figure_s *unit, char *name)
{
figure_s	*ally;
int		used;
int		om;
/*
 * Fist
 */
	used = 1;
/*
 * Used for any movement
 */
	for (ally = unit->target; ally; ally = ally->next_target) {
		if (ally == unit)
			continue;
		while (move_soldier(ally))
			used = 0;
		if (!used) {
			report_spell(unit, name, 0);
			break;
		} else
			ally->has_moved = 0;
	}
/*
 * Skill was used in battle
 */
	return used;
}
#endif


#ifdef FX_HEALING
/**
 ** BATTLE_HEAL
 **	Simple and straightforward
 **/
static void battle_heal(figure_s *unit, char *name, figure_s *target)
{
int	healed;
int	rolls;
/*
 * Do
 */
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" for ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	print_folded(terse_report, 5);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
/*
 * Healing
 */
	healed = 0;
	for (rolls = 1; rolls < 6; rolls++)
		healed += 1 + roll_1Dx(6);
	target->wounded = 0;
	target->hits -= healed;
	if (target->hits < 0)
		target->hits = 0;
}
#endif


#ifdef FX_BATTLE_CONFUSION
/**
 ** BATTLE_CONFUSED
 **	Simple and straightforward
 **/
static void battle_confused(figure_s *unit, char *name, figure_s *target)
{
int	healed;
int	rolls;
/*
 * Do
 */
	start_fold_unit_segment(unit);
	add_fold_string("use ");
	add_fold_string(name);
	add_fold_string(" for ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
	print_folded(terse_report, 5);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
/*
 * Healing
 */
	healed = 0;
	for (rolls = 1; rolls < 6; rolls++)
		healed += 1 + roll_1Dx(6);
	target->wounded = 0;
	target->hits -= healed;
	if (target->hits < 0)
		target->hits = 0;
}
#endif


#ifdef FX_BATTLE_CONFUSED
/**
 ** BATTLE_BLINDED
 **	Simple and straightforward
 **/
static void battle_blinded(figure_s *unit, char *name, figure_s *target)
{
int	roll;
/*
 * Do check
 */
	start_fold_unit_segment(unit);
	add_fold_string("causes confusion for ");
	add_fold_string(target->unit->name);
	if (target->simplename)
		add_fold_tag(&target->unit->id);
/*
 * Chance of being confused
 */
	if (target->living > 20) {
		roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll >= 20 && unit->side->fate)
			roll = roll_1Dx(target->living);
		if (roll < 20 && target->side->fate)
			roll = roll_1Dx(target->living);
#endif
		if (roll >= 20) {
			add_fold_string(" but fails");
			target = 0;
		}
	}
/*
 * Target was struck
 */
	if (target)
		target->friend_or_foe = 1;
	print_folded(terse_report, 5);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


#ifdef FX_BATTLE_GUST_WIND
/**
 ** BATTLE_WINDED
 **	Puts a penalty against ranged attacks
 **/
static int battle_winded(figure_s *unit, char *name, figure_s *target)
{
int	roll, did;
/*
 * Do?
 */
	for (did = 1; target; target = target->next_target) {
		if (target->bonus.missile < -1)
			continue;
		if (target->living > 20) {
			roll = roll_1Dx(target->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
			if (roll >= 20 && unit->side->fate)
				roll = roll_1Dx(target->living);
			if (roll < 20 && target->side->fate)
				roll = roll_1Dx(target->living);
#endif
		} else
			roll = 0;
		if (roll < 20) {
			did = 0;
			target->modified.missile -= 2;
			target->bonus.missile -= 2;
		}
	}
/*
 * One target was struck
 */
	if (!did)
		report_spell(unit, name, 0);
	return did;
}
#endif


#ifdef FX_STINKING_CLOUD
/**
 ** BATTLE_STINK
 **	Affected units must retreat one square
 **/
static void battle_stink(figure_s *unit, char *name, figure_s *target)
{
int	roll;
/*
 * Do?
 */
	report_spell(unit, name, 0);
	for (; target; target = target->next_target) {
		roll = roll_1Dx(100);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (roll < target->living && unit->side->fate)
			roll = roll_1Dx(100);
		if (roll >= target->living && target->side->fate)
			roll = roll_1Dx(100);
#endif
		if (roll >= target->living) {
			(void)battle_move_retreat(target);
			target->has_moved = 1;
		}
	}
}
#endif


#ifdef FX_RESHAPE_SELF
/**
 ** BATTLE_RESHAPE
 **	Unit reshapes itself into a fire spirit
 **/
static void battle_reshape_self(figure_s *unit, skill_s *effective)
{
static race_s	*spirit;
combat_set_s	*next;
experience_s	*exp;
/*
 * Fire spirit
 */
	if (!spirit) {
		synthetic_tag("fspi");
		spirit = race_from_tag(0);
	}
	if (unit->race == spirit)
		return;
/*
 */
	unit->race = spirit;
	compute_battle_stats(unit, 0);
	for (next = unit->considered + 1; next->option; next++)
		next->initiative -= 2;
/*
 * Substract mana and add experience
 */
	(void)battle_components_away(unit->unit, effective, 1);
	if ((exp = unit_experiences(unit->unit, effective, 0)) != 0)
		exp->points += (SKILL_POINTS_PER_DAY / 2);
	unit->considered->skill_used = 1;
	unit->considered->avoid_action = 1;
/*
 * Report event
 */
	report_spell(unit, effective->name, 0);
	start_fold_unit_segment(unit);
	add_fold_string("suddendly bursts in flame!");
	print_folded(terse_report, 5);
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}
#endif


/**
 ** BATTLE_FX_EFFECT
 **	Execute a special effect
 **/
int battle_fx_effect(figure_s *unit, int amount, int fx, char *name, skill_s *effective)
{
	switch (fx) {
#ifdef FX_BATTLE_QUAGMIRE
	    case FX_BATTLE_QUAGMIRE:
		if (!unit->target)
			return 1;
		battle_quagmire(unit, name);
		return 0;
#endif
#ifdef FX_BATTLE_PRESSURE
	    case FX_BATTLE_PRESSURE:
		if (!unit->target)
			return 1;
		battle_pressure(unit, name);
		return 0;
#endif
#ifdef FX_BATTLE_DRAINLIFE
	    case FX_BATTLE_DRAINLIFE:
		if (!unit->target)
			return 1;
		battle_drainlife(unit, name);
		return 0;
#endif
#ifdef FX_TIDAL_WAVE
	    case FX_TIDAL_WAVE:
		battle_tidal_apply(unit, name);
		return 0;
#endif
#ifdef FX_STONE_HAND
	    case FX_STONE_HAND:
		if (!unit->target)
			return 1;
		battle_disarm(unit, name);
		return 0;
#endif
#ifdef FX_BATTLE_MISHAP
	    case FX_BATTLE_MISHAP:
		if (!unit->target)
			return 1;
		battle_mishap(unit, name);
		return 0;
#endif
#ifdef FX_BATTLE_FIRE_CLOAK
	    case FX_BATTLE_FIRE_CLOAK:
		if (unit->pending_effects & FX_BIT_FIRE_CLOAK)
			return 1;
		battle_firecloak(unit, name, effective);
		return 1;	/* fake failure, we've in fact executed */
#endif
#ifdef FX_CATCH_SOUL
	    case FX_CATCH_SOUL:
		return battle_soul_catcher(unit, name, effective->specific);
#endif
#ifdef FX_FIREWALL
	    case FX_FIREWALL:
		battle_generate_firewall(unit, name, effective->specific);
		return 0;
#endif
#ifdef FX_EARTH_CLEAVING
	    case FX_EARTH_CLEAVING:
		if (!unit->target)
			return 1;
		battle_open_earth(unit, name);
		return 0;
#endif
#ifdef FX_MIND_CONFUSION
	    case FX_MIND_CONFUSION:
		if (!unit->target)
			return 1;
		battle_seed_confusion(unit, name);
		return 0;
#endif
#ifdef FX_INSTANT_FORTRESS
	    case FX_INSTANT_FORTRESS:
		if (unit->side->fortress)
			return 1;
		battle_fortress(unit, name);
		return 0;
#endif
#ifdef FX_BATTLE_DROWN
	    case FX_BATTLE_DROWN:
		if (!unit->target)
			return 1;
		battle_drown(unit, name);
		return 0;
#endif
#ifdef FX_INSTANT_MOVEMENT
	    case FX_INSTANT_MOVEMENT:
		return battle_instant_move(unit, name);
#endif
#ifdef FX_BLACK_AURA
	    case FX_BLACK_AURA:
		if (unit->black_aura)
			return 1;
		unit->black_aura = 4;
		report_spell(unit, name, 0);
		return 0;
#endif
#ifdef FX_HEAVINESS
	    case FX_HEAVINESS:
		return battle_heaviness(unit, amount, name);
#endif
#ifdef FX_COUNTER_WINDS
	    case FX_COUNTER_WINDS:
		battle_winds(unit, name);
		return 0;
#endif
#ifdef FX_CAPTURE_BEAST
	    case FX_CAPTURE_BEAST:
#ifdef FX_CAPTURE_CREATURE
	    case FX_CAPTURE_CREATURE:
#endif
#ifdef FX_CAPTURE_MONSTER
	    case FX_CAPTURE_MONSTER:
#endif
		if (!unit->target)
			return 1;
		battle_tame(unit, name);
		return 0;
#endif
#ifdef FX_SWIRLINGVORTEX
	    case FX_SWIRLINGVORTEX:
		battle_generate_vortex(unit, name, effective->specific);
		return 0;
#endif
#ifdef FX_STONE_HEADS
	    case FX_STONE_HEADS:
		if (unit->side->opposing->stone_headed)
			return 1;
		battle_stonehead(unit, name);
		return 0;
#endif
#ifdef FX_RESHAPE_EQUIPMENT
	    case FX_RESHAPE_EQUIPMENT:
		battle_reshape(unit, name, effective);
		return 1; /* might have executed in practice */
#endif
#ifdef FX_CALL_HELP
	    case FX_CALL_HELP:
		if (unit->help_called)
			return 1;
		battle_generate_beasts(unit, name, effective->specific);
		unit->help_called = 1;
		return 0;
#endif
#ifdef FX_BATTLE_FLOW
	    case FX_BATTLE_FLOW:
		if (!unit->target)
			return 1;
		return battle_speedup_one(unit, name);
#endif
#ifdef FX_ANGEL_OF_DEATH
	    case FX_ANGEL_OF_DEATH:
		if (unit->angel_called && unit->angel_called->living)
			return 1;
		battle_generate_angel(unit, name, effective->specific);
		return 0;
#endif
#ifdef FX_HEALING
	    case FX_HEALING:
		if (!unit->target)
			return 1;
		battle_heal(unit, name, unit->target);
		return 0;
#endif
#ifdef FX_BATTLE_CONFUSED
	    case FX_BATTLE_CONFUSED:
		if (!unit->target)
			return 1;
		battle_blinded(unit, name, unit->target);
		return 0;
#endif
#ifdef FX_BATTLE_GUST_WIND
	    case FX_BATTLE_GUST_WIND:
		return battle_winded(unit, name, unit->target);
#endif
#ifdef FX_STINKING_CLOUD
	    case FX_STINKING_CLOUD:
		if (!unit->target)
			return 1;
		battle_stink(unit, name, unit->target);
		return 0;
#endif
#ifdef FX_RESHAPE_SELF
	    case FX_RESHAPE_SELF:
		battle_reshape_self(unit, effective);
		return 1;
#endif
#ifdef FX_FIRE_PILLAR
	    case FX_FIRE_PILLAR:
		battle_generate_pillar(unit, name, effective->specific);
		return 0;
#endif
	    default:
		printf("Unimplemented battle FX %d [%s] by %s [%s]\n", fx, name, unit->unit->name, unit->unit->id.text);
	}
	return 1;
}


#ifdef FX_WRAITH_CALL
/**
 ** BATTLE_WRAITH_CALL
 **	Causes terror on the battlefield
 **/
static void battle_wraith_call(figure_s *unit)
{
figure_s	*target;
int		n;
/*
 * Terror strikes!
 */
	if (unit->living > 20) {
		n = roll_1Dx(unit->living);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
		if (n >= 20 && unit->side->fate)
			n = roll_1Dx(unit->living);
		if (n < 20 && target->side->fate)
			n = roll_1Dx(unit->living);
#endif
	} else
		n = 1;
	if (n < 20) {
		add_fold_string(" inspiring terror");
		unit->movement = BATTLEFIELD_MOVE_FLEE;
	}
}
#endif


#ifdef FX_TERRIFY
/**
 ** BATTLE_TERRIFY
 **	Causes terror in the heart of the unit
 **/
static void battle_terrified(figure_s *unit)
{
figure_s	*target;
int		n;
/*
 * Terror strikes!
 */
	add_fold_string(" causing it to flee in terror");
	unit->was_hit = 0;
	unit->movement = BATTLEFIELD_MOVE_FLEE;
	for (n = 0; n <= MAX_COMBAT_SETTING; n++)
		unit->actions[n].option = 0;
	unit->actions[0].option = COMBAT_SET_PARRY;
}
#endif


/**
 ** BATTLE_FX_STRIKE
 **	Special effects that occur on a strike
 **/
void battle_fx_strike(figure_s *target, int fx)
{
	switch (fx) {
#ifdef FX_WRAITH_CALL
	    case FX_WRAITH_CALL:
		if (target->has_lost)
			battle_wraith_call(target);
		return;
#endif
#ifdef FX_DRAGONSLICER
            case FX_DRAGONSLICER: /* the target is the select */
		return;
#endif
#ifdef FX_TERRIFY
	    case FX_TERRIFY:
		if (target->was_hit)
			battle_terrified(target);
		return;
#endif
	    default:
		printf("Unimplemented battle strike FX %d [???]\n", fx);
	}
}
