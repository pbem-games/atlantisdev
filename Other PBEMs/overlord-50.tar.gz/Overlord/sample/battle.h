/* $Id: battle.h,v 1.9 1999/11/21 15:46:12 archer Exp $
 *	Battle module
 */
#ifndef _overlord_battle_h_
#define _overlord_battle_h_
#include "overlord.h"


/**
 ** Battle units
 **/
struct struct_side {
	faction_s		*factions;
	struct struct_side	*opposing;
	struct struct_fig	*units;
	carry_s			*spoils;
	int			tactician,
				strategist,
				stealth,
				observe,
				ambush;
	int			overall_strength;
	int			size,
				rout,
				casualties,
				turn_casualties;
	char			lost;
	char			fate;
	char			fortress; /* in fortress */
#ifdef FX_STONE_HEADS
	char			stone_headed; /* occurs only once */
#endif
};
typedef struct struct_side	side_s;


struct struct_fig {
	struct struct_fig	*same_square;		/* same location */
	struct struct_fig	*next_initiative,	/* doubly-link list */
				*prev_initiative;
	struct struct_fig	*same_side;		/* same side */
	struct struct_fig	*target,
				*next_target;		/* strike! */
#ifdef FX_ANGEL_OF_DEATH
	struct struct_fig	*angel_called;	/* called an angel */
#endif
	unit_s			*unit;
	race_s			*race;
	side_s			*side;
	carry_s			*using;
	stats_s			vital;
	stats_s			modified;
	stats_s			bonus;
	combat_set_s		actions[MAX_COMBAT_SETTING+2];
	combat_set_s		mandated;
	combat_set_s		*considered;
	long			permanent_effects;
	long			pending_effects;
#ifdef BATTLE_INITIATIVE
	int			tactical_bonus;
	int			current_init;
	int			repeating;
#endif
	int			living, active, deceased;
	int			wounded, hits, losses;
	int			was_struck, was_wounded, was_hit, has_lost;
	int			combat_exp, melee_exp, parry_exp;
	char			has_moved, has_acted;
	char			reloading, fleeing, fled;
	char			ranges, targets;
	char			rank, file,
				movement;	/* during combat */
	char			range;		/* of target */
	char			offense;	/* unit attacks or defends? */
	char			fanatic;
	char			flying;
	char			simplename;	/* report unit ID in battle */
#ifdef FX_BLACK_AURA
	char			black_aura;	/* turns of blackness */
#endif
#ifdef FX_CALL_HELP
	char			help_called;	/* call only once */
#endif
#ifdef FX_ANGEL_OF_DEATH
	char			angel_turns;	/* called an angel */
#endif
#ifdef FX_HEAVINESS
	char			heavy;		/* heaviness has struck */
	char			heavy_penalty;
#endif
#ifdef FX_BATTLE_CONFUSED
	char			friend_or_foe;	/* confuse friend and foe */
#endif
#ifdef FX_SHIELDBREAKER
	char			shield_breaker;	/* has -THAT- sword equipped! */
#endif
};
typedef struct struct_fig	figure_s;


struct struct_square {
	figure_s		*attackers,
				*defenders;
	stats_s			local_modifiers;
};
typedef struct struct_square	square_s;


/**
 ** Battle module variables
 **/
extern FILE		*full_report, *long_report, *terse_report;
extern location_s	*battle_location;
extern figure_s		*acting_units;
extern side_s		attackers, defenders;
extern square_s		battlefield[6][3];
extern int		initiative_level;
extern int		observation_round;
extern int		round_number;


/**
 ** Prototypes
 **/
extern void	initiate_attack(unit_s *,unit_s *);
extern void	battle_delay_processing(figure_s *);
extern void	battle_engagement(unit_s *,unit_s *,int);
extern void	battle_assassination(unit_s *, unit_s *, int);
extern void	free_all_soldiers(void);
extern void	run_battle(void);
extern void	start_fold_unit_segment(figure_s *);
extern int	move_soldier(figure_s *);
extern int	move_at_random(figure_s *);
extern int	battle_move_retreat(figure_s *);
extern int	unit_may_act(figure_s *);
extern void	unit_away(figure_s *);
extern void	unit_has_acted(figure_s *);
extern void	random_shuffle(side_s *);
extern void	compute_battle_stats(figure_s *,int);

extern int	battle_fx_target_check(figure_s *,int);
extern int	battle_fx_effect(figure_s *, int, int, char *, skill_s *);
extern void	battle_fx_strike(figure_s *, int);
extern int	battle_components_away(unit_s *, skill_s *, int);


#endif /*_overlord_battle_h_*/
