/* $Id: enumstxt.c,v 1.11 1999/11/21 15:46:12 archer Exp $
 *	Strings
 */

/**
 ** This is visual, and appear in the report generator
 **/
extern char		stance_arguments[];
extern char		participate_modes[];
extern char		battlefield_ranks[];
extern char		battlefield_files[];
extern char		battlefield_moves[];
static char		battlefield_targets[] = "\nbattlefield\nself\narmy\nopposing army\nfriendly unit\nopposing unit\nfriendly leader\nopposing leader";
static char		battlefield_ranges[] = "\nmelee\nranged\nlong range (2)\nfar range (3)\nfield range (4)\nextreme range (5)\ncomplete range (6)\nbattlefield";
static char		battlefield_actions[] = "\nmelee attack\nranged attack\nspecial";
static char		battle_damage_types[] = "standard\nair\nearth\nfire\nvoid\nwater";
static char		equipment_categories[] = "\nfood\nmount\ntool\nship\nweapon\narmor\nhelmet\nshield\ngloves\nboots\namulet\nring\nmisc.\nscroll";
static char		skill_types[] = "\ncombat\nmagic\ncreature";
static char		season_names[] = "spring\nsummer\nautumn\nwinter";
static char		climatic_conditions[] = "standard\nfair\nsunny\nrainy\nwindy\nstormy\nblizzard\ntwilight\nbland";
static char		title_kinds[] = "minor\nstandard\nmajor\noverlord";
static char		race_types[] = "\nleader\nfollower\nbeast\ncreature\nmonster\nbattle-only entity";
