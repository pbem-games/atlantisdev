/* $Id: command_e.h,v 1.2 1999/02/23 18:06:18 archer Exp $
 *	Command argument strings
 */

extern char		movement_modes[];
extern char		stance_arguments[];
extern char		participate_modes[];
extern char		battlefield_ranks[];
extern char		battlefield_files[];
extern char		battlefield_moves[];
extern char		possible_settings[];
#define battle_arguments	participate_modes
#define rank_arguments		battlefield_ranks
#define file_arguments		battlefield_files
#define move_arguments		battlefield_moves
