/* $Id: executing.c,v 1.32 1999/11/21 15:46:13 archer Exp $
 *	Commands execution module.
 */
#include "turn.h"
#include "battle.h"
#include "parser.h"
#include "command_u.h"
#include "command_e.h"


/**
 ** UNEXECUTABLE
 **	Default call for orders
 **/
int unexecutable(unit_s *unit, order_s *current)
{
#ifdef DYNAMICALLY_DEFINED_GAME
	printf("Unexecutable order %s for unit %s\n", current->executing.keyword, unit->id.text);
#endif
	current->considered = 1;
	return 0;
}


/**
 ** EXECUTING_RETREAT
 **	The unit is attempting to cancel the movement
 **/
int execute_retreat(unit_s *unit, order_s *current)
{
	unit_personal_event(unit, today_number, "Cannot RETREAT");
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_DISBAND
 **	The unit is attempting to vanish
 **/
int execute_disband(unit_s *unit, order_s *current)
{
experience_s	*exp;
/*
 * Must exist
 */
	if (unit->size == 0) {
		unit_personal_event(unit, today_number, "Already disbanded");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Add to local population
 */
	if (unit->true_location->type->optima)
		unit->true_location->population += unit->size;
	unit->size = 0;
	unit_personal_event(unit, today_number, "Disbands!");
	for (exp = unit->skilled; exp; exp = exp->next) {
		exp->points = 0;
		exp->effective = 0;
#ifdef USES_SKILL_LEVELS
		exp->level = 0;
#endif
	}
	unit->wages = 0;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_FATE
 **	The unit calls upon the GM
 **/
int execute_fate(unit_s *unit, order_s *current)
{
carry_s	*fate;
/*
 * Must either have a fate item, or have fate in cash
 */
	synthetic_tag("fate");
	fate = unit_possessions(unit, item_from_tag(0), 0);
	if ((!fate || !fate->amount ) && !unit->faction->fate_points)
		return 0;
	if (fate && fate->amount)
		fate->amount--;
	else
		unit->faction->fate_points--;
	printf("%s [%s] calls for FATE in %s [%s]!!!\n", unit->name, unit->id.text, unit->current->name, unit->current->id.text);
	unit_personal_event(unit, today_number, "Fate smiles on you!");
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_STAY
 **	Wants to remain in place
 **/
int execute_stay(unit_s *unit, order_s *current)
{
	unit->wants_stay = 1;
	current->considered = 1;
	return 0;
}


/**
 ** EXECUTING_UNSTACK
 **	The unit is attempting to leave the stack
 **/
int execute_unstack(unit_s *unit, order_s *current)
{
unit_s	*overall_leader;
/*
 * Valid condition?
 */
	if (unit->leader) {
		if (current) {
			if (current->executing.routine == execute_stay)
				sprintf(work, "%s [%s] stays in place", unit->name, unit->id.text);
			else
				sprintf(work, "%s [%s] unstacks", unit->name, unit->id.text);
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("%s executes %s\n", unit->id.text, current->executing.keyword);
#endif
		}
#ifdef TRACING_REQUIRED
		else
			if (unit->traced_unit)
				printf("%s auto-unstacks\n", unit->id.text);
#endif
/*
 * If no current order, the calling execute_xxx has already filled in some for us
 */
		unit_personal_event(unit, today_number, work);
		unit_personal_event(unit->leader, today_number, work);
		overall_leader = unit->leader;
		while (overall_leader->leader)
			overall_leader = overall_leader->leader;
		unstack_unit(unit);
		unit->next_location = overall_leader->next_location;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s copies leader %s->next_location (0x%x)\n", unit->id.text,overall_leader->id.text,(unsigned)unit->next_location);
#endif
		overall_leader->next_location = unit;
#ifdef TRACING_REQUIRED
		if (overall_leader->traced_unit)
			printf("%s->next_location is now %s (0x%x)\n", overall_leader->id.text,unit->id.text,(unsigned)unit);
#endif
	} else
		unit_personal_event(unit, today_number, "Already unstacked!");
	if (current)
		order_is_complete(unit, current);
	return 1;
}


/**
 ** UNSTACK_STAYS
 **	Unstack any unit that wants to stay in place. This is recursive
 **/
static void unstack_stays(unit_s *stack)
{
unit_s	*next;
order_s	*stay;
/*
 * Stacking is scanned depth-first, then breadth-first
 */
	while (stack) {
		next = stack->next_location;
/*
 * Unit wants to stay, it executes again STAY, but as UNSTACK
 */
		if (stack->wants_stay) {
			for (stay = stack->orders; stay; stay = stay->next)
				if (stay->considered && stay->executing.routine == execute_stay)
					break;
			if (stay)
				(void)execute_unstack(stack, stay);
		} else
			unstack_stays(stack->stack);
		stack = next;
	}
}


/**
 ** EXECUTING_COMBAT
 **	The unit changes its combat actions
 **/
int execute_combat(unit_s *unit, order_s *current)
{
combat_set_s	*c;
int		n;
/*
 * Validate arguments
 */
	c = unit->combat;
	for (n = 0; n < MAX_COMBAT_SETTING; n++) {
		if (current->executing.types[n] == 0)
			break;
		if (current->executing.types[n] == ARGUMENT_IS_COMBAT_OPTION) {
			c->option = current->arguments[n].number;
			c++;
			continue;
		}
		if (current->executing.types[n] == ARGUMENT_IS_SKILL_TAG) {
			c->u.use_skill = current->arguments[n].skill;
			if (!c->u.use_skill->combat_action.effect) {
				sprintf(work, "Skill %s isn't a combat action, skipped", c->u.use_skill->name);
				unit_personal_event(unit, today_number, work);
			} else {
				c->option = COMBAT_SET_SKILL;
				c++;
			}
			continue;
		}
		if (current->executing.types[n] == ARGUMENT_IS_ITEM_TAG) {
			c->u.use_item = current->arguments[n].item;
			if (!c->u.use_item->combat_action.effect) {
				sprintf(work, "Item %s cannot be used in combat, skipped", c->u.use_item->name);
				unit_personal_event(unit, today_number, work);
			} else {
				c->option = COMBAT_SET_ITEM;
				c++;
			}
			continue;
		}
	}
	if (c != unit->combat)
		unit_personal_event(unit, today_number, "Combat actions selected");
	else
		unit_personal_event(unit, today_number, "Default combat actions now used (melee, parry)");
	c->option = 0;
/*
 * Done
 */
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_SETTING
 **	The unit changes its settings
 **/
int execute_setting(unit_s *unit, order_s *current)
{
int	n;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_SETTING ||
	    current->executing.types[1] != ARGUMENT_IS_BOOLEAN) {
		unit_personal_event(unit, today_number, "Invalid SETTING order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Execute
 */
	n = current->arguments[1].number;
	switch (current->arguments[0].number) {
	    case 0: /* ADVERTISE */
		sprintf(work, "Advertise faction is now %s", n ? "true" : "false");
		unit->setting_advert = n;
		break;
	    case 1: /* ANNOUNCE */
		sprintf(work, "Announce presence is now %s", n ? "true" : "false");
		unit->setting_report = n;
		break;
	    case 2: /* HTML */
		printf("Panic: HTML used!\n");
		break;
	    case 3: /* MISER */
		sprintf(work, "Avoid fund use is now %s", n ? "true" : "false");
		unit->setting_miser = n;
		break;
	    case 4: /* SILENT */
		sprintf(work, "Silence on activities is now %s", n ? "true" : "false");
		unit->setting_silent = n;
		break;
	    case 5: /* SUPPORT */
		sprintf(work, "Prefer fund support is now %s", n ? "true" : "false");
		unit->setting_support = n;
		break;
	    case 6: /* TERSE */
		sprintf(work, "Short battle reports is now %s", n ? "true" : "false");
		unit->faction->setting_terse = n;
		break;
	    default:
		sprintf(work, "BEWARE! Incoherency within game engine");
		printf("%s!!!\n", work);
	}
	unit_personal_event(unit, today_number, work);
/*
 * Done
 */
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_STANCE
 **	The faction changes its stances
 **/
int execute_stance(unit_s *unit, order_s *current)
{
stance_s	*stance;
faction_s	*toward;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_STANCE ||
	    current->executing.types[1] != ARGUMENT_IS_FACTION_ID) {
		unit_personal_event(unit, today_number, "Invalid STANCE order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Special case?
 */
	if (unit->faction == (toward = current->arguments[1].faction)) {
		if (current->arguments[0].number == 5)
			unit_personal_event(unit, today_number, "Can't default the default stance");
		else {
			unit->faction->attitude = current->arguments[0].number;
			unit_personal_event(unit, today_number, "Default stance changed");
		}
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Other faction stance!
 */
	stance = find_stance_for(unit->faction, toward, 1);
	if (current->arguments[0].number == 5) {
		stance->attitude = -1;
		sprintf(work, "Attitude toward %s [%s] reverted to default", toward->name, toward->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		stance->attitude = current->arguments[0].number;
		sprintf(work, "Attitude toward %s [%s] specified", toward->name, toward->id.text);
		unit_personal_event(unit, today_number, work);
	}
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_TACTIC
 **	The unit is changing its tactics
 **/
int execute_tactic(unit_s *unit, order_s *current)
{
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_BATTLE ||
	    current->executing.types[1] != ARGUMENT_IS_RANK ||
	    current->executing.types[2] != ARGUMENT_IS_FILE ||
	    current->executing.types[3] != ARGUMENT_IS_MOVE) {
		unit_personal_event(unit, today_number, "Invalid TACTIC order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Just copy the settings
 */
	unit->participate = current->arguments[0].number;
	unit->rank = current->arguments[1].number;
	unit->file = current->arguments[2].number;
	unit->movement = current->arguments[3].number;
	unit_personal_event(unit, today_number, "New tactics selected");
	order_is_complete(unit, current);
	return 1;
}


/**
 ** GUARDED_AGAINST_ACTIVITY
 **	Is the location under guard by hostile units?
 **/
static int guarded_against_markets(unit_s *unit)
{
unit_s	*guards;
/*
 * Check now
 */
	if (!unit->true_location->guarded)
		return 0;
	for (guards = unit->true_location->present; guards; guards = guards->next_location)
		if (guards->is_guarding &&
		    attitude_vs_faction(guards->faction, unit->faction) > ATTITUDE_IS_NEUTRAL)
			return 1;
/*
 * No hostile guards
 */
	return 0;
}


/**
 ** EXECUTE_BUY
 **	Unit wants to buy.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed! Furthermore, buy occurs only
 ** during market day.
 **/
int execute_buy(unit_s *unit, order_s *current)
{
market_s	*possible;
request_s	*pending;
experience_s	*marketer;
int		price, amount;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid BUY order");
		order_is_complete(unit, current);
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Only leaders may BUY");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Occur on correct day
 */
	if (!unit->true_location->first_market)
		return 0;
	if (today_number % unit->true_location->market_days != 0)
		return 0;
/*
 * Validate elements
 */
	amount = current->arguments[0].number;
/*
 * Process a request only once
 */
	current->considered = 1;
	for (possible = unit->true_location->markets; possible; possible = possible->next)
		if (possible->type == current->arguments[1].item)
			break;
	if (!possible || !possible->offered.amount_remains) {
		marketer = unit_experiences(unit, marketing_skill, 0);
		if (!marketer || !marketer->effective)
			return 0;
		if (!possible)
			possible = new_market_at_location(unit->true_location, current->arguments[1].item);
	}
/*
 * Must be allowed
 */
	if (guarded_against_markets(unit)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent buying");
		return 0;
	}
/*
 * BUY is tentative...
 */
	if (unit->coins == 0)
		unit->coins = unit_possessions(unit, item_cash, 1);
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
		price = current->arguments[2].number;
	else
		price = 0;
	if (price <= 0)
		price = possible->offered.negociated_price;
	if (price <= 0)
	if (amount == 0)
		amount = unit->coins->amount / price;
	if (amount) {
		pending = new_request_instance();
		pending->validated_order = current;
		pending->asked = unit;
		pending->price = price;
		pending->amount = amount;
		pending->next = possible->offered.shopping;
		possible->offered.shopping = pending;
		unit->has_recruited = 1;
	}
/*
 * Offer recorded
 */
	return 1;
}


/**
 ** EXECUTE_SELL
 **	Unit wants to sell.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed! Furthermore, sell occurs only
 ** during market day.
 **/
int execute_sell(unit_s *unit, order_s *current)
{
market_s	*possible;
request_s	*pending;
carry_s		*owns;
experience_s	*marketer;
int		price, amount;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid SELL order");
		order_is_complete(unit, current);
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Only leaders may SELL");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Occur on correct day
 */
	if (!unit->true_location->first_market)
		return 0;
	if (today_number % unit->true_location->market_days != 0)
		return 0;
	owns = unit_possessions(unit, current->arguments[1].item, 0);
	if (!owns || owns->amount == 0)
		return 0;
/*
 * Must be allowed
 */
	current->considered = 1;
	if (guarded_against_markets(unit)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent selling");
		return 0;
	}
/*
 * Validate elements
 */
	amount = current->arguments[0].number;
	if (!amount)
		amount = owns->amount;
/*
 * Process a request only once
 */
	for (possible = unit->true_location->markets; possible; possible = possible->next)
		if (possible->type == current->arguments[1].item)
			break;
	if (!possible || !possible->wanted.amount_remains) {
		marketer = unit_experiences(unit, marketing_skill, 0);
		if (!marketer || !marketer->effective)
			return 0;
		if (!possible)
			possible = new_market_at_location(unit->true_location, current->arguments[1].item);
	}
/*
 * BUY is tentative...
 */
	if (unit->coins == 0)
		unit->coins = unit_possessions(unit, item_cash, 1);
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
		price = current->arguments[2].number;
	else
		price = 0;
	if (price <= 0)
		price = possible->wanted.negociated_price;
	if (price <= 0)
		price = 9999999;
	if (amount == 0)
		amount = unit->coins->amount / price;
	if (amount) {
		pending = new_request_instance();
		pending->validated_order = current;
		pending->asked = unit;
		pending->price = price;
		pending->amount = amount;
		pending->next = possible->wanted.shopping;
		possible->wanted.shopping = pending;
		unit->has_recruited = 1;
	}
/*
 * Offer recorded
 */
	return 1;
}


/**
 ** EXECUTE_RECRUIT
 **	Unit wants to recruit. Only leaders do that.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed!
 **/
int execute_recruit(unit_s *unit, order_s *current)
{
recruit_s	*possible;
request_s	*pending;
race_s		*race;
int		price, amount;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order, wrong unit ID");
		order_is_complete(unit, current);
		return 1;
	}
	if (current->executing.types[1] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order, missing amount");
		order_is_complete(unit, current);
		return 1;
	}
	if (current->executing.types[2] != ARGUMENT_IS_RACE_TAG) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order, missing race tag");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Validate racials
 */
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Only leaders may recruit");
		order_is_complete(unit, current);
		return 1;
	}
	race = current->arguments[2].race;
	amount = current->arguments[1].number;
	if (race->type == RACE_LEADER) {
		if (amount > 1 || current->arguments[0].unit->size) {
			unit_personal_event(unit, today_number, "Only 1 leader at a time per unit");
			order_is_complete(unit, current);
			return 1;
		} else
			amount = 1;
	}
/*
 * If recruiting within an existing unit...
 */
	if (current->arguments[0].unit->race && current->arguments[0].unit->race != race) {
		unit_personal_event(unit, today_number, "Racial mismatch");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Must be allowed
 */
	current->considered = 1;
	if (guarded_against_markets(unit)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent recruitment");
		return 0;
	}
/*
 * Process a request only once
 */
	for (possible = unit->true_location->opportunity; possible; possible = possible->next)
		if (possible->type == current->arguments[2].race &&
		    possible->amount != 0) {
			if (unit->coins == 0)
				unit->coins = unit_possessions(unit, item_cash, 1);
			if (current->executing.types[3] != ARGUMENT_IS_NUMBER)
				price = 0;
			else
				price = current->arguments[3].number;
			if (price <= 0)
				price = possible->price;
			if (price < possible->price)
				return 0;
			if (amount == 0)
				amount = unit->coins->amount / price;
			if (amount) {
#ifdef TRACING_REQUIRED
				if (unit->traced_unit)
					printf("%s: Recruit pending %d %s @ $%d\n",unit->name,
						amount, possible->type->name, price);
#endif
				pending = new_request_instance();
				pending->validated_order = current;
				pending->asked = unit;
				pending->price = price;
				pending->amount = amount;
				pending->next = possible->wanted;
				possible->wanted = pending;
				unit->has_recruited = 1;
			}
			return 1;
		}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s tries to recruit %s (not here)\n", unit->name, current->arguments[2].race->name);
#endif
	return 1;
}


/**
 ** EXECUTING_SWAP
 **	The units want a secure trade
 **/
int execute_swap(unit_s *unit, order_s *current)
{
order_s	*order;
unit_s	*target;
item_s	*giving, *getting;
carry_s	*mine, *yours, *hand;
int	given, expected;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[1] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[2] != ARGUMENT_IS_ITEM_TAG ||
	    current->executing.types[3] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[4] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid SWAP order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (target == unit) {
		unit_personal_event(unit, today_number, "Can't swap with yourself");
		order_is_complete(unit, current);
		return 1;
	}
	if (target->inactive || target->dead)
		return 0;
	if (unit->faction != target->faction && !may_interact_with(unit, target))
		return 0;
	given  = current->arguments[1].number;
	giving = current->arguments[2].item;
	expected = current->arguments[3].number;
	getting  = current->arguments[4].item;
/*
 * Both must have the items!
 */
	mine = unit_possessions(unit, giving, 0);
	if (!mine || mine->amount < given)
		return 0;
	yours = unit_possessions(target, getting, 0);
	if (!yours || yours->amount < expected)
		return 0;
/*
 * Find out if the target has the reciprocal order
 */
	for (order = target->orders; order; order = order->next)
		if (order->executing.routine == execute_swap &&
		    !order->conditional &&
		    (!order->limited || order->limited == today_number) &&
		    order->executing.types[0] == ARGUMENT_IS_UNIT_ID &&
		    order->arguments[0].unit == unit &&
		    order->executing.types[1] == ARGUMENT_IS_NUMBER &&
		    order->arguments[1].number == expected &&
		    order->executing.types[2] == ARGUMENT_IS_ITEM_TAG &&
		    order->arguments[2].item == getting &&
		    order->executing.types[3] == ARGUMENT_IS_NUMBER &&
		    order->arguments[3].number == given &&
		    order->executing.types[4] == ARGUMENT_IS_ITEM_TAG &&
		    order->arguments[4].item == giving)
			break;
	if (!order)
		return 0;
/*
 * We do swap!
 */
	sprintf(work, "Swapped %d %s for %d %s", given, given > 1 ? giving->plural : giving->name,
					expected, expected > 1 ? getting->plural : getting->name);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	hand = unit_possessions(target, giving, 1);
	hand->amount += given;
	mine->amount -= given;
	hand = unit_possessions(unit, getting, 1);
	hand->amount += expected;
	yours->amount -= expected;
/*
 * Did we swap equipment?
 */
	if (mine->equipped > mine->amount) {
		mine->equipped = mine->amount;
		compute_unit_stats(unit);
	}
	if (yours->equipped > yours->amount) {
		yours->equipped = yours->amount;
		compute_unit_stats(target);
	}
/*
 * The other unit also executes!
 */
	order_was_executed(unit, current);
	order_was_executed(target, order);
	return 1;
}


/**
 ** EXECUTE_GET
 **	Unit gives something to another unit. Both must be at the same location
 ** and the other must treat the first as friendly.
 **/
int execute_get(unit_s *unit, order_s *current)
{
unit_s	*recipient;
carry_s	*items;
carry_s	*handed;
item_s	*type;
int	given, kept;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid GET order");
		order_is_complete(unit, current);
		return 1;
	}
	recipient = current->arguments[0].unit;
/*
 * Interaction
 */
	if (!may_interact_with(unit, recipient))
		return 0;
	if (recipient->faction && recipient->faction != unit->faction) {
		unit_personal_event(unit, today_number, "GET is allowed only within same faction");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Validate item amounts
 */
	type = current->arguments[1].item;
	items = unit_possessions(recipient, type, 0);
	if (!items)
		return 0;
	kept = 0;
	given = 0;
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER) {
		given = current->arguments[2].number;
		if (current->executing.types[3] == ARGUMENT_IS_NUMBER)
			kept = current->arguments[3].number;
	}
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given > items->amount)
		return 0;
	current->considered = 1;
/*
 * Carrying
 */
	handed = unit_possessions(unit, type, 1);
	items->amount -= given;
	if (type == item_mana)
		given = 0;
	handed->amount += given;
	if (given > 0 && !unit->setting_silent) {
		sprintf(work, "Getting %d %s [%s] from %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
	}
	if (!recipient->setting_silent) {
		sprintf(work, "Handed %d %s [%s] to %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
	}
	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(recipient);
	}
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_DROP
 **	Unit gives drops something (gives to a stockpile).
 **/
int execute_drop(unit_s *unit, order_s *current)
{
unit_s	*recipient;
carry_s	*items;
carry_s	*handed;
item_s	*type;
int	given, kept;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid DROP order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Validate item amounts
 */
	type = current->arguments[0].item;
	items = unit_possessions(unit, type, 0);
	if (!items)
		return 0;
	kept = 0;
	given = 0;
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER) {
		given = current->arguments[2].number;
		if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
			kept = current->arguments[2].number;
	}
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given > items->amount)
		return 0;
	current->considered = 1;
/*
 * Carrying
 */
	items->amount -= given;
	if (type == item_mana)
		given = 0;
	if (!unit->setting_silent) {
		sprintf(work, "Dropping %d %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text);
		unit_personal_event(unit, today_number, work);
	}
/*
 * Find a stockpile. Failing that, create one.
 */
	for (recipient = unit->current->present; recipient; recipient = recipient->next_location)
		if (recipient->size == 0)
			break;
	if (!recipient) {
		memset(&tag_token, 0, sizeof(tag_token));
		strcpy(tag_token.text, "*EMPTY*");
		recipient = unit_from_id(1);
		assign_unit_id(recipient);
		move_to_location(recipient, unit->current);
	}
	recipient->inactive = 0;
	recipient->dead = 0;
/*
 * Put items in the stockpile
 */
	handed = unit_possessions(recipient, type, 1);
	handed->amount += given;
	if (given && !recipient->setting_silent && recipient->faction) {
		sprintf(work, "Received %d %s [%s] from %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
	}
	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(unit);
	}
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_GIVE
 **	Unit gives something to another unit. Both must be at the same location
 ** and the other must treat the first as friendly.
 **/
int execute_give(unit_s *unit, order_s *current)
{
unit_s	*recipient;
carry_s	*items;
carry_s	*handed;
item_s	*type;
int	given, kept;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid GIVE order");
		order_is_complete(unit, current);
		return 1;
	}
	recipient = current->arguments[0].unit;
	if (!may_interact_with(unit, recipient))
		return 0;
/*
 * Validate item amounts
 */
	type = current->arguments[1].item;
	items = unit_possessions(unit, type, 0);
	if (!items)
		return 0;
	kept = 0;
	given = 0;
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER) {
		given = current->arguments[2].number;
		if (current->executing.types[3] == ARGUMENT_IS_NUMBER)
			kept = current->arguments[3].number;
	}
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given+kept > items->amount)
		return 0;
	current->considered = 1;
	if (attitude_vs(recipient->faction, unit) > 2) {
		sprintf(work, "%s [%s] does not accept gifts", recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "Refused gifts from %s [%s]", unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Carrying
 */
	handed = unit_possessions(recipient, type, 1);
	items->amount -= given;
	if (type == item_mana)
		given = 0;
	if (!unit->setting_silent) {
		sprintf(work, "Giving %d %s [%s] to %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
	}
	handed->amount += given;
	if (given && !recipient->setting_silent) {
		sprintf(work, "Received %d %s [%s] from %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
	}
	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(unit);
	}
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_WITHDRAW
 **	Withdraw from faction fund.
 **/
int execute_withdraw(unit_s *unit, order_s *current)
{
carry_s	*cash;
int	amount;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid WITHDRAW order");
		order_is_complete(unit, current);
		return 1;
	}
	if (unit->true_location->type != terrain_city && strcmp(unit->current->type->tag.text, "bank")) {
		current->considered = 1;
		return 0;
	}
	amount = current->arguments[0].number;
	if (amount == 0)
		return 0;
	if (amount < 0) {
		if (strcmp(unit->current->type->tag.text, "bank")) {
			unit_personal_event(unit, today_number, "Invalid WITHDRAW order; negative disallowed");
			order_is_complete(unit, current);
			return 1;
		}
		if ((cash = unit->coins) == 0)
			unit->coins = cash = unit_possessions(unit, item_cash, 1);
		if (cash->amount + amount < 0)
			return 0;
	} else
		if (amount > unit->faction->faction_fund) {
			sprintf(work, "$%d exceeds faction funds ($%d)", amount, unit->faction->faction_fund);
			unit_personal_event(unit, today_number, work);
			order_is_complete(unit, current);
			return 1;
		}
/*
 * Carrying
 */
	if ((cash = unit->coins) == 0)
		unit->coins = cash = unit_possessions(unit, item_cash, 1);
	cash->amount += amount;
	if (amount < 0) {
		amount -= amount / 5;
		sprintf(work, "Saving %d coins in %s [%s]", amount,
				unit->current->name, unit->current->id.text);
	} else
		sprintf(work, "Withdrawing %d coins in %s [%s]", amount,
			unit->true_location->name, unit->true_location->id.text);
	unit->faction->faction_fund -= amount;
	unit_personal_event(unit, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_HAVE
 **	Wait for the items
 **/
int execute_have(unit_s *unit, order_s *current)
{
carry_s	*has;
int	amount;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid HAVE order");
		order_is_complete(unit, current);
		return 1;
	}
	current->considered = 1;
/*
 * Amount?
 */
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		amount = current->arguments[1].number;
	else
		amount = 1;
	if (amount <= 0)
		amount = 1;
/*
 * Owns?
 */
	if ((has = unit_possessions(unit, current->arguments[0].item, 0)) == 0 ||
	    has->amount < amount)
		return 0;
	current->considered = 1;
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SKILL
 **	The unit checks its skill advance
 **/
int execute_skill(unit_s *unit, order_s *current)
{
experience_s	*exp;
#ifdef USES_SKILL_LEVELS
int		amount;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG ||
	    current->executing.types[1] != ARGUMENT_IS_NUMBER) {
#else
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
#endif
		unit_personal_event(unit, today_number, "Invalid SKILL order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must have the skill
 */
	if ((exp = unit_experiences(unit, current->arguments[0].skill, 0)) == 0 || exp->points == 0)
		return 0;
#ifdef USES_SKILL_LEVELS
	amount = current->arguments[1].number;
	if (current->executing.types[2] == ARGUMENT_IS_STRING &&
	    strcasecmp(current->arguments[2].string, "days") == 0) {
		amount *= SKILL_POINTS_PER_DAY;
		amount *= unit->size;
		if (amount > exp->points)
			return 0;
	} else {
		if (exp->level < amount)
			return 0;
	}
#else
	if (exp->effective == 0)
		return 0;
#endif
/*
 * We do have the required skill
 */
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SYNCHRO
 **	The unit waits the other one to catch up
 **/
int execute_synchro(unit_s *unit, order_s *current)
{
unit_s	*target;
order_s	*order;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid SYNCHRO order; missing unit ID");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (target == unit) {
		if (!unit->setting_silent)
			unit_personal_event(unit, today_number, "Self-synchronise");
		order_was_executed(unit, current);
		return 1;
	}
	if (target->inactive || target->dead)
		return 0;
	if (unit->faction != target->faction && !may_interact_with(unit, target))
		return 0;
/*
 * Find out if the target has the reciprocal order
 */
	for (order = target->orders; order; order = order->next)
		if (order->executing.routine == execute_synchro &&
		    !order->conditional &&
		    (!order->limited || order->limited == today_number) &&
		    order->executing.types[0] == ARGUMENT_IS_UNIT_ID &&
		    order->arguments[0].unit == unit &&
		    order->executing.types[1] == current->executing.types[1] &&
		    (current->executing.types[1] != ARGUMENT_IS_NUMBER || order->arguments[1].number == current->arguments[1].number) )
			break;
	if (!order)
		return 0;
/*
 * We do synchronise
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit || target->traced_unit)
		printf("Synchro between %s (%s) and %s (%s) occurs\n", unit->id.text, unit->name, target->id.text, target->name);
#endif
	if (!unit->setting_silent) {
		sprintf(work, "Synchronise with %s [%s]", target->name, target->id.text);
		if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
			sprintf(work+strlen(work), ", ID %d", current->arguments[1].number);
		unit_personal_event(unit, today_number, work);
	}
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
/*
 * The other unit also executes!
 */
	if (!target->setting_silent) {
		sprintf(work, "Synchronise with %s [%s]", unit->name, unit->id.text);
		if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
			sprintf(work+strlen(work), ", ID %d", current->arguments[1].number);
		unit_personal_event(target, today_number, work);
	}
	order_was_executed(target, order);
	return 1;
}


/**
 ** EXECUTING_ACCEPT
 **	The unit accepts someone
 **/
int execute_accept(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid ACCEPT order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (target->faction == unit->faction) {
		unit_personal_event(unit, today_number, "Accept ignored within the same faction");
		order_is_complete(unit, current);
		return 1;
	}
	if (!may_interact_with(unit, target))
		return 0;
	current->considered = 1;
	return 1;
}


/**
 ** EXECUTING_CAPACITY
 **	The unit must have a specific capacity
 **/
int execute_capacity(unit_s *unit, order_s *current)
{
int	mode;
int	capacity;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_STRING ||
	    (mode = parsed_enum(current->arguments[0].string, movement_modes)) < 0) {
		unit_personal_event(unit, today_number, "Invalid CAPACITY order; bad movement mode");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Check capacity
 */
	compute_stack_capacity(unit);
	capacity = unit->stack_weight;
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		capacity += current->arguments[1].number;
/*
 * Simplest check
 */
	if (unit->stack_capacity[mode] > capacity)
		return 0;
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SIZE
 **	The unit must have a specific size
 **/
int execute_size(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid SIZE order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Simplest check
 */
	if (unit->size < current->arguments[0].number)
		return 0;
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_ID
 **	The unit must have ID X
 **/
int execute_id(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid ID order; wrong unit id");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must have unit equal to argument. If it isn't true now, it never will
 * today.
 */
	current->considered = 1;
	if (unit != current->arguments[0].unit)
		return 0;
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_LEADER
 **	The unit must be led by X (at any level)
 **/
int execute_leader(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*leader;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid LEADER order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must have the target in the leader links
 */
	target = current->arguments[0].unit;
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader == target)
			break;
	if (leader == 0)
		return 0;
/*
 * True
 */
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** HAS_FOLLOWER
 **	Check for follower presence in stack
 **/
static int has_follower(unit_s *follower, unit_s *target)
{
	while (follower) {
		if (follower == target)
			return 1;
		if (has_follower(follower->stack, target))
			return 1;
		follower = follower->next_location;
	}
	return 0;
}


/**
 ** EXECUTING_LEADING
 **	The unit must have X as a follower
 **/
int execute_leading(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*follower;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid LEADING order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must have the target in the stack list
 */
	target = current->arguments[0].unit;
	if (!has_follower(unit->stack, target))
		return 0;
/*
 * True
 */
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SEE
 **	The unit looks around for someone
 **/
int execute_see(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid SEE order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
	if (!unit->setting_silent) {
		sprintf(work, "Saw %s [%s]", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	}
	if (current->days < 0)
		current->days = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_OATH
 **	The unit wants to follows another's rule
 **/
int execute_oath(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid OATH order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
/*
 * Unit is now loyal to...
 */
	sprintf(work, "Oathed to %s [%s]", target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit->now_loyal = target->faction;
	sprintf(work, "%s [%s] declared its loyalty to your cause", unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_AT
 **	Wait for the location
 **/
int execute_at(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid AT order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Valid
 */
	current->considered = 1;
	if (unit->current == current->arguments[0].location) {
		if (current->days < 0)
			current->days = 0;
		order_was_executed(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTING_DAY
 **	Wait for the specific day of the month
 **/
int execute_day(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid DAY order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Valid
 */
	current->considered = 1;
	if (today_number == current->arguments[0].number) {
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTING_EQUIP
 **	The unit puts some equipment around
 **/
int execute_equip(unit_s *unit, order_s *current)
{
experience_s	*requirement;
carry_s		*owns, *others;
item_s		*item;
int		amount;
int		max;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid EQUIP order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Find out about the items
 */
	item = current->arguments[0].item;
	if (!item->equip_category) {
		sprintf(work, "It is impossible to equip %s [%s]\n", item->name, item->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Skill requirement?
 */
	if (item->equip_skill) {
		requirement = unit_experiences(unit, item->equip_skill, 0);
		if (!requirement || requirement->points == 0 || requirement->level < item->equip_level)
			return 0;
	}
/*
 * How many items
 */
	owns = unit_possessions(unit, item, 0);
	if (!owns || owns->amount == 0)
		return 0;
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		amount = current->arguments[1].number;
	else
		amount = owns->amount;
	if (amount > owns->amount)
		return 0;
/*
 * Disequip!
 */
	if (amount <= owns->equipped) {
		max = owns->equipped - amount;
		if (max) {
			sprintf(work, "Unequipped %d %s [%s]", max, max > 1 ? item->plural : item->name, item->tag.text);
			unit_personal_event(unit, today_number, work);
			owns->equipped = amount;
		}
		order_was_executed(unit, current);
		return 1;
	}
/*
 * Increase equipment amount... Check maximas
 */
	max = unit->size * item->equip_maximum;
	for (others = unit->carrying; others; others = others->next)
		if (others != owns && others->equipped && others->item->equip_category == item->equip_category) {
			if (others->item->equip_requires > 1)
				max -= others->equipped * others->item->equip_requires;
			else
				max -= others->equipped;
		}
	if (max > unit->size)
		max = unit->size;
	if (item->equip_requires > 1)
		max /= item->equip_requires;
	if (amount > max)
		amount = max;
	if (amount < 0)
		amount = 0;
/*
 * Equipment change
 */
	if (amount != owns->equipped) {
		sprintf(work, "Now equipped %d %s [%s]", amount, amount > 1 ? item->plural : item->name, item->tag.text);
		unit_personal_event(unit, today_number, work);
		owns->equipped = amount;
/*
 * Combat items become the default action
 */
#ifdef ITEMS_USED_IN_BATTLE
		if (item->combat_action.effect && unit->combat[0].option == 0) {
			unit->combat[0].option = COMBAT_SET_ITEM;
			unit->combat[0].u.use_item = item;
			unit->combat[1].option = 0;
		}
#endif
		order_was_executed(unit, current);
	} else
		current->considered = 1;
	return 1;
}


/**
 ** EXECUTING_SPLIT
 **	The unit is attempting to split in differing parts
 **/
int execute_split(unit_s *unit, order_s *current)
{
unit_s		*created;
experience_s	*original,
		*split;
carry_s		*held,
		*handed;
long		quantity;
int		amount, size;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_UNIT_ID ||
	    !(created = current->arguments[1].unit)->inactive ||
	    (created->faction && created->faction != unit->faction) ||
	    created->dead) {
		unit_personal_event(unit, today_number, "Invalid SPLIT order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Yup. Maybe we can do.
 */
	if ((amount = current->arguments[0].number) <= 0)
		amount = 1;
	if ((size = unit->size) <= amount)
		return 0;
/*
 * Huly gee! We can split! Activate that unit *now*
 */
	created->race = unit->race;
	created->size = amount;
	unit->size -= amount;
	assign_unit_id(created);
/*
 * Unit is located just after this one
 */
	created->next_location = unit->next_location;
	unit->next_location = created;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("inserted split 0x%x as %s->next_location",(unsigned)created,unit->id.text);
#endif
	created->leader = unit->leader;
	created->current = unit->current;
	created->true_location = unit->true_location;
	created->faction = unit->faction;
	created->same_faction = unit->faction->units;
	unit->faction->units = created;
/*
 * Split experience points
 */
	for (original = unit->skilled; original; original = original->next) {
		if (original->points == 0)
			continue;
		split = unit_experiences(created, original->skill, 1);
		quantity = fractional(original->points, amount, size);
		original->points -= quantity;
		split->points += quantity;
		split->effective = original->effective;
#ifdef USES_SKILL_LEVELS
		split->level = original->level;
#endif
	}
/*
 * Hand off equipment
 */
	for (held = unit->carrying; held; held = held->next) {
		switch (held->item->item_type) {
		    case ITEM_DAYS:
			handed = unit_possessions(created, held->item, 1);
			handed->amount = held->amount;
			created->has_effects = 1;
			break;
		    case ITEM_TOKEN:
			handed = unit_possessions(created, held->item, 1);
			quantity = fractional(held->amount, amount, size);
			held->amount -= quantity;
			handed->amount += quantity;
			break;
		    case ITEM_ITEM:
		    case ITEM_EFFECT:
			if (held->equipped > unit->size) {
				quantity = held->equipped - unit->size;
				handed = unit_possessions(created, held->item, 1);
				held->amount -= quantity;
				held->equipped -= quantity;
				handed->amount += quantity;
				handed->equipped += quantity;
			}
			break;
		}
	}
/*
 * Recompute stats?
 */
	compute_unit_stats(unit);
	compute_unit_stats(created);
	created->inactive = 0;
	sprintf(work, "Created Unit [%s] using %d %s", created->id.text, amount,
			amount > 1 ? unit->race->plural : unit->race->name);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "Created by %s [%s]", unit->name, unit->id.text);
	unit_personal_event(created, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_MERGE
 **	The unit is attempting to merge into another unit
 **/
int execute_merge(unit_s *unit, order_s *current)
{
unit_s		*created;
experience_s	*original,
		*split;
carry_s		*held,
		*handed;
long		quantity;
int		amount, size;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid MERGE order; bad number of figures");
		order_is_complete(unit, current);
		return 1;
	}
	if (current->executing.types[1] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid MERGE order; invalid unit ID");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Fall-back case
 */
	if ((created = current->arguments[1].unit)->inactive)
		return 0;
	if (created->true_location != unit->true_location)
		return 0;
	if (created->race && created->race != unit->race) {
		unit_personal_event(unit, today_number, "Unit being merged to must be of same race");
		order_is_complete(unit, current);
		return 1;
	}
	if (created->faction && created->faction != unit->faction) {
		unit_personal_event(unit, today_number, "Merge only into stockpiles or same faction units");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Yup. Maybe we can do it.
 */
	size = unit->size;
	if ((amount = current->arguments[0].number) <= 0)
		amount = size;
	if (amount > size)
		return 0;
/*
 * Huly gee! We can merge!
 */
	created->race = unit->race;
	created->size += amount;
	unit->size -= amount;
/*
 * Unit is now of the same faction
 */
	if (!created->faction) {
		created->faction = unit->faction;
		created->same_faction = unit->faction->units;
		unit->faction->units = created;
	}
/*
 * Split experience points
 */
	for (original = unit->skilled; original; original = original->next) {
		if (original->points == 0)
			continue;
		split = unit_experiences(created, original->skill, 1);
		quantity = fractional(original->points, amount, size);
		original->points -= quantity;
		split->points += quantity;
	}
	for (split = created->skilled; split; split = split->next)
		adjust_experience(split, created->size);
/*
 * Hand off equipment only if merge 0.
 */
	if (current->arguments[0].number == 0)
		for (held = unit->carrying; held; held = held->next)
			if (held->item->item_type == ITEM_ITEM) {
				handed = unit_possessions(created, held->item, 1);
				handed->amount += held->amount;
				held->amount = 0;
				held->equipped = 0;
			}
/*
 * Unit falls down to 0, loses all its experiences!
 */
	if (unit->size == 0) {
		free_experience_instance(unit->skilled);
		unit->skilled = 0;
		unit->executing = 0;
	}
/*
 * Recompute stats?
 */
	compute_unit_stats(unit);
	compute_unit_stats(created);
	sprintf(work, "Merged %d %s into %s [%s]",
			amount, amount > 1 ? unit->race->plural : unit->race->name,
			created->name, created->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "Merged %d %s from %s [%s]",
			amount, amount > 1 ? unit->race->plural : unit->race->name,
			unit->name, unit->id.text);
	unit_personal_event(created, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_PROMOTE
 **	The unit is attempting to promot someone
 **/
int execute_promote(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*prior, *scan;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid PROMOTE order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same stack level and at the same location!
 */
	target = current->arguments[0].unit;
	if (target->current != unit->current ||
	    target->leader != unit->leader)
		return 0;
/*
 * Stealth intervenes: we have to see the promoted unit
 */
#ifdef STEALTH_STATS
	if (!target->setting_report)
		if (unit->vital.observation < target->effective_stealth)
			return 0;
#endif
/*
 * Furthermore, the next unit must be following us
 */
	prior = unit;
	for (scan = unit->next_location; scan; scan = scan->next_location)
		if (scan == target)
			break;
		else
			prior = scan;
	if (!scan)
		return 0;
/*
 * We do promote!
 */
	prior->next_location = target->next_location;
#ifdef TRACING_REQUIRED
	if (prior->traced_unit)
		printf("dropping unit %s from %s->next_location (now 0x%x)\n", target->id.text, prior->id.text, (unsigned)prior->next_location);
#endif
	prior = 0;
	if (unit->leader)
		scan = unit->leader->stack;
	else
		scan = unit->current->present;
	while (scan)
		if (scan == unit)
			break;
		else {
			prior = scan;
			scan = scan->next_location;
		}
/*
 * Impossibility
 */
	if (!scan)
		abort();
	if (prior) {
		prior->next_location = target;
#ifdef TRACING_REQUIRED
		if (prior->traced_unit)
			printf("inserted unit %s at %s->next_location (now 0x%x)\n", target->id.text, prior->id.text, (unsigned)prior->next_location);
#endif
	} else
		if (unit->leader)
			unit->leader->stack = target;
		else
			unit->current->present = target;
	target->next_location = unit;
#ifdef TRACING_REQUIRED
	if (target->traced_unit)
		printf("unit %s now precedes unit %s\n", target->id.text, unit->id.text);
#endif
/*
 * Report promotion
 */
	sprintf(work, "%s [%s] promotes %s [%s]", unit->name, unit->id.text,
				target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EJECT_UNIT
 **	Sub-routine for ejection
 **/
static void eject_unit(unit_s *unit, unit_s *target)
{
/*
 * Ejection proceeeds
 */
	sprintf(work, "%s [%s] is no longer welcome in stack", target->name, target->id.text);
	(void)execute_unstack(target, 0);
	if (unit->leader) {
		stack_under(unit->leader, target);
		sprintf(work, "%s [%s] is now stacked under your leadership", target->name, target->id.text);
		unit_personal_event(unit->leader, today_number, work);
	}
}


/**
 ** EXECUTING_EJECT
 **	We throw out the unit
 **/
int execute_eject(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Valid condition?
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		while (unit->stack)
			eject_unit(unit, unit->stack);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * We want to eject someone from out stack!
 */
	target = current->arguments[0].unit;
	if (target == unit) {
		unit_personal_event(unit, today_number, "Invalid EJECT; cannot eject self");
		order_is_complete(unit, current);
		return 1;
	}
	if (target->leader == unit) {
		eject_unit(unit, target);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * That someone is located in a structure we are owner and it is not
 * the title holder!
 */
	if (target->current == target->true_location)
		return 0;
	if (target->current->present == unit) {
		if (target->title == target->current)
			unit_personal_event(unit, today_number, "Invalide EJECT; cannot eject title owner");
		else {
			sprintf(work, "%s [%s] expells you", unit->name, unit->id.text);
			unit_personal_event(target, today_number, work);
			execute_leave(target, 0);
		}
		order_is_complete(unit, current);
		return 1;
	}
/*
 * That someone is located in a structure and we are the title owner
 */
	if (unit->title == target->current && unit->true_location == target->true_location) {
		sprintf(work, "%s [%s] expells you", unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		execute_leave(target, 0);
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTING_STACK
 **	The unit is attempting to enter the stack
 **/
int execute_stack(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*leader;
order_s	*accepting;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID)
		return execute_unstack(unit, current);
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
	if (unit->leader == target) {
		sprintf(work, "Already stacked under %s [%s]'s leadership", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * If new leader is already stacked beneath us, unstack the leader first!
 */
	for (leader = target->leader; leader; leader = leader->leader)
		if (leader == unit)
			break;
	if (leader) {
		sprintf(work, "%s [%s] unstacks to allow stack swapping", target->name, target->id.text);
		(void)execute_unstack(target, 0);
	}
/*
 * The leader must accept us
 */
	if (target->faction != unit->faction) {
		if (attitude_vs(target->faction, unit) > ATTITUDE_IS_FRIEND) {
			for (accepting = target->orders; accepting; accepting = accepting->next)
				if (accepting->executing.routine == execute_accept &&
				    !accepting->conditional && accepting->arguments[0].unit == unit)
					break;
			if (!accepting) {
				sprintf(work, "%s [%s] tried to stack beneath you!", unit->name, unit->id.text);
				unit_personal_event(target, today_number, work);
				sprintf(work, "%s [%s] will not lead you", target->name, target->id.text);
				unit_personal_event(unit, today_number, work);
				order_was_executed(unit, current);
				return 1;
			}
			order_is_complete(target, accepting);
		}
	}
/*
 * Unstack first
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s executes STACK %s\n", unit->id.text, target->id.text);
#endif
	if (unit->leader) {
		sprintf(work, "%s [%s] first unstacks", unit->name, unit->id.text);
		(void)execute_unstack(unit, 0);
	}
	stack_under(target, unit);
	sprintf(work, "%s [%s] stacks under %s [%s]", unit->name, unit->id.text,
				target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_LEAVE
 **	The unit is attempting to get out of the location
 **/
int execute_leave(unit_s *unit, order_s *current)
{
	if (unit->current->type->type == TERRAIN_STRUCTURE) {
		if (current)
			current->considered = 1;
		unstack_stays(unit->stack);
		sprintf(work, "%s [%s] leaves %s [%s]", unit->name, unit->id.text,
					unit->current->name, unit->current->id.text);
		unit_personal_event(unit, today_number, work);
		location_global_event(unit, today_number, work);
		move_to_location(unit, unit->current->outer);
		if (current)
			order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTING_ENTER
 **	The unit is attempting to move into a location.
 **/
int execute_enter(unit_s *unit, order_s *current)
{
location_s	*entering;
direction_s	*direction;
unit_s		*guard;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid ENTER order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Special case: "enter" outward location
 */
	if (unit->true_location == current->arguments[0].location &&
	    unit->true_location != unit->current)
		return execute_leave(unit, current);
/*
 * Search thru inner locations
 */
	for (entering = unit->true_location->inner; entering; entering = entering->next_inner)
		if (entering == current->arguments[0].location &&
		    entering->type->type == TERRAIN_STRUCTURE) {
			current->considered = 1;
			if (entering->partial)
				return 0;
/*
 * Guards may prevent entering, unless you are the holder of the title!
 */
			if (unit->title != entering)
				if ((guard = entering->present) && attitude_vs_faction(guard->faction, unit->faction) > ATTITUDE_IS_NEUTRAL) {
					sprintf(work, "%s [%s] prevents you from entering %s [%s]", guard->name, guard->id.text,
							entering->name, entering->id.text);
					unit_personal_event(unit, today_number, work);
					sprintf(work, "%s [%s] attempted to enter", unit->name, unit->id.text);
					unit_personal_event(guard, today_number, work);
					order_is_complete(unit, current);
					return 1;
				}
/*
 * Enter occurs
 */
			unstack_stays(unit->stack);
			sprintf(work, "%s [%s] enters %s [%s]", unit->name, unit->id.text,
					entering->name, entering->id.text);
			unit_personal_event(unit, today_number, work);
			location_global_event(unit, today_number, work);
			move_to_location(unit, entering);
			order_is_complete(unit, current);
			return 1;
		}
/*
 * Special 0-day movement
 */
	for (direction = unit->true_location->exits; direction; direction = direction->next)
		if (direction->days == 0 &&
		    direction->toward == current->arguments[0].location) {
			current->considered = 1;
			sprintf(work, "%s [%s] departs", unit->name, unit->id.text);
			location_global_event(unit, today_number, work);
			move_to_location(unit, direction->toward);
			sprintf(work, "%s [%s] arrives at %s [%s]", unit->name, unit->id.text,
					direction->toward->name, direction->toward->id.text);
			unit_personal_event(unit, today_number, work);
			location_global_event(unit, today_number, work);
			order_is_complete(unit, current);
			return 1;
		}
	return 0;
}


/**
 ** EXECUTE_TARGET
 **	Unit wants to select a target
 **/
int execute_target(unit_s *unit, order_s *current)
{
/*
 * Invalid argument? Delete the order
 */
	if (current->executing.types[0] == ARGUMENT_IS_EMPTY) {
		unit_personal_event(unit, today_number, "Invalid TARGET order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Copy the argument
 */
	unit->target = current->arguments[0];
	unit->target_type = current->executing.types[0];
	switch (unit->target_type) {
	    case ARGUMENT_IS_UNIT_ID:
		sprintf(work, "Target is now %s [%s]", unit->target.unit->name, unit->target.unit->id.text);
		break;
	    case ARGUMENT_IS_LOCATION_ID:
		sprintf(work, "Target is now %s [%s]", unit->target.location->name, unit->target.location->id.text);
		break;
	    case ARGUMENT_IS_TERRAIN_TAG:
		sprintf(work, "Target is now %s", unit->target.terrain->name);
		break;
	}
	order_is_complete(unit, current);
	return 0;
}


/**
 ** ANY_FORGOTTEN
 **	Forget the specified skill. Recursively, if we have dependent skills
 **/
static int any_forgotten(unit_s *unit, skill_s *skill)
{
experience_s	*exp;
#ifdef USES_REQUIRED_LEVELS
skill_s		*depend;
#endif
/*
 * Do!
 */
	exp = unit_experiences(unit, skill, 0);
	if (!exp || exp->points <= 0)
		return 0;
	exp->points = 0;
	exp->effective = 0;
#ifdef USES_SKILL_LEVELS
	exp->level = 0;
#ifdef USES_REQUIRED_LEVELS
	for (depend = skills_list; depend; depend = depend->next)
		if (depend->required_skill == skill)
			(void)any_forgotten(unit, depend);
#endif
#endif
	return 1;
}


/**
 ** EXECUTE_FORGET
 **	Unit wants to forget a skill.
 **/
int execute_forget(unit_s *unit, order_s *current)
{
/*
 * Invalid argument? Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid FORGET order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Get the experience
 */
	current->considered = 1;
	if (any_forgotten(unit, current->arguments[0].skill)) {
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** NAME_CLEANUP
 **	Cut any spurious characters from names.
 **/
static void name_cleanup(char *name)
{
	while (*name) {
		switch (*name) {
		    case '[':
		    case ']':
		    case ';':
		    case ':':
		    case ',':
			*name = 0;
			return;
		}
		name++;
	}
}


/**
 ** EXECUTING_CHRISTEN
 **	The unit is attempting to rename a location
 **/
int execute_christen(unit_s *unit, order_s *current)
{
location_s	*local;
char		*name;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Invalid CHRISTEN order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Make sure name is ok
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
/*
 * Valid
 */
	local = unit->current;
	if (local->present == unit) {
		if (local->type->type != TERRAIN_STRUCTURE && strcasecmp(local->name, local->type->name)) {
			unit_personal_event(unit, today_number, "Location already has a name");
			order_is_complete(unit, current);
			return 1;
		}
		current->considered = 1;
		sprintf(work, "%s [%s] christen %s as %s", unit->name, unit->id.text,
					local->id.text, name);
		unit_personal_event(unit, today_number, work);
		location_global_event(unit, today_number, work);
		free(local->name);
		local->name = name;
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTE_DESCRIBE
 **	Unit changes its description
 **/
int execute_describe(unit_s *unit, order_s *current)
{
char	*name;
/*
 * Invalid argument? Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Removed description");
		if (unit->description) {
			free(unit->description);
			unit->description = 0;
		}
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Do it quick
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
	if (unit->description)
		free(unit->description);
	unit->description = name;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_NAME
 **	Unit changes its name
 **/
int execute_name(unit_s *unit, order_s *current)
{
char	*name;
/*
 * Invalid argument? Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Invalid NAME order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Do it quick
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
	free(unit->name);
	unit->name = name;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_YIELD
 **	Unit wants to yield a title.
 **/
int execute_yield(unit_s *unit, order_s *current)
{
title_s	*title;
/*
 * Check condition
 */
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid YIELD order");
		order_is_complete(unit, current);
		return 1;
	}
	if (unit->title == 0)
		return 0;
/*
 * Yield
 */
	title = unit->title->title;
	sprintf(work, "%s [%s] is not longer %s of %s [%s]",
			unit->name, unit->id.text, title->name, unit->title->name, unit->title->id.text);
	unit_personal_event(unit, today_number, work);
	location_visible_event(unit->title, today_number, work);
	unit->title->holder = 0;
	unit->title = 0;
/*
 * Order is done
 */
	if (current) {
		current->considered = 1;
		order_is_complete(unit, current);
	}
	return 1;
}


/**
 ** EXECUTE_BESTOW
 **	Unit wants to bestow a title to another.
 **/
int execute_bestow(unit_s *unit, order_s *current)
{
location_s	*location;
unit_s		*successor;
/*
 * Check condition
 */
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid BESTOW order");
		order_is_complete(unit, current);
		return 1;
	}
	if ((location = unit->title) == 0)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid unit id for BESTOW order");
		order_is_complete(unit, current);
		return 0;
	}
	successor = current->arguments[0].unit;
	if (successor->title)
		return 0;
	if (!may_interact_with(unit, successor))
		return 0;
	if (successor->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "BESTOW must be done on a leader");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Bestow now
 */
	sprintf(work, "%s [%s] succeeds to %s [%s] as %s of %s [%s]!",
			successor->name, successor->id.text, unit->name, unit->id.text,
			location->title->name, location->name, location->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(successor, today_number, work);
	location_visible_event(location, today_number, work);
	location->holder = successor;
	unit->title = 0;
	successor->title = location;
/*
 * Order is done
 */
	if (current) {
		current->considered = 1;
		order_is_complete(unit, current);
	}
	return 1;
}


/**
 ** EXECUTE_CLAIM
 **	Unit wants to claim a title. A challenge is thrown.
 **/
int execute_claim(unit_s *unit, order_s *current)
{
location_s	*location;
unit_s		*holder;
title_s		*title;
experience_s	*exp;
event_s		*event;
carry_s		*cash;
int		compare;
/*
 * Validate arguments
 */
	if (current->executing.types[0] != ARGUMENT_IS_TITLE_TAG ||
	    current->executing.types[1] != ARGUMENT_IS_LOCATION_ID ||
	    unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid CLAIM order");
		order_is_complete(unit, current);
		return 0;
	}
	if ((location = current->arguments[1].location) != unit->current)
		return 0;
	if ((title = current->arguments[0].title) != location->title) {
		sprintf(work, "No such title (%s) here", title->name);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Now, do we have the required for the title?
 */
	exp = unit_experiences(unit, title->required, 0);
	if (!exp || !exp->effective)
		return 0;
#ifdef USES_SKILL_LEVELS
	if (exp->level < title->level)
		return 0;
#endif
/*
 * Throw a challenge or not?
 */
	if ((holder = location->holder) != 0 && current->executing.types[2])
		return 0;
/*
 * Pay up front
 */
	if (payment_required(unit, title->cost))
		return 0;
	if (unit->title)
		(void)execute_yield(unit, 0);
	if (holder) {
/*
 * Challenge occurs
 */
		compare = unit_experiences(holder, title->required, 1)->points;
		if (holder->current == location)
			compare += compare / 10;
/*
 * And succeeds!
 */
		if (compare <= exp->points) {
			sprintf(work, "You challenge %s [%s] for the title of %s of %s [%s], and wins!",
				holder->name, holder->id.text, title->name, location->name, location->id.text);
			unit_personal_event(unit, today_number, work);
			sprintf(work, "You have been challenged by %s [%s] and judged wanting",
				unit->name, unit->id.text);
			unit_personal_event(holder, today_number, work);
			holder->title = 0;
			location->holder = unit;
/*
 * Challenge fails
 */
		} else {
			compare *= exp->points;
			compare += 50;
			compare /= 100;
			sprintf(work, "Your challenge for the title of %s failed by %d%%",
					title->name, compare);
			unit_personal_event(unit, today_number, work);
			sprintf(work, "You have been challenged by %s [%s] and which has %d%% of the requirements",
					unit->name, unit->id.text, compare);
			unit_personal_event(holder, today_number, work);
		}
		if ((cash = holder->coins) == 0)
			holder->coins = cash = unit_possessions(holder, item_cash, 1);
		cash->amount += title->cost / 2;
/*
 * No challenge, grab the title
 */
	} else {
		sprintf(work, "You are now %s of %s [%s]",
				title->name, location->name, location->id.text);
		unit_personal_event(unit, today_number, work);
		location->holder = unit;
	}
/*
 * Do we proclaim the title change!
 */
	if (location->holder == unit) {
		unit->title = location;
		sprintf(work, "%s [%s] is now %s of %s [%s]!",
			unit->name, unit->id.text, title->name, location->name, location->id.text);
		event = new_dated_event();
		event->day = today_number;
		event->text = strdup(work);
#ifdef STEALTH_STATS
		event->stealth = -99;
#endif
		location_general_event(unit->true_location, event);
		printf("%s\n", work);
	}
/*
 * Order is executed
 */
	unit->full_day = 1;
	unit->executing = 0;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_GUARD
 **	Unit wants to switch to guard mode
 **/
int execute_guard(unit_s *unit, order_s *current)
{
experience_s	*exp;
/*
 * Must be 1st combat
 */
	if ((exp = unit_experiences(unit, combat_skill, 0)) == 0 ||
	    !exp->effective)
		return 0;
/*
 * Must hold a title!
 */
/*** HACK ***/
/*
 * Switch to GUARD mode
 */
	unit->is_guarding = 1;
	unit->was_guarding = 1;
	unit->wants_stay = 1;
	unit->current->guarded = 1;
	add_to_experience(unit ,exp , combat_skill, (SKILL_POINTS_PER_DAY/20) * unit->size);
	order_was_executed(unit, current);
#ifdef DYNAMIC_ECONOMY
	unit->true_location->economy++;
#endif
	return 1;
}


/**
 ** EXECUTING_PATROL
 **	Unit wants to switch to patrol mode
 **/
int execute_patrol(unit_s *unit, order_s *current)
{
experience_s	*exp;
int		best_time;
/*
 * Must be 1st combat
 */
	if ((exp = unit_experiences(unit, combat_skill, 0)) == 0 ||
	    !exp->effective)
		return 0;
/*
 * Must hold a title!
 */
/*** HACK ***/
/*
 * Start the patrol. Right now, it's one day to move into position
 */
	if (unit->leader) {
		sprintf(work, "%s [%s] leaves its leader for patrol", unit->name, unit->id.text);
		(void)execute_unstack(unit, 0);
	}
	if (unit->true_location != unit->current)
		(void)execute_leave(unit, 0);
/*** HACK ***/
	best_time = 1;
	unit->toward = unit->true_location;
	unit->move_for_days = best_time;
	unit->moving_by = -1;
	unit->already_moved = 0;
	set_stack_movement(unit, 1);
	unit->executing = current;
	unit->setting_advert = 1;
#ifdef STEALTH_RULES
	unit->setting_report = 1;
#endif
	sprintf(work, "%s [%s] begins patrol", unit->name, unit->id.text);
	location_global_event(unit, today_number, work);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "Patrol will take %d days", best_time);
	if (best_time > 1)
		unit_personal_event(unit, today_number, work);
/*
 * Now, finish this day's movement!
 */
	unit->full_day = 1;
	execute_movement_advances(unit);
	return 1;
}


/**
 ** EXECUTING_PILLAGE
 **	Unit wants to pillage
 **/
int execute_pillage(unit_s *unit, order_s *current)
{
experience_s	*exp;
resource_s	*tokens;
int		amount, cash;
/*
 * Must be 2nd combat
 */
	if ((exp = unit_experiences(unit, combat_skill, 0)) == 0 ||
	    exp->level < 2 || unit->is_guarding)
		return 0;
/*
 * Unit must be large enough to pillage, and locations must not be guarded
 */
	if (unit->size * 60 < unit->true_location->taxes) {
		unit_personal_event(unit, today_number, "Too few pillagers!");
		current->considered = 1;
		return 0;
	}
	if (unit->true_location->guarded) {
		unit_personal_event(unit, today_number, "Location is guarded!");
		current->considered = 1;
		return 0;
	}
/*
 * Accumulate things. Note that this is the only way creature units can "earn" working money.
 */
	tokens = location_has_resource(unit->true_location, token_tax, 1);
	amount = unit->size;
	if (amount > tokens->tokens)
		amount = tokens->tokens;
	tokens->tokens -= amount;
	cash = amount;
	tokens = location_has_resource(unit->true_location, token_entertain, 1);
	amount = unit->size;
	if (amount > tokens->tokens)
		amount = tokens->tokens;
	tokens->tokens -= amount;
	cash += amount;
	if (!cash) {
		unit_personal_event(unit, today_number, "Location is already pillaged!");
		current->considered = 1;
		return 0;
	}
/*
 * Pillage mode.
 */
	sprintf(work, "Pillaged $%d", cash);
	unit_personal_event(unit, today_number, work);
	if (unit->coins == 0)
		unit->coins = unit_possessions(unit, item_cash, 1);
	unit->coins->amount += cash;
	unit->wants_stay = 1;
	add_to_experience(unit ,exp , combat_skill, (SKILL_POINTS_PER_DAY/20) * unit->size);
	unit->wages += unit->size;
/*
 * Order executed
 */
	if (unit->executing != current) {
		sprintf(work, "%s [%s] is pillaging the area!", unit->name, unit->id.text);
		location_visible_event(unit->true_location, today_number, work);
#ifdef STEALTH_STATS
		unit->setting_report = 1;
#endif
	}
	order_was_executed(unit, current);
	unit->executing = 0;
	unit->full_day = 1;
#ifdef DYNAMIC_ECONOMY
	unit->true_location->economy -= 10;
#endif
	return 1;
}


/**
 ** EXECUTING_ATTACK
 **	The unit looks around for someone to slay
 **/
int execute_attack(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid ATTACK order");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target) || target->size <= 0 || target->dead)
		return 0;
	if (unit->faction == target->faction) {
		unit_personal_event(unit, today_number, "Cannot attack your own units");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Stealth intervenes
 */
	sprintf(work, "%s [%s] attacks %s [%s]", unit->name, unit->id.text, target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	location_visible_event(unit->true_location, today_number, work);
	initiate_attack(unit, target);
	unit->full_day = 1;
	unit->executing = 0;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** DO_THE_MOVE
 **	Start the movement
 **/
static int do_the_move(unit_s *unit, location_s *toward, direction_s *dir)
{
experience_s	*scouts;
long		factor;
int		mode;
char		best_mode, best_time;
char		durations[MAX_MOVE_MODES];
/*
 * Last minute check
 */
	if (unit->race->type == RACE_FOLLOWER) {
		if ((scouts = unit_experiences(unit, scouting_skill, 0)) == 0 || !scouts->effective)
			return 0;
	}
	if (unit->has_recruited) {
		unit_personal_event(unit, today_number, "Movement prohibited while shopping");
		return 0;
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s [%s] attempts to move to %s\n", unit->name, unit->id.text, toward->id.text);
#endif
	unstack_stays(unit->stack);
/*
 * Movement toward unfinished inner locations is prohibited
 */
	if (toward->partial && toward->outer)
		return 0;
/*
 * How long to move toward that?
 */
#if defined(END_OF_WORLD) && END_OF_WORLD == 4
	dir = 0;
#endif
	for (mode = 0; mode < MAX_MOVE_MODES; mode++) {
		durations[mode] = 0;
		if (mode == 2) {
			if (dir)
				durations[2] = 4;
			else
				durations[2] = 1;
			continue;
		}
		if (!dir)
			durations[mode] = 1;
		else {
			if (dir->mode) {
				if (mode == dir->mode)
					durations[mode] = dir->days;
				else
					durations[mode] = 0;
			} else
				if (dir->days >= 0)
					switch (mode) {
					    case 0:
						durations[mode] = dir->days;
						break;
					    case 1:
						durations[mode] = (dir->days * 2 + 1)/ 3;
						break;
					}
		}
	}
/*
 * Apply climatic factors
 */
	if (dir) {
		if (!toward->type->covered) {
			switch (unit->current->last_climate) {
			    case 3:
				durations[0] += durations[0] / 5;
				durations[1] += durations[1] / 5;
				durations[2]  = 6;
				break;
			    case 4:
				durations[2]  = 5;
				durations[3] *= 3;
				durations[3] /= 4;
				break;
			    case 5:
				durations[2]  = 15;
				durations[3] *= 9;
				durations[3] /= 10;
				break;
			    case 6:
				durations[2]  = 15;
				durations[1] *= 2;
				break;
			}
		}
		if (dir->mode)
			durations[dir->mode] = dir->days;
	}
/*
 * Capacity plays a role!
 */
	compute_stack_capacity(unit);
	for (mode = 1; mode < MAX_MOVE_MODES; mode++)
		if (unit->stack_capacity[mode] < unit->stack_weight)
			durations[mode] = 0;
	if (durations[0] && unit->stack_capacity[0] > 0 && (unit->stack_capacity[0] < unit->stack_weight)) {
		factor  = unit->stack_weight - unit->stack_capacity[0];
		factor *= 3;
		factor *= durations[0];
		factor /= unit->stack_capacity[0];
		factor += durations[0];
		if (factor > 60)
			factor = 0;
		durations[0] = factor;
	}
/*
 * Apply skill criteria:
 *	Uncovered locations and mundane skill: modes 0,1,3 forbidden
 *	Covered locations or magical skill: all modes forbidden
 */
	if (dir && dir->skill) {
		scouts = unit_experiences(unit, dir->skill, 0);
#ifdef USES_SKILL_LEVELS
		if (!scouts || scouts->level < dir->level) {
#else
		if (!scouts || !scouts->effective) {
#endif
			durations[0] = 0;
			durations[1] = 0;
			durations[3] = 0;
			if (toward->outer || dir->skill->type == 2)
				durations[2] = 0;
			if (dir->skill->required_skill == magecraft)
				durations[2] = 0;
		}
	}
/*
 * What mode will we have?
 */
	best_mode = -1;
	best_time = 99;
	for (mode = 0; mode < MAX_MOVE_MODES; mode++)
		if (durations[mode] &&
		    durations[mode] < best_time) {
			best_time = durations[mode];
			best_mode = mode;
		}
/*
 * Did we find a mode?
 */
	if (best_mode < 0)
		return 0;
/*
 * YESSSS! We move!
 */
	if (unit->leader) {
		sprintf(work, "%s [%s] unstacks to move", unit->name, unit->id.text);
		(void)execute_unstack(unit, 0);
	}
	unit->toward = toward;
	unit->move_for_days = best_time;
	unit->moving_by = best_mode;
	unit->already_moved = 0;
	set_stack_movement(unit, 1);
	unit->executing = 0;
#ifdef STEALTH_RULES
	compute_stack_stealth(unit);
#endif
	sprintf(work, "%s [%s] departs to %s [%s]", unit->name, unit->id.text,
			toward->name, toward->id.text);
	location_global_event(unit, today_number, work);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "Movement will take %d days", best_time);
	if (best_time > 1)
		unit_personal_event(unit, today_number, work);
/*
 * Now, finish this day's movement!
 */
	unit->full_day = 1;
	execute_movement_advances(unit);
	return 1;
}


/**
 ** EXECUTING_MOVE
 **	The unit is attempting to move.
 **/
int execute_move(unit_s *unit, order_s *current)
{
location_s	*toward;
location_s	*inner;
terrain_s	*desired;
direction_s	*dir;
char		*direction;
/*
 * Validity
 */
	if (unit->is_guarding)
		return 0;
	dir = 0;
	switch (current->executing.types[0]) {
	    case ARGUMENT_IS_LOCATION_ID:
		toward = current->arguments[0].location;
		for (dir = unit->true_location->exits; dir; dir = dir->next)
			if (dir->toward == toward)
				break;
		if (!dir) {
			if (toward == unit->true_location->outer)
				break;
			for (inner = unit->true_location->inner; inner; inner = inner->next_inner)
				if (inner == toward)
					break;
			if (!inner) {
/*
 * Special. Maybe we forgot "MOVE OUT"?
 */
				if ((inner = unit->true_location->outer) == 0)
					return 0;
				for (dir = inner->exits; dir; dir = dir->next)
					if (dir->toward == toward)
						break;
				if (!dir)
					return 0;
/*
 * We did. Fake MOVE OUT
 */
				return do_the_move(unit, inner, 0);
			}
		}
		break;
/*
 * Move toward a certain terrain type
 */
	    case ARGUMENT_IS_TERRAIN_TAG:
		desired = current->arguments[0].terrain;
		for (dir = unit->true_location->exits; dir; dir = dir->next)
			if ((toward = dir->toward)->type == desired)
				break;
		if (!dir) {
			if ((toward = unit->true_location->outer) != 0 && desired == toward->type)
				break;
			for (toward = unit->true_location->inner; toward; toward = toward->next_inner)
				if (desired == toward->type)
					break;
			if (!toward)
				return 0;
		}
		break;
/*
 * Move toward a certain direction name
 */
	    case ARGUMENT_IS_STRING:
		direction = current->arguments[0].string;
/*
 * Special case: MOVE OUT
 */
		if (strcasecmp(direction, "OUT") == 0) {
			if (unit->true_location->outer == 0)
				return 0;
			toward = unit->true_location->outer;
			break;
		}
/*
 * Direction is full direction or terrain type?
 */
		for (dir = unit->true_location->exits; dir; dir = dir->next)
			if (strcasecmp(dir->name, direction) == 0)
				break;
		if (!dir)
			for (dir = unit->true_location->exits; dir; dir = dir->next)
				if (abbreviated_keyword(dir->name, direction))
					break;
/*
 * Maybe we forgot to move out first?
 */
		if (!dir) {
			if ((inner = unit->true_location->outer) == 0)
				return 0;
			for (dir = inner->exits; dir; dir = dir->next)
				if (strcasecmp(dir->name, direction) == 0)
					break;
			if (!dir)
				for (dir = inner->exits; dir; dir = dir->next)
					if (abbreviated_keyword(dir->name, direction))
						break;
			if (!dir)
				return 0;
			return do_the_move(unit, inner, 0);
		}
		toward = dir->toward;
		break;
/*
 * Invalid arguments. Delete the order
 */
	    default:
		unit_personal_event(unit, today_number, "Invalid MOVE order");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Now, execute a movement
 */
	if (!do_the_move(unit, toward, dir))
		return 0;
	if (current->executing.routine && current->days >= 0)
		order_is_complete(unit, current);
	unit->executing = 0;
	return 1;
}


/**
 ** EXECUTING_CARAVAN
 **	The unit is moving along a regular route
 **/
int execute_caravan(unit_s *unit, order_s *current)
{
location_s	*toward, *inner;
direction_s	*dir;
int		j, n;
t_argument	swapped[MAX_ORDER_ARGUMENTS];
/*
 * Validity
 */
	if (unit->is_guarding)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID ||
	    current->executing.types[1] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid CARAVAN, require at least two locations");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Search for original location
 */
	for (n = 0; n < MAX_ORDER_ARGUMENTS-1; n++)
		if (current->executing.types[n] != ARGUMENT_IS_LOCATION_ID) {
			unit_personal_event(unit, today_number, "CARAVAN outside of normal route!");
			return 0;
		} else
			if (current->arguments[n].location == unit->true_location)
				break;
/*
 * We've found a location. End of caravaning map? Reverse the caravan and execute
 */
	if (current->executing.types[n+1] != ARGUMENT_IS_LOCATION_ID) {
		if (current->days == 0 || current->days == 1) {
			order_is_complete(unit, current);
			return 0;
		}
		for (j = 0; j <= n; j++)
			swapped[n-j].location = current->arguments[j].location;
		swapped[++n] = 0;
		memcpy(current->arguments, swapped, sizeof(current->arguments));
		if (current->days > 0)
			current->days--;
/*
 * We are now on position 0 (previously n-1), moving toward position 1 (previously n)
 */
		unit_personal_event(unit, today_number, "End of caravan route, turning back");
		n = 1;
	} else
		n++;
/*
 * Direction is found?
 */
	toward = current->arguments[n].location;
	for (dir = unit->true_location->exits; dir; dir = dir->next)
		if (dir->toward == toward)
			break;
	if (dir == 0 && toward != unit->true_location->outer) {
		for (inner = unit->true_location->inner; inner; inner = inner->next_inner)
			if (inner == toward)
				break;
		if (inner == 0) {
			unit_personal_event(unit, today_number, "CARAVAN next step isn't there!");
			order_is_complete(unit, current);
			return 0;
		}
	}
/*
 * Now, execute a movement
 */
	return do_the_move(unit, toward, dir);
}


/**
 ** EXECUTING_STUDY
 **	The unit is attempting to study a skill. Allow that to proceed
 **/
int execute_study(unit_s *unit, order_s *current)
{
skill_s		*skill;
experience_s	*exp;
#ifdef USES_SKILL_LEVELS
int		max;
#endif
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid STUDY order");
		order_is_complete(unit, current);
		return 0;
	}
	skill = current->arguments[0].skill;
/*
 * May study the skill?
 */
	if (unit->race->type >= RACE_CREATURE) {
		sprintf(work, "Creatures cannot study");
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
	if (skill->student && unit->race->type != skill->student) {
		sprintf(work, "Unit cannot study skill %s [%s]", skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s trying to study %s\n", unit->id.text, skill->tag.text);
#endif
/*
 * Great! Do we study the skill, or did we reach the level?
 */
	exp = unit_experiences(unit, skill, 1);
	if (exp->points == 0 && !may_study_skill(unit, skill))
		return 0;
#ifdef USES_SKILL_LEVELS
	if ((max = max_level_allowed(unit, skill)) <= exp->level) {
		sprintf(work, "Maximum level %d already reached in %s [%s]", max, skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		max = current->arguments[1].number;
	else
		max = 99;	/* effective infinity */
	if (max <= exp->level) {
		sprintf(work, "Unit already reached level %d in %s", max, skill->name);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
#endif
/*
 * Report
 */
	if (unit->executing != current)
		unit->executing = 0;
	if (unit_studies_skill(unit, exp, skill))
		return 0;
	unit->executing = current;
	unit->full_day = 1;
#ifdef USES_SKILL_LEVELS
	if (max <= exp->level) {
		order_is_complete(unit, current);
		return 1;
	}
/*
 * STUDY without duration and a skill level is equivalent to @STUDY
 */
	if (max < 99 && current->days == 0) {
		current->considered = 1;
		return 1;
	}
#endif
	order_was_executed(unit, current);
	return 1;
}


#ifdef FX_ABSORB_SKILL_0
/**
 ** EXECUTE_IMBUE
 **	Unit teaches a location
 **/
int execute_imbue(unit_s *unit, order_s *current)
{
location_s	*guild;
skill_s		*skill;
experience_s	*limits, *learned, *maxed;
int		i, multi;
/*
 * Cannot teach while guarding
 */
	if (unit->is_guarding)
		return 0;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing location-id");
		order_is_complete(unit, current);
		return 0;
	}
	if (current->executing.types[1] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing skill");
		order_is_complete(unit, current);
		return 0;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; leader-only");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Make sure location may receive teaching
 */
	guild = current->arguments[0].location;
	skill = current->arguments[1].skill;
	if (guild->type->special_effect != FX_ABSORB_SKILL_0 + skill->type) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; location cannot receive skill type");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Must be in guild and head/owner
 */
	if (unit->current != guild)
		return 0;
#ifdef USES_TITLE_SYSTEM
	if (unit->title != guild)
#endif
		if (unit->current->present != unit)
			return 0;
	if ((limits = unit_experiences(unit, skill, 0)) == 0)
		return 0;
#ifdef USES_SKILL_LEVELS
	if (limits->level < 1)
		return 0;
	if ((learned = location_experiences(guild, skill, 0)) != 0 && learned->level >= limits->level) {
		sprintf(work, "%s [%s] cannot be taught, %s level is present", guild->name,
					guild->id.text, skill->name);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
#else
	learned = 0;
#endif
/*
 * At LAST! We're teaching!
 */
	current->considered = 1;
	if (unit->executing != current) {
		sprintf(work, "Teaching %s [%s] at %s [%s]", skill->name, skill->tag.text,
				guild->name, guild->id.text);
		unit_personal_event(unit, today_number, work);
	}
/*
 * Are we the owner of a special building?
 */
	learned = location_experiences(unit->current, skill, 1);
#ifdef USES_SKILL_LEVELS
	if (learned->level < limits->level) {
		if (learned->effective)
			skill = learned->effective->next_level;
#else
	if (!learned->effective) {
#endif
		learned->points += SKILL_POINTS_PER_DAY;
		if (learned->points >= skill->for_level) {
			learned->effective = skill;
#ifdef USES_SKILL_LEVELS
			learned->level++;
			sprintf(work, "%s [%s] is now providing level %d in %s [%s]",
							guild->name, guild->id.text, learned->level,
#else
			sprintf(work, "%s [%s] is now providing %s [%s]",
							guild->name, guild->id.text,
#endif
							skill->name, skill->tag.text);
			unit_personal_event(unit, today_number, work);
			location_visible_event(unit->true_location, today_number,work);
			printf("%s\n", work);
		}
	}
/*
 * Teaching done for today
 */
	(void)add_to_experience(unit, limits, limits->skill, 1);
	unit->full_day = 1;
	unit->executing = current;
	order_was_executed(unit, current);
#ifdef DYNAMIC_ECONOMY
	unit->true_location->economy += 2;
#endif
	return 1;
}
#endif


/**
 ** EXECUTE_TEACH
 **	Unit teaches another, if that other studies
 **/
int execute_teach(unit_s *unit, order_s *current)
{
unit_s		*student, *pupils;
skill_s		*skill;
experience_s	*limits, *learned, *maxed;
order_s		*order;
int		i, multi;
static int	study_percent[] = { 0, 60, 40, 30, 25, 20 };
/*
 * Cannot TEACH while guarding
 */
	if (unit->is_guarding)
		return 0;
/*
 * Validate argument
 */
#ifdef FX_ABSORB_SKILL_0
	if (current->executing.types[0] == ARGUMENT_IS_LOCATION_ID)
		return execute_imbue(unit, current);
#endif
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing unit-id");
		order_is_complete(unit, current);
		return 0;
	}
	if (current->executing.types[1] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing skill");
		order_is_complete(unit, current);
		return 0;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; leader-only");
		order_is_complete(unit, current);
		return 0;
	}
	student = current->arguments[0].unit;
	skill  = current->arguments[1].skill;
	if (!unit->size || !may_interact_with(unit, student))
		return 0;
	if ((limits = unit_experiences(unit, skill, 0)) == 0)
		return 0;
#ifdef USES_SKILL_LEVELS
	if (limits->level < 1)
		return 0;
	if ((learned = unit_experiences(student, skill, 0)) != 0 && learned->level >= limits->level) {
			sprintf(work, "%s [%s] cannot be taught, %s level is mastered", student->name,
					student->id.text, skill->name);
			unit_personal_event(unit, today_number, work);
			order_is_complete(unit, current);
			return 0;
		}
#else
	learned = 0;
#endif
/*
 * Check multiple student teaching. All must be present and leaders
 */
	multi = 0;
	for (multi = 0; multi < 5; multi++)
	if (current->executing.types[2+multi] != ARGUMENT_IS_UNIT_ID)
		break;
	else {
		pupils = current->arguments[2+multi].unit;
		if (pupils->size && pupils->race->type != RACE_LEADER) {
			unit_personal_event(unit, today_number, "Invalid student for TEACH order");
			order_is_complete(unit, current);
			return 0;
		}
	}
/*
 * Additional restriction
 */
	if (multi && student->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid student for TEACH order");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Target unit must execute some skill
 */
	if (student->is_guarding || student->inactive || student->dead || student->size == 0)
		return 0;
	unit->full_day = 1;
	if (!student->full_day) {
		if (!multi)
			student->taught = limits;
/*
 * Validate arguments
 */
		full_day_order_by_unit(student);
	}
/*
 * Target unit must be studying the skill. Else, we're not doing teach.
 * Check against keyword, else, the study order might not be stored in
 * executing.routine anymore...
 */
	if (!student->full_day || !student->executing ||
	    strcmp(student->executing->executing.keyword, "study") ||
	    student->executing->arguments[0].skill != skill) {
#ifdef TRACING_REQUIRED
		if (unit->traced_unit || student->traced_unit)
			printf("%s trying to teach %s but not studying\n", unit->id.text, student->id.text);
#endif
		unit->full_day = 0;
		return 0;
	}
/*
 * For multi also, we must check teaching!
 */
	for (i = 0; i < multi; i++) {
		pupils = current->arguments[2+i].unit;
		if (!pupils->size || !may_interact_with(unit, pupils))
			continue;
		if (!pupils->full_day)
/*
 * Validate arguments
 */
			full_day_order_by_unit(pupils);
	}
/*
 * At LAST! We're teaching!
 */
	current->considered = 1;
	if (unit->executing != current) {
		sprintf(work, "Teaching %s [%s] to %s [%s]", skill->name, skill->tag.text,
				student->name, student->id.text);
		if (multi)
			strcat(work, " and others...");
		unit_personal_event(unit, today_number, work);
		sprintf(work, "Taught by %s [%s]", unit->name, unit->id.text);
		unit_personal_event(student, today_number, work);
	}
/*
 * Add appropriate % of teaching
 */
	if (!learned)
		learned = unit_experiences(student, skill, 1);
	unit_study_again(student, learned, skill, 50, study_percent[multi]);
	for (i = 0; i < multi; i++) {
		pupils = current->arguments[2+i].unit;
		if (pupils->size && pupils->full_day && pupils->executing &&
		    pupils->executing->executing.routine == execute_study &&
		    pupils->executing->arguments[0].skill == skill &&
		    may_interact_with(unit, pupils)) {
			maxed = unit_experiences(pupils, skill, 1);
			unit_study_again(pupils, maxed, skill, 1, study_percent[multi]);
			if (unit->executing != current) {
				sprintf(work, "Taught by %s [%s]", unit->name, unit->id.text);
				unit_personal_event(pupils, today_number, work);
			}
#ifdef USES_SKILL_LEVELS
			if (pupils->executing->executing.types[1] == ARGUMENT_IS_NUMBER &&
			    pupils->executing->arguments[1].number <= maxed->level) {
				for (order = pupils->orders; order; order = order->next)
					if (order == pupils->executing)
						break;
				if (order)
					order_is_complete(pupils, order);
			}
#endif
		}
	}
/*
 * Maybe the student's order was also executed...
 */
#ifdef USES_SKILL_LEVELS
	if (student->executing->executing.types[1] == ARGUMENT_IS_NUMBER &&
	    student->executing->arguments[1].number <= learned->level) {
		for (order = student->orders; order; order = order->next)
			if (order == student->executing)
				break;
		if (order)
			order_is_complete(student, order);
	}
#endif
/*
 * Are we the owner of a special building?
 */
#ifdef FX_ABSORB_SKILL_0
	if (unit->current->present == unit) {
		switch ((i = unit->current->type->special_effect)) {
		    case FX_ABSORB_SKILL_0:
#ifdef FX_ABSORB_SKILL_1
		    case FX_ABSORB_SKILL_1:
#endif
#ifdef FX_ABSORB_SKILL_2
		    case FX_ABSORB_SKILL_2:
#endif
#ifdef FX_ABSORB_SKILL_3
		    case FX_ABSORB_SKILL_3:
#endif
			if (skill->type == i - FX_ABSORB_SKILL_0)
				break;
		    default:
			skill = 0;
		}
/*
 * Skill match
 */
		if (skill) {
			learned = location_experiences(unit->current, skill, 1);
#ifdef USES_SKILL_LEVELS
			if (learned->level < limits->level) {
				if (learned->effective)
					skill = learned->effective->next_level;
#else
			if (!learned->effective) {
#endif
				learned->points += SKILL_POINTS_PER_DAY / 2;
				if (learned->points >= skill->for_level) {
					learned->effective = skill;
#ifdef USES_SKILL_LEVELS
					learned->level++;
					sprintf(work, "%s [%s] is now providing level %d in %s [%s]",
							unit->current->name, unit->current->id.text, learned->level,
#else
					sprintf(work, "%s [%s] is now providing %s [%s]",
							unit->current->name, unit->current->id.text,
#endif
							skill->name, skill->tag.text);
					unit_personal_event(unit, today_number, work);
					location_visible_event(unit->true_location, today_number,work);
					printf("%s\n", work);
				}
			}
		}
	}
#endif
/*
 * Teaching done for today
 */
	(void)add_to_experience(unit, limits, limits->skill, 1);
	unit->full_day = 1;
	unit->executing = current;
	order_was_executed(unit, current);
#ifdef DYNAMIC_ECONOMY
	unit->true_location->economy ++;
#endif
	return 1;
}


/**
 ** EXECUTE_WORK
 **	This is the default order. It might be called with an order pointer
 **/
int execute_work(unit_s *unit, order_s *current)
{
/*
 * Carrying
 */
	if (unit->is_guarding || !unit->size)
		return 0;
	if (unit->race->type >= RACE_CREATURE)
		return 0;
	unit->wages += unit->size;
	if (current)
		order_was_executed(unit, current);
	unit->executing = 0;
	unit->full_day = 1;
	return 1;
}
