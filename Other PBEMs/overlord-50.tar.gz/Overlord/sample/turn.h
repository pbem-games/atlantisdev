/* $Id: turn.h,v 1.22 1999/11/21 15:46:15 archer Exp $
 *	Turn processor prototypes
 */
#include "enums.h"
#include "overlord.h"
#include "file.h"
#include "info.h"

#define END_OF_WORLD 4

/**
 ** Global variables
 **/
extern int	today_number,
		processing_mode;
#ifdef WORLD_HAS_CLIMATE
extern int	season_number;
#endif
extern item_s		*token_tax,
			*token_entertain,
			*discontent_effect,
			*item_dead, *item_corpse,
			*item_fish,
			*item_mstudy,
			*item_cash;
extern item_s		*item_mana;
extern skill_s		*magecraft,
			*combat_skill,
			*melee_skill,
			*parry_skill,
			*marketing_skill,
			*scouting_skill;
extern skill_s		*air_skill,
			*earth_skill,
			*fire_skill,
			*void_skill,
			*water_skill;
extern terrain_s	*terrain_city;
extern faction_s	*outlaw_faction;


/**
 ** Common functions
 **/
extern int		proportional(int,int,int);
extern int		fractional(int,int,int);
extern int		roll_1Dx(int);
extern char		attitude_vs(faction_s *,unit_s *);
extern char		attitude_vs_faction(faction_s *,faction_s *);
extern int		may_interact_with(unit_s *,unit_s *);
extern void		create_reports(void);
extern void		compute_control_points(void);
extern void		compute_upkeep_values(void);
extern void		compute_upkeep(void);
extern void		compute_unit_stats(unit_s *);
extern void		compute_overall_capacity(unit_s *);
extern void		compute_overall_stealth(unit_s *);
extern void		compute_stack_capacity(unit_s *);
extern void		compute_stack_stealth(unit_s *);
extern void		stack_under(unit_s *, unit_s *);
extern void		unstack_unit(unit_s *);
extern void		adjust_units(void);
extern void		adjust_locations(void);
extern void		location_values(void);
extern void		location_evolves(void);
extern void		pay_upkeep(unit_s *);
extern void		select_climate(void);
#ifdef USES_SKILL_LEVELS
extern int		is_skill_available(location_s *,faction_s *,skill_s *,int);
#else
extern int		is_skill_available(location_s *,faction_s *,skill_s *);
#endif
extern int		stack_size(unit_s *);
extern int		execute_work(unit_s *,order_s *);
extern int		payment_required(unit_s *,long);
extern int		unit_can_pay(unit_s *,long);
extern void		set_stack_movement(unit_s *,int);
extern void		execute_movement_advances(unit_s *);
extern int		full_day_order_by_unit(unit_s *);
extern void		tokens_allocated(location_s *);
extern void		location_harvest_tokens(location_s *);
extern void		harvest_location(unit_s *);
extern char		*uppercase_string(char *);
extern void		report_stats(stats_s *,unit_s *);
extern void		market_evolution(location_s *);

/**
 ** User-defined plugs
 **/
extern int		may_study_skill(unit_s *, skill_s *);
extern int		max_level_allowed(unit_s *, skill_s *);
extern void		unit_study_again(unit_s *, experience_s *, skill_s *, int, int);
extern int		unit_studies_skill(unit_s *, experience_s *, skill_s *);
extern int		add_to_experience(unit_s *,experience_s *,skill_s *,long);
extern int		add_landwalk_experience(unit_s *,skill_s *,int);
