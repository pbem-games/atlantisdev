/* $Id: enums.c,v 1.3 1998/08/31 15:03:15 archer Exp $
 *	Enumerated arrays/values
 */

