/* $Id: config.h,v 1.15 1999/11/21 15:46:12 archer Exp $
 *	User-configurable file
 *
 * This file sets the appropriate global behaviour of an Overlord game.  It
 * drives the style of the game, rather than the details.  To set the details,
 * modify the overlord game files.  Refer to the Gamemaster manual.
 */


/**
 ** DYNAMICALLY_DEFINED_GAME
 **	Define this if you will be building your world and rules on-line.
 ** Doing this will insert more checks, and the turn processor will notify you
 ** of limits reached by players.
 **/
#define DYNAMICALLY_DEFINED_GAME


/**
 ** FIXED_WORLD
 **     The world is fixed at the beginning, and contains locations and
 ** characters designed from scratch.
 **/
#undef FIXED_WORLD


/**
 ** RECRUIT_UNITS
 **	Units may be recruited using a market-like system
 **/
#define RECRUIT_UNITS


/**
 ** PRIMARY_DIRECTION_EAST_WEST
 **     The main "flat" direction is East-West, so we have full lines,
 ** but twisted columns
 **/
#undef PRIMARY_DIRECTION_EAST_WEST


/**
 ** TRACING_REQUIRED
 **	Define this if you require debugging. Debugging allows you to run the
 ** turn processor, tracing all activities from a specific unit.
 **/
#define TRACING_REQUIRED


/**
 ** RANDOM_LOCATION_IDS
 **	Define this to generate location IDs at random, in the form Lxxxxx.
 ** Otherwise, location IDs are generated in sequence, starting at L1, and
 ** increasing monotonically.
 **/
#undef RANDOM_LOCATION_IDS


/**
 ** RANDOM_UNIT_IDS
 **	Define this to generate units IDs at random, in the form xxxxx.
 ** Otherwise, unit IDs are generated in sequence, starting at 1, and
 ** increasing monotonically.
 **/
#define RANDOM_UNIT_IDS


/**
 ** NUMERICAL_UNIT_IDS
 **	Define this if IDs are numerical, and you want to sort them somewow.
 **/
#define NUMERICAL_UNIT_IDS


/**
 ** SORTED_UNIT_IDS
 **	Define this if you want to sort the unit IDs. If they're numerical,
 ** they'll be sorted in numeric order, else in alphabetic order
 **/
#undef SORTED_UNIT_IDS


/**
 ** STANCE_TOWARD_UNITS
 **	Define this if you want stances toward specific units, even without
 ** knowing their faction. Stances toward specific units override faction
 ** stances.
 **/
#undef STANCE_TOWARD_UNITS


/**
 ** USE_OVERLAND_COORDINATES
 **	Define this to use overland coordinates over an hex-based grid
 **/
#define USE_OVERLAND_COORDINATES


/**
 ** REPORT_OVERLAND_COORDINATES
 **	Define this to include the overland coordinates in the player reports.
 ** This setting is valid only if the USE_OVERLAND_COORDINATES has been used.
 **/
#undef REPORT_OVERLAND_COORDINATES


/**
 ** OVERLAND_3D
 **	Uses 3D coordinates for locations.
 **/
#undef OVERLAND_3D


/**
 ** USES_FACTION_FUND
 **	The rules make use a faction fund (or "unclaimed" cash).  If a faction
 ** fund is enabled, an amount of cash will exist on a "floating state", which
 ** can be claimed by units on some specific occasions.  See the next settings.
 **/
#define USES_FACTION_FUND


/**
 ** PRESS_REWARD
 **	Uses this if player-contributed press provides an automatic reward. The
 ** item defines how much is that reward.  The alternative is to have the
 ** game master evaluate how much each article is worth, or not to have rewards
 ** for the player-contributed press.  You need to have both PLAYER_PRESS and
 ** USES_FACTION_FUND defined for this.
 **/
#define PRESS_REWARD 100


/**
 ** RUMOR_REWARD
 **	Uses this if player-contributed press provides an automatic reward. The
 ** item defines how much is that reward for unsigned articles, if different
 ** from signed articles.  If you do not define the RUMOR_REWARD, it will be
 ** equal to PRESS_REWARD; set to 0.
 **/
#undef RUMOR_REWARD


/**
 ** PLAYER_PRESS
 **	Uses this if players can contribute to a game newspaper.  This will be
 ** a per-turn newspaper.  Players may submit at will.
 **/
#define PLAYER_PRESS


/**
 ** USES_FATE_POINTS
 **	The rules make use of fate points (or "destiny" points).  If a faction
 ** fate is enabled, a whole load of code is added to deal with those points.
 **/
#define USES_FATE_POINTS


/**
 ** USES_CONTROL_POINTS
 **	The rules make use of control points to limit the size of factions.
 ** If control points are enabled, the counting module is used to determine
 ** control points, and the CONTROL attributes are handled in structures,
 ** factions, skills and so on.  The USES directive specifies the default
 ** number of control points.
 **/
#define USES_CONTROL_POINTS 200


/**
 ** CONTROL_POINTS_FRACTION
 **	A fraction of N figures requires one control point.  This is meaningful
 ** only when USES_CONTROL_POINTS is selected.
 **/
#define CONTROL_POINTS_FRACTION 20


/**
 ** MULTIPLE_UNIT_OWNERSHIP
 **	Units may be controlled by multiple factions.
 **/
#undef MULTIPLE_UNIT_OWNERSHIP


/**
 ** LOCATION_FACTION_CONTROL
 **	Locations may be controlled by factions.
 **/
#define LOCATION_FACTION_CONTROL


/** 
 ** UNIT_CONTROLS_OTHERS
 **	Units may control units or locations.
 **/
#undef UNIT_CONTROLS_OTHERS


/** 
 ** PARTIAL_CONTROLS
 **	Controls may be partial
 **/
#define PARTIAL_CONTROLS


/**
 ** UNIT_STACKS
 **	Units may be organised into stacks
 **/
#define UNIT_STACKS


/**
 ** USES_SKILL_LEVELS
 **	The rules use skill levels.  Typically advanced skills level may either
 ** be learned, or obtained thru experience, and so on.
 **/
#define USES_SKILL_LEVELS


/**
 ** USES_REQUIRED_LEVELS
 **	The rules use required skill levels to be able to learn skills.
 **/
#define USES_REQUIRED_LEVELS


/**
 ** SPECIALIST_SKILLS
 **	The rules state that some skills may only be learned by teaching
 **/
#define SPECIALIST_SKILLS


/**
 ** SKILL_USE_POINTS
 **	Skills use points to materialise mastery or level attained.
 **/    
#define SKILL_USE_POINTS


/**
 ** SKILL_POINTS_PER_DAY
 **	How many skill points are gained each day? Must be enough to
 ** withstand the various divisors
 **/
#define SKILL_POINTS_PER_DAY 20


/**
 ** SKILL_BENEFITS_FROM_TOOL
 **	The ownership of a tool reduce by 33% the time for a skill
 ** use.
 **/
#define SKILL_BENEFITS_FROM_TOOL


/**
 ** SKILL_BENEFITS_FROM_BOOK
 **	The ownership of an item reduces the time spent learning a
 ** skill.
 **/
#define SKILL_BENEFITS_FROM_BOOK


/**
 ** SKILL_REQUIRES_BOOK
 **	The ownership of an item is required to study a specific skill.
 **/
#define SKILL_REQUIRES_BOOK
   

/**     
 ** SKILLS_USED_IN_BATTLE
 **	Skills have combat applications.
 **/
#define SKILLS_USED_IN_BATTLE

   
/** 
 ** ITEMS_USED_IN_BATTLE
 **	Items have combat applications.
 **/
#define ITEMS_USED_IN_BATTLE


/**
 ** RACE_FAVOR_SKILLS
 **	Races may have specific bonuses or maluses to skill learning.
 **/
#define RACE_FAVOR_SKILLS


/**
 ** BATTLE_INITIATIVE
 **	Uses the initiative rules in battle.
 **/
#define BATTLE_INITIATIVE


/**
 ** STEALTH_STATS
 **	Uses stealth rules.
 **/
#define STEALTH_STATS


/**
 ** STEALTH_DISCLOSES_FACTION
 **	Indicates the number of observation levels required to guess a
 ** faction appartenance.  Valid only if STEALTH_STATS are used.
 **/
#define STEALTH_DISCLOSES_FACTION 3


/**
 ** STEALTH_DISCLOSES_STATS
 **	Indicates the number of observation levels required to guess a
 ** unit vital stats.  Valid only if STEALTH_STATS are used.
 **/
#define STEALTH_DISCLOSES_STATS 6


/**
 ** STEALTH_DISCLOSES_SKILLS
 **	Indicates the number of observation levels required to guess a
 ** known skills.  Valid only if STEALTH_STATS are used.
 **/
#define STEALTH_DISCLOSES_SKILLS 12


/**
 ** USES_MANA_POINTS
 **	Uses mana rules.
 **/
#define USES_MANA_POINTS


/**
 ** MANA_REQUIRE_CONTROL
 **	Mana increase the amount of control points required for a unit,
 ** by 1 control point for each MANA_REQUIRE_CONTROL mana, rounded up.
 ** This is meaningful only if USES_CONTROL_POINTS is defined.
 **/
#define MANA_REQUIRE_CONTROL 4


/**
 ** MANA_REQUIRE_UPKEEP
 **	Mana increase the amount of upkeep one must pay for a unit,
 ** by $MANA_REQUIRE_UPKEEP for each mana.  This is meaningful only if
 ** USES_CASH_UPKEEP is defined.
 **/
#undef MANA_REQUIRE_UPKEEP


/**
 ** USES_TITLE_SYSTEM
 **	Titles and deeds
 **/
#define USES_TITLE_SYSTEM


/**
 ** WORLD_HAS_CLIMATE
 **	Report climatic variations
 **/
#define WORLD_HAS_CLIMATE


/**
 ** DYNAMIC_ECONOMY
 **	Factors influence the economy (attraction) of an hex
 **/
#define DYNAMIC_ECONOMY


/**
 ** SEASONAL_UPKEEP
 **	Upkeep varies depending on the seasons
 **/
#define SEASONAL_UPKEEP


/**
 ** HIDE_RESOURCES
 **	Some resources are hidden. You see them only if you have the
 ** skill that harvest them, or if you have the special "see all".
 **/
#define HIDE_RESOURCES


/**
 ** UNIQUE_ARTEFACTS
 **	The rules state that some items may be unique. These are always won
 ** as spoils (no 50% chance), and quantities are not displayed.
 **/
#define UNIQUE_ARTEFACTS


/**
 ** NECROMANCY_HOOK
 **	This hook enables necromantic processes: dead bodies are buried
 ** and may be unhearted for use
 **/
#define NECROMANCY_HOOK


/**
 ** USES_CASH
 **	The rules make use of some form of cash.
 **/
#define USES_CASH


/**
 ** USES_CASH_UPKEEP
 **	The rules state that each unit must pay upkeep at end of turn.
 **/
#define USES_CASH_UPKEEP


/**
 ** USES_ACTION_POINTS
 **     The system is based on action points, which may be different from
 ** race to race (eventually)
 **/
#undef USES_ACTION_POINTS


/**
 ** REPORTS_EXPERIENCE_POINTS
 **	The report includes how many experience points a unit has in a skill.
 **/
#define REPORTS_EXPERIENCE_POINTS


/**
 ** REPORTS_ITEM_KNOWLEDGE
 **	The report includes the description for items that you discover.
 **/
#define REPORTS_ITEM_KNOWLEDGE


/**
 ** REPORTS_RACIAL_KNOWLEDGE
 **	The report includes the description for races that you encounter.
 **/
#define REPORTS_RACIAL_KNOWLEDGE


/**
 ** REPORTS_SKILL_KNOWLEDGE
 **	The report includes the description for skills (levels) that you
 ** achieve or may discover.
 **/
#define REPORTS_SKILL_KNOWLEDGE


/**
 ** REPORTS_RANKINGS
 **	The report includes how many factions outperform you in any specific
 ** domain. npcN factions are not counted.
 **/
#define REPORTS_RANKINGS


/**
 ** REPORTS_HTML
 **	The report may be generated in HTML. The html version is kept
 ** separate, and the commit processor chooses which to submit.
 **/
#undef REPORTS_HTML


/**
 ** MAX_MOVE_MODES
 **	How many different move modes are available within the game.  This
 ** should be completed in the enumstxt.c string definition.  If left
 ** undefined, the game will not compile
 **/
#define MAX_MOVE_MODES	4


/**
 ** HOOKS
 **	Those hooks disable some common code in very specialised situations
 ** The following hooks are available:
 **	- HOOK_UNIT_STATS : disable compute_unit_stats/capacity (write your own)
 **/
#undef HOOK_UNIT_STATS
