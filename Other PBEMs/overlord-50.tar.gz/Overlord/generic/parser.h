/* $Id: parser.h,v 1.5 1998/09/08 08:41:21 archer Exp $
 *	Parsing routines include. Many Overlord modules include it.
 */
#ifndef overlord_parser_h
#define overlord_parser_h


/*
 * Prototypes
 */
extern int		keyword(char *);
extern int		separate_tag(void);
extern void		synthetic_tag(char *);
extern int		separate_token(void);
extern int		parsed_enum(char *,char *);
extern int		abbreviated_keyword(char *,char *);
#define make_a_copy_(p,v) { if (p) free(p); p = strdup(v); }

/*
 * Global variables
 */
extern char		*string_ptr;
extern t_tag		tag_token;
extern t_tag		id_token;
extern char		token_keyword[256];


#endif/*overlord_parser_h*/
