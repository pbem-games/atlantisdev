/* $Id: formatter.h,v 1.2 1998/12/12 16:32:31 archer Exp $
 *	Report formatting
 */


/**
 ** Variable
 **/
extern char	header_character;
extern char	comma[];


/**
 ** Prototypes
 **/
extern void	start_fold_string(char *);
#define empty_fold_string()	string_ptr = work
#define add_fold_char(c)	*string_ptr++=(c)
extern void	add_fold_string(char *);
extern void	add_fold_tag(t_tag *);
extern void	add_fold_integer(int);
extern void	add_fold_signed(int);
extern void	add_fold_long(long);
extern void	add_fold_item_amount(int,item_s *);
extern void	ensure_print_folded(FILE *,int,char *);
extern void	print_folded(FILE*, int);
