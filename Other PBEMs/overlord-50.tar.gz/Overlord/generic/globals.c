/* $Id: globals.c,v 1.26 1999/11/21 15:46:08 archer Exp $
 *	Turn processor global routines.
 */
#include "turn.h"
#include "fx.h"


/**
 ** Global variables
 **/
#ifdef WORLD_HAS_CLIMATE
int	season_number;
#endif


/**
 ** ROLL_1DX
 **	Roll the very large dice. Correct for any disparities in lrand's distribution.
 ** The "dice" rolled is 0 to n-1, not 1-n...
 **/
int roll_1Dx(int n)
{
static int	old_n = 0;
static long	max;
long		rnd;
/*
 * Go
 */
	if (old_n != n) {
		old_n = n;
		max = n;
		while ((max & 0xFF000000) == 0)
			max <<= 1;
	}
	while (1) {
		rnd = lrand48() >> 6;
		if (rnd < max)
			break;
	}
	return rnd % n;
}


/**
 ** PROPORTIONAL
 **	Useful rule of three.
 **/
int proportional(int value, int amount, int size)
{
long	intermediate;

	if (amount >= size)
		return value;
	if (amount <= 0)
		return 0;
	intermediate  = value;
	intermediate *= amount;
	intermediate /= size;
	return intermediate;
}


/**
 ** FRACTIONAL
 **	Same as above, but the result is rounded
 **/
int fractional(int value, int amount, int size)
{
long	intermediate;

	if (amount >= size)
		return value;
	if (amount <= 0)
		return 0;
	intermediate  = value;
	intermediate *= amount;
	intermediate += size / 2;
	intermediate /= size;
	return intermediate;
}


#ifndef MAP_EDITOR
#ifdef USES_CONTROL_POINTS
/**
 ** COMPUTE_CONTROL_POINTS
 **	Compute control points for a faction
 **/
void compute_control_points(void)
{
faction_s	*faction;
unit_s		*unit;
/*
 * Starting values
 */
	for (faction = faction_list; faction; faction = faction->next) {
		faction->control_max = USES_CONTROL_POINTS + faction->control_bonus;
		faction->control_current = 0;
	}
	for (unit = unit_list; unit; unit = unit->next)
		if (!unit->inactive && !unit->dead && (faction = unit->faction) != 0) {
			compute_unit_stats(unit);
			faction->control_current += unit->vital.control;
#ifdef USES_TITLE_SYSTEM
			if (unit->title)
				faction->control_max += unit->title->title->control;
#endif
		}
}
#endif


#ifdef USES_CASH_UPKEEP
/**
 ** COMPUTE_UPKEEP
 **	Compute the upkeep for all units
 **/
void compute_upkeep(void)
{
unit_s		*unit;
/*
 * Starting values
 */
	for (unit = unit_list; unit; unit = unit->next)
		if (!unit->inactive && !unit->dead && unit->size != 0) {
			compute_unit_stats(unit);
#ifdef SEASONAL_UPKEEP
/*
 * During winter, any unit not in a structure/inner location has to pay extra
 */
			switch (season_number) {
			    case 3:
				if (!unit->current->outer && !unit->current->type->covered)
					unit->vital.upkeep += unit->vital.upkeep / 2;
			}
#endif
		}
}
#endif


#ifdef STEALTH_STATS
/**
 ** COMPUTE_STACK_STEALTH
 **	Effective stack stealth is computed recursively
 **/
void compute_stack_stealth(unit_s *stack)
{
unit_s		*stacked;
/*
 * Unit intrinsic capacity
 */
	stack->effective_stealth = stack->vital.stealth;
	if (stack->is_moving) {
		stack->effective_stealth -= stack->size/10;
		if (stack->moving_by == 2)
			stack->effective_stealth++;
	}
/*
 * Sums the rest of the stack
 */
#ifdef UNIT_STACKS
	for (stacked = stack->stack; stacked; stacked = stacked->next_location) {
		compute_stack_stealth(stacked);
		if (stacked->effective_stealth < stack->effective_stealth)
			stack->effective_stealth = stacked->effective_stealth;
	}
#endif
}


/**
 ** COMPUTE_OVERALL_STEALTH
 **	Compute overall stealth
 **/
void compute_overall_stealth(unit_s *unit)
{
#ifdef UNIT_STACKS
	while (unit->leader)
		unit = unit->leader;
#endif
	compute_stack_stealth(unit);
}
#endif


#ifndef HOOK_UNIT_STATS
/**
 ** COMPUTE_STACK_CAPACITY
 **	Stack capacity is computed here, recursively
 **/
void compute_stack_capacity(unit_s *stack)
{
race_s		*race;
item_s		*type;
carry_s		*items;
unit_s		*stacked;
experience_s	*skills;
skill_s		*mastered;
int		mode;
int		size, equip, unequip;
/*
 * Unit intrinsic capacity
 */
	stack->weight = 0;
	for (mode = 0; mode < MAX_MOVE_MODES; mode++)
		stack->capacity[mode] = 0;
/*
 * Intrinsic to the unit
 */
	if ((size = stack->size) != 0 && (race = stack->race) != 0) {
		stack->weight = race->weight*size;
		for (mode = 0; mode < MAX_MOVE_MODES; mode++)
			stack->capacity[mode] = race->capacity[mode]*size;
	}
/*
 * Skills
 */
	for (skills = stack->skilled; skills; skills = skills->next)
		if ((mastered = skills->effective) != 0)
			for (mode = 0; mode < MAX_MOVE_MODES; mode++)
				stack->capacity[mode] += mastered->capacity[mode] * size;
/*
 * Possessions and equipment
 */
	for (items = stack->carrying; items; items = items->next) {
		size = items->amount;
		type = items->item;
		stack->weight += size * type->weight;
		for (mode = 0; mode < MAX_MOVE_MODES; mode++) {
			equip = items->equipped;
			unequip = size - equip;
			if (type->capacity[mode] > type->equip_capacity[mode]) {
				equip = 0;
				unequip = size;
			}
			if (type->item_type == ITEM_DAYS)
				unequip = stack->size;
			stack->capacity[mode] += equip * type->equip_capacity[mode];
			stack->capacity[mode] += unequip * type->capacity[mode];
		}
	}
/*
 * Sums the rest of the stack
 */
#ifdef UNIT_STACKS
	stack->stack_weight = stack->weight;
	memcpy(stack->stack_capacity, stack->capacity, sizeof(stack->stack_capacity));
	for (stacked = stack->stack; stacked; stacked = stacked->next_location) {
		compute_stack_capacity(stacked);
		for (mode = 0; mode < MAX_MOVE_MODES; mode++)
			stack->stack_capacity[mode] += stacked->stack_capacity[mode];
		stack->stack_weight += stacked->stack_weight;
	}
#endif
}


/**
 ** COMPUTE_UNIT_STATS
 **	Compute the appropriate stats value
 **/
void compute_unit_stats(unit_s *unit)
{
experience_s	*skill;
skill_s		*known;
carry_s		*load;
item_s		*kind;
int		size, equipped;
/*
 * Compute stats
 */
#ifdef STEALTH_STATS
	unit->effective_observe = 0;
#endif
	if (!unit->race) {
		memset(&unit->vital, 0, sizeof(unit->vital));
		return;
	}
	unit->vital = unit->race->intrinsic;
#ifdef USES_CONTROL_POINTS
#ifdef CONTROL_POINTS_FRACTION
/*
 * Control points are multiplied
 */
	size = unit->size;
	size += (CONTROL_POINTS_FRACTION-1);
	size /= CONTROL_POINTS_FRACTION;
	unit->vital.control *= size;
#endif
#endif
/*
 * Cash is proportional to size
 */
	size = unit->size;
#ifdef USES_CASH_UPKEEP
	unit->vital.upkeep *= size;
#endif
/*
 * Apply skill knowledge
 */
	for (skill = unit->skilled; skill; skill = skill->next)
		if ((known = skill->effective) != 0) {
			add_to_stats(&unit->vital, &known->bonus);
#ifdef STEALTH_STATS
			if (known->combat_action.bonus.observation && !known->combat_action.effect)
				unit->effective_observe += known->combat_action.bonus.observation;
#endif
		}
#ifdef USES_CONTROL_POINTS
#ifdef MANA_REQUIRE_CONTROL
/*
 * Mana may increase the amount of control. This apply before item bonus.
 */
	unit->vital.control += (unit->vital.mana - unit->race->intrinsic.mana + (MANA_REQUIRE_CONTROL-1)) / MANA_REQUIRE_CONTROL;
#endif
#endif
/*
 * Add equipment bonus
 */
	for (load = unit->carrying; load; load = load->next) {
		if (load->amount == 0)
			continue;
		if ((kind = load->item)->item_type == ITEM_DAYS)
			add_to_stats(&unit->vital, &kind->equip_bonus);
		else
			if ((equipped = load->equipped) != 0)
				add_proportional_stats(&unit->vital, &kind->equip_bonus, equipped, size);
#ifdef USES_CONTROL_POINTS
		unit->vital.control += kind->equip_bonus.control * load->amount;
#endif
#ifdef USES_CASH_UPKEEP
		unit->vital.upkeep += kind->equip_bonus.upkeep * load->amount;
#endif
		}
#ifdef STEALTH_STATS
	unit->effective_observe += unit->vital.observation;
#endif
}
#endif


/**
 ** COMPUTE_OVERALL_CAPACITY
 **	Compute overall stealth
 **/
void compute_overall_capacity(unit_s *unit)
{
#ifdef UNIT_STACKS
	while (unit->leader)
		unit = unit->leader;
#endif
	compute_stack_capacity(unit);
}


/**
 ** STACK_SIZE
 **	How many figures stacked?
 **/
int stack_size(unit_s *stack)
{
int	people;
/*
 * Compute people
 */
	for (people = 0; stack; stack = stack->next_location)
		people += stack->size
#ifdef UNIT_STACKS
					+ stack_size(stack->stack);
#else
					;
#endif
	return people;
}


/**
 ** ATTITUDE_VS_FACTION
 **	Determine the attitude against a specific faction
 **/
char attitude_vs_faction(faction_s *faction, faction_s *against)
{
stance_s	*stance;
/*
 * We are ally to ourselves!
 */
	if (faction == against || !faction)
		return 0;
/*
 * Find specific stance?
 */
	for (stance = faction->stances; stance; stance = stance->next)
		if (stance->faction == against)
			break;
	if (!stance)
		return faction->attitude;
	return stance->attitude;
}


/**
 ** ATTITUDE_VS
 **	Determine the attitude against a specific unit
 **/
char attitude_vs(faction_s *faction, unit_s *unit)
{
/*
 * Find specific stance?
 */
	return attitude_vs_faction(faction, unit->faction);
}


/**
 ** MAY_INTERACT_WITH
 **	You may interact with the other unit
 **/
int may_interact_with(unit_s *unit, unit_s *target)
{
unit_s	*leader;
/*
 * Cannot interact unless at same location, not dead, nor moving
 */
	if (unit->true_location != target->true_location)
		return 0;
	if (target->inactive || target->dead)
		return 0;
	if (target->is_moving || target->toward) {
		leader = target;
#ifdef UNIT_STACKS
		while (leader->leader)
			leader = leader->leader;
#endif
		if (leader->already_moved > 1)
			return 0;
	}
#ifdef STEALTH_STATS
/*
 * Stealth intervenes, unless stacked or of same faction
 */
#ifdef UNIT_STACKS
	if (target->leader != unit && unit->leader != target &&
#else
	if (
#endif
	    unit->faction != target->faction)
		if (!target->setting_report)
			if (unit->vital.observation < target->effective_stealth)
				return 0;
#endif
	return 1;
}


/**
 ** HAS_FX_IN_STACK
 **/
static int has_fx_in_stack(unit_s *stack, faction_s *faction, int fx)
{
experience_s	*exp;
carry_s		*owns;
/*
 * Loop on stack
 */
	while (stack) {
		if (stack->faction == faction) {
			for (exp = stack->skilled; exp; exp = exp->next)
				if (exp->effective && exp->effective->special_effects == fx)
					return 1;
			for (owns = stack->carrying; owns; owns = owns->next)
				if (owns->amount && owns->item->special_effects == fx)
					return 1;
		}
#ifdef UNIT_STACKS
		if (has_fx_in_stack(stack->stack, faction, fx))
			return 1;
#endif
		stack = stack->next_location;
	}
	return 0;
}


/**
 ** IS_FX_AVAILABLE
 **	Does the faction has the required fx present
 **/
int is_fx_available(location_s *here, faction_s *faction, int fx)
{
location_s	*sublocation;
/*
 * Find
 */
	if (has_fx_in_stack(here->present, faction, fx))
		return 1;
	for (sublocation = here->inner; sublocation; sublocation = sublocation->next_inner)
		if (sublocation->type->type == TERRAIN_STRUCTURE)
			if (has_fx_in_stack(sublocation->present, faction, fx))
				return 1;
	return 0;
}


/**
 ** HAS_SKILL_IN_STACK
 **/
#ifdef USES_SKILL_LEVELS
static int has_skill_in_stack(unit_s *stack, faction_s *faction, skill_s *skill, int level)
#else
static int has_skill_in_stack(unit_s *stack, faction_s *faction, skill_s *skill)
#endif
{
experience_s	*exp;
/*
 * Loop on stack
 */
	while (stack) {
		if (stack->faction == faction) {
			for (exp = stack->skilled; exp; exp = exp->next)
				if (exp->skill == skill)
#ifdef USES_SKILL_LEVELS
				if (exp->level >= level)
#endif
					return 1;
		}
#ifdef UNIT_STACKS
#ifdef USES_SKILL_LEVELS
		if (has_skill_in_stack(stack->stack, faction, skill, level))
#else
		if (has_skill_in_stack(stack->stack, faction, skill))
#endif
			return 1;
#endif
		stack = stack->next_location;
	}
	return 0;
}


/**
 ** IS_SKILL_AVAILABLE
 **	Does the faction has the required skill present
 **/
#ifdef USES_SKILL_LEVELS
int is_skill_available(location_s *here, faction_s *faction, skill_s *skill, int level)
#else
int is_skill_available(location_s *here, faction_s *faction, skill_s *skill)
#endif
{
location_s	*sublocation;
/*
 * Find
 */
#ifdef USES_SKILL_LEVELS
	if (has_skill_in_stack(here->present, faction, skill, level))
#else
	if (has_skill_in_stack(here->present, faction, skill))
#endif
		return 1;
	for (sublocation = here->inner; sublocation; sublocation = sublocation->next_inner)
		if (sublocation->type->type == TERRAIN_STRUCTURE)
#ifdef USES_SKILL_LEVELS
			if (has_skill_in_stack(sublocation->present, faction, skill, level))
#else
			if (has_skill_in_stack(sublocation->present, faction, skill))
#endif
				return 1;
	return 0;
}


/**
 ** ADJUST_UNITS
 **	Pre-game adjustments
 **/
void adjust_units(void)
{
unit_s	*unit;
unit_s	*leader;
carry_s	*has;
int	stop;
/*
 * Go
 */
	stop = 0;
	for (unit = unit_list; unit; unit = unit->next) {
/*
 * Activate newly created unit
 */
		if (unit->inactive) {
			if (unit->size == 0 || !unit->faction)
				continue;
#ifdef TURN_PROCESSOR
			assign_unit_id(unit);
#endif
			unit->inactive = 0;
		}
/*
 * Active units must have things
 */
		if (!unit->race) {
			if (unit->size)
				printf("Unit %s has no race\n", unit->id.text);
			unit->size = 0;
			unit->faction = 0;
/*** HACK ***/
			continue;
		}
#ifdef USES_ACTION_POINTS
		else {
			unit->actions = unit->race->actions;
			unit->spent = 0;
		}
#endif
/*
 * Capacities and stats
 */
		compute_unit_stats(unit);
		compute_stack_capacity(unit);
#ifdef UNIT_STACKS
		if ((leader = unit->leader) != 0) {
			while (leader->leader)
				leader = leader->leader;
			unit->current = leader->current;
			unit->true_location = leader->true_location;
		}
#endif
		if (!unit->current) {
			printf("Unit %s is in never neverland!!!\n", unit->id.text);
			stop = 1;
		}
#ifdef STEALTH_STATS
		compute_stack_stealth(unit);
#endif
/*
 * Unit may have "days of xxxx" pending
 */
		for (has = unit->carrying; has; has = has->next)
			if (has->item->item_type == ITEM_DAYS) {
				unit->has_effects = 1;
				break;
			}
	}
	if (stop)
		exit(1);
}
#endif


#ifdef TURN_PROCESSOR
/**
 ** ADJUST_LOCATIONS
 **	Pre-game adjustments
 **/
void adjust_locations(void)
{
location_s	*local;
/*
 * Go
 */
#ifdef USES_CASH
	for (local = location_list; local; local = local->next) {
/*
 * Market day
 */
		market_check(local);
	}
#endif
/*
 * Recompute each location
 */
#ifndef MAP_EDITOR
#ifdef WORLD_HAS_CLIMATE
	season_number = (game_turn_number % 12) / 3;
#endif
	location_values();
#endif
}


/**
 ** TOKENS_ALLOCATED
 **	One 30th of the tokens are released for consumption
 **/
void tokens_allocated(location_s *location)
{
resource_s	*token;
int		amount;
int		fraction;
/*
 * Go
 */
	fraction = 31 - today_number;
	for (token = location->resources; token; token = token->next) {
		amount = token->remains;
		if (fraction > 1) {
			amount += fraction / 2;
			amount /= fraction;
		}
		if (amount > token->remains)
			amount = token->remains;	/* weirdness??? */
		token->remains -= amount;
		token->tokens += amount;
	}
}


/**
 ** LOCATION_HARVEST_TOKENS
 **	Location has harvesting tokens available
 **/
void location_harvest_tokens(location_s *location)
{
resource_s	*resource;
resource_s	*token;
/*
 * Each ressource yields a given amount of tokens
 */
	for (resource = location->resources; resource; resource = resource->next)
		resource->remains = resource->amount * resource->type->token_multiplier;
/*
 * If taxing, then tokens for taxes are available
 */
#ifdef USES_CASH
	if (location->taxes) {
		token = new_resource_instance();
		token->next = location->resources;
		location->resources = token;
		token->type = token_tax;
		token->remains = location->taxes;
	}
/*
 * If entertainers, then tokens for enterainment are available
 */
	if (location->entertainment) {
		token = new_resource_instance();
		token->next = location->resources;
		location->resources = token;
		token->type = token_entertain;
		token->remains = location->entertainment;
	}
#endif
/*
 * Effective infinite amount of private ressources (tokens only)
 */
	if (location->type->local_token && location->type->local_token->item_type) {
		token = new_resource_instance();
		token->next = location->resources;
		location->resources = token;
		token->type = location->type->local_token;
		token->remains = 99999999;
	}
/*
 * Special effects may alter this nice order
 */
	if (location->type->special_effect)
		fx_location_init(location);
}
#endif
