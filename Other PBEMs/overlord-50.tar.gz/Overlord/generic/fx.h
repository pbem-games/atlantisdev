/* $Id: fx.h,v 1.11 1999/11/21 15:46:08 archer Exp $
 *	Technicolor special effects - anything that does not fit
 * in the standard framework.  FXs are attached to skills, items
 * or produced tokens.
 */
#ifndef overlord_fx_h_
#define overlord_fx_h_
#include "fxdef.h"


/**
 ** Prototypes
 **/
extern int	fx_available_here_for(location_s *, faction_s *, int);
extern void	fx_location_init(location_s *);
extern int	fx_execute_event(item_s *,int,unit_s *,skill_s *,order_s *);
extern void	fx_end_of_turn(unit_s *,carry_s *);
extern void	fx_mind_reading(unit_s *, int);
extern int	fx_active_structure(unit_s *, int);
extern int	is_fx_available(location_s *,faction_s *,int);


#endif /* overlord_fx_h_ */
