/* $Id: checker.c,v 1.8 1998/12/12 16:32:30 archer Exp $
 *	Syntax checker. Currently, only comments all orders, do not validate any!
 */
#include "checker.h"
#include "email.h"


/**
 ** Global variables
 **/
FILE		*current_report;
faction_s	*current_faction;
int		cleared;
int		conditional;
int		days;
unit_s		*current_unit;


/**
 ** SYNTAX_CHECK_LINE
 **	Parse one line of orders.  Such lines have a wildly
 ** differing format.
 **/
static void syntax_check_line(void)
{
command_s	*command;
int		i;
/*
 * Special case: the CLEAR order
 */
	if (keyword("CLEAR")) {
		if (!cleared)
			fprintf(current_report, ">>> CLEAR wipes all the previous\n");
		return;
	}
/*
 * Conditional count
 */
	while (isspace(*string_ptr))
		string_ptr++;
	i = 0;
	while (*string_ptr == '-') {
		i++;
		string_ptr++;
	}
	if (i > conditional+1)
		fprintf(current_report, ">>> Too many conditionals, maybe\n");
	conditional = i;
	while (isspace(*string_ptr))
		string_ptr++;
	if (*string_ptr == '+')
		string_ptr++;
/*
 * Duration
 */
	while (isspace(*string_ptr))
		string_ptr++;
	days = 0;
	if (isdigit(*string_ptr)) {
		while (isdigit(*string_ptr))
			days = (days*10) + (*string_ptr++) - '0';
		if (days > 99)
			days = 99;
	} else
		if (*string_ptr == '@') {
			days = -1;
			string_ptr++;
		}
	if (days == 0)
		days = 1;
/*
 * Order itself
 */
	while (isspace(*string_ptr))
		string_ptr++;
	if ((*string_ptr == 'D' || *string_ptr == 'd') && isdigit(string_ptr[1])) {
		string_ptr++;
		while (isdigit(*string_ptr))
			string_ptr++;
		while (isspace(*string_ptr))
			string_ptr++;
	}
	for (command = valid_orders; command->keyword; command++)
		if (keyword(command->keyword))
			break;
	if (!command->keyword) {
		fprintf(current_report, ">>> Unknown order\n");
		return;
	}
/*
 * Use the executor parser!
 */
	if ((*command->routine)(current_unit, 0)) {
		fprintf(current_report, "Syntax: %s", command->keyword);
		for (i = 0; i < MAX_ORDER_ARGUMENTS; i++) {
			if (!command->types[i])
				break;
			fprintf(current_report, " %s", visual_enum(command->types[i], "\n\
unit-id\n\
location-id\n\
item-tag\n\
skill-tag\n\
race-tag\n\
terrain-tag\n\
faction-id\n\
title-tag\n\
stance\n\
boolean\n\
string\n\
number\n\
battle\n\
rank\n\
file\n\
move\n\
combat-option\n\
setting\n\
direction-or-location-id\n\
unit-location-id-or-structure-tag\n"));
			if (command->types[i] == command->types[i+1]) {
				fprintf(current_report, "...");
				break;
			}
		}
		putc('\n', current_report);
	}
#ifdef USES_ACTION_POINTS
	  else
		current_unit->spent += days;
#endif
}


/**
 ** MAIN
 **	Entry point for the syntax checker
 **/
int main(int argc, char **argv)
{
FILE		*orders;
char		*email;
#ifdef KEEP_CHECKER_OUTPUT
char		*fname;
char		sendchk[8192];
#endif
/*
 * We require two arguments: The faction id, and the checker recipient
 */
	if (argc < 2) {
		fprintf(stderr, "Invalid arguments to syntax checker\n");
		exit(1);
	}
/*
 * Load all info
 */
	load_game_info();
	load_items();
	load_skills();
	load_races();
	load_factions();
	load_units();
#ifdef USES_TITLE_SYSTEM
	load_titles();
#endif
	load_locations();
/*
 * Which faction are we checking?
 */
	string_ptr = argv[1];
	if (!separate_tag() || (current_faction = faction_from_id(0)) == 0) {
		fprintf(stderr, "Invalid faction ID %s\n", argv[1]);
		exit(1);
	}
/*
 * Start the reply. Use the sendcheck script
 */
	if (argc > 2)
		email = argv[2];
	else
		email = current_faction->e_mail;
#ifdef KEEP_CHECKER_OUTPUT
	fname = player_specific_file(current_faction, "checked");
	sprintf(sendchk, "./sendcheck \"%s\" < %s", email, fname);
	if ((current_report = fopen(fname, "w")) == 0) {
		perror(fname);
#else
	sprintf(work, "./sendcheck \"%s\"", email);
	if ((current_report = popen(work, "w")) == 0) {
		perror("popen()");
#endif
		exit(1);
	}
	fprintf(current_report, "From: %s\n", server_email);
	fprintf(current_report, "Subject: Syntax check for your turn %d orders\n", game_turn_number);
	fprintf(current_report, "To: %s\n", argv[2]);
	fprintf(current_report, "\n");
/*
 * Do we have an order file?
 */
	if ((orders = fopen(player_specific_file(current_faction, "order"), "r")) == 0)  {
		fprintf(current_report, "No order file submitted\n");
#ifdef KEEP_CHECKER_OUTPUT
		fclose(current_report);
		system(sendchk);
#else
		pclose(current_report);
#endif
		return 0;
	}
	fprintf(current_report, "#GAME %s %s\n", current_faction->id.text, current_faction->password);
/*
 * Now, parse
 */
	current_unit = 0;
	while (file_gets(orders)) {
		fprintf(current_report, "%s\n", work);
		while (isspace(*string_ptr))
			string_ptr++;
		if (!*string_ptr || *string_ptr == ';')
			continue;
/*
 * Faction-wide orders are parsed here
 */
		if (!current_unit) {
			if (keyword("EMAIL")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->name, token_keyword))
					fprintf(current_report, "; changes your report mail address to `%s'\n", token_keyword);
				else
					fprintf(current_report, ">>> Invalid email change\n");
				continue;
			}
			if (keyword("NAME")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->name, token_keyword))
					fprintf(current_report, "; changes your faction name to `%s'\n", token_keyword);
				else
					fprintf(current_report, ">>> Invalid faction renaming\n");
				continue;
			}
			if (keyword("PASSWORD")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->name, token_keyword))
					fprintf(current_report, "; changes your orders password to `%s' (at next turn)\n", token_keyword);
				else
					fprintf(current_report, ">>> Invalid password change\n");
				continue;
			}
			if (keyword("RESHOW")) {
/*** HACK ***/
			}
		}
/*
 * Unit select!
 */
		if (keyword("UNIT")) {
#ifdef USES_ACTION_POINTS
			if (current_unit && current_unit->spent > current_unit->actions)
				fprintf(current_report, "; beware: you've spent an extra %d actions\n", current_unit->spent - current_unit->actions);
#endif
			cleared = 0;
			current_unit = 0;
			if (!separate_tag()) {
				fprintf(current_report, ">>> Not a unit ID!\n");
				continue;
			}
			current_unit = potential_unit_id(current_faction);
			if (!current_unit) {
				fprintf(current_report, ">>> Unit does not and cannot exist\n");
				continue;
			}
			if (current_unit->faction != current_faction) {
				fprintf(current_report, ">>> Unit does not belong to your faction\n");
				current_unit = 0;
			} else {
				cleared = 1;
				conditional = 0;
			}
#ifdef USES_ACTION_POINTS
			if (current_unit->race)
				current_unit->actions = current_unit->race->actions;
			else
				current_unit->actions = USES_ACTION_POINTS;
			current_unit->spent = 0;
#endif
			continue;
		}
		if (!current_unit) {
			fprintf(current_report, ">>> No unit selected, skipped\n");
			continue;
		}
/*
 * Parse now
 */
		syntax_check_line();
	}
#ifdef USES_ACTION_POINTS
	if (current_unit && current_unit->spent > current_unit->actions)
		fprintf(current_report, "; beware: you've spent an extra %d actions\n", current_unit->spent - current_unit->actions);
#endif
	fclose(orders);
/*
 * Done
 */
	fprintf(current_report, "#END\n");
#ifdef KEEP_CHECKER_OUTPUT
	fclose(current_report);
	system(sendchk);
#else
	pclose(current_report);
#endif
	return 0;
}
