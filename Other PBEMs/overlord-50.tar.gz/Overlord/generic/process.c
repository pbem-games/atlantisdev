/* $Id: process.c,v 1.5 1999/04/05 10:05:35 archer Exp $
 *	Processing of orders, common parts
 */
#include "turn.h"


/**
 ** ORDER_IS_COMPLETE
 **	Order just completed, and is removed
 **/
void order_is_complete(unit_s *unit, order_s *current)
{
order_s	*next;
#ifdef TRACING_REQUIRED
/*
 * Full trace
 */
	if (unit->traced_unit)
		printf("Order 0x%x (%s) for %s dropped\n", (unsigned)current, current->executing.keyword, unit->id.text);
#endif
/*
 * Check
 */
	if (!current->executing.routine)
		return;
/*
 * Unlink
 */
	if (current->prev)
		current->prev->next = current->next;
	else
		if (unit->orders == current)
			unit->orders = current->next;
	next = current->next;
	if (next)
		next->prev = current->prev;
/*
 * Dispose of actual structure
 */
	current->next = 0;
	current->executing.routine = 0;
	free_order_instance(current);
/*
 * Positive conditional? Drop all of them
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
/*
 * Conditional?
 */
	for (; next; next = next->next)
		if (!next->conditional)
			break;
		else
			next->conditional--;
/*
 * 2nd instance of positive conditional? Drop all of these too...
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
}


/**
 ** ORDER_WAS_EXECUTED
 **	Unit just finished
 **/
int order_was_executed(unit_s *unit, order_s *current)
{
	current->considered = 1;
	if (current->days > 0)
		current->days--;
	if (current->days == 0)
		order_is_complete(unit, current);
	return 1;
}


#ifdef USES_CASH
/**
 ** UNIT_CAN_PAY
 **	Unit will have to pay for something
 **/
int unit_can_pay(unit_s *unit, long cash)
{
unit_s	*leader;
carry_s	*coins;
/*
 * Payment is extracted from coinage
 */
	if ((coins = unit->coins) == 0)
		unit->coins = coins = unit_possessions(unit, item_cash, 0);
	if (coins != 0) {
		if (coins->amount >= cash)
			return 0;
		cash -= coins->amount;
	}
#ifdef USES_FACTION_FUND
/*
 * Payment may be withdrawn
 */
	if (unit->true_location->type == terrain_city && !unit->setting_miser) {
		if (unit->faction->faction_fund >= cash)
			return 0;
		cash -= unit->faction->faction_fund;
		if (cash < 0)
			return 0;
	}
#endif
/*
 * We may draw from out fearless leader's cash supply!
 */
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader->faction == unit->faction) {
			if ((coins = leader->coins) == 0)
				leader->coins = coins = unit_possessions(leader, item_cash, 0);
			if (coins != 0) {
				if (coins->amount >= cash)
					return 0;
				cash -= coins->amount;
			}
		}
/*
 * Cannot pay
 */
	return 1;
}


/**
 ** PAYMENT_REQUIRED
 **	Unit pays for something. It is assumed it has been checked...
 **/
int payment_required(unit_s *unit, long cash)
{
unit_s	*leader;
carry_s	*coins;
long	drawn;
/*
 * Payment is extracted from coinage
 */
	if ((coins = unit->coins) == 0)
		unit->coins = coins = unit_possessions(unit, item_cash, 1);
	drawn = 0;
	if (coins != 0) {
		if ((drawn = coins->amount) >= cash) {
			coins->amount -= cash;
			return 0;
		}
		coins->amount = 0;
		cash -= drawn;
	}
#ifdef USES_FACTION_FUND
/*
 * Payment may be withdrawn
 */
	if (unit->true_location->type == terrain_city && !unit->setting_miser) {
		if (unit->faction->faction_fund >= cash) {
			unit->faction->faction_fund -= cash;
			if (coins)
				coins->amount = 0;
			unit->withdrawn += cash;
			return 0;
		}
	}
#endif
/*
 * We may draw from out fearless leader's cash supply!
 */
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader->faction == unit->faction) {
			if ((coins = leader->coins) == 0)
				leader->coins = coins = unit_possessions(leader, item_cash, 1);
			if (coins->amount >= cash) {
				coins->amount -= cash;
				return 0;
			}
			drawn += coins->amount;
			cash -= coins->amount;
			coins->amount = 0;
		}
/*
 * Cannot pay, restore coinage. This *may* result in transfer of funds back to the
 * leader, so beware.
 */
	if (drawn)
		coins->amount += drawn;
	return 1;
}
#endif


#ifdef USES_CASH_UPKEEP
/**
 ** PAY_UPKEEP
 **	Will try to draw upon any possible upkeep source
 **/
void pay_upkeep(unit_s *unit)
{
unit_s	*other;
carry_s	*pay;
long	cash, paid, frac;
int	food, remain;
/*
 * Try to pay locally
 */
	unit->full_day = 1;
	cash = unit->vital.upkeep;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s pays $%ld upkeep\n", unit->name, cash);
#endif
	if (!cash)
		return;
/*
 * Pay from food or upkeep tokens!
 */
	remain = unit->size;
	if (!remain)
		return;
	frac = cash / unit->size;
	food = 0;
	for (pay = unit->carrying; pay; pay = pay->next)
		if (pay->equipped && pay->item->equip_category == 1) {
			if (pay->equipped >= remain) {
				food += remain;
				pay->amount -= remain;
				remain = 0;
			} else {
				food += pay->equipped;
				pay->amount -= pay->equipped;
				remain -= pay->equipped;
			}
			if (pay->equipped > pay->amount)
				pay->equipped = pay->amount;
			if (remain == 0)
				break;
		}
	if (food) {
		sprintf(work, "%d rations eaten for upkeep", food);
		unit_personal_event(unit, 30, work);
		paid = food * frac;
		paid *= 4;
		paid /= 5;
		cash -= paid;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s eats %d food\n", unit->name, food);
#endif
	}
	if (!cash)
		return;
/*
 * Use faction fund in priority?
 */
#ifdef USES_FACTION_FUND
	if (cash && unit->setting_support && unit->faction->faction_fund) {
		if (cash >= unit->faction->faction_fund)
			paid = unit->faction->faction_fund;
		else
			paid = cash;
		cash -= paid;
		unit->faction->faction_fund -= paid;
		sprintf(work, "Using $%ld funds for upkeep", paid);
		unit_personal_event(unit, 30, work);
		if (!cash)
			return;
	}
#endif
/*
 * Pay from pocket change
 */
	if ((pay = unit->coins) == 0)
		unit->coins = pay = unit_possessions(unit, item_cash, 0);
	if (pay && pay->amount) {
		if (pay->amount >= cash) {
			pay->amount -= cash;
			return;
		}
		cash -= pay->amount;
		pay->amount = 0;
	}
/*
 * Any other unit of the same faction around that could lend us coins?
 */
	for (other = unit->faction->units; other; other = other->same_faction)
		if (!other->inactive && !other->dead && other->true_location == unit->true_location) {
			if (!other->full_day)
				pay_upkeep(other);
			pay = other->coins;
			if (pay && pay->amount) {
				if (pay->amount >= cash)
					paid = cash;
				else
					paid = pay->amount;
				sprintf(work, "%s [%s] lent $%ld for %s [%s]'s upkeep", other->name, other->id.text,
							paid, unit->name, unit->id.text);
				unit_personal_event(unit, 30, work);
				unit_personal_event(other, 30, work);
				pay->amount -= paid;
				cash -= paid;
				if (!cash)
					return;
			}
		}
/*
 * We still need cash!
 */
#ifdef USES_FACTION_FUND
	if (cash && unit->faction->faction_fund) {
		if (cash >= unit->faction->faction_fund)
			paid = unit->faction->faction_fund;
		else
			paid = cash;
		cash -= paid;
		unit->faction->faction_fund -= paid;
		sprintf(work, "Using $%ld funds for upkeep", paid);
		unit_personal_event(unit, 30, work);
	}
#endif
	if (cash) {
		sprintf(work, "Lacks $%ld for upkeep", cash);
		unit_personal_event(unit, 30, work);
		cash *= 30;
		pay = unit_possessions(unit, discontent_effect, 1);
/*
 * Desertion occurs?
 */
		if (pay->amount) {
			unit_personal_event(unit, 30, "Unit deserts");
			unit->now_loyal = outlaw_faction;
			pay->amount = 0;
		}
		pay->amount = cash / unit->size;
	}
}
#endif
