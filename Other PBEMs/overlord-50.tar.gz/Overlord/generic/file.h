/* $Id: file.h,v 1.3 1998/03/05 13:37:12 archer Exp $
 *	File routines include. Many Overlord modules include it.
 */
#ifndef overlord_file_h
#define overlord_file_h


/*
 * Prototypes
 */
extern int		file_gets(FILE *);
extern char		*new_file(char *);


/*
 * Global variables
 */
extern char		*string_ptr;
extern char		work[8192];


#endif/*overlord_file_h*/
