/* $Id: item.h,v 1.14 1999/11/21 15:46:09 archer Exp $
 *	Define the internals about an item
 */
#ifndef overlord_item_h
#define overlord_item_h

/**
 ** Item object
 **/
struct struct_item {
	t_tag			tag;
	struct struct_item	*next;
	char			*name,
				*plural;
#ifdef REPORTS_ITEM_KNOWLEDGE
	char			*description;
#endif
	skill_s			*equip_skill;
	skill_s			*use_skill;
	long			weight;
	long			capacity[MAX_MOVE_MODES];
	long			equip_capacity[MAX_MOVE_MODES];
	int			token_multiplier;	/* For harvesting */
#ifdef ITEMS_USED_IN_BATTLE
	combat_s		combat_action;		/* if useable as combat setting */
#endif
	stats_s			equip_bonus;		/* to vital stats */
#ifdef USES_SKILL_LEVELS
	int			equip_level;
#endif
	int			suggested_price;	/* for auto-market */
	char			equip_category;
	char			equip_maximum;		/* how many per category */
	char			equip_requires;		/* how many men to equip */
	char			item_category;
	char			item_type;
#define ITEM_ITEM		0
#define ITEM_DAYS		1
#define ITEM_EFFECT		2
#define ITEM_EVENT		3
#define ITEM_TOKEN		4
	char			item_live;		/* live product */
	char			item_special;		/* special/magical item */
#ifdef HIDE_RESOURCES
	char			item_hidden;		/* high-level resource*/
#endif
#ifdef UNIQUE_ARTEFACTS
	char			unique;			/* artefact */
#endif
	char			auto_equip;
	char			special_effects;	/* FX!!! */
};
typedef struct struct_item	item_s;		/* item type */

struct struct_carry {
	struct struct_carry	*next;
	item_s			*item;
	int			amount;
	int			equipped;
	int			tokens;
};
typedef struct struct_carry	carry_s;	/* ownership of items */


/*
 * Variables
 */
extern item_s	*item_list;


/*
 * Prototypes
 */
extern void	load_items(void);
extern void	adjust_items(void);
extern item_s	*item_from_tag(int);
extern void	free_carry_instance(carry_s *);
extern carry_s	*new_carry_instance(void);


#endif/*overlord_item_h*/
