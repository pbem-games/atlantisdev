/* $Id: combat.h,v 1.3 1998/11/23 13:41:03 archer Exp $
 *	Combat-related values for items and skills
 */
#ifndef overlord_combat_h
#define overlord_combat_h
#include "typedef.h"
/*
 * Combat attributes
 */
struct struct_combat {
	stats_s		action;		/* action produce */
	stats_s		bonus;		/* bonus to base skills */
	char		target;		/* target of action */
	char		range;		/* range of action */
	char		effect;		/* effect of action */
#define COMBAT_EFFECT_MELEE	1
#define COMBAT_EFFECT_RANGED	2
#define COMBAT_EFFECT_SPECIAL	3
	char		damage;		/* damage type */
	char		strength;	/* hit points per damage */
};

typedef struct struct_combat	combat_s;	/* combat effects */


/**
 ** Prototypes
 **/
extern void	combat_attributes(combat_s *);


#endif/*overlord_combat_h*/
