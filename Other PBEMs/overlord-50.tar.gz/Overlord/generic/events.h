/* $Id: events.h,v 1.2 1998/05/17 11:31:34 archer Exp $
 *	Define the events (which is common to units and locations)
 */
#ifndef overlord_event_h
#define overlord_event_h


/**
 ** Event object
 **/

struct struct_activity {
	struct struct_activity	*next;	/* occurs in chronological order */
	char			*text;
	short			day;
#ifdef STEALTH_STATS
	short			stealth;
#endif
};

typedef struct struct_activity	event_s;	/* dated action */


/**
 ** Prototypes
 **/
extern event_s	*new_dated_event(void);


#endif/*overlord_event_h*/
