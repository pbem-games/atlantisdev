/* $Id: market.c,v 1.18 1999/11/21 15:46:09 archer Exp $
 *	Process, store and so on markets
 */
#include "turn.h"
#include "parser.h"
#include "command_u.h"


#ifndef REQUESTS_CHUNK
#define REQUESTS_CHUNK	1000
#endif

#ifndef MARKET_CHUNK
#define MARKET_CHUNK	1000
#endif

/**
 ** Special type
 **/
typedef int (*market_cmp)(request_s *,request_s *);


#ifdef USES_CASH
/**
 ** Local cache
 **/
#ifdef TURN_PROCESSOR
static request_s	*free_request_chain;
static terrain_s	*cache_market;
#endif
static market_s		*free_market_chain;


#ifdef TURN_PROCESSOR
#if 0
/**
 ** FREE_ONE_REQUEST
 **	Free the request, and all the following. Not used...
 **/
void free_one_request(request_s *old)
{
	old->next = free_request_chain;
	free_request_chain = old;
}
#endif


/**
 ** FREE_REQUEST_INSTANCE
 **	Free the request, and all the following
 **/
void free_request_instance(request_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	free_request_instance(old->next);
	old->next = free_request_chain;
	free_request_chain = old;
}


/**
 ** NEW_REQUEST_INSTANCE
 **	Allocate one request instance
 **/
request_s *new_request_instance(void)
{
request_s	*request;
int		i, j;
/*
 * Any cached request_s?
 */
	if ((request = free_request_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		request = (request_s *)malloc(sizeof(request_s)*REQUESTS_CHUNK);
		j = 0;
		for (i = 0; i < (REQUESTS_CHUNK-1); i++)
			request[i].next = request+(++j);
		free_request_chain = request;
	}
/*
 * Allocated
 */
	free_request_chain = request->next;
	memset(request, 0, sizeof(*request));
	return request;
}
#endif


/**
 ** NEW_MARKET_AT_LOCATION
 **	Allocate a new market slot pointer.
 **/
market_s *new_market_at_location(location_s *here, item_s *item)
{
market_s	*wares, *prev;
int		i, j;
/*
 * Check first
 */
	prev = 0;
	for (wares = here->markets; wares; wares = wares->next)
		if (wares->type == item)
			return wares;
		else
			prev = wares;
/*
 * No items
 */
	if (!free_market_chain) {
		free_market_chain = (market_s *)zero_malloc(sizeof(market_s)*MARKET_CHUNK);
		j = 0;
		for (i = 0; i < (MARKET_CHUNK-1); i++)
			free_market_chain[i].next = free_market_chain+(++j);
	}
	wares = free_market_chain;
	free_market_chain = wares->next;
	memset(wares, 0, sizeof(*wares));
	wares->type = item;
	wares->offered.negociated_price =
	wares->wanted.negociated_price  = 99999999;
	if (prev)
		prev->next = wares;
	else
		here->markets = wares;
	return wares;
}
#endif


#ifdef TURN_PROCESSOR
#ifdef USES_CASH
/**
 ** CLEAN_MARKET
 **	Clean market prior to a day
 **/
void clean_markets(location_s *location)
{
recruit_s	*job;
market_s	*market;
/*
 * Go
 */
	for (job = location->opportunity; job; job = job->next) {
		free_request_instance(job->wanted);
		job->wanted = 0;
	}
	for (market = location->markets; market; market = market->next) {
		free_request_instance(market->wanted.shopping);
		market->wanted.shopping = 0;
		free_request_instance(market->offered.shopping);
		market->offered.shopping = 0;
	}
}
#endif


#if defined(USES_CASH) || !defined(FIXED_WORLD)
/**
 ** DECREASING_PRICES
 **/
static int decreasing_prices(request_s *a, request_s *b)
{
	if (a->price < b->price)
		return 0;
	return 1;
}


/**
 ** INCREASING_PRICES
 **/
static int increasing_prices(request_s *a, request_s *b)
{
	if (a->price > b->price)
		return 0;
	return 1;
}


/**
 ** SORTED_MARKET
 **	Sort all requests by prices
 **/
static request_s *sorted_market(request_s *original, market_cmp compare)
{
request_s	*next;
/*
 * End of recursion
 */
	if (!original || !original->next)
		return original;
/*
 * Sort the rest
 */
	next = sorted_market(original->next, compare);
/*
 * Correctly ordered?
 */
	if ((*compare)(original, next)) {
		original->next = next;
		return original;
	}
/*
 * Nope, we have to shift things
 */
	original->next = next->next;
	next->next = sorted_market(original, compare);
	return sorted_market(next, compare);
}


/**
 ** RECURSIVE_AMOUNTS
 **	Recursively compute how many of each X are requested
 **/
static int recursive_amounts(request_s *order)
{
	if (!order)
		return 0;
	return (order->remaining_amount = recursive_amounts(order->next) + order->amount);
}
#endif


#ifndef FIXED_WORLD
/**
 ** WILL_RECRUIT_NOW
 **	A set of new recruits are added to the given unit.
 ** Create and stack if needed.
 **/
int will_recruit_now(unit_s *leader, unit_s *target, race_s *racial, int amount)
{
experience_s	*intrinsic;
experience_s	*added;
/*
 * Invocation proceeds?
 */
	if (target->size != 0 && target->race != racial) {
		return 1;
	}
/*
 * Do we activate the unit?
 */
	if (target->inactive || target->dead) {
		if (target->inactive) {
			assign_unit_id(target);
			target->same_faction = target->faction->units;
			target->faction->units = target;
		}
		stack_under(leader, target);
		target->inactive = 0;
		target->dead = 0;
		target->full_day = 1;
	}
/*
 * Summoning occurs
 */
	target->race = racial;
	target->size += amount;
	target->dead = 0;
/*
 * Skills adjustment
 */
	for (intrinsic = racial->skilled; intrinsic; intrinsic = intrinsic->next) {
		added = unit_experiences(target, intrinsic->skill, 1);
#ifdef USES_SKILL_LEVELS
		added->points += intrinsic->points * amount;
		adjust_experience(added, target->size);
#else
		added->effective = intrinsic->effective;
#endif
	}
	return 0;
}


#ifdef RECRUIT_UNITS
/**
 ** PROCESS_RECRUITMENT
 **	How many people were recruited?
 **/
void process_recruitment(location_s *location)
{
request_s	*buyer, *offers, *prospective;
recruit_s	*job;
order_s		*order;
unit_s		*unit = 0, *created;
experience_s	*skill;
#ifdef USES_TITLE_SYSTEM
long		market_cut = 0, market_excess = 0;
#endif
int		price, spend;
int		amount;
/*
 * Do the job
 */
	for (job = location->opportunity; job; job = job->next) {
		if ((buyer = job->wanted) == 0)
			continue;
/*
 * Eliminate illegal requests first!
 */
		while (buyer) {
			order = buyer->validated_order;
			if (buyer->asked->dead || buyer->asked->size == 0)
				buyer->amount = 0;
/*
 * Unit created with a different race, of with another leader!
 */
			created = order->arguments[0].unit;
			if (created->size)
				if (created->race != job->type ||
				    created->race->type == RACE_LEADER) {
					buyer->amount = 0;
					buyer->price  = 0;
				}
/*
 * Price exceeds the capacities of the payor.
 * If requested *max* figures, reduce figures accordingly
 */
			price = buyer->price;
			spend = buyer->amount * price;
			if (unit_can_pay(buyer->asked, spend)) {
				if (order->arguments[1].number == 0) {
					buyer->amount--;
					for (spend -= price; spend; spend -= price) {
						if (!unit_can_pay(buyer->asked, spend))
							break;
						buyer->amount--;
					}
				}
				if (!buyer->amount)
					buyer->price = 0;
			}
			buyer = buyer->next;
		}
/*
 * Sort by price, and forget about insufficient offers
 */
		offers = job->wanted = sorted_market(job->wanted, increasing_prices);
		(void)recursive_amounts(offers);
		while (offers && offers->price < job->price)
			offers = offers->next;
		if (!offers)
			continue;
/*
 * Inflation might occur?
 */
		price = job->price;
		prospective = offers;
		for (buyer = offers; buyer; buyer = buyer->next) {
			if (buyer->remaining_amount <= job->amount)
				break;
			if (price != buyer->price) {
				offers = buyer;
				price = buyer->price;
			}
		}
/*
 * Offers now points to the right price segment. Maybe it changed.
 * Note that we now have a new price, and unsatisfied recruiters.
 */
		if (prospective != offers) {
			printf("Inflation in %s, raised %s to $%d (recruit %d over %d)\n", location->name, job->type->name, price, offers->remaining_amount, job->amount);
			sprintf(work, "Inflation raised the price of %s to $%d, none recruited.", job->type->plural, price);
			while (prospective != offers) {
				unit_personal_event(prospective->asked, today_number, work);
				prospective = prospective->next;
			}
		}
/*
 * We now have a price and number of recruits. Satisfy the orders
 */
		for (buyer = offers; buyer; buyer = buyer->next) {
			if (!buyer->amount) {
#ifdef TRACING_REQUIRED
				if (buyer->asked->traced_unit)
					printf("%s: None to recruit\n", buyer->asked->name);
#endif
				continue;
			}
#ifdef TRACING_REQUIRED
			if (buyer->asked->traced_unit)
				printf("%s: Examined recruit\n", buyer->asked->name);
#endif
/*
 * Percentage of chances?
 */
			amount = buyer->amount;
			if (job->amount < buyer->remaining_amount) {
				amount *= job->amount;
				amount += buyer->remaining_amount / 2;
				amount /= buyer->remaining_amount;
/*
 * For a single recruit, we have to play the chances
 */
				if (amount == 0 && roll_1Dx(buyer->remaining_amount) < job->amount)
					amount = 1;
#ifdef TRACING_REQUIRED
				if (buyer->asked->traced_unit)
					printf("%s: Shrunk recruit from %d to %d\n", buyer->asked->name, buyer->amount, amount);
#endif
			}
/*
 * Pay upfront if really recruiting
 */
			unit = buyer->asked;
			if (amount) {
				order = buyer->validated_order;
				if (payment_required(unit, amount * buyer->price)) {
#ifdef TRACING_REQUIRED
					if (buyer->asked->traced_unit)
						printf("%s: Could not pay recruits\n", buyer->asked->name);
#endif
					continue;
				}
#ifdef USES_TITLE_SYSTEM
				market_cut += amount * buyer->price;
				if (buyer->price > price)
					market_excess += amount * (buyer->price - price);
#endif
				job->amount    -= amount;
				job->recruited += amount;
/*
 * Activate unit!
 */
				created = order->arguments[0].unit;
				(void)will_recruit_now(unit, created, job->type, amount);
				sprintf(work, "Recruited %d %s for %s [%s] at $%d each", amount, amount > 1 ? job->type->plural : job->type->name,
						created->name, created->id.text, buyer->price);
				unit_personal_event(unit, today_number, work);
				unit_personal_event(created, today_number, work);
/*
 * Order is at least partially processed
 */
				if (order->days == 0) {
					if (order->arguments[1].number)
						order->arguments[1].number -= amount;
					if (order->arguments[1].number > 0)
						continue;
				}
/*
 * Order is complete
 */
				order_was_executed(unit, order);
			} else {
				sprintf(work, "Too many %s recruited", job->type->plural);
				unit_personal_event(unit, today_number, work);
			}
		}
/*
 * Inflation
 */
		if (price > job->price)
			job->price = price;
	}
#ifdef USES_TITLE_SYSTEM
/*
 * Merchant prince gets its share
 */
	if (location->first_market && (unit = location->first_market->holder) != 0) {
		if (unit->coins == 0)
			unit->coins = unit_possessions(unit, item_cash, 1);
		market_cut -= market_excess;
		market_cut /= 20;	/* 5% cut for the prince */
		if (market_cut) {
			unit->coins->amount += market_cut;
			sprintf(work, "Recruitment 5%% share of %ld coins", market_cut);
			unit_personal_event(unit, today_number, work);
		}
		if (market_excess) {
			unit->coins->amount += market_excess;
			sprintf(work, "Recruitment cut of %ld coins", market_excess);
			unit_personal_event(unit, today_number, work);
		}
	}
#endif
}
#endif
#endif


#ifdef USES_CASH
/**
 ** PURCHASE_ADVANCED
 **	A purchase was made, of N items. Complete the order, and
 ** increase marketing skill, if any.
 **/
static void purchase_advanced(request_s *sale, int amount, request_s *other)
{
unit_s		*unit;
experience_s	*skill;
order_s		*order;
int		executed;
/*
 * We are called only for real sales!
 */
	unit = sale->asked;
	order = sale->validated_order;
/*
 * Decrease the amount of sold/bought for single-shot orders
 */
	executed = 1;
	if (order->days == 0 && order->arguments[0].number) {
		order->arguments[0].number -= amount;
		if (order->arguments[0].number > 0)
			executed = 0;
	}
/*
 * Order completed
 */
	if (executed)
		order_was_executed(unit, order);
/*
 * Limited to 1 day of experience per market
 */
	if (other->asked && other->asked->faction == unit->faction)
		return;
	if (amount > 10 - unit->marketer)
		amount = 10 - unit->marketer;
	if (amount) {
		unit->marketer += amount;
	}
}


/**
 ** PROCESS_MARKET
 **	Items may be bought and sold
 **/
void process_markets(location_s *location)
{
market_s	*market;
request_s	*pending;
request_s	*buyers, *sellers;
experience_s	*skilled;
carry_s		*bulk;
item_s		*item;
unit_s		*unit;
#ifdef USES_TITLE_SYSTEM
long		market_cut = 0, market_excess = 0;
#endif
int		price = 0, final, amount, amount_sell, amount_buy;
int		tempted;
/*
 * Each market will be examined in turn
 */
	for (market = location->markets; market; market = market->next) {
		if (!market->wanted.shopping && !market->offered.shopping)
			continue;
/*
 * Now, validate offers. To sell, one must have the items.
 */
		item = market->type;
		for (sellers = market->wanted.shopping; sellers; sellers = sellers->next) {
			if (sellers->asked->dead || sellers->asked->size == 0)
				sellers->amount = 0;
			if (sellers->amount) {
				bulk = unit_possessions(sellers->asked, item, 0);
				if (!bulk) {
					unit_personal_event(sellers->asked, today_number, "Items disappearead since you entered sale");
					sellers->amount = 0;
				} else
					if (bulk->amount < sellers->amount)
						sellers->amount = bulk->amount;
			}
		}
/*
 * To buy, one must have the cash.
 */
		for (buyers = market->offered.shopping; buyers; buyers = buyers->next) {
			if (buyers->asked->dead || buyers->asked->size == 0)
				buyers->amount = 0;
			if (buyers->amount &&
			    unit_can_pay(buyers->asked, (price = buyers->price * buyers->amount))) {
				sprintf(work, "Needed $%d to complete purchase", price);
				unit_personal_event(buyers->asked, today_number, work);
				buyers->amount = 0;
			}
		}
/*
 * Create local offers/demands?
 */
		if (market->offered.shopping && market->offered.amount_remains) {
			pending = new_request_instance();
			pending->price = market->offered.negociated_price;
			pending->amount = market->offered.amount_remains;
			pending->next = market->wanted.shopping;
			market->wanted.shopping = pending;
		}
		if (market->wanted.shopping && market->wanted.amount_remains) {
			pending = new_request_instance();
			pending->price = market->wanted.negociated_price;
			pending->amount = market->wanted.amount_remains;
			pending->next = market->offered.shopping;
			market->offered.shopping = pending;
		}
/*
 * Must have offer and demand to transact
 */
		if (!market->wanted.shopping || !market->offered.shopping)
			continue;
		sellers = market->wanted.shopping = sorted_market(market->wanted.shopping, decreasing_prices);
		buyers  = market->offered.shopping = sorted_market(market->offered.shopping, increasing_prices);
		(void)recursive_amounts(sellers);
		(void)recursive_amounts(buyers);
/*
 * If demand exceeds offer (or vice versa), shrink that demand or offer
 */
/*** HACK ***/
/*
 * Sellers & buyers
 */
/*
 * Now, process the effective market
 */
		while (sellers && buyers) {
			amount_sell = sellers->amount;
			amount_buy  = buyers->amount;
			if (amount_sell > amount_buy)
				amount = amount_buy;
			else
				amount = amount_sell;
/*
 * We will trade exactly AMOUNT items
 */
/*** HACK ***/
/*
 * First, check that the buyer has the cash!
 */
			if ((unit = buyers->asked) != 0) {
				price = buyers->price * amount;
				if (payment_required(unit, price)) {
					sprintf(work, "You lack the $%d required to purchase %s", price, item->plural);
					unit_personal_event(unit, today_number, work);
					buyers = buyers->next;
					continue;
				}
			}
/*
 * Next, check that the seller has the goods. Else, cancel the sale!
 */
			if (sellers->asked) {
				bulk = unit_possessions(sellers->asked, item, 0);
				if (bulk->amount < amount) {
					if (unit)
						unit->coins->amount += price;
					sprintf(work, "You lack the %s to sell", item->plural);
					unit_personal_event(sellers->asked, today_number, work);
					sellers = sellers->next;
					continue;
				}
				bulk->amount -= amount;
				if (bulk->equipped > bulk->amount) {
					bulk->equipped = bulk->amount;
					compute_unit_stats(sellers->asked);
				}
			} else {
				market->offered.amount_remains -= amount;
				if (market->offered.amount_remains < 0)
					market->offered.amount_remains = 0;
			}
/*
 * Good, the transaction now completes
 */
			final = sellers->price * amount;
#ifdef USES_TITLE_SYSTEM
			if (final < price)
				market_excess += price - final;
#endif
			if ((unit = sellers->asked) != 0) {
				if (unit->coins == 0)
					unit->coins = unit_possessions(unit, item_cash, 1);
				unit->coins->amount += final;
/*
 * Order completes?
 */
				sprintf(work, "Sold %d %s for $%d", amount, amount > 1 ? item->plural : item->name, final);
				unit_personal_event(unit, today_number, work);
				purchase_advanced(sellers, amount, buyers);
#ifdef USES_TITLE_SYSTEM
			} else
				market_cut += final;
#else
			}
#endif
			if ((unit = buyers->asked) != 0) {
				bulk = unit_possessions(unit, item, 1);
				bulk->amount += amount;
/*
 * Order completes?
 */
				sprintf(work, "Bought %d %s for $%d", amount, amount > 1 ? item->plural : item->name, price);
				unit_personal_event(unit, today_number, work);
				purchase_advanced(buyers, amount, sellers);
			} else {
#ifdef USES_TITLE_SYSTEM
				market_cut += final;
#endif
				market->wanted.amount_remains -= amount;
				if (market->wanted.amount_remains < 0)
					market->wanted.amount_remains = 0;
			}
/*
 * Advance to next buyer/seller mix
 */
			buyers->amount  -= amount;
			sellers->amount -= amount;
			market->wanted.finally_sold += amount;
			market->offered.finally_sold += amount;
			if (buyers->amount == 0)
				buyers = buyers->next;
			else
				if (sellers->amount)
					abort();
			if (sellers->amount == 0)
				sellers = sellers->next;
		}
	}
#ifdef USES_TITLE_SYSTEM
/*
 * Merchant prince gets its share
 */
	if (location->first_market && (unit = location->first_market->holder) != 0) {
		if (unit->coins == 0)
			unit->coins = unit_possessions(unit, item_cash, 1);
		market_cut /= 20;	/* 5% cut for the prince */
		if (market_cut) {
			unit->coins->amount += market_cut;
			sprintf(work, "Market 5%% share of %ld coins", market_cut);
			unit_personal_event(unit, today_number, work);
		}
		if (market_excess) {
			unit->coins->amount += market_excess;
			sprintf(work, "Market cut of %ld coins", market_excess);
			unit_personal_event(unit, today_number, work);
		}
	}
#endif
}


/**
 ** MARKET_VARIATIONS
 **	An existing market will evolve over time
 **/
static long market_variations(offer_s *offers, int variation)
{
/*
 * 1st case: Price per item is over 1000? Item lasts only one turn in market!
 */
	if (offers->negociated_price >= 1000) {
		offers->initial_amount = 0;
		return 0;
	}
/*
 * 2nd case: Only one item. It has 50% chance disappearing
 */
	if (offers->initial_amount == 1 && roll_1Dx(2) == 0) {
		offers->initial_amount = 0;
		return 0;
	}
/*
 * 3rd case: More than the initial amount were transacted!
 */
	if (offers->finally_sold >= offers->initial_amount) {
/*
 * 3rd case distinction: We *did* sell something! Price varies up, and offer/demand increase.
 * We didn't compete? Price lowers, demand lowers
 */
		if (offers->amount_remains != offers->initial_amount) {
			offers->negociated_price -= variation * (offers->negociated_price) / 20;
			offers->initial_amount += offers->initial_amount / 10;
		} else {
			offers->negociated_price -= variation * (offers->negociated_price) / 10;
			offers->initial_amount -= offers->initial_amount / 10;
		}
	} else
/*
 * 4th case: Nothing was sold at all
 */
		if (offers->finally_sold == 0) {
			offers->initial_amount *= 9;
			offers->initial_amount /= 10;
			if (offers->initial_amount && roll_1Dx(3) == 1)
				offers->initial_amount --;
			offers->negociated_price += variation * (offers->negociated_price) / 20;
		} else {
/*
 * 5th case: Transactions. Amount will vary at random
 */
			offers->initial_amount *= 15 + roll_1Dx(11);
			offers->initial_amount += 10;
			offers->initial_amount /= 20;
		}
	return offers->negociated_price * offers->initial_amount;
}


/**
 ** RANDOM_MARKET
 **	Create a market for a product, at random
 **/
static long random_market(location_s *location, long marketshare)
{
item_s		*item, *goods;
market_s	*market;
offer_s		*offer;
int		number, price;
int		max, chances;
/*
 * Find one item not already in market
 */
	goods = 0;
	number = 0;
	for (item = item_list; item; item = item->next) {
		if (!item->suggested_price)
			continue;
		for (market = location->markets; market; market = market->next)
			if (market->type == item)
				break;
		if (market && (market->offered.initial_amount || market->wanted.initial_amount))
			continue;
/*
 * If item is too expensive, it will not appear outside of cities
 */
		if (!location->outer && item->suggested_price > 300)
			continue;
		if (location->type != terrain_city && item->suggested_price > 500)
			continue;
/*
 * Item might be of interest. The cheaper, the more probable!
 */
		chances = 5 - (item->suggested_price / 60);
		if (chances < 1)
			chances = 1;
		if (item->token_multiplier)
			chances++;
		number += chances;
		if (!goods || roll_1Dx(number) < chances)
			goods = item;
	}
/*
 * Everything is already on display!
 */
	if (!goods)
		return 0;
/*
 * Add a new item for sale
 */
	market = new_market_at_location(location, goods);
/*
 * Do we sell or buy?
 */
	if (roll_1Dx(2) == 0) {
		price = 95 - roll_1Dx(20);
		price *= goods->suggested_price;
		price /= 100;
		offer = &market->offered;
	} else {
		price = 105 + roll_1Dx(20);
		price *= goods->suggested_price;
		price /= 100;
		offer = &market->wanted;
	}
/*
 * Depend on the marketshare
 */
	if (marketshare < 1500)
		max = marketshare / price;
	else
		max = 1500 / price;
	if (max < 2)
		number = 1;
	else {
		max /= 2;
		if (max > 20)
			max = 20;
		number = roll_1Dx(max) + roll_1Dx(max) + max;
	}
	offer->initial_amount = number;
	offer->negociated_price = price;
printf("Created market of %d %s at $%d in %s\n",number,goods->plural,price,location->id.text);/*** HACK ***/
	return number * price;
}


/**
 ** MARKET_EVOLUTION
 **	Market evolve over time
 **/
void market_evolution(location_s *location)
{
market_s	*market;
long		transactions, shares;
/*
 * Process only where a market exists
 */
	if (!location->first_market)
		return;
	transactions = location->population;
#ifdef USES_TITLE_SYSTEM
	if (!location->first_market->holder)
		transactions += transactions / 2;
	else
#endif
		transactions *= 2;
	shares = transactions / 2;
/*
 * 1: Process existing markets
 */
	for (market = location->markets; market; market = market->next) {
		if (market->offered.initial_amount)
			transactions -= market_variations(&market->offered, 1);
		if (market->wanted.initial_amount)
			transactions -= market_variations(&market->wanted, -1);
	}
	if (transactions <= 0)
		return;
/*
 * 3: Create a market for a random item
 */
	transactions -= random_market(location, transactions);
	while (transactions > shares) {
		transactions -= random_market(location, transactions);
		shares += shares / 4;
	}
	if (transactions > 0)
		printf("Marketshare remains on %s for $%ld\n", location->id.text, transactions);
}


/**
 ** MARKET_CHECK
 **	Is there a market locally? Are there any resources?
 **/
void market_check(location_s *local)
{
location_s	*global;
/*
 * Find the market terrain
 */
	if (!cache_market) {
		synthetic_tag("mrkt");
		cache_market = terrain_from_tag(0);
	}
/*
 * Is this a market?
 */
	if (local->type != cache_market || local->partial)
		return;
	global = local->outer;
	if (global->first_market)
		return;
	global->first_market = local;
	if (global->population < 1000)
		global->market_days = 30;
	else
		if (global->population < 5000)
			global->market_days = 15;
		else
			if (global->population < 10000)
				global->market_days = 10;
			else
				if (global->population < 20000)
					global->market_days = 5;
				else
					global->market_days = 3;
}
#endif
#endif
