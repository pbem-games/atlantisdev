/* $Id: argument.h,v 1.2 1998/11/26 15:52:42 archer Exp $
 *	Define the generic argument pointer
 */
#ifndef overload_argument_h
#define overload_argument_h

/**
 ** Arguments types
 **/
#define ARGUMENT_IS_EMPTY		0
#define ARGUMENT_IS_UNIT_ID		1
#define ARGUMENT_IS_LOCATION_ID		(ARGUMENT_IS_UNIT_ID+1)
#define ARGUMENT_IS_ITEM_TAG		(ARGUMENT_IS_LOCATION_ID+1)
#define ARGUMENT_IS_SKILL_TAG		(ARGUMENT_IS_ITEM_TAG+1)
#define ARGUMENT_IS_RACE_TAG		(ARGUMENT_IS_SKILL_TAG+1)
#define ARGUMENT_IS_TERRAIN_TAG		(ARGUMENT_IS_RACE_TAG+1)
#define ARGUMENT_IS_FACTION_ID		(ARGUMENT_IS_TERRAIN_TAG+1)
#define ARGUMENT_IS_TITLE_TAG		(ARGUMENT_IS_FACTION_ID+1)
/*
 * Argument object
 */
typedef union {
	struct struct_unit	*unit;
	struct struct_location	*location;
	item_s			*item;
	skill_s			*skill;
	race_s			*race;
	struct struct_terrain	*terrain;
	faction_s		*faction;
#ifdef USES_TITLE_SYSTEM
	title_s			*title;
#endif
	int			number;
	char			*string;
} t_argument;


#endif/*overlord_argument_h*/
