/* $Id: checker.h,v 1.1 1998/06/02 10:13:24 archer Exp $
 *	Syntax checker's particularities
 */
#include "turn.h"
#include "parser.h"

/**
 ** Global variables
 **/
extern FILE		*current_report;
extern faction_s	*current_faction;
extern int		cleared;
extern int		conditional;
extern int		days;
extern unit_s		*current_unit;
