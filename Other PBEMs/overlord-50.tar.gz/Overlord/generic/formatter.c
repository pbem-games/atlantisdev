/* $Id: formatter.c,v 1.4 1998/12/12 16:32:31 archer Exp $
 *	Report formatting
 */
#include "turn.h"
#include "formatter.h"


/**
 ** Global variable
 **/
char	header_character;
char	comma[] = ", ";


/**
 ** START_FOLD_STRING
 **/
void start_fold_string(char *text)
{
	if (text)
		strcpy(work, text);
	else
		work[0] = 0;
	string_ptr = work+strlen(work);
}

#define empty_fold_string()	string_ptr = work
#define add_fold_char(c)	*string_ptr++=(c)

/**
 ** ADD_FOLD_STRING
 **/
void add_fold_string(char *text)
{
	if (!text)
		return;
	while (*text)
		*string_ptr++ = *text++;
}


/**
 ** ADD_FOLD_TAG
 **/
void add_fold_tag(t_tag *t)
{
	add_fold_char(' ');
	add_fold_char('[');
	add_fold_string(t->text);
	add_fold_char(']');
}


/**
 ** ADD_FOLD_INTEGER
 **/
void add_fold_integer(int i)
{
	if (i < 0) {
		add_fold_char('-');
		i = -i;
	}
	if (i > 9)
		add_fold_integer(i/10);
	add_fold_char((i%10) + '0');
}


/**
 ** ADD_FOLD_SIGNED
 **/
void add_fold_signed(int i)
{
	if (i < 0) {
		add_fold_char('-');
		i = -i;
	} else
		if (i > 0)
			add_fold_char('+');
	if (i > 9)
		add_fold_integer(i/10);
	add_fold_char((i%10) + '0');
}


/**
 ** ADD_FOLD_LONG
 **/
void add_fold_long(long i)
{
	if (i < 0) {
		add_fold_char('-');
		i = -i;
	}
	if (i > 9)
		add_fold_long(i/10);
	add_fold_char((i%10) + '0');
}


/**
 ** ADD_FOLD_ITEM_AMOUNT
 **	Special formatting
 **/
void add_fold_item_amount(int amount, item_s *type)
{
	add_fold_integer(amount);
	add_fold_char(' ');
	if (amount > 1)
		add_fold_string(type->plural);
	else {
#ifdef UNIQUE_ARTEFACTS
/*
 * For unique items, quantity is not needed
 */
		if (type->unique)
			string_ptr -= 2;
#endif
		add_fold_string(type->name);
	}
	if (type->item_type == ITEM_ITEM)
		add_fold_tag(&type->tag);
}


/**
 ** PRINT_FOLDED
 **/
void print_folded(FILE *report, int margins)
{
int	len;
int	columns;
char	*print;
/*
 * First, terminate the string
 */
	*string_ptr = 0;
	print = work;
	len = strlen(work);
	columns = 76;
	if (header_character)
		columns -= margins;
/*
 * Go!
 */
	while (len >= columns) {
		while (columns >= 0)
			if (isspace(print[columns]))
				break;
			else
				columns--;
		if (columns <= 0)
			break;
		while (columns--) {
			putc(*print++, report);
			len--;
		}
		putc('\n', report);
		if (header_character)
			putc(header_character, report);
		for (columns = margins; columns; columns--)
			putc(' ', report);
		columns = 76-margins;
		while (isspace(*print)) {
			len--;
			print++;
		}
	}
	fprintf(report, "%s\n", print);
}


/**
 ** ENSURE_PRINT_FOLDED
 **	Protect against overload
 **/
void ensure_print_folded(FILE *report, int margin, char *pre)
{
	if (string_ptr - work > 8000) {
		print_folded(report, margin);
		start_fold_string(pre);
	}
}
