/* $Id: faction.h,v 1.16 1999/11/21 15:46:08 archer Exp $
 *	Define the internals about a faction, and how it is manipulated
 */
#ifndef overload_faction_h
#define overload_faction_h

/**
 ** Faction objects
 **/
#ifdef REPORTS_ITEM_KNOWLEDGE
typedef struct struct_item_known {
	struct struct_item_known	*next;
	item_s				*about;
	int				report;
} itemknow_s;

extern itemknow_s	*new_item_knowledge(void);
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
typedef struct struct_skill_known {
	struct struct_skill_known	*next;
	skill_s				*about;
#ifdef USES_SKILL_LEVELS
	int				from_level;
	int				at_level;
#else
	int				report;
#endif
} skillknow_s;

extern skillknow_s	*new_skill_knowledge(void);
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
typedef struct struct_race_known {
	struct struct_race_known	*next;
	race_s				*about;
	int				report;
} raceknow_s;

extern raceknow_s	*new_race_knowledge(void);
#endif


typedef struct struct_stance {
	struct struct_stance	*next;
	struct struct_faction	*faction;
#ifdef STANCE_TOWARD_UNITS
	struct struct_unit	*unit;
#endif
	char			attitude;
#define ATTITUDE_IS_ALLY	0
#define ATTITUDE_IS_FRIEND	1
#define ATTITUDE_IS_NEUTRAL	2
#define ATTITUDE_IS_HOSTILE	3
#define ATTITUDE_IS_ENNEMY	4
} stance_s;


struct struct_faction {
	t_tag			id;
	struct struct_faction	*next;
	struct struct_faction	*next_side;
	char			*e_mail;
	char			*password;
	char			*name;
	struct struct_unit	*units;
#ifdef ORDERS_NEEDED
	stance_s		*stances;
#ifdef REPORTS_ITEM_KNOWLEDGE
	itemknow_s		*known_items;
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
	skillknow_s		*known_skills;
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
	raceknow_s		*known_races;
#endif
	struct struct_location	*headquarters;
	event_s			*globals;
#ifdef USES_FACTION_FUND
	int			faction_fund;
	int			turn_rewards;
#endif
#ifdef USES_FATE_POINTS
	int			fate_points;
#endif
#ifdef USES_CONTROL_POINTS
	int			control_bonus,
				control_max,
				control_current;
#endif
#ifdef REPORTS_RANKINGS
	int			faction_skill,
				faction_size,
				faction_strength,
				faction_wealth,
				faction_worth;
#ifdef USES_MANA_POINTS
	int			faction_mana;
	int			mage_mana;
#endif
#ifdef USES_TITLE_SYSTEM
	int			faction_titles;
#endif
#endif
	char			attitude;
	char			has_enemies;
	char			setting_terse;
	char			npc;
	char			attacking, defending;
#endif
};
typedef struct struct_faction	faction_s;	/* the player faction */


/*
 * Variables
 */
extern faction_s	*faction_list;


/*
 * Prototypes
 */
extern void		load_factions(void);
extern void		save_factions(void);
extern void		adjust_factions(void);
extern stance_s		*find_stance_for(faction_s *,faction_s *,int);
extern char		*player_specific_file(faction_s *,char *);
extern faction_s	*faction_from_id(int);
extern void		faction_knows_item(faction_s *,item_s *);
extern void		faction_knows_skill_level(faction_s *,skill_s *,int);
extern void		faction_knows_skill(faction_s *,skill_s *);
extern void		faction_knows_race(faction_s *,race_s *);


#endif/*overlord_faction_h*/
