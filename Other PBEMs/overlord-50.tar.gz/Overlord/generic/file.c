/* $Id: file.c,v 1.5 1998/03/20 13:57:49 archer Exp $
 *	File routines. Include file access proper and parsing subroutines
 */
#include "overlord.h"
#include "file.h"


/*
 * Global variables
 */
char		work[8192];


/**
 ** FILE_GETS
 **	Reads a line from a file.  If we go above 8k, something's very wrong!
 **/
int file_gets(FILE *stream)
{
char	*tail;
/*
 * Use standard stdio
 */
	if (!fgets(work, sizeof(work), stream))
		return 0;
	string_ptr = work;
/*
 * Strip trailing \n and all spaces
 */
	tail = work + strlen(work) - 1;
	for (*tail-- = 0; tail > work; tail--)
		if (!isspace(*tail))
			break;
/*
 * String truncated
 */
	tail[1] = 0;
	return 1;
}


/**
 ** NEW_FILE
 **	Return the same file name, with ".new" added
 **/
char *new_file(char *old)
{
static char	path[256];	/* to be sure */
/*
 * Quick'n dirty
 */
	sprintf(path, "%s.new", old);
	return path;
}
