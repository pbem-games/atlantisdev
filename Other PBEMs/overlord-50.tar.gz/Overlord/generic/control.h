/* $Id: control.h,v 1.2 1999/02/06 07:54:19 archer Exp $
 *	Control defines control factors, when multiple controls are
 * supported. In other circumstances, this file is purely and simply
 * ignored.
 */
#ifndef overlord_control_h
#define overlord_control_h
#include "typedef.h"
#include "fxdef.h"

/**
 ** Control structures
 **/
struct struct_loyalty {
	struct struct_loyalty	*next;
	faction_s		*faction;
#ifdef PARTIAL_CONTROLS
	int			control;
#endif
#ifdef TYPED_CONTROLS
	char			type;
#endif
};

struct struct_control {
	struct struct_control	*next;
	union {
		struct struct_unit	*unit;
		struct struct_location	*location;
	} u;
#ifdef PARTIAL_CONTROLS
	int			control;
#endif
#ifdef TYPED_CONTROLS
	char			type;
#endif
};


typedef struct struct_loyalty	loyalty_s;
typedef struct struct_control	control_s;


/**
 ** Prototypes
 **/
extern control_s	*unit_controls(struct struct_unit *, struct struct_unit *, int);
extern control_s	*unit_governs(struct struct_unit *, struct struct_location *, int);
extern control_s	*new_control_instance(void);
extern loyalty_s	*new_loyalty_instance(void);
extern void		free_control_list(control_s *);
extern void		inverse_unit_controls(void);
extern void		inverse_land_controls(void);


#endif/*overlord_control_h*/
