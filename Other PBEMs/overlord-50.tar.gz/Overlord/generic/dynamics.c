/* $Id: dynamics.c,v 1.18 1999/11/21 15:46:08 archer Exp $
 *	Dynamical evolution of the game world
 */
#include "turn.h"


#ifdef WORLD_HAS_CLIMATE
/**
 ** Climate probability tables
 **/
static int	climatic_table[][4] = {
	{ 0, 0, 0, 0},	/* standard */
	{ 40, 40, 30,  0},	/* fair */
	{ 30, 60, 20,  0},	/* sun */
	{ 20,  0, 30, 60},	/* rain */
	{ 10,  0, 15, 30},	/* wind */
	{  0,  0,  5, 10},	/* storm */
	{  0,  0,  0,  0} };

/**
 ** SELECT_CLIMATE
 **	This choose the climate for next turn
 **/
void select_climate(void)
{
location_s	*local;
direction_s	*dir;
int		rnd;
int		value;
/*
 * First, the climate
 */
	for (local = location_list; local; local = local->next) {
		if (local->type->type != TERRAIN_COUNTRY)
			continue;
#ifdef END_OF_WORLD
		value = 4 + END_OF_WORLD;
#else
		rnd = roll_1Dx(100);
		for (value = 1; value < 5; value++) {
			rnd -= climatic_table[value][season_number];
			if (rnd < 0)
				break;
		}
#endif
		local->next_climate = value;
	}
/*
 * Fix climates: around storms, fair becomes rain, sun becomes wind, and around rain, sun becomes fair
 */
	if (season_number != 3)
		for (local = location_list; local; local = local->next) {
			if (local->type->type != TERRAIN_COUNTRY)
				continue;
			switch (local->next_climate) {
			    case 5:
				for (dir = local->exits; dir; dir = dir->next)
					if (dir->toward->next_climate < 3)
						dir->toward->next_climate += 2;
				break;
			    case 3:
				for (dir = local->exits; dir; dir = dir->next)
					if (dir->toward->next_climate == 2)
						dir->toward->next_climate = 1;
			}
		}
}
#endif


/**
 ** LOCATION_EVOLVES
 **	Location values change over the time
 **/
void location_evolves(void)
{
location_s	*local;
location_s	*inner;
direction_s	*dir;
experience_s	*exp;
resource_s	*riches, *bodies;
recruit_s	*jobs;
race_s		*race;
int		rnd;
long		value, optima;
int		plus, minus;
/*
 * Optimas of population
 */
	for (local = location_list; local; local = local->next) {
		if (local->population == 0)
			continue;
		optima = 10000;
/*
 * Location itself
 *	Title (held): +5% (10%)
 *	Ressources: +0.1%/item
 */
#ifdef USES_TITLE_SYSTEM
		if (local->title)
			if (local->holder)
				optima += optima / 10;
			else
				optima += optima / 20;
#endif
		rnd = 1000;
		for (riches = local->resources; riches; riches = riches->next)
/* bones and bodies are of type ITEM_EFFECT/2 */
			if (riches->type->item_type == ITEM_EFFECT)
				rnd -= riches->amount * 3;
			else
				rnd += riches->amount;
		if (rnd < 100)
			rnd = 100;
/*
 * Optima increases with all sub-locations
 *	All sub-locations: +5%
 *	Title (held): +1% (2%)
 *	All skills: +5%
 */
		for (inner = local->inner; inner; inner = inner->next_inner) {
			optima += optima / 20;
#ifdef USES_TITLE_SYSTEM
			if (inner->title)
				if (inner->holder)
					optima += optima / 50;
				else
					optima += optima / 100;
#endif
			for (exp = inner->skills; exp; exp = exp->next)
#ifdef USES_SKILL_LEVELS
				optima += (optima * exp->level) / 20;
#else
				optima += optima / 20;
#endif
		}
		optima *= rnd;
		optima /= 1000;
/*
 * Now, adjust economy factors
 */
#ifdef DYNAMIC_ECONOMY
		value = 0;
		for (riches = local->resources; riches; riches = riches->next)
			if (riches->type == token_tax) {
				if (local->taxes) {
					rnd = (local->taxes / 2) - riches->tokens;
					if (rnd > 0) {
						rnd *= 300;
						value -= rnd / local->taxes;
					}
				}
			} else if (riches->type == token_entertain) {
				if (local->entertainment) {
					rnd = (local->entertainment / 2) - riches->tokens;
					if (rnd > 0) {
						rnd *= 350;
						value += rnd / local->entertainment;
					}
				}
			} else {
				rnd = riches->amount * riches->type->token_multiplier;
				if (rnd > 0)
					value += ((rnd - riches->tokens) * 25 ) / rnd;
			}
		value += local->economy;
		value *= 4;
		value /= 5;
		if (value < -900)
			value = -900;
		else
			if (value > 900)
				value = 900;
/*
 * Economy is memorised and drives the optima
 */
		local->economy = value;
		value += 1000;
		optima *= value;
		optima /= 1000;
#endif
/*
 * Finally, set new optima
 */
		optima *= local->type->optima;
		optima /= 10000;
		local->optima = optima;
	}
/*
 * Adjust population
 */
	for (local = location_list; local; local = local->next) {
		if ((value = local->population) == 0)
			continue;
		plus  = (local->population * roll_1Dx(100)) / 3000;
		minus = (local->population * roll_1Dx(100)) / 3000;
/*
 * Skew birth/death rates
 */
		optima = local->optima;
		if (value < optima) {
			minus /= 3;
			if (value < (optima / 3)) {
				minus = 0;
				plus++;
				plus *= 2;
			}
		} else
			if (value > optima)
				plus /= 3;
		value += plus - minus;
		local->delta = plus - minus;
/*
 * Migrations due to population pressure?
 */
		if (value > optima) {
			if (local->outer && local->outer->population) {
				rnd = ((value - optima) * roll_1Dx(100)) / 2000;
				local->outer->population += rnd;
				local->outer->migrate += rnd;
				value -= rnd;
				local->migrate -= rnd;
			}
			for (inner = local->inner; inner; inner = inner->next_inner)
				if (inner->population) {
					rnd = ((value - optima) * roll_1Dx(100)) / 2000;
					inner->population += rnd;
					inner->migrate += rnd;
					value -= rnd;
					local->migrate -= rnd;
				}
			for (dir = local->exits; dir; dir = dir->next)
				if (dir->toward->population) {
					rnd = ((value - optima) * roll_1Dx(100)) / 2000;
					dir->toward->population += rnd;
					dir->toward->migrate += rnd;
					value -= rnd;
					local->migrate -= rnd;
				}
			optima += optima / 2;
			if (value > optima)
				value -= roll_1Dx((value +5 - optima) / 3);
		}
		local->population = value;
	}
/*
 * Recruiment opportunities
 */
	for (local = location_list; local; local = local->next) {
		if ((value = local->population) > 0) {
#ifndef FIXED_WORLD
			for (jobs = local->opportunity; jobs; jobs = jobs->next) {
				race = jobs->type;
				minus = jobs->amount;
				if (race->fraction) {
					plus = value / race->fraction;
					if (!plus && roll_1Dx(race->fraction) < value)
						plus = 1;
				} else
					plus = 0;
				if (plus > race->max_recruited)
					plus = race->max_recruited;
/*
 * Deflation occurs if less than 1/3rd of recruits, and price above base
 */
				if (race->base_cost && jobs->price > race->base_cost && plus > 1) {
					if (minus > 2 * jobs->recruited) {
						rnd = 92 + roll_1Dx(5);
						rnd *= jobs->price;
						rnd += 50;
						rnd /= 100;
						if (rnd >= jobs->price)
							rnd--;
						if (rnd < race->base_cost)
							rnd = race->base_cost;
						printf("Deflation for %s in %s, $%d -> $%d\n",
								race->name, local->name, jobs->price, rnd);
						jobs->price = rnd;
					}
				}
				jobs->amount += plus - minus;
				value += minus - plus;
			}
			local->population = value;
		}
#endif
#ifdef USES_CASH
/*
 * Market processing
 */
		if (local->first_market)
			market_evolution(local);
#endif
#ifdef NECROMANCY_HOOK
/*
 * Dead bodies rot, skeletons decay
 */
		riches = location_has_resource(local, item_dead, 0);
		bodies = location_has_resource(local, item_corpse, 0);
		if (bodies) {
			bodies->amount *= 9;
			bodies->amount /= 10;
		}
		if (riches) {
			if (!bodies)
				bodies = location_has_resource(local, item_corpse, 1);
			plus  = riches->amount / 5;
			if (!plus && roll_1Dx(5) < riches->amount)
				plus++;
			bodies->amount += plus;
			riches->amount -= plus;
		}
#ifdef FX_CEMETARY
		if (local->type->special_effect == FX_CEMETARY) {
/*
 * Swap 30 bodies from local to cemetary
 */
			riches = location_has_resource(local->outer, item_dead, 0);
			if (riches && riches->amount) {
				bodies = location_has_resource(local, item_dead, 1);
				if (riches->amount < 30) {
					bodies->amount += riches->amount;
					riches->amount  = 0;
				} else {
					bodies->amount += 30;
					riches->amount -= 30;
				}
			} else
				bodies = 0;
/*
 * If a cemetary is present, any dead are buried there...
 */
			if ((minus = local->outer->delta) < 0) {
				if (!bodies)
					bodies = location_has_resource(local, item_dead, 1);
				bodies->amount -= minus;
#ifdef USES_TITLE_SYSTEM
				if (local->holder && local->holder->current == local) {
					sprintf(work, "The locals buried %d dead%s this month", 0-minus, minus==-1 ? "" : "s");
					unit_personal_event(local->holder, 30, work);
					if (!local->holder->coins)
						local->holder->coins = unit_possessions(local->holder, item_cash, 1);
					local->holder->coins->amount -= minus;
				}
#endif
			}
/*
 * Swap 30 bones from local to cemetary
 */
			riches = location_has_resource(local->outer, item_corpse, 0);
			if (riches && riches->amount) {
				bodies = location_has_resource(local, item_corpse, 1);
				if (riches->amount < 30) {
					bodies->amount += riches->amount;
					riches->amount  = 0;
				} else {
					bodies->amount += 30;
					riches->amount -= 30;
				}
			}
		}
#endif
#endif
/*
 * Report on devastated locations
 */
#ifdef DYNAMIC_ECONOMY
		value = local->population;
		if (!value)
			continue;
		if (local->optima*3 < local->type->optima) {
/*
 * Population is already below optima
 */
			if (local->population < local->optima) {
				local->description = "This devastated area has been deserted by its inhabitants";
				continue;
			}
/*
 * Economy is largely positive
 */
			if (local->economy > 150) {
				local->description = "People are now busy rebuilding this totally devastated area.";
				continue;
			}
			if (local->economy > 0) {
				if (local->migrate < -50)
					local->description = "Despite a steady emigration of refugees, people are already rebuilding this totally devastated region.";
				else
					local->description = "The sturdy people remaining have begun rebuilding their devastated homes.";
				continue;
			}
/*
 * Economy is negative
 */
			if (local->migrate < -100) {
				local->description = "A steady flow of refugees are fleeing this devastated location.";
				continue;
			}
			if (local->delta < 0) {
				local->description = "Plagues continue to par down the population of the devastated region.";
				continue;
			}
			if (local->migrate < 0)
				local->description = "While refugees are still fleeing their devastated homes, the situation is somehow stabilising.";
			else
				local->description = "Life is slowly returning to this dangerous and devastated area.";
			continue;
/*
 * Report on poor locations
 */
		} else if (local->optima*3 < local->type->optima*2) {
			if (local->economy > 300) {
				if (value > local->optima)
					local->description = "Valiant efforts try to stop the refugee flow from this desolated area."; 
				else
					local->description = "The courageous inhabitants are busy rebuilding this once devastated area back to former prosperity.";
			} else
				if (local->economy < -200)
					local->description = "Pillage and intolerable tax pressure contribute to the desolation that reigns over the area.";
			else
				if (local->migrate < -30)
					local->description = "People are leaving this desolate region for better lands.";
				else
					if (local->delta < 0)
						local->description = "The desolation of this region is further encouraged by plagues that sweep the area regularly.";
					else
						local->description = "Hope has kindled in this desolated area, as emigration slows and plagues recess.";
/*
 * Report on rich locations
 */
		} else if (local->optima*3 > local->type->optima*5) {
/*
 * Location is rich, but has negative economy?
 */
			if (local->economy < 0) {
				local->description = "This rich area is slowly turning seedy...";
				continue;
			}
/*
 * Rich location has a low population
 */
			if (value*3 < local->optima*2) {
				if (local->migrate > 20) {
					local->description = "Despite immigration, this rich area remains rife with opportunities.";
					continue;
				}
				if (local->delta > 0)
					local->description = "Despite its steady population growth, a lot of potential remains unrealised in this rich location.";
				else
					if (local->delta < -10)
						local->description = "A small plague outbreak had temporarily set back this rich area.";
					else
						local->description = "This rich region enjoys a relative stability.";
				continue;
			}
/*
 * Rich has topped its maximum
 */
			if (value > local->optima) {
				local->description = "This rich region has reached the peak of its prosperity.";
				continue;
			}
/*
 * Area is 90% full, or almost
 */
			if (value*10 > local->optima*9)
				local->description = "This rich area is approaching the maximum development available.";
			else
				local->description = "This area has a steady growth toward new heights of richesses.";
			continue;
/*
 * Report on prosperous locations
 */
		} else if (local->optima*3 > local->type->optima*4) {
			if (local->economy < 0)
				local->description = "This prosperous region is suffering from economic depression.";
			else
				if (value > local->optima)
					local->description = "This prosperous area has attracted far too many people.";
				else
					if (local->migrate > 0) {
						if (local->delta + local->migrate <= 0)
							local->description = "Migrations in this prosperous region barely compensate deaths from old age.";
						else
							local->description = "This prosperous area is attracting immigrants from all over the area";
					} else
						if (value * 10 < local->optima * 8)
							local->description = "The potential prosperity of the region offers many opportunities.";
						else
							local->description = "Life is good and stable in this prosperous region.";
/*
 * Report on average locations
 */
		} else {
			if (local->economy < -200) {
				if (local->migrate < 0)
					local->description = "Emigrants start to leave an area that was once prosperous.";
				else
					local->description = "An economic bust has set back this once prosperous area.";
			} else
				if (local->delta > 10)
					local->description = "A natality boom is spreading all over the region.";
				else
					if (local->delta < -10)
						local->description = "A plague is spreading thru the region, falling down the locals.";
		}
#endif
	}
}


/**
 ** LOCATION_VALUES
 **	Compute the location values
 **/
void location_values(void)
{
location_s	*local;
recruit_s	*jobs;
int		people;
/*
 * Go
 */
	for (local = location_list; local; local = local->next) {
		if (local->type->type == TERRAIN_STRUCTURE)
			continue;
/*
 * Population
 */
		people = local->population + stack_size(local->present);
#ifndef FIXED_WORLD
		for (jobs = local->opportunity; jobs; jobs = jobs->next)
			people += jobs->amount + jobs->recruited;
#endif
		local->total_figures = people;
#ifdef USES_CASH
/*
 * Entertainment is equal to 40% people, plus bonus
 */
		local->entertainment = (2*people)/5;
		local->taxes = local->population * 2;
#ifdef WORLD_HAS_CLIMATE
		if (local->outer)
			local->last_climate = local->outer->last_climate;
		switch (season_number) {
		    case 0:	/* Spring */
			local->entertainment += local->entertainment / 4;
			break;
		    case 1:	/* Summer */
			break;
		    case 2:	/* Autumn */
			local->taxes += local->population / 2;
			break;
		    case 3:	/* Winter */
			local->entertainment += local->entertainment / 2;
			break;
		}
#endif
#endif
	}
#ifdef USES_TITLE_SYSTEM
	title_ranges();
#endif
}
