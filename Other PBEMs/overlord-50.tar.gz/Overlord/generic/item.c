/* $Id: item.c,v 1.15 1999/11/21 15:46:08 archer Exp $
 *	Manipulate the item file
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"


/**
 ** Global variables
 **/
item_s	*item_list;


/**
 ** The item file
 **/
#ifndef ITEM_FILE_NAME
#define ITEM_FILE_NAME	"items"
#endif


#ifndef ITEMS_CHUNK
#define ITEMS_CHUNK	1000
#endif

/**
 ** Local cache
 **/
static carry_s	*free_carry_chain;


#ifdef REPORTS_ITEM_KNOWLEDGE
/**
 ** NEW_ITEM_KNOWLEDGE
 **	Allocate a new item knowledge. For memory efficiency, allocate by
 ** big chunks. These are never unallocated!
 **/
itemknow_s *new_item_knowledge(void)
{
static itemknow_s	*free_know_chain;
itemknow_s		*item;
int			i, j;
/*
 *
 */
	if (!free_know_chain) {
		free_know_chain = (itemknow_s *)zero_malloc(sizeof(itemknow_s)*ITEMS_CHUNK);
		j = 0;
		for (i = 0; i < (ITEMS_CHUNK-1); i++)
			free_know_chain[i].next = free_know_chain+(++j);
	}
	item = free_know_chain;
	free_know_chain = item->next;
	item->next = 0;
	return item;
}


/**
 ** FACTION_KNOWS_ITEM
 **/
void faction_knows_item(faction_s *faction, item_s *item)
{
itemknow_s		*already;
/*
 * Already known?
 */
	if (!item || item->item_type > ITEM_EFFECT)
		return;
	for (already = faction->known_items; already; already = already->next)
		if (already->about == item)
			return;
	already = new_item_knowledge();
	already->about = item;
	already->next = faction->known_items;
	faction->known_items = already;
#ifdef REPORTS_SKILL_KNOWLEDGE
#ifdef USES_SKILL_LEVELS
	faction_knows_skill_level(faction, item->equip_skill, item->equip_level);
	faction_knows_skill_level(faction, item->use_skill, 1);
#else
	faction_knows_skill(faction, item->equip_skill);
	faction_knows_skill(faction, item->use_skill);
#endif
#endif
}
#endif


/**
 ** FREE_CARRY_INSTANCE
 **	Free the carry, and all the following
 **/
void free_carry_instance(carry_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	free_carry_instance(old->next);
	old->next = free_carry_chain;
	free_carry_chain = old;
}


/**
 ** NEW_CARRY_INSTANCE
 **	Allocate one carry instance
 **/
carry_s *new_carry_instance(void)
{
carry_s	*carry;
int	i, j;
/*
 * No cached carry_s?
 */
	if ((carry = free_carry_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		carry = (carry_s *)zero_malloc(sizeof(carry_s)*ITEMS_CHUNK);
		j = 0;
		for (i = 0; i < (ITEMS_CHUNK-1); i++)
			carry[i].next = carry+(++j);
		free_carry_chain = carry;
	}
/*
 * Allocated
 */
	free_carry_chain = carry->next;
	memset(carry, 0, sizeof(*carry));
	return carry;
}


/**
 ** ITEM_FROM_TAG
 **	Returns the item pointer associated with a tag. If specified,
 **	create the item, because it is brand new.
 **/
item_s *item_from_tag(int create)
{
item_s	*scanner;
/*
 * Simple loop
 */
	for (scanner = item_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->tag.all == tag_token.all)
#else
		if (strcmp(scanner->tag.text, tag_token.text) == 0)
#endif
			return scanner;
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(item_s);
		scanner->tag = tag_token;
		scanner->next = item_list;
		item_list = scanner;
	}
	return scanner;
}


/**
 ** ADJUST_ITEM
 **	Fix the item database
 **/
void adjust_items(void)
{
item_s	*item;
/*
 * Loop on all
 */
	for (item = item_list; item; item = item->next) {
		if (!item->name)
			item->name = item->tag.text;
		if (!item->plural)
			item->plural = item->name;
	}
}


/**
 ** LOAD_ITEMS
 **	Load the items file.  This must be called exactly once, and no
 **	more.
 **/
void load_items(void)
{
FILE	*items;
item_s	*current_item = 0;
int	number;
/*
 * Start loading
 */
	if ((items = fopen(ITEM_FILE_NAME, "r")) == 0)
		fatal_error(ITEM_FILE_NAME);
/*
 */
	while (file_gets(items)) {
		if (strcmp(work, "END") == 0)
			break;
		if (keyword("ITEM")) {
			if (separate_tag())
				current_item = item_from_tag(1);
			else
				current_item = 0;
			continue;
		}
		if (!current_item)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_item->name, string_ptr);
			continue;
		}
		if (keyword("PLURAL")) {
			make_a_copy_(current_item->plural, string_ptr);
			continue;
		}
#ifdef REPORTS_ITEM_KNOWLEDGE
		if (keyword("TEXT")) {
			make_a_copy_(current_item->description, string_ptr);
			continue;
		}
#endif
		if (keyword("CATEGORY")) {
			current_item->item_category = atoi(string_ptr);
			continue;
		}
		if (keyword("TYPE")) {
			current_item->item_type = atoi(string_ptr);
			continue;
		}
		if (keyword("TOKEN")) {
			current_item->token_multiplier = atoi(string_ptr);
			continue;
		}
		if (keyword("EQUIP_CATEGORY")) {
			current_item->equip_category = atoi(string_ptr);
			current_item->equip_maximum = 1;
			continue;
		}
		if (keyword("EQUIP_MAX")) {
			current_item->equip_maximum = atoi(string_ptr);
			continue;
		}
		if (keyword("EQUIP_MEN")) {
			current_item->equip_requires = atoi(string_ptr);
			continue;
		}
		if (keyword("USE_SKILL")) {
			if (separate_tag())
				current_item->use_skill = skill_from_tag(1);
			continue;
		}
		if (keyword("EQUIP_SKILL")) {
			if (separate_tag()) {
				current_item->equip_skill = skill_from_tag(1);
#ifdef USES_SKILL_LEVELS
				current_item->equip_level = atoi(string_ptr);
#endif
			}
			continue;
		}
		if (keyword("WEIGHT")) {
			current_item->weight = atol(string_ptr);
			continue;
		}
		if (keyword("CAPACITY")) {
			number = atoi(string_ptr);
			if (number < 0 || number >= MAX_MOVE_MODES)
				number = 0;
			separate_token();
			current_item->capacity[number] = atol(string_ptr);
			continue;
		}
		if (keyword("EQUIP_CAPACITY")) {
			number = atoi(string_ptr);
			if (number < 0 || number >= MAX_MOVE_MODES)
				number = 0;
			separate_token();
			current_item->equip_capacity[number] = atol(string_ptr);
			continue;
		}
		if (keyword("AUTO_EQUIP")) {
			current_item->auto_equip = 1;
			continue;
		}
		if (keyword("LIVE")) {
			current_item->item_live = 1;
			continue;
		}
		if (keyword("SPECIAL") || keyword("MAGIC")) {
			current_item->item_special = 1;
			continue;
		}
		if (keyword("PRICE")) {
			current_item->suggested_price = atoi(string_ptr);
			continue;
		}
#ifdef UNIQUE_ARTEFACTS
		if (keyword("UNIQUE")) {
			current_item->unique = 1;
			continue;
		}
#endif
#ifdef HIDE_RESOURCES
		if (keyword("HIDDEN")) {
			current_item->item_hidden = 1;
			continue;
		}
#endif
		if (keyword("FX")) {
			current_item->special_effects = atoi(string_ptr);
			continue;
		}
#ifdef ITEMS_USED_IN_BATTLE
		if (keyword("COMBAT")) {
			combat_attributes(&current_item->combat_action);
			continue;
		}
#endif
		if (stats_definition(&current_item->equip_bonus))
			continue;
	}
/*
 * Load done
 */
	fclose(items);
}
