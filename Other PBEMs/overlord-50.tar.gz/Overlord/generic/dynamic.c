/* $Id: dynamic.c,v 1.6 1999/02/06 07:54:19 archer Exp $
 *	The game world is dynamically defined.
 */
#include "turn.h"
#include "parser.h"


/**
 ** Directions
 **/
#ifdef PRIMARY_DIRECTION_EAST_WEST
char	*compass_names[] = {
	"East", "West",
#else/* PRIMARY_DIRECTION_NORTH_SOUTH */
char	*compass_names[] = {
	"North", "South",
#endif
	"NorthEast", "SouthWest",
	"SouthEast", "NorthWest",
	0 };


/**
 ** COMPASS_DIRECTION
 **	Find the direction
 **/
direction_s *compass_direction(location_s *local, int number)
{
direction_s	*dir;
/*
 * Find
 */
	for (dir = local->exits; dir; dir = dir->next)
		if (strcasecmp(dir->name, compass_names[number]) == 0)
			break;
	return dir;
}


/**
 ** LOCATION_FROM_POSITION
 **	Find from relative coordinates
 **/
location_s *location_from_position(int x,int y)
{
location_s	*list;
/*
 * Search
 */
	for (list = location_list; list; list = list->next)
		if (list->x == x && list->y == y)
			break;
	return list;
}


/**
 ** COMPASS_CONNECT
 **	Connect two locations
 **/
void compass_connect(location_s *one, location_s *two, int dir)
{
direction_s	*connector;
/*
 * Now, connect
 */
	if (!one || !two)
		return;
	if (compass_direction(one, dir) == 0) {
		printf("Connecting %s [%s] to %s [%s] thru %s\n",
				one->name, one->id.text,
				two->name, two->id.text,
				compass_names[dir]);
		connector = new_direction_from_location();
		connector->toward = two;
		if (one->type && two->type) {
			if (one->type->days >= 0 && two->type->days >= 0)
				connector->days = (one->type->days + two->type->days * 3) / 4;
			else
				connector->days = -1;
			if (one->type->mode)
				connector->mode = one->type->mode;
			if (two->type->mode)
				connector->mode = two->type->mode;
		}
		connector->name = compass_names[dir];
		connector->next = one->exits;
		one->exits = connector;
	}
	dir ^= 1;
	if (compass_direction(two, dir) == 0) {
		printf("Connecting %s [%s] to %s [%s] thru %s\n",
				two->name, two->id.text,
				one->name, one->id.text,
				compass_names[dir]);
		connector = new_direction_from_location();
		connector->toward = one;
		if (one->type && two->type) {
			if (one->type->days >= 0 && two->type->days >= 0)
				connector->days = (two->type->days + one->type->days * 3) / 4;
			else
				connector->days = -1;
			if (two->type->mode)
				connector->mode = two->type->mode;
			if (one->type->mode)
				connector->mode = one->type->mode;
		}
		connector->name = compass_names[dir];
		connector->next = two->exits;
		two->exits = connector;
	}
}


#ifdef PRIMARY_DIRECTION_EAST_WEST
/**
 ** ALL_COMPASS_CONNECT
 **	Connect in all directions
 **/
void all_compass_connect(location_s *central)
{
int	x, y, even;
/*
 * Staggered
 */
	x = central->x;
	y = central->y;
	if (y & 1)
		even = 0;
	else
		even = 1;
	compass_connect(central, location_from_position(x+1, y), 0);
	compass_connect(central, location_from_position(x-1, y), 1);
	compass_connect(central, location_from_position(x+1-even, y-1), 2);
	compass_connect(central, location_from_position(x  -even, y+1), 3);
	compass_connect(central, location_from_position(x+1-even, y+1), 4);
	compass_connect(central, location_from_position(x  -even, y-1), 5);
}


/**
 ** RECURSIVE_RELATIVE_POSITION
 **	Doing a recursion on all positions
 **/
void recursive_relative_position(location_s *local, int x, int y)
{
direction_s	*dir;
int		even;
/*
 * End of recursion
 */
	if (!local || local->x || local->y)
		return;
	local->x = x;
	local->y = y;
	if (y & 1)
		even = 0;
	else
		even = 1;
	for (dir = local->exits; dir; dir = dir->next)
		if (strcasecmp(dir->name, compass_names[0]) == 0) {
			recursive_relative_position(dir->toward, x+1, y);
		} else if (strcasecmp(dir->name, compass_names[1]) == 0) {
			recursive_relative_position(dir->toward, x-1, y);
		} else if (strcasecmp(dir->name, compass_names[2]) == 0) {
			recursive_relative_position(dir->toward, x+1-even, y-1);
		} else if (strcasecmp(dir->name, compass_names[3]) == 0) {
			recursive_relative_position(dir->toward, x-even, y+1);
		} else if (strcasecmp(dir->name, compass_names[4]) == 0) {
			recursive_relative_position(dir->toward, x+1-even, y+1);
		} else if (strcasecmp(dir->name, compass_names[5]) == 0) {
			recursive_relative_position(dir->toward, x-even, y-1);
		}
}
#else


/**
 ** ALL_COMPASS_CONNECT
 **	Connect in all directions
 **/
void all_compass_connect(location_s *central)
{
int	x, y, even;
/*
 * Staggered
 */
	x = central->x;
	y = central->y;
	if (x & 1)
		even = 0;
	else
		even = 1;
	compass_connect(central, location_from_position(x, y-1), 0);
	compass_connect(central, location_from_position(x, y+1), 1);
	compass_connect(central, location_from_position(x+1, y-even), 2);
	compass_connect(central, location_from_position(x-1, y+1-even), 3);
	compass_connect(central, location_from_position(x+1, y+1-even), 4);
	compass_connect(central, location_from_position(x-1, y-even), 5);
}


/**
 ** RECURSIVE_RELATIVE_POSITION
 **	Doing a recursion on all positions
 **/
void recursive_relative_position(location_s *local, int x, int y)
{
direction_s	*dir;
int		even;
/*
 * End of recursion
 */
	if (!local || local->x || local->y)
		return;
	local->x = x;
	local->y = y;
	if (x & 1)
		even = 0;
	else
		even = 1;
	for (dir = local->exits; dir; dir = dir->next)
		if (strcasecmp(dir->name, compass_names[0]) == 0) {
			recursive_relative_position(dir->toward, x, y-1);
		} else if (strcasecmp(dir->name, compass_names[1]) == 0) {
			recursive_relative_position(dir->toward, x, y+1);
		} else if (strcasecmp(dir->name, compass_names[2]) == 0) {
			recursive_relative_position(dir->toward, x+1, y-even);
		} else if (strcasecmp(dir->name, compass_names[3]) == 0) {
			recursive_relative_position(dir->toward, x-1, y+1-even);
		} else if (strcasecmp(dir->name, compass_names[4]) == 0) {
			recursive_relative_position(dir->toward, x+1, y+1-even);
		} else if (strcasecmp(dir->name, compass_names[5]) == 0) {
			recursive_relative_position(dir->toward, x-1, y-even);
		}
}
#endif


#ifndef USE_OVERLAND_COORDINATES
/**
 ** RELATIVE_POSITIONS_FROM
 **	Compute positions on the overland map.
 **	The pointed area is located (arbitrarily) at 1000,1000.
 **/
void relative_positions_from(location_s *location)
{
location_s	*list;
/*
 * First, wipe x/y
 */
	for (list = location_list; list; list = list->next)
		list->x = list->y = 0;
	recursive_relative_position(location, 1000, 1000);
}
#endif
