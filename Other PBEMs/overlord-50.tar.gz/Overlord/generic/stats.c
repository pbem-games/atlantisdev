/* $Id: stats.c,v 1.4 1998/11/02 15:42:55 archer Exp $
 *	Manipulate the stats in some elements
 */
#include "turn.h"
#include "parser.h"


/**
 ** STATS_DEFINITION
 **	Look at the stats file.  This must be called exactly once, and no
 **	more.
 **/
int stats_definition(stats_s *stat)
{
#ifdef USES_CASH_UPKEEP
	if (keyword("UPKEEP")) {
		stat->upkeep = atoi(string_ptr);
		return 1;
	}
#endif
#ifdef BATTLE_INITIATIVE
	if (keyword("INITIATIVE")) {
		stat->initiative = atoi(string_ptr);
		return 1;
	}
#endif
	if (keyword("MELEE")) {
		stat->melee = atoi(string_ptr);
		return 1;
	}
	if (keyword("MISSILE")) {
		stat->missile = atoi(string_ptr);
		return 1;
	}
	if (keyword("DEFENSE")) {
		stat->defense = atoi(string_ptr);
		return 1;
	}
	if (keyword("HITS")) {
		stat->hits = atoi(string_ptr);
		return 1;
	}
	if (keyword("DAMAGE")) {
		stat->damage = atoi(string_ptr);
		return 1;
	}
	if (keyword("LIFE")) {
		stat->life = atoi(string_ptr);
		return 1;
	}
#ifdef STEALTH_STATS
	if (keyword("STEALTH")) {
		stat->stealth = atoi(string_ptr);
		return 1;
	}
	if (keyword("OBSERVATION")) {
		stat->observation = atoi(string_ptr);
		return 1;
	}
#endif
#ifdef USES_MANA_POINTS
	if (keyword("MANA")) {
		stat->mana = atoi(string_ptr);
		return 1;
	}
#endif
#ifdef USES_CONTROL_POINTS
	if (keyword("CONTROL")) {
		stat->control = atoi(string_ptr);
		return 1;
	}
#endif
/*
 * Not a stats definition
 */
	return 0;
}


/**
 ** ADD_TO_STATS
 **	Adds to stats
 **/
void add_to_stats(stats_s *add_to, stats_s *added)
{
#ifdef USES_CASH_UPKEEP
	add_to->upkeep += added->upkeep;
#endif
#ifdef BATTLE_INITIATIVE
	add_to->initiative += added->initiative;
#endif
	add_to->melee += added->melee;
	add_to->missile += added->missile;
	add_to->defense += added->defense;
	add_to->life += added->life;
	add_to->damage += added->damage;
	add_to->hits += added->hits;
#ifdef STEALTH_STATS
	add_to->stealth += added->stealth;
	add_to->observation += added->observation;
#endif
#ifdef USES_MANA_POINTS
	add_to->mana += added->mana;
#endif
#ifdef USES_CONTROL_POINTS
	add_to->control += added->control;
#endif
}


/**
 ** ADD_PROPORTIONAL_STATS
 **	In a rule of thee, rounded down!
 **/
void add_proportional_stats(stats_s *add_to, stats_s *added, int equipped, int size)
{
#ifdef BATTLE_INITIATIVE
	add_to->initiative += proportional(added->initiative, equipped, size);
#endif
	add_to->melee += proportional(added->melee, equipped, size);
	add_to->missile += proportional(added->missile, equipped, size);
	add_to->defense += proportional(added->defense, equipped, size);
	add_to->life += proportional(added->life, equipped, size);
	add_to->damage += proportional(added->damage, equipped, size);
	add_to->hits += proportional(added->hits, equipped, size);
#ifdef STEALTH_STATS
	add_to->stealth += proportional(added->stealth, equipped, size);
	add_to->observation += proportional(added->observation, equipped, size);
#endif
#ifdef USES_MANA_POINTS
	add_to->mana += proportional(added->mana, equipped, size);
#endif
/*
 * Note: control and upkeep are always equal to amount, not just equipped
 */
}
