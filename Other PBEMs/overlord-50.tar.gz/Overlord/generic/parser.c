/* $Id: parser.c,v 1.8 1998/09/08 08:41:20 archer Exp $
 *	Parser routines.
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"


/*
 * Global variables
 */
char		*string_ptr;
t_tag		tag_token;
t_tag		id_token;
char		token_keyword[256];


/**
 ** KEYWORD
 **	Is the keyword in the current stream? If so, skip it and return true
 **/
int keyword(char *key)
{
char	*scan;
/*
 * Compare
 */
	scan = string_ptr;
	while (*key) {
		if (*key != *scan) {
			if (!isalpha(*key) || !isalpha(*scan))
				return 0;
			if ((*key & 0x1F) != (*scan & 0x1F))
				return 0;
		}
		key++;
		scan++;
	}
	if (isalnum(*scan))
		return 0;
	while (isspace(*scan))
		scan++;
	string_ptr = scan;
	return 1;
}


/**
 ** SEPARATE_TAG
 **	The next token in sequence must be a tag/id. Isolate it
 **/
int separate_tag(void)
{
char	*dest;
char	*alternate;
int	max;
/*
 * Skip spacing
 */
	memset(&tag_token, 0, sizeof(t_tag));
	memset(&id_token, 0, sizeof(t_tag));
	while (isspace(*string_ptr))
		string_ptr++;
	dest = tag_token.text;
	max = sizeof(tag_token) - 1;
/*
 * Copy all alnum
 */
	while (*string_ptr) {
		if (max-- <= 0)
			break;
		if (!isalnum(*string_ptr))
			break;
		*dest++ = *string_ptr++;
	}
/*
 * Tag must end here
 */
	if (*string_ptr && !isspace(*string_ptr))
		return 0;
	while (isspace(*string_ptr))
		string_ptr++;
	dest = tag_token.text;
	if (!*dest)
		return 0;
/*
 * Convert to lowercase
 */
	alternate = id_token.text;
	for (; *dest; dest++) {
		*alternate = *dest;
		if (isupper(*dest))
			*dest += 'a'-'A';
		else
			if (islower(*alternate))
				*alternate += 'A'-'a';
		alternate++;
	}
	return 1;
}


/**
 ** SYNTHETIC_TAG
 **	Separate the tag, but an internal one
 **/
void synthetic_tag(char *tag)
{
char	*save;
	save = string_ptr;
	string_ptr = tag;
	(void)separate_tag();
	string_ptr = save;
}


/**
 ** SEPARATE_TOKEN
 **	The next token in sequence must be any type of keyword.
 ** If starting with a ", it may include anything up to the next
 ** "...
 **/
int separate_token(void)
{
char	*dest;
int	max;
char	sep;
/*
 * Skip spacing
 */
	while (isspace(*string_ptr))
		string_ptr++;
	dest = token_keyword;
	max = sizeof(token_keyword) - 1;
/*
 * Separator?
 */
	if (*string_ptr == '"')
		sep = *string_ptr++;
	else
		sep = 0;
/*
 * Copy all non-space
 */
	while (*string_ptr) {
		if (sep) {
			if (*string_ptr == sep) {
				string_ptr++;
				break;
			}
		} else
			if (isspace(*string_ptr))
				break;
		if (max-- <= 0)
			break;
		*dest++ = *string_ptr++;
	}
/*
 * Token must end here
 */
	if (*string_ptr && !isspace(*string_ptr))
		return 0;
	while (isspace(*string_ptr))
		string_ptr++;
	*dest = 0;
	if (!token_keyword[0])
		return 0;
	return 1;
}


/**
 ** ABBREVIATED_KEYWORD
 **	An abbreviated keyword match the uppercase characters of the
 ** full keyword.
 **/
int abbreviated_keyword(char *full, char *abbrev)
{
/*
 * Search for abbreviation - using only uppercase from name -
 */
	for (; *full; full++)
		if (!islower(*full)) {
			if (islower(*abbrev)) {
				if (*abbrev-32 != *full)
					break;
			} else
				if (*abbrev != *full)
					break;
			abbrev++;
		}
	if (!*full && !*abbrev)
		return 1;
	return 0;
}


/**
 ** PARSED_ENUM
 **	Argument must appear within the enumerated list
 **/
int parsed_enum(char *arg, char *enum_list)
{
char	*string;
int	number;
/*
 * Loop on all enums
 */
	number = 0;
	while (*enum_list) {
		for (string = arg; *enum_list; enum_list++) {
			if (*enum_list == '\n')
				break;
			if (*string != *enum_list) {
				if (!isalpha(*string) || !isalpha(*enum_list) ||
				    (*string & 0x1F) != (*enum_list & 0x1F))
					break;
			}
			string++;
		}
		if (!*enum_list || *enum_list == '\n')
			return number;
		while (*enum_list)
			if (*enum_list++ == '\n')
				break;
		number++;
	}
	return -1;
}
