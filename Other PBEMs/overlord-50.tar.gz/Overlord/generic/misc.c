/* $Id: misc.c,v 1.6 1998/06/03 20:41:19 archer Exp $
 *	Generic routines. All Overlord modules use these.
 */
#include "overlord.h"
#ifdef HAVE_MEMORY_H
#include <memory.h>
#endif
#ifdef STDC_HEADERS
#include <stdlib.h>
#endif
#include <errno.h>


/**
 ** FATAL_ERROR
 **	A fatal error occured.  Output it on stderr.
 **/
void fatal_error(char *name)
{
#ifdef MAIL_PROCESSOR
extern char	reply_address[];
#ifndef HAVE_SYS_ERRLIST
extern char	*sys_errlist[];
#endif
extern char	work[];
char		command[1024];
FILE		*p;
/*
 * Start the error reporter
 */
	sprintf(work, "Subject: Mail processing fatal error\n\n%s: %s\n", name,
			sys_errlist[errno]);
	sprintf(command, "./senderror %s", reply_address);
	if ((p = popen(command, "w")) == 0)
		perror(command);
	else {
		fprintf(p, "%s", work);
		pclose(p);
	}
	exit(1);
#else
	perror(name);
	exit(1);
#endif
}


/**
 ** ZERO_MALLOC
 **	Mallocate a block of memory, making sure it is zeroed
 **/
void *zero_malloc(size_t s)
{
void	*mem;
/*
 * Go for it
 */
	if ((mem = malloc(s)) == 0)
		fatal_error("malloc()");
	memset(mem, 0, s);
	return mem;
}


#ifndef HAVE_STRDUP
/**
 ** Missing strdup implementation
 **/
char *strdup(char *string)
{
char	*copy;
/*
 * Quick'n dirty
 */
	if ((copy = malloc(strlen(string)+1)) != 0)
		strcpy(copy, string);
	return copy;
}
#endif
