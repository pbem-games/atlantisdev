/* $Id: mail.c,v 1.13 2000/08/07 00:35:18 jtraub Exp $
 *	Mail processor.
 *	Handles incoming mail, and dispatch the appropriate data
 */
#include "overlord.h"
#include "file.h"
#include "email.h"
#include "parser.h"
#include "info.h"
#include <signal.h>
#include <errno.h>
#include <varargs.h>
#include <string.h>
#ifdef HAVE_SYSLOG
#include <syslog.h>
#endif


/**
 ** Post-process macros
 **/
#ifndef MAIL_VIRTUAL_GM
#define MAIL_VIRTUAL_GM "gm"
#endif

#ifndef MAIL_VIRTUAL_NAME
#define MAIL_VIRTUAL_NAME "server"
#endif

#ifndef MAIL_VIRTUAL_HOSTNAME
#define MAIL_VIRTUAL_HOSTNAME "rise.dragoncat.net"
#endif

#ifdef MAIL_VIRTUAL_HOST
#ifdef MAIL_PROCESS_FILES
#undef MAIL_PROCESS_FILES
#endif
#endif


/**
 ** Global addresses
 **/
char		reply_address[1024];
#ifdef MAIL_VIRTUAL_HOST
static char	mail_subject[1024];
#endif


/**
 ** Local variables
 **/
FILE *maillog;
static char		mail_log_name[] = "suspect.log";
static faction_s	*for_faction;
static unit_s		*for_unit;
#ifdef PLAYER_PRESS
static char		separator[] = "---------------------------------------------------------------------------\n";
#endif
#ifndef MAIL_PROCESS_FILES
static char		lock_file_name[256];
static char		global_lock_name[] = "lock.file";
extern char		info_file_name[];
extern char		press_file_name[];
extern char		rumor_file_name[];
static char		rumor_log_name[] = "rumor.log";


/**
 ** USER_ERROR
 **	A user error occured.  Output it thru mail, but do not exit
 **/
static void user_error(char *text)
{
FILE	*p;
/*
 * Start the error reporter
 */
	sprintf(work, "./senderror %s", reply_address);
	if ((p = popen(work, "w")) == 0)
		perror(work);
	else {
		fprintf(p, "Subject: processing error\n\n%s", text);
		pclose(p);
	}
#ifdef HAVE_SYSLOG
	syslog(LOG_INFO, "Mail processing failure \"%s\"", text);
#endif
}

static void user_ack(char *text)
{
    FILE *p;

	sprintf(work, "./senderror %s", reply_address);
	if((p = popen(work, "w")) == 0) perror(work);
	else {
		fprintf(p, "Subject: Acknowledgement\n\n%s", text);
		pclose(p);
	}
}


/**
 ** UNLOCK_ACCESS
 **	Remove the exclusive lock we did install
 **/
static void unlock_access(void)
{
	unlink(global_lock_name);
	unlink(lock_file_name);
}


/**
 ** LOCK_EXCLUSIVE
 **	Pose an exclusive lock against all other accesses
 **/
static void lock_exclusive(void)
{
FILE	*lockfile;
int	id, old_id = 0;
int	state = 0;
int	count = 0;
/*
 * First, create our own lock file
 */
	sprintf(lock_file_name, "lock.%d", getpid());
	if ((lockfile = fopen(lock_file_name, "w")) == 0)
		fatal_error(lock_file_name);
	fprintf(lockfile, "%d\n", getpid());
	fclose(lockfile);
/*
 * Now, try to get the lock
 */
	while (1) {
		if (link(lock_file_name, global_lock_name) == 0)
			break;
/*
 * there's a lock file present?
 */
		if ((lockfile = fopen(global_lock_name, "r")) == 0) {
/*
 * We can't open it. Count unsucessful attempts. If 10 quick tries
 * occur, with "can't link", "can't open", either:
 *	1: the file is there, and unreadable
 *	2: the directory is unmodifiable by us
 */
			if (state != 0)
				state = count = 0;
			count++;
			if (count < 10)
				continue;
			unlink(lock_file_name);
			fatal_error(global_lock_name);
		}
		file_gets(lockfile);
		fclose(lockfile);
/*
 * The file doesn't contain an id! File trashed!
 */
		if ((id = atoi(work)) <= 0) {
			unlink(global_lock_name);
			state = count = 0;
			continue;
		}
/*
 * Is the process there?
 */
		if (kill(id, 0) < 0 && (errno != EINVAL || errno != EPERM)) {
			if (state != 1) {
				state = 1;
				old_id = 0;
			}
/*
 * The process isn't there, but the ID is changing!
 */
			if (old_id != id) {
				old_id = id;
				continue;
			}
/*
 * The process isn't there, and ID stays: spurious lock
 */
			unlink(global_lock_name);
			continue;
		}
/*
 * The procees is present
 */
		if (state != 2) {
			state = 2;
			old_id = 0;
		}
		if (id != old_id) {
			old_id = id;
			count = 0;
		}
		count++;
/*
 * We've spent 10mn waiting. The process is still running, so
 * it's probably *not* a mail processor
 */
		if (count > 60) {
			old_id = 0;
			unlink(global_lock_name);
			continue;
		}
/*
 * Wait 5 seconds for the other processor to run
 */
		sleep(5);
	}
/*
 * We are now reasonably secure
 */
}
#endif


/**
 ** VALID_FACTION
 **	This validate the faction id & password
 **/
static void valid_faction(void)
{
/*
 * Must find a tag
 */
	if (!separate_tag()) {
		user_error("Syntax error; missing faction ID\n");	
#ifndef MAIL_PROCESS_FILES
		unlock_access();
#endif
		exit(1);
	}
	if ((for_faction = faction_from_id(0)) == 0) {
		if ((for_unit = unit_from_id(0)) == 0) {
			user_error("No such faction ID\n");
#ifndef MAIL_PROCESS_FILES
			unlock_access();
#endif
			exit(1);
		}
		for_faction = for_unit->faction;
	}
	if (for_faction->password) {
		separate_token();
		if (strcasecmp(token_keyword, for_faction->password)) {
			user_error("Invalid password\n");
#ifndef MAIL_PROCESS_FILES
		unlock_access();
#endif
			exit(1);
		}
	}
}


/**
 ** PROCESS_ORDER_FILE
 **	This is an order (or press) submission
 **/
static void process_order_file(void)
{
FILE	*orders;
int	save_turn, old_turn;
int found = 0;
/*
 * Check for turn in progress
 */
#ifndef MAIL_PROCESS_FILES
	if (access(new_file(info_file_name), 0) == 0) {
		user_error("Turn is being processed now. Wait for the turn reports.\n");
		exit(1);
	}
	lock_exclusive();
#endif
/*
 * Load faction file
 */
	load_game_info();
	load_factions();
	load_units();
	while (file_gets(stdin)) {
		if(maillog) fprintf(maillog, "%s\n", work);
/*
 * old report is requested
 */
		if (keyword("#REPORT")) {
			found = 1;
			valid_faction();
			separate_token();
			old_turn = atoi(token_keyword);
			if (old_turn < 0 || old_turn >= game_turn_number)
				continue;
			save_turn = game_turn_number;
			game_turn_number = old_turn;
			if (access(player_specific_file(for_faction, "report"), 0) == 0) {
				sprintf(work, "./sendreport %s < %s", reply_address,
						player_specific_file(for_faction, "report"));
				system(work);
			}
			game_turn_number = save_turn;
			continue;
		}
/*
 * orders are given
 */
		if (keyword("#GAME")) {
			found = 1;
			valid_faction();
			if ((orders = fopen(player_specific_file(for_faction, "order"), "w")) == 0) {
#ifndef MAIL_PROCESS_FILES
				unlock_access();
#endif
				fatal_error(player_specific_file(for_faction, "order"));
			}
			while (file_gets(stdin)) {
				if(maillog) fprintf(maillog, "%s\n", work);
				if (keyword("#END"))
					break;
				else
					fprintf(orders, "%s\n", work);
			}
			fclose(orders);
#ifndef MAIL_NO_CHECK
			sprintf(work, "./checker %s %s",
					for_faction->id.text, reply_address);
#else
			sprintf(work, "./send-ack %s %s",
					for_faction->id.text, reply_address);
#endif
			system(work);
#ifdef MAIL_PROCESS_FILES
			continue;
#else
			break;
#endif
		}
#ifdef PLAYER_PRESS
/*
 * Player makes an announcement
 */
		if (keyword("#PRESS")) {
			found = 1;
			valid_faction();
			if ((orders = fopen(press_file_name, "a")) == 0) {
#ifndef MAIL_PROCESS_FILES
				unlock_access();
#endif
				fatal_error(press_file_name);
			}
			while (file_gets(stdin)) {
				if(maillog) fprintf(maillog, "%s\n", work);
				if (keyword("#END"))
					break;
				else
					fprintf(orders, "%s\n", work);
			}
			fprintf(orders, "\n");
			if (for_unit)
				fprintf(orders, "\t\t\t%s [%s]\n", for_unit->name, for_unit->id.text);
			else
				fprintf(orders, "\t\t\t%s [%s]\n", for_faction->name, for_faction->id.text);
			fprintf(orders, separator);
			fclose(orders);
			if ((orders = fopen(player_specific_file(for_faction, press_file_name), "w")) != 0)
				fclose(orders);
			user_ack("Press submission received");
#ifdef MAIL_PROCESS_FILES
			continue;
#else
			break;
#endif
		}
/*
 * Player agitates
 */
		if (keyword("#RUMOR")) {
			FILE *log;
			int count;
			found = 1;
			valid_faction();
			if ((orders = fopen(rumor_file_name, "a")) == 0) {
#ifndef MAIL_PROCESS_FILES
				unlock_access();
#endif
				fatal_error(rumor_file_name);
			}
			log = fopen(rumor_log_name, "a");
			if(log) {
				fprintf(log, "Rumour from %s.\n", for_faction->id.text);
			}
			count = 0;
			while (file_gets(stdin)) {
				if(maillog) fprintf(maillog, "%s\n", work);
				if (keyword("#END"))
					break;
				else {
					fprintf(orders, "%s\n", work);
					if(log && count < 6) {
						fprintf(log, "%s\n", work);
						count++;
					}
				}
			}
			fprintf(orders, separator);
			if(log) {
				fprintf(log, separator);
				fclose(log);
			}
			fclose(orders);
			if ((orders = fopen(player_specific_file(for_faction, rumor_file_name), "w")) != 0)
				fclose(orders);
			user_ack("Rumor submission received");
#ifdef MAIL_PROCESS_FILES
			continue;
#else
			break;
#endif
		}
#endif
	}
	if(!found) {
		user_error("None of #GAME/#REPORT/#PRESS/#RUMOR found. Invalid submission ignored\n");
	}
#ifndef MAIL_PROCESS_FILES
	unlock_access();
#endif
}


/**
 ** EXTRACT_RFC822
 **	Extract an email address.  More complex.
 **/
static void extract_rfc822(void)
{
char	*dest;
char	mode;
/*
 * Wipe out
 */
	dest = reply_address;
	reply_address[0] = 0;
	for (mode = 0; *string_ptr; string_ptr++) {
		if (*string_ptr == mode) {
			if (dest)
				*dest = 0;
			if (mode == '>')
				return;
			if (mode != '"')
				dest = reply_address;
			mode = 0;
			continue;
		}
		if (!mode) {
			if (*string_ptr == '(') {
				mode = ')';
				if (dest)
					*dest = 0;
				dest = 0;
				continue;
			}
			if (*string_ptr == '<') {
				mode = '>';
				dest = reply_address;
				continue;
			}
			if (*string_ptr == '"') {
				mode = '"';
				continue;
			}
		}
		if (isspace(*string_ptr)) {
			if (!mode)
				dest = reply_address;
		} else
			if (dest)
				*dest++ = *string_ptr;
	}
/*
 * Finish it
 */
	if (dest && dest != reply_address)
		*dest = 0;
}


/**
 ** EXTRACT_HEADERS
 **	Extract the headers from the mail.  We make assumptions
 ** that the mail is reasonably formatted: No line breaks in from,
 ** reply-to, subject lines.  The rest is just ignored.
 **/
static void extract_headers(void)
{
/*
 * Loop till first empty line
 */
#ifdef MAIL_VIRTUAL_HOST
	mail_subject[0] = 0;
#endif
	while (file_gets(stdin)) {
		if(maillog) fprintf(maillog, "%s\n", work);
		if (!work[0])
			break;
		if (keyword("From:")) {
			if (!reply_address[0])
				extract_rfc822();
			continue;
		}
#ifdef MAIL_VIRTUAL_HOST
		if (keyword("Subject:")) {
			while (isspace(*string_ptr))
				string_ptr++;
			strcpy(mail_subject, string_ptr);
			continue;
		}
#endif
		if (keyword("Reply-to:")) {
			extract_rfc822();
			continue;
		}
	}
}


#ifdef MAIL_VIRTUAL_HOST
/**
 ** SEND_BACK_ERROR
 **/
static void send_back_error(char *text)
{
FILE	*pipe_to;
	sprintf(work, "./forward.mail %s", reply_address);
	if ((pipe_to = popen(work, "w")) == 0)
		fatal_error("forward.mail");
	fprintf(pipe_to, "Subject: %s\n", text);
	fprintf(pipe_to, "\n");
	pclose(pipe_to);
	exit(0);
}


/**
 ** FORWARD_MAIL_TO
 **	Send the mail to the real-world recipient
 **/
static void forward_mail_to(char *recipient, char *to, int anon_allow)
{
FILE		*pipe_to;
unit_s		*fm_unit;
faction_s	*fm_faction;
char		*full_name;
char		*s;
char		command[8192];
/*
 * We must check the very first line... It must be a #FROM
 * anonymisation?
 */
	load_game_info();
	full_name = 0;
	while (1) {
		if (!file_gets(stdin))
			send_back_error("Empty mail, not forwarded");
		if(maillog) fprintf(maillog, "%s\n", work);
		if (work[0] == 0)
			continue;
		if (!keyword("#FROM")) {
			if (anon_allow)
				break;
			send_back_error("Requires a #FROM or #FROM entity password");
		}
		if (!separate_tag()) {
			work[0] = 0;
			break;
		}
		if ((fm_unit = unit_from_id(0)) == 0 && (fm_faction = faction_from_id(0)) == 0)
			send_back_error("Invalid entity ID");
		if (fm_unit)
			fm_faction = fm_unit->faction;
		if (!fm_faction)
			send_back_error("Uncontrolled entity");
		if (!fm_faction->password)
			send_back_error("Non-player entity");
		separate_token();
		if (strcasecmp(token_keyword, fm_faction->password))
			send_back_error("Invalid password");
		if (fm_unit) {
			sprintf(reply_address, "%s%s", fm_unit->id.text, game_server_email);
			full_name = fm_unit->name;
		} else {
			sprintf(reply_address, "%s%s", fm_faction->id.text, game_server_email);
			full_name = fm_faction->name;
		}
		work[0] = 0;
		break;
	}
/*
 * Open the stream
 */
	sprintf(command, "./forward.mail %s", recipient);
	if ((pipe_to = popen(command, "w")) == 0)
		fatal_error("forward.mail");
/*
 * Insert very basic headers
 */
	fprintf(pipe_to, "From: %s", reply_address);
	if (full_name)
		fprintf(pipe_to, " (%s)\n", full_name);
	else
		putc('\n', pipe_to);
	fprintf(pipe_to, "To: %s@%s\n", to, MAIL_VIRTUAL_HOSTNAME);
	fprintf(pipe_to, "Subject: %s\n", mail_subject);
	putc('\n', pipe_to);
/*
 * Copy the text
 */
	if (work[0])
		fprintf(pipe_to, "%s\n", work);
	while (file_gets(stdin)) {
		if(maillog) fprintf(maillog, "%s\n", work);
		if (full_name) {
			if (strncasecmp(work, "#END", 4) == 0)
				break;
			if (work[0] == '-' && work[1] == '-') {
				for (s = work+2; *s; s++)
					if (!isspace(*s))
						break;
				if (!*s)
					break;
			}
		}
		fprintf(pipe_to, "%s\n", work);
	}
	pclose(pipe_to);
}
#endif


/**
 ** MAIN
 **	Entry point for the mail processor
 **/
int main(int argc, char **argv)
{
char		*scan;
char		path[1024];
#ifdef MAIL_VIRTUAL_HOST
char		address[1024];
t_tag		id, tag;
faction_s	*faction;
unit_s		*unit;
dead_unit_s	*dead;
#endif
/*
 * Switch our user id first thing
 */
#ifdef MAIL_USER_ID
	setuid(MAIL_USER_ID);
#endif
#ifdef HAVE_SYSLOG
	openlog("overlord", 0, LOG_USER);
#endif
#ifdef HAVE_UMASK
	umask(022);
#endif
	reply_address[0] = 0;
/*
 * Path name we are called with gives us the working directory
 */
	strcpy(path, *argv++);
	argc--;
	if (path[0] == '/' && (scan = strrchr(path, '/')) != 0)
		*scan = 0;
	else
		strcpy(path, ".");
/*
 * Do we have a virtual host?
 */
#ifdef MAIL_VIRTUAL_HOST
	if (!argc--) {
		fprintf(stderr, "No argument to mail processor!\n");
		return 1;
	}
	strcpy(address, *argv++);
	if ((scan = strchr(address, '@')) != 0)
		*scan = 0;
#endif
/*
 * Do we have a specific path name
 */
	if (argc--)
		strcpy(path, *argv++);
	if (chdir(path))
		fatal_error(path);

	maillog = fopen(mail_log_name, "a");
	if(maillog) fprintf(maillog, "----------------------------\n");
/*
 * Load the start of mail
 */
	extract_headers();
/*
 * What do we do?
 */
#ifdef MAIL_VIRTUAL_HOST
	if (strcasecmp(address, MAIL_VIRTUAL_NAME) == 0)
		process_order_file();
#ifdef MAIL_GM_ADDRESS
	else
		if (strcasecmp(address, MAIL_VIRTUAL_GM) == 0) {
			load_factions();
			load_units();
			forward_mail_to(MAIL_GM_ADDRESS, address, 1);
#endif
		} else {
		        char *saveaddy;
		        saveaddy = strdup(address);
			string_ptr = address;
			if (!separate_tag()) {
				user_error("Unknown user\n");
				return 1;
			}
			id = id_token;
			tag = tag_token;
			load_factions();
			load_units();
			id_token = id;
			tag_token = tag;
			if ((faction = faction_from_id(0)) == 0) {
				if ((unit = unit_from_id(0)) == 0) {
					if ((dead = dead_unit_existed()) != 0)
						faction = dead->faction;
				} else
					faction = unit->faction;
			}
			if (!faction) {
				user_error("Unknown game entity\n");
				if(maillog) fclose(maillog);
				return 1;
			}
			if (!faction->e_mail) {
				user_error("Non-player entity\n");
				if(maillog) fclose(maillog);
				return 1;
			}
			forward_mail_to(faction->e_mail, saveaddy, faction->npc);
		}
#else
	process_order_file();
#endif
/*
 * Done
 */
	if(maillog) fclose(maillog);
	return 0;
}
