/* $Id: stats.h,v 1.2 2000/03/20 03:53:03 jtraub Exp $
 *	Define the internals about unit stats.
 */
#ifndef overlord_stats_h
#define overlord_stats_h


/**
 ** Vital statistics
 **/
struct struct_stats {
#ifdef USES_CASH_UPKEEP
	int		upkeep;		/* upkeep costs */
#endif
#ifdef BATTLE_INITIATIVE
	int		initiative;	/* intitiative in battle*/
#endif
	int		melee,		/* melee stats */
			missile,	/* missile stats */
			defense,	/* defense stats */
			hits,		/* hit times */
			damage,		/* damage times */
			life;		/* amount of life points */
#ifdef STEALTH_STATS
	int		stealth,	/* stealthy */
			observation;	/* observation */
#endif
#ifdef USES_MANA_POINTS
	int		mana;		/* maximum mana */
#endif
#ifdef USES_CONTROL_POINTS
	int		control;	/* control points */
#endif
};

typedef struct struct_stats	stats_s;	/* battle vital stats */


/**
 ** Prototypes
 **/
extern int	stats_definition(stats_s *);
extern void	add_to_stats(stats_s *,stats_s *);
extern void	add_proportional_stats(stats_s *,stats_s *,int,int);
extern void	add_multiple_stats(stats_s *,stats_s *,int);
#ifdef TURN_PROCESSOR
#ifdef USES_MANA_POINTS
extern int	compute_max_mana(stats_s *, stats_s *, int);
#endif
#endif

#endif/*overlord_stats_h*/
