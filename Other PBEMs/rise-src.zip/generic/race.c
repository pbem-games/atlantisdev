/* $Id: race.c,v 1.2 2000/02/25 17:15:32 jtraub Exp $
 *	Manipulate the race file
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"


#ifndef RACE_CHUNK
#define RACE_CHUNK	1000
#endif


/**
 ** Global variables
 **/
race_s	*race_list;


/**
 ** The race file
 **/
#ifndef RACE_FILE_NAME
#define RACE_FILE_NAME	"races"
#endif


#ifdef REPORTS_RACIAL_KNOWLEDGE
/**
 ** NEW_RACE_KNOWLEDGE
 **	Allocate a new race knowledge. For memory efficiency, allocate by
 ** big chunks. These are never unallocated!
 **/
raceknow_s *new_race_knowledge(void)
{
static raceknow_s	*free_know_chain;
raceknow_s		*race;
int			i, j;
/*
 *
 */
	if (!free_know_chain) {
		free_know_chain = (raceknow_s *)zero_malloc(sizeof(raceknow_s)*RACE_CHUNK);
		j = 0;
		for (i = 0; i < (RACE_CHUNK-1); i++)
			free_know_chain[i].next = free_know_chain+(++j);
	}
	race = free_know_chain;
	free_know_chain = race->next;
	race->next = 0;
	return race;
}


/**
 ** FACTION_KNOWS_RACE
 **/
void faction_knows_race(faction_s *faction, race_s *race)
{
raceknow_s	*already;
#ifdef REPORTS_SKILL_KNOWLEDGE
experience_s	*skills;
#endif
/*
 * Already known?
 */
	if (!race || !faction)
		return;
	for (already = faction->known_races; already; already = already->next)
		if (already->about == race)
			return;
	already = new_race_knowledge();
	already->about = race;
	already->next = faction->known_races;
	faction->known_races = already;
#ifdef REPORTS_SKILL_KNOWLEDGE
/*
 * Intrinsic skills from race
 */
	for (skills = race->skilled; skills; skills = skills->next)
#ifdef USES_SKILL_LEVELS
		faction_knows_skill_level(faction, skills->skill, skills->level);
#else
		faction_knows_skill(faction, skills->skill);
#endif
#endif
}
#endif


/**
 ** RACE_FROM_TAG
 **	Returns the race pointer associated with a tag. If specified,
 **	create the race, because it is brand new.
 **/
race_s *race_from_tag(int create)
{
race_s	*scanner;
/*
 * Simple loop
 */
	for (scanner = race_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->tag.all == tag_token.all)
#else
		if (strcmp(scanner->tag.text, tag_token.text) == 0)
#endif
			return scanner;
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(race_s);
		scanner->tag = tag_token;
		scanner->next = race_list;
/*
 * Defaults
 */
		scanner->intrinsic.hits = 1;
		scanner->intrinsic.damage = 1;
		scanner->intrinsic.life = 1;
		race_list = scanner;
	}
	return scanner;
}


/**
 ** LOAD_RACES
 **	Load the races file.  This must be called exactly once, and no
 **	more.
 **/
void load_races(void)
{
FILE	*races;
race_s	*current_race = 0;
int	number;
/*
 * Start loading
 */
	if ((races = fopen(RACE_FILE_NAME, "r")) == 0)
		fatal_error(RACE_FILE_NAME);
/*
 */
	while (file_gets(races)) {
		if (keyword("RACE")) {
			if (separate_tag())
				current_race = race_from_tag(1);
			else
				current_race = 0;
			continue;
		}
		if (!current_race)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_race->name, string_ptr);
			continue;
		}
#ifdef REPORTS_RACIAL_KNOWLEDGE
		if (keyword("TEXT")) {
			make_a_copy_(current_race->description, string_ptr);
			continue;
		}
#endif
		if (keyword("PLURAL")) {
			make_a_copy_(current_race->plural, string_ptr);
			continue;
		}
		if (keyword("TYPE")) {
			current_race->type = atoi(string_ptr);
			continue;
		}
		if (keyword("WEIGHT")) {
			current_race->weight = atol(string_ptr);
			continue;
		}
		if (keyword("CAPACITY")) {
			number = atoi(string_ptr);
			if (number < 0 || number >= MAX_MOVE_MODES)
				number = 0;
			separate_token();
			current_race->capacity[number] = atol(string_ptr);
			continue;
		}
		if (keyword("FRACTION")) {
			current_race->fraction = atoi(string_ptr);
			continue;
		}
		if (keyword("MAXIMUM")) {
			current_race->max_recruited = atoi(string_ptr);
			continue;
		}
		if (keyword("COST")) {
			current_race->base_cost = atoi(string_ptr);
			continue;
		}
#ifdef USES_ACTION_POINTS
		if (keyword("ACTIONS")) {
			current_race->actions = atoi(string_ptr);
			continue;
		}
#endif
		if (keyword("SKILL")) {
			current_race->skilled = parse_experience_skill(current_race->skilled, 1);
			continue;
		}
#ifdef RACE_FAVOR_SKILLS
		if (keyword("FAMILIAR")) {
			current_race->favors = parse_experience_skill(current_race->favors, 1);
			continue;
		}
#endif
		if (stats_definition(&current_race->intrinsic))
			continue;
	}
/*
 * Load done
 */
	fclose(races);
}
