/* $Id: title.c,v 1.1.1.1 2000/02/04 19:39:47 jtraub Exp $
 *	Manipulate the titles file
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"
#ifdef USES_TITLE_SYSTEM


/**
 ** Global variables
 */
static title_s	*title_list;


/**
 ** The title file
 **/
#ifndef TITLE_FILE_NAME
#define TITLE_FILE_NAME	"titles"
#endif


#ifdef LOCATION_FACTION_CONTROL
/**
 ** PRE_SPREAD_TITLE
 **	Prepare the room for a spread... This cuts down the tree a lot!
 **/
static void prespread_title(unit_s *holder, location_s *land, int range)
{
direction_s	*dir;
control_s	*owns;
/*
 * End of recursion
 */
	if (range <= 0)
		return;
	range--;
/*
 * Title already applied here?
 */
	for (owns = land->control_by; owns; owns = owns->next)
		if (owns->u.unit == holder)
			break;
#ifndef PARTIAL_CONTROLS
#error Hola! TITLE&LAND_CONTROL implies PARTIAL_CONTROLS, fix config.h
#endif
	if (owns && owns->control >= range)
		return;
/*
 * New title
 */
	if (!owns) {
		owns = new_control_instance();
		owns->u.unit = holder;
		owns->next = land->control_by;
		land->control_by = owns;
	}
/*
 * Controlled at range X-1 (next pass will go all the way up to range X)
 */
	owns->control = range;
}


/**
 ** RECURSIVE_SPREAD_TITLE
 **	Apply a title to a range of locations
 **/
static void recursive_spread_title(unit_s *holder, location_s *land, int range)
{
direction_s	*dir;
location_s	*inner;
control_s	*owns;
/*
 * End of recursion
 */
	if (range <= 0)
		return;
/*
 * Title already applied here?
 */
	for (owns = land->control_by; owns; owns = owns->next)
		if (owns->u.unit == holder)
			break;
#ifndef PARTIAL_CONTROLS
#error Hola! TITLE&LAND_CONTROL implies PARTIAL_CONTROLS, fix config.h
#endif
	if (owns && owns->control >= range)
		return;
/*
 * New title
 */
	if (!owns) {
		owns = new_control_instance();
		owns->u.unit = holder;
		owns->next = land->control_by;
		land->control_by = owns;
	}
/*
 * Controlled at range X
 */
	owns->control = range;
/*
 * Pre-spread: cuts down on the controls
 */
	for (dir = land->exits; dir; dir = dir->next)
		if (dir->days > 0 && !dir->mode && !dir->skill)
			prespread_title(holder, dir->toward, range - dir->days);
	if (land->outer)
		prespread_title(holder, land->outer, range-1);
	for (inner = land->inner; inner; inner = inner->next_inner)
		prespread_title(holder, inner, range-1);
/*
 * Adjacent directions?
 */
	for (dir = land->exits; dir; dir = dir->next)
		if (dir->days > 0 && !dir->mode && !dir->skill)
			recursive_spread_title(holder, dir->toward, range - dir->days);
/*
 * Outer location? Recurse from there
 */
	if (land->outer)
		recursive_spread_title(holder, land->outer, range-1);
/*
 * Inner locations?
 */
	for (inner = land->inner; inner; inner = inner->next_inner)
		recursive_spread_title(holder, inner, range-1);
}


/**
 ** TITLE_RANGES
 **	Recompute exactly which title controls which area
 **/
void title_ranges(void)
{
location_s	*local;
/*
 * Purge all controllers
 */
	for (local = location_list; local; local = local->next) {
		free_control_list(local->control_by);
		local->control_by = 0;
	}
/*
 * Spread influence from all ranged titles
 */
	for (local = location_list; local; local = local->next)
		if (local->title && local->holder && local->title->range)
			recursive_spread_title(local->holder, local, local->title->range+1);
}
#endif


/**
 ** TITLE_FROM_TAG
 **	Returns the title pointer associated with a tag. If specified,
 **	create the title, because it is brand new.
 **/
title_s *title_from_tag(int create)
{
title_s	*scanner;
/*
 * Simple loop
 */
	for (scanner = title_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->tag.all == tag_token.all)
#else
		if (strcmp(scanner->tag.text, tag_token.text) == 0)
#endif
			return scanner;
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(title_s);
		scanner->tag = tag_token;
		scanner->next = title_list;
/*
 * Defaults
 */
		title_list = scanner;
	}
	return scanner;
}


/**
 ** LOAD_TITLES
 **	Load the titles file.  This must be called exactly once, and no
 **	more.
 **/
void load_titles(void)
{
FILE	*titles;
title_s	*current_title = 0;
/*
 * Start loading
 */
	if ((titles = fopen(TITLE_FILE_NAME, "r")) == 0)
		fatal_error(TITLE_FILE_NAME);
/*
 */
	while (file_gets(titles)) {
		if (keyword("TITLE")) {
			if (separate_tag())
				current_title = title_from_tag(1);
			else
				current_title = 0;
			continue;
		}
		if (!current_title)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_title->name, string_ptr);
			continue;
		}
		if (keyword("TYPE")) {
			current_title->type = atoi(string_ptr);
			continue;
		}
		if (keyword("COST")) {
			current_title->cost = atoi(string_ptr);
			continue;
		}
		if (keyword("SKILL")) {
			if (separate_tag())
				current_title->required = skill_from_tag(0);
			continue;
		}
#ifdef USES_SKILL_LEVELS
		if (keyword("LEVEL")) {
			current_title->level = atoi(string_ptr);
			continue;
		}
#endif
		if (keyword("RANGE")) {
			current_title->range = atoi(string_ptr);
			continue;
		}
#ifdef USES_CONTROL_POINTS
		if (keyword("CONTROL")) {
			current_title->control = atoi(string_ptr);
			continue;
		}
#endif
	}
/*
 * Load done
 */
	fclose(titles);
}
#endif/*USES_TITLE_SYSTEM*/
