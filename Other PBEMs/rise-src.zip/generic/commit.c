/* $Id: commit.c,v 1.3 2000/07/05 23:51:40 jtraub Exp $
 *	Turn commit.
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"
#include "info.h"
#include <sys/types.h>
#include <sys/stat.h>


/**
 ** This is not public except in this module
 **/
extern char	info_file_name[];
extern char	faction_file_name[];
extern char	unit_file_name[];
extern char	location_file_name[];
extern char	press_file_name[];
extern char	rumor_file_name[];


/**
 ** This is purely local
 **/
static char	admin_file_name[] = "admin";
static char	separator[] = "---------------------------------------------------------------------------\n";


/**
 ** OLD_FILE
 **	Return the same file name, with ".old" added
 **/
static char *old_file(char *current)
{
static char	path[256];	/* to be sure */
/*
 * Quick'n dirty
 */
	sprintf(path, "%s.old", current);
	return path;
}


/**
 ** MAIN
 **	Entry point for the commit
 **/
int main(int argc, char **argv)
{
FILE	*info;
FILE	*shell_script;
FILE	*paper;
faction_s *fac;
/*
 * New Info file must exist
 */
	load_game_info();
        load_factions();
	printf("Now commiting game turn %d\n", game_turn_number);
	if (access(new_file(info_file_name), 0)) {
		fprintf(stderr, "Turn was not processed!\n");
		return 1;
	}
/*
 * Create the game news paper
 */
	sprintf(work, "paper.%d", game_turn_number);
	if ((paper = fopen(work, "w")) == 0) {
		perror(work);
		exit(1);
	}
	fprintf(paper, "Subject: %s times issue %d\n", game_name, game_turn_number);
	fprintf(paper, "From: %s\n", server_email);
	fprintf(paper, "\n");
	if ((info = fopen(admin_file_name, "r")) != 0) {
		fprintf(paper, "\t\t\tAdmin info\n");
		fprintf(paper, separator);
		while (file_gets(info))
			fprintf(paper, "%s\n", work);
		fclose(info);
		fprintf(paper, separator);
	}
	fprintf(paper, "\t\t\tPlayer press\n");
	fprintf(paper, separator);
	if ((info = fopen(press_file_name, "r")) != 0) {
		while (file_gets(info))
			fprintf(paper, "%s\n", work);
		fclose(info);
	} else {
		fprintf(paper, "\t\t\tNone submitted\n");
		fprintf(paper, separator);
	}
	if ((info = fopen(rumor_file_name, "r")) != 0) {
		fprintf(paper, "\t\t\tPlayer rumors\n");
		fprintf(paper, separator);
		while (file_gets(info))
			fprintf(paper, "%s\n", work);
		fclose(info);
	}
	fclose(paper);
/*
 * First, send all the reports to Email along with the newspaper
 */
	if ((shell_script = fopen("send-it-all", "w")) == 0)
		fatal_error("send-it-all");
	fprintf(shell_script, "#!/bin/sh -x\n");
	fprintf(shell_script, "# Turn processed\n");
	for(fac = faction_list; fac; fac = fac->next) {
		char buf[256];
		if(fac->npc) continue;
		fprintf(shell_script, "\necho Faction %s\n", fac->id.text);
		fprintf(shell_script,
			"./sendreport \"%s\" < players/%s/report.%d\n",
			fac->e_mail, fac->id.text, game_turn_number);
		fprintf(shell_script, "./sendpaper \"%s\" < paper.%d\n",
			fac->e_mail, game_turn_number);
		strcpy(buf, player_specific_file(fac, "report"));
		rename(player_specific_file(fac, "newrep"), buf);
	}
	fclose(shell_script);
        chmod("send-it-all", 0777);
/*
 * Everyone was notified. Commit the database
 */
	if (rename(faction_file_name, old_file(faction_file_name)))
		perror(faction_file_name);
	if (rename(new_file(faction_file_name), faction_file_name))
		perror(faction_file_name);
	if (rename(unit_file_name, old_file(unit_file_name)))
		perror(unit_file_name);
	if (rename(new_file(unit_file_name), unit_file_name))
		perror(unit_file_name);
	if (rename(location_file_name, old_file(location_file_name)))
		perror(location_file_name);
	if (rename(new_file(location_file_name), location_file_name))
		perror(location_file_name);
	if (rename(info_file_name, old_file(info_file_name)))
		perror(info_file_name);
	if (rename(new_file(info_file_name), info_file_name))
		perror(info_file_name);
	(void)rename(admin_file_name, old_file(admin_file_name));
	(void)rename(press_file_name, old_file(press_file_name));
	(void)rename(rumor_file_name, old_file(rumor_file_name));
	return 0;
}
