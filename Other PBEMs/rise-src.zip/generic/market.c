/* $Id: market.c,v 1.14 2000/12/03 17:48:23 jtraub Exp $
 *	Process, store and so on markets
 */
#include "turn.h"
#include "parser.h"
#include "fx.h"
#include "fxdef.h"
#include "command_u.h"


#ifndef REQUESTS_CHUNK
#define REQUESTS_CHUNK	1000
#endif

#ifndef MARKET_CHUNK
#define MARKET_CHUNK	1000
#endif

/**
 ** Special type
 **/
typedef int (*market_cmp)(request_s *,request_s *);


#ifdef USES_CASH
/**
 ** Local cache
 **/
#ifdef TURN_PROCESSOR
static request_s	*free_request_chain;
static terrain_s	*cache_market;
static pot_market_s	markets[10];

#endif
static market_s		*free_market_chain;


#ifdef TURN_PROCESSOR
#if 0
/**
 ** FREE_ONE_REQUEST
 **	Free the request, and all the following. Not used...
 **/
void free_one_request(request_s *old)
{
	old->next = free_request_chain;
	free_request_chain = old;
}
#endif


/**
 ** FREE_REQUEST_INSTANCE
 **	Free the request, and all the following
 **/
void free_request_instance(request_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	free_request_instance(old->next);
	old->next = free_request_chain;
	free_request_chain = old;
}


/**
 ** NEW_REQUEST_INSTANCE
 **	Allocate one request instance
 **/
request_s *new_request_instance(void)
{
request_s	*request;
int		i, j;
/*
 * Any cached request_s?
 */
	if ((request = free_request_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		request = (request_s *)malloc(sizeof(request_s)*REQUESTS_CHUNK);
		j = 0;
		for (i = 0; i < (REQUESTS_CHUNK-1); i++)
			request[i].next = request+(++j);
		free_request_chain = request;
	}
/*
 * Allocated
 */
	free_request_chain = request->next;
	memset(request, 0, sizeof(*request));
	return request;
}
#endif


/**
 ** NEW_MARKET_AT_LOCATION
 **	Allocate a new market slot pointer.
 **/
market_s *new_market_at_location(location_s *here, item_s *item)
{
market_s	*wares, *prev;
int		i, j;
/*
 * Check first
 */
	prev = 0;
	for (wares = here->markets; wares; wares = wares->next)
		if (wares->type == item)
			return wares;
		else
			prev = wares;
/*
 * No items
 */
	if (!free_market_chain) {
		free_market_chain = (market_s *)zero_malloc(sizeof(market_s)*MARKET_CHUNK);
		j = 0;
		for (i = 0; i < (MARKET_CHUNK-1); i++)
			free_market_chain[i].next = free_market_chain+(++j);
	}
	wares = free_market_chain;
	free_market_chain = wares->next;
	memset(wares, 0, sizeof(*wares));
	wares->type = item;
	wares->offered.negociated_price =
	wares->wanted.negociated_price  = 99999999;
	if (prev)
		prev->next = wares;
	else
		here->markets = wares;
	return wares;
}
#endif


#ifdef TURN_PROCESSOR
#ifdef USES_CASH
/**
 ** CLEAN_MARKET
 **	Clean market prior to a day
 **/
void clean_markets(location_s *location)
{
recruit_s	*job;
market_s	*market;
/*
 * Go
 */
	for (job = location->opportunity; job; job = job->next) {
		free_request_instance(job->wanted);
		job->wanted = 0;
	}
	for (market = location->markets; market; market = market->next) {
		free_request_instance(market->wanted.shopping);
		market->wanted.shopping = 0;
		free_request_instance(market->offered.shopping);
		market->offered.shopping = 0;
	}
}
#endif


#if defined(USES_CASH) || !defined(FIXED_WORLD)
/**
 ** DECREASING_PRICES
 **/
static int decreasing_prices(request_s *a, request_s *b)
{
	if (a->price < b->price)
		return 0;
	return 1;
}


/**
 ** INCREASING_PRICES
 **/
static int increasing_prices(request_s *a, request_s *b)
{
	if (a->price > b->price)
		return 0;
	return 1;
}


/**
 ** SORTED_MARKET
 **	Sort all requests by prices
 **/
static request_s *sorted_market(request_s *original, market_cmp compare)
{
request_s	*next;
/*
 * End of recursion
 */
	if (!original || !original->next)
		return original;
/*
 * Sort the rest
 */
	next = sorted_market(original->next, compare);
/*
 * Correctly ordered?
 */
	if ((*compare)(original, next)) {
		original->next = next;
		return original;
	}
/*
 * Nope, we have to shift things
 */
	original->next = next->next;
	next->next = sorted_market(original, compare);
	return sorted_market(next, compare);
}


/**
 ** RECURSIVE_AMOUNTS
 **	Recursively compute how many of each X are requested
 **/
static int recursive_amounts(request_s *order)
{
	if (!order)
		return 0;
	return (order->remaining_amount = recursive_amounts(order->next) + order->amount);
}
#endif


#ifndef FIXED_WORLD
/**
 ** WILL_RECRUIT_NOW
 **	A set of new recruits are added to the given unit.
 ** Create and stack if needed.
 **/
int will_recruit_now(unit_s *leader, unit_s *target, race_s *racial, int amount)
{
experience_s	*intrinsic;
experience_s	*added;
/*
 * Invocation proceeds?
 */
	if (target->size != 0 && target->race != racial) {
		return 1;
	}
/*
 * Do we activate the unit?
 */
	if (target->inactive || target->dead) {
		if (target->inactive) {
			assign_unit_id(target);
			target->same_faction = target->faction->units;
			target->faction->units = target;
		}
		stack_under(leader, target);
		target->inactive = 0;
		target->dead = 0;
		target->full_day = 1;
	}
/*
 * Summoning occurs
 */
	target->race = racial;
	target->size += amount;
	target->dead = 0;
/*
 * Skills adjustment
 */
	for (intrinsic = racial->skilled; intrinsic; intrinsic = intrinsic->next) {
		added = unit_experiences(target, intrinsic->skill, 1);
#ifdef USES_SKILL_LEVELS
		added->points += intrinsic->points * amount;
		adjust_experience(added, target->size);
#else
		added->effective = intrinsic->effective;
#endif
	}
	return 0;
}


#ifdef RECRUIT_UNITS
/**
 ** PROCESS_RECRUITMENT
 **	How many people were recruited?
 **/
void process_recruitment(location_s *location)
{
request_s	*buyer, *offers, *prospective;
recruit_s	*job;
order_s		*order;
unit_s		*unit = 0, *created;
experience_s	*skill;
#ifdef USES_TITLE_SYSTEM
long		market_cut = 0, market_excess = 0;
#endif
int		price, spend;
int		amount;
/*
 * Do the job
 */
	for (job = location->opportunity; job; job = job->next) {
		if ((buyer = job->wanted) == 0)
			continue;
/*
 * Eliminate illegal requests first!
 */
		while (buyer) {
			order = buyer->validated_order;
			if (buyer->asked->dead || buyer->asked->size == 0)
				buyer->amount = 0;
/*
 * Unit created with a different race, of with another leader!
 */
			created = order->arguments[0].unit;
			if (created->size)
				if (created->race != job->type ||
				    created->race->type == RACE_LEADER) {
					buyer->amount = 0;
					buyer->price  = 0;
				}
/*
 * Price exceeds the capacities of the payor.
 * If requested *max* figures, reduce figures accordingly
 */
			price = buyer->price;
			spend = buyer->amount * price;
			if (unit_can_pay(buyer->asked, spend)) {
				if (order->arguments[1].number == 0) {
					buyer->amount--;
					for (spend -= price; spend; spend -= price) {
						if (!unit_can_pay(buyer->asked, spend))
							break;
						buyer->amount--;
					}
				}
				if (!buyer->amount)
					buyer->price = 0;
			}
			buyer = buyer->next;
		}
/*
 * Sort by price, and forget about insufficient offers
 */
		offers = job->wanted = sorted_market(job->wanted, increasing_prices);
		(void)recursive_amounts(offers);
		while (offers && offers->price < job->price)
			offers = offers->next;
		if (!offers)
			continue;
/*
 * Inflation might occur?
 */
		price = job->price;
		prospective = offers;
		for (buyer = offers; buyer; buyer = buyer->next) {
			if (buyer->remaining_amount <= job->amount)
				break;
			if (price != buyer->price) {
				offers = buyer;
				price = buyer->price;
			}
		}
/*
 * Offers now points to the right price segment. Maybe it changed.
 * Note that we now have a new price, and unsatisfied recruiters.
 */
		if (prospective != offers) {
			printf("Inflation in %s, raised %s to $%d (recruit %d over %d)\n", location->name, job->type->name, price, offers->remaining_amount, job->amount);
			sprintf(work, "Inflation raised the price of %s to $%d, none recruited.", job->type->plural, price);
			while (prospective != offers) {
				unit_personal_event(prospective->asked, today_number, work);
				prospective = prospective->next;
			}
		}
/*
 * We now have a price and number of recruits. Satisfy the orders
 */
		for (buyer = offers; buyer; buyer = buyer->next) {
			if (!buyer->amount) {
#ifdef TRACING_REQUIRED
				if (buyer->asked->traced_unit)
					printf("%s: None to recruit\n", buyer->asked->name);
#endif
				continue;
			}
#ifdef TRACING_REQUIRED
			if (buyer->asked->traced_unit)
				printf("%s: Examined recruit\n", buyer->asked->name);
#endif
/*
 * Percentage of chances?
 */
			amount = buyer->amount;
			if (job->amount < buyer->remaining_amount) {
				amount *= job->amount;
				amount += buyer->remaining_amount / 2;
				amount /= buyer->remaining_amount;
/*
 * For a single recruit, we have to play the chances
 */
				if (amount == 0 && roll_1Dx(buyer->remaining_amount) < job->amount)
					amount = 1;
#ifdef TRACING_REQUIRED
				if (buyer->asked->traced_unit)
					printf("%s: Shrunk recruit from %d to %d\n", buyer->asked->name, buyer->amount, amount);
#endif
			}
/*
 * Pay upfront if really recruiting
 */
			unit = buyer->asked;
			if (amount) {
				order = buyer->validated_order;
				if (payment_required(unit, amount * buyer->price)) {
#ifdef TRACING_REQUIRED
					if (buyer->asked->traced_unit)
						printf("%s: Could not pay recruits\n", buyer->asked->name);
#endif
					continue;
				}
#ifdef USES_TITLE_SYSTEM
				market_cut += amount * buyer->price;
				if (buyer->price > price)
					market_excess += amount * (buyer->price - price);
#endif
				job->amount    -= amount;
				job->recruited += amount;
/*
 * Activate unit!
 */
				created = order->arguments[0].unit;
				(void)will_recruit_now(unit, created, job->type, amount);
				sprintf(work, "Recruited %d %s for %s [%s] at $%d each", amount, amount > 1 ? job->type->plural : job->type->name,
						created->name, created->id.text, buyer->price);
				unit_personal_event(unit, today_number, work);
				unit_personal_event(created, today_number, work);
/*
 * Order is at least partially processed
 */
				if (order->days == 0) {
					if (order->arguments[1].number)
						order->arguments[1].number -= amount;
					if (order->arguments[1].number > 0)
						continue;
				}
/*
 * Order is complete
 */
				order_was_executed(unit, order);
			} else {
				sprintf(work, "Too many %s recruited", job->type->plural);
				unit_personal_event(unit, today_number, work);
			}
		}
/*
 * Inflation
 */
		if (price > job->price)
			job->price = price;
	}
#ifdef USES_TITLE_SYSTEM
/*
 * Merchant prince gets its share
 */
	if (location->first_market && (unit = location->first_market->holder) != 0) {
		if (unit->coins == 0)
			unit->coins = unit_possessions(unit, item_cash, 1);
		market_cut -= market_excess;
		market_cut /= 20;	/* 5% cut for the prince */
		if (market_cut) {
			unit->coins->amount += market_cut;
			sprintf(work, "Recruitment 5%% share of %ld coins", market_cut);
			unit_personal_event(unit, today_number, work);
		}
		if (market_excess) {
			unit->coins->amount += market_excess;
			sprintf(work, "Recruitment cut of %ld coins", market_excess);
			unit_personal_event(unit, today_number, work);
		}
	}
#endif
}
#endif
#endif


#ifdef USES_CASH
/**
 ** PURCHASE_ADVANCED
 **	A purchase was made, of N items. Complete the order, and
 ** increase marketing skill, if any.
 **/
static void purchase_advanced(request_s *sale, int amount, request_s *other)
{
unit_s		*unit;
order_s		*order;
int		executed;
/*
 * We are called only for real sales!
 */
	unit = sale->asked;
	order = sale->validated_order;
/*
 * Decrease the amount of sold/bought for single-shot orders
 */
	executed = 1;
	if (order->days == 0 && order->arguments[0].number) {
		order->arguments[0].number -= amount;
		if (order->arguments[0].number > 0)
			executed = 0;
	}
/*
 * Order completed
 */
	if (executed)
		order_was_executed(unit, order);
}


/**
 ** PROCESS_MARKET
 **	Items may be bought and sold
 **/
void process_markets(location_s *location)
{
market_s	*market;
request_s	*pending;
request_s	*buyers, *sellers;
carry_s		*bulk;
item_s		*item;
unit_s		*unit;
int has_purse;
#ifdef USES_TITLE_SYSTEM
long		market_cut = 0, market_excess = 0;
#endif
int		price = 0, final, amount, amount_sell, amount_buy;
/*
 * Each market will be examined in turn
 */
	for (market = location->markets; market; market = market->next) {
		price = 0;
		if (!market->wanted.shopping && !market->offered.shopping)
			continue;
/*
 * Now, validate offers. To sell, one must have the items.
 */
		item = market->type;
		for (sellers = market->wanted.shopping; sellers; sellers = sellers->next) {
			if (sellers->asked->dead || sellers->asked->size == 0)
				sellers->amount = 0;
			if (sellers->amount) {
				bulk = unit_possessions(sellers->asked, item, 0);
				if (!bulk) {
					unit_personal_event(sellers->asked, today_number, "Items disappearead since you entered sale");
					sellers->amount = 0;
				} else
					if (bulk->amount < sellers->amount)
						sellers->amount = bulk->amount;
			}
		}
/*
 * To buy, one must have the cash.
 */
		for (buyers = market->offered.shopping; buyers; buyers = buyers->next) {
			if (buyers->asked->dead || buyers->asked->size == 0)
				buyers->amount = 0;
			if(buyers->amount == -1) {
				buyers->amount = buyers->asked->coins->amount/buyers->price;
			}
			if (buyers->amount &&
			    unit_can_pay(buyers->asked, (price = buyers->price * buyers->amount))) {
				sprintf(work, "Needed $%d to complete purchase", price);
				unit_personal_event(buyers->asked, today_number, work);
				buyers->amount = 0;
			}
		}
/*
 * Create local offers/demands?
 */
		if (market->offered.shopping && market->offered.amount_remains) {
			pending = new_request_instance();
			pending->price = market->offered.negociated_price;
			pending->amount = market->offered.amount_remains;
			pending->next = market->wanted.shopping;
			market->wanted.shopping = pending;
		}
		if (market->wanted.shopping && market->wanted.amount_remains) {
			pending = new_request_instance();
			pending->price = market->wanted.negociated_price;
			pending->amount = market->wanted.amount_remains;
			pending->next = market->offered.shopping;
			market->offered.shopping = pending;
		}
/*
 * Must have offer and demand to transact
 */
		if (!market->wanted.shopping || !market->offered.shopping)
			continue;
		sellers = market->wanted.shopping = sorted_market(market->wanted.shopping, decreasing_prices);
		buyers  = market->offered.shopping = sorted_market(market->offered.shopping, increasing_prices);
		(void)recursive_amounts(sellers);
		(void)recursive_amounts(buyers);
/*
 * If demand exceeds offer (or vice versa), shrink that demand or offer
 */
/*** HACK ***/
/*
 * Sellers & buyers
 */
/*
 * Now, process the effective market
 */
		while (sellers && buyers) {
			if(sellers->price > buyers->price) {
				if(!buyers->asked) {
					sprintf(work, "The local market isn't willing to pay more than $%d for %s",
						buyers->price, item->plural);
				} else {
					sprintf(work, "The buyer isn't willing to pay more than $%d for %s",
						buyers->price, item->plural);
				}
				if(sellers->asked) {
					unit_personal_event(sellers->asked, today_number, work);
				}
				if(!sellers->asked) {
					sprintf(work, "The local market isn't willing to sell %s for less than $%d",
						item->plural, sellers->price);
				} else {
					sprintf(work, "The buyer isn't willing to sell %s for less than $%d",
						item->plural, sellers->price);
				}
				if(buyers->asked) {
					unit_personal_event(buyers->asked, today_number, work);
				}
				buyers = buyers->next;
				continue;
			}
			amount_sell = sellers->amount;
			amount_buy  = buyers->amount;
			if (amount_sell > amount_buy)
				amount = amount_buy;
			else
				amount = amount_sell;
/*
 * We will trade exactly AMOUNT items
 */
/*** HACK ***/
/*
 * First, check that the buyer has the cash!
 */
			if ((unit = buyers->asked) != 0) {
				price = buyers->price * amount;
				if (payment_required(unit, price)) {
					sprintf(work, "You lack the $%d required to purchase %s", price, item->plural);
					unit_personal_event(unit, today_number, work);
					buyers = buyers->next;
					continue;
				} else {
				}
			}
/*
 * Next, check that the seller has the goods. Else, cancel the sale!
 */
			if (sellers->asked) {
				bulk = unit_possessions(sellers->asked, item, 0);
				if (bulk->amount < amount) {
					if (unit)
						unit->coins->amount += price;
					sprintf(work, "You lack the %s to sell", item->plural);
					unit_personal_event(sellers->asked, today_number, work);
					sellers = sellers->next;
					continue;
				}
				bulk->amount -= amount;
				if (bulk->equipped > bulk->amount) {
					bulk->equipped = bulk->amount;
					compute_unit_stats(sellers->asked);
				}
			} else {
				market->offered.amount_remains -= amount;
				if (market->offered.amount_remains < 0)
					market->offered.amount_remains = 0;
			}
/*
 * Good, the transaction now completes
 */
			final = sellers->price * amount;
			if (final < price)
#ifdef USES_TITLE_SYSTEM
				market_excess += price - final;
#else
				final = price;
#endif

			if ((unit = sellers->asked) != 0) {
				if (unit->coins == 0)
					unit->coins = unit_possessions(unit, item_cash, 1);
				unit->coins->amount += final;
				has_purse = fx_equipped_on_unit(unit, FX_LUGNARD_PURSE);
				if(has_purse) {
					unit->coins->amount += final/10;
				}
/*
 * Order completes?
 */
				if(buyers->asked) {
					sprintf(work, "Sold %d %s for $%d to %s [%s]", amount, amount > 1 ? item->plural : item->name, final, buyers->asked->name, buyers->asked->id.text);
				} else {
					sprintf(work, "Sold %d %s for $%d to the local market", amount, amount > 1 ? item->plural : item->name, final);
				}
				unit_personal_event(unit, today_number, work);
				if(has_purse) {
					sprintf(work, "The purse's power lets you get an additional %d coins for the sale", final/10);
					unit_personal_event(unit, today_number, work);
				}
				
				purchase_advanced(sellers, amount, buyers);
#ifdef USES_TITLE_SYSTEM
			} else
				market_cut += final;
#else
			}
#endif
			if ((unit = buyers->asked) != 0) {
				bulk = unit_possessions(unit, item, 1);
				bulk->amount += amount;
/*
 * Order completes?
 */
				if(sellers->asked) {
					sprintf(work, "Bought %d %s for $%d from %s [%s]",
							amount, (amount > 1 ? item->plural : item->name),
							price, sellers->asked->name,
							sellers->asked->id.text);
				} else {
					sprintf(work, "Bought %d %s for $%d at the local market",
							amount, (amount > 1 ? item->plural : item->name),
							price);
				}
				unit_personal_event(unit, today_number, work);
				if(unit->withdrawn) {
					sprintf(work, "$%d funds used to cover purchase",
							unit->withdrawn);
					unit_personal_event(unit, today_number, work);
					unit->withdrawn = 0;
				}
				has_purse = fx_equipped_on_unit(unit, FX_LUGNARD_PURSE);
				if(has_purse) {
					if (unit->coins == 0)
						unit->coins = unit_possessions(unit, item_cash, 1);
					unit->coins->amount += final/10;
					sprintf(work, "The purse's power lets you save %d coins on the sale",
							final/10);
					unit_personal_event(unit, today_number, work);
				}
				purchase_advanced(buyers, amount, sellers);
			} else {
#ifdef USES_TITLE_SYSTEM
				market_cut += final;
#endif
				market->wanted.amount_remains -= amount;
				if (market->wanted.amount_remains < 0)
					market->wanted.amount_remains = 0;
			}
/*
 * Advance to next buyer/seller mix
 */
			buyers->amount  -= amount;
			sellers->amount -= amount;
			market->wanted.finally_sold += amount;
			market->offered.finally_sold += amount;
			if (buyers->amount == 0)
				buyers = buyers->next;
			else
				if (sellers->amount)
					abort();
			if (sellers->amount == 0)
				sellers = sellers->next;
		}
	}
#ifdef USES_TITLE_SYSTEM
/*
 * Merchant prince gets its share
 */
	if (location->first_market && (unit = location->first_market->holder) != 0) {
		if (unit->coins == 0)
			unit->coins = unit_possessions(unit, item_cash, 1);
		market_cut /= 20;	/* 5% cut for the prince */
		if (market_cut) {
			unit->coins->amount += market_cut;
			sprintf(work, "Market 5%% share of %ld coins", market_cut);
			unit_personal_event(unit, today_number, work);
		}
		if (market_excess) {
			unit->coins->amount += market_excess;
			sprintf(work, "Market cut of %ld coins", market_excess);
			unit_personal_event(unit, today_number, work);
		}
	}
#endif
}


/**
 ** Evolve a specific good
 **/
void market_evolve_good(market_s *market, location_s *location)
{
	int selling = market->offered.initial_amount;
	int buying = market->wanted.initial_amount;
	int change = 0;
	int base = selling ? selling : buying;

	market->turns--;

	if(!selling && !buying)
		return;
	if(selling && buying)
		return;

	/* Market is drying up */
	if(market->turns < 3) {
		change = -(base / 2);
		if((base & 1) && roll_1Dx(1))
			change++;
	} else {
		int neg = (location->economy < 0);
		int min, max;
		int eco = neg ? -location->economy : location->economy;
		if(eco >= 750) {
			min = base / 20;
			if(roll_1Dx(20) < (base % 20)) min++;
			max = base / 10;
			max += base / 20;
			if(roll_1Dx(10) < (base % 10)) max++;
			if(roll_1Dx(20) < (base % 20)) max++;
		} else if(eco >= 475) {
			min = 0;
			max = base / 10;
			if(roll_1Dx(10) < (base % 10)) change++;
		} else {
			max = base/20;
			if(roll_1Dx(20) < (base % 20)) max++;
			min = -max;
		}
		change = min + roll_1Dx(max-min+1);
		if(neg) change *= -1;
	}

	if((base + change) <= 0) change = 0;

	if(selling) {
		market->offered.initial_amount = base + change;
	} else {
		market->wanted.initial_amount = base + change;
	}
}

static void create_local_markets(location_s *loc, int count, int buy)
{
   int i, chance = 0, roll, x;
   item_s *item;
   location_s *inner;
   resource_s *res;
   experience_s *exp;
   consume_s *cons;
   market_s *mark;
   static terrain_s *hall;

   if(!hall) {
      synthetic_tag("hall");
      hall = terrain_from_tag(0);
   }

   for(i = 0; i < count; i++) markets[i].chance = 101;
   i = count;
   while(i) {
      for(item = item_list; item; item = item->next) {
         if(!item->market_value) continue;
         if(item->unique) continue;
         if(item == item_cash) continue;
	 if(item->nosell && !buy) continue;
         chance = 10;
	 if((item->item_category == 5) && (item->item_subcat == 1)) { /* food */
            chance += 65;
         }
	 if(loc->economy < 0) {
            if(item->market_value > 55) chance = 0;
         } else if(loc->economy >= 0 && loc->economy < 100) {
            if(item->market_value > 100) chance = 0;
	 } else if(loc->economy >= 100 && loc->economy < 300) {
            if(item->market_value < 100) chance -= 15;
            if(item->market_value > 300) chance -= 15;
         } else if(loc->economy >= 300 && loc->economy < 600) {
            if(item->market_value < 300) chance -= 15;
         } else if(loc->economy >= 600) {
            if(item->market_value >300) chance += 18;
         }
   
         /*
          * Alter the chance if it's a product/consume for our
          * hall.
          * Make sure it isn't something we (or one of our
          * inner locations produces
          */
         for(inner = loc->inner; inner; inner = inner->next_inner) {
            if(inner->type->type != TERRAIN_STRUCTURE) continue;
            for(res = inner->resources; res; res = res->next) {
               /* If this place is a guild hall */
               if(inner->type == hall) {
                  for(exp = inner->skills; exp; exp = exp->next) {
                      if(!exp->skill) continue;
                      for(cons = exp->skill->use_consumes; cons; cons = cons->next) {
                          if(cons->what == item) {
                             if(buy && chance) chance += 20;
                             else if(chance) chance -= 20;
                          }
                      }
                      if(exp->skill->harvests == item) {
                          if(buy && chance) chance += 20;
                          else if (chance) chance -= 20;
                      }
                      if(exp->skill->end_product == item) {
                          if(buy && chance) chance -= 20;
                          else if(chance) chance += 20;
                      }
                  }
               }
               if(res->type == item) chance = 0;
            }
         }
         for(mark = loc->markets; mark; mark = mark->next) {
             if(mark->type == item)  chance = 0;
             if(chance && !mark->turns &&
                ((buy && mark->wanted.initial_amount) ||
                 (!buy && mark->offered.initial_amount))) {
                if(mark->type->item_type == item->item_type &&
                   mark->type->item_category == item->item_category &&
                   mark->type->item_subcat == item->item_subcat) {
                   chance += 30;
                }
             }
         }

         /* Only give 1/2 the chance of getting a follower */
         if(item->item_type == ITEM_FOLLOWER) {
            chance /= 2;
         }

         for(res = loc->resources; res; res = res->next) {
            if(res->type == item) chance = 0;
         }

         /* Now, see how the chances look */
         if(chance <= 0) continue;
         roll = roll_1Dx(100);
         if(roll < chance) {
            /* It might be here */
            if(roll < markets[0].chance) {
               if(!markets[0].item) i--;
               markets[0].item = item;
               markets[0].chance = roll;
            }
            /* Now sort the markets in descending order of chance */
            for(x = 1; x < count; x++) {
                int t1 = markets[x].chance;
                item_s *t2 = markets[x].item;
                int y = x;
                while (y-- && markets[y].chance < t1) {
                    markets[y + 1].item = markets[y].item;
                    markets[y + 1].chance = markets[y].chance;
                }
                markets[y + 1].chance = t1;
                markets[y + 1].item = t2;
            }
         }
      }
   }
}

static int fake_root(int val)
{
   float root = val/2.0;
   int iroot = 0;
   int extra;
   float t;
   if(val == 0) return 0;
   if(val == 1) return 1;
   do {
      t = root;
      root = ((val/root) + root)/2.0;
   } while (t != root);

   iroot = (int)root;
   root *= 100;
   extra = ((int)root) % 100;
   if(roll_1Dx(100) < extra) iroot++; 
   return iroot;
}

/**
 ** MARKET_EVOLUTION
 **	Market evolve over time
 **/
void market_evolution(location_s *loc)
{
	int bought, sold, have, want;
	int stalls;
	market_s *wares;
	item_s *item;
	int price, value, count;
	int markup;

	printf("Evolving market at %s [%s] (%s)\n", loc->name,
               loc->id.text, loc->type->name);
	/* Figure out how many things are bought here */
	bought = sold = have = want = 0;
	for(wares = loc->markets; wares; wares = wares->next) {
		market_evolve_good(wares, loc);
		if(wares->offered.initial_amount) {
			sold++;
			if(!wares->turns) have++;
		}
		if(wares->wanted.initial_amount) {
			bought++;
			if(!wares->turns) want++;
		}
	}
	stalls = 0;
	if(loc->type == neutral_city) {
		stalls = 3;
	} else if(loc->type->type == TERRAIN_INNER) {
		stalls = loc->type->optima/500;
	}
	if(loc->economy >= 200) stalls++;
	if(loc->economy >= 500) stalls++;
	if(loc->economy >= 800) stalls++;
	if(loc->economy <= -200) stalls--;
	if(loc->economy <= -500) stalls--;
	if(loc->economy <= -800) stalls--;
	if(stalls <= 0 && loc->economy > 75) stalls++;

	if(stalls) {
		if(stalls > sold) {
			have++;
		}
		if(stalls > bought) {
			want++;
		}
	} else {
		have = 0;
		want = 0;
	}

	/* Wipe out the global market accumulator */
	for(stalls = 0; stalls < 10; stalls++) {
		markets[stalls].item = NULL;
		markets[stalls].chance = -1;
	}
	if(have) {
		create_local_markets(loc, have, 0);
		for(stalls = 0; stalls < have; stalls++) {
			item = markets[stalls].item;
			if(item) {
				markup = 10 + roll_1Dx(21);
				price = item->market_value * (100 + markup);
				price /= 100;
				value = (150/fake_root(price));
				count = roll_1Dx(value);
				if(count < value/2 && price < 50) {
					count = count*5/4 + 3 + roll_1Dx(value/2);
				}
				if(loc->economy < 70)
					count /= 2;
				if(count < 1) count = 1;
				wares = new_market_at_location(loc, item);
				wares->offered.amount_remains = 
				wares->offered.initial_amount = count;
				wares->offered.negociated_price = price;
				if(item->item_type == ITEM_FOLLOWER)
					value = 1 + roll_1Dx(1);
				else
					value = 15+roll_1Dx(6);
					
				wares->turns = value;
				printf("Created sell market of %d %s at $%d for %d turns.\n",
				       wares->offered.initial_amount, item->plural, wares->offered.negociated_price, wares->turns);
			}
		}
	}

	/* Wipe out the global market accumulator */
	for(stalls = 0; stalls < 10; stalls++) {
		markets[stalls].item = NULL;
		markets[stalls].chance = -1;
	}
	if(want) {
		create_local_markets(loc, want, 1);
		for(stalls = 0; stalls < want; stalls++) {
			item = markets[stalls].item;
			if(item) {
				markup = 10 + roll_1Dx(21);
				price = item->market_value * (100 - markup);
				price /= 100;
				value = (150/fake_root(price));
				count = roll_1Dx(value);
				if(count < value/2 && price < 50) {
					count = count*5/4 + 3 + roll_1Dx(value/2);
				}
				if(loc->economy < 70)
					count /= 2;
				if(count < 1) count = 1;
				wares = new_market_at_location(loc, item);
				wares->wanted.amount_remains = 
				wares->wanted.initial_amount = count;
				wares->wanted.negociated_price = price;
				wares->turns = 15 + roll_1Dx(6);
				printf("Created buy market of %d %s at $%d for %d turns.\n",
				       wares->wanted.initial_amount, item->plural, wares->wanted.negociated_price, wares->turns);
			}
		}
	}
}


/**
 ** MARKET_CHECK
 **	Is there a market locally? Are there any resources?
 **/
void market_check(location_s *local)
{
location_s	*global;
/*
 * Find the market terrain
 */
	if (!cache_market) {
		synthetic_tag("mrkt");
		cache_market = terrain_from_tag(0);
	}
/*
 * Is this a market?
 */
	if (local->type != cache_market || local->partial)
		return;
	global = local->outer;
	if (global->first_market)
		return;
	global->first_market = local;
}
#endif
#endif
