/* $Id: order.h,v 1.5 2000/06/14 03:59:34 jtraub Exp $
 *	Define the internals about an order in a stack, and how it is manipulated
 */
#ifndef overload_order_h
#define overload_order_h
#ifdef ORDERS_NEEDED
#include "argument.h"


#ifndef MAX_ORDER_ARGUMENTS
#ifndef MAX_COMBAT_SETTING
#define MAX_ORDER_ARGUMENTS	14
#else
#define MAX_ORDER_ARGUMENTS	MAX_COMBAT_SETTING
#endif
#endif
/**
 ** Arguments types
 **/
#define ARGUMENT_IS_STANCE		(ARGUMENT_IS_TITLE_TAG+1)
#define ARGUMENT_IS_BOOLEAN		(ARGUMENT_IS_STANCE+1)
#define ARGUMENT_IS_STRING		(ARGUMENT_IS_BOOLEAN+1)
#define ARGUMENT_IS_NUMBER		(ARGUMENT_IS_STRING+1)
#define ARGUMENT_IS_BATTLE		(ARGUMENT_IS_NUMBER+1)
#define ARGUMENT_IS_RANK		(ARGUMENT_IS_BATTLE+1)
#define ARGUMENT_IS_FILE		(ARGUMENT_IS_RANK+1)
#define ARGUMENT_IS_MOVE		(ARGUMENT_IS_FILE+1)
#define ARGUMENT_IS_COMBAT_OPTION	(ARGUMENT_IS_MOVE+1)
#define ARGUMENT_IS_SETTING		(ARGUMENT_IS_COMBAT_OPTION+1)
#define ARGUMENT_IS_DIRECTION		(ARGUMENT_IS_SETTING+1)
#define ARGUMENT_IS_TARGET		(ARGUMENT_IS_DIRECTION+1)
#define ARGUMENT_IS_COMBAT_TARGET	(ARGUMENT_IS_TARGET+1)

#define ARGUMENT_IS_OPTIONAL		0x40
#define ARGUMENT_MASK			0x3F
/*
 * Order object
 */
typedef struct {
	char		*keyword;
	int		(*routine)(unit_s *,struct struct_order *);
	char		types[MAX_ORDER_ARGUMENTS];
	char		full_day_order;
} command_s;

struct struct_order {
	struct struct_order	*next, *prev;
	t_argument		arguments[MAX_ORDER_ARGUMENTS];
	char			combat_once[MAX_ORDER_ARGUMENTS];
	command_s		executing;
	char			days;
	char			limit_low,
				limit_high;
	char			conditional,
				masked_conditional;
	char			positive;
	char			considered;
};
typedef struct struct_order	order_s;	/* a stacked order */


/*
 * External variables
 */
extern command_s	valid_orders[];


/*
 * Prototypes
 */
extern order_s		*parse_order_line(order_s *);
extern void		infinite_conditional(unit_s *, order_s *);
extern void		order_is_error(unit_s *, order_s *);
extern void		order_is_complete(unit_s *, order_s *);
extern int		order_was_executed(unit_s *, order_s *);
extern void		free_order_instance(order_s *);
extern order_s		*new_order_instance(void);
extern char		*visual_enum(int,char *);
extern void		write_order_on_file(FILE *, order_s *);
extern void		load_orders(void);
extern void		execute_oathing_process(unit_s *,int,faction_s *,faction_s *); /* special plug */


#endif
#endif/*overlord_order_h*/
