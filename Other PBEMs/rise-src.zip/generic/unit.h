/* $Id: unit.h,v 1.23 2000/12/03 17:48:23 jtraub Exp $
 *	Define the internals about a unit, and how it is manipulated
 */
#ifndef overlord_unit_h
#define overlord_unit_h

#ifndef MAX_COMBAT_SETTING
#ifndef MAX_ORDER_ARGUMENTS
#define MAX_COMBAT_SETTING	14
#else
#define MAX_COMBAT_SETTING	MAX_ORDER_ARGUMENTS
#endif
#endif
/**
 ** Combat settings
 **/
struct struct_combat_set {
	union	{
		item_s	*use_item;
		skill_s	*use_skill;
	}	u;
#ifdef BATTLE_INITIATIVE
	int	initiative;
#endif
	char	option;
	char	skill_used;
	char	avoid_action;
	char	disabled;
	char	once;
};
typedef struct struct_combat_set	combat_set_s;

struct struct_taught {
	experience_s *exp;
	struct struct_unit *teacher;
	struct struct_taught *next;
};
typedef struct struct_taught	taught_s;

/**
 ** Unit object
 **/
struct struct_dead {
	t_tag			id;
	struct struct_dead	*next;
	faction_s		*faction;
};
typedef struct struct_dead	dead_unit_s;

struct struct_unit {
	t_tag			id;
#ifdef NUMERICAL_UNIT_IDS
	int			id_number;
#endif
	struct struct_unit	*next;
	struct struct_unit	*next_hash;
	struct struct_unit	*same_faction;	/* per-faction linkage */
	faction_s		*faction;	/* backpointer */
	char			*name;		/* useful */
#ifndef MAIL_PROCESSOR
#ifdef ORDERS_NEEDED
	faction_s		*now_loyal;	/* to new faction */
	char			*description;	/* for reports */
#ifdef MULTIPLE_UNIT_OWNERSHIP
	loyalty_s		*allegiance;	/* to factions */
#endif
#ifdef UNIT_CONTROLS_OTHERS
	control_s		*master_of;	/* controls units */
	control_s		*oathed_to;	/* controlled by units */
#endif
#ifdef LOCATION_FACTION_CONTROL
	control_s		*land_grants;	/* control locations */
#endif
	struct struct_unit	*next_location,	/* per-location linkage */
				*next_visible;	/* per-location linkage */
#ifdef UNIT_STACKS
	struct struct_unit	*stack,
				*leader;	/* stacked beneath */
#endif
	race_s			*race;		/* which type of unit */
#ifdef FX_ALTERED_UNIT
	race_s			*altered;	/* apparent type of unit */
#endif
	event_s			*events;	/* events during turn */
	experience_s		*skilled;	/* which levels */
	taught_s		*taught;	/* someone willing to teach */
	struct struct_order	*executing,	/* order sheet */
				*orders;
	carry_s			*carrying,	/* unit possessions */
#ifdef USES_MANA_POINTS
				*power,		/* mana levels */
#endif
				*coins,		/* cash-cache */
				*spoils;	/* current spoils */
	struct struct_location	*current,	/* not saved, location itself saves */
				*true_location;
#ifdef TURN_PROCESSOR
	struct struct_resource	*special_resources;
#endif
#ifdef USES_TITLE_SYSTEM
	struct struct_location	*title;		/* title held */
#endif
	t_argument		target;		/* current targetting */
	long			weight;		/* of unit */
	long			capacity[MAX_MOVE_MODES];	/* of unit */
	long			stack_weight;			/* of stack */
	long			stack_capacity[MAX_MOVE_MODES];
	int			size;		/* number of race items */
	stats_s			vital;		/* vital stats */
#ifdef SEPARATE_BONUS
	stats_s			bonus;		/* additional stats */
#endif
#ifdef STEALTH_STATS
	int			effective_stealth;/* after corrective */
	int			effective_observe;/* to guess things */
#endif
	struct struct_location	*toward;	/* movement */
	struct struct_location	*move_from;
	combat_set_s		combat[MAX_COMBAT_SETTING];
	int			wages;		/* amount of man-days worked */
#ifdef USES_FACTION_FUND
	int			withdrawn;	/* auto-withdrawn */
#endif
#ifdef USES_ACTION_POINTS
	char			actions,
				spent;		/* per turn */
#endif
	char			target_type;
	char		summoned;
	char			is_moving,
				move_for_days,
				moving_by,
				already_moved,
				did_a_move,
				wants_stay;
	char			participate,	/* to combat */
				rank,		/* rank 0-2 */
				file,		/* file 0-2 */
				movement;	/* during combat */
	char			is_guarding,	/* now half day */
				is_patrolling,	/* busy on effective patrol */
				was_guarding,	/* Guard is seen on report */
				is_attacking,	/* During this battle! */
				is_defending;	/* During this battle! */
#ifdef PRISONERS_TAKEN
	char			is_captive;	/* was captured */
	char			attempted_suicide;	/* tried to disband */
#endif
	char			setting_advert;	/* advertise faction */
	char			setting_silent;	/* be silent about use/get/give */
	char			setting_protect;/* protect area access */
	char			setting_guard;	/* protect area exploitation */
	char			setting_hushgive; /* infinite gives are silenced */
#ifdef STEALTH_STATS
	char			setting_report;	/* advertise presence */
#endif
#ifdef USES_FACTION_FUND
	char			setting_support;/* use faction fund in priority */
	char			setting_miser;	/* do not draw from faction fund */
#endif
	char			full_day;	/* already processed? */
	int			intelligent;    /* effect of a spell */
	char			synchro;	/* Has unit done a syncrho? */
	skill_s 		*studying;
	char			has_recruited;	/* movement is forbidden */
	char			has_effects;	/* has pending effects */
	char			sneaking;	/* Unit is sneaking */
	char			escaping;	/* unit is escaping */
	char			no_sneak;	/* Unit cannot sneak */
	char			masqing;	/* Unit has aura masq */
#endif
	char			inactive;	/* either dead, disbanded, or to be created */
	char			dead;		/* unit is dead */
	char			disbanded;	/* Unit is currently disbanded */
#ifdef TRACING_REQUIRED
	char			traced_unit;	/* unit does weird things, require step-by-step */
	char			victor;		/* unit was victor in combat */
#endif
#ifdef BATTLE_INITIATIVE
	char			num_battles;	/* number of previous battles */
#endif
	char			virtual;	/* do not archive */
#endif
};
typedef struct struct_unit	unit_s;		/* a unit in the game */


/*
 * Variables
 */
extern unit_s		*unit_list;
extern dead_unit_s	*dead_list;
extern t_tag		last_unit_tag;


/*
 * Prototypes
 */
extern void		load_units(void);
extern void		save_units(void);
extern carry_s		*parse_carried_item(carry_s *);
extern carry_s		*unit_possessions(unit_s *,item_s *,int);
extern carry_s		*unit_spoils(unit_s *,item_s *,int);
extern experience_s	*unit_experiences(unit_s *,skill_s *,int);
extern dead_unit_s	*dead_unit_existed(void);
extern unit_s		*unit_from_id(int);
extern unit_s		*potential_unit_id(faction_s *);
extern unit_s		*virtual_unit(race_s *, int);
extern unit_s		*random_unit_id(void);
extern void		assign_unit_id(unit_s *);
extern void		unstack_unit(unit_s *);
extern void		stack_under(unit_s *,unit_s *);
extern void		stack_relocated(unit_s *);
extern void		unit_is_now_dead(unit_s *,int);
extern void		unit_personal_event(unit_s *,int,char *);
extern int		will_recruit_now(unit_s *, unit_s *, race_s *, int);
#ifdef BATTLE_INITIATIVE
extern void		unit_increment_battles(unit_s *);
#endif
extern void		unit_set_victor(unit_s *, char);
extern struct struct_resource	*unit_has_resource(unit_s *, item_s *type);

extern int roll_1Dx(int);

#ifdef TURN_PROCESSOR
unit_s			*unit_was_taught(unit_s *, skill_s *, int *);
void			add_unit_teaching(unit_s *, unit_s *, experience_s *);
void			free_unit_teaching(unit_s *);
#endif
#endif/*overlord_unit_h*/
