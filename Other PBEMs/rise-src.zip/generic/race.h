/* $Id: race.h,v 1.1.1.1 2000/02/04 19:39:47 jtraub Exp $
 *	Define the internals about a race.
 */
#ifndef overlord_race_h
#define overlord_race_h

/**
 ** Race object
 **/
struct struct_race {
	t_tag			tag;
	struct struct_race	*next;
	char			*name,
				*plural;
#ifdef REPORTS_RACIAL_KNOWLEDGE
	char			*description;
#endif
	struct struct_experience *skilled;	/* when joining */
#ifdef RACE_FAVOR_SKILLS
	struct struct_experience *favors;	/* when studying */
#endif
	long			weight;
	long			capacity[MAX_MOVE_MODES];
	stats_s			intrinsic;
	int			fraction,
				max_recruited;
#ifdef USES_CASH_UPKEEP
	int			upkeep;
#endif
	int			base_cost;
#ifdef USES_ACTION_POINTS
	char			actions;
#endif
	char			type;
};

typedef struct struct_race	race_s;		/* racial type */


/*
 * Variables
 */
extern race_s	*race_list;


/*
 * Prototypes
 */
extern void	load_races(void);
extern race_s	*race_from_tag(int);


#endif/*overlord_race_h*/
