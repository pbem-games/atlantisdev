/* $Id: fx.h,v 1.4 2000/09/09 17:18:33 jtraub Exp $
 *	Technicolor special effects - anything that does not fit
 * in the standard framework.  FXs are attached to skills, items
 * or produced tokens.
 */
#ifndef overlord_fx_h_
#define overlord_fx_h_
#include "fxdef.h"


/**
 ** Prototypes
 **/
extern int	fx_available_here_for(location_s *, faction_s *, int);
extern void	fx_location_init(location_s *);
extern int	fx_execute_event(item_s *,int,unit_s *,skill_s *,order_s *);
extern void	fx_end_of_turn(unit_s *,carry_s *);
extern void	fx_mind_reading(unit_s *, int);
extern int	fx_active_structure(unit_s *, int);
extern int	is_fx_available(location_s *,faction_s *,int);
extern int  fx_equipped_on_unit(unit_s *, int);
extern int	fx_building_preconditions(terrain_s *, unit_s *);
extern int	fx_race_preconditions(race_s *, unit_s *);
extern int	fx_product_preconditions(item_s *, unit_s *);


#endif /* overlord_fx_h_ */
