/* $Id: events.c,v 1.1.1.1 2000/02/04 19:39:46 jtraub Exp $
 *	Allocate day events
 */
#include "overlord.h"


#ifndef EVENTS_CHUNK
#define EVENTS_CHUNK	1000
#endif

/**
 ** Local cache
 **/
static event_s	*free_events_chain;


/**
 ** NEW_DATED_EVENT
 **	Allocate one events instance
 **/
event_s *new_dated_event(void)
{
event_s	*event;
int	i, j;
/*
 * Any cached experience_s?
 */
	if (free_events_chain == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		free_events_chain = (event_s *)zero_malloc(sizeof(event_s)*EVENTS_CHUNK);
		j = 0;
		for (i = 0; i < (EVENTS_CHUNK-1); i++)
			free_events_chain[i].next = free_events_chain+(++j);
	}
/*
 * Allocated
 */
	event = free_events_chain;
	free_events_chain = event->next;
	event->next = 0;
	return event;
}
