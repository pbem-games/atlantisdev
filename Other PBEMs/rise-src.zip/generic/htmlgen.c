/* $Id: htmlgen.c,v 1.5 2000/07/10 00:09:16 jtraub Exp $
 *	Generate HTML access information from the players list
 */
#include "overlord.h"
#include "info.h"
#include "file.h"
#include "email.h"

#ifdef __linux__
/* Needed on some machines for crypt */
extern char *crypt(const char *key, const char *salt);
#endif


/**
 ** Faction list is sorted alphabetically
 **/
static faction_s *sorted_factions(faction_s *faction)
{
faction_s	*next;
/*
 * Place them in alphabetical order
 */
	if (!faction || !faction->next)
		return faction;
	next = sorted_factions(faction->next);
/*
 * Sort?
 */
	if (strcasecmp(faction->name, next->name) <= 0) {
		faction->next = next;
		return faction;
	}
	faction->next = next->next;
	next->next = faction;
	return sorted_factions(next);
}


/**
 ** MAIN
 **	Entry point
 **/
int main(int argc, char **argv)
{
FILE		*index_html;
FILE		*src, *pindex;
faction_s	*faction, *list, *loop;
int		i;
/*
 * Load the useful info
 */
	load_game_info();
	load_factions();
/*
 * Now, generate the files
 */
	if ((src = fopen("src.html", "r")) == 0) {
		perror("src.html");
		exit(1);
	}
	if ((index_html = fopen("players/index.html", "w")) == 0) {
		perror("index.html");
		exit(1);
	}
	while (fgets(work, sizeof(work), src) != 0)
		fputs(work, index_html);
	fclose(src);
/*
 * Create the table
 */
	faction_list = sorted_factions(faction_list);
	for (faction = faction_list; faction; faction = faction->next) {
		if (faction->npc)
			continue;
		i = 0;
		for (list = faction_list; list; list = list->next)
			for (loop = list->vassal_of; loop; loop = loop->vassal_of)
				if (loop == list)
					break;
				else
					if (loop == faction)
						i++;
                fprintf(index_html, "  <TR>");
		fprintf(index_html,
			"<TH><A HREF=\"%s/\"><CODE>%s</CODE></A></TH>",
			faction->id.text, faction->id.text);
		fprintf(index_html, "<TD>%s</TD>", faction->name);
		if (i > 1)
			if (i > 3)
				if (i > 9)
					if (i > 15)
						if (i > 25)
							fprintf(index_html, "<TD>empire</TD>");
						else
							fprintf(index_html, "<TD>nation</TD>");
					else
						fprintf(index_html, "<TD>kingdom</TD>");
				else
					fprintf(index_html, "<TD>faction</TD>");
			else
				fprintf(index_html, "<TD>tribe</TD>");
		else
			fprintf(index_html, "<TD></TD>");
		if (strncmp(faction->id.text, "npc", 3) == 0)
			fprintf(index_html, "<TD>(npc)</TD>");
		else
#ifdef ANONYMOUS_PLAY
			fprintf(index_html,
				"<TD><A HREF=\"mailto:%s%s\">%s%s</A></TD>",
				faction->id.text, game_server_email,
				faction->id.text, game_server_email);
#else
			fprintf(index_html,
				"<TD><A HREF=\"mailto:%s\">%s</A></TD>",
				faction->e_mail, faction->e_mail);
#endif
		fprintf(index_html, "</TR>\n");
/*
 * Now generate the per-user .htaccess
 */
		sprintf(work, "players/%s/.htaccess", faction->id.text);
		if ((src = fopen(work, "w")) == 0) {
			perror(work);
			exit(1);
		}
		fprintf(src, "AuthName RoH\n");
		fprintf(src, "AuthType Basic\n");
		fprintf(src, "AuthUserFile %s/players/%s/.auth\n", argv[1], faction->id.text);
		fprintf(src, "Require valid-user\n");
		fclose(src);

		if ((src = fopen("template.html", "r")) != 0) {
			sprintf(work, "players/%s/index.php3",
				faction->id.text);
			if((pindex= fopen(work, "w")) != 0) {
				while (fgets(work, sizeof(work), src) != 0)
					fputs(work, pindex);
				fclose(src);
			}
			sprintf(work, "players/%s/clan.dat", faction->id.text);
			if((src = fopen(work, "w")) != 0) {
			    fprintf(src, "%s\n", faction->name);
			    fprintf(src, "%s\n", faction->id.text);
			    fprintf(src, "%s\n", argv[2]);
			}
		}


/*
 * Generate the per-user .auth
 */
		sprintf(work, "players/%s/.auth", faction->id.text);
		if ((src = fopen(work, "w")) != 0) {
			if (strncmp(faction->id.text, "npc", 3) != 0)
				fprintf(src, "%s:%s\n", faction->id.text, crypt(faction->password, "00"));
			fclose(src);
		}
	}
/*
 * Finish
 */
	fprintf(index_html, "  </TABLE>\n</BODY>\n</HTML>\n");
	return 0;
}
