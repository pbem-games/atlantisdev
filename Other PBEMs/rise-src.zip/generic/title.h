/* $Id: title.h,v 1.1.1.1 2000/02/04 19:39:47 jtraub Exp $
 *	Title system
 */
#ifndef _overlord_title_h_
#define _overlord_title_h_
#ifdef USES_TITLE_SYSTEM
/**
 ** Title object
 **/
struct struct_title {
	t_tag			tag;
	struct struct_title	*next;
	char			*name;
	skill_s			*required;
#ifdef USES_SKILL_LEVELS
	int			level;
#endif
	int			cost;
	int			range;		/* for land titles */
#ifdef USES_CONTROL_POINTS
	char			control;
#endif
	char			type;
#define TITLE_MINOR	0
#define TITLE_STANDARD	1
#define TITLE_MAJOR	2
#define TITLE_OVERLORD	3
};
typedef struct struct_title	title_s;


/**
 ** Prototypes
 **/
extern title_s	*title_from_tag(int);
extern void	load_titles(void);
extern void	title_ranges(void);


#endif
#endif/*_overlord_title_h_*/
