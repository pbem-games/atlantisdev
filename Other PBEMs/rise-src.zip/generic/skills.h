/* $Id: skills.h,v 1.3 2000/07/17 19:20:51 jtraub Exp $
 *	Define the internals about skills
 */
#ifndef overlord_skill_h
#define overlord_skill_h
#include "argument.h"


/**
 ** Sub-types
 **/

struct struct_consume {
	struct struct_consume	*next;
	struct struct_item	*what;
	int			amount;
};
typedef struct struct_consume	consume_s;


/**
 ** Skill object
 **/
struct struct_skill {
	t_tag			tag;
	struct struct_skill	*next;
#ifdef USES_SKILL_LEVELS
	struct struct_skill	*next_level;
#endif
#ifdef USES_REQUIRED_LEVELS
	struct struct_skill	*required_skill;
#ifdef USES_SKILL_LEVELS
	int			required_at_level;
#endif
#endif
	char			*name;
#ifdef REPORTS_SKILL_KNOWLEDGE
	char			*describe;
#endif
	consume_s		*use_consumes;		/* If craft skill */
	struct struct_item	*harvests;		/* harvests token */
	struct struct_item	*end_product;		/* finished product */
/*
 * Optional arguments
 */
#ifdef SKILL_BENEFITS_FROM_TOOL
	consume_s		*enhanced;		/* speeds up use by X% */
#endif
#ifdef SKILL_BENEFITS_FROM_BOOK
	struct struct_item	*wisdom;		/* speeds up learning by 5-10-20% */
#endif
#ifdef SKILL_REQUIRES_BOOK
	struct struct_item	*required_item;		/* allows study */
#endif
#ifdef SKILLS_USED_IN_BATTLE
	combat_s		combat_action;		/* if useable as combat setting */
#endif
	t_argument		specific;		/* used as target */
	stats_s			bonus;			/* capacities from level */
	int			tokens_required;	/* how many tokens (day) are required */
	int			multiples;		/* how many end products */
	int			multiplier;		/* how many tolens are produced / day */
	long			capacity[MAX_MOVE_MODES];/* adds capacity per level */
#ifdef SKILL_USE_POINTS
	int			for_level;		/* experience for level */
#endif
	int			study_cost,		/* per day */
				experience;
	short			flags;			/* special flags */
	char			type;
	char			student;		/* who may study? */
#ifdef SPECIALIST_SKILLS
	char			specialist;		/* requires another to study */
#endif
	char			target;			/* skill requires a target */
#define SKILL_TARGET_UNIT	1
#define SKILL_TARGET_LOCATION	2
#define SKILL_TARGET_STRUCTURE	3
#define SKILL_TARGET_SKILL	4
#define SKILL_TARGET_ITEM	5
#define SKILL_TARGET_TERRAIN	6
	char			local_target;		/* or 2 for adjacent */
	char			specific_type;		/* type of specific field */
	unsigned char		special_effects;	/* FX!!! */
};
typedef struct struct_skill	skill_s;	/* a skill description */

struct struct_experience {
	struct struct_experience	*next;
	skill_s				*skill;
#ifdef SKILL_USE_POINTS
	long				points;		/* points earned */
	long				studied;	/* studied this turn */
#endif
	skill_s				*effective;
#ifdef USES_SKILL_LEVELS
	int				level;
#endif
};
typedef struct struct_experience experience_s;	/* a skill achieved */


/*
 * Variables
 */
extern skill_s	*skills_list;


/*
 * Prototypes
 */
extern void		load_skills(void);
extern skill_s		*skill_from_tag(int);
extern experience_s	*new_experience_instance(void);
extern void		free_experience_instance(experience_s *);
extern void		adjust_experience(experience_s *, int);
extern experience_s	*parse_experience_skill(experience_s *,int);
extern skill_s		*skill_at_level(skill_s *,int);
extern int		may_see_item(struct struct_unit *, struct struct_item *);


#endif/*overlord_skill_h*/
