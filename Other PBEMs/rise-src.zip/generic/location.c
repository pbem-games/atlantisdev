/* $Id: location.c,v 1.18 2000/08/27 16:19:38 jtraub Exp $
 *	Manipulate the terrain and location files
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"
#include "enums.h"
#include "enumstxt.h"

#ifdef TURN_PROCESSOR
extern terrain_s *neutral_city;
#endif

/**
 ** Fix settings
 **/
#ifdef TURN_PROCESSOR
#define SAVE_NEEDED
#elif MAP_EDITOR
#define SAVE_NEEDED
#endif


/**
 ** Private title
 **/
struct text_direction {
	struct text_direction	*next;
	char			*text;
};


/**
 ** Global variables
 **/
int last_location_id;
terrain_s	*terrains_list;

location_s	*location_list;

#define LHASH_SIZE 1000
location_s *loc_hash[LHASH_SIZE];

/**
 ** The various files
 **/
#ifndef TERRAIN_FILE_NAME
#define TERRAIN_FILE_NAME	"terrains"
#endif
#ifndef LOCATION_FILE_NAME
#define LOCATION_FILE_NAME	"locations"
#endif
#ifndef RESOURCE_CHUNK
#define RESOURCE_CHUNK	1000
#endif


/**
 ** Private variables
 **/
#ifdef TURN_PROCESSOR
static seen_s	*free_seen_chain;
#endif
#ifndef COMMIT_PROCESSOR
static
#endif
	char	location_file_name[]=LOCATION_FILE_NAME;


#ifndef EXITS_CHUNK
#define EXITS_CHUNK	1000
#endif

#ifndef OBSERVE_CHUNK
#define OBSERVE_CHUNK	1000
#endif


#ifndef COMMIT_PROCESSOR
/**
 ** NEW_RESOURCE_INSTANCE
 **	Allocate one resource instance
 **/
resource_s *new_resource_instance(void)
{
static resource_s	*free_resource_chain = 0;
resource_s		*contains;
int			i, j;
/*
 * No cached carry_s?
 */
	if ((contains = free_resource_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		contains = (resource_s *)zero_malloc(sizeof(resource_s)*RESOURCE_CHUNK);
		j = 0;
		for (i = 0; i < (RESOURCE_CHUNK-1); i++)
			contains[i].next = contains+(++j);
		free_resource_chain = contains;
	}
/*
 * Allocated
 */
	free_resource_chain = contains->next;
	memset(contains, 0, sizeof(*contains));
	return contains;
}

int wrap_x(char plane)
{
    switch(plane) {
	case REGION_OVERWORLD:
	    return 120;
	case REGION_AIR:
	    return 60;
	case REGION_EARTH:
	    return 0;
	case REGION_FIRE:
	    return 0;
	case REGION_WATER:
	    return 60;
	case REGION_VOID:
	    return 40;
	case REGION_UNDERWORLD:
	    return 0;
	default:
	    return 0;
    }
}

int wrap_y(char plane)
{
    switch(plane) {
	case REGION_OVERWORLD:
	    return 0;
	case REGION_AIR:
	    return 60;
	case REGION_EARTH:
	    return 0;
	case REGION_FIRE:
	    return 0;
	case REGION_WATER:
	    return 40;
	case REGION_VOID:
	    return 40;
	case REGION_UNDERWORLD:
	    return 0;
	default:
	    return 0;
    }
}


/**
 ** LOCATION_HAS_RESOURCE
 **	Allocate one resource instance
 **/
resource_s *location_has_resource(location_s *local, item_s *type, int create)
{
resource_s	*contains, *last;
/*
 * Last
 */
	last = 0;
	for (contains = local->resources; contains; contains = contains->next)
		if (contains->type == type)
			return contains;
		else
			last = contains;
/*
 * New resource
 */
	if (create) {
		contains = new_resource_instance();
		if (last)
			last->next = contains;
		else
			local->resources = contains;
		contains->type = type;
	}
	return contains;
}


/**
 ** NEW_DIRECTION_FROM_LOCATION
 **	Allocate a new direction pointer.
 **/
direction_s *new_direction_from_location(void)
{
static direction_s	*free_dir_chain;
direction_s		*direction;
int			i, j;
/*
 *
 */
	if (!free_dir_chain) {
		free_dir_chain = (direction_s *)zero_malloc(sizeof(direction_s)*EXITS_CHUNK);
		j = 0;
		for (i = 0; i < (EXITS_CHUNK-1); i++)
			free_dir_chain[i].next = free_dir_chain+(++j);
	}
	direction = free_dir_chain;
	free_dir_chain = direction->next;
	direction->next = 0;
	return direction;
}


/**
 ** NEW_RECRUITMENT_AT_LOCATION
 **	Allocate a new recruit slot pointer.
 **/
static recruit_s *new_recruitment_at_location(race_s *race, int amount, int price)
{
static recruit_s	*free_people_chain;
recruit_s		*jobs;
int			i, j;
/*
 *
 */
	if (!free_people_chain) {
		free_people_chain = (recruit_s *)zero_malloc(sizeof(recruit_s)*RESOURCE_CHUNK);
		j = 0;
		for (i = 0; i < (RESOURCE_CHUNK-1); i++)
			free_people_chain[i].next = free_people_chain+(++j);
	}
	jobs = free_people_chain;
	free_people_chain = jobs->next;
	jobs->next = 0;
	jobs->type = race;
	jobs->amount = amount;
	jobs->price = price;
	return jobs;
}


#ifdef FX_ABSORB_SKILL_0
/**
 ** LOCATION_EXPERIENCES
 **	Structure gains exerience in the given skill!
 **/
experience_s *location_experiences(location_s *here, skill_s *skill, int create)
{
experience_s	*has, *previous;
/*
 * Go
 */
	previous = 0;
	for (has = here->skills; has; has = has->next)
		if (has->skill == skill)
			return has;
		else
			previous = has;
/*
 * Not owned. Create item?
 */
	if (create) {
		has = new_experience_instance();
		has->skill = skill;
		if (previous)
			previous->next = has;
		else
			here->skills = has;
	}
	return has;
}
#endif


/**
 ** DIRECTION_TEXT
 **	Directions are free-form, but usually few in numbers
 **/
static char *direction_text(void)
{
static struct text_direction	*list;
struct text_direction		*scan;
/*
 * Do the right thing
 */
	for (scan = list; scan; scan = scan->next)
		if (strcasecmp(scan->text, token_keyword) == 0)
			break;
	if (!scan) {
		scan = mallocator(struct text_direction);
		scan->text = strdup(token_keyword);
		scan->next = list;
		list = scan;
	}
	return scan->text;
}


/**
 ** TERRAIN_FROM_STRING
 **/
terrain_s *terrain_from_token(void)
{
    terrain_s *scanner;
    char *a;

    a = token_keyword;
    while(*a) {
	if(*a == '_') *a = ' ';
	a++;
    }
    for (scanner = terrains_list; scanner; scanner = scanner->next) {
	if(scanner->name && strcmp(scanner->name, token_keyword) == 0)
	    return scanner;
    }
    return NULL;
}

/**
 ** TERRAIN_FROM_TAG
 **	Returns the terrain pointer associated with a tag. If specified,
 **	create the terrain, because it is brand new.
 **/
terrain_s *terrain_from_tag(int create)
{
    terrain_s	*scanner, *last = 0;

/*
 * Simple loop
 */
	for (scanner = terrains_list; scanner; scanner = scanner->next) {
#ifdef USE_LONG_LONG
	    if (scanner->tag.all == tag_token.all)
#else
	    if (strcmp(scanner->tag.text, tag_token.text) == 0)
#endif
		return scanner;
	    last = scanner;
	}
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(terrain_s);
		scanner->tag = tag_token;
		scanner->next = terrains_list;
		terrains_list = scanner;
	}
	return scanner;
}


/**
 ** LOAD_TERRAINS
 **	Load the terrains file.  This must be called exactly once, and no
 **	more.
 **/
void load_terrains(void)
{
FILE		*terrains;
terrain_s	*current_terrain = 0;
/*
 * Start loading
 */
	if ((terrains = fopen(TERRAIN_FILE_NAME, "r")) == 0)
		fatal_error(TERRAIN_FILE_NAME);
/*
 */
	while (file_gets(terrains)) {
		if (keyword("TERRAIN")) {
			if (separate_tag())
				current_terrain = terrain_from_tag(1);
			else
				current_terrain = 0;
			continue;
		}
		if (!current_terrain)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_terrain->name, string_ptr);
			continue;
		}
		if (keyword("TYPE")) {
			current_terrain->type = atoi(string_ptr);
			continue;
		}
		if (keyword("OPTIMA")) {
			current_terrain->optima = atoi(string_ptr);
			continue;
		}
		if (keyword("LANDWALK")) {
			if (separate_tag())
				current_terrain->attached_skill = skill_from_tag(0);
			continue;
		}
		if (keyword("TOKEN")) {
			if (separate_tag())
				current_terrain->local_token = item_from_tag(0);
			continue;
		}
		if (keyword("RESOURCE")) {
			current_terrain->required = parse_resource_item(current_terrain->required);
			continue;
		}
		if (keyword("PIXEL")) {
			current_terrain->pixel = parse_integer(string_ptr);
			continue;
		}
		if (keyword("FX")) {
			current_terrain->special_effect = parse_integer(string_ptr);
			continue;
		}
		if(keyword("SOLID")) {
		    current_terrain->solid = 1;
		    continue;
		}
#ifdef DYNAMICALLY_DEFINED_GAME
		if (keyword("DAYS")) {
			current_terrain->days = atoi(string_ptr);
			(void)separate_token();
			current_terrain->max_days = atoi(string_ptr);
			continue;
		}
		if (keyword("MODE")) {
			current_terrain->mode = parse_integer(string_ptr);
			continue;
		}
#endif
		stats_definition(&current_terrain->local_conditions);
	}
/*
 * Load done
 */
	fclose(terrains);
}


/**
 ** RANDOM_LOCATION_ID
 **	Allocate a new random id
 **/
location_s *random_location_id(void)
{
int	number;
/*
 * Try seqentially
 */
	for (number = last_location_id + 1; 1; number++) {
		sprintf(id_token.text, "L%d", number);
		if (location_from_id(0) == 0)
			break;
	}
/*
 * Notifier
 */
	printf("Creating hex [%s]...\n", id_token.text);
	return location_from_id(1);
}


#ifdef SAVE_NEEDED
/**
 ** RECURSIVE_EXITS
 **	Recursively saves the exit (due to reversed order)
 **/
static void recursive_exits(FILE *save, direction_s *dir)
{
/*
 * Recursion
 */
	if (!dir)
		return;
	recursive_exits(save, dir->next);
/*
 * Save this exit
*/
	fprintf(save, "EXIT %s %s %d %d", dir->name, dir->toward->id.text, dir->days, dir->mode);
	if (dir->skill)
#ifdef USES_SKILL_LEVELS
		fprintf(save, " %s %d", dir->skill->tag.text, dir->level);
#else
		fprintf(save, " %s", dir->skill->tag.text);
#endif
	putc('\n', save);
}


/**
 ** SAVE_LOCATIONS
 **	Rewrites the locations file.
 **/
void save_locations(void)
{
FILE		*save;
location_s	*location;
experience_s	*skills;
unit_s		*unit;
recruit_s	*jobs;
market_s	*wares;
resource_s	*resources;
/*
 * Start writing
 */
	if ((save = fopen(new_file(location_file_name), "w")) == 0)
		fatal_error(location_file_name);
	fprintf(save, "ID L%d\n\n", last_location_id);
	for (location = location_list; location; location = location->next) {
		fprintf(save, "LOCATION %s %s\n", location->id.text, location->type->tag.text);
		if (location->name)
			fprintf(save, "NAME %s\n", location->name);
		if(location->region > 0)
		    fprintf(save, "REGION %s\n", visual_enum(location->region, regions));
		if (location->description)
			fprintf(save, "DESCRIBE %s\n", location->description);
		if (location->outer)
			fprintf(save, "OUTER %s\n", location->outer->id.text);
		recursive_exits(save, location->exits);
		if ((unit = location->present) != 0) {
			for (fprintf(save, "UNIT"); unit; unit = unit->next_location)
				fprintf(save, " %s", unit->id.text);
			putc('\n', save);
		}
		if (location->racial) {
			fprintf(save, "POPULATION %d %s\n",
				location->population, location->racial->tag.text);
		}
		if (location->optima)
			fprintf(save, "OPTIMA %d\n", location->optima);
#ifdef DYNAMIC_ECONOMY
		if (location->economy)
			fprintf(save, "ECONOMY %d\n", location->economy);
#endif
#ifdef USES_CASH
		if (location->wages)
			fprintf(save, "WAGES %d\n", location->wages);
#endif
#ifdef USES_TITLE_SYSTEM
		if (location->title) {
			fprintf(save, "TITLE %s", location->title->tag.text);
			if (location->holder)
				fprintf(save, " %s", location->holder->id.text);
			putc('\n', save);
		}
#endif
#ifndef FIXED_WORLD
		for (jobs = location->opportunity; jobs; jobs = jobs->next)
			fprintf(save, "RECRUIT %s %d %d\n", jobs->type->tag.text,
					jobs->amount, jobs->price);
#endif
#ifdef USES_CASH
		for (wares = location->markets; wares; wares = wares->next) {
			if (wares->offered.initial_amount && wares->turns)
				fprintf(save, "SELL %s %d %d %d\n", wares->type->tag.text,
						wares->offered.initial_amount, wares->offered.negociated_price, wares->turns);
			if (wares->wanted.initial_amount && wares->turns)
				fprintf(save, "BUY %s %d %d %d\n", wares->type->tag.text,
						wares->wanted.initial_amount, wares->wanted.negociated_price, wares->turns);
		}
#endif
		for (resources = location->resources; resources; resources = resources->next)
			if (resources->amount)
				fprintf(save, "RESOURCE %s %d\n", resources->type->tag.text,
						resources->amount);

		if(location->treasure)
		    fprintf(save, "TREASURE %s %d\n",
			    location->treasure->type->tag.text,
			    location->treasure->amount);
		if(location->unlooted)
		    fprintf(save, "UNLOOTED\n");

		for (skills = location->skills; skills; skills = skills->next)
#ifdef SKILL_USE_POINTS
			fprintf(save, "SKILL %s %ld\n", skills->skill->tag.text,
					skills->points);
#else
			fprintf(save, "SKILL %s\n", skills->skill->tag.text);
#endif
		if (location->partial)
			fprintf(save, "PARTIAL\n");
#ifdef USE_OVERLAND_COORDINATES
		if (location->type->type == TERRAIN_COUNTRY)
#ifdef OVERLAND_3D
			fprintf(save, "XYZ %d %d %d\n", location->x, location->y, location->z);
#else
			fprintf(save, "XY %d %d\n", location->x, location->y);
#endif
#endif
		putc('\n', save);
	}
	fclose(save);
}
#endif/*SAVE_NEEDED*/


/**
 ** PARSE_RECRUITS
 **	Add a recruit to the list at the location
 **/
recruit_s *parse_recruits(recruit_s *existing, race_s *who, int amount, int price)
{
	if (existing)
		existing->next = parse_recruits(existing->next, who, amount, price);
	else
		existing = new_recruitment_at_location(who, amount, price);
	return existing;
}


/**
 ** PARSE_RESOURCE_ITEM
 **	Parse one resource for a location
 **/
resource_s *parse_resource_item(resource_s *list)
{
item_s		*item;
/*
 * Threading
 */
	if (list) {
		list->next = parse_resource_item(list->next);
		return list;
	}
	if (!separate_tag())
		return 0;
	if (!(item = item_from_tag(0)))
		return 0;
	list = new_resource_instance();
	list->type = item;
	list->amount = atoi(string_ptr);
	return list;
}


/**
 ** LOCATION_FROM_ID
 **	Returns the location pointer associated with an id. If specified,
 **	create the location, because it is brand new.
 **/
location_s *location_from_id(int create)
{
    static location_s *last = NULL;
    location_s	*scanner;
    int val = atoi(id_token.text+1);
    int hash = val % LHASH_SIZE;

    for(scanner = loc_hash[hash]; scanner; scanner = scanner->next_hash) {
#ifdef USE_LONG_LONG
	if (scanner->id.all == id_token.all)
#else
	if (strcmp(scanner->id.text, id_token.text) == 0)
#endif
		return scanner;
    }

    /* We didn't find it, we might need to create it */
    if(create) {
	scanner = mallocator(location_s);
	scanner->id = id_token;
	scanner->next_hash = loc_hash[hash];
	loc_hash[hash] = scanner;
	if(last) {
	    last->next = scanner;
	    last = scanner;
	} else {
            location_list = scanner;
	    last = scanner;
	}
	/*
	 * Keep track of increasing ID?
	 */
	if (last_location_id < atoi(id_token.text+1))
	    last_location_id = atoi(id_token.text+1);
    }

    return scanner;
}


/**
 ** LOAD_LOCATION
 **	Load the locations file.  This must be called exactly once, and no
 **	more.
 **/
void load_locations(void)
{
FILE		*locations;
location_s	*current_location = 0;
location_s	*outer;
direction_s	*direction;
market_s	*wares;
unit_s		*unit;
char		*textual;
int		value;
/*
 * Start loading
 */
	load_terrains();
	if ((locations = fopen(location_file_name, "r")) == 0)
		fatal_error(location_file_name);
/*
 */
	while (file_gets(locations)) {
/*
 * Pr�-allocate all locations
 */
		if (keyword("ID")) {
			if (separate_tag()) {
			    int i;
			    last_location_id = atoi(id_token.text+1);
			    value = last_location_id;
			    memset(&id_token, 0, sizeof(id_token));
			    for (i = 0; i <= value; i++) {
				sprintf(id_token.text, "L%d", i);
				(void)location_from_id(1);
			    }
			}
			continue;
		}
		if (keyword("LOCATION")) {
			if (separate_tag()) {
				current_location = location_from_id(1);
				if (separate_tag())
					current_location->type = terrain_from_tag(0);
			} else
				current_location = 0;
			continue;
		}
		if (!current_location)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_location->name, string_ptr);
			continue;
		}
		if(keyword("REGION")) {
		    current_location->region = parsed_enum(string_ptr, regions);
		    if(current_location->region < 0)
			current_location->region = 0;
		    continue;
		}
		if (keyword("DESCRIBE")) {
			make_a_copy_(current_location->description, string_ptr);
			continue;
		}
		if (keyword("TYPE")) {
			if (separate_tag())
				current_location->type = terrain_from_tag(0);
			continue;
		}
		if (keyword("OPTIMA")) {
			current_location->optima = atoi(string_ptr);
			continue;
		}

		if (keyword("OUTER")) {
			if (separate_tag()) {
				current_location->outer =
				outer = location_from_id(1);
				if (!outer->inner)
					outer->inner = current_location;
				else {
					outer = outer->inner;
					while (outer->next_inner)
						outer = outer->next_inner;
					outer->next_inner = current_location;
				}
			}
			continue;
		}
		if (keyword("EXIT")) {
			if (separate_token()) {
				textual = direction_text();
				if (separate_tag()) {
					direction = new_direction_from_location();
					direction->toward = location_from_id(1);
					direction->days = atoi(string_ptr);
					(void)separate_token();
					direction->mode = atoi(string_ptr);
					direction->name = textual;
					(void)separate_token();
					if (separate_tag()) {
						direction->skill = skill_from_tag(0);
#ifdef USES_SKILL_LEVELS
						if((direction->level = atoi(string_ptr)) <= 0)
							direction->level = 1;
#endif
					}
					direction->next = current_location->exits;
					current_location->exits = direction;
				}
			}
			continue;
		}
		if (keyword("UNIT")) {
			while (separate_tag()) {
				if ((unit = potential_unit_id(0)) == 0)
					unit = unit_from_id(1);
				move_to_location(unit, current_location);
			}
			continue;
		}
		if (keyword("POPULATION")) {
			current_location->population = atoi(string_ptr);
			(void)separate_token();
			if (separate_tag())
				current_location->racial = race_from_tag(0);
			continue;
		}
#ifdef USES_CASH
		if (keyword("WAGES")) {
			current_location->wages = atoi(string_ptr);
			continue;
		}
#endif
#ifdef USES_TITLE_SYSTEM
		if (keyword("TITLE")) {
			if (separate_tag()) {
				current_location->title = title_from_tag(0);
				if (separate_tag()) {
					unit_s *holder;
					current_location->holder = holder = unit_from_id(1);
					if (holder)
						holder->title = current_location;
				}
			}
			continue;
		}
#endif
#ifndef FIXED_WORLD
		if (keyword("RECRUIT")) {
			if (separate_tag()) {
				value = atoi(string_ptr);
				(void)separate_token();
				current_location->opportunity = parse_recruits(current_location->opportunity, race_from_tag(0), value, atoi(string_ptr));
			}
			continue;
		}
#endif
#ifdef USES_CASH
		if (keyword("SELL")) {
			if (separate_tag()) {
				int price, turn;
				value = atoi(string_ptr);
				(void)separate_token();
				price = atoi(string_ptr);
				(void)separate_token();
				if(separate_token()) {
					turn = atoi(token_keyword);
				} else {
					int done;
					do {
						done = 1;
						turn = roll_1Dx(6)+4;
						for(wares = current_location->markets; wares; wares = wares->next) {
							if(wares->offered.initial_amount)
								if(wares->turns == turn)
									done = 0;
						}
					} while (!done);
				}

				wares = new_market_at_location(current_location, item_from_tag(0));
				wares->offered.amount_remains =
				wares->offered.initial_amount = value;
				wares->offered.negociated_price = price;
				wares->turns = turn;
			}
			continue;
		}
		if (keyword("BUY")) {
			if (separate_tag()) {
				int price, turn;
				value = atoi(string_ptr);
				(void)separate_token();
				price = atoi(string_ptr);
				(void)separate_token();
				if(separate_token()) {
					turn = atoi(token_keyword);
				} else {
					int done;
					do {
						done = 1;
						turn = roll_1Dx(6)+4;
						for(wares = current_location->markets; wares; wares = wares->next) {
							if(wares->wanted.initial_amount)
								if(wares->turns == turn)
									done = 0;
						}
					} while (!done);
				}

				wares = new_market_at_location(current_location, item_from_tag(0));
				wares->wanted.amount_remains =
				wares->wanted.initial_amount = value;
				wares->wanted.negociated_price = price;
				wares->turns = turn;
			}
			continue;
		}
#endif
		if (keyword("TREASURE")) {
		    current_location->treasure = parse_resource_item(current_location->treasure);
		    continue;
		}
		if(keyword("UNLOOTED")) {
		    current_location->unlooted = 1;
		    continue;
		}

		if (keyword("RESOURCE")) {
			current_location->resources = parse_resource_item(current_location->resources);
			continue;
		}
		if (keyword("SKILL")) {
			current_location->skills = parse_experience_skill(current_location->skills, 1);
			continue;
		}
#ifdef DYNAMICALLY_DEFINED_GAME
		if (keyword("PARTIAL")) {
			current_location->partial = 1;
			continue;
		}
#endif
#ifdef DYNAMIC_ECONOMY
		if (keyword("ECONOMY")) {
			current_location->economy = atoi(string_ptr);
			continue;
		}
#endif
#ifdef USE_OVERLAND_COORDINATES
#ifdef OVERLAND_3D
		if (keyword("XYZ")) {
			current_location->x = atoi(string_ptr);
			separate_token();
			current_location->y = atoi(string_ptr);
			separate_token();
			current_location->z = atoi(string_ptr);
			continue;
		}
#else
		if (keyword("XY")) {
			current_location->x = atoi(string_ptr);
			separate_token();
			current_location->y = atoi(string_ptr);
			continue;
		}
#endif
#endif
#ifdef DYNAMICALLY_DEFINED_GAME
		if (*string_ptr)
			printf("location: %s\n", work);
#endif
	}
/*
 * Load done
 */
	fclose(locations);
/*
 * Validate locations
 */
#ifdef DYNAMICALLY_DEFINED_GAME
	textual = 0;
	for (current_location = location_list; current_location;
				current_location = current_location->next) {
		if (!current_location->type) {
			printf("missing terrain for %s\n", current_location->id.text);
			textual = current_location->id.text;
		} else
			if (current_location->type->type && !current_location->outer) {
				printf("missing outer for %s\n", current_location->id.text);
				textual = current_location->id.text;
			}
		if (!current_location->name) {
			printf("missing name for %s\n", current_location->id.text);
			textual = current_location->id.text;
		}
	}
	if (textual)
		exit(1);
#endif
}

#ifdef TURN_PROCESSOR
int taxable_loc(location_s *local)
{
	if(local->type->type == 0 && local->type != neutral_city)
		return 1;
	return 0;
}
#endif

/**
 ** MOVE_TO_LOCATION
 **	Unit is now located there, and is the last comer
 **/
void move_to_location(unit_s *unit, location_s *into)
{
location_s	*from;
unit_s		*previous, *list;
/*
 * Is this unit located somewhere?
 */
	if (!unit)
		return;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("moving %s to location 0x%x\n", unit->id.text,(unsigned)into);
#endif
#ifdef UNIT_STACKS
	unstack_unit(unit);
#endif
	if ((from = unit->current) != 0) {
		previous = 0;
		for (list = from->present; list; list = list->next_location)
			if (list == unit)
				break;
			else
				previous = list;
		if (list) {
			if (previous) {
				previous->next_location = list->next_location;
#ifdef TRACING_REQUIRED
				if (previous->traced_unit)
					printf("unit %s->next_location is now 0x%x\n", previous->id.text, (unsigned)previous->next_location);
#endif
			} else
				from->present = list->next_location;
		}
#ifdef TRACING_REQUIRED
		else if (unit->traced_unit)
			printf("Not at current location?\n");
#endif
	}
/*
 * Unit is linked there
*/
	unit->next_location = 0;
	if ((unit->current = into) != 0) {
		previous = 0;
		for (list = into->present; list; list = list->next_location)
			previous = list;
		if (previous) {
			previous->next_location = unit;
#ifdef TRACING_REQUIRED
			if (previous->traced_unit)
				printf("unit %s->next_location is now 0x%x instead of 0\n", previous->id.text, (unsigned)previous->next_location);
#endif
		} else
			into->present = unit;
		if (into->type->type == TERRAIN_STRUCTURE)
			unit->true_location = into->outer;
		else
			unit->true_location = into;
#ifdef UNIT_STACKS
		stack_relocated(unit->stack);
#endif
	}
/*
 * Stack moved
 */
}


#ifdef TURN_PROCESSOR
/**
 ** ADD_PRESENCE
 **/
static void add_presence(location_s *global, unit_s *unit)
{
	while (unit) {
		unit->next_visible = global->interacting;
		global->interacting = unit;
#ifdef UNIT_STACKS
		add_presence(global, unit->stack);
#endif
		unit = unit->next_location;
	}
}


/**
 ** WHO_IS_PRESENT
 **	Something requires the presence of all
 **/
void who_is_present(location_s *global)
{
location_s	*inner;
/*
 * No list currently
 */
	global->interacting = 0;
	add_presence(global, global->present);
	for (inner = global->inner; inner; inner = inner->next_inner)
		if (inner->type->type == TERRAIN_STRUCTURE)
			add_presence(global, inner->present);
}


#if 0
/**
 ** FREE_OBSERVE_INSTANCE
 **	Free the observation slot (merged)
 **/
static void free_observe_instance(seen_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	old->next = free_seen_chain;
	free_seen_chain = old;
}
#endif


/**
 ** NEW_OBSERVE_INSTANCE
 **	Allocate one observation instance
 **/
static seen_s *new_observe_instance(faction_s *faction, int day)
{
seen_s	*seen;
int	i, j;
/*
 * Any cached seen_s?
 */
	if ((seen = free_seen_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		seen = (seen_s *)zero_malloc(sizeof(seen_s)*OBSERVE_CHUNK);
		j = 0;
		for (i = 0; i < (OBSERVE_CHUNK-1); i++)
			seen[i].next = seen+(++j);
		free_seen_chain = seen;
	}
/*
 * Allocated
 */
	free_seen_chain = seen->next;
	memset(seen, 0, sizeof(*seen));
	seen->next = 0;
	seen->witness = faction;
	seen->day_start = day;
	seen->day_end   = day;
	return seen;
}


/**
 ** FACTION_PRESENT
 **	Faction is present, and observes at a given observation level
 **/
#ifdef STEALTH_STATS
static void faction_present(faction_s *faction, location_s *location, int day, int observe)
#else
static void faction_present(faction_s *faction, location_s *location, int day)
#endif
{
seen_s		*presence;
seen_s		*last_fact;
int		previous_day;
/*
 * Search for witness slot
 */
	last_fact = 0;
	previous_day = day - 1;
	for (presence = location->witness; presence; presence = presence->next)
		if (presence->witness == faction)
			last_fact = presence;
/*
 * Witness slots are clumped by faction, then in chronological order.
 * We also take advantage of the fact that all days are called in order.
 */
/*
 * First time the faction is here!
 */
	if (!last_fact) {
		presence = new_observe_instance(faction, day);
#ifdef STEALTH_STATS
		presence->observation = observe;
#endif
		presence->next = location->witness;
		location->witness = presence;
		return;
	}
/*
 * Hiatus between observations
 */
	if (last_fact->day_end < previous_day) {
		presence = new_observe_instance(faction, day);
#ifdef STEALTH_STATS
		presence->observation = observe;
#endif
		presence->next = last_fact->next;
		last_fact->next = presence;
		return;
	}
/*
 * Same day look?
 */
	if (last_fact->day_end == day) {
#ifndef STEALTH_STATS
		return;
#else
/*
 * We don't see anything new
 */
		if (observe <= last_fact->observation)
			return;
/*
 * Our observation for the day increases
 */
		if (last_fact->day_start == day) {
			last_fact->observation = observe;
			return;
		}
/*
 * We have two different periods
 */
		last_fact->day_end = previous_day;
#endif
	}
/*
 * Extend the presence
 */
#ifdef STEALTH_STATS
	if (observe != last_fact->observation) {
		presence = new_observe_instance(faction, day, observe);
		presence->observation = observe;
		presence->next = last_fact->next;
		last_fact->next = presence;
		return;
	}
#endif
/*
 * Increment the end day
 */
	last_fact->day_end = day;
}


/**
 ** OBSERVER_PRESENT
 **	One observer for a location
 **/
void observer_present(unit_s *unit, location_s *location, int day)
{
seen_s		*presence;
seen_s		*last_fact, *last_unit, *free_unit;
faction_s	*faction;
resource_s	*harvests;
int		previous_day;
location_s	*outer;
#ifdef STEALTH_STATS
int		observe;
/*
 * Validation
 */
	observe = unit->vital.observation;
#endif
	faction  = unit->faction;
	if (!faction || !location)
		return;
	if (location->type->type == TERRAIN_STRUCTURE) {
		outer = location;
		while (outer->type->type == TERRAIN_STRUCTURE)
			outer = outer->outer;
		observer_present(unit, outer, day);
	}
/*
 * The new loyal faction gets a report on the location, but not hidden resources
 */
	if (unit->now_loyal && unit->now_loyal != faction)
#ifdef STEALTH_STATS
		faction_present(unit->now_loyal, location, day, unit->vital.observation);
#else
		faction_present(unit->now_loyal, location, day);
#endif
/*
 * Does the location feature a hidden resource? If not, or the unit is not able to
 * see them anyway, just ignore it.
 */
	for (harvests = location->resources; harvests; harvests = harvests->next)
		if (harvests->type->item_hidden && may_see_item(unit, harvests->type))
			break;
	if (!harvests) {
#ifdef STEALTH_STATS
		faction_present(faction, location, day, unit->vital.observation);
#else
		faction_present(faction, location, day);
#endif
		return;
	}
/*
 * Search for witness slot. If a witness slot is found, it'd better have the same
 * unit, or none
 */
	last_fact = 0;
	last_unit = 0;
	free_unit = 0;
	previous_day = day - 1;
	for (presence = location->witness; presence; presence = presence->next)
		if (presence->witness == faction) {
			last_fact = presence;
			if (presence->expert == unit)
				last_unit = presence;
			if (!presence->expert)
				free_unit = presence;
		}
/*
 * First time the faction is here!
 */
	if (!last_fact) {
		presence = new_observe_instance(faction, day);
#ifdef STEALTH_STATS
		presence->observation = observe;
#endif
		presence->expert = unit;
		presence->next = location->witness;
		location->witness = presence;
		return;
	}
/*
 * We did not had recorded the presence of that unit, but we have a "free"
 * expertise slot.
 */
	if (!last_unit && free_unit)
		free_unit->expert = unit;
/*
 * We have recorded (just now, maybe), the presence of the expert
 */
	if (last_unit || free_unit) {
#ifdef STEALTH_STATS
		faction_present(faction, location, day, unit->vital.observation);
#else
		faction_present(faction, location, day);
#endif
		return;
	}
/*
 * This is a lot simpler than the faction_present code, since we DO have to allocate
 * a slot to record the expert's presence anyway. So, we'll do so.
 */
	presence = new_observe_instance(faction, day);
	presence->expert = unit;
	presence->next = last_fact->next;
	last_fact->next = presence;
#ifdef STEALTH_STATS
	if (last_fact->day_end < day || observe > last_fact->observation)
		presence->observation = observe
	else
		presence->observation = last_fact->observation
#endif
}

void return_unique_item(item_s *item)
{
    location_s *l;
    for(l = location_list; l; l = l->next) {
	if(!l->treasure) continue;
	if(l->unlooted) continue;
	if(l->treasure->type == item) {
	    l->unlooted = 1;
	}
    }
}

/**
 ** LOCATION_GENERAL_EVENT
 **	Event occurs at location, for all to see
 **/
void location_general_event(location_s *location, event_s *event)
{
event_s	*list, *previous;
/*
 * Go.
 */
	if (location->type->type == TERRAIN_STRUCTURE)
		location = location->outer;
	previous = 0;
	for (list = location->events; list; list = list->next)
		previous = list;
	if (previous)
		previous->next = event;
	else
		location->events = event;
}


/**
 ** LOCATION_VISIBLE_EVENT
 **/
void location_visible_event(location_s *location, int day, char *what)
{
event_s	*event;
/*
 * Synthetise event
 */
	event = new_dated_event();
	event->day = day;
	event->text = strdup(what);
#ifdef STEALTH_STATS
	event->stealth = -99;
#endif
	location_general_event(location, event);
}


/**
 ** LOCATION_GLOBAL_EVENT
 **	Event occurs at location
 **/
void location_global_event(unit_s *unit, int day, char *text)
{
event_s	*event;
/*
 * Go.
 */
	event = new_dated_event();
	event->day = day;
	event->text = strdup(text);
#ifdef STEALTH_STATS
	if (!unit || unit->setting_report)
		event->stealth = -99;
	else
		event->stealth = unit->effective_stealth;
#endif
	location_general_event(unit->true_location, event);
}


/**
 ** OBSERVE_LOCATIONS
 **	Observe all locations
 **/
void observe_locations(int day)
{
unit_s	*unit;
/*
 * All units
 */
	for (unit = unit_list; unit; unit = unit->next) {
#ifdef PRISONERS_TAKEN
/*
 * Captive units do not report to their faction
 */
		if (unit->is_captive)
			continue;
#endif
/*
 * Observer present?
 */
		observer_present(unit, unit->current, day);
	}
}
#endif /*TURN_PROCESSOR*/
#endif /*not COMMIT_PROCESSOR*/
