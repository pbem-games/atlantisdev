/* $Id: control.c,v 1.1.1.1 2000/02/04 19:39:46 jtraub Exp $
 *	Handles controls and loyalties
 */
#include "overlord.h"

#ifndef CONTROL_CHUNK
#define CONTROL_CHUNK   1000
#endif


#if defined(UNIT_CONTROLS_OTHERS) || defined(LOCATION_FACTION_CONTROL)
/**
 ** Local cache
 **/
static control_s	*free_control_chain;
#ifdef LOCATION_FACTION_CONTROL
static loyalty_s	*free_loyalty_chain;


/**
 ** NEW_LOYALTY_INSTANCE
 **	Allocate a new chunk of loyalty blocks
 **/
loyalty_s *new_loyalty_instance(void)
{
loyalty_s	*loyalty;
int		i, j;
/*
 * Any loyalty chain?
 */
	if (!free_loyalty_chain) {
		free_loyalty_chain = (loyalty_s *)zero_malloc(sizeof(loyalty_s)*CONTROL_CHUNK);
		j = 0;
		for (i = 0; i < (CONTROL_CHUNK-1); i++)
			free_loyalty_chain[i].next = free_loyalty_chain + (++j);
	}
	loyalty = free_loyalty_chain;
	free_loyalty_chain = loyalty->next;
	loyalty->next = 0;
	return loyalty;
}
#endif


/**
 ** FREE_CONTROL_LIST
 **	List is not longer used, recycle
 **/
void free_control_list(control_s *control)
{
	if (!control)
		return;
	free_control_list(control->next);
	memset(control, 0, sizeof(*control));
	control->next = free_control_chain;
	free_control_chain = control;
}


/**
 ** NEW_CONTROL_INSTANCE
 **	Allocate a new chunk of control blocks
 **/
control_s *new_control_instance(void)
{
control_s	*control;
int		i, j;
/*
 * Any control chain?
 */
	if (!free_control_chain) {
		free_control_chain = (control_s *)zero_malloc(sizeof(control_s)*CONTROL_CHUNK);
		j = 0;
		for (i = 0; i < (CONTROL_CHUNK-1); i++)
			free_control_chain[i].next = free_control_chain + (++j);
	}
	control = free_control_chain;
	free_control_chain = control->next;
	control->next = 0;
	return control;
}
#endif


#ifdef UNIT_CONTROLS_OTHERS
/**
 ** UNIT_CONTROLS
 **	Unit exerts a control over other units
 **/
control_s *unit_controls(unit_s *unit, unit_s *oathed, int modifier)
{
control_s	*oath, *prev;
/*
 * Search for the oath record
 */
	prev = 0;
	for (oath = unit->master_of; oath; oath = oath->next)
		if (oath->u.unit == oathed)
			break;
		else
			prev = oath;
/*
 * No oath record? Create one
 */
	if (!oath) {
		oath = new_control_instance();
		if (prev)
			prev->next = oath;
		else
			unit->master_of = oath;
		oath->u.unit = oathed;
	}
#ifdef PARTIAL_CONTROLS
	oath->control += modifier;
#endif
	return oath;
}


/**
 ** INVERSE_UNIT_CONTROLS
 **	From a unit direct control, derive the inverse controls
 **/
void inverse_unit_controls(void)
{
unit_s		*unit, *oathed;
control_s	*master, *oath, *prev;
/*
 * First, clean any oathed records
 */
#ifdef PARTIAL_CONTROLS
	for (unit = unit_list; unit; unit = unit->next)
		for (oath = unit->oathed_to; oath; oath = oath->next)
			oath->control = 0;
#endif
/*
 * Next, preform inversion
 */
	for (unit = unit_list; unit; unit = unit->next)
		for (master = unit->master_of; master; master = master->next) {
#ifdef PARTIAL_CONTROLS
			if (master->control == 0)
				continue;
#endif
			oathed = master->u.unit;
			prev = 0;
			for (oath = oathed->oathed_to; oath; oath = oath->next)
				if (oath->u.unit == unit)
					break;
				else
					prev = oath;
			if (!oath) {
				oath = new_control_instance();
				if (prev)
					prev->next = oath;
				else
					oathed->oathed_to = oath;
				oath->u.unit = unit;
			}
#ifdef PARTIAL_CONTROLS
			oath->control = master->control;
#endif
		}
}
#endif


#ifdef LOCATION_FACTION_CONTROL
/**
 ** UNIT_GOVERNS
 **	Unit has mastery of a location
 **/
control_s *unit_governs(unit_s *unit, location_s *land, int modifier)
{
control_s	*grant, *prev;
/*
 * Search for the grant record
 */
	prev = 0;
	for (grant = unit->land_grants; grant; grant = grant->next)
		if (grant->u.location == land)
			break;
		else
			prev = grant;
/*
 * No grant record? Create one
 */
	if (!grant) {
		grant = new_control_instance();
		if (prev)
			prev->next = grant;
		else
			unit->land_grants = grant;
		grant->u.location = land;
	}
#ifdef PARTIAL_CONTROLS
	grant->control += modifier;
#endif
	return grant;
}


/**
 ** INVERSE_LAND_CONTROLS
 **	From a unit land control, derive the inverse controls
 **/
void inverse_land_controls(void)
{
unit_s		*unit;
location_s	*land;
control_s	*master, *oath, *prev;
/*
 * First, clean any oathed records
 */
#ifdef PARTIAL_CONTROLS
	for (land = location_list; land; land = land->next)
		for (oath = land->control_by; oath; oath = oath->next)
			oath->control = 0;
#endif
/*
 * Next, preform inversion
 */
	for (unit = unit_list; unit; unit = unit->next)
		for (master = unit->land_grants; master; master = master->next) {
#ifdef PARTIAL_CONTROLS
			if (master->control == 0)
				continue;
#endif
			land = master->u.location;
			prev = 0;
			for (oath = land->control_by; oath; oath = oath->next)
				if (oath->u.unit == unit)
					break;
				else
					prev = oath;
			if (!oath) {
				oath = new_control_instance();
				if (prev)
					prev->next = oath;
				else
					land->control_by = oath;
				oath->u.unit = unit;
			}
#ifdef PARTIAL_CONTROLS
			oath->control = master->control;
#endif
		}
}
#endif
