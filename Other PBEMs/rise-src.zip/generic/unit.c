/* $Id: unit.c,v 1.26 2000/12/07 23:56:11 jtraub Exp $
 *	Manipulate the units file
 */
#include "overlord.h"
#include "file.h"
#include "info.h"
#include "parser.h"
#include "command_e.h"

#ifdef TURN_PROCESSOR
#include "enums.h"
extern race_s *garrison_race;
extern void set_stack_movement(unit_s *, int);
#endif



/**
 ** Temporary function
 **/
#define allocate_dead_block()	mallocator(dead_unit_s)


/**
 ** Global variables
 **/
unit_s		*unit_list;
dead_unit_s	*dead_list;

#define UHASH_SIZE 500
unit_s *unit_hash[UHASH_SIZE];


/**
 ** The unit file
 **/
#ifndef UNIT_FILE_NAME
#define UNIT_FILE_NAME	"units"
#endif
#ifndef COMMIT_PROCESSOR
static
#endif
	char	unit_file_name[] = UNIT_FILE_NAME;
#ifndef COMMIT_PROCESSOR
static char	default_unit_name[] = "Unit";
#endif


#ifndef COMMIT_PROCESSOR
#ifdef TURN_PROCESSOR

unit_s *unit_was_taught(unit_s *student, skill_s *skill, int *was_taught)
{
	taught_s *teachers = student->taught;
	while(teachers) {
		if(teachers->exp->skill == skill) {
			*was_taught = 1;
			return teachers->teacher;
		}
		teachers = teachers->next;
	}
	return NULL;
}

void add_unit_teaching(unit_s *student, unit_s *teacher, experience_s *skill)
{
	taught_s *temp = mallocator(taught_s);
	temp->next = student->taught;
	student->taught = temp;
	temp->teacher = teacher;
	temp->exp = skill;
	return;
}

void free_unit_teaching(unit_s *student)
{
	taught_s *taught, *next;
	taught = student->taught;
	while(taught) {
		next = taught->next;
		free(taught);
		taught = next;
	}
	student->taught = NULL;
}

/**
 ** UNIT_HAS_RESOURCE
 ** check if a unit has a special resource
 **/
resource_s *unit_has_resource(unit_s *unit, item_s *type)
{
	resource_s *res;
	for(res = unit->special_resources; res; res = res->next) {
		if(res->type == type) return res;
	}
	return NULL;
}
#endif
 
/**
 ** UNIT_FROM_ID
 **	Returns the unit pointer associated with a tag. If specified,
 **	create the unit, because it is brand new.
 **/
unit_s *unit_from_id(int create)
{
    static unit_s *last = NULL;
    unit_s *scanner;
    int val = atoi(tag_token.text);
    int hash = val % UHASH_SIZE;

/*
 * Simple loop
 */
    for (scanner = unit_hash[hash]; scanner; scanner = scanner->next_hash) {
#ifdef USE_LONG_LONG
	if (scanner->id.all == tag_token.all)
#else
	if (strcmp(scanner->id.text, tag_token.text) == 0)
#endif
	    return scanner;
    }
/*
 * Creation occurs
 */
    if (create) {
	scanner = mallocator(unit_s);
	scanner->id = tag_token;
	scanner->next_hash = unit_hash[hash];
	unit_hash[hash] = scanner;
	if(last) {
	    last->next = scanner;
	    last = scanner;
	} else {
	    unit_list = scanner;
	    last = scanner;
	}
	scanner->name = strdup(default_unit_name);
#ifdef NUMERICAL_UNIT_IDS
	scanner->id_number = atoi(tag_token.text);
#ifndef MAIL_PROCESSOR
#ifdef ORDERS_NEEDED
	scanner->file = roll_1Dx(3);
#endif
#endif
#endif
    }
    return scanner;
}


/**
 ** DEAD_UNIT_EXISTED
 **	Return the dead unit, if that unit exists
 **/
dead_unit_s *dead_unit_existed(void)
{
dead_unit_s	*scanner;
/*
 * Figure out the faction
 */
	for (scanner = dead_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->id.all == tag_token.all)
#else
		if (strcmp(scanner->id.text, tag_token.text) == 0)
#endif
			break;
	return scanner;
}


#ifndef MAIL_PROCESSOR
/**
 ** POTENTIAL_UNIT_ID
 **	Unit might exist, or be created... someday
 **/
unit_s *potential_unit_id(faction_s *required)
{
faction_s	*faction;
unit_s		*unit;
t_tag		save_id;
int		l;
/*
 * Already exists?
 */
	if ((unit = unit_from_id(0)) != 0)
		return unit;
/*
 * May exist? Must end in 'n99'
 */
	l = strlen(tag_token.text);
	if (l < 4)
		return 0;
	if (tag_token.text[l-3] != 'n' ||
	    !isdigit(tag_token.text[l-2]) ||
	    !isdigit(tag_token.text[l-1]))
		return 0;
	save_id = tag_token;
	tag_token.text[l-3] = 0;
	tag_token.text[l-2] = 0;
	tag_token.text[l-1] = 0;
	faction = faction_from_id(0);
	tag_token = save_id;
	if (faction == 0)
		return 0;
	if (required && required != faction)
		return 0;
/*
 * Great! Faction, 'n', number!
 */
	unit = unit_from_id(1);
	unit->faction = faction;
	unit->inactive = 1;
	return unit;
}
#endif


#if defined(TURN_PROCESSOR) || defined(MAP_EDITOR)
#ifdef SORTED_UNIT_IDS
/**
 ** SORT_UNIT_IDS
 **	Sort all units IDs prior to save. Will be useful for next turn
 **/
static void sort_unit_ids(void)
{
unit_s	*unit, *previous, *next;
int	flag;
/*
 * Bubble sort (for now)
 */
	flag = 1;
	printf("Sorting units");
	while (flag) {
		flag = 0;
		previous = 0;
		unit = unit_list;
		next = unit->next;
		putchar('.');
		while (next) {
#ifdef NUMERICAL_UNIT_IDS
			if (unit->id_number < next->id_number) {
#else
			if (strcmp(unit->id.text, next->id.text) <= 0) {
#endif
				previous = unit;
				unit = next;
			} else {
				flag = 1;
				if (previous)
					previous->next = next;
				else
					unit_list = next;
				unit->next = next->next;
				next->next = unit;
				previous = next;
			}
			next = unit->next;
		}
	}
	putchar('\n');
}
#endif


/**
 ** SAVE_UNITS
 **	Rewrites the units file.
 **/
void save_units(void)
{
FILE		*save;
unit_s		*unit;
experience_s	*skill;
carry_s		*items;
unit_s		*stack;
dead_unit_s	*deads;
order_s		*order;
#if defined(UNIT_CONTROLS_OTHERS) || defined(LOCATION_FACTION_CONTROL)
control_s	*mastery;
#endif
#ifdef TURN_PROCESSOR
int	garr;
#endif
int		i;
/*
 * Sort units prior to writing?
 */
#ifdef SORTED_UNIT_IDS
	sort_unit_ids();
#endif
/*
 * Start writing
 */
	if ((save = fopen(new_file(unit_file_name), "w")) == 0)
		fatal_error(unit_file_name);
/*
 * Save actual units first
 */
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead || unit->virtual)
			continue;
		fprintf(save, "UNIT %s\n", unit->id.text);
		if (unit->faction)
			fprintf(save, "FACTION %s\n", unit->faction->id.text);
		if (unit->name && strcmp(unit->name, default_unit_name))
			fprintf(save, "NAME %s\n", unit->name);
		if (unit->description)
			fprintf(save, "DESCRIPTION %s\n", unit->description);
		if (unit->race && unit->size)
			fprintf(save, "RACE %s %d\n", unit->race->tag.text, unit->size);
		for (skill = unit->skilled; skill; skill = skill->next)
#ifdef SKILL_USE_POINTS
			if (skill->points)
				fprintf(save, "SKILL %s %ld\n", skill->skill->tag.text,
								skill->points);
#else
			if (skill->effective)
				fprintf(save, "SKILL %s\n", skill->skill->tag.text);
#endif
		for (items = unit->carrying; items; items = items->next) {
		    if (items->amount || items->tokens)
			fprintf(save, "ITEM %s %d %d %d\n",
				items->item->tag.text, items->amount,
				items->equipped, items->tokens);
		}
		if (unit->participate||unit->rank||unit->file||unit->movement) {
#ifdef TURN_PROCESSOR
			if(unit->rank != 0 && unit->race->type != RACE_LEADER) {
				unit->rank = 0;
			}
#endif
			fprintf(save, "TACTICS %d %d %d %d\n", unit->participate, unit->rank, unit->file, unit->movement);
		}
		for (i = 0; i < MAX_COMBAT_SETTING; i++)
			switch (unit->combat[i].option) {
#ifdef COMBAT_SET_MELEE
			    case COMBAT_SET_MELEE:
#endif
#ifdef COMBAT_SET_PARRY
			    case COMBAT_SET_PARRY:
#endif
#ifdef COMBAT_SET_RANGED
			    case COMBAT_SET_RANGED:
#endif
#ifdef COMBAT_SET_GUARD
			    case COMBAT_SET_GUARD:
#endif
				fprintf(save, "COMBAT %d %d %d\n", i, unit->combat[i].option, unit->combat[i].once);
				break;
#ifdef COMBAT_SET_SKILL
			    case COMBAT_SET_SKILL:
				fprintf(save, "COMBAT %d %s %d\n", i, unit->combat[i].u.use_skill->tag.text, unit->combat[i].once);
				break;
#endif
#ifdef COMBAT_SET_ITEM
			    case COMBAT_SET_ITEM:
				fprintf(save, "COMBAT %d %s %d\n", i, unit->combat[i].u.use_item->tag.text, unit->combat[i].once);
				break;
#endif
			}
		switch (unit->is_moving) {
		    case 1:
			fprintf(save, "MOVING\n");
			break;
		    case 2:
			fprintf(save, "MARCHING\n");
			break;
		}
		if(unit->escaping) {
			fprintf(save, "ESCAPING %d\n", unit->escaping);
		}

		if (unit->toward)
			fprintf(save, "MOVE %s %d %d %d\n", unit->toward->id.text, unit->move_for_days, unit->already_moved, unit->moving_by);
		if (unit->setting_advert)
			fprintf(save, "FLAG ADVERTISE\n");
#ifdef STEALTH_STATS
		if (unit->setting_report)
			fprintf(save, "FLAG ANNOUNCE\n");
#endif
		if (unit->setting_silent)
			fprintf(save, "FLAG SILENT\n");
		if(unit->setting_hushgive)
		    fprintf(save, "FLAG HUSHGIVE\n");
#ifdef TURN_PROCESSOR
		garr = 0;
		if(unit->race->type == RACE_LEADER) garr = 1;
		for(items = unit->carrying; items; items = items->next) {
			if(items->amount &&
			   items->item->item_type == ITEM_FOLLOWER &&
			   (items->item->equip_bonus.melee ||
			    items->item->equip_bonus.missile)) {
				garr = 1;
			}
			
		}
		if(garr) {
			if (unit->setting_protect)
				fprintf(save, "FLAG PROTECT\n");
			if (unit->setting_guard)
				fprintf(save, "FLAG GUARD\n");
		} else {
			if(unit->setting_protect || unit->setting_guard)
				printf("Bogus! unit %s is guarding/protecting.\n",
				       unit->id.text);
		}
#else
		if (unit->setting_protect)
			fprintf(save, "FLAG PROTECT\n");
		if (unit->setting_guard)
			fprintf(save, "FLAG GUARD\n");
#endif
#ifdef USES_FACTION_FUND
		if (unit->setting_support)
			fprintf(save, "FLAG SUPPORT\n");
		if (unit->setting_miser)
			fprintf(save, "FLAG MISER\n");
#endif
#ifdef PRISONERS_TAKEN
		if (unit->is_captive)
			fprintf(save, "FLAG PRISONER\n");
#endif
		putc('\n', save);
	}
/*
 * Archive stacking and orders after all units defined!
 */
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead)
			continue;
#ifdef UNIT_STACKS
		if (unit->stack == 0 &&
#else
		if (
#endif
#ifdef UNIT_CONTROLS_OTHERS
		    unit->master_of == 0 &&
#endif
#ifdef LOCATION_FACTION_CONTROL
		    unit->land_grants == 0 &&
#endif
		    unit->target_type == 0 && unit->orders == 0)
			continue;
		fprintf(save, "UNIT %s\n", unit->id.text);
		switch (unit->target_type) {
		    case ARGUMENT_IS_UNIT_ID:
			fprintf(save, "TARGET UNIT %s\n", unit->target.unit->id.text);
			break;
		    case ARGUMENT_IS_LOCATION_ID:
			fprintf(save, "TARGET LOCATION %s\n", unit->target.location->id.text);
			break;
		    case ARGUMENT_IS_TERRAIN_TAG:
			fprintf(save, "TARGET TERRAIN %s\n", unit->target.terrain->tag.text);
			break;
		    case ARGUMENT_IS_ITEM_TAG:
			fprintf(save, "TARGET ITEM %s\n", unit->target.item->tag.text);
			break;
		    case ARGUMENT_IS_RACE_TAG:
			fprintf(save, "TARGET RACE %s\n", unit->target.race->tag.text);
			break;
		    case ARGUMENT_IS_SKILL_TAG:
			fprintf(save, "TARGET SKILL %s\n", unit->target.skill->tag.text);
			break;
		}
#ifdef UNIT_STACKS
		if ((stack = unit->stack) != 0) {
			for (fprintf(save, "STACK"); stack; stack = stack->next_location)
				if (!unit->dead)
					fprintf(save, " %s", stack->id.text);
			putc('\n', save);
		}
#endif
#ifdef UNIT_CONTROLS_OTHERS
		for (mastery = unit->master_of; mastery; mastery = mastery->next)
#ifdef PARTIAL_CONTROLS
			if (mastery->control)
#endif
#ifdef TYPED_CONTROLS
			if (!mastery->type)
#endif
#ifdef PARTIAL_CONTROLS
				fprintf(save, "LORD %s %d\n", mastery->u.unit->id.text, mastery->control);
#else
				fprintf(save, "LORD %s\n", mastery->u.unit->id.text);
#endif
#endif
#ifdef LOCATION_FACTION_CONTROL
		for (mastery = unit->land_grants; mastery; mastery = mastery->next)
#ifdef PARTIAL_CONTROLS
			if (mastery->control)
#endif
#ifdef TYPED_CONTROLS
			if (!mastery->type)
#endif
#ifdef PARTIAL_CONTROLS
				fprintf(save, "MASTER %s %d\n", mastery->u.location->id.text, mastery->control);
#else
				fprintf(save, "MASTER %s\n", mastery->u.location->id.text);
#endif
#endif
		for (order = unit->orders; order; order = order->next) {
			fprintf(save, "ORDER ");
			write_order_on_file(save, order);
		}
		putc('\n', save);
	}
/*
 * Finally, write down dead units
 */
	for (unit = unit_list; unit; unit = unit->next)
		if (unit->dead) {
			fprintf(save, "DEAD %s\n", unit->id.text);
			if (unit->faction)
				fprintf(save, "FACTION %s\n", unit->faction->id.text);
			putc('\n', save);
		}
	for (deads = dead_list; deads; deads = deads->next) {
		fprintf(save, "DEAD %s\n", deads->id.text);
		if (deads->faction)
			fprintf(save, "FACTION %s\n", deads->faction->id.text);
		putc('\n', save);
	}
	fclose(save);
}


/**
 ** ASSIGN_UNIT_ID
 **	Create a new unit ID out of the the blue
 **/
void assign_unit_id(unit_s *unit)
{
extern int	roll_1Dx(int); /* normally in turn.h */
unit_s		*exist;
int		n;
unit_s *scanner;
int oldval;
int hash;
/*
 * Start empty
 */
	exist = unit;
	n = 1000 + roll_1Dx(99000);
	while (exist) {
		if (n > 999) {
#ifdef USE_LONG_LONG
			tag_token.all = 0;
#else
			memset(&tag_token, 0, sizeof(tag_token));
#endif
			sprintf(tag_token.text, "%d", n);
			if (dead_unit_existed())
				exist = unit_list;
			else
				exist = unit_from_id(0);
		}
		if(exist) {
			n = (n + 97) % 100000;
		}
	}

	/* Okay.  We need to unlink it from the hash here */
	oldval = atoi(unit->id.text);
	hash = oldval % UHASH_SIZE;
	if(unit_hash[hash] == unit) {
	    /* simple case */
	    unit_hash[hash] = unit->next_hash;
	} else {
	    scanner = unit_hash[hash];
	    while(scanner->next_hash != unit) scanner = scanner->next_hash;
	    scanner->next_hash = unit->next_hash;
	}

	unit->id = tag_token;
#ifdef NUMERICAL_UNIT_IDS
	unit->id_number = n;
#endif
	/* and link it back in here */
	hash = n % UHASH_SIZE;
	unit->next_hash = unit_hash[hash];
	unit_hash[hash] = unit;
}


/**
 ** RANDOM_UNIT_ID
 **	Create a new unit with a random ID
 **/
unit_s *random_unit_id(void)
{
unit_s	*scanner,
	*last = 0;
/*
 * Simple loop
 */
	for (scanner = unit_list; scanner; scanner = scanner->next)
		last = scanner;
/*
 * Creation occurs
 */
	scanner = mallocator(unit_s);
	if (last)
		last->next = scanner;
	else
		unit_list = scanner;
	assign_unit_id(scanner);
	return scanner;
}
#endif/*TURN_PROCESSOR or MAP_EDITOR*/


#ifdef TURN_PROCESSOR

#ifdef BATTLE_INITIATIVE
void unit_increment_battles(unit_s *unit)
{
	unit->num_battles++;
}
#endif

void unit_set_victor(unit_s *unit, char flag)
{
	unit_s *stack;
	unit->victor = flag;
	for(stack = unit->stack; stack; stack = stack->next_location) {
		unit_set_victor(stack, flag);
	}
}


/**
 ** UNIT_PERSONAL_EVENT
 **	Event occurs for unit
 **/
void unit_personal_event(unit_s *unit, int day, char *text)
{
event_s	*event, *list, *previous;
/*
 * Go.
 */
	event = new_dated_event();
	event->day = day;
	event->text = strdup(text);
#ifdef DEBUG
	printf("%s [%s]: %d - %s\n", unit->name, unit->id.text, day, text);
#endif
	previous = 0;
	for (list = unit->events; list; list = list->next)
		previous = list;
	if (previous)
		previous->next = event;
	else
		unit->events = event;
}
#endif/*TURN_PROCESSOR*/


#ifdef ORDERS_NEEDED
/**
 ** PARSE_CARRIED_ITEM
 **	Parse one possession for a unit
 **/
carry_s *parse_carried_item(carry_s *list)
{
item_s	*item;
carry_s	*owns;
/*
 * Threading
 */
	if (list) {
		list->next = parse_carried_item(list->next);
		return list;
	}
	if (!separate_tag())
		return 0;
	if (!(item = item_from_tag(0)))
		return 0;
	owns = new_carry_instance();
	owns->item = item;
	owns->amount = atoi(string_ptr);
	separate_token();
	owns->equipped = atoi(string_ptr);
	separate_token();
	owns->tokens = atoi(string_ptr);
	return owns;
}


/**
 ** UNIT_EXPERIENCES
 **	Unit has exerience in the given skill!
 **/
experience_s *unit_experiences(unit_s *unit, skill_s *skill, int create)
{
experience_s	*has, *previous;
/*
 * Go
 */
	previous = 0;
	for (has = unit->skilled; has; has = has->next)
		if (has->skill == skill)
			return has;
		else
			previous = has;
/*
 * Not owned. Create item?
 */
	if (create) {
		has = new_experience_instance();
		has->skill = skill;
		if (previous)
			previous->next = has;
		else
			unit->skilled = has;
	}
	return has;
}

/**
 ** UNIT_SPOILS
 **	Unit possess the given object as spoils!
 **/
carry_s *unit_spoils(unit_s *unit, item_s *item, int create)
{
carry_s	*has, *previous;
/*
 * Go
 */
	if (!item) abort();
	previous = 0;
	for (has = unit->spoils; has; has = has->next)
		if (has->item == item)
			return has;
		else
			previous = has;
/*
 * Not already spoils. Create item?
 */
	if (create) {
		has = new_carry_instance();
		has->item = item;
		if (previous)
			previous->next = has;
		else
			unit->spoils = has;
	}
	return has;
}


/**
 ** UNIT_POSSESSIONS
 **	Unit possess the given object!
 **/
carry_s *unit_possessions(unit_s *unit, item_s *item, int create)
{
carry_s	*has, *previous;
/*
 * Go
 */
	if (!item) abort();
	previous = 0;
	for (has = unit->carrying; has; has = has->next)
		if (has->item == item)
			return has;
		else
			previous = has;
/*
 * Not owned. Create item?
 */
	if (create) {
		has = new_carry_instance();
		has->item = item;
		if (previous)
			previous->next = has;
		else
			unit->carrying = has;
	}
	return has;
}


/**
 ** STACKED_UNIT
 **	Unit is stacked beneath
 **/
static unit_s *stacked_unit(unit_s *beneath, unit_s *stack)
{
	if (!stack) {
		beneath->next_location = 0;
		return beneath;
	}
#ifdef TRACING_REQUIRED
	if (stack->traced_unit)
			printf("stack %s->next_location was 0x%x\n", stack->id.text, (unsigned)stack->next_location);
#endif
	stack->next_location = stacked_unit(beneath, stack->next_location);
#ifdef TRACING_REQUIRED
	if (stack->traced_unit)
			printf("stack %s->next_location fixed to 0x%x\n", stack->id.text, (unsigned)stack->next_location);
#endif
	return stack;
}


#ifdef UNIT_STACKS
/**
 ** UNSTACK_UNIT
 **	Unit is no longer stacked under another
 **/
void unstack_unit(unit_s *unit)
{
unit_s	*leader;
unit_s	*previous, *list;
/*
 * Stacked?
 */
	if ((leader = unit->leader) == 0)
		return;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit || leader->traced_unit)
		printf("unstacking %s from %s\n", unit->id.text, leader->id.text);
#endif
	previous = 0;
	for (list = leader->stack; list; list = list->next_location)
		if (list == unit)
			break;
		else
			previous = list;
	if (list) {
		if (previous) {
			previous->next_location = unit->next_location;
#ifdef TRACING_REQUIRED
			if (previous->traced_unit)
				printf("previous %s->next_location skips %s to 0x%x\n", previous->id.text, unit->id.text, (unsigned)previous->next_location);
#endif
		} else {
			leader->stack = unit->next_location;
#ifdef TRACING_REQUIRED
			if (leader->traced_unit)
				printf("%s->stack now is equal to 0x%x\n", leader->id.text, (unsigned)leader->stack);
#endif
		}
		unit->next_location = 0;
	}
#ifdef TRACING_REQUIRED
	else if (unit->traced_unit)
		printf("not in leader stack???\n");
#endif
	unit->leader = 0;
	if(unit->is_captive) unit->is_captive = 0;
}


/**
 ** STACK_RELOCATED
 **	Stack is now at a specific location
 **/
void stack_relocated(unit_s *stack)
{
	while (stack) {
		stack->current = stack->leader->current;
		stack->true_location = stack->leader->true_location;
		stack_relocated(stack->stack);
		stack = stack->next_location;
	}
}


/**
 ** STACK_UNDER
 **	Unit is now stacked beneath another
 **/
void stack_under(unit_s *leader, unit_s *stacked)
{
	if (leader == stacked)
		return;
#ifdef TRACING_REQUIRED
	if (stacked->traced_unit || leader->traced_unit)
		printf("Unit %s stacks under %s\n", stacked->id.text, leader->id.text);
#endif
	move_to_location(stacked, 0);
	stacked->leader = leader;
	leader->stack = stacked_unit(stacked, leader->stack);
	stacked->current = leader->current;
	stacked->true_location = leader->true_location;
	stack_relocated(stacked->stack);
}
#endif


/**
 ** UNIT_IS_NOW_DEAD
 **	The unit is dead. All sub-stacked are moved upward once.
 **/
void unit_is_now_dead(unit_s *unit, int keep)
{
#ifdef UNIT_STACKS
unit_s	*tail, *next;
unit_s	*stack;
#ifdef TURN_PROCESSOR
int 	told = 0;
extern int today_number;	/* usually in turn.h */
#endif

	/* Fixup for possible movement  Move the unit back to where it was.*/
	if(unit->is_moving) {
		move_to_location(unit, unit->move_from);
#ifdef TURN_PROCESSOR
		set_stack_movement(unit, 0);
#endif
	}
#ifdef TURN_PROCESSOR
#ifdef PRISONERS_TAKEN
	stack = unit->stack;
	while(stack) {
		next = stack->next_location;
		if(stack->is_captive) {
			stack->is_captive = 0;
                        sprintf(work, "Freed because captor is no longer alive."
);
                        unit_personal_event(stack, today_number, work);
			if(!told) {
				sprintf(work, "All captives freed due to your death.");
				unit_personal_event(unit, today_number, work);
				told = 1;
			}
		}
		stack = next;
	}
#endif
#endif
/*
 * Any stacked?
 */
	if ((stack = unit->stack) != 0) {
		for (tail = stack; (next = tail->next_location) != 0; tail = next)
			tail->leader = unit->leader;

		tail->leader = unit->leader;
		tail->next_location = unit->next_location;
		unit->next_location = stack;
		unit->stack = 0;
	}
#endif
	unit->dead = 1;
	unit->size = 0;
	if (keep) {
		if (unit->leader)
			unstack_unit(unit);
	} else {
		move_to_location(unit, 0);
		unit->true_location = 0;
	}
}
#endif/*ORDERS_NEEDED*/


#ifdef TURN_PROCESSOR
/**
 ** VIRTUAL_UNIT
 **	Virtual units are created during the turn, and vanish afterward
 ** Virtual units are not saved, nor maintained, nor located anywhere.
 **/
unit_s *virtual_unit(race_s *racial, int size)
{
unit_s		*target;
experience_s	*intrinsic;
experience_s	*added;
char		virtua_id[8];
static int	virtua_number = 1;
/*
 * Summoning occurs
 */
	sprintf(virtua_id, "VIR%d", virtua_number++);
	synthetic_tag(virtua_id);
	target = unit_from_id(1);
	target->virtual = 1;
	target->race = racial;
	target->size = size;
	target->dead = 0;
	for (intrinsic = racial->skilled; intrinsic; intrinsic = intrinsic->next) {
		added = unit_experiences(target, intrinsic->skill, 1);
#ifdef SKILL_USE_POINTS
		added->points = intrinsic->points * size;
		adjust_experience(added, target->size);
#else
		added->effective = intrinsic->skill;
#endif
	}
	return target;
}
#endif


/**
 ** LOAD_UNITS
 **	Load the units file.  This must be called exactly once, and no
 **	more.
 **/
void load_units(void)
{
FILE		*units;
faction_s	*faction;
unit_s		*current_unit = 0;
dead_unit_s	*current_dead = 0;
#ifdef ORDERS_NEEDED
int		i;
#endif
/*
 * Start loading
 */
	if ((units = fopen(unit_file_name, "r")) == 0)
		fatal_error(unit_file_name);
/*
 */
	while (file_gets(units)) {
		if (keyword("UNIT")) {
			if (separate_tag()) {
#ifndef MAIL_PROCESSOR
				if ((current_unit = potential_unit_id(0)) == 0) {
#endif
					current_unit = unit_from_id(1);
#ifndef MAIL_PROCESSOR
#ifdef NUMERICAL_UNIT_IDS
					current_unit->id_number = atoi(tag_token.text);
#endif
				}
#endif
			} else
				current_unit = 0;
			current_dead = 0;
			continue;
		}
		if (keyword("DEAD")) {
			if (separate_tag()) {
				for (current_dead = dead_list; current_dead; current_dead = current_dead->next)
#ifdef USE_LONG_LONG
					if (current_dead->id.all == tag_token.all)
#else
					if (strcmp(current_dead->id.text, tag_token.text) == 0)
#endif
						break;
				if (!current_dead) {
					current_dead = allocate_dead_block();
					current_dead->id = tag_token;
					current_dead->next = dead_list;
					dead_list = current_dead;
				}
			} else
				current_dead = 0;
			current_unit = 0;
			continue;
		}
/*
 * FACTION is common to dead and alive
 */
		if (!current_unit && !current_dead)
			continue;
		if (keyword("FACTION")) {
			if (separate_tag()) {
				faction = faction_from_id(0);
				if (faction) {
					if (current_dead)
						current_dead->faction = faction;
					else {
						if (current_unit->faction == faction)
#ifndef MAIL_PROCESSOR
						if(!current_unit->inactive)
#endif
							continue;
						if (current_unit->faction != 0)
#ifndef MAIL_PROCESSOR
						if(!current_unit->inactive)
#endif
							fprintf(stderr, "Base inconsistency for unit %s\n", current_unit->id.text);
						current_unit->faction = faction;
						current_unit->same_faction = faction->units;
						faction->units = current_unit;
					}
				}
			}
			continue;
		}
		if (!current_unit)
			continue;
		if (keyword("NAME")) {
			make_a_copy_(current_unit->name, string_ptr);
			continue;
		}
#ifndef MAIL_PROCESSOR
#ifdef ORDERS_NEEDED
		if (keyword("DESCRIPTION")) {
			make_a_copy_(current_unit->description, string_ptr);
			continue;
		}
		if (keyword("ORDER")) {
			current_unit->orders = parse_order_line(current_unit->orders);
			continue;
		}
		if (keyword("RACE")) {
			if (separate_tag()) {
				current_unit->race = race_from_tag(0);
				current_unit->size = atoi(string_ptr);
			}
			continue;
		}
		if (keyword("SKILL")) {
			current_unit->skilled = parse_experience_skill(current_unit->skilled,
								current_unit->size);
			continue;
		}
		if (keyword("ITEM")) {
			current_unit->carrying = parse_carried_item(current_unit->carrying);
			continue;
		}
#ifdef UNIT_STACKS
		if (keyword("STACK")) {
			while (separate_tag())
				stack_under(current_unit, unit_from_id(1));
			continue;
		}
#endif
		if (keyword("TACTICS")) {
			current_unit->participate = atoi(string_ptr);
			separate_token();
			current_unit->rank = atoi(string_ptr);
			separate_token();
			current_unit->file = atoi(string_ptr);
			separate_token();
			current_unit->movement = atoi(string_ptr);
			continue;
		}
		if (keyword("COMBAT")) {
			i = atoi(string_ptr);
			separate_token();
			if (separate_tag()) {
				if ((current_unit->combat[i].u.use_skill = skill_from_tag(0)) != 0)
					current_unit->combat[i].option = COMBAT_SET_SKILL;
				else if ((current_unit->combat[i].u.use_item = item_from_tag(0)) != 0)
					current_unit->combat[i].option = COMBAT_SET_ITEM;
				else
					current_unit->combat[i].option = atoi(tag_token.text);
			} else
				current_unit->combat[i].option = atoi(string_ptr);
			if(separate_token()) {
			    current_unit->combat[i].once = atoi(token_keyword);
			}
			continue;
		}
		if (keyword("FLAG")) {
			if (keyword("ADVERTISE"))
				current_unit->setting_advert = 1;
#ifdef STEALTH_STATS
			else if (keyword("ANNOUNCE"))
				current_unit->setting_report = 1;
#endif
			else if (keyword("SILENT"))
				current_unit->setting_silent = 1;
			else if (keyword("PROTECT"))
				current_unit->setting_protect = 1;
			else if (keyword("GUARD"))
				current_unit->setting_guard = 1;
			else if (keyword("HUSHGIVE"))
			    current_unit->setting_hushgive = 1;
#ifdef USES_FACTION_FUND
			else if (keyword("SUPPORT"))
				current_unit->setting_support = 1;
			else if (keyword("MISER"))
				current_unit->setting_miser = 1;
#endif
#ifdef PRISONERS_TAKEN
			else if (keyword("PRISONER"))
				current_unit->is_captive = 1;
#endif
			continue;
		}
#ifdef TRACING_REQUIRED
		if (keyword("TRACE")) {
			current_unit->traced_unit = 1;
			continue;
		}
#endif
#ifdef UNIT_CONTROLS_OTHERS
		if (keyword("LORD")) {
			if (separate_tag())
				(void)unit_controls(current_unit, unit_from_id(0), atoi(string_ptr));
			continue;
		}
#endif
#ifdef LOCATION_FACTION_CONTROL
		if (keyword("MASTER")) {
			if (separate_tag())
				(void)unit_governs(current_unit, location_from_id(0), atoi(string_ptr));
			continue;
		}
#endif

		if (keyword("MOVE")) {
			if (separate_tag()) {
				current_unit->toward = location_from_id(1);
				current_unit->move_for_days = atoi(string_ptr);
				separate_token();
				current_unit->already_moved = atoi(string_ptr);
				separate_token();
				current_unit->moving_by = atoi(string_ptr);
			}
			continue;
		}
		if(keyword("ESCAPING")) {
			current_unit->escaping = atoi(string_ptr);
			continue;
		}

		if (keyword("MOVING")) {
			current_unit->is_moving = 1;
			continue;
		}
		if (keyword("MARCHING")) {
			current_unit->is_moving = 2;
			continue;
		}
		if (keyword("TARGET")) {
			current_unit->target_type = ARGUMENT_IS_EMPTY;
			if (keyword("UNIT")) {
				if (separate_tag()) {
					if ((current_unit->target.unit = potential_unit_id(0)) == 0)
						current_unit->target.unit = unit_from_id(1);
					current_unit->target_type = ARGUMENT_IS_UNIT_ID;
				}
				continue;
			}
			if (keyword("LOCATION")) {
				if (separate_tag()) {
					current_unit->target.location = location_from_id(1);
					current_unit->target_type = ARGUMENT_IS_LOCATION_ID;
				}
				continue;
			}
			if (keyword("TERRAIN")) {
				if (separate_tag() && (current_unit->target.terrain = terrain_from_tag(0)) != 0)
					current_unit->target_type = ARGUMENT_IS_TERRAIN_TAG;
				continue;
			}
			if (keyword("ITEM")) {
				if (separate_tag() && (current_unit->target.item = item_from_tag(0)) != 0)
					current_unit->target_type = ARGUMENT_IS_ITEM_TAG;
				continue;
			}
			if (keyword("RACE")) {
				if (separate_tag() && (current_unit->target.race = race_from_tag(0)) != 0)
					current_unit->target_type = ARGUMENT_IS_RACE_TAG;
				continue;
			}
			if (keyword("SKILL")) {
				if (separate_tag() && (current_unit->target.skill = skill_from_tag(0)) != 0)
					current_unit->target_type = ARGUMENT_IS_SKILL_TAG;
				continue;
			}
			continue;
		}
/*
 * The GM has prepared events for the player
 */
#ifdef TURN_PROCESSOR
		if (keyword("EVENT")) {
			separate_token();
			while (isspace(*string_ptr))
				string_ptr++;
			unit_personal_event(current_unit, atoi(token_keyword), string_ptr);
		}
#endif
#endif
#endif
	}
/*
 * Load done
 */
	fclose(units);
}
#endif
