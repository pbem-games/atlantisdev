/* $Id: checker.h,v 1.1.1.1 2000/02/04 19:39:46 jtraub Exp $
 *	Syntax checker's particularities
 */
#include "turn.h"
#include "parser.h"

/**
 ** Global variables
 **/
extern FILE		*current_report;
extern faction_s	*current_faction;
extern int		cleared;
extern int		conditional;
extern int		days;
extern unit_s		*current_unit;
extern char		raw_order[];


/**
 ** Common subroutine
 **/
extern int	basic_syntax_check(unit_s *,order_s *);
