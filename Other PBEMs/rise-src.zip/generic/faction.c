/* $Id: faction.c,v 1.13 2000/08/05 17:00:57 jtraub Exp $
 *	Manipulate the faction file
 */
#include "overlord.h"
#include "file.h"
#include "info.h"
#include "parser.h"


#ifdef PRESS_REWARD
#ifndef RUMOR_REWARD
#define RUMOR_REWARD PRESS_REWARD
#endif
#endif


/**
 ** Global variables
 **/
faction_s	*faction_list;


/**
 ** The faction file
 **/
#ifndef FACTION_FILE_NAME
#define FACTION_FILE_NAME	"factions"
#endif
#ifndef COMMIT_PROCESSOR
static
#endif
	char	faction_file_name[] = FACTION_FILE_NAME;
static char	default_faction_name[] = "Faction";


/**
 ** FACTION_FROM_ID
 **	Returns the faction pointer associated with a tag. If specified,
 **	create the faction, because it is brand new.
 **/
faction_s *faction_from_id(int create)
{
faction_s	*scanner,
		*last = 0;
/*
 * Simple loop
 */
	for (scanner = faction_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->id.all == tag_token.all)
#else
		if (strcmp(scanner->id.text, tag_token.text) == 0)
#endif
			return scanner;
		else
			last = scanner;
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(faction_s);
		scanner->id = tag_token;
		if (last)
			last->next = scanner;
		else
			faction_list = scanner;
		scanner->name = strdup(default_faction_name);
#ifdef ORDERS_NEEDED
		scanner->anon_attitude = -1;
#endif
	}
	return scanner;
}


#ifndef COMMIT_PROCESSOR
#ifdef ORDERS_NEEDED
/**
 ** SAVE_FACTIONS
 **	Rewrites the factions file.
 **/
void save_factions(void)
{
FILE		*save;
faction_s	*faction;
stance_s	*stances;
unit_s		*unit;
#ifdef REPORTS_ITEM_KNOWLEDGE
itemknow_s	*item_known;
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
skillknow_s	*skill_known;
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
raceknow_s	*race_known;
#endif
/*
 * Start writing
 */
	if ((save = fopen(new_file(faction_file_name), "w")) == 0)
		fatal_error(faction_file_name);
	for (faction = faction_list; faction; faction = faction->next) {
		if (faction->resigned)
			continue;
		fprintf(save, "FACTION %s\n", faction->id.text);
		if (faction->e_mail)
			fprintf(save, "EMAIL %s\n", faction->e_mail);
		if (faction->password)
			fprintf(save, "PASSWORD %s\n", faction->password);
		if (faction->name && strcmp(faction->name, default_faction_name))
			fprintf(save, "NAME %s\n", faction->name);
		if (faction->npc)
			fprintf(save, "NPC\n");
		if (faction->dissolve)
			fprintf(save, "DISSOLVE %d\n", faction->dissolve);
#ifdef USES_FACTION_FUND
		if (faction->faction_fund)
			fprintf(save, "FUNDS %d\n", faction->faction_fund);
#endif
#ifdef USES_FATE_POINTS
		if (faction->fate_points)
			fprintf(save, "FATE %d\n", faction->fate_points);
#endif
#ifdef USES_CONTROL_POINTS
		if (faction->control_bonus)
			fprintf(save, "CONTROL %d\n", faction->control_bonus);
#endif
		if (faction->attitude)
			fprintf(save, "ATTITUDE %d\n", faction->attitude);
		if (faction->anon_attitude >= 0)
			fprintf(save, "ANON_ATTITUDE %d\n", faction->anon_attitude);
		for (stances = faction->stances; stances; stances = stances->next) {
			if(stances->attitude < 0) continue;
			if(stances->faction && faction->vassal_of == stances->faction) continue;
#ifdef STANCE_TOWARD_UNITS
			if (stances->unit) {
				if(!stances->unit->size) continue;
				if(stances->unit->faction && stances->unit->faction == faction->vassal_of) continue;
				fprintf(save, "STANCE UNIT %s %d\n", stances->unit->id.text, stances->attitude);
			} else
#endif
				if (stances->faction && !stances->faction->resigned)
					fprintf(save, "STANCE %s %d\n", stances->faction->id.text, stances->attitude);
		}
		if ((unit = faction->units) != 0) {
			for (fprintf(save, "UNIT"); unit; unit = unit->same_faction)
				if (unit->dead == 0 && unit->inactive == 0 && unit->size > 0 && unit->faction == faction)
					fprintf(save, " %s", unit->id.text);
			putc('\n', save);
		}
#ifdef OATH_TOWARD_FACTIONS
		if (faction->vassal_of && !faction->vassal_of->resigned)
			fprintf(save, "OATHED %s\n", faction->vassal_of->id.text);
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
		for (race_known = faction->known_races; race_known; race_known = race_known->next)
			fprintf(save, "RACE %s\n", race_known->about->tag.text);
#endif
#ifdef REPORTS_ITEM_KNOWLEDGE
		for (item_known = faction->known_items; item_known; item_known = item_known->next)
			fprintf(save, "ITEM %s\n", item_known->about->tag.text);
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
		for (skill_known = faction->known_skills; skill_known; skill_known = skill_known->next)
#ifdef USES_SKILL_LEVELS
			fprintf(save, "SKILL %s %d\n", skill_known->about->tag.text,
							skill_known->at_level);
#else
			fprintf(save, "SKILL %s\n", skill_known->about->tag.text);
#endif
#endif
		putc('\n', save);
	}
	fclose(save);
}


#ifdef TURN_PROCESSOR
#ifdef USES_FACTION_FUND
/**
 ** ADJUST_FACTIONS
 **	Perform a post-load factions adjust
 **/
void adjust_factions(void)
{
faction_s	*faction;
extern char     press_file_name[];
extern char     rumor_file_name[];
/*
 * Loop on all factions
 */
    for (faction = faction_list; faction; faction = faction->next) {
#ifdef USES_FACTION_FUND
#ifdef PRESS_REWARD
        if (!access(player_specific_file(faction, press_file_name), 0)) {
            faction->faction_fund += PRESS_REWARD;
            faction->turn_rewards += PRESS_REWARD;
            sprintf(work, "$%d reward for submitting a news/rumor article",
                    PRESS_REWARD);
            faction_wide_event(faction, 1, work);
        } else {
            if (!access(player_specific_file(faction, rumor_file_name), 0)) {
                faction->faction_fund += RUMOR_REWARD;
                faction->turn_rewards += RUMOR_REWARD;
                sprintf(work, "$%d reward for submitting a news/rumor article",
                        RUMOR_REWARD);
                faction_wide_event(faction, 1, work);
            }
        }
#endif
#endif
    }
}
#endif/*USES_FACTION_FUND*/


/**
 ** FACTION_WIDE_EVENT
 **	Report an event at faction level
 **/
void faction_wide_event(faction_s *faction, int day, char *text)
{
event_s	*list, *last;
/*
 * Insert at last position, for the appropriate day
 */
	last = 0;
	for (list = faction->globals; list; list = list->next)
		if (list->day > day)
			break;
		else
			last = list;
/*
 * Synthetise new event
 */
	list = new_dated_event();
	if (last) {
		list->next = last->next;
		last->next = list;
	} else {
		list->next = faction->globals;
		faction->globals = list;
	}
	list->day = day;
	list->text = strdup(text);
}
#endif/*TURN_PROCESSOR*/


#ifdef STANCE_TOWARD_UNITS
/**
 ** FIND_STANCE_FOR
 **	Find a stance in the stance list
 **/
stance_s *find_unit_stance_for(faction_s *by_faction, unit_s *for_unit, int create)
{
stance_s	*found, *previous;
/*
 * Scan stance
 */
	previous = 0;
	for (found = by_faction->stances; found; found = found->next)
		if (found->unit == for_unit)
			break;
		else
			previous = found;
/*
 * Create if not found?
 */
	if (!found && create) {
		found = mallocator(stance_s);
		found->unit = for_unit;
		if (previous)
			previous->next = found;
		else
			by_faction->stances = found;
	}
	return found;
}
#endif /*STANCE_TOWARD_UNITS*/


/**
 ** FIND_STANCE_FOR
 **	Find a stance in the stance list
 **/
stance_s *find_stance_for(faction_s *by_faction, faction_s *for_faction, int create)
{
stance_s	*found, *previous;
/*
 * Scan stance
 */
	previous = 0;
	for (found = by_faction->stances; found; found = found->next)
		if (found->faction == for_faction)
			break;
		else
			previous = found;
/*
 * Create if not found?
 */
	if (!found && create) {
		found = mallocator(stance_s);
		found->faction = for_faction;
		if (previous)
			previous->next = found;
		else
			by_faction->stances = found;
	}
	return found;
}
#endif /*ORDERS_NEEDED*/
#endif /* ! COMMIT */

/**
 ** PLAYER_SPECIFIC_FILE
 **	Return a player-specific file name from that player's directory
 **/
char *player_specific_file(faction_s *faction, char *type)
{
static char	path[256];
/*
 * Quick'n easy
 */
	sprintf(path, "players/%s/%s.%d", faction->id.text,
				type, game_turn_number);
	return path;
}

/**
 ** LOAD_FACTIONS
 **	Load the factions file.  This must be called exactly once, and no
 **	more.
 **/
void load_factions(void)
{
FILE		*factions;
faction_s	*current_faction = 0;
#ifdef ORDERS_NEEDED
stance_s	*stance;
faction_s	*other_faction;
#ifdef STANCE_TOWARD_UNITS
unit_s		*other_unit;
#endif
#endif
unit_s		*unit;
unit_s		*last = 0;
/*
 * Start loading
 */
	if ((factions = fopen(faction_file_name, "r")) == 0)
		fatal_error(faction_file_name);
/*
 * Main loop
 */
	while (file_gets(factions)) {
		if (keyword("FACTION")) {
			last = 0;
			if (separate_tag()) {
				current_faction = faction_from_id(1);
				for (unit = current_faction->units; unit; unit = unit->same_faction)
					last = unit;
				if (strncmp(tag_token.text, "npc", 3) == 0)
					current_faction->npc = 1;
			} else
				current_faction = 0;
			continue;
		}
		if (!current_faction)
			continue;
		if (keyword("EMAIL")) {
			if (separate_token()) {
				make_a_copy_(current_faction->e_mail, token_keyword);
			}
			continue;
		}
		if (keyword("PASSWORD")) {
			if (separate_token()) {
				make_a_copy_(current_faction->password, token_keyword);
			}
			continue;
		}
		if (keyword("NAME")) {
			make_a_copy_(current_faction->name, string_ptr);
			continue;
		}
		if (keyword("DISSOLVE")) {
			current_faction->dissolve = atoi(string_ptr);
			continue;
		}
		if (keyword("NPC")) {
			current_faction->npc = 1;
			continue;
		}
		if(keyword("NEW")) {
			current_faction->new_fac = 1;
			continue;
		}
#ifdef OATH_TOWARD_FACTIONS
		if (keyword("OATHED")) {
			if (separate_tag())
				current_faction->vassal_of = faction_from_id(1);
			continue;
		}
#endif
#ifdef ORDERS_NEEDED
#ifdef USES_FACTION_FUND
		if (keyword("FUNDS")) {
			current_faction->faction_fund += atoi(string_ptr);
			continue;
		}
		if (keyword("GMREWARD")) {
			current_faction->faction_fund += atoi(string_ptr);
			current_faction->turn_rewards += atoi(string_ptr);
			continue;
		}
		if (keyword("REWARD")) {
			int val;
			separate_token();
			val = atoi(token_keyword);
#ifdef TURN_PROCESSOR
			faction_wide_event(current_faction, 1, string_ptr);
#endif
			current_faction->faction_fund += val;
			current_faction->turn_rewards += val;
			continue;
		}
#endif/*USES_FACTION_FUND*/
#ifdef USES_FATE_POINTS
		if (keyword("FATE")) {
			current_faction->fate_points += atoi(string_ptr);
			continue;
		}
#endif/*USES_FATE_POINTS*/
#ifdef USES_CONTROL_POINTS
		if (keyword("CONTROL")) {
			current_faction->control_bonus += atoi(string_ptr);
			continue;
		}
#endif/*USES_CONTROL_POINTS*/
		if (keyword("ATTITUDE")) {
			current_faction->attitude = atoi(string_ptr);
			if (current_faction->attitude == ATTITUDE_IS_ENEMY)
				current_faction->has_enemies = 1;
			continue;
		}
		if (keyword("ANON_ATTITUDE")) {
			current_faction->anon_attitude = atoi(string_ptr);
			if (current_faction->anon_attitude == ATTITUDE_IS_ENEMY)
				current_faction->has_enemies = 1;
			continue;
		}
		if (keyword("STANCE")) {
			if (separate_tag()) {
#ifdef STANCE_TOWARD_UNITS
				if (strcasecmp(tag_token.text, "unit") == 0) {
					if (!separate_tag())
						continue;
					other_unit = unit_from_id(1);
					stance = find_unit_stance_for(current_faction, other_unit, 1);
				} else {
#endif
					other_faction = faction_from_id(1);
					stance = find_stance_for(current_faction, other_faction, 1);
#ifdef STANCE_TOWARD_UNITS
				}
#endif
				stance->attitude = atoi(string_ptr);
				if (stance->attitude == ATTITUDE_IS_ENEMY)
					current_faction->has_enemies = 1;
			}
			continue;
		}
#ifdef REPORTS_ITEM_KNOWLEDGE
		if (keyword("ITEM")) {
itemknow_s	*known;
itemknow_s	*prev, *list;
item_s		*item;
			if (separate_tag() && (item = item_from_tag(0)) != 0) {
				known = new_item_knowledge();
				known->about = item;
				if (*string_ptr != '0')
					known->report = 1;
				prev = 0;
				for (list = current_faction->known_items; list; list = list->next)
					prev = list;
				if (prev)
					prev->next = known;
				else
					current_faction->known_items = known;
			}
			continue;
		}
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
		if (keyword("RACE")) {
raceknow_s	*known;
raceknow_s	*prev, *list;
race_s		*race;
			if (separate_tag() && (race = race_from_tag(0)) != 0) {
				known = new_race_knowledge();
				known->about = race;
				if (*string_ptr != '0')
					known->report = 1;
				prev = 0;
				for (list = current_faction->known_races; list; list = list->next)
					prev = list;
				if (prev)
					prev->next = known;
				else
					current_faction->known_races = known;
			}
			continue;
		}
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
		if (keyword("SKILL")) {
skillknow_s	*known;
skillknow_s	*prev, *list;
skill_s		*skill;
			if (separate_tag() && (skill = skill_from_tag(0)) != 0) {
				known = new_skill_knowledge();
				known->about = skill;
#ifdef USES_SKILL_LEVELS
				known->from_level =
				known->at_level = atoi(string_ptr);
#else
				if (*string_ptr != '0')
					known->report = 1;
#endif
				prev = 0;
				for (list = current_faction->known_skills; list; list = list->next)
					prev = list;
				if (prev)
					prev->next = known;
				else
					current_faction->known_skills = known;
			}
			continue;
		}
#endif
#ifdef TURN_PROCESSOR
		if (keyword("EVENT")) {
			separate_token();
			faction_wide_event(current_faction, atoi(token_keyword), string_ptr);
			continue;
		}
#endif
/*
 * Ordered list of units
 */
		if (keyword("UNIT")) {
			while (separate_tag()) {
				unit = unit_from_id(1);
				if (unit->faction) {
					if (unit->faction != current_faction) {
						fprintf(stderr, "Base inconsistency! Unit %s belongs to %s & %s\n",
								unit->id.text, current_faction->id.text, unit->faction->id.text);
						exit(1);
					}
				} else {
/*
 * Link at end of chain
 */
					unit->faction = current_faction;
					unit->same_faction = 0;
					if (last)
						last->same_faction = unit;
					else
						current_faction->units = unit;
					last = unit;
				}
			}
		}
#endif/*TURN_PROCESSOR*/
	}
/*
 * Load done
 */
	fclose(factions);
}
