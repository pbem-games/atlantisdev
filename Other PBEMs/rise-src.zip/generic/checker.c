/* $Id: checker.c,v 1.10 2000/07/23 04:06:03 jtraub Exp $
 *	Syntax checker. Currently, only comments all orders, do not validate any!
 */
#include "checker.h"
#include "email.h"
#include "command_e.h"


/**
 ** Global variables
 **/
FILE		*current_report;
faction_s	*current_faction;
int		cleared;
int		conditional;
int		days;
unit_s		*current_unit;
char		raw_order[sizeof(work)];


/**
 ** BASIC_SYNTAX_CHECK
 **	Parse one line of orders, according to the syntax descriptor. No
 ** specific parsing is needed. It is assumed that all arguments are mandatory.
 **/
int basic_syntax_check(unit_s *unit, order_s *added)
{
char	*save_ptr;
int	i;
char	optional;
/*
 * Do parser
 */
	for (i = 0; i < MAX_ORDER_ARGUMENTS; i++) {
		optional = added->executing.types[i] & ARGUMENT_IS_OPTIONAL;
		switch (added->executing.types[i] & ARGUMENT_MASK) {
		    case 0:
			return 0;
		    case ARGUMENT_IS_UNIT_OR_FACTION_ID:
                        if(!separate_tag()) {
                                added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing unit or faction ID\n", raw_order);
				return 1;
			} else {
                                if((added->arguments[i].unit = potential_unit_id
(0)) == 0) {
                                        if((added->arguments[i].faction = faction_from_id(0)) == 0) {
                                                added->executing.types[i] = 0;
						fprintf(current_report, "%s\n>>> invalid unit or faction ID\n", raw_order);
						return 1;
                                        } else {
                                                added->executing.types[i] = ARGUMENT_IS_FACTION_ID;
						return 0;
					}
                                } else {
                                        added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
					return 0;
                                }
                        }
                        break;

		    case ARGUMENT_IS_UNIT_ID:
			if (!separate_tag() || (added->arguments[i].unit = potential_unit_id(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing unit ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_LOCATION_ID:
			if (!separate_tag() || (added->arguments[i].location = location_from_id(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing location ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_FACTION_ID:
			if (!separate_tag() || (added->arguments[i].faction = faction_from_id(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing faction ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_ITEM_TAG:
			if (!separate_tag() || (added->arguments[i].item = item_from_tag(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing item ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_SKILL_TAG:
			if (!separate_tag() || (added->arguments[i].skill = skill_from_tag(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing skill ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_RACE_TAG:
			if (!separate_tag() || (added->arguments[i].race = race_from_tag(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing race ID\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_TERRAIN_TAG:
			if (!separate_tag() || (added->arguments[i].terrain = terrain_from_tag(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional && !tag_token.text[0])
					return 0;
				fprintf(current_report, "%s\n>>> missing terrain ID\n", raw_order);
				return 1;
			}
			break;
#ifdef USES_TITLE_SYSTEM
		    case ARGUMENT_IS_TITLE_TAG:
			if (!separate_tag() || (added->arguments[i].title = title_from_tag(0)) == 0) {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> missing title ID\n", raw_order);
				return 1;
			}
			break;
#endif
		    case ARGUMENT_IS_STANCE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, stance_arguments)) < 0) {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> missing/invalid stance\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_BOOLEAN:
			separate_token();
			if (strcasecmp(token_keyword, "ON") == 0)
				added->arguments[i].number = 1;
			else
				if (strcasecmp(token_keyword, "OFF") == 0)
					added->arguments[i].number = 0;
				else {
					added->executing.types[i] = 0;
					if (optional & !token_keyword[0])
						return 0;
					fprintf(current_report, "%s\n>>> missing boolean\n", raw_order);
					return 1;
				}
			break;
		    case ARGUMENT_IS_STRING:
			separate_token();
			if (token_keyword[0])
				added->arguments[i].string = strdup(token_keyword);
			else {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> missing string\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_NUMBER:
			separate_token();
			if (isdigit(token_keyword[0]) || token_keyword[0] == '-')
				added->arguments[i].number = atoi(token_keyword);
			else
				if (token_keyword[0] == '+')
					added->arguments[i].number = atoi(token_keyword+1);
				else {
					added->executing.types[i] = 0;
					if (optional && !token_keyword[0])
						return 0;
					fprintf(current_report, "%s\n>>> invalid number\n", raw_order);
					return 1;
				}
			break;
		    case ARGUMENT_IS_BATTLE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, battle_arguments)) < 0) {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> invalid battle tactic\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_RANK:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, rank_arguments)) < 0) {
				added->executing.types[i] = 0;
				if (optional && !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid battle rank\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_FILE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, file_arguments)) < 0) {
				added->executing.types[i] = 0;
				if (optional && !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid battle file\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_MOVE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, move_arguments)) < 0) {
				added->executing.types[i] = 0;
				if (optional && !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid battle move\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_SETTING:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, possible_settings)) < 0) {
				added->executing.types[i] = 0;
				if (optional && !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid setting name\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_DIRECTION:
			save_ptr = string_ptr;
			if (separate_tag()) {
				if ((added->arguments[i].location = location_from_id(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
					break;
				}
				if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
					break;
				}
			}
			string_ptr = save_ptr;
			separate_token();
			if (token_keyword[0]) {
				added->arguments[i].string = strdup(token_keyword);
				added->executing.types[i] = ARGUMENT_IS_STRING;
			} else {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> unrecognisable direction\n", raw_order);
				return 1;
			}
			break;
		    case ARGUMENT_IS_COMBAT_OPTION:
			if (keyword("ONCE")) {
			    added->combat_once[i] = 1;
			    i--;
			    break;
			}
			if(*string_ptr == '-') {
			    added->combat_once[i] = 1;
			    string_ptr++;
			}
			if (keyword("MELEE")) {
				added->arguments[i].number = 2;
				break;
			}
			if (keyword("RANGED")) {
				added->arguments[i].number = 3;
				break;
			}
			if (keyword("GUARD")) {
				added->arguments[i].number = 4;
				break;
			}
			if (separate_tag()) {
				if ((added->arguments[i].skill = skill_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_SKILL_TAG;
					break;
				}
				if ((added->arguments[i].item = item_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_ITEM_TAG;
					break;
				}
			}
			added->executing.types[i] = 0;
			if (optional)
				return 0;
			fprintf(current_report, "%s\n>>> unrecognisable combat action\n", raw_order);
			return 1;
		    case ARGUMENT_IS_COMBAT_TARGET:
			if(!separate_tag()) {
				added->executing.types[i] = 0;
				if (optional)
					return 0;
				fprintf(current_report, "%s\n>>> unrecognisable combat target\n", raw_order);
				return 1;
			}
			if ((added->arguments[i].unit = potential_unit_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
				break;
			}
			if ((added->arguments[i].location = location_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
				break;
			}
			if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
				break;
			}
			if ((added->arguments[i].faction = faction_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_FACTION_ID;
				break;
			}
		    case ARGUMENT_IS_TARGET:
			if (!separate_tag()) {
				/* Try treating it as a string */
				if(!separate_token()) {
					added->executing.types[i] = 0;
					if (optional) return 0;
					fprintf(current_report, "%s\n>>> unrecognisable target\n",
							raw_order);
					return 1;
				}
				if((added->arguments[i].terrain = terrain_from_token()) != 0) {
					added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
					break;
				}
				if(optional) return 0;
				fprintf(current_report, "%s\n>>> unrecognisable target\n",
						raw_order);
				return 1;
			}
			if ((added->arguments[i].unit = potential_unit_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
				break;
			}
			if ((added->arguments[i].location = location_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
				break;
			}
			if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
				break;
			}
			if ((added->arguments[i].skill = skill_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_SKILL_TAG;
				break;
			}
			if ((added->arguments[i].item = item_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_ITEM_TAG;
				break;
			}
			if ((added->arguments[i].race = race_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_RACE_TAG;
				break;
			}
			added->executing.types[i] = 0;
			if (optional)
				return 0;
			fprintf(current_report, "%s\n>>> unrecognisable target\n", raw_order);
			return 1;
#ifdef ARGUMENT_IS_ENUM_0
		    case ARGUMENT_IS_ENUM_0:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, order_enum_0)) < 0) {
				added->executing.types[i] = 0;
				if (optional & !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid element\n", raw_order);
				return 1;
			}
			break;
#endif
#ifdef ARGUMENT_IS_ENUM_1
		    case ARGUMENT_IS_ENUM_1:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, order_enum_1)) < 0) {
				added->executing.types[i] = 0;
				if (optional & !token_keyword[0])
					return 0;
				fprintf(current_report, "%s\n>>> invalid type\n", raw_order);
				return 1;
			}
			break;
#endif
		    default:
			fprintf(current_report, "%s\n>>> messed up order; please notify the gm!\n", raw_order);
			added->executing.types[i] = 0;
			return 1;
		}
	}
/*
 * Append at end of list
 */
	return 0;
}


/**
 ** SYNTAX_CHECK_LINE
 **	Parse one line of orders.  Such lines have a wildly
 ** differing format.
 **/
static void syntax_check_line(void)
{
command_s	*command;
order_s		fake;
int		i;
/*
 * Special case: the CLEAR order
 */
	if (keyword("CLEAR")) {
		if (!cleared)
			fprintf(current_report, "CLEAR\n");
		return;
	}
	memset(&fake, 0, sizeof(fake));
/*
 * Conditional count
 */
	while (isspace(*string_ptr))
		string_ptr++;
	i = 0;
	while (*string_ptr == '-') {
		i++;
		string_ptr++;
	}
	conditional = i;
	fake.conditional = i;
	while (isspace(*string_ptr))
		string_ptr++;
	if (*string_ptr == '+') {
		string_ptr++;
		fake.positive = 1;
	}
/*
 * Duration
 */
	while (isspace(*string_ptr))
		string_ptr++;
	days = 0;
	if (isdigit(*string_ptr)) {
		while (isdigit(*string_ptr))
			days = (days*10) + (*string_ptr++) - '0';
		if (days > 99)
			days = 99;
	} else
		if (*string_ptr == '@') {
			days = -1;
			string_ptr++;
		}
	fake.days = days;
	if (days == 0)
		days = 1;
/*
 * Order itself
 */
	while (isspace(*string_ptr))
		string_ptr++;
	if ((*string_ptr == 'D' || *string_ptr == 'd') && isdigit(string_ptr[1])) {
		string_ptr++;
		while (isdigit(*string_ptr)) {
			fake.limit_low *= 10;
			fake.limit_low += *string_ptr++ - '0';
		}
		if (*string_ptr == '-') {
			string_ptr++;
			while (isdigit(*string_ptr)) {
				fake.limit_high *= 10;
				fake.limit_high += *string_ptr++ - '0';
			}
		}
		if (fake.limit_high < fake.limit_low)
			fake.limit_high = fake.limit_low;
		while (isspace(*string_ptr))
			string_ptr++;
	}
	for (command = valid_orders; command->keyword; command++)
		if (keyword(command->keyword))
			break;
	if (!command->keyword) {
		fprintf(current_report, "%s\n>>> Unknown order\n", raw_order);
		return;
	}
	fake.executing = *command;
/*
 * Use the executor parser!
 */
	if ((*command->routine)(current_unit, &fake)) {
		fprintf(current_report, ">>> Syntax: %s", command->keyword);
		for (i = 0; i < MAX_ORDER_ARGUMENTS; i++) {
			if (!command->types[i])
				break;
			fprintf(current_report, " %s", visual_enum(command->types[i] & ARGUMENT_MASK, "\n\
unit-id\n\
location-id\n\
item-tag\n\
skill-tag\n\
race-tag\n\
terrain-tag\n\
faction-id\n\
faction/unit-id\n\
title-tag\n\
stance\n\
boolean\n\
string\n\
number\n\
battle\n\
rank\n\
file\n\
move\n\
combat-option\n\
setting\n\
direction-or-location-id\n\
target\n\
unit/building-id/building-name/faction\n\
element\n\
type\n"));
			if (command->types[i] == (command->types[i+1] & ARGUMENT_MASK)) {
				fprintf(current_report, "...");
				break;
			}
		}
		putc('\n', current_report);
	} else {
#ifdef USES_ACTION_POINTS
		current_unit->spent += days;
#endif
		write_order_on_file(current_report, &fake);
	}
}


/**
 ** MAIN
 **	Entry point for the syntax checker
 **/
int main(int argc, char **argv)
{
FILE		*orders;
char		*email;
#ifdef KEEP_CHECKER_OUTPUT
char		*fname;
char		sendchk[8192];
#endif
/*
 * We require two arguments: The faction id, and the checker recipient
 */
	if (argc < 2) {
		fprintf(stderr, "Invalid arguments to syntax checker\n");
		exit(1);
	}
/*
 * Load all info
 */
	load_game_info();
	load_items();
	load_skills();
	load_races();
	load_factions();
	load_units();
#ifdef USES_TITLE_SYSTEM
	load_titles();
#endif
	load_locations();
/*
 * Which faction are we checking?
 */
	string_ptr = argv[1];
	if (!separate_tag() || (current_faction = faction_from_id(0)) == 0) {
		fprintf(stderr, "Invalid faction ID %s\n", argv[1]);
		exit(1);
	}
/*
 * Start the reply. Use the sendcheck script
 */
	if (argc > 2)
		email = argv[2];
	else
		email = current_faction->e_mail;
#ifdef KEEP_CHECKER_OUTPUT
	fname = player_specific_file(current_faction, "checked");
	sprintf(sendchk, "./sendcheck \"%s\" < %s", email, fname);
	if ((current_report = fopen(fname, "w")) == 0) {
		perror(fname);
#else
	sprintf(work, "./sendcheck \"%s\"", email);
	if ((current_report = popen(work, "w")) == 0) {
		perror("popen()");
#endif
		exit(1);
	}
	fprintf(current_report, "From: %s\n", server_email);
	fprintf(current_report, "Subject: Syntax check for your turn %d orders\n", game_turn_number);
	fprintf(current_report, "To: %s\n", argv[2]);
	fprintf(current_report, "\n");
/*
 * Do we have an order file?
 */
	if ((orders = fopen(player_specific_file(current_faction, "order"), "r")) == 0)  {
		fprintf(current_report, "No order file submitted\n");
#ifdef KEEP_CHECKER_OUTPUT
		fclose(current_report);
		system(sendchk);
#else
		pclose(current_report);
#endif
		return 0;
	}
	fprintf(current_report, "Here is how the game server sees your order file, barring execution bugs\n");
	fprintf(current_report, "\n");
	fprintf(current_report, "#GAME %s %s\n", current_faction->id.text, current_faction->password);
/*
 * Now, parse
 */
	current_unit = 0;
	while (file_gets(orders)) {
		strcpy(raw_order, work);
		while (isspace(*string_ptr))
			string_ptr++;
		if (!*string_ptr || *string_ptr == ';')
			continue;
/*
 * Faction-wide orders are parsed here
 */
		if (!current_unit) {
			if (keyword("EMAIL")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->name, token_keyword))
					fprintf(current_report, "EMAIL %s\n", token_keyword);
				else
					fprintf(current_report, "%s\n>>> missing email\n", raw_order);
				continue;
			}
			if (keyword("NAME")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->name, token_keyword))
					fprintf(current_report, "NAME %s\n", token_keyword);
				else
					fprintf(current_report, "%s\n>>> missing name\n", raw_order);
				continue;
			}
			if (keyword("PASSWORD")) {
				separate_token();
				if (token_keyword[0] && strcmp(current_faction->password, token_keyword))
					fprintf(current_report, "PASSWORD %s\n", token_keyword);
				else
					fprintf(current_report, "%s\n>>> missing password\n", raw_order);
				continue;
			}
			if (keyword("RESHOW")) {
/*** HACK ***/
				fprintf(current_report, "%s\n", raw_order);
				continue;
			}
#ifdef OATH_TOWARD_FACTIONS
			if (keyword("OATH")) {
				if (!separate_tag() || !faction_from_id(0))
					fprintf(current_report, "%s\n>>> missing faction\n", raw_order);
				else
					fprintf(current_report, "OATH %s\n", id_token.text);
				continue;
			}
#endif
			if (keyword("RESIGN")) {
			    if(!separate_token() ||
			       strcasecmp(token_keyword,"CONFIRM")) {
				fprintf(current_report, "%s\n>>> missing 'confirm'\n", raw_order);
			    } else {
			    	fprintf(current_report,"RESIGN CONFIRM\n");
			    }
			    continue;
			}
			if(keyword("ORDER") || keyword("ORDERING")) {
			    fprintf(current_report,"%s\n", raw_order);
			    continue;
			}
		}
/*
 * Unit select!
 */
		if (keyword("UNIT")) {
#ifdef USES_ACTION_POINTS
			if (current_unit && current_unit->spent > current_unit->actions)
				fprintf(current_report, "; beware: you've spent an extra %d actions\n", current_unit->spent - current_unit->actions);
#endif
			cleared = 0;
			current_unit = 0;
			if (!separate_tag()) {
				fprintf(current_report, "%s\n>>> Not a unit ID!\n", raw_order);
				continue;
			}
			current_unit = potential_unit_id(current_faction);
			if (!current_unit) {
				fprintf(current_report, "%s\n>>> Unit does not and cannot exist\n", raw_order);
				continue;
			}
			if (current_unit->faction != current_faction) {
				fprintf(current_report, "%s\n>>> Unit does not belong to your faction\n", raw_order);
				current_unit = 0;
			} else {
				cleared = 1;
				conditional = 0;
			}
#ifdef USES_ACTION_POINTS
			if (current_unit->race)
				current_unit->actions = current_unit->race->actions;
			else
				current_unit->actions = USES_ACTION_POINTS;
			current_unit->spent = 0;
#endif
			fprintf(current_report, "\nUNIT %s\n", current_unit->id.text);
			continue;
		}
		if (!current_unit) {
			fprintf(current_report, "%s>>> No unit selected, skipped\n", raw_order);
			continue;
		}
/*
 * Parse now
 */
		syntax_check_line();
	}
#ifdef USES_ACTION_POINTS
	if (current_unit && current_unit->spent > current_unit->actions)
		fprintf(current_report, "; beware: you've spent an extra %d actions\n", current_unit->spent - current_unit->actions);
#endif
	fclose(orders);
/*
 * Done
 */
	fprintf(current_report, "#END\n");
#ifdef KEEP_CHECKER_OUTPUT
	fclose(current_report);
	system(sendchk);
#else
	pclose(current_report);
#endif
	return 0;
}
