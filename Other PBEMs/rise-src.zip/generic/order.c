/* $Id: order.c,v 1.11 2000/12/12 20:35:43 jtraub Exp $
 *	Manipulate the orders in file
 */
#include "overlord.h"
#include "file.h"
#include "info.h"
#include "parser.h"
#include "command_e.h"


#ifndef ORDER_CHUNK
#define ORDER_CHUNK	1000
#endif


/**
 ** Local cache
 **/
static order_s	*free_order_chain;
#include "command_e.c"


/**
 ** VISUAL_ENUM
 **	From enum to visual text representation
 **/
char *visual_enum(int number, char *text)
{
static char	visual[80];
static char visual2[80];
static int which = 0;
char		*dst;
/*
 * Go for the right number
 */
	while (number-- > 0) {
		while (*text)
			if (*text++ == '\n')
				break;
	}
/*
 * Copy
 */
	if(which) {
	    dst = visual2;
		which = 0;
	} else {
	    dst = visual;
		which = 1;
	}
	while (*text)
		if (*text == '\n')
			break;
		else
			*dst++ = *text++;
	*dst = 0;
	if(which) {
	    return visual;
	} else {
		return visual2;
	}
}


/**
 ** FREE_ORDER_INSTANCE
 **	Free the order, and all the following
 **/
void free_order_instance(order_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	free_order_instance(old->next);
	if (old == free_order_chain)
		abort();
	old->next = free_order_chain;
	free_order_chain = old;
/*
 * We don't need to maintain the "prev" linkage
 */
}


/**
 ** NEW_ORDER_INSTANCE
 **	Allocate one order instance
 **/
order_s *new_order_instance(void)
{
order_s	*order;
int	i, j;
/*
 * Any cached order_s?
 */
	while (1) {
		if ((order = free_order_chain) != 0) {
			free_order_chain = order->next;
			break;
		}
/*
 * Allocate by larger chuncks (to spare memory)
 */
		order = (order_s *)zero_malloc(sizeof(order_s)*ORDER_CHUNK);
		j = 0;
		for (i = 0; i < (ORDER_CHUNK-1); i++)
			order[i].next = order+(++j);
		free_order_chain = order;
	}
/*
 * Allocated
 */
	memset(order, 0, sizeof(*order));
	return order;
}


/**
 ** PARSE_ORDER_LINE
 **	Parse one line of orders.  Such lines have a wildly
 ** differing format.
 **/
order_s *parse_order_line(order_s *old)
{
order_s		*previous, *list;
order_s		*added;
command_s	*command;
char		*save_ptr;
int		days;
int		i;
/*
 * Special case: the CLEAR order
 */
	if (keyword("CLEAR")) {
		free_order_instance(old);
		return 0;
	}
/*
 * Allocate one order instance
 */
	added = new_order_instance();
/*
 * Conditional count
 */
	while (isspace(*string_ptr))
		string_ptr++;
	if (*string_ptr == '-') {
		while (*string_ptr == '-') {
			added->conditional++;
			string_ptr++;
		}
		while (isspace(*string_ptr))
			string_ptr++;
	}
	if (*string_ptr == '+') {
		added->positive++;
		string_ptr++;
		while (isspace(*string_ptr))
			string_ptr++;
	}
/*
 * Duration
 */
	if (isdigit(*string_ptr)) {
		days = 0;
		while (isdigit(*string_ptr))
			days = (days*10) + (*string_ptr++) - '0';
		if (days > 99)
			days = 99;
		added->days = days;
		while (isspace(*string_ptr))
			string_ptr++;
	} else {
		if (*string_ptr == '@') {
			added->days = -1;
			string_ptr++;
		}
		while (isspace(*string_ptr))
			string_ptr++;
	}
/*
 * Day restrictor
 */
	if (isdigit(string_ptr[1]) && (*string_ptr == 'd' || *string_ptr == 'D')) {
		string_ptr++;
		days = 0;
		while (isdigit(*string_ptr))
			days = (days*10) + (*string_ptr++) - '0';
		if (days > 30)
			days = 30;
		added->limit_low  = days;
		added->limit_high = days;
/*
 * Day range?
 */
		if (*string_ptr == '-') {
			string_ptr++;
			days = 0;
			while (isdigit(*string_ptr))
				days = (days*10) + (*string_ptr++) - '0';
			if (days < added->limit_low)
				days = added->limit_low;
			if (days > 30)
				days = 30;
			added->limit_high = days;
		}
/*
 * Skip the rest
 */
		while (isspace(*string_ptr))
			string_ptr++;
	}
/*
 * Order itself
 */
	for (command = valid_orders; command->keyword; command++)
		if (keyword(command->keyword))
			break;
	if (!command->keyword) {
		free_order_instance(added);
		return old;
	}
	added->executing = *command;
/*
 * Parse order arguments
 */
	for (i = 0; i < MAX_ORDER_ARGUMENTS; i++) {
		added->executing.types[i] &= ARGUMENT_MASK;
		switch (added->executing.types[i]) {
		    case ARGUMENT_IS_UNIT_OR_FACTION_ID:
			if(!separate_tag()) {
				added->executing.types[i] = 0;
			} else {
				if((added->arguments[i].unit = potential_unit_id(0)) == 0) {
					if((added->arguments[i].faction = faction_from_id(0)) == 0)
						added->executing.types[i] = 0;
					else
						added->executing.types[i] = ARGUMENT_IS_FACTION_ID;
				} else {
					added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
				}
			}
			break;
		    case ARGUMENT_IS_UNIT_ID:
			if (!separate_tag() || (added->arguments[i].unit = potential_unit_id(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_LOCATION_ID:
			if (!separate_tag() || (added->arguments[i].location = location_from_id(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_FACTION_ID:
			if (!separate_tag() || (added->arguments[i].faction = faction_from_id(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_ITEM_TAG:
			if (!separate_tag() || (added->arguments[i].item = item_from_tag(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_SKILL_TAG:
			if (!separate_tag() || (added->arguments[i].skill = skill_from_tag(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_RACE_TAG:
			if (!separate_tag() || (added->arguments[i].race = race_from_tag(0)) == 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_TERRAIN_TAG:
			if (!separate_tag() || (added->arguments[i].terrain = terrain_from_tag(0)) == 0)
				added->executing.types[i] = 0;
			break;
#ifdef USES_TITLE_SYSTEM
		    case ARGUMENT_IS_TITLE_TAG:
			if (!separate_tag() || (added->arguments[i].title = title_from_tag(0)) == 0)
				added->executing.types[i] = 0;
			break;
#endif
		    case ARGUMENT_IS_STANCE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, stance_arguments)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_BOOLEAN:
			separate_token();
			if (strcasecmp(token_keyword, "ON") == 0)
				added->arguments[i].number = 1;
			else
				if (strcasecmp(token_keyword, "OFF") == 0)
					added->arguments[i].number = 0;
				else
					added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_STRING:
			separate_token();
			if (token_keyword[0])
				added->arguments[i].string = strdup(token_keyword);
			else
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_NUMBER:
			separate_token();
			if (isdigit(token_keyword[0]) || token_keyword[0] == '-')
				added->arguments[i].number = atoi(token_keyword);
			else
				if (token_keyword[0] == '+')
					added->arguments[i].number = atoi(token_keyword+1);
				else
					added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_BATTLE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, battle_arguments)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_RANK:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, rank_arguments)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_FILE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, file_arguments)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_MOVE:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, move_arguments)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_SETTING:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, possible_settings)) < 0)
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_DIRECTION:
			save_ptr = string_ptr;
			if (separate_tag()) {
				if ((added->arguments[i].location = location_from_id(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
					break;
				}
				if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
					break;
				}
			}
			string_ptr = save_ptr;
			separate_token();
			if (token_keyword[0]) {
				added->arguments[i].string = strdup(token_keyword);
				added->executing.types[i] = ARGUMENT_IS_STRING;
			} else
				added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_COMBAT_OPTION:
			if (keyword("ONCE")) {
			    added->combat_once[i] = 1;
			    i--;
			    break;
			}
			if(*string_ptr == '-') {
			    string_ptr++;
			    added->combat_once[i] = 1;
			}
			if (keyword("MELEE")) {
				added->arguments[i].number = 2;
				break;
			}
			if (keyword("RANGED")) {
				added->arguments[i].number = 3;
				break;
			}
			if (keyword("GUARD")) {
				added->arguments[i].number = 4;
				break;
			}
			if (separate_tag()) {
				if ((added->arguments[i].skill = skill_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_SKILL_TAG;
					break;
				}
				if ((added->arguments[i].item = item_from_tag(0)) != 0) {
					added->executing.types[i] = ARGUMENT_IS_ITEM_TAG;
					break;
				}
			}
			added->executing.types[i] = 0;
			break;
		    case ARGUMENT_IS_COMBAT_TARGET:
			if(!separate_tag()) {
				added->executing.types[i] = 0;
				break;
			}
			if((added->arguments[i].unit = potential_unit_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
				break;
			}
			if ((added->arguments[i].location = location_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
				break;
			}
			if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
				break;
			}
			if ((added->arguments[i].faction = faction_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_FACTION_ID;
				break;
			}
		    case ARGUMENT_IS_TARGET:
			if (!separate_tag()) {
			    /* Try treating it as a string */
			    separate_token();
			    if((added->arguments[i].terrain = terrain_from_token()) != 0) {
				added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
				break;
			    } else {
				added->executing.types[i] = 0;
				break;
			    }
			}
			if ((added->arguments[i].unit = potential_unit_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_UNIT_ID;
				break;
			}
			if ((added->arguments[i].location = location_from_id(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_LOCATION_ID;
				break;
			}
			if ((added->arguments[i].terrain = terrain_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_TERRAIN_TAG;
				break;
			}
			if ((added->arguments[i].skill = skill_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_SKILL_TAG;
				break;
			}
			if ((added->arguments[i].item = item_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_ITEM_TAG;
				break;
			}
			if ((added->arguments[i].race = race_from_tag(0)) != 0) {
				added->executing.types[i] = ARGUMENT_IS_RACE_TAG;
				break;
			}
			added->executing.types[i] = 0;
			break;
#ifdef ARGUMENT_IS_ENUM_0
		    case ARGUMENT_IS_ENUM_0:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, order_enum_0)) < 0)
				added->executing.types[i] = 0;
			break;
#endif
#ifdef ARGUMENT_IS_ENUM_1
		    case ARGUMENT_IS_ENUM_1:
			separate_token();
			if ((added->arguments[i].number = parsed_enum(token_keyword, order_enum_1)) < 0)
				added->executing.types[i] = 0;
			break;
#endif
		    default:
			added->executing.types[i] = 0;
		}
	}
/*
 * Append at end of list
 */
	if ((list = old) == 0)
		return added;
	for (previous = 0; list; list = list->next)
		previous = list;
	previous->next = added;
	added->prev = previous;
	return old;
}


#ifdef TURN_PROCESSOR
/**
 ** LOAD_ORDERS
 **	Load order files for all factions
 **/
void load_orders(void)
{
faction_s	*factions, *resigned;
FILE		*orders;
unit_s		*current_unit;
unit_s		*previous, *scanner, *unit;
item_s		*item;
skill_s		*skill;
#ifdef REPORTS_ITEM_KNOWLEDGE
itemknow_s	*knew_item;
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
skillknow_s	*knew_skill;
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
raceknow_s	*knew_race;
race_s		*race;
#endif
/*
 * Go go!
 */
	for (factions = faction_list; factions; factions = factions->next) {
		if ((orders = fopen(player_specific_file(factions, "order"), "r")) == 0)
			continue;
		factions->orders_subbed = 1;
		factions->dissolve = 0;
		current_unit = 0;
		while (file_gets(orders)) {
			while (isspace(*string_ptr))
				string_ptr++;
			if (!*string_ptr || *string_ptr == ';')
				continue;
/*
 * Faction-wide orders are parsed here
 */
			if (!current_unit) {
				if (keyword("EMAIL")) {
					separate_token();
					if (token_keyword[0] && strcmp(factions->name, token_keyword))
						make_a_copy_(factions->e_mail, token_keyword);
					continue;
				}
				if (keyword("NAME")) {
					separate_token();
					if (token_keyword[0] && strcmp(factions->name, token_keyword))
						make_a_copy_(factions->name, token_keyword);
					continue;
				}
				if (keyword("PASSWORD")) {
					separate_token();
					if (token_keyword[0] && strcmp(factions->name, token_keyword))
						make_a_copy_(factions->password, token_keyword);
					continue;
				}
#ifdef OATH_TOWARD_FACTIONS
				if (keyword("OATH")) {
					separate_tag();
					if ((resigned = faction_from_id(0)) != 0)
						execute_oathing_process(0, 0, factions, resigned);
					continue;
				}
#endif
				if (keyword("RESHOW")) {
#ifdef REPORTS_ITEM_KNOWLEDGE
					if (keyword("ITEMS")) {
						for (knew_item = factions->known_items; knew_item; knew_item = knew_item->next)
							knew_item->report = 0;
						continue;
					}
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
					if (keyword("SKILLS")) {
						for (knew_skill = factions->known_skills; knew_skill; knew_skill = knew_skill->next)
#ifdef USES_SKILL_LEVELS
							knew_skill->from_level = 0;
#else
							knew_skill->report = 0;
#endif
						continue;
					}
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
					if (keyword("RACES")) {
						for (knew_race = factions->known_races; knew_race; knew_race = knew_race->next)
							knew_race->report = 0;
						continue;
					}
#endif
					if (keyword("ALL")) {
#ifdef REPORTS_ITEM_KNOWLEDGE
						for (knew_item = factions->known_items; knew_item; knew_item = knew_item->next)
							knew_item->report = 0;
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
						for (knew_skill = factions->known_skills; knew_skill; knew_skill = knew_skill->next)
#ifdef USES_SKILL_LEVELS
							knew_skill->from_level = 0;
#else
							knew_skill->report = 0;
#endif
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
						for (knew_race = factions->known_races; knew_race; knew_race = knew_race->next)
							knew_race->report = 0;
#endif
						continue;
					}
/*
 * Not a keyword, maybe a token?
 */
					separate_tag();
#ifdef REPORTS_ITEM_KNOWLEDGE
					if ((item = item_from_tag(0)) != 0) {
						for (knew_item = factions->known_items; knew_item; knew_item = knew_item->next)
							if (knew_item->about == item)
								knew_item->report = 0;
					}
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
					if ((skill = skill_from_tag(0)) != 0) {
						for (knew_skill = factions->known_skills; knew_skill; knew_skill = knew_skill->next)
							if (knew_skill->about == skill)
#ifdef USES_SKILL_LEVELS
								knew_skill->from_level = 0;
#else
								knew_skill->report = 0;
#endif
					}
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
					if ((race = race_from_tag(0)) != 0) {
						for (knew_race = factions->known_races; knew_race; knew_race = knew_race->next)
							if (knew_race->about == race)
								knew_race->report = 0;
					}
#endif
				}
				if (keyword("RESIGN")) {
				    if (separate_token()) {
				    	if(strcasecmp(token_keyword,
						      "CONFIRM") == 0) {
					    for (current_unit = unit_list; current_unit; current_unit = current_unit->next) {
						if (current_unit->faction == factions &&
						    !current_unit->now_loyal) {
						    current_unit->size = 0;
						}
					    }
					}
					printf("%s [%s] resigned", factions->name, factions->id.text);
					putchar('\n');
					factions->resigned = 1;
					if(factions->vassal_of) {
					    sprintf(work, "%s [%s] renounced oath to us due to resigning.", factions->name, factions->id.text);
					    faction_wide_event(factions->vassal_of, 1, work);
					}
				    }
				    continue;
				}
/*
 * Re-order units
 */
				if (keyword("ORDER") || keyword("ORDERING")) {
					if (!separate_tag())
						continue;
					if ((current_unit = unit_from_id(0)) == 0)
						continue;
					if (current_unit->faction == factions)
						while (separate_tag())
							if ((unit = unit_from_id(0)) != 0 &&
							    unit != current_unit &&
							    unit->faction == factions) {
								previous = 0;
								for (scanner = factions->units; scanner; scanner = scanner->same_faction)
									if (scanner == unit)
										break;
									else
										previous = scanner;
								if (scanner) {
									if (previous != current_unit) {
										if (previous)
											previous->same_faction = unit->same_faction;
										else
											factions->units = unit->same_faction;
										unit->same_faction = current_unit->same_faction;
										current_unit->same_faction = unit;
									}
									current_unit = unit;
								}
							}
					current_unit = 0;
					continue;
				}
			}
/*
 * Unit select!
 */
			if (keyword("UNIT")) {
				current_unit = 0;
				if (!separate_tag())
					continue;
				current_unit = potential_unit_id(factions);
				if (!current_unit)
					continue;
				if (current_unit->faction != factions)
					current_unit = 0;
				else {
					free_order_instance(current_unit->orders);
					current_unit->orders = 0;
				}
				continue;
			}
			if (!current_unit)
				continue;
/*
 * Parse now
 */
			current_unit->orders = parse_order_line(current_unit->orders);
		}
		fclose(orders);
	}
}
#endif /*TURN_PROCESSOR*/


/**
 ** WRITE_ORDER_ON_FILE
 **	Used for the current order stack, or the report
 **/
void write_order_on_file(FILE *save, order_s *order)
{
int	i;
/*
 * Conditionals first
 */
	for (i = order->conditional; i > 0; i--)
		putc('-', save);
	if (order->positive)
		putc('+', save);
	if (order->days < 0)
		putc('@', save);
	else
		if (order->days > 0)
			fprintf(save, "%d ", order->days);
	if (order->limit_low) {
		fprintf(save, "d%d", order->limit_low);
		if (order->limit_high > order->limit_low)
			fprintf(save, "-%d", order->limit_high);
		putc(' ', save);
	}
/*
 * Keyword
 */
	fprintf(save, "%s", order->executing.keyword);
	for (i = 0; i < MAX_ORDER_ARGUMENTS; i++)
		if (!order->executing.types[i])
			break;
		else
			switch (order->executing.types[i] & ARGUMENT_MASK) {
			    case ARGUMENT_IS_UNIT_ID:
				fprintf(save, " %s", order->arguments[i].unit->id.text);
				break;
			    case ARGUMENT_IS_LOCATION_ID:
				fprintf(save, " %s", order->arguments[i].location->id.text);
				break;
			    case ARGUMENT_IS_FACTION_ID:
				fprintf(save, " %s", order->arguments[i].faction->id.text);
				break;
			    case ARGUMENT_IS_ITEM_TAG:
				fprintf(save, " %s%s",
					(order->combat_once[i] ? "-" : ""),
					order->arguments[i].item->tag.text);
				break;
			    case ARGUMENT_IS_SKILL_TAG:
				fprintf(save, " %s%s",
					(order->combat_once[i] ? "-" : ""),
					order->arguments[i].skill->tag.text);
				break;
			    case ARGUMENT_IS_RACE_TAG:
				fprintf(save, " %s", order->arguments[i].race->tag.text);
				break;
			    case ARGUMENT_IS_TERRAIN_TAG:
				fprintf(save, " %s", order->arguments[i].terrain->tag.text);
				break;
#ifdef USES_TITLE_SYSTEM
			    case ARGUMENT_IS_TITLE_TAG:
				fprintf(save, " %s", order->arguments[i].title->tag.text);
				break;
#endif
			    case ARGUMENT_IS_STANCE:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, stance_arguments));
				break;
			    case ARGUMENT_IS_BOOLEAN:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, boolean_arguments));
				break;
			    case ARGUMENT_IS_STRING:
				fprintf(save, " \"%s\"", order->arguments[i].string);
				break;
			    case ARGUMENT_IS_NUMBER:
				fprintf(save, " %d", order->arguments[i].number);
				break;
			    case ARGUMENT_IS_BATTLE:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, battle_arguments));
				break;
			    case ARGUMENT_IS_RANK:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, rank_arguments));
				break;
			    case ARGUMENT_IS_FILE:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, file_arguments));
				break;
			    case ARGUMENT_IS_MOVE:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, move_arguments));
				break;
			    case ARGUMENT_IS_SETTING:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, possible_settings));
				break;
			    case ARGUMENT_IS_COMBAT_OPTION:
				fprintf(save, " %s%s",
					(order->combat_once[i] ? "-" : ""),
					visual_enum(order->arguments[i].number, combat_arguments));
				break;
#ifdef ARGUMENT_IS_ENUM_0
			    case ARGUMENT_IS_ENUM_0:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, order_enum_0));
				break;
#endif
#ifdef ARGUMENT_IS_ENUM_1
			    case ARGUMENT_IS_ENUM_1:
				fprintf(save, " %s", visual_enum(order->arguments[i].number, order_enum_1));
				break;
#endif
			}
	putc('\n', save);
}
