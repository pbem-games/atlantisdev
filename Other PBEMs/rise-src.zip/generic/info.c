/* $Id: info.c,v 1.5 2000/07/16 19:48:38 jtraub Exp $
 *	Manipulate the general info file
 */
#include "overlord.h"
#include "file.h"
#include "info.h"
#include "parser.h"


/**
 ** Global variables
 **/
int	game_turn_number;
int	seed = 0;
char	*server_email;
char	*game_server_email;
char	*game_name;
char	deadline[80];
char	olddeadline[80];


/**
 ** The base files
 **/
#ifndef INFO_FILE_NAME
#define INFO_FILE_NAME	"game"
#endif
#ifndef PRESS_FILE_NAME
#define PRESS_FILE_NAME	"press"
#endif
#ifndef RUMOR_FILE_NAME
#define RUMOR_FILE_NAME	"rumors"
#endif
#ifndef COMMIT_PROCESSOR
#ifndef MAIL_PROCESSOR
static
#endif
#endif
	char	info_file_name[] = INFO_FILE_NAME;
#if defined(COMMIT_PROCESSOR) || defined (MAIL_PROCESSOR) || defined(TURN_PROCESSOR)
char		press_file_name[] = PRESS_FILE_NAME,
		rumor_file_name[] = RUMOR_FILE_NAME;
#endif

#ifdef TURN_PROCESSOR
/**
 ** SAVE_GAME_INFO
 **	Write back the info file, before commit.
 **/
void save_game_info(void)
{
FILE	*save;
/*
 * Save possible? This commits the game turn
 */
	if ((save = fopen(new_file(info_file_name), "w")) == 0)
		fatal_error(info_file_name);
	fprintf(save, "TURN %d\n", game_turn_number+1);
	if (server_email)
		fprintf(save, "EMAIL %s\n", server_email);
	if (game_name)
		fprintf(save, "NAME %s\n", game_name);
	fprintf(save, "CURDEADLINE %s\n", deadline);
	fclose(save);
}
#endif


/**
 ** LOAD_GAME_INFO
 **	Load the generic info file.
 **/
void load_game_info(void)
{
FILE	*info;
/*
 * Start loading
 */
	if ((info = fopen(info_file_name, "r")) == 0)
		fatal_error(info_file_name);
/*
 */
	while (file_gets(info)) {
		if (keyword("TURN")) {
			game_turn_number = atoi(string_ptr);
			continue;
		}
		if (keyword("SEED")) {
		    seed = atoi(string_ptr);
		    continue;
		}
		if (keyword("EMAIL")) {
			separate_token();
			make_a_copy_(server_email, token_keyword);
			game_server_email = strchr(server_email, '@');
			continue;
		}
		if (keyword("NAME")) {
			separate_token();
			make_a_copy_(game_name, token_keyword);
			continue;
		}
		if(keyword("CURDEADLINE")) {
		    strcpy(olddeadline, string_ptr);
		    continue;
		}
		if (keyword("DEADLINE")) {
			strcpy(deadline, string_ptr);
			continue;
		}
	}
/*
 * Load done
 */
	fclose(info);
}
