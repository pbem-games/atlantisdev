/* $Id: typedef.h,v 1.2 2000/09/22 06:57:54 jtraub Exp $
 *	Predefines all objects in the game.
 */
#ifndef overlord_typedef_h
#define overlord_typedef_h
#include <sys/types.h>


/**
 ** Global types, used everywhere
 **/
union union_tag {
	char		text[9];		/* allows large tags */
#ifdef __GNUC__
#define USE_LONG_LONG
	long long	all;			/* must be 64 bits */
#endif
};
typedef union union_tag		t_tag;		/* a tag or id */


/**
 ** Stats pack
 **/
#include "stats.h"
/**
 ** Events chain
 **/
#include "events.h"
/**
 ** Combat pack
 **/
#include "combat.h"
/**
 ** Racial types
 **/
#include "race.h"
/**
 ** Item and skills
 **/
#include "skills.h"
#include "item.h"
/**
 ** Faction
 **/
#include "faction.h"
/**
 ** Control factors
 **/
#include "control.h"
/**
 ** Titles
 **/
#include "title.h"
/**
 ** Arguments
 **/
#include "argument.h"
/**
 ** Units
 **/
#include "unit.h"
/**
 ** Locations
 **/
#include "location.h"
/**
 ** Order
 **/
#include "order.h"
/**
 ** Market requests
 **/
#include "market.h"


#endif/*overlord_typedef_h*/
