/* $Id: warning.c,v 1.3 2000/03/01 17:47:11 jtraub Exp $
 *	Warning message. Notifies all factions that have not sumitted
 *	their orders for this turn.
 */
#include "enums.h"
#include "overlord.h"
#include "file.h"
#include "info.h"


/**
 ** MAIN
 **	Entry point for the warning checker
 **/
int main(int argc, char **argv)
{
FILE		*message;
faction_s	*player;
/*
 * We require 1 argument: the date
 */
	if (argc < 2) {
		fprintf(stderr, "Usage: warning \"date\"\n");
		exit(1);
	}
/*
 * Load all required info. Namely, info and factions.
 */
	load_game_info();
	load_factions();
/*
 * Now, check all factions
 */
	for (player = faction_list; player; player = player->next)
		if (!player->npc && !player->new_fac) {
			if ((message = fopen(player_specific_file(player, "order"), "r")) != 0) {
				fclose(message);
				continue;
			}
/*
 * No order found. Send a notice!
 */
			sprintf(work, "./sendwarn %s", player->e_mail);
			if ((message = popen(work, "w")) == 0) {
				perror("popen()");
				exit(1);
			}
			fprintf(message, "From: %s\n", server_email);
			fprintf(message, "Subject: You did not submit turn %d orders\n", game_turn_number);
			fprintf(message, "To: %s\n", player->e_mail);
			fprintf(message, "\n");
			fprintf(message, "This is a friendly reminder. The orders for turn %d will be accepted\n", game_turn_number);
			fprintf(message, "until the following date:\n");
			fprintf(message, "\n");
			fprintf(message, "\t%s\n", argv[1]);
			fprintf(message, "\n");
			fprintf(message, "Delay at your own risk!\n");
			pclose(message);
		}
	return 0;
}
