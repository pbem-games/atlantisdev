/* $Id: location.h,v 1.16 2000/10/15 18:59:35 jtraub Exp $
 *	Define the internals about locations & terrains
 */
#ifndef overlord_location_h
#define overlord_location_h
#include "typedef.h"
#include "fxdef.h"


/**
 ** Macro fixes
 **/
#ifdef DYNAMICALLY_DEFINED_GAME
#define REQUIRE_X_Y
#elif USE_OVERLAND_COORDINATES
#define REQUIRE_X_Y
#endif

#ifdef FX_SPEEDUP_STRUCTURE
#define REQUIRE_SPEEDUP
#elif FX_SPEEDUP_HARVEST
#define REQUIRE_SPEEDUP
#endif


/**
 ** Terrain/structure/directions & observation per faction object
 **/
struct struct_resource {
	struct struct_resource	*next;
	item_s			*type;
	int			amount;
	int			remains;
};
typedef struct struct_resource		resource_s;


struct struct_terrain {
	t_tag			tag;
	struct struct_terrain	*next;
	char			*name;		/* as it says */
	skill_s			*attached_skill;/* land walking */
	item_s			*local_token;	/* infinitely available */
	resource_s		*required;	/* ressources */
	stats_s			local_conditions;/* for battle */
	long			pixel;		/* color for map/HTML generation */
	int			optima;		/* for population */
#ifdef DYNAMICALLY_DEFINED_GAME
	char			days,		/* for walking */
				max_days;
	char			mode;		/* special mode */
#endif
#ifdef WORLD_HAS_CLIMATE
	char			covered;	/* weather-safe */
#endif
	char			solid;
	char			type;
#define TERRAIN_COUNTRY		0
#define TERRAIN_INNER		1
#define TERRAIN_STRUCTURE	2
	unsigned char		special_effect;	/* extra effects */
};
typedef struct struct_terrain	terrain_s;	/* type of location */

struct struct_observed {
	struct struct_observed	*next;
	faction_s		*witness;
	unit_s			*expert;
	short			day_start, day_end;
#ifdef STEALTH_STATS
	short			observation;
#endif
};
typedef struct struct_observed		seen_s;


struct struct_recruit {
	struct struct_recruit	*next;
	race_s			*type;
	struct struct_request	*wanted;
	int			amount;
	int			recruited;
	int			price;
};
typedef struct struct_recruit	recruit_s;	/* recruitment */


struct struct_location {
	t_tag			id;
	struct struct_location	*next,
				*next_hash;	/* global linkage */
	terrain_s		*type;		/* visual terrain */
	char			*name;		/* allocated name */
	char			*description;	/* user descriptions */
	char			region;		/* Region of the world */
	struct struct_location	*outer,		/* if any, for non-overland */
				*inner,
				*next_inner;
	struct struct_direction	*exits;		/* directions from here */
#ifdef LOCATION_FACTION_CONTROL
	loyalty_s		*mastery;	/* of the land */
	control_s		*control_by;	/* who owns what */
	faction_s		*overseeing;	/* the overall controller */
#endif
	seen_s			*witness;	/* during turn */
	event_s			*events;	/* during turn */
	unit_s			*present,
				*interacting;	/* present units */
#ifndef FIXED_WORLD
	recruit_s		*opportunity;	/* recruitment */
#endif
	race_s			*racial;	/* racial makeup */
#ifdef USES_CASH
	struct struct_market	*markets;	/* for sale or buy */
	struct struct_location	*first_market;	/* if any */
#endif
	resource_s		*resources;	/* overland & tokens */
	resource_s		*treasure;
	char			unlooted;
	experience_s		*skills;	/* available here */
	skill_s			*walk;		/* walking skill */
#ifdef USES_TITLE_SYSTEM
	title_s			*title;
	unit_s			*holder;
#endif
#ifdef REQUIRE_X_Y
	int			x, y;		/* relative coordinates */
#ifdef OVERLAND_3D
	int			z;		/* 3d dimension */
#endif
#endif
	int			population,	/* local */
				optima,
				migrate,
				delta,
#ifdef DYNAMIC_ECONOMY
				economy,	/* variation in % */
#endif
				total_figures;	/* present */
	char			pillaged;
#ifdef USES_CASH
	int			market_days;
	int			wages,
				entertainment,
				taxes;		/* recomputed each turn */
#endif
	char			been;	/* for various FX calculations */
	char			partial;	/* partially built location */
#ifdef TURN_PROCESSOR
	char			harvesting;	/* someone has harvested today */
	char			dedicated;	/* dedicated this month */
	char			guarded;	/* someone is guarding */
	char			patrolled;	/* someone is on patrol */
	char			cursed;		/* cursed this month */
	char			blessed;	/* blessed this month */
	char			cultivated; /* cultivated this month */
#ifdef REQUIRE_SPEEDUP
	char			speedup;	/* speeded up harvest or building? */
#endif
#endif
#ifdef WORLD_HAS_CLIMATE
	char			last_climate,
				next_climate;
#endif
};
typedef struct struct_location	location_s;	/* where are all units */


struct struct_direction {
	struct struct_direction	*next;
	location_s		*toward;
	char			*name;
	skill_s			*skill;
#ifdef USES_SKILL_LEVELS
	short			level;
#endif
	char			days;
	char			mode;
};
typedef struct struct_direction		direction_s;


/*
 * Variables
 */
extern terrain_s	*terrains_list;
extern location_s	*location_list;
extern char		*compass_names[];


/*
 * Prototypes
 */
extern void		save_locations(void);
extern void		load_locations(void);
extern void		load_terrains(void);
extern location_s	*location_from_id(int);
extern terrain_s	*terrain_from_token(void);
extern terrain_s	*terrain_from_tag(int);
extern direction_s	*new_direction_from_location(void);
extern recruit_s	*parse_recruits(recruit_s *, race_s *, int , int);
extern resource_s	*parse_resource_item(resource_s *);
extern resource_s	*new_resource_instance(void);
extern experience_s	*location_experiences(location_s *, skill_s *, int);

extern void		move_to_location(unit_s *,location_s *);
extern void		who_is_present(location_s *);
extern void		observe_locations(int);
extern void		observer_present(unit_s *,location_s *,int);
extern void		location_visible_event(location_s *,int,char *);
extern void		location_global_event(unit_s *, int, char *);

extern void		relative_positions_from(location_s *);
extern direction_s	*compass_direction(location_s *,int);
extern location_s	*location_from_position(int,int,char);
extern int		wrap_x(char);
extern int		wrap_y(char);
extern void		compass_connect(location_s *,location_s *,int);
extern location_s	*random_location_id(void);
extern void		all_compass_connect(location_s *);
extern terrain_s	*create_random_country(int,int);
extern void		location_general_event(location_s *,event_s *);
extern resource_s	*location_has_resource(location_s *,item_s *,int);
extern void		return_unique_item(item_s *);
#ifdef TURN_PROCESSOR
extern int		taxable_loc(location_s *);
#endif

#endif/*overlord_location_h*/
