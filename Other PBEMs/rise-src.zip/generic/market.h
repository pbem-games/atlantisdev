/* $Id: market.h,v 1.2 2000/03/10 06:35:57 jtraub Exp $
 *	Markets are processed in two stages: Firstly, the request is made.
 *	Then, the market occurs. Then, the orders finish.
 */
#ifndef _overlord_market_h
#define _overlord_market_h
/**
 ** Special market request
 **/
struct struct_request {
	struct struct_request	*next;
	unit_s			*asked;		/* 0 for local market */
	struct struct_order	*validated_order;
	int			amount,
				price;
	int			remaining_amount;
};
typedef struct struct_request	request_s;


struct struct_offer {
	request_s		*shopping;	/* in price order! */
	int			initial_amount;
	int			amount_remains;
	int			finally_sold;
	int			negociated_price;
};
typedef struct struct_offer	offer_s;


struct struct_market {
	struct struct_market	*next;
	item_s			*type;
	offer_s			wanted,
				offered;
	int			turns;
};
typedef struct struct_market	market_s;

struct struct_pot_market {
	item_s	*item;
	int 	chance;
};
typedef struct struct_pot_market	pot_market_s;

/**
 ** Prototypes
 **/
extern request_s	*new_request_instance(void);
extern void		free_request_instance(request_s *);
extern market_s		*new_market_at_location(location_s *,item_s *);
extern void		clean_markets(location_s *);
extern void		process_recruitment(location_s *);
extern void		market_check(location_s *);
extern void		process_markets(location_s *);


#endif /*_overlord_market_h*/
