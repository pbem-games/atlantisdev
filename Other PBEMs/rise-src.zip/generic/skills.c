/* $Id: skills.c,v 1.6 2000/07/17 19:20:51 jtraub Exp $
 *	Manipulate the skills file
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"


/**
 ** Global variables
 **/
skill_s	*skills_list;


/**
 ** The skill file
 **/
#ifndef SKILL_FILE_NAME
#define SKILL_FILE_NAME	"skills"
#endif


#ifndef LEVELS_CHUNK
#define LEVELS_CHUNK	1000
#endif

#ifndef CONSUME_CHUNK
#define CONSUME_CHUNK	1000
#endif

/**
 ** Local cache
 **/
static experience_s	*free_experience_chain;
static consume_s	*free_consume_chain;


#ifdef REPORTS_SKILL_KNOWLEDGE
/**
 ** NEW_SKILL_KNOWLEDGE
 **	Allocate a new skill knowledge. For memory efficiency, allocate by
 ** big chunks. These are never unallocated!
 **/
skillknow_s *new_skill_knowledge(void)
{
static skillknow_s	*free_know_chain;
skillknow_s		*skill;
int			i, j;
/*
 *
 */
	if (!free_know_chain) {
		free_know_chain = (skillknow_s *)zero_malloc(sizeof(skillknow_s)*LEVELS_CHUNK);
		j = 0;
		for (i = 0; i < (LEVELS_CHUNK-1); i++)
			free_know_chain[i].next = free_know_chain+(++j);
	}
	skill = free_know_chain;
	free_know_chain = skill->next;
	skill->next = 0;
	return skill;
}


/**
 ** FACTION_KNOWS_SKILL
 **/
#ifdef USES_SKILL_LEVELS
void faction_knows_skill_level(faction_s *faction, skill_s *skill, int level)
#else
void faction_knows_skill(faction_s *faction, skill_s *skill)
#endif
{
skillknow_s	*already;
consume_s	*items;
/*
 * Already known?
 */
	if (!skill)
		return;
	for (already = faction->known_skills; already; already = already->next)
		if (already->about == skill)
			break;
	if (!already) {
		already = new_skill_knowledge();
		already->about = skill;
		already->next = faction->known_skills;
		faction->known_skills = already;
	}
#ifdef USES_SKILL_LEVELS
	if (level <= 0)
		level = 1;
	if (level > already->at_level)
		already->at_level = level;
#ifdef USES_REQUIRED_LEVELS
	faction_knows_skill_level(faction, skill->required_skill, skill->required_at_level);
#endif
#else
#ifdef USES_REQUIRED_LEVELS
	faction_knows_skill(faction, skill->required_skill);
#endif
#endif
#ifdef REPORTS_ITEM_KNOWLEDGE
	for (items = skill->use_consumes; items; items = items->next)
		faction_knows_item(faction, items->what);
	faction_knows_item(faction, skill->end_product);
	if (skill->specific_type == ARGUMENT_IS_ITEM_TAG)
		faction_knows_item(faction, skill->specific.item);
#endif
#ifdef REPORTS_RACE_KNOWLEDGE
	if (skill->specific_type == ARGUMENT_IS_RACE_TAG)
		faction_knows_race(faction, skill->specific.race);
#endif
	if (skill->specific_type == ARGUMENT_IS_SKILL_TAG)
#ifdef USES_SKILL_LEVELS
		faction_knows_skill_level(faction, skill->specific.skill, 1);
#else
		faction_knows_skill(faction, skill->specific.skill);
#endif
}
#endif


#ifdef HIDE_RESOURCES
/**
 ** MAY_SEE_ITEM
 **	Unit masters a skill that allows it to see a hidden item
 **/
int may_see_item(unit_s *unit, item_s *item)
{
experience_s	*knows;
skill_s		*skill;
#ifdef FX_SEE_RESOURCES
carry_s		*view;
#endif
/*
 * Loop on skills
 */
	for (knows = unit->skilled; knows; knows = knows->next) {
		if ((skill = knows->effective) == 0)
			continue;
#ifdef FX_SEE_RESOURCES
		if (skill->special_effects == FX_SEE_RESOURCES)
			return 1;
#endif
		if (skill->harvests == item)
			return 1;
	}
/*
 * Unit may have an item that lets it see resources
 */
#ifdef FX_SEE_RESOURCES
	for (view = unit->carrying; view; view = view->next)
		if (view->equipped && view->item->special_effects == FX_SEE_RESOURCES)
			return 1;
#endif
	return 0;
}
#endif


/**
 ** FREE_EXPERIENCE_INSTANCE
 **	Free the experience, and all the following
 **/
void free_experience_instance(experience_s *old)
{
/*
 * Recursive
 */
	if (!old)
		return;
	free_experience_instance(old->next);
	old->next = free_experience_chain;
	free_experience_chain = old;
}


/**
 ** NEW_EXPERIENCE_INSTANCE
 **	Allocate one experience instance
 **/
experience_s *new_experience_instance(void)
{
experience_s	*experience;
int	i, j;
/*
 * Any cached experience_s?
 */
	if ((experience = free_experience_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		experience = (experience_s *)malloc(sizeof(experience_s)*LEVELS_CHUNK);
		j = 0;
		for (i = 0; i < (LEVELS_CHUNK-1); i++)
			experience[i].next = experience+(++j);
		free_experience_chain = experience;
	}
/*
 * Allocated
 */
	free_experience_chain = experience->next;
	memset(experience, 0, sizeof(*experience));
	return experience;
}


#ifdef SKILL_USE_POINTS
/**
 ** ADJUST_EXPERIENCE
 **	Points/size have changed, adjust
 **/
void adjust_experience(experience_s *mastered, int size)
{
skill_s	*skill;
int	points;
/*
 * Mastered
 */
	points = mastered->points;
	skill = mastered->skill;
	if (size)
		points /= size;
	mastered->effective = 0;
#ifdef USES_SKILL_LEVELS
	mastered->level = 0;
	while (skill) {
		if (points < skill->for_level)
			break;
		mastered->effective = skill;
		skill = skill->next_level;
		mastered->level++;
	}
#ifndef SYNTAX_CHECKER
#ifdef DYNAMICALLY_DEFINED_GAME
/*	if (!skill && !mastered->skill->student && !mastered->skill->type)
		printf("Beware: skill %s last level reached\n", mastered->skill->tag.text);
		*/
#endif
#endif
#else
	if (points >= skill->for_level)
		mastered->effective = skill;
#endif
}
#endif


/**
 ** PARSE_EXPERIENCE_SKILL
 **	Parse one skill for a unit
 **/
experience_s *parse_experience_skill(experience_s *list, int size)
{
skill_s		*skill;
experience_s	*mastered;
/*
 * Threading
 */
	if (list) {
		list->next = parse_experience_skill(list->next, size);
		return list;
	}
	if (!separate_tag())
		return 0;
	if ((skill = skill_from_tag(0)) == 0)
		return 0;
	mastered = new_experience_instance();
	mastered->skill = skill;
#ifdef SKILL_USE_POINTS
	mastered->points = atol(string_ptr);
	adjust_experience(mastered, size);
#else
	mastered->effective = skill;
#endif
	return mastered;
}




/**
 ** NEW_CONSUME_INSTANCE
 **	Allocate one consume instance
 **/
static consume_s *new_consume_instance(void)
{
consume_s	*consume;
int		i, j;
/*
 * Any cached experience_s?
 */
	if ((consume = free_consume_chain) == 0) {
/*
 * Allocate by larger chuncks (to spare memory)
 */
		consume = (consume_s *)zero_malloc(sizeof(consume_s)*CONSUME_CHUNK);
		j = 0;
		for (i = 0; i < (LEVELS_CHUNK-1); i++)
			consume[i].next = consume+(++j);
		free_consume_chain = consume;
	}
/*
 * Allocated
 */
	free_consume_chain = consume->next;
	consume->next = 0;
	return consume;
}


#ifdef USES_SKILL_LEVELS
/**
 ** Quick 'n dirty
 **/
skill_s *skill_at_level(skill_s *skill, int level)
{
	while (--level > 0 && skill)
		skill = skill->next_level;
	return skill;
}
#endif


/**
 ** SKILL_FROM_TAG
 **	Returns the skill pointer associated with a tag. If specified,
 **	create the skill, because it is brand new.
 **/
skill_s *skill_from_tag(int create)
{
skill_s	*scanner;
/*
 * Simple loop
 */
	for (scanner = skills_list; scanner; scanner = scanner->next)
#ifdef USE_LONG_LONG
		if (scanner->tag.all == tag_token.all)
#else
		if (strcmp(scanner->tag.text, tag_token.text) == 0)
#endif
			return scanner;
/*
 * Creation occurs
 */
	if (create) {
		scanner = mallocator(skill_s);
		scanner->tag = tag_token;
		scanner->next = skills_list;
		skills_list = scanner;
	}
	return scanner;
}


/**
 ** LOAD_SKILLS
 **	Load the skills file.  This must be called exactly once, and no
 **	more.
 **/
void load_skills(void)
{
FILE		*skills;
skill_s		*current_skill = 0;
consume_s	*consume;
int		mode;
/*
 * Start loading
 */
	if ((skills = fopen(SKILL_FILE_NAME, "r")) == 0)
		fatal_error(SKILL_FILE_NAME);
/*
 */
	while (file_gets(skills)) {
		if (strcmp(work, "END") == 0)
			break;
		if (keyword("SKILL")) {
			if (separate_tag())
				current_skill = skill_from_tag(1);
			else
				current_skill = 0;
			continue;
		}
		if (!current_skill)
			continue;
		if (keyword("NAME")) {
			current_skill->name = strdup(string_ptr);
			continue;
		}
#ifdef REPORTS_SKILL_KNOWLEDGE
		if (keyword("TEXT")) {
			make_a_copy_(current_skill->describe, string_ptr);
			continue;
		}
#endif
#ifdef SKILL_USE_POINTS
		if (keyword("POINTS")) {
			current_skill->for_level = atoi(string_ptr);
			continue;
		}
#endif
		if (keyword("STUDENT")) {
			current_skill->student = atoi(string_ptr);
			continue;
		}
#ifdef SPECIALIST_SKILLS
		if (keyword("SPECIALIST")) {
			current_skill->specialist = 1;
			continue;
		}
#endif
		if (keyword("TYPE")) {
			current_skill->type = atoi(string_ptr);
			continue;
		}
		if (keyword("FLAGS")) {
			current_skill->flags = parse_integer(string_ptr);
			continue;
		}
		if (keyword("FX")) {
			current_skill->special_effects = parse_integer(string_ptr);
			continue;
		}
		if (keyword("STUDY_COST")) {
			current_skill->study_cost = atoi(string_ptr);
			continue;
		}
		if (keyword("EXPERIENCE")) {
			current_skill->experience = atoi(string_ptr);
			continue;
		}
		if (keyword("CAPACITY")) {
			mode = atoi(string_ptr);
			if (mode >= 0 && mode < MAX_MOVE_MODES) {
				(void)separate_token();
				current_skill->capacity[mode] = atoi(string_ptr);
			}
			continue;
		}
#ifdef USES_SKILL_LEVELS
		if (keyword("RECONSUME")) {
			current_skill->use_consumes = 0;
			continue;
		}
#endif
		if (keyword("CONSUME")) {
			if (separate_tag()) {
				consume = new_consume_instance();
				consume->what = item_from_tag(1);
				consume->amount = atoi(string_ptr);
				consume->next = current_skill->use_consumes;
				current_skill->use_consumes = consume;
			}
			continue;
		}
		if (keyword("PRODUCES")) {
			if (separate_tag()) {
				current_skill->end_product = item_from_tag(1);
				current_skill->tokens_required = atoi(string_ptr);
			}
			continue;
		}
		if (keyword("MULTIPLE")) {
			current_skill->multiples = atoi(string_ptr);
			continue;
		}
		if (keyword("HARVEST")) {
			if (separate_tag()) {
				current_skill->harvests = item_from_tag(1);
				current_skill->multiplier = atoi(string_ptr);
			}
			continue;
		}
#ifdef SKILL_BENEFITS_FROM_TOOL
		if (keyword("RETOOL")) {
			current_skill->enhanced = 0;
			continue;
		}
		if (keyword("TOOL")) {
			if (separate_tag())
				consume = new_consume_instance();
				consume->what = item_from_tag(1);
				consume->amount = atoi(string_ptr);
				consume->next = current_skill->enhanced;
				current_skill->enhanced = consume;
			continue;
		}
#endif
#ifdef SKILL_BENEFITS_FROM_BOOK
		if (keyword("WISDOM")) {
			if (separate_tag())
				current_skill->wisdom = item_from_tag(1);
			continue;
		}
#endif
#ifdef SKILL_REQUIRES_BOOK
		if (keyword("ENABLE")) {
			if (separate_tag())
				current_skill->required_item = item_from_tag(1);
			continue;
		}
#endif
		if (keyword("ASSOCIATED")) {
			if (keyword("RACE")) {
				if (separate_tag()) {
					current_skill->specific.race = race_from_tag(1);
					current_skill->specific_type = ARGUMENT_IS_RACE_TAG;
				}
			} else if (keyword("ITEM")) {
				if (separate_tag()) {
					current_skill->specific.item = item_from_tag(1);
					current_skill->specific_type = ARGUMENT_IS_ITEM_TAG;
				}
			} else if (keyword("SKILL")) {
				if (separate_tag()) {
					current_skill->specific.skill = skill_from_tag(1);
					current_skill->specific_type = ARGUMENT_IS_SKILL_TAG;
				}
			} else if (keyword("TERRAIN")) {
				if (separate_tag()) {
					current_skill->specific.terrain = terrain_from_tag(1);
					current_skill->specific_type = ARGUMENT_IS_TERRAIN_TAG;
				}
			}
			continue;
		}
		if (keyword("TARGET")) {
			if (keyword("UNIT"))
				current_skill->target = SKILL_TARGET_UNIT;
			else if (keyword("LOCATION"))
				current_skill->target = SKILL_TARGET_LOCATION;
			else if (keyword("STRUCTURE"))
				current_skill->target = SKILL_TARGET_STRUCTURE;
			else if (keyword("SKILL"))
				current_skill->target = SKILL_TARGET_SKILL;
			else if (keyword("ITEM"))
				current_skill->target = SKILL_TARGET_ITEM;
			else if (keyword("TERRAIN"))
				current_skill->target = SKILL_TARGET_TERRAIN;
			if (keyword("LOCAL"))
				current_skill->local_target = 1;
			else if (keyword("NEAR"))
				current_skill->local_target = 2;
			continue;
		}
#ifdef SKILLS_USED_IN_BATTLE
		if (keyword("COMBAT")) {
			combat_attributes(&current_skill->combat_action);
			continue;
		}
#endif
#ifdef USES_SKILL_LEVELS
		if (keyword("LEVEL")) {
skill_s	*next;
			if ((next = current_skill->next_level) == 0) {
				next = mallocator(skill_s);
				*next = *current_skill;
				next->required_skill = 0;
				next->next = 0;
#ifdef REPORTS_SKILL_KNOWLEDGE
				next->describe = 0;
#endif
				current_skill->next_level = next;
			}
			if ((next->for_level = atoi(string_ptr)) == 0)
				next->for_level = current_skill->for_level * 2;
			current_skill = next;
			continue;
		}
#endif /*USES_SKILL_LEVELS*/
#ifdef USES_REQUIRED_LEVELS
		if (keyword("REQUIRES")) {
			if (separate_tag()) {
				current_skill->required_skill = skill_from_tag(1);
#ifdef USES_SKILL_LEVELS
				if ((current_skill->required_at_level = atoi(string_ptr)) <= 0)
					current_skill->required_at_level = 1;
#endif
			}
			continue;
		}
#endif /*USES_REQUIRED_LEVELS*/
		if (stats_definition(&current_skill->bonus))
			continue;
#ifndef MAP_EDITOR
#ifdef DYNAMICALLY_DEFINED_GAME
		if (*string_ptr)
			printf("skills: %s\n", work);
#endif
#endif
	}
/*
 * Load done
 */
	fclose(skills);
}
