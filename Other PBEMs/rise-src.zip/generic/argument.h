/* $Id: argument.h,v 1.2 2000/03/03 01:06:25 jtraub Exp $
 *	Define the generic argument pointer
 */
#ifndef overload_argument_h
#define overload_argument_h

/**
 ** Arguments types
 **/
#define ARGUMENT_IS_EMPTY		0
#define ARGUMENT_IS_UNIT_ID		1
#define ARGUMENT_IS_LOCATION_ID		(ARGUMENT_IS_UNIT_ID+1)
#define ARGUMENT_IS_ITEM_TAG		(ARGUMENT_IS_LOCATION_ID+1)
#define ARGUMENT_IS_SKILL_TAG		(ARGUMENT_IS_ITEM_TAG+1)
#define ARGUMENT_IS_RACE_TAG		(ARGUMENT_IS_SKILL_TAG+1)
#define ARGUMENT_IS_TERRAIN_TAG		(ARGUMENT_IS_RACE_TAG+1)
#define ARGUMENT_IS_FACTION_ID		(ARGUMENT_IS_TERRAIN_TAG+1)
#define ARGUMENT_IS_UNIT_OR_FACTION_ID	(ARGUMENT_IS_FACTION_ID+1)
#define ARGUMENT_IS_TITLE_TAG		(ARGUMENT_IS_UNIT_OR_FACTION_ID+1)
/*
 * Argument object
 */
typedef union {
	struct struct_unit	*unit;
	struct struct_location	*location;
	struct struct_item	*item;
	struct struct_skill	*skill;
	struct struct_race	*race;
	struct struct_terrain	*terrain;
	struct struct_faction	*faction;
#ifdef USES_TITLE_SYSTEM
	struct struct_title	*title;
#endif
	char			*string;
	int			number;
} t_argument;


#endif/*overlord_argument_h*/
