/* $Id: parser.c,v 1.3 2000/07/23 04:06:03 jtraub Exp $
 *	Parser routines.
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"


/*
 * Global variables
 */
char		*string_ptr;
t_tag		tag_token;
t_tag		id_token;
char		token_keyword[256];


/**
 ** KEYWORD
 **	Is the keyword in the current stream? If so, skip it and return true
 **/
int keyword(char *key)
{
char	*scan;
/*
 * Compare
 */
	scan = string_ptr;
	while (*key) {
		if (*key != *scan) {
			if (!isalpha(*key) || !isalpha(*scan))
				return 0;
			if ((*key & 0x1F) != (*scan & 0x1F))
				return 0;
		}
		key++;
		scan++;
	}
	if (isalnum(*scan))
		return 0;
	while (isspace(*scan))
		scan++;
	string_ptr = scan;
	return 1;
}


/**
 ** SEPARATE_TAG
 **	The next token in sequence must be a tag/id. Isolate it
 **/
int separate_tag(void)
{
char *a;
char	*dest;
char	*alternate;
int	max;
char	endch;
/*
 * Skip spacing
 */
	memset(&tag_token, 0, sizeof(t_tag));
	memset(&id_token, 0, sizeof(t_tag));
	while (isspace(*string_ptr))
		string_ptr++;
	dest = tag_token.text;
	max = sizeof(tag_token) - 1;
	a = string_ptr;
	if (*a == '"')
		endch = *a++;
	else
		endch = 0;
/*
 * Copy all alnum
 */
	while (*a) {
		if (max-- <= 0)
			break;
		if (!isalnum(*a))
			break;
		*dest++ = *a++;
	}
	if (endch) {
	   if(*a== endch) a++;
	   else return 0;
	}
/*
 * Tag must end here
 */
	if (*a && !isspace(*a))
		return 0;
	string_ptr = a;
	while (isspace(*string_ptr))
		string_ptr++;
	dest = tag_token.text;
	if (!*dest)
		return 0;
/*
 * Convert to lowercase
 */
	alternate = id_token.text;
	for (; *dest; dest++) {
		*alternate = *dest;
		if (isupper(*dest))
			*dest += 'a'-'A';
		else
			if (islower(*alternate))
				*alternate += 'A'-'a';
		alternate++;
	}
	return 1;
}


/**
 ** SYNTHETIC_TAG
 **	Separate the tag, but an internal one
 **/
void synthetic_tag(char *tag)
{
char	*save;
	save = string_ptr;
	string_ptr = tag;
	(void)separate_tag();
	string_ptr = save;
}


/**
 ** SEPARATE_TOKEN
 **	The next token in sequence must be any type of keyword.
 ** If starting with a ", it may include anything up to the next
 ** "...
 **/
int separate_token(void)
{
	char *a;
	char *dest;
	int	max;
	char sep;
/*
 * Skip spacing
 */
	while (isspace(*string_ptr))
		string_ptr++;
	dest = token_keyword;
	max = sizeof(token_keyword) - 1;

	a = string_ptr;
/*
 * Separator?
 */
	if (*a == '"')
		sep = *a++;
	else
		sep = 0;
/*
 * Copy all non-space
 */
	while (*a) {
		if (sep) {
			if (*a == sep) {
				a++;
				break;
			}
		} else
			if (isspace(*a))
				break;
		if (max-- <= 0)
			break;
		*dest++ = *a++;
	}
/*
 * Token must end here
 */
	if (*a && !isspace(*a))
		return 0;
	string_ptr = a;
	while (isspace(*string_ptr))
		string_ptr++;
	*dest = 0;
	if (!token_keyword[0])
		return 0;
	return 1;
}


/**
 ** ABBREVIATED_KEYWORD
 **	An abbreviated keyword match the uppercase characters of the
 ** full keyword.
 **/
int abbreviated_keyword(char *full, char *abbrev)
{
/*
 * Search for abbreviation - using only uppercase from name -
 */
	for (; *full; full++)
		if (!islower(*full)) {
			if (islower(*abbrev)) {
				if (*abbrev-32 != *full)
					break;
			} else
				if (*abbrev != *full)
					break;
			abbrev++;
		}
	if (!*full && !*abbrev)
		return 1;
	return 0;
}


/**
 ** PARSED_ENUM
 **	Argument must appear within the enumerated list
 **/
int parsed_enum(char *arg, char *enum_list)
{
char	*string;
int	number;
/*
 * Loop on all enums
 */
	number = 0;
	while (*enum_list) {
		for (string = arg; *enum_list; enum_list++) {
			if (*enum_list == '\n')
				break;
			if (*string != *enum_list) {
				if (!isalpha(*string) || !isalpha(*enum_list) ||
				    (*string & 0x1F) != (*enum_list & 0x1F))
					break;
			}
			string++;
		}
		if (!*enum_list || *enum_list == '\n')
			return number;
		while (*enum_list)
			if (*enum_list++ == '\n')
				break;
		number++;
	}
	return -1;
}


/**
 ** PARSE_HEXA_VALUE
 **	Convert hexa to long
 **/
static long parse_hexa(char *s)
{
long	i;
/*
 * Conversion loop
 */
	for (i = 0; *s; s++) {
		if (isdigit(*s)) {
			i <<= 4;
			i |= *s - '0';
			continue;
		}
		if (isupper(*s)) {
			i <<= 4;
			i |= *s - 'A' + 10;
			continue;
		}
		if (!islower(*s))
			break;
		i <<= 4;
		i |= *s - 'a' + 10;
	}
	return i;
}


/**
 ** PARSE_INTEGER
 **/
long parse_integer(char *s)
{
long	i;
long	multiplier;
/*
 * May have a sign
 */
	while (isspace(*s))
		s++;
	switch (*s) {
	    case '-':
		return 0-parse_integer(s+1);
	    case '+':
		return parse_integer(s+1);
/*
 * May be an hexa value
 */
	    case '0':
		s++;
		if (*s == 'x' || *s == 'X')
			return parse_hexa(s+1);
/*
 * May be an octal value
 */
		multiplier = 8;
		break;
/*
 * Sounds like a decimal
 */
	    default:
		multiplier = 10;
	}
/*
 * Convert
 */
	i = 0;
	while (isdigit(*s)) {
		i *= multiplier;
		i += *s++ - '0';
	}
	return i;
}
