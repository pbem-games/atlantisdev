/* $Id: info.h,v 1.2 2000/07/06 03:07:16 jtraub Exp $
 *	Define the global settings for the game
 */
#ifndef overload_info_h
#define overload_info_h
#include "typedef.h"


/*
 * Variables
 */
extern int	game_turn_number;
extern int	seed;
extern char	*server_email;
extern char	*game_server_email;
extern char	*game_name;
extern char	deadline[];


/*
 * Prototypes
 */
extern void	load_game_info(void);
extern void	save_game_info(void);


#endif/*overlord_info_h*/
