/* $Id: combat.c,v 1.2 2000/02/18 01:25:58 jtraub Exp $
 *	Manipulate the combat settings in some elements
 */
#include "overlord.h"
#include "file.h"
#include "parser.h"
#include "enums.h"


#if defined(ITEMS_USED_IN_BATTLE) || defined(SKILLS_USED_IN_BATTLE)
/**
 ** COMBAT_DEFINITION
 **/
void combat_attributes(combat_s *stat)
{
/*
 * Target
 */
	if (keyword("TARGET")) {
		if (keyword("SIDE"))
			stat->target = BATTLEFIELD_TARGET_ARMY;
		else if (keyword("OPPOSING"))
			stat->target = BATTLEFIELD_TARGET_ENEMIES;
		else if (keyword("BATTLE"))
			stat->target = BATTLEFIELD_TARGET_ALL;
		else if (keyword("SELF"))
			stat->target = BATTLEFIELD_TARGET_SELF;
		else if (keyword("FRIEND"))
			stat->target = BATTLEFIELD_TARGET_FRIENDLY;
		else if (keyword("UNIT"))
			stat->target = BATTLEFIELD_TARGET_OPPOSING;
		else if (keyword("LEADER"))
			stat->target = BATTLEFIELD_TARGET_LEADER;
		else if (keyword("OFFICER"))
			stat->target = BATTLEFIELD_TARGET_TARGET;
		return;
	}
/*
 * Range
 */
	if (keyword("RANGE")) {
		stat->range = atoi(string_ptr);
		return;
	}
/*
 * Type of effect
 */
	if (keyword("EFFECT")) {
		if (keyword("MELEE"))
			stat->effect = COMBAT_EFFECT_MELEE;
		else if (keyword("RANGED"))
			stat->effect = COMBAT_EFFECT_RANGED;
		else if (keyword("SPECIAL"))
			stat->effect = COMBAT_EFFECT_SPECIAL;
		return;
	}
/*
 * Type of damage
 */
	if (keyword("DAMAGE_TYPE")) {
		stat->damage = atoi(string_ptr);
		return;
	}
/*
 * Bonus
 */
	if (keyword("BONUS")) {
		(void)stats_definition(&stat->bonus);
		return;
	}
/*
 * Effects
 */
	(void)stats_definition(&stat->action);
}
#endif
