/* $Id: overlord.h,v 1.1.1.1 2000/02/04 19:39:47 jtraub Exp $
 *	Global include. All Overlord modules include it.
 */
#ifndef overlord_overlord_h
#define overlord_overlord_h
/*
 * Special circumstances
 */
#ifdef TURN_PROCESSOR
#define ORDERS_NEEDED
#elif SYNTAX_CHECKER
#define ORDERS_NEEDED
#elif MAP_EDITOR
#define ORDERS_NEEDED
#endif

#include "sysdef.h"
#include "config.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#ifdef HAVE_UNISTD_H
#include <unistd.h>
#endif
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#endif
#ifdef HAVE_MEMORY_H
#include <memory.h>
#endif
#include "fxdef.h"
#include "typedef.h"

/**
 ** Macro fixes
 **/
#ifdef MAP_EDITOR
#ifdef REPORTS_ITEM_KNOWLEDGE
#undef REPORTS_ITEM_KNOWLEDGE
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
#undef REPORTS_SKILL_KNOWLEDGE
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
#undef REPORTS_RACIAL_KNOWLEDGE
#endif
#endif

#ifdef REPORTS_ITEM_KNOWLEDGE
#define REPORTS_KNOWLEDGE
#elif REPORTS_SKILL_KNOWLEDGE
#define REPORTS_KNOWLEDGE
#elif REPORTS_RACIAL_KNOWLEDGE
#define REPORTS_KNOWLEDGE
#endif


/*
 * Global prototypes
 */
extern void		fatal_error(char *);
extern void		*zero_malloc(size_t);
#define mallocator(t)	((t*)zero_malloc(sizeof(t)))


#endif/*overlord_overlord_h*/
