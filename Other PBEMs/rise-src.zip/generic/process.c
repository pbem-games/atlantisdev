/* $id: process.c,v 1.3 2000/03/18 06:39:28 jtraub exp $
 *	Processing of orders, common parts
 */
#include "turn.h"
#include "parser.h"
#include "fx.h"

/**
 ** ORDER_IS_ERROR
 **	Order is bogus, and is removed.
 **/
void order_is_error(unit_s *unit, order_s *current)
{
order_s	*next;
	if (!current)
		return;
#ifdef TRACING_REQUIRED
/*
 * Full trace
 */
	if (unit->traced_unit)
		printf("Order 0x%x (%s) for %s dropped for error\n", (unsigned)current, current->executing.keyword, unit->id.text);
#endif
/*
 * Check
 */
	if (!current->executing.routine)
		return;
/*
 * Unlink
 */
	if (current->prev)
		current->prev->next = current->next;
	else
		if (unit->orders == current)
			unit->orders = current->next;
	next = current->next;
	if (next)
		next->prev = current->prev;
/*
 * Dispose of actual structure
 */
	current->next = 0;
	current->executing.routine = 0;
	free_order_instance(current);
/*
 * Positive conditional? Drop all of them
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
/*
 * Conditional?
 */
	while (next && next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Conditional Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
/*
 * 2nd instance of positive conditional? Drop all of these too...
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
}

/**
 ** ORDER_IS_COMPLETE
 **	Order just completed, and is removed
 **/
void order_is_complete(unit_s *unit, order_s *current)
{
order_s	*next;
	if (!current)
		return;
#ifdef TRACING_REQUIRED
/*
 * Full trace
 */
	if (unit->traced_unit)
		printf("Order 0x%x (%s) for %s dropped\n", (unsigned)current, current->executing.keyword, unit->id.text);
#endif
/*
 * Check
 */
	if (!current->executing.routine)
		return;
/*
 * Unlink
 */
	if (current->prev)
		current->prev->next = current->next;
	else
		if (unit->orders == current)
			unit->orders = current->next;
	next = current->next;
	if (next)
		next->prev = current->prev;
/*
 * Dispose of actual structure
 */
	current->next = 0;
	current->executing.routine = 0;
	free_order_instance(current);
/*
 * Positive conditional? Drop all of them
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
/*
 * Conditional?
 */
	for (; next; next = next->next)
		if (!next->conditional)
			break;
		else {
			next->conditional--;
		}
/*
 * 2nd instance of positive conditional? Drop all of these too...
 */
	while (next && next->positive && !next->conditional) {
		current = next->next;
		if (next->prev)
			next->prev->next = current;
		else
			unit->orders = current;
		if (current)
			current->prev = next->prev;
		next->next = 0;
		next->considered = 1;
		next->executing.routine = 0;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s dropped\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		free_order_instance(next);
		next = current;
	}
}


/**
 ** INFINITE_CONDITIONAL
 **	An infinite duration conditional may be used to temporarily
 ** enable/disable orders. It is quite similar to execution, but does
 ** not remove orders.
 **/
void infinite_conditional(unit_s *unit, order_s *current)
{
order_s	*next;
#ifdef TRACING_REQUIRED
/*
 * Full trace
 */
	if (unit->traced_unit)
		printf("Order 0x%x (%s) for %s 'completed'\n", (unsigned)current, current->executing.keyword, unit->id.text);
#endif
/*
 * Check
 */
	current->considered = 1;
	if (!current->executing.routine)
		return;
/*
 * Positive conditional? Drop all of them
 */
	next = current->next;
	while (next && next->positive && !next->conditional) {
		next->considered = 1;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s masked\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
		next = next->next;
	}
/*
 * Conditional?
 */
	for (; next; next = next->next)
		if (!next->conditional)
			break;
		else {
			next->conditional--;
			next->masked_conditional++;
		}
/*
 * 2nd instance of positive conditional? Drop all of these too...
 */
	while (next && next->positive && !next->conditional) {
		next->considered = 1;
		next = next->next;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("Positive Order 0x%x (%s) for %s masked\n", (unsigned)next, next->executing.keyword, unit->id.text);
#endif
	}
}


/**
 ** ORDER_WAS_EXECUTED
 **	Unit just finished
 **/
int order_was_executed(unit_s *unit, order_s *current)
{
	current->considered = 1;
	if (current->days > 0)
		current->days--;
	if (current->days == 0)
		order_is_complete(unit, current);
	return 1;
}


#ifdef USES_CASH
/**
 ** UNIT_CAN_PAY
 **	Unit will have to pay for something
 **/
int unit_can_pay(unit_s *unit, long cash)
{
#ifdef LEADER_CASH_SIPHON
unit_s	*leader;
#endif
carry_s	*coins;
/*
 * Payment is extracted from coinage
 */
	if ((coins = unit->coins) == 0)
		unit->coins = coins = unit_possessions(unit, item_cash, 0);
	if (coins != 0) {
		if (coins->amount >= cash)
			return 0;
		cash -= coins->amount;
	}
#ifdef USES_FACTION_FUND
/*
 * Payment may be withdrawn
 */
#ifdef LIMITED_WITHDRAW
	if (unit->true_location->type == terrain_city && !unit->setting_miser) {
#else
	if (!unit->setting_miser) {
#endif
		if (unit->faction->faction_fund >= cash)
			return 0;
		cash -= unit->faction->faction_fund;
		if (cash < 0)
			return 0;
	}
#endif
#ifdef LEADER_CASH_SIPHON
/*
 * We may draw from out fearless leader's cash supply!
 */
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader->faction == unit->faction) {
			if ((coins = leader->coins) == 0)
				leader->coins = coins = unit_possessions(leader, item_cash, 0);
			if (coins != 0) {
				if (coins->amount >= cash)
					return 0;
				cash -= coins->amount;
			}
		}
#endif
/*
 * Cannot pay
 */
	return 1;
}


/**
 ** PAYMENT_REQUIRED
 **	Unit pays for something. It is assumed it has been checked...
 **/
int payment_required(unit_s *unit, long cash)
{
#ifdef LEADER_CASH_SIPHON
unit_s	*leader;
#endif
carry_s	*coins;
long	drawn;
/*
 * Payment is extracted from coinage
 */
	if ((coins = unit->coins) == 0)
		unit->coins = coins = unit_possessions(unit, item_cash, 1);
	drawn = 0;
	if (coins != 0) {
		if ((drawn = coins->amount) >= cash) {
			coins->amount -= cash;
			return 0;
		}
		coins->amount = 0;
		cash -= drawn;
	}
#ifdef USES_FACTION_FUND
/*
 * Payment may be withdrawn
 */
#ifdef LIMITED_WITHDRAW
	if (unit->true_location->type == terrain_city && !unit->setting_miser) {
#else
	if (!unit->setting_miser) {
#endif
		if (unit->faction->faction_fund >= cash) {
			unit->faction->faction_fund -= cash;
			unit->faction->turn_withdraw += cash;
			if (coins)
				coins->amount = 0;
			unit->withdrawn += cash;
			return 0;
		}
	}
#endif
#ifdef LEADER_CASH_SIPHON
/*
 * We may draw from out fearless leader's cash supply!
 */
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader->faction == unit->faction) {
			if ((coins = leader->coins) == 0)
				leader->coins = coins = unit_possessions(leader, item_cash, 1);
			if (coins->amount >= cash) {
				coins->amount -= cash;
				return 0;
			}
			drawn += coins->amount;
			cash -= coins->amount;
			coins->amount = 0;
		}
#endif
/*
 * Cannot pay, restore coinage. This *may* result in transfer of funds back to the
 * leader, so beware.
 */
	if (drawn)
		coins->amount += drawn;
	return 1;
}
#endif


#ifdef USES_CASH_UPKEEP
/**
 ** PAY_UPKEEP
 **	Will try to draw upon any possible upkeep source
 **/
void pay_upkeep(unit_s *unit)
{
unit_s	*other;
carry_s	*pay;
long	cash, paid;
int	food, remain, used_food;
int has_cornu;

/*
 * Try to pay locally
 */
	unit->full_day = 1;
	cash = unit->vital.upkeep;

/* Give them a break on upkeep cost if they are in an inn*/
        if(!unit->did_a_move) {
                static terrain_s *inn;
                if(!inn) {
                        synthetic_tag("inn");
                        inn = terrain_from_tag(0);
                }
                /* Special code for inns */
                if(inn && unit->current && (unit->current->type == inn)) {
                        cash *= .90;
                }
        }

#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s pays $%ld upkeep\n", unit->name, cash);
#endif
	if (!cash)
		return;
/*
 * Pay from food or upkeep tokens!
 */

/* NOTE TO SELF *.
 * When doing this upkeep, need to track how many already upkept in each
 * subgroup whether by food or by cash.  This *might* mean  that we need
 * to completely rewrite this code
 */
	remain = unit->size;
	if (!remain)
		return;
	food = 0, used_food = 0;

	has_cornu = fx_equipped_on_unit(unit, FX_CORNUCOPIA);
	
	if(has_cornu) {
		int men = 0;
		for(pay = unit->carrying; pay; pay = pay->next) {
			if(pay && pay->amount && pay->item->equip_bonus.upkeep &&
					(pay->item->item_type == ITEM_FOLLOWER)) {
				men += pay->amount;
			}
		}
		if(men > 30) men = 30;
		if(men) {
			item_s *manna;
			synthetic_tag("mann");
			manna = item_from_tag(0);
			printf("Generating %d manna for %s [%s] of %s.",
					men, unit->name, unit->id.text, unit->faction->id.text);
			/* Add manna */
			pay = unit_possessions(unit, manna, 1);
			pay->amount += men;
			sprintf(work, "The Cornucopia provides %d manna to feed your men.",
					men);
			unit_personal_event(unit, 30, work);
		} else {
			sprintf(work, "The Cornucopia is empty as you have no followers.");
			unit_personal_event(unit, 30, work);
		}
	}

	/* Clear all the contributed markers */
	for (pay = unit->carrying; pay; pay = pay->next) {
	    pay->contributed2 = 0;
	}

	for (pay = unit->carrying; pay; pay = pay->next) {
		if (pay->amount && pay->item->item_category == 6) {
		    printf("Unit %s (%s) [%s] is using manna for upkeep\n",
			    unit->name, unit->id.text,
			    unit->faction->id.text);
		    food += pay->amount;
		}
	}

	if(food) {
	    /* Collect all the followers that can be fed */
	    int need_food = 0;
	    for(pay = unit->carrying; pay; pay = pay->next) {
		if(pay && pay->amount && pay->item->equip_bonus.upkeep &&
		   (pay->item->item_type == ITEM_FOLLOWER ||
		    pay->item->item_type == ITEM_BEAST)) {
		    need_food += pay->amount;
		}
	    }
	    /* Pick a random follower that needs upkeep */
	    while(food && need_food) {
		int fcount = 0;
		int who = roll_1Dx(need_food);
		for(pay = unit->carrying; pay; pay = pay->next) {
		    if(!pay->amount) continue;
		    if(!pay->item->equip_bonus.upkeep) continue;
		    if(pay->item->item_type != ITEM_FOLLOWER &&
		       pay->item->item_type != ITEM_BEAST)
			continue;
		    if(who < fcount+pay->amount) break;
		    fcount += pay->amount;
		}
		/* Mark them as upkept */
		if(!pay && need_food) {
		    printf("Unit %s (%s) should have something to feed!\n",
			    unit->name, unit->id.text);
		    break;
		}
		need_food--;
		food--;
		used_food++;
		/* deduct the cost of their upkeep */
		cash -= pay->item->equip_bonus.upkeep;
		pay->contributed2++;
	    }
	}

	if (used_food) {
		sprintf(work, "%d rations eaten for upkeep", used_food);
		unit_personal_event(unit, 30, work);
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s eats %d food\n", unit->name, used_food);
#endif
		/* Need to subtract the food we used from the food on hand */
		for(pay = unit->carrying; pay; pay = pay->next) {
		    if (pay->amount && pay->item->item_category == 6) {
			if(pay->amount > used_food) {
			    pay->amount -= used_food;
			    used_food = 0;
			} else {
			    used_food -= pay->amount;
			    pay->amount = 0;
			}
		    }
		}
		if(used_food) {
		    printf("Unit %s (%s) used more food than it had!\n",
			    unit->name, unit->id.text);
		}
	}
	if (!cash)
		return;
/*
 * Use faction fund in priority?
 */
#ifdef USES_FACTION_FUND
	if (cash && unit->setting_support && unit->faction->faction_fund) {
		if (cash >= unit->faction->faction_fund)
			paid = unit->faction->faction_fund;
		else
			paid = cash;
		cash -= paid;
		unit->faction->faction_fund -= paid;
		unit->faction->turn_withdraw += paid;
		sprintf(work, "Using $%ld funds for upkeep", paid);
		unit_personal_event(unit, 30, work);
		if (!cash)
			return;
	}
#endif
/*
 * Pay from pocket change
 */
	if ((pay = unit->coins) == 0)
		unit->coins = pay = unit_possessions(unit, item_cash, 0);
	if (pay && pay->amount) {
		if (pay->amount >= cash) {
			pay->amount -= cash;
			return;
		}
		cash -= pay->amount;
		pay->amount = 0;
	}
/*
 * Any other unit of the same faction around that could lend us coins?
 */
	for (other = unit->faction->units; other; other = other->same_faction)
		if (!other->inactive && !other->dead && other->true_location == unit->true_location && !other->is_captive) {
			if (!other->full_day)
				pay_upkeep(other);
			if ((pay = other->coins) == 0)
				other->coins = pay = unit_possessions(other, item_cash, 0);
			if (pay && pay->amount) {
				if (pay->amount >= cash)
					paid = cash;
				else
					paid = pay->amount;
				sprintf(work, "%s [%s] lent $%ld for %s [%s]'s upkeep", other->name, other->id.text,
							paid, unit->name, unit->id.text);
				unit_personal_event(unit, 30, work);
				unit_personal_event(other, 30, work);
				pay->amount -= paid;
				cash -= paid;
				if (!cash)
					return;
			}
		}
/*
 * We still need cash!
 */
#ifdef USES_FACTION_FUND
	if (cash && unit->faction->faction_fund) {
		if (cash >= unit->faction->faction_fund)
			paid = unit->faction->faction_fund;
		else
			paid = cash;
		cash -= paid;
		unit->faction->faction_fund -= paid;
		unit->faction->turn_withdraw += paid;
		sprintf(work, "Using $%ld funds for upkeep", paid);
		unit_personal_event(unit, 30, work);
	}
#endif
	if (cash) {
		int destroyable = 0;
		printf("Unit %s (%s) [%s] lacks upkeep!\n", unit->name, unit->id.text, unit->faction->id.text);
		sprintf(work, "Lacks $%ld for upkeep", cash);
		unit_personal_event(unit, 30, work);
		/* Need to kill off followers, beasts, and items */
		/* Find all destroyable items */
		for(pay = unit->carrying; pay; pay = pay->next) {
			if(pay && pay->amount && pay->item->equip_bonus.upkeep) {
				destroyable += pay->amount - pay->contributed2;
				pay->contributed = 0;
			}
		}
		
		while(cash && destroyable) {
			int count = 0;
			/* Pick a random item */
			int i = roll_1Dx(destroyable);
			for(pay = unit->carrying; pay; pay = pay->next) {
			    	int temp = pay->amount-pay->contributed2;
				if(!pay->item->equip_bonus.upkeep) continue;
				if(i < count+temp) break;
				count += temp;
			}
			if(!pay && destroyable) {
				printf("Unit %s (%s) should have something to destroy, but doesn't seem to!\n", unit->name, unit->id.text);
				break;
			}
			if(cash > pay->item->equip_bonus.upkeep) {
				pay->amount--;
				destroyable--;
				pay->contributed++;
				cash -= pay->item->equip_bonus.upkeep;
			} else {
				if(roll_1Dx(pay->item->equip_bonus.upkeep) < cash) {
					pay->amount--;
					destroyable--;
					pay->contributed++;
				}
				cash = 0;
			}
		}
		for(pay = unit->carrying; pay; pay = pay->next) {
			int am = pay->contributed;
			item_s *item = pay->item;
			if(am) {
				char *destruction = "rotted";
				if(item->item_type == ITEM_FOLLOWER) {
					destruction = "deserted";
				} else if(item->item_type == ITEM_BEAST) {
					destruction = "starved";
				}

				sprintf(work, "%d %s %s due to lack of upkeep",
					am,
					(am == 1 ? item->name : item->plural),
					destruction);
				unit_personal_event(unit, 30, work);
				pay->contributed = 0;
			}
		}
	}
}
#endif
