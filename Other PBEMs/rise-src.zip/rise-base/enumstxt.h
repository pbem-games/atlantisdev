/* $Id: enumstxt.h,v 1.1 2000/06/23 05:20:55 jtraub Exp $
 *	Strings
 */

/**
 ** This is visual, and appear in the report generator
 **/
#ifndef SYNTAX_CHECKER
extern char		battlefield_targets[];
extern char		battlefield_ranges[];
extern char		battlefield_actions[];
extern char		battle_damage_types[];
extern char		equipment_categories[];

#ifdef WORLD_HAS_CLIMAT
extern char		season_names[];
extern char		climatic_conditions[];
#endif
#ifdef USES_TITLE_SYSTEM
extern char		title_kinds[];
#endif
#ifndef TURN_PROCESSOR
extern char		skill_types[];
extern char		race_types[];
#endif
#endif
extern char		regions[];
