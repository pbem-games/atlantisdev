/* $Id: checker_u.c,v 1.7 2000/10/21 02:00:39 jtraub Exp $
 *	Commands checking module
 */
#include "checker.h"
#include "command_e.h"
#include "command_u.h"
#include "enumstxt.h"

/**
 ** Cache
 **/
skill_s		*magecraft;


/**
 ** Strings pulled from report module
 **/


/**
 ** ORDER_WAS_EXECUTED
 **	Unit just finished
 **/
int order_was_executed(unit_s *unit, order_s *current)
{
	return 0;
}


/**
 ** UNEXECUTABLE
 **	Default call for orders
 **/
int unexecutable(unit_s *unit, order_s *current)
{
	fprintf(current_report, "%s\n>>> command not yet implemented. The GM will be notified\n", raw_order);
	return 0;
}

/**
 ** Redirected execute
 **/
int execute_accept(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_at(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_attack(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_capture(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_christen(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_day(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_describe(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_eject(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_enter(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_equip(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_forget(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_have(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_less(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_exactly(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_kill(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_leader(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_leading(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_leave(unit_s *unit, order_s *added)
{
	return 0;
}
int execute_loyal(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_march(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_move(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_name(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_oath(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_promote(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_recruit(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_retreat(unit_s *unit, order_s *added)
{
	return 0;
}
int execute_see(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_setting(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_size(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_skill(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_stack(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_stance(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_stay(unit_s *unit, order_s *added)
{
	return 0;
}
int execute_study(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_swap(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_tactic(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_teach(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_transfer(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_unequip(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_unstack(unit_s *unit, order_s *added)
{
	return 0;
}

/**
 ** Has optional parts
 **/
int execute_buy(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_camp(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_caravan(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_combat(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_disband(unit_s *unit, order_s *added)
{
	if (basic_syntax_check(unit, added))
		return 1;
	if (strcasecmp(added->arguments[0].string, "UNIT") && 
		strcasecmp(added->arguments[0].string, "\"UNIT\""))
		return 1;
	return 0;
}
int execute_drop(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_get(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_give(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_synchro(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_use(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_research(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_sell(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_withdraw(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
int execute_within(unit_s *unit, order_s *added)
{
	return basic_syntax_check(unit, added);
}
