/* $Id: turn.c,v 1.63 2001/02/08 19:14:20 jtraub Exp $
 *	Turn processor main module.
 */
#include "turn.h"
#include "parser.h"
#include "fx.h"
#include "battle.h"
#include "command_u.h"
#include "enumstxt.h"
#include <time.h>

char *endgame = "Across the world the faces of the 5 Gods appear in the heavens and proclaim in voices that ring like thunder, 'The artifacts that we hid throughout the planes have all been returned to the knowledge of mortals.   The testing is almost complete.  Let those who desire to join us take up the artifacts and prove themselves worthy.'";

char *sword_msg = "The faces of the gods appear once more within the sky, and joining them is the face of Cedrik Borgan, leader of The Golden Phoenix.   Their voices thunder, 'Here stands Cedrik.  He has proven himself worthy by taking up the six Swords and now strides among us.   Remember him and honor him as you honor us.";
char *craft_msg = "The faces of the gods appear once more within the sky, and joining them is the face of <NAME HERE>, leader of <CLAN HERE>.   Their voices thunder, 'Here stands <NAME>.  He has proven himself worthy by taking up the five Craft artifacts and now strides among us.   Remember him and honor him as you honor us.";
char *mage_msg = "The faces of the gods appear once more within the sky, and joining them is the face of <NAME HERE>, leader of <CLAN HERE>.   Their voices thunder, 'Here stands <NAME>.  He has proven himself worthy by taking up the three Mage artifacts and now strides among us.   Remember him and honor him as you honor us.";

/**
 ** Globals
 **/
int		today_number;
item_s *token_tax, *token_entertain, *discontent_effect, *item_dead,
	   *item_corpse, *item_mstudy, *item_recruit, *item_cash;
int sword_victory = 0;
int mage_victory = 0;
int craft_victory = 0;
static int mage_announce = 0;
static int craft_announce = 0;
static int sword_announce = 0;
#ifdef USES_MANA_POINTS
item_s		*item_mana;
#endif
skill_s		*magecraft,
		*combat_skill,
		*melee_skill,
		*parry_skill,
		*marketing_skill,
		*scouting_skill;
skill_s		*air_skill,
		*earth_skill,
		*fire_skill,
		*void_skill,
		*water_skill;
terrain_s	*terrain_city, *neutral_city;
race_s		*camp_race, *garrison_race;

int unit_has_artifacttype_equipped(unit_s *unit, int type)
{
	carry_s *owns;
	int count = 0;
	for(owns = unit->carrying; owns; owns = owns->next) {
		if(owns && owns->amount && owns->equipped &&
				owns->item->item_special == type)
			count++;
	}
	return count;
}

int unit_has_artifacttype(unit_s *unit, int type)
{
	carry_s *owns;
	int count = 0;
	for(owns = unit->carrying; owns; owns = owns->next) {
		if(owns && owns->amount && owns->item->item_special == type) count++;
	}
	return count;
}


int unit_has_artifact(unit_s *unit)
{
	carry_s *owns;
	int count = 0;
	for(owns = unit->carrying; owns; owns = owns->next) {
		if(owns && owns->amount && owns->item->unique) count++;
	}
	return count;
}

int all_artifacts_found(void)
{
	unit_s *unit;
	int count = 0;
	for(unit = unit_list; unit; unit = unit->next) {
		if(unit->size <= 0) continue;
		count += unit_has_artifact(unit);
	}
	if(count == 14) return 1;
	return 0;
}

void check_sword_victory() {
	faction_s *faction;
	unit_s *unit;
	int count = 0;
	for(faction = faction_list; faction; faction = faction->next) {
		if(faction->resigned) continue;
		count = 0;
		for(unit = faction->units; unit; unit = unit->same_faction) {
			if(unit_has_artifacttype(unit, 1) != 1) continue;
			if(unit_has_artifacttype_equipped(unit, 1) != 1) continue;
			count++;
		}
		if(count == 6) {
			sword_victory = 1;
			return;
		}
	}
}

void check_mage_victory() {
	faction_s *faction;
	unit_s *unit;
	for(faction = faction_list; faction; faction = faction->next) {
		if(faction->resigned) continue;
		for(unit = faction->units; unit; unit = unit->same_faction) {
			if(unit_has_artifacttype(unit, 2) != 3) continue;
			if(unit_has_artifacttype_equipped(unit, 2) != 3) continue;
			mage_victory = 1;
			return;
		}
	}
}

void check_craft_victory() {
	faction_s *faction;
	unit_s *unit;
	int count = 0;
	for(faction = faction_list; faction; faction = faction->next) {
		if(faction->resigned) continue;
		count = 0;
		for(unit = faction->units; unit; unit = unit->same_faction) {
			if(unit_has_artifacttype(unit, 3) != 1) continue;
			if(unit_has_artifacttype_equipped(unit, 3) != 1) continue;
			count++;
		}
		if(count == 5) {
			craft_victory = 1;
			return;
		}
	}
}

void check_victory(void)
{
	faction_s *faction;
	if(!all_artifacts_found()) return;
    if(!sword_victory) check_sword_victory();
    if(!mage_victory) check_mage_victory();
    if(!craft_victory) check_craft_victory();

	/* Announce to the world */
	if(sword_victory || craft_victory || mage_victory) {
		if(!sword_announce && sword_victory)
			printf("SWORD VICTORY!!!!\n");
		if(!mage_announce && mage_victory)
			printf("MAGE VICTORY!!!!\n");
		if(!craft_announce && craft_victory)
			printf("CRAFT VICTORY!!!!\n");
		for(faction = faction_list; faction; faction = faction->next) {
			if(sword_victory && !sword_announce) {
				faction_wide_event(faction, today_number, sword_msg);
			}
			if(mage_victory && !mage_announce) {
				faction_wide_event(faction, today_number, mage_msg);
			}
			if(craft_victory && !craft_announce) {
				faction_wide_event(faction, today_number, craft_msg);
			}
		}
		if(sword_victory) sword_announce = 1;
		if(mage_victory) mage_announce = 1;
		if(craft_victory) craft_announce = 1;
	}
}

void artifact_homing(void)
{
	int type;
	unit_s *unit, *unit2;
	carry_s *owns;
	char buf[5000];
	if(!all_artifacts_found()) return;
	for(type = 1; type < 4; type++) {
		for(unit = unit_list; unit; unit=unit->next) {
			if(unit_has_artifacttype(unit, type)) {
				for(unit2 = unit_list; unit2; unit2= unit2->next) {
					if(unit2 == unit) continue;
					if(unit2->size <= 0) continue;
					for(owns = unit2->carrying; owns; owns = owns->next) {
						if(owns && owns->amount &&
						   owns->item->item_special==type) {
							sprintf(buf, "You get the odd feeling that %s [%s] is located at %s", owns->item->name, owns->item->tag.text, unit2->true_location->name);
							if(unit2->true_location->region) {
								sprintf(work, " <%s>",
										visual_enum(unit2->true_location->region, regions));
							} else {
								strcpy(work, "");
							}
							strcat(buf, work);
							sprintf(work, " [%s]", unit2->true_location->id.text);
							strcat(buf, work);
							if(unit2->true_location->type->type == TERRAIN_COUNTRY) {
								sprintf(work, " (%d,%d).",
										unit2->true_location->x,
										unit2->true_location->y);
							} else {
								strcpy(work, ".");
							}
							strcat(buf, work);
							unit_personal_event(unit, 30, buf);
						}
					}
				}
			}
		}
	}
}

/**
 ** CLEANUP_LOCATIONS
 **	Locations are adjusted
 **/
static void cleanup_locations(void)
{
location_s	*local;
/*
 * Description is purely local
 */
	for (local = location_list; local; local = local->next)
		local->description = 0;
}

/**
 ** SPECIAL_ADJUST_UNITS
 **     Give units that need them special resources
 **/
void special_adjust_units(void)
{
	unit_s *unit;
        static race_s *claim;
	resource_s	*token, *resource;

        if (!claim) {
                synthetic_tag("clai");
                claim = race_from_tag(0);
        }

	for(unit = unit_list; unit; unit = unit->next) {
		if(unit->race == claim) {
			for(resource = unit->true_location->resources;
			    resource; resource = resource->next) {
				if(resource->type == token_tax) break;
			}
			if(resource) {	
				token = new_resource_instance();
				token->next = unit->special_resources;
				unit->special_resources = token;
				token->type = resource->type;
				token->remains = resource->remains * 50;
				token->remains += 50;
				token->remains /= 100;
			}
		}
	}
}


/**
 ** ALL_PAY_UPKEEP
 **/
static void all_pay_upkeep(void)
{
unit_s		*unit;
experience_s	*exp;
carry_s		*followers;
int		size;

	for (unit = unit_list; unit; unit = unit->next) {
		unit->full_day = 0;
		for (exp = unit->skilled; exp; exp = exp->next) {
			if (exp->points && !exp->effective && !exp->studied) {
				exp->points -= SKILL_POINTS_PER_DAY;
				if (exp->points < 0)
					exp->points = 0;
			}
		}
		if (unit->race == camp_race) {
			/* We are only a garrison *iff* we have troops */
			carry_s *carry;
			int gar = 0;
			for(carry = unit->carrying; carry; carry = carry->next) {
				if(carry->item->item_type == ITEM_FOLLOWER && carry->amount) {
					if(carry->item->equip_bonus.melee)
						gar = 1;
					if(carry->item->equip_bonus.missile)
						gar = 1;
				}
			}
			if (gar)
				unit->race = garrison_race;
		} else if (unit->race == garrison_race) {
			/* We are only a garrison *iff* we have troops */
			carry_s *carry;
			int gar = 0;
			for(carry = unit->carrying; carry; carry = carry->next) {
				if(carry->item->item_type == ITEM_FOLLOWER && carry->amount) {
					if(carry->item->equip_bonus.melee)
						gar = 1;
					if(carry->item->equip_bonus.missile)
						gar = 1;
				}
			}
			if (!gar)
				unit->race = camp_race;
		}
		if (!unit->size || !unit->race)
			continue;
		if (unit->race->type == 0 || unit->race->type == 2) {
			size = 0;
			for (followers = unit->carrying; followers; followers = followers->next)
				if (followers->item->item_type == ITEM_FOLLOWER)
					size += followers->amount;
			if (size == 0)
				execute_disband(unit, 0);
		}
	}

	for(unit = unit_list; unit; unit = unit->next) {
		if(unit->dead || unit->inactive || !unit->faction) continue;
		if(unit->faction->dissolve >= 10) {
			if(roll_1Dx(100)<(50+(5*(unit->faction->dissolve-10)))) {
				sprintf(work, "Unit disbands due to neglect.");
				unit->is_captive = 0;
				unit_personal_event(unit, 30, work);
				execute_disband(unit, 0);
			}
		}
	}

	for (unit = unit_list; unit; unit = unit->next) {
		if (!unit->inactive &&
		    !unit->dead &&
		    unit->size &&
		    !unit->full_day &&
		    unit->vital.upkeep) {
			pay_upkeep(unit);
		}
	}
	for (unit = unit_list; unit; unit = unit->next) {
		if (!unit->size || !unit->race)
			continue;
		if(unit->race->type == 0 || unit->race->type == 2) {
			size = 0;
			for(followers = unit->carrying; followers; followers = followers->next) {
				if(followers->item->item_type == ITEM_FOLLOWER)
				    size += followers->amount;
			}
			if(size == 0) execute_disband(unit, 0);
		}
	}
}


/**
 ** CLEANUP_UNITS
 **	Units are adjusted. Stockpiles vanish over time (the more people,
 ** the faster), unit finish switching sides.
 **/
static void cleanup_units(void)
{
unit_s		*unit, *overall_leader;
carry_s		*had;

/*
 *  Unstack any units who are stacked under a resigned faction.
 */
	for(unit = unit_list; unit; unit = unit->next) {
		if(unit->dead || unit->inactive) continue;
		if(unit->leader) {
			if((unit->faction != unit->leader->faction)  &&
			   (!unit->leader->faction || unit->leader->faction->resigned)) {
				overall_leader = unit->leader;
				while(overall_leader->leader) overall_leader = overall_leader->leader;
				unstack_unit(unit);
				unit->next_location = overall_leader->next_location;
				overall_leader->next_location = unit;
			}
		}
	}

/*
 * Collect wages
 */
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead)
			continue;
/*
 * Meanwhile, change our loyalty... Any pending order
 * is dropped. Don't care about recycling, we're going to exit
 * in a few seconds...
 */
		if (unit->now_loyal) {
			unit->faction = unit->now_loyal;
			unit->orders = 0;
		}
/*
 * Stockpiles might vanish
 */
		if (unit->size == 0 || !unit->faction) {
			unit->faction = 0;
			for (had = unit->carrying; had; had = had->next) {
				had->tokens = 0;
				had->equipped = 0;
				had->amount = 0;
				if(had->item->unique)
				    return_unique_item(had->item);
			}
/*
 * Stockpile is now empty and vanishes...
 */
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("stockpile %s wiped\n", unit->name);
#endif
			unit->dead = 1;
			move_to_location(unit, 0);
			continue;
		}
	}
}


/**
 ** SET_STACK_MOVEMENT
 **	The entire stack is either moving or not
 **/
void set_stack_movement(unit_s *stack, int flag)
{
carry_s	*partial;
/*
 * Loop
 */
	if (stack) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s movement is now %s\n",stack->name, flag?"on":"off");
#endif
		stack->is_moving = flag;
		stack->full_day  = 1;
		stack->was_guarding = 0;
		stack->is_guarding = 0;
		stack->setting_guard = 0;
		stack->setting_protect = 0;
		stack->executing = 0;
		stack->did_a_move = 1;
		if (flag)
			for (partial = stack->carrying; partial; partial = partial->next)
				partial->tokens = 0;
		for (stack = stack->stack; stack; stack = stack->next_location) {
			if (flag && !stack->is_moving)
				unit_personal_event(stack, today_number, "Moving along our stack");
			set_stack_movement(stack, flag);
		}
	}
}


/**
 ** EXECUTE_MOVEMENT_ADVANCES
 **	Stack process a movement
 **/
void execute_movement_advances(unit_s *stack)
{
location_s	*current,
		*toward;
unit_s		*guards;
extern int	execute_retreat(unit_s *,order_s *);
/*
 * RETREAT is scheduled?
 */
	current = stack->current;
	toward  = stack->toward;
	if (stack->orders && stack->orders->executing.routine == execute_retreat) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s retreats\n", stack->name);
#endif
		order_is_complete(stack, stack->orders);
		unit_personal_event(stack, today_number, "Retreating!");
		stack->already_moved = stack->move_for_days - stack->already_moved;
	} else
/*
 * Switchover? Occurs only if we did not retreat
 */
		if ((stack->move_for_days / 2) == stack->already_moved) {
#ifdef TRACING_REQUIRED
			if (stack->traced_unit)
				printf("%s is now in %s [%s]\n", stack->name, toward->name, toward->id.text);
#endif
/*
 * Do we have hostile guards there?
 */
			if ((guards = guarded_against_activity(stack, toward, ATTITUDE_IS_HOSTILE)) && !stack->sneaking) {
			        char facbuf[500];
			        char stackfacbuf[500];
				if(guards->setting_advert) {
				    sprintf(facbuf, ", anonymous");
				} else {
				    sprintf(facbuf, ", of %s [%s]",
					    guards->faction->name,
					    guards->faction->id.text);
				}
				if(stack->setting_advert) {
				    sprintf(stackfacbuf, ", anonymous");
				} else {
				    sprintf(stackfacbuf, ", of %s [%s]",
					    stack->faction->name,
					    stack->faction->id.text);
				}
				if (stack->is_moving <= 1) {
					sprintf(work, "Prevented from entering %s [%s] by %s [%s]%s",
						toward->name, toward->id.text,
						guards->name, guards->id.text,
						facbuf);
					unit_personal_event(stack, today_number, work);
					sprintf(work, "Prevented %s [%s]%s from entering.",
						stack->name, stack->id.text,
						stackfacbuf);
					unit_personal_event(guards, today_number, work);
					stack->full_day = 1;
					stack->already_moved++;
					if (stack->already_moved >= stack->move_for_days)
						execute_movement_advances(stack);
					return;
				}
/*
 * We are marching! Attack!
 */
				stack->move_from = current;
				move_to_location(stack, toward);
#ifdef PRISONERS_TAKEN
				if(stack->participate == 4) {
					all_capture_target = 1;
				}
#endif
				sprintf(work, "%s [%s] attacks %s [%s]", stack->name,
						stack->id.text, guards->name, guards->id.text);
				unit_personal_event(stack, today_number, work);
				unit_personal_event(guards, today_number, work);
				stack->sneaking = 0;

				initiate_attack(stack, guards);
#ifdef PRISONERS_TAKEN
				all_capture_target = 0;
#endif

				if(stack->dead || stack->is_captive) {
					sprintf(work, "Prevented from entering %s [%s] by %s [%s] %s", toward->name, toward->id.text, guards->name, guards->id.text, facbuf);
					unit_personal_event(stack, today_number, work);
					sprintf(work, "Prevented %s [%s]%s from entering.",
						stack->name, stack->id.text,
						stackfacbuf);
					unit_personal_event(guards, today_number, work);
					return;
				}

				if(!stack->victor) {
					sprintf(work, "Prevented from entering %s [%s] by %s [%s] %s", toward->name, toward->id.text, guards->name, guards->id.text, facbuf);
					unit_personal_event(stack, today_number, work);
					sprintf(work, "Prevented %s [%s]%s from entering.",
						stack->name, stack->id.text,
						stackfacbuf);
					unit_personal_event(guards, today_number, work);
				        move_to_location(stack, current);
					stack->full_day = 1;
					stack->already_moved++;
					if (stack->already_moved >= stack->move_for_days)
						execute_movement_advances(stack);
					return;
				}
				unit_set_victor(stack, 0);
				
				/* We won, we get to move in */
				stack->toward = current;
				current = toward;
			} else  {
/*
 * No obstacles
 */
				move_to_location(stack, toward);
				stack->toward = current;
				current = toward;
			}
		}
/*
 * Movement finished?
 */
	stack->full_day = 1;
	stack->already_moved++;
	if (current->type->attached_skill) {
		if (add_landwalk_experience(stack, current->type->attached_skill, SKILL_POINTS_PER_DAY/10))
			compute_stack_capacity(stack);
	}
	if (stack->already_moved >= stack->move_for_days) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s arrives\n", stack->name);
#endif
		sprintf(work, "%s [%s] arrived from %s [%s]", stack->name, stack->id.text,
				stack->toward->name, stack->toward->id.text);
		if(!stack->sneaking)
			location_global_event(stack, today_number, work);
		unit_personal_event(stack, today_number, work);

		/* Handle treasure */

		if(stack->true_location->unlooted &&
		   stack->true_location->treasure) {
		    carry_s *c;
		    if(stack->true_location->treasure->amount == 1) {
		       sprintf(work, "You find the %s [%s]!",
			       stack->true_location->treasure->type->name,
			       stack->true_location->treasure->type->tag.text);
		    } else {
		       sprintf(work, "You find %d %s [%s]!",
			       stack->true_location->treasure->amount,
			       stack->true_location->treasure->type->name,
			       stack->true_location->treasure->type->tag.text);
		    }
		    unit_personal_event(stack, today_number, work);
		    c = unit_possessions(stack,
					 stack->true_location->treasure->type,
					 1);
		    c->amount += stack->true_location->treasure->amount;
		    stack->true_location->unlooted = 0;
		    if(c->item->unique) {
				faction_s *fac;
				int found=0;
				if(all_artifacts_found()) found =1;
				for(fac = faction_list; fac; fac = fac->next) {
					faction_wide_event(fac, today_number,
							c->item->unique);
					if(found) faction_wide_event(fac, today_number, endgame);
				}
		    }
		}

		stack->toward = 0;
		stack->already_moved = 0;
		stack->move_for_days = 0;
		stack->moving_by = 0;
		set_stack_movement(stack, 0);
#ifdef STEALTH_STATS
		compute_stack_stealth(stack);
#endif
/*
 * Recursively set full-day processed
 */
	} else
		set_stack_movement(stack, stack->is_moving);
}


/**
 ** FULL_DAY_ORDER_BY_UNIT
 **	One unit selects a full day order. It has to, we might be called
 ** by execute_teach
 **/
int full_day_order_by_unit(unit_s *unit)
{
order_s		*order, *next;
unit_s		*target;

/*
 * If the unit is moving, we'll handle that under the unit itself, not
 * under this being called because someone is trying to teach us or
 * something else
 */
	if(unit->is_moving) {
		return 0;
	}
/*
 * Has enemies and is ready to pounce! Maybe this unit will attack...
 */
	if (!unit->is_captive && unit->participate > 2 && unit->faction->has_enemies && unit->true_location->type != neutral_city) {
		who_is_present(unit->true_location);
		for (target = unit->true_location->interacting; target; target = target->next_visible) {
			if (!may_interact_with(unit, target) || target->size <= 0 || target->is_captive)
				continue;
			if (attitude_vs(unit->faction, target) != ATTITUDE_IS_ENEMY)
				continue;
			if(unit->participate == 4 && target->race->type != RACE_LEADER)
				continue;
/*
 * Do an attack!
 */
			if(!eligible_attacker(unit) || !eligible_defender(target))
				continue;

			sprintf(work, "Spotted %s [%s], an enemy!", target->name, target->id.text);
			unit_personal_event(unit, today_number, work);
			sprintf(work, "%s [%s] attacks %s [%s]", unit->name, unit->id.text,
					target->name, target->id.text);
			unit_personal_event(target, today_number, work);
#ifdef PRISONERS_TAKEN
			if(unit->participate == 4) {
				all_capture_target = 1;
			}
#endif
			initiate_attack(unit, target);
#ifdef PRISONERS_TAKEN
			all_capture_target = 0;
#endif
			return 1;
		}
		if (unit->full_day || unit->dead)
			return 0;
	}
/*
 * Find an order to process
 */
	for (order = unit->orders; order; order = next) {
		next = order->next;
		if (order->executing.full_day_order &&
		    !order->conditional&&
		    !order->considered &&
		    (!order->limit_low || (order->limit_low <= today_number && order->limit_high >= today_number)) &&
	    	    (*order->executing.routine)(unit, order)) {
			return 1;
		}
/*
 * We do have something that was unexecuted, and but the next orders have
 * been dropped! Reloop
 */
		if (next && !next->executing.routine)
			next = unit->orders;
	}
/*
 * Fall back to default
 */
	if (!order) {
		(void)execute_work(unit, 0);
		unit->full_day = 1;
	}
	return 1;
}


/**
 ** FULL_DAY_ORDER_BY_STACK
 **	Stack process a full day order
 **/
static int full_day_order_by_stack(unit_s *stack)
{
unit_s		*sibling;
int		all_done;
/*
 * Loop on all of the stack
 */
	all_done = 0;
	while (stack) {
/*
 * Unit looks dead? Retry
 */
		if (stack->dead || !stack->size) {
			stack->executing = 0;
			stack->full_day = 1;
		}
/*
 * Search for a full-day order
 */
		sibling = stack->next_location;
		if (!stack->full_day) {
			if (stack->is_moving) {
				if (stack->toward)
					execute_movement_advances(stack);
				else
					stack->full_day = 1;
				all_done = 1;
			} else {
				all_done |= full_day_order_by_unit(stack);
				if (stack->full_day || stack->dead)
					break;
			}
		}
		if (stack->dead)
			break;
		if (full_day_order_by_stack(stack->stack))
			all_done = 1;
		stack = sibling;
	}
	return all_done;
}

/**
 ** ADJUST_UNIT_EFFECTS
 ** 	Adjust any unit special effects
 **/
static void adjust_unit_effects(unit_s *unit)
{
	static item_s *masq_cache;
	static item_s *sneak_cache;
	carry_s *carry;
	item_s *item;

	if(!masq_cache) {
		synthetic_tag("dayaurm");
		masq_cache = item_from_tag(0);
	}
	if(!sneak_cache) {
		synthetic_tag("daycove");
		sneak_cache = item_from_tag(0);
	}

	unit->has_effects = 0;
	unit->sneaking = 0;
	unit->masqing = 0;
	for(carry = unit->carrying; carry; carry = carry->next) {
		item = carry->item;
		if(item->item_type == ITEM_DAYS && carry->amount != 0) {
			unit->has_effects = 1;
			if(item == masq_cache) unit->masqing = 1;
			if(item == sneak_cache && !unit->is_captive &&
			   !unit->setting_guard && !unit->setting_protect &&
			   !unit->no_sneak) {
				if(roll_1Dx(100) > 10) unit->sneaking = 1;
			}
		}
	}
}

/**
 ** FULL_DAY_PROCESSING
 **	Process one complete day
 **/
static void full_day_processing(void)
{
location_s	*location, *sublocation;
unit_s		*unit;
order_s		*order, *next;
carry_s		*effect;
int		reloop;
/*
 * No market or location effect pending
 */
	for (location = location_list; location; location = location->next) {
		location->harvesting = 0;
		location->guarded = 0;
		location->patrolled = 0;
#ifdef REQUIRE_SPEEDUP
		location->speedup = 0;
#endif
		clean_markets(location);
	}
/*
 * Prepare units for the day
 */
	printf("Processing day %d\n", today_number);
	for (unit = unit_list; unit; unit = unit->next) {
		/* skip dead units */
		if (unit->dead) continue;
/*
 * No orders were executed (so far)
 */
		for (order = unit->orders; order; order = order->next) {
			order->considered = 0;
		}
		if(unit->orders)
			unit->faction->orders_execed = 1;
/*
 * Unit is not executing GUARD
 */
		unit->is_guarding = 0;
		/* Compute any special effects */
		if(unit->has_effects) {
			adjust_unit_effects(unit);
		}
		if(unit->escaping) unit->escaping--;
		if(unit->summoned) unit->summoned--;
		unit->full_day = 0;
		unit->intelligent = 0;
		unit->synchro = 0;
		unit->studying = 0;
		unit->has_recruited = 0;
		unit->wants_stay = 0;
		if (unit->setting_guard)
			unit->true_location->guarded = 1;
		if(unit->setting_guard || unit->setting_protect)
			unit->sneaking= 0;
		free_unit_teaching(unit);
	}
/*
 * Process immediate orders. No specific unit order is required here...
 */
	reloop = 1;
	while (reloop) {
		reloop = 0;
		for (unit = unit_list; unit; unit = unit->next) {
			if (unit->inactive  || unit->dead || unit->is_moving)
				continue;
			for (order = unit->orders; order; order = next) {
				next = order->next;
				if (!order->executing.full_day_order &&
				    !order->conditional &&
				    (!order->limit_low || (order->limit_low <= today_number && order->limit_high >= today_number)) &&
				    !order->considered &&
				    (*order->executing.routine)(unit, order)) {
					reloop = 1;
					break;
				}
/*
 * We do have something that was unexecuted, and but the next orders have
 * been dropped! Reloop
 */
				if (next && !next->executing.routine)
					next = unit->orders;
			}
		}
	}
/*
 * Process day orders.
 */
	if (today_number == 1) {
		for (location = location_list; location; location = location->next) {
			location->wages = 0;
			location->taxes = 0;
			location->entertainment = 0;
			location_harvest_tokens(location);
		}
		special_adjust_units();
	}
	for (location = location_list; location; location = location->next) {
/*
 * Tokens
 */
		if (location->type->type == TERRAIN_STRUCTURE)
			continue;
/*
 * Full-day orders
 */
		while (full_day_order_by_stack(location->present))
			;
		for (sublocation = location->inner; sublocation; sublocation = sublocation->next_inner)
			if (sublocation->type->type == TERRAIN_STRUCTURE)
				while (full_day_order_by_stack(sublocation->present))
					;
/*
 * Recruitment/Market/Harvest?
 */
		if (location->first_market)
			process_markets(location);
		if(location->pillaged) location->pillaged--;
	}
/*
 * Turn is done
 */
	for (unit = unit_list; unit; unit = unit->next) {
#ifdef USES_MANA_POINTS
carry_s		*power;
int		max_mana;
static terrain_s *cache_mcir;

		if(!cache_mcir) {
			synthetic_tag("mcir");
			cache_mcir = terrain_from_tag(0);
		}

#endif
/*
 * No orders were executed (so far)
 */
		for (order = unit->orders; order; order = order->next) {
			order->conditional += order->masked_conditional;
			order->masked_conditional = 0;
		}

		if (unit->inactive || unit->dead)
			continue;
		if (unit->has_effects)
			for (effect = unit->carrying; effect; effect = effect->next)
				if (effect->amount && effect->item->item_type == ITEM_DAYS)
					effect->amount--;

#ifdef USES_MANA_POINTS
/*
 * Mana changes?
 */
		compute_unit_stats(unit);
		max_mana = compute_max_mana(&unit->vital, &unit->bonus, unit->size);
		/*
		if ((max_mana = compute_max_mana(&unit->vital, &unit->bonus, unit->size)) == 0)
			continue;
		*/
		if ((power = unit->power) == 0)
			power = unit->power = unit_possessions(unit, item_mana, 1);
		if (power->amount < max_mana) {
			power->amount++;
			if(unit->current->type == cache_mcir)
				if(power->amount < max_mana)
					power->amount++;
		} else
			if (power->amount > max_mana)
				power->amount--;
#endif
	}
	observe_locations(today_number);
	check_victory();
}

void check_faction_dissolve(void)
{
faction_s	*faction;

	for (faction = faction_list; faction; faction = faction->next) {
		int growth = 0;
		if(faction->npc) continue;
		if(faction->new_fac) continue;
		if(!faction->orders_subbed) {
			growth++;
			if(!faction->orders_execed) growth++;
		}
		faction->dissolve += growth;
		if(faction->dissolve && growth) {
			int val = (10 - faction->dissolve)/growth;
			if((val <= 2) && (val > 0)) {
				faction_wide_event(faction, 30, "You are close to losing units due to neglect.");
			} else if(val <= 0) {
				faction_wide_event(faction, 30, "Your faction is suffering from neglect.");
			}
		}
	}
}
/**
 ** SPECIAL_ADJUST_FACTION
 **	Do the oath dance
 **/
void special_adjust_faction(void)
{
faction_s	*faction, *loop;
/*
 * Loop over all factions
 */
	for (faction = faction_list; faction; faction = faction->next) {
		faction->scratchpad[2] = 0;
	}
	for (faction = faction_list; faction; faction = faction->next) {
		if(faction->resigned) continue;
		for (loop = faction->vassal_of; loop; loop = loop->vassal_of) {
			if(loop->resigned) break;
			if (loop == faction) {
				printf("Beware!!! Oath loop for %s\n", loop->id.text);
				break;
			} else {
				loop->control_max += (USES_CONTROL_POINTS + faction->control_bonus) / 20;
				loop->scratchpad[2]++;
			}
		}
	}
}


/**
 ** FINAL_ADJUST_FACTION
 **	Control points increase
 **/
static void final_adjust_faction(void)
{
faction_s	*faction;
/*
 * Loop over all factions
 */
	for (faction = faction_list; faction; faction = faction->next) {
		faction->control_bonus += faction->scratchpad[0];
		if(faction->npc) continue;
		if(faction->units) {
			unit_s *unit;
                        char res = 2;
			for(unit = faction->units; unit; unit = unit->same_faction) {	
				if(unit->faction != faction) continue;
				if(unit->size != 0) {
					res = 0;
					break;
				}
			}
			if(!faction->resigned && res) faction->resigned = res;
		} else {
			faction->resigned = 2;
		}
		if(faction->resigned == 2) {
			if(faction->vassal_of) {
				sprintf(work, "%s [%s] renounced oath to us due to resigning.", faction->name, faction->id.text);
				faction_wide_event(faction->vassal_of, 30, work);
			}
		}
	}
}


/**
 ** SPECIAL_LOCATION_EVOLVES
 **	Do the oath dance
 **/
static void special_location_evolves(void)
{
location_s	*local;
resource_s	*res;
int		i;
int		found_recr, found_tax, found_ent;
/*
 * Loop over all factions
 */
	for (local = location_list; local; local = local->next) {
		found_recr = 0;
		found_tax = 0;
		found_ent = 0;
		i = local->population;
		if(i >= 0) {
			for (res=local->resources; res; res= res->next) {
				if (res->type == item_recruit) {
					res->amount = i / 24;
					found_recr = 1;
				}
				if (res->type == token_tax) {
					res->amount = i;
					found_tax = 1;
				}
				if (res->type == token_entertain) {
					res->amount = i;
					found_ent = 1;
				}
			}
			if(!found_recr) {
				res = location_has_resource(local, item_recruit, 1);
				res->amount = i/24;
			}
			if(!found_ent) {
				res = location_has_resource(local, token_entertain, 1);
				res->amount = i;
			}
			if(!found_tax && taxable_loc(local)) {
				res = location_has_resource(local, token_tax, 1);
				res->amount = i;
			}
		}
	}
}


/**
 ** ITEM_CACHING
 **	All these items are used regularly
 **/
static void item_caching(void)
{
	synthetic_tag("coin");
	item_cash = item_from_tag(1);
	synthetic_tag("mana");
	item_mana = item_from_tag(1);
	synthetic_tag("mage");
	magecraft = skill_from_tag(1);
	synthetic_tag("cmbt");
	combat_skill = skill_from_tag(1);
	synthetic_tag("recr");
	item_recruit = item_from_tag(1);
	synthetic_tag("toktaxe");
	token_tax = item_from_tag(1);
	synthetic_tag("tokente");
	token_entertain = item_from_tag(1);
	synthetic_tag("mstudy");
	item_mstudy = item_from_tag(1);
	synthetic_tag("camp");
	camp_race = race_from_tag(1);
	synthetic_tag("garr");
	garrison_race = race_from_tag(1);
	synthetic_tag("neucity");
	neutral_city = terrain_from_tag(1);
}

#if defined(USES_SKILL_LEVELS) && defined(SKILL_USE_POINTS)
static int count_stacked_mages(unit_s *unit)
{
    unit_s *s;
    experience_s *exp;
    int count = 0;
    if(!unit) return 0;
    for(s = unit->stack; s; s = s->next_location) {
        exp = unit_experiences(s, magecraft, 0);
        if(exp) count++;
	count += count_stacked_mages(s);
    }
    return count;
}

static int count_local_mages(location_s *loc)
{
    unit_s *unit;
    experience_s *exp;
    int count = 0;
    for(unit = loc->present; unit; unit = unit->next_location) {
        exp = unit_experiences(unit, magecraft, 0);
        if(exp) count++;
        count += count_stacked_mages(unit);
    }
    return count;
}

static int count_prisoners(unit_s *unit)
{
    unit_s *stack;
    int count = 0;
    for(stack = unit->stack; stack; stack = stack->next_location) {
        if(stack->is_captive) count++;
    }
    return count;
}

static int count_troops(unit_s *unit)
{
    carry_s *c;
    int troops = 0;
    if(unit->race->type == RACE_LEADER) troops++;
    for(c = unit->carrying; c; c = c->next) {
        if((c->item->item_type == ITEM_FOLLOWER) &&
           (c->item->equip_bonus.melee || c->item->equip_bonus.missile)) {
            troops += c->amount;
        }
    }
    return troops;
}

int escape_chance(unit_s *captor, int transfer)
{
   int troops = count_troops(captor);
   int prisoners = count_prisoners(captor);
   int required_troops = (prisoners * 5);
   if(!transfer) {
       if(troops >= required_troops) return 0;
       return ((required_troops-troops) * 20)/prisoners;
   } else {
       int base = 40;
       if(troops < required_troops) {
          base += ((required_troops-troops) * 20)/prisoners;
          if(base > 100) base = 100;
       } else {
          base -= ((troops - required_troops)*5);
          if(base < 0) base = 0;
       }
       return base;
   }
}

static void prisoner_escape_check(void)
{
    unit_s *unit, *overall_leader;
    int chance;
    for(unit = unit_list; unit; unit = unit->next) {
        if(!unit->is_captive) continue;
        if(unit->dead || unit->inactive) continue;
        if(unit->size == 0) continue;
        chance = escape_chance(unit->leader, 0);
        if(chance && (roll_1Dx(100) < chance)) {
            /* We have an escape! */
            sprintf(work, "Prisoner %s [%s] managed to escape", unit->name,
                    unit->id.text);
            unit_personal_event(unit->leader, 30, work);
            sprintf(work, "You managed to escape from %s [%s]",
                    unit->leader->name, unit->leader->id.text);
            unit_personal_event(unit, 30, work);
			unit->escaping = 2;
            overall_leader = unit->leader;
            while (overall_leader->leader)
                overall_leader = overall_leader->leader;
            unstack_unit(unit);
	    unit->is_moving = 0;
	    unit->toward = 0;
	    unit->already_moved = 0;
	    unit->move_for_days = 0;
	    unit->moving_by = 0;
            unit->next_location = overall_leader->next_location;
            overall_leader->next_location = unit;
        }
    }
}

static void zombie_decay_chance()
{
    static item_s *dzom, *lzom, *fzom;
    unit_s *unit;
    carry_s *carry;

    if(!dzom) {
        synthetic_tag("dzom");
        dzom = item_from_tag(0);
    }
    if(!lzom) {
        synthetic_tag("lzom");
        dzom = item_from_tag(0);
    }
    if(!fzom) {
        synthetic_tag("fzom");
        fzom = item_from_tag(0);
    }

    for(unit = unit_list; unit; unit = unit->next) {
        if(unit->dead || unit->inactive) continue;
        if(!unit->size) continue;
        if(!unit->carrying) continue;
        for(carry = unit->carrying; carry; carry = carry->next) {
            if(carry->item == dzom || carry->item == fzom ||
               carry->item == lzom) {
                int i, count = 0;
                for(i = 0; i < carry->amount; i++) {
                    if(roll_1Dx(100) < 1) count++;
                }
                if(count) {
                    sprintf(work, "%d %s [%s] rot away to nothing",
                            count, carry->item->name, carry->item->tag.text);
                    unit_personal_event(unit, 30, work);
                }
            }
        }
    }
}

static void unit_skill_discovery()
{
    static terrain_s *mtow_cache;
    unit_s *unit;
    experience_s *exp;
    skill_s *skill;
    int found, chance, roll;

    if(!mtow_cache) {
        synthetic_tag("mtow");
        mtow_cache = terrain_from_tag(0);
    }

    for(unit = unit_list; unit; unit = unit->next) {
        if(unit->dead || unit->inactive) continue;
        if(unit->size == 0) continue;
#ifdef PRISONERS_TAKEN
        if(unit->is_captive) continue;
#endif
	if(unit->race->type != RACE_LEADER) continue;

        /* Check if in a tower */
        found = 0;
        if(unit->current &&
           (unit->current->type == mtow_cache) &&
           (unit->current->present == unit)) {
            int mages = count_local_mages(unit->current);
            int dedication = 0;
			int numskills = 0;
			skill_s *tskills[50];

            chance = 2 + ((mages-1));
			roll = roll_1Dx(100);
			if(roll >= chance) {
				chance = 0;
			}

            /* determine dedication if any */
            for(exp = unit->skilled; exp && chance; exp = exp->next) {
                if (exp->effective && exp->skill->student) {
                        dedication = exp->skill->student;
                        break;
                }
            }
            for(skill = skills_list; skill && !found && chance; skill = skill->next) {
                if(!skill->specialist) continue;
                if(!skill->student && skill->type != 2) continue;
                if(skill->student && skill->student != dedication) continue;
                exp = unit_experiences(unit, skill, 0);
                if(exp) continue;
                exp = unit_experiences(unit, skill->required_skill, 0);
                if(!exp) continue;
                if(exp->level < skill->required_at_level) continue;
				tskills[numskills++] = skill;
				found = 1;
			}

			if(chance && found) {
				chance = roll_1Dx(numskills);
				skill = tskills[chance];

				sprintf(work, "Exposure to magical energies in the tower gives you insight into the basics of %s [%s]",
						skill->name, skill->tag.text);
				unit_personal_event(unit, 30, work);
				exp = unit_experiences(unit, skill, 1);
				exp->points++;
				exp->studied++;
				printf("%s [%s] [%s] randomly discovered %s [%s] due to mage tower. (chance=%d,roll=%d)\n",
						unit->name, unit->id.text, unit->faction->id.text,
						skill->name, skill->tag.text, 2+mages-1,roll);
            }
        }

        for(skill = skills_list; skill && !found; skill = skill->next) {
            if(!skill->specialist) continue;
            if(skill->student || skill->type == 2) continue; /* magic */
            exp = unit_experiences(unit, skill, 0);
            if(exp) continue;
            exp = unit_experiences(unit, skill->required_skill, 0);
            if(!exp) continue;
            if(exp->level < skill->required_at_level) continue;
            switch(exp->level - skill->required_at_level) {
                case 0: chance = 0; break;
                case 1: chance = 2; break;
                case 2: chance = 5; break;
                case 3: chance = 8; break;
                default: chance = 0;
            }
            if(!chance) continue;
			roll = roll_1Dx(100);
            if(roll < chance) {
                sprintf(work, "Experience with %s [%s] has shown you the basics of %s [%s]",
                        exp->effective->name, exp->effective->tag.text,
                        skill->name, skill->tag.text);
                unit_personal_event(unit, 30, work);
                printf("%s [%s] [%s] randomly discovered %s [%s] due to %s [%s]. (chance=%d,roll=%d)\n",
                       unit->name, unit->id.text, unit->faction->id.text,
                       skill->name, skill->tag.text, exp->effective->name,
                       exp->effective->tag.text, chance,roll);
                exp = unit_experiences(unit, skill, 1);
                exp->points++;
                exp->studied++;
                found = 1;
            }
        }
    }
}
#endif

/**
 ** MAIN
 **	Entry point for the turn processor
 **/
int main(int argc, char **argv)
{
faction_s	*faction;
int		day_per_month = 30;
/*
 * How many days? Default to 30
 */
	if (argc > 1)
		day_per_month = atoi(argv[1]);
	if (day_per_month < 0)
		day_per_month = 30;
	load_game_info();
	if(!seed) {
	    seed = time(0);
	}
	srand48(seed);
/*
 * Turn processor begins in the game directory
 */
	printf("Now processing game turn %d -- seed %d\n", game_turn_number,
	       seed);
	save_game_info();
/*
 * We now have locked the game turn. Load all info
 */
	load_items();
	printf("items loaded...\n");
	load_skills();
	printf("skills loaded...\n");
	load_races();
	printf("races loaded...\n");
	load_factions();
	printf("factions loaded...\n");
	load_locations();
	printf("locations loaded...\n");
	load_units();
	printf("units loaded...\n");
/*
 * Global values
 */
	adjust_items();
	adjust_factions();
	adjust_units();
	adjust_locations();
	item_caching();
	special_location_evolves();
/***HACK***/
	compute_control_points();
	special_adjust_faction();

	load_orders();
	printf("orders loaded...\n");

	for (faction = faction_list; faction; faction = faction->next) {
		faction->scratchpad[0] = 1;
		faction->scratchpad[1] = 1;
	}
/*
 * Process the turn. Yikes!
 */
	today_number = 1;
	if (day_per_month > 0)
		full_day_processing();
/***HACK***/
	while (today_number < day_per_month) {
		today_number++;
		full_day_processing();
	}
/*
 * Do the final accounting
 */
#if defined(USES_SKILL_LEVELS) && defined(SKILL_USE_POINTS)
	unit_skill_discovery();
#endif
	prisoner_escape_check();
	zombie_decay_chance();
	if (day_per_month > 1)
		compute_upkeep();
	check_faction_dissolve();
	all_pay_upkeep();
	final_adjust_faction();
	compute_control_points();
	artifact_homing();
	special_adjust_faction();
	location_evolves();
	special_location_evolves();
/*
 * Turn is done. Now, generate the reports
 */
	create_reports();
	cleanup_locations();
	cleanup_units();
/*
 * Save the databases
 */
	save_game_info();
	save_factions();
	save_units();
	save_locations();
	return 0;
}
