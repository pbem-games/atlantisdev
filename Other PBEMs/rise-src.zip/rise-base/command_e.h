/* $Id: command_e.h,v 1.3 2000/06/14 07:30:46 jtraub Exp $
 *	Command argument strings
 */

extern char		movement_modes[];
extern char		stance_arguments[];
extern char		participate_modes[];
extern char		battlefield_ranks[];
extern char		battlefield_files[];
extern char		battlefield_moves[];
extern char		possible_settings[];
#define battle_arguments	participate_modes
#define rank_arguments		battlefield_ranks
#define file_arguments		battlefield_files
#define move_arguments		battlefield_moves

#define ARGUMENT_IS_ENUM_0		(ARGUMENT_IS_COMBAT_TARGET+1)
#define ARGUMENT_IS_ENUM_1		(ARGUMENT_IS_ENUM_0+1)
extern char		order_enum_0[];
extern char		order_enum_1[];

#define UNIT_SETTING_ANNOUNCE	0
#define UNIT_SETTING_GUARD	1
#define UNIT_SETTING_HTML	2
#define UNIT_SETTING_MISER	3
#define UNIT_SETTING_PROTECT	4
#define UNIT_SETTING_SILENT	5
#define UNIT_SETTING_SUPPORT	6
#define UNIT_SETTING_TERSE	7
#define UNIT_SETTING_HUSHGIVE	8

#define COMBAT_SET_DEFAULT	0
#define COMBAT_SET_ONCE		1
#define COMBAT_SET_MELEE	2
#define COMBAT_SET_RANGED	3
#define COMBAT_SET_GUARD	4
#define COMBAT_SET_SKILL	5
#define COMBAT_SET_ITEM		6
#define COMBAT_SET_RELOAD	7
#define COMBAT_SET_RESTRIKE	8
#define COMBAT_SET_RESHOOT	9
