/* $Id: fx.c,v 1.114 2001/01/12 20:20:11 jtraub Exp $
 *	Special effects here
 */
#include "turn.h"
#include "fx.h"
#include "parser.h"
#include "battle.h"
#include "command_u.h"
#include "enumstxt.h"
#include "location.h"


/**
 ** Special type
 **/
typedef int	(*suitable_locale)(location_s *);
typedef int	(*resource_valid)(item_s *);
typedef int	(*unit_search)(unit_s *, unit_s *, int);

typedef struct _searchlink {
    location_s *loc;
    int cost;
    struct _searchlink *next;
} searchlink;

/**
 ** Private variables
 **/
static item_s *targeted_item;
static terrain_s *target_terrain;


/**
 ** MATCH_RESOURCE
 **	Simple resource comparator
 **/
static int match_resource(location_s *here)
{
    resource_s	*items;
    for (items = here->resources; items; items = items->next)
	if (items->type == targeted_item && items->amount) return 1;
    return 0;
}

static int match_inner_loc(location_s *here)
{
    if(here->type->type == TERRAIN_INNER) return 1;
    return 0;
}

static int match_terrain(location_s *here)
{
	if(here->type == target_terrain) return 1;
	return 0;
}

static int planar_distance(location_s *newloc, location_s *loc) 
{
	int plane = newloc->region;
	int t, xd, yd, xw, yw;

	xw = wrap_x(plane);
	yw = wrap_y(plane);
	if(xw) {
		xd = (newloc->x - loc->x);
		if(xd < 0) xd = xw - xd;
		t = (loc->x - newloc->x);
		if(t < 0) t = xw - t;
		if(t < xd)
			xd = t;
	} else {
		if (newloc->x > loc->x)
			xd = newloc->x - loc->x;
		else
			xd = loc->x - newloc->x;
	}
	if(yw) {
		yd = (newloc->y - loc->y);
		if(yd < 0) yd = yw - yd;
		t = (loc->y - newloc->y);
		if(t < 0) t = yw - t;
		if(t < yd)
			yd = t;
	} else {
		if (newloc->y > loc->y)
			yd = newloc->y - loc->y;
		else
			yd = loc->y - newloc->y;
	}

	t = xd & 1;
	xd *= 2;
	yd *= 2;

	if(t) {
		if(newloc->x & 1) yd--;
		else yd++;
	}
	xd = abs(xd);
	yd = abs(yd);

	if(xd >= yd*2) {
		t = xd;
	} else {
		t = xd/2 + yd;
	}
	t /= 2;

	return t;
}

static void wipe_search(searchlink *searches)
{
    searchlink *t;
    location_s *l;
    while(searches) {
		t = searches->next;
		free(searches);
		searches = t;
    }

    /* Also need to wipe out any marks in the locations */
    for(l = location_list; l; l = l->next) {
		l->been = 0;
    }
}

static void insert_search(searchlink **head, location_s *loc, int cost)
{
    searchlink *elem;

    if(loc->been) return;
   
    elem = (searchlink *)malloc(sizeof(searchlink));
    elem->cost = cost;
    elem->loc = loc;
    elem->loc->been = 1;

    while(*head && (*head)->cost < elem->cost) head = &(*head)->next;
    elem->next = *head;
    *head = elem;
}

static int search_for_location(location_s *start, suitable_locale check,
			       location_s **found)
{
    searchlink *searches = NULL, *s;
    int stop = 0, days = -1;

    /* Null out the best found */
    *found = NULL;

    /* insert the starting location */
    insert_search(&searches, start, 0);

    while(searches && !stop) {
		/* Take the top item */
		s = searches;
		searches = s->next;

		/* Check it */
		if ((*check)(s->loc)) {
			*found = s->loc;
			days = s->cost;
			stop = 1;
		} else {
			location_s *i;
			direction_s *dir;
			int cost;
			/* This isn't it, we need to enqueue the options */

			/* Inners first, they have cost 0 or 1 */
			for(i = s->loc->inner; i; i = i->next_inner) {
				cost = s->cost;
				if(i->type->type == TERRAIN_INNER) cost++;
				insert_search(&searches, i, cost);
			}
			/* And our outer */
			i = s->loc->outer;
			if(i) {
				cost = s->cost;
				if(s->loc->type->type == TERRAIN_INNER) cost++;
				insert_search(&searches, i, cost);
			}
			/* And any exits we have */
			for (dir = s->loc->exits; dir; dir = dir->next) {
				if(dir->days < 0) continue;
				insert_search(&searches, dir->toward, s->cost + dir->days);
			}
		}
		free(s);
	}

    /* Wipe the search list */
    wipe_search(searches);

    /* Return our best find */
    return days;

}

int fx_equipped_on_unit(unit_s *unit, int fx)
{
	carry_s *owns;
	for(owns = unit->carrying; owns; owns = owns->next) {
		if(owns && owns->amount && owns->equipped &&
				owns->item->special_effects == fx)
			return 1;
	}
	return 0;
}

/**
 ** FX_AVAILABLE_IN_STACK
 **	One unit has the skill, or the object, or whatever it takes
 **/
static int fx_available_in_stack(unit_s *stack, faction_s *faction, int fx)
{
carry_s		*owns;
experience_s	*knows;
/*
 * Loop on stack
 */
	while (stack) {
		if (faction == 0 || stack->faction == faction) {
			for (owns = stack->carrying; owns; owns = owns->next)
				if (owns->item->special_effects == fx)
					return 1;
			for (knows = stack->skilled; knows; knows = knows->next)
				if (knows->effective && knows->effective->special_effects == fx)
					return 1;
			if (fx_available_in_stack(stack->stack, faction, fx))
				return 1;
		}
		stack = stack->next_location;
	}
	return 0;
}


/**
 ** FX_AVAILABLE_HERE_FOR
 **	One unit has the skill, or the object, or whatever it takes
 **/
int fx_available_here_for(location_s *here, faction_s *faction, int fx)
{
location_s	*structures;
/*
 * First, check main
 */
	if (fx_available_in_stack(here->present, faction, fx))
		return 1;
	for (structures = here->inner; structures; structures = structures->next_inner)
		if (fx_available_in_stack(structures->present, faction, fx))
			return 1;
	return 0;
}


/**
 ** FX_INCREASE_RESOURCES
 **	Resource increases
 **/
static void fx_increase_resources(location_s *local, item_s *item, int amount)
{
resource_s	*that;
resource_s	*prev;
/*
 * Scan for resources
 */
	prev = 0;
	for (that = local->resources; that; that = that->next)
		if (that->type == item)
			break;
		else
			prev = that;
/*
 * New resource?
 */
	if (!that) {
		that = new_resource_instance();
		that->type = item;
		if (prev)
			prev->next = that;
		else
			local->resources = that;
	}
	that->amount += amount;
	that->remains += amount * that->type->token_multiplier;
}

static int search_stacked_units(unit_s *searcher, unit_s *unit,
				unit_search func, char *fmt, char *detect,
				int val)
{
    unit_s *u;
    int count = 0;
    if(!unit) return count;
    for(u = unit->stack; u; u = u->next_location) {
        if((*func)(searcher, u, val)) {
            count++;
            sprintf(work, fmt, u->name, u->id.text);
            unit_personal_event(searcher, today_number, work);
            if(detect)
               unit_personal_event(u, today_number, detect);
        }
        count += search_stacked_units(searcher, u, func, fmt, detect, val);
    }
    return count;
}

static int search_local_units(unit_s *searcher, location_s *loc,
			      unit_search func, char *fmt, char *detect,
			      int val)
{
    unit_s *u;
    int count = 0;
    for(u = loc->present; u; u = u->next_location) {
        if((*func)(searcher, u, val)) {
            count++;
            sprintf(work, fmt, u->name, u->id.text);
            unit_personal_event(searcher, today_number, work);
            if(detect)
                unit_personal_event(u, today_number, detect);
        }
        count += search_stacked_units(searcher, u, func, fmt, detect, val);
    }
    return count;
}

/********************************* FX ROUTINES *******************************/

#ifdef FX_SEARCH
int search_unit(unit_s *searcher, unit_s *subject, int val)
{
    if(searcher == subject) return 0;
    if(roll_1Dx(100) < val) {
        subject->no_sneak = 1;
        return 1;
    }
    return 0;
}

static void fx_search(unit_s *unit, skill_s *effective)
{
	location_s *loc = unit->true_location;
	static skill_s *search_cache;
	skill_s *p;
        int count;
	int val, level;

	if(!search_cache) {
	    synthetic_tag("srch");
	    search_cache=skill_from_tag(0);
	}

	p = search_cache;
	while(p && p != effective) {
		level++;
		p = p->next_level;
	}
	if(!p) return;

	val = 20 + (level-1)*5;

	if(loc != unit->current) {
		unit_personal_event(unit, today_number, "Searching is only effective while outdoors");
		return;
	}

	count = search_local_units(unit, loc, search_unit,
                           "Your search reveals %s [%s] in the vicinity.",
                           "A search of the area has revealed your presence.",
			   val);
        if(!count) {
            unit_personal_event(unit, today_number,
				"Your search turns up nothing.");
        }
}
#endif

#ifdef FX_TALE_BONES
static void fx_tale_bones(unit_s *unit)
{
	location_s *target;
	direction_s *dir;
	int count;
	int num;
	char buf[200];

	if(unit->target_type != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Unable to find that location to tell a tale about.");
		return;
	}
	target = unit->target.location;
	while(target->outer) target = target->outer;

	count = 1;
	for(dir = target->exits; dir; dir = dir->next) {
		count++;
	}
	num = roll_1Dx(count);
	if(num) {
		for(dir = target->exits; dir && num; dir = dir->next, num--)
			target = dir->toward;
	}

	if(target->region) {
		sprintf(buf, " <%s>", visual_enum(target->region, regions));
	} else {
		strcpy(buf, "");
	}
	sprintf(work, "You gain a tale of the bones about %s%s [%s] (%d, %d).",
			target->name, buf, target->id.text, target->x, target->y);
	unit_personal_event(unit, today_number, work);
	for(num = today_number; num < 32; num++) {
		observer_present(unit, target, num);
	}
}
#endif

struct struct_neighbor {
	direction_s *dir;
    int dist;
};
typedef struct struct_neighbor neighbor_s;

static int check_capacity(unit_s *mover, int mode)
{
	if(mover->weight < mover->capacity[mode]) return 0;
	return (mover->weight - mover->capacity[mode]);
}

static location_s *move_nearest_neighbor(unit_s *mover, location_s *target)
{
	location_s *thex = target;
	location_s *lhex = mover->current;
	location_s *nhex;
	neighbor_s neighs[10];
	direction_s *dir;
	int dist, i;
	location_s *dest = NULL;
	int need_retreat = 0;
	int need_move = 1;
	int drop_stuff = 0;
	carry_s *carry;
	order_s *order;
	int mode;
	static command_s *cmd_retreat;
	static command_s *cmd_move;
	command_s *cmd;

	if(!cmd_retreat) {
		for(cmd = valid_orders; cmd->keyword; cmd++) {
			if(strcasecmp(cmd->keyword, "retreat")) continue;
			cmd_retreat = cmd;
			break;
		}
	}
	if(!cmd_move) {
		for(cmd = valid_orders; cmd->keyword; cmd++) {
			if(strcasecmp(cmd->keyword, "march")) continue;
			cmd_move = cmd;
			break;
		}
	}


	/* okay, we need to do a bit of finagling if the mover is already moving */
	if(mover->is_moving) {
		if(mover->already_moved <= (mover->move_for_days/2)) {
			need_retreat = 1;
		}
	}

	for(i = 0; i < 10; i++) {
		neighs[i].dir = NULL;
		neighs[i].dist = -1;
	}

	/* Okay, check outter and inner */
	if(need_retreat && thex == lhex) {
		need_move = 0;
		dest = thex;
	}

	if(need_move) {
		while(thex->outer) thex = thex->outer;
		while(lhex->outer) lhex = lhex->outer;
		if(thex == lhex) {
			/* we need to check inners/outers */
			thex = target;
			lhex = mover->current;
			nhex = lhex->outer;
			while(nhex) {
				if(nhex == thex) break;
				nhex = nhex->outer;
			}
			if(nhex) {
				dest = lhex->outer;
				drop_stuff = check_capacity(mover, 0);
				mode = 0;
			}

			if(!dest) {
				for(nhex = lhex->inner; nhex && !dest; nhex=nhex->next_inner) {
					if((nhex == thex) || (nhex == thex->outer)) {
						dest = nhex;
						drop_stuff = check_capacity(mover, 0);
						mode = 0;
					}
				}
			}
		} else {
			/* If they are on different planes, fail */
			if(thex->region != lhex->region) return NULL;
			i = 0;
			/* check all the exits in the same plane */
			for(dir = lhex->exits; dir; dir = dir->next) {
				if(dir->toward->region == thex->region) {
					experience_s *exp;
					dist = dir->mode;
					if(!mover->capacity[dist]) continue;
					if(dir->skill)
						exp = unit_experiences(mover, dir->skill, 0);
					if(dir->skill && !exp) continue;
					if(exp && (exp->level > dir->level)) continue;
					neighs[i].dir = dir;
					neighs[i].dist = planar_distance(thex, dir->toward);
					i++;
				}
			}
			dist = 9999999;
			for(i = 0; i < 10; i++) {
				if(neighs[i].dist != -1) {
					if(neighs[i].dist < dist)
						dist = neighs[i].dist;
				}
			}
			if(dist == 9999999) {
				return NULL;
			}
			for(i = 0; i < 10 && !dest; i++) {
				if(neighs[i].dist == dist) {
					dest = neighs[i].dir->toward;
					mode = neighs[i].dir->mode;
					drop_stuff = check_capacity(mover, mode);
				}
			}
		}
	}

	if(!dest)
		return NULL;

	/* enter the move and retreat */
	if(drop_stuff) {
		int carried = 0;
		int n;
		for(carry = mover->carrying; carry; carry= carry->next) {
			carry->contributed = 0;
			if(carry->item->capacity[mode]) continue;
			if(carry->amount && carry->item->weight)
				carried += carry->amount;
		}

		/* randomly drop stuff */
		while(drop_stuff > 0 && carried) {
			int stop = 0;
			n = roll_1Dx(carried);
			for(carry = mover->carrying; carry && !stop; carry = carry->next) {
				if(carry->item->capacity[mode]) continue;
				if(carry->amount && carry->item->weight)
					n -= carry->amount;
				if(n >= 0) continue;
				carry->amount--;
				carry->contributed++;
				carried--;
				stop = 1;
				drop_stuff -= carry->item->weight;
			}
		}

		if(drop_stuff) {
			carried = 0;
			for(carry = mover->carrying; carry; carry= carry->next) {
				if(carry->item->capacity[mode] < carry->item->weight) continue;
				if(carry->amount && carry->item->weight)
					carried += carry->amount;
			}
			while(drop_stuff > 0 && carried) {
				int stop = 0;
				n = roll_1Dx(carried);
				for(carry = mover->carrying; carry && !stop; carry = carry->next) {
					if(carry->item->capacity[mode] < carry->item->weight)
						continue;
					if(carry->amount && carry->item->weight)
						n -= carry->amount;
					if(n >= 0) continue;
					carry->amount--;
					carry->contributed++;
					carried--;
					stop = 1;
					drop_stuff -= (carry->item->weight - carry->item->capacity[mode]);
				}
			}
		}
		compute_unit_stats(mover);
		/* Now report what got dropped */
		for(carry = mover->carrying; carry; carry = carry->next) {
			if(carry->contributed) {
				sprintf(work, "Dropped %d %s [%s] in order to move.",
						carry->contributed,
						(carry->contributed > 1 ? carry->item->plural : carry->item->name),
						carry->item->tag.text);
				unit_personal_event(mover, today_number, work);
				carry->contributed = 0;
			}
		}
	}

	if(need_move) {
		unit_s *stack = mover->stack, *next;
		/* Make sure we are not being led */
		if(mover->leader) {
			sprintf(work,  "%s [%s] unstacks.", mover->name, mover->id.text);
			(void)execute_unstack(mover, 0);
		}

		/* Eject all of our stack */
		while(stack) {
			next = stack->next_location;
			sprintf(work, "%s [%s] unstacked because %s [%s] rushes off.",
					stack->name, stack->id.text, mover->name, mover->id.text);
			(void)execute_unstack(stack, 0);
			stack = next;
		}
		order = new_order_instance();
		order->executing = *cmd_move;
		order->arguments[0].location = dest;
		order->executing.types[0] = ARGUMENT_IS_LOCATION_ID;
		order->next = mover->orders;
		mover->orders->prev = order;
		mover->orders = order;
		mover->summoned = 2;
	}
	if(need_retreat) {
		order = new_order_instance();
		order->executing = *cmd_retreat;
		order->next = mover->orders;
		mover->orders->prev = order;
		mover->orders = order;
	}
	return dest;
}

#ifdef FX_ILLUSION_TORTURED_ALLY
static void fx_illusion_tortured_ally(unit_s *unit)
{
    unit_s *target;
    int base;
    int allies;
	faction_s *list;
	stance_s *stance;
	location_s *move;

    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No such unit to give an illusion.");
        return;
    }
    target = unit->target.unit;
    if(target->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "The unit you wish to give the illusion to has no leader.");
		return;
    }

    sprintf(work, "You send an illusion to %s [%s].", target->name,
	    target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You recieve an image of %s [%s] torturing one of your allies", unit->name,
			unit->id.text);
    unit_personal_event(target, today_number, work);

    base = 10;
    allies = 0;
	for(list = faction_list; list; list = list->next) {
		list->scratchpad[7] = 0;
	}
	target->faction->scratchpad[7] = 1;
	for(list = faction_list; list; list = list->next) {
		if(list != target->faction) {
			if(attitude_vs_faction(target->faction, list) == ATTITUDE_IS_ALLY) {
				list->scratchpad[7] = 1;
				allies++;
			}
		}
	}
	for(stance = target->faction->stances; stance; stance = stance->next) {
		if(stance->unit) {
			if(stance->unit->faction->scratchpad[7] == 0) {
				stance->unit->faction->scratchpad[7] = 1;
				allies++;
			}
		}
	}

	
    base = base + allies;
    allies = roll_1Dx(100);
    if(allies >= base) {
		sprintf(work, "%s [%s] resists your illusion.", target->name,
				target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the vision sent by %s [%s]", unit->name,
				unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
	}
	/* Make target move toward caster */
	move = move_nearest_neighbor(target, unit->true_location);

	if(!move) {
		sprintf(work, "%s [%s] resists your illusion.", target->name,
				target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the vision sent by %s [%s]", unit->name,
				unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
	}

	sprintf(work, "%s [%s] moves toward you to save his ally.",
			target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "You learn of %s [%s] torturing your ally and moves toward %s [%s] to try and save them",
			unit->name, unit->id.text, move->name, move->id.text);
	unit_personal_event(target, today_number, work);
	printf("%s [%s] [%s] used tortured ally illusion -- %d/%d chance!\n",
			unit->name, unit->id.text, unit->faction->id.text, allies,
			base);
	/*
	sprintf(work, "%s [%s] resists your illusion.", target->name,
			target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "You resist the vision sent by %s [%s]", unit->name,
			unit->id.text);
	unit_personal_event(target, today_number, work);
    return;
	*/
}
#endif

#ifdef FX_HYPNOTIC_CALL
static void fx_hypnotic_call(unit_s *unit)
{
    unit_s *target;
    int base;
    int vassals;
	faction_s *list, *loop, *tfac;
	location_s *move;

    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No such unit to hypnotically call.");
        return;
    }
    target = unit->target.unit;
    if(target->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "The unit you wish to hypnotize has has no leader able to be charmed.");
		return;
    }

    sprintf(work, "You send a hypnotic summons to %s [%s].", target->name,
	    target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You feel %s [%s] calling you hypnotically", unit->name,
			unit->id.text);
    unit_personal_event(target, today_number, work);

	tfac = target->faction;
    base = 10;
    vassals = 0;
	for(list = faction_list; list; list = list->next) {
		for(loop = list->vassal_of; loop; loop = loop->vassal_of) {
			if(loop == list) break;
			else if(loop == tfac) vassals++;
		}
	}
    base = base + vassals;
    vassals = roll_1Dx(100);
    if(vassals >= base) {
		sprintf(work, "%s [%s] resists your hypnotic call.", target->name,
				target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the hypnotic call of %s [%s]", unit->name,
				unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
	}
	/* Make target move toward caster */
	move = move_nearest_neighbor(target, unit->true_location);
	if(!move) {
		sprintf(work, "%s [%s] resists your hypnotic call.", target->name,
				target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the hypnotic call of %s [%s]", unit->name,
				unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
	}

	sprintf(work, "%s [%s] is hypnotized and moves toward you.",
			target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "You are hypnotized by %s [%s] and moves toward %s [%s]",
			unit->name, unit->id.text, move->name, move->id.text);
	unit_personal_event(target, today_number, work);

	printf("%s [%s] [%s] used hypnotic call -- %d/%d chance!\n",
			unit->name, unit->id.text, unit->faction->id.text, vassals,
			base);
	/*
	sprintf(work, "%s [%s] resists your hypnotic call.", target->name,
			target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "You resist the hypnotic call of %s [%s]", unit->name,
			unit->id.text);
	unit_personal_event(target, today_number, work);
    return;
	*/
}
#endif

#ifdef FX_CALL_TO_BATTLE
static void fx_call_to_battle(unit_s *unit)
{
    unit_s *target;
    int base;
    int followers;
    carry_s *carry;
	location_s *move;

    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No such unit to call to battle.");
        return;
    }
    target = unit->target.unit;
    if(target->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "The unit you wish to fight has no leader noble enough to take up the challenge.");
		return;
    }

    sprintf(work, "You summon %s [%s] to the field of battle.", target->name,
	    target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You were summoned to the field of battle by %s [%s]",
	    unit->name, unit->id.text);
    unit_personal_event(target, today_number, work);

    if(attitude_vs(target->faction, unit) < ATTITUDE_IS_HOSTILE) {
		sprintf(work,  "%s [%s] does not hate you enough to fight you.",
				target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You do not hate %s [%s] enough to fight.",
				unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
    }

    base = 10;
    followers = 0;
    for(carry = target->carrying; carry; carry = carry->next) {
		if(carry->amount && carry->item->item_type == ITEM_FOLLOWER)
			followers += carry->amount;
    }
    base = base + followers/2;
    followers = roll_1Dx(100);
    if(followers >= base) {
		sprintf(work, "%s [%s] decides to ignore your challenge.",
				target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the urge to go fight %s [%s]",
				unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
    }
	/* Make target move toward caster */
	move = move_nearest_neighbor(target, unit->true_location);
	if(!move) {
		sprintf(work, "%s [%s] decides to ignore your challenge.",
				target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "You resist the urge to go fight %s [%s]",
				unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		return;
	}

	sprintf(work, "%s [%s] accepts your challenge and moves toward you.",
			target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work,
			"You are so angered by %s [%s]'s challenge that you move toward %s [%s] to find him",
			unit->name, unit->id.text, move->name, move->id.text);
	unit_personal_event(target, today_number, work);

    printf("%s [%s] [%s] used call to battle -- %d/%d chance!\n",
	    unit->name, unit->id.text, unit->faction->id.text, followers,
	    base);
	/*
    sprintf(work, "%s [%s] decides to ignore your challenge.",
	    target->name, target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You resist the urge to go fight %s [%s]",
	    unit->name, unit->id.text);
    unit_personal_event(target, today_number, work);
    return;
	*/
}
#endif

static location_s *planar_loc(int plane, int distance, location_s *loc,
		char perm, char from_plane)
{
	int count = 0;
	location_s *newloc;

	for(newloc = location_list; newloc; newloc = newloc->next) {
		if(newloc->region != plane) continue;
		if(!newloc->type->solid) continue;
		if(loc) {
			int dist = planar_distance(newloc, loc);
			if(dist >= distance) continue;
			if(perm) {
				direction_s *dir;
				char bad = 0;
			    for(dir = newloc->exits; dir; dir = dir->next) {
					if(dir->toward->region == from_plane) {
						bad = 1;
						break;
					}
				}
				if(bad) continue;
			}
		}
		count++;
	}

    if(!count) {
		return NULL;
	}

	count = roll_1Dx(count);
	for(newloc = location_list; newloc; newloc = newloc->next) {
		if(newloc->region != plane) continue;
		if(!newloc->type->solid) continue;
		if(loc) {
			int dist = planar_distance(newloc, loc);
			if(dist >= distance) continue;
			if(perm) {
				direction_s *dir;
				char bad = 0;
			    for(dir = newloc->exits; dir; dir = dir->next) {
					if(dir->toward->region == from_plane) {
						bad = 1;
						break;
					}
				}
				if(bad) continue;
			}
		}
		if(!count--) break;
	}
	return newloc;
}

static int fx_gate(unit_s *unit, int plane)
{
    int distance = 20;
    location_s *loc, *newloc, *real;
	direction_s *dir;
	static terrain_s *cache_mcir;

	if(!cache_mcir) {
		synthetic_tag("mcir");
		cache_mcir = terrain_from_tag(0);
	}

    if (unit->target_type != ARGUMENT_IS_LOCATION_ID &&
			unit->target_type != ARGUMENT_IS_EMPTY) {
		unit_personal_event(unit, today_number,
				"That is not a valid location to travel to.");
		return 0;
	}
	loc = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(loc) {
		if(loc->region != plane) {
			unit_personal_event(unit, today_number,
					"That location is not in the right plane.");
			return 0;
		}
	}
	real = unit->true_location;

	if(unit->current->type == cache_mcir) {
		distance /= 10;
	}

    newloc = planar_loc(plane, distance, loc, 1, real->region);

    if(!newloc) {
		printf("%s [%s] [%s] tried to build planar gate and couldn't!\n",
				unit->name, unit->id.text, unit->faction->id.text);
		sprintf(work, "No viable location on the target plane!");
		unit_personal_event(unit, today_number, work);
		return 0;
	}

	sprintf(work, "%s [%s] builds a gate to the plane of %s", unit->name,
			unit->id.text, visual_enum(plane, regions));
	location_visible_event(unit->current, today_number, work);

    sprintf(work, "You build a gate to %s [%s] (%d, %d) in the plane of %s",
			newloc->name, newloc->id.text, newloc->x, newloc->y,
			visual_enum(plane, regions));
	unit_personal_event(unit, today_number, work);

    sprintf(work, "A gateway leading to the plane of %s appears.",
			visual_enum(real->region, regions));
    location_visible_event(newloc, today_number, work);

	/* Actually build the gate */
	dir = new_direction_from_location();
	dir->toward = newloc;
	dir->mode = 0;
	dir->days = 26 + roll_1Dx(5);
	dir->name = strdup(visual_enum(plane, regions));
	dir->next = real->exits;
	real->exits = dir;

	/* And the gate back */
	dir = new_direction_from_location();
	dir->toward = real;
	dir->mode = 0;
	dir->days = 26 + roll_1Dx(5);
	dir->name = strdup(visual_enum(real->region, regions));
	dir->next = newloc->exits;
	newloc->exits = dir;
    return 1;
}

static int fx_sendself(unit_s *unit, int plane)
{
	int distance = 60;
	location_s *loc, *newloc;
	unit_s *stack, *next;
	static terrain_s *cache_mcir;

	if(!cache_mcir) {
		synthetic_tag("mcir");
		cache_mcir = terrain_from_tag(0);
	}

	if (unit->target_type != ARGUMENT_IS_LOCATION_ID &&
			unit->target_type != ARGUMENT_IS_EMPTY) {
		unit_personal_event(unit, today_number,
				"That is not a valid location to travel to.");
		return 0;
	}
	loc = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(loc) {
		if(loc->region != plane) {
			unit_personal_event(unit, today_number,
					"That location is not in the right plane.");
			return 0;
		}
	}

	if(unit->current->type == cache_mcir) {
		distance /= 10;
	}

	newloc = planar_loc(plane, distance, loc, 0, 0);

	if(!newloc) {
		printf("%s [%s] [%s] sent himself plane hopping and couldn't!\n",
				unit->name, unit->id.text, unit->faction->id.text);
		sprintf(work, "No viable location on the target plane!");
		unit_personal_event(unit, today_number, work);
		return 0;
	}

	sprintf(work, "%s [%s] disappears in a flash of eerie light", unit->name,
			unit->id.text);
	location_visible_event(unit->current, today_number, work);

	stack = unit->stack;
	while(stack) {
		next = stack->next_location;
		execute_unstack(stack, NULL);
		stack = next;
	}
	unit->stack = NULL;

	unstack_unit(unit);
	move_to_location(unit, newloc);
	sprintf(work,
			"You transport yourself to %s [%s] (%d, %d) in the plane of %s",
			newloc->name, newloc->id.text, newloc->x, newloc->y,
			visual_enum(plane, regions));
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%s [%s] appears in a flash of eerie light", unit->name,
			unit->id.text);
	location_visible_event(newloc, today_number, work);
	return 1;
}

static int fx_sendother(unit_s *unit, int plane)
{
	int distance = 60;
	location_s *loc, *newloc;
	unit_s *target = unit->stack;
	unit_s *stack, *next;
	static terrain_s *cache_mcir;

	if(!cache_mcir) {
		synthetic_tag("mcir");
		cache_mcir = terrain_from_tag(0);
	}

	if(!target) return 0;

	if (unit->target_type != ARGUMENT_IS_LOCATION_ID &&
			unit->target_type != ARGUMENT_IS_EMPTY) {
		unit_personal_event(unit, today_number,
				"That is not a valid location to travel to.");
		return 0;
	}
	loc = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(loc) {
		if(loc->region != plane) {
			unit_personal_event(unit, today_number,
					"That location is not in the right plane.");
			return 0;
		}
	}

	if(unit->current->type == cache_mcir) {
		distance /= 10;
	}

	newloc = planar_loc(plane, distance, loc, 0, 0);

	if(!newloc) {
		printf("%s [%s] sent %s [%s] [%s] plane hopping and couldn't!\n",
				unit->name, unit->faction->id.text, unit->stack->name,
				unit->stack->id.text, unit->stack->faction->id.text);
		sprintf(work, "No viable location on the target plane!");
		unit_personal_event(unit, today_number, work);
		return 0;
	}

	sprintf(work, "%s [%s] disappears in a flash of eerie light",
			target->name, target->id.text);
	location_visible_event(unit->current, today_number, work);

	stack = target->stack;
	while(stack) {
		next = stack->next_location;
		execute_unstack(stack, NULL);
		stack = next;
	}
	target->stack = NULL;

	unstack_unit(target);
	move_to_location(target, newloc);
	sprintf(work, "You transport %s [%s] to the plane of %s", target->name,
			target->id.text, visual_enum(plane, regions));
	unit_personal_event(unit, today_number, work);
	sprintf(work,
			"%s [%s] transports you to %s [%s] (%d, %d) in the plane of %s",
			unit->name, unit->id.text, newloc->name, newloc->id.text,
			newloc->x, newloc->y, visual_enum(plane, regions));
	unit_personal_event(target, today_number, work);
	sprintf(work, "%s [%s] appears in a flash of eerie light", target->name,
			target->id.text);
	location_visible_event(newloc, today_number, work);
	return 1;
}

static void fx_sendself_damage(unit_s *unit, char plane)
{
	static item_s *wound_cache;
	int res = fx_sendself(unit, plane);

	/* We can lose some life for this */
	if(res && (roll_1Dx(100) < 3)) {
		if(!wound_cache) {
			synthetic_tag("wound");
			wound_cache = item_from_tag(0);
		}
		if(wound_cache) {
			carry_s *wounds = unit_possessions(unit, wound_cache, 1);
			wounds->amount++;
		}
		unit_personal_event(unit, today_number, "The transport damages you!");
	}
}

static void fx_sendother_damage(unit_s *unit, char plane)
{
	static item_s *wound_cache;
	unit_s *target = unit->stack;
	int res;

	if(!target) return;
	res = fx_sendother(unit, plane);

	/* We can lose some life for this */
	if(res && (roll_1Dx(100) < 3)) {
		if(!wound_cache) {
			synthetic_tag("wound");
			wound_cache = item_from_tag(0);
		}
		if(wound_cache) {
			carry_s *wounds = unit_possessions(target, wound_cache, 1);
			wounds->amount++;
		}
		unit_personal_event(target, today_number, "The transport damages you!");
	}
}

#ifdef FX_DETECT_BEAST
int unit_has_beast(unit_s *searcher, unit_s *subject, int val)
{
	carry_s *s;
	if(subject == searcher) return 0;
	if(subject->dead || subject->virtual) return 0;

	for(s = subject->carrying; s; s = s->next) {
		if(s->item->item_type == ITEM_BEAST && s->amount) return 1;
	}
	return 0;
}

static void fx_detect_beast(unit_s *unit)
{
	location_s *loc = unit->current;
	int count = search_local_units(unit, loc, unit_has_beast,
			"Your hounds scent the beasts of %s [%s].",
			"You hear dogs sniff and howl outside of your tent.", 20);
	if(!count) {
		unit_personal_event(unit, today_number, "Your hounds scent no beasts");
	}
}
#endif

#if defined( FX_DETECT_LIFE) || defined(FX_SENSE_PEOPLE)
int living_unit(unit_s *searcher, unit_s *subject, int val)
{
	carry_s *s;
	if(subject == searcher) return 0;
	if(subject->dead || subject->virtual) return 0;
	if(subject->race->type == RACE_LEADER) return 1;

	for(s = subject->carrying; s; s = s->next) {
		if(s->item->item_type == ITEM_FOLLOWER && s->amount) return 1;
	}
	return 0;
}

static void fx_detect_life(unit_s *unit)
{
	location_s *loc = unit->current;
	int count = search_local_units(unit, loc, living_unit,
			"You detect the lifeforce of %s [%s].",
			"You feel a light tickle as if someone stepped on your grave.",
			20);
	if(!count) {
		unit_personal_event(unit, today_number,
				"You sense no living units other than yourself");
	}
}

static void fx_sense_people(unit_s *unit)
{
	location_s *loc = unit->current;
	int count = search_local_units(unit, loc, living_unit,
			"You detect the lifeforce of %s [%s].",
			"You sense someones spirit questing after your presence.",
			20);
	if(!count) {
		unit_personal_event(unit, today_number,
				"You sense no living units other than yourself");
	}
}
#endif

#ifdef FX_DETECT_ENEMIES
int hostile_unit(unit_s *searcher, unit_s *subject, int val)
{
    if(attitude_vs(subject->faction, searcher) >= ATTITUDE_IS_NEUTRAL)
        return 1;
    return 0;
}

static void fx_detect_enemies(unit_s *unit)
{
	location_s *loc = unit->current;
	int count = search_local_units(unit, loc, hostile_unit,
                           "You detect the hostility of %s [%s] toward you.",
                           "You feel a light tickle as someone scans your feelings.", 20);
        if(!count) {
            unit_personal_event(unit, today_number,
				"You sense no hostile units");
        }
}
#endif

#ifdef FX_AMBUSH
static void fx_ambush(unit_s *unit)
{
    unit_s *target;

    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number, "No such unit to ambush.");
        return;
    }
    target = unit->target.unit;
    unit->target_type = ARGUMENT_IS_EMPTY;
    initiate_ambush(unit, target);
}
#endif

#ifdef FX_UNEARTH_ARCANA
static int skill_known_to_faction(skill_s *skill, faction_s *faction)
{
	skillknow_s *skill_know;
	for(skill_know = faction->known_skills; skill_know; skill_know = skill_know->next) {
		if(skill_know->about == skill) return 1;
	}
	return 0;
}

static void fx_unearth_arcana(unit_s *unit)
{
	int count= 0;
	skill_s *skill;
	skill_s *skills[200];

	for(skill = skills_list; skill && (count < 200); skill = skill->next) {
		if(!skill->student || !skill->flags) continue;
		if(skill_known_to_faction(skill, unit->faction)) continue;
		skills[count++] = skill;
	}

	count = roll_1Dx(count);
	skill = skills[count];
#ifdef USES_SKILL_LEVELS
	faction_knows_skill_level(unit->faction, skill, 1);
#else
	faction_knows_skill(unit->faction, skill);
#endif
	sprintf(work, "You discover ancient lore explaining %s [%s]",
			skill->name, skill->tag.text);
	unit_personal_event(unit, today_number, work);
}
#endif

#ifdef FX_EXECUTE
static void fx_execute(unit_s *unit)
{
    unit_s *target;
    int diff;
    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No such prisoner to execute.");
        return;
    }
    target = unit->target.unit;
    unit->target_type = ARGUMENT_IS_EMPTY;
    if(!target->is_captive || (target->leader != unit)) {
        unit_personal_event(unit, today_number,
                            "That unit isn't your prisoner.");
        return;
    }

    compute_unit_stats(target);
    diff = target->vital.control - target->race->intrinsic.control;
    target->faction->control_bonus -= diff/2;
    if(target->faction->control_bonus < 0)
	target->faction->control_bonus = 0;

    unit_is_now_dead(target, 0);
    sprintf(work, "Prisoner %s [%s] has been executed.", target->name,
            target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You have been executed by %s [%s].",
            unit->name, unit->id.text);
    unit_personal_event(target, today_number, work);
    sprintf(work, "%s [%s] has been executed by %s [%s].",
	    target->name, target->id.text, unit->name, unit->id.text);
    location_visible_event(unit->true_location, today_number, work);
    unit->true_location->economy+=10;
}
#endif

#ifdef FX_WIZARDS_CURSE
static void fx_wizards_curse(unit_s *unit)
{
    location_s *loc = unit->true_location;

    if(loc->cursed) {
		unit_personal_event(unit, today_number,
				"This location has already been cursed.");
		return;
    }
    if(loc->blessed) {
		loc->blessed = 0;
		unit_personal_event(unit, today_number,
				"The blessing on this location has been nullified.");
		return;
    }

    loc->cursed = 1;
    sprintf(work, "%s [%s] has cursed the land.", unit->name, unit->id.text);
    location_visible_event(loc, today_number, work);
}
#endif

#ifdef FX_CROP_BLESSING
static void fx_crop_blessing(unit_s *unit)
{
    location_s *loc = unit->true_location;

    if(loc->blessed) {
		unit_personal_event(unit, today_number,
				"This location has already been blessed.");
		return;
    }
    if(loc->cursed) {
		loc->cursed = 0;
		unit_personal_event(unit, today_number,
				"The curse on this location has been lifted.");
		return;
    }

    loc->blessed = 1;
    sprintf(work, "%s [%s] has blessed the land.", unit->name, unit->id.text);
    location_visible_event(loc, today_number, work);
}
#endif

#ifdef FX_RANSOM
static void fx_ransom(unit_s *unit)
{
    unit_s *target, *overall_leader;
    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No such prisoner to ransom.");
        return;
    }
    target = unit->target.unit;
    unit->target_type = ARGUMENT_IS_EMPTY;
    if(!target->is_captive || (target->leader != unit)) {
        unit_personal_event(unit, today_number,
                            "That unit isn't your prisoner.");
        return;
    }
    sprintf(work, "Prisoner %s [%s] has been ransomed.", target->name,
            target->id.text);
    unit_personal_event(unit, today_number, work);
    sprintf(work, "You have been ransomed and released by %s [%s].",
            unit->name, unit->id.text);
    unit_personal_event(target, today_number, work);
    overall_leader = target->leader;
    while(overall_leader->leader) overall_leader = overall_leader->leader;
    unstack_unit(target);
    target->next_location = overall_leader->next_location;
    overall_leader->next_location = target;
}
#endif

#ifdef FX_PILLAGE
static void fx_pillage(unit_s *unit, skill_s *effective)
{
	static skill_s *tax_cache;
	resource_s *res;
	item_s *what;
	int man_days = 0;
	carry_s *uses;
	carry_s *results;
	int tcoins;
	int taxable;
	location_s *loc;
	consume_s *enhanced;
	int soldier;
	int required;
	int multiple;
	int amount;
	int garr;
	unit_s *guards;

	if(!tax_cache) {
		synthetic_tag("taxe");
		tax_cache = skill_from_tag(0);
	}

	if(unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Only leaders may pillage.");
		return;
	}

	loc = unit->true_location;

	if(loc->pillaged == 2) {
		unit_personal_event(unit, today_number,
				"This location has already been pillaged today.");
		return;
	}

	man_days = 100 * unit->size;
	for(uses = unit->carrying; uses; uses = uses->next) {
		uses->contributed = 0;
	}

	for (enhanced=effective->enhanced;enhanced;enhanced=enhanced->next) {
		what = enhanced->what;
		if (what->item_type == ITEM_TOKEN) {
			/* soldier? recruit? */
			if (what->tag.text[0] == 'w')
				soldier = 0;
			else
				soldier = 1;
			for (uses = unit->carrying; uses; uses = uses->next) {
				if(uses->contributed) continue;
				if (uses->amount &&
						uses->item->item_type == ITEM_FOLLOWER &&
						uses->item != item_recruit) {
					if (soldier) {
						if (!uses->item->equip_bonus.melee &&
								!uses->item->equip_bonus.missile)
							continue;
					} else
						if (uses->item->equip_bonus.melee ||
								uses->item->equip_bonus.missile)
							continue;
					uses->contributed = uses->amount * enhanced->amount;
				}
			}
		} else {
			uses = unit_possessions(unit, what, 0);
			if (uses) {
				uses->contributed = uses->amount * enhanced->amount;
			}
		}
	}
	
	for(uses = unit->carrying; uses; uses = uses->next) {
		man_days += uses->contributed;
		uses->contributed = 0;
	}
	if (man_days == 0) {
		unit_personal_event(unit, today_number,
				"You do not have enough troops to pillage the region.");
		return;
	}

	for(res = loc->resources; res; res = res->next) {
		if(res->type == token_tax) break;
	}

	if(res) {
		tcoins = res->remains;
	} else
		tcoins = 0;

	taxable = ((31-today_number)* man_days)/tax_cache->tokens_required;
	taxable /= 100;
	if(taxable < tcoins) {
		unit_personal_event(unit, today_number,
				"You do not have enough troops to pillage the region.");
		return;
	}

	if(!tcoins || tcoins < 0) {
		unit_personal_event(unit, today_number,
				"No coins left to pillage in the region.");
		return;
	}

	/* See if there are other garrisons */
	garr = 0;
	who_is_present(loc);
	for(guards= loc->interacting; guards; guards = guards->next_visible) {
		if(guards->faction == unit->faction) continue;
		if(guards->current != unit->current) continue;
		if(guards->participate == 0) continue;
		if(!guards->setting_guard) continue;
		if(guards->is_captive) continue;
		if(guards->summoned) continue;
		if(guards->is_moving) continue;
		if(guards->race->type == RACE_LEADER) {
			garr = 1;
		} else {
			/* see if it has any fighting men */
			for(uses = guards->carrying; uses; uses = uses->next) {
				if(uses->item->item_type == ITEM_FOLLOWER &&
						uses->amount &&
						(uses->item->equip_bonus.melee ||
						 uses->item->equip_bonus.missile))
					garr = 1;
			}
		}
		if(garr) break;
	}

	if(guards) {
		sprintf(work,
				"You see %s [%s] pillaging and attempt to stop them!",
				unit->name, unit->id.text);
		unit_personal_event(guards, today_number, work);
		sprintf(work,
				"%s [%s] sees you pillaging and attempts to stop you!",
				guards->name, guards->id.text);
		unit_personal_event(unit, today_number, work);
		initiate_attack(guards, unit);
		if(unit->dead) return;
		if(!unit->victor || unit->is_captive) {
			sprintf(work, "A local garrison prevents you from pillaging.");
			unit_personal_event(unit, today_number, work);
		}
	}
	unit->sneaking = 0;
	sprintf(work, "%s [%s] pillages the area", unit->name, unit->id.text);
	location_visible_event(loc, today_number, work);

	required = tax_cache->tokens_required*100;
	multiple = tax_cache->multiples;
	if(multiple == 0) multiple = 1;
	multiple *= 2;
	amount = 0;
	results = unit_possessions(unit, tax_cache->end_product, 1);

	while(man_days) {
		if(res->remains <= 0) break;

		if((results->tokens + man_days) < required) {
			results->tokens += man_days;
			man_days = 0;
			break;
		}
		if(res) res->remains--;
		man_days -= required - results->tokens;
		results->tokens = 0;
		results->amount += multiple;
		amount += multiple;
	}
	sprintf(work, "%d %s produced", amount,
			(amount > 1 ? tax_cache->end_product->plural :
			 tax_cache->end_product->name));
	unit_personal_event(unit, today_number, work);

	loc->pillaged = 2;
	loc->economy -= 5;
	loc->population -= roll_1Dx(4)+1;
	if(loc->markets) {
		market_s *market;
		for(market = loc->markets; market; market = market->next) {
			if(market->wanted.initial_amount && (roll_1Dx(30)<1)) {
				market->wanted.initial_amount--;
				if(market->wanted.amount_remains)
					market->wanted.amount_remains--;
			}
			if(market->offered.initial_amount && (roll_1Dx(30)<1)) {
				market->offered.initial_amount--;
				if(market->offered.amount_remains)
					market->offered.amount_remains--;
			}
		}
	}
	if(loc->population < 1) loc->population = 1;
}
#endif

#ifdef FX_INSPIRATION
static void fx_inspiration(unit_s *unit, int amount)
{
    static skill_s *dmas_cache;
    skill_s *temp, *t1;
    skill_s *maybe[40];
    experience_s *exp;
    int amt, count, x;

    if(!dmas_cache) {
	synthetic_tag("dmas");
	dmas_cache = skill_from_tag(0);
    }

    exp = unit_experiences(unit, dmas_cache, 0);
    if(!exp) {
	unit_personal_event(unit, today_number, "You are an odd duck, casting dmas spells without having the skill!");
	printf("%s [%s] [%s] had inspiration cast but isn't a dedicant\n",
	       unit->name, unit->id.text, unit->faction->id.text);
	return;
    }
    if(exp->level == 1 && roll_1Dx(100) < 50) {
	unit_personal_event(unit, today_number, "The Master chooses not to grant you inspiration.");
	return;
    }

    if(exp->level > 2) {
	amt = (exp->level - 2)*20;
    } else {
	amt = 1;
    }

    count = 0;
    for(temp = skills_list; temp && (count < 40); temp = temp->next) {
	if(temp->student != dmas_cache->student) continue;
	if(unit_experiences(unit, temp, 0)) continue;
	t1 = temp->required_skill;
	exp = unit_experiences(unit, t1, 0);
	if(!exp) continue;
	if(temp->required_at_level > exp->level) continue;
	maybe[count++] = temp;
    }
    if(!count) {
	sprintf(work, "You do not feel inspired at this time.");
	unit_personal_event(unit, today_number, work);
	exp = unit_experiences(unit, dmas_cache, 0);
	add_to_experience(unit, exp, dmas_cache, 40);
	return;
    }
    while(amount) {
        x = roll_1Dx(count);
	if(!maybe[x]) continue;
        exp = unit_experiences(unit, maybe[x], 1);
        exp->points += amt;
        exp->studied++;
        sprintf(work, "You are inspired by knowledge about %s [%s]",
		maybe[x]->name, maybe[x]->tag.text);
        unit_personal_event(unit, today_number, work);
	maybe[x] = NULL;
	amount--;
    }
    return;
}
#endif

#ifdef FX_INCREASE_INT
static void fx_increase_int(unit_s *unit, int amount)
{
    unit_s *target;
    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number,
                            "No target for increased intelligence.");
        return;
    }
    target = unit->target.unit;
    unit->target_type = ARGUMENT_IS_EMPTY;

    if(target->full_day && target->studying) {
        /* target already executed, do the bonus now */
        order_s *executing = target->executing;
        if(executing && executing->executing.routine == execute_study) {
            skill_s *skill = target->studying;
            experience_s *exp = unit_experiences(target, skill, 0);
            if(!exp) return;
            if(exp->effective) return;
	    while(amount--) {
                unit_study_again(target, exp, skill, target->size, 0);
	    }
            if(exp->effective) {
                target->faction->control_current += exp->effective->bonus.control;
                if(executing->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
                    order_was_executed(target, executing);
                    target->executing=0;
                } else {
                    order_is_complete(target, executing);
                }
            }
	}
    } else {
        target->intelligent += amount;
    }
    return;
}
#endif

#ifdef FX_SPYING
static void fx_spying(unit_s *unit, skill_s *effective)
{
	static skill_s *spy_cache;
	skill_s *p;
	int level = 1;
	unit_s *target;

	if(!spy_cache) {
		synthetic_tag("spyi");
		spy_cache = skill_from_tag(0);
	}

	if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number,
			            "No target specified for spying.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "Spied upon unit must be in the same location.");
		return;
	}
	
	p = spy_cache;
	while(p && p != effective) {
		level++;
		p = p->next_level;
	}
	if(!p) return;

	compute_unit_stats(target);
	switch(level) {
		case 1: {/* Get melee, missile, and defense */
			int melee = target->vital.melee + target->bonus.melee;
			int missile = target->vital.missile + target->bonus.missile;
			int defense = target->vital.defense + target->bonus.defense;
			sprintf(work, "Spying reveals - Melee: %d, Missile: %d, Defense: %d.",
				melee, missile, defense);
			unit_personal_event(unit, today_number, work);
			break;
		}
		case 2: { /* Get melee, missile, defense and initiative */
			int melee = target->vital.melee + target->bonus.melee;
			int missile = target->vital.missile + target->bonus.missile;
			int defense = target->vital.defense + target->bonus.defense;
			int init = target->vital.initiative + target->bonus.initiative;
			sprintf(work, "Spying reveals - Melee: %d, Missile: %d, Defense: %d, Initiative: %d.",
				melee, missile, defense, init);
			unit_personal_event(unit, today_number, work);
			break;
		}
		default:
			printf("Unimplemented spying level.");
	}
}
#endif

#ifdef FX_CHANGEMORPH
static void fx_changemorph(unit_s *unit)
{
    race_s *race = unit->race;
    race_s *newrace;
    static int count = 0;
    int rnd;

    if(!count) {
	for(newrace = race_list; newrace; newrace = newrace->next) {
	    if(newrace->type == RACE_LEADER && newrace != race &&
	       newrace->intrinsic.control != 0)
		count++;
	}
    }
    if(!count) {
	printf("URK! No race to morph into for unit %s [%s] [%s]\n",
	       unit->name, unit->id.text, unit->faction->id.text);
	return;
    }
    rnd = roll_1Dx(count);

    for(newrace = race_list; newrace; newrace = newrace->next) {
	if(newrace == race) continue;
	if(newrace->type != RACE_LEADER) continue;
	if(newrace->intrinsic.control == 0) continue;
	if(!rnd--) break;
    }

    sprintf(work, "Your body contorts and changes into that of %s [%s]",
	    newrace->name, newrace->tag.text);
    faction_knows_race(unit->faction, newrace);
    unit_personal_event(unit, today_number, work);
    unit->race = newrace;
}
#endif

#ifdef FX_IDENTIFY
static void fx_identify(unit_s *unit)
{
    unit_s *target;
    experience_s *exp, *exp2;
    if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
	unit_personal_event(unit, today_number,
			    "No target specified for read auras.");
	return;
    }
    target = unit->target.unit;
    unit->target_type = ARGUMENT_IS_EMPTY;
    if(target->true_location != unit->true_location) {
	unit_personal_event(unit, today_number,
			    "Target unit must be in the same location.");
	return;
    }
    exp = unit_experiences(target, magecraft, 0);
    exp2 = unit_experiences(unit, magecraft, 0);

    /* Failure */
    if(exp && exp->level > exp2->level) {
	sprintf(work, "%s [%s] is too powerful a mage for identification",
		target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%s [%s] tried to identify your affiliation",
		unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
	return;
    }
    sprintf(work, "%s [%s] is loyal to %s [%s]", target->name, target->id.text,
	    target->faction->name, target->faction->id.text);
    unit_personal_event(unit, today_number, work);
}
#endif

#ifdef USES_MANA_POINTS
#ifdef FX_EVALUATE_MANA
static void fx_evaluate_mana(unit_s *unit)
{
	unit_s *target;
	experience_s *exp;
	static item_s *masq_cache;
	int mana, min, max, res;

	if(!masq_cache) {
		synthetic_tag("dayaurm");
		masq_cache = item_from_tag(0);
	}

	if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number,
			            "No target specified for read auras.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "Target unit must be in the same location.");
		return;
	}
	for(exp = target->skilled; exp; exp = exp->next) {
		if(exp->skill == magecraft) break;
	}
	/* Adjust aura masq */
	if(exp && target->masqing) {
		carry_s *days = unit_possessions(target, masq_cache, 0);
		if(days->amount > 7) {
			days->amount -= 7;
		} else {
			days->amount = 0;
			target->masqing = 0;
		}
	}
	if(!exp || target->masqing) {
		unit_personal_event(unit, today_number, "Target unit does not seem to know magecraft.");
		return;
	}

	if(!target->power) mana = 0;
	else mana = target->power->amount;

	if(mana < 10) {
		min = mana-1;
		max = mana+1;
	} else {
		min = mana * .90;
		max = mana * 1.10;
	}
	res = min + roll_1Dx(max-min+1);
        if(res < 0) res = 0;
	sprintf(work,  "%s [%s] has about %d mana.", target->name,
		target->id.text, res);
	unit_personal_event(unit, today_number, work);
}
#endif
#endif

#ifdef FX_DIVINE_REVEAL
static void fx_divine_revelation(unit_s *unit)
{
	unit_s *target;
	experience_s *exp;
	experience_s *found[100];
	int count = 0;
	if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number,
				"No target specified for read auras.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number,
				"Target unit must be in the same location.");
		return;
	}
	if(target->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number,
				"Only leaders can be divinely inspired!");
		return;
	}

	for(exp = target->skilled; exp; exp = exp->next) {
		if(exp->skill->type == 2 || exp->skill->student) continue;
		if(exp->level < 1 || !exp->effective) continue;
		if(exp->level > 3) continue;
		found[count++] = exp;
	}

	count = roll_1Dx(count);
	exp = found[count];

	add_to_experience(target, exp, exp->skill, 100);
	sprintf(work, "You gain insight into %s [%s] due to a divine revelation",
			exp->skill->name, exp->skill->tag.text);
	unit_personal_event(target, today_number, work);
}
#endif

#ifdef FX_ACQUIRE_ARTISAN
static void fx_acquire_artisan(unit_s *unit)
{
	skill_s *temp, *t1;
	static skill_s *artisan;
	experience_s *exp;
	int count = 0;

	if(!artisan) {
		synthetic_tag("arti");
		artisan = skill_from_tag(0);
	}

	for(temp = skills_list; temp; temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have an artisan skill */
		if(t1 == artisan) {
		        exp = unit_experiences(unit, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(may_study_skill(unit, temp)) {
				exp = unit_experiences(unit, temp, 1);
				exp->points = 20 * (roll_1Dx(5)+1);
				exp->studied++;
				sprintf(work, "You are granted knowledge about %s [%s]",
					temp->name, temp->tag.text);
				unit_personal_event(unit, today_number, work);
				count = 1;
			}
		}
	}

	if(!count) {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(unit, artisan, 0);
		if(exp)
		    add_to_experience(unit, exp, artisan, 40);
	}
}
#endif

#ifdef FX_REVEAL_LEADERSHIP
static void fx_reveal_leadership(unit_s *unit)
{
	unit_s *target;
	skill_s *maybe[20];
	skill_s *temp, *t1;
	static skill_s *lead;
	experience_s *exp;
	int count = 0;
	int x;

	if(!lead) {
		synthetic_tag("lead");
		lead = skill_from_tag(0);
	}

	if(unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "The target unit does not exist.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "The target unit does appear to be here.");
		return;
	}

	for(temp = skills_list; temp && (count < 20); temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have a leadership skill */
		if(t1 == lead) {
		        exp = unit_experiences(target, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(temp->required_skill) {
				exp = unit_experiences(target,temp->required_skill, 0);
				if(exp) {
					if(temp->required_at_level <= exp->level)
						maybe[count++] = temp;
				}
			} else {
				maybe[count++] = temp;
			}
		}
	}

	if(count) {
		x = roll_1Dx(count);
		exp = unit_experiences(target, maybe[x], 1);
		exp->points++;
		exp->studied++;
		sprintf(work, "You are granted knowledge about %s [%s]",
			maybe[x]->name, maybe[x]->tag.text);
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] was granted knowledge of a leadership skill.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] could not be granted a leadership skill at this time.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(target, lead, 0);
		add_to_experience(target, exp, lead, 40);
	}
}
#endif

#ifdef FX_REVEAL_SCOUTING
static void fx_reveal_scouting(unit_s *unit)
{
	unit_s *target;
	skill_s *maybe[20];
	skill_s *temp, *t1;
	static skill_s *scout;
	experience_s *exp;
	int count = 0;
	int x;

	if(!scout) {
		synthetic_tag("scou");
		scout = skill_from_tag(0);
	}

	if(unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "The target unit does not exist.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "The target unit does appear to be here.");
		return;
	}

	for(temp = skills_list; temp && (count < 20); temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have a scouting skill */
		if(t1 == scout) {
		        exp = unit_experiences(target, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(temp->required_skill) {
				exp = unit_experiences(target,temp->required_skill, 0);
				if(exp) {
					if(temp->required_at_level <= exp->level)
						maybe[count++] = temp;
				}
			} else {
				maybe[count++] = temp;
			}
		}
	}

	if(count) {
		x = roll_1Dx(count);
		exp = unit_experiences(target, maybe[x], 1);
		exp->points++;
		exp->studied++;
		sprintf(work, "You are granted knowledge about %s [%s]",
			maybe[x]->name, maybe[x]->tag.text);
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] was granted knowledge of a scouting skill.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] could not be granted a scouting skill at this time.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(target, scout, 0);
		add_to_experience(target, exp, scout, 40);
	}
}
#endif

#ifdef FX_REVEAL_SAIL
static void fx_reveal_sailing(unit_s *unit)
{
	unit_s *target;
	skill_s *maybe[20];
	skill_s *temp, *t1;
	static skill_s *seamanship;
	experience_s *exp;
	int count = 0;
	int x;

	if(!seamanship) {
		synthetic_tag("seas");
		seamanship = skill_from_tag(0);
	}

	if(unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "The target unit does not exist.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "The target unit does appear to be here.");
		return;
	}

	for(temp = skills_list; temp && (count < 20); temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have a combat skill */
		if(t1 == seamanship) {
		        exp = unit_experiences(target, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(temp->required_skill) {
				exp = unit_experiences(target,temp->required_skill, 0);
				if(exp) {
					if(temp->required_at_level <= exp->level)
						maybe[count++] = temp;
				}
			} else {
				maybe[count++] = temp;
			}
		}
	}

	if(count) {
		x = roll_1Dx(count);
		exp = unit_experiences(target, maybe[x], 1);
		exp->points++;
		exp->studied++;
		sprintf(work, "You are granted knowledge about %s [%s]",
			maybe[x]->name, maybe[x]->tag.text);
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] was granted knowledge of a sailing skill.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] could not be granted a sailing skill at this time.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(target, seamanship, 0);
		add_to_experience(target, exp, seamanship, 40);
	}
}
#endif

#ifdef FX_WARRIOR_REVEAL
static void fx_reveal_combat(unit_s *unit)
{
	unit_s *target;
	skill_s *maybe[20];
	skill_s *temp, *t1;
	static skill_s *combat;
	experience_s *exp;
	int count = 0;
	int x;

	if(!combat) {
		synthetic_tag("cmbt");
		combat = skill_from_tag(0);
	}

	if(unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "The target unit does not exist.");
		return;
	}
	target = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->true_location != unit->true_location) {
		unit_personal_event(unit, today_number, "The target unit does appear to be here.");
		return;
	}
	if(unit_experiences(target, combat, 0) == 0) {
		unit_personal_event(unit, today_number, "The target unit must have minimal combat skills.");
		return;
	}

	for(temp = skills_list; temp && (count < 20); temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have a combat skill */
		if(t1 == combat) {
		        exp = unit_experiences(target, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(temp->required_skill) {
				exp = unit_experiences(target,temp->required_skill, 0);
				if(exp) {
					if(temp->required_at_level <= exp->level)
						maybe[count++] = temp;
				}
			} else {
				maybe[count++] = temp;
			}
		}
	}

	if(count) {
		x = roll_1Dx(count);
		exp = unit_experiences(target, maybe[x], 1);
		exp->points++;
		exp->studied++;
		sprintf(work, "You are granted knowledge about %s [%s]",
			maybe[x]->name, maybe[x]->tag.text);
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] was granted knowledge of a combat skill.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(target, today_number, work);
		sprintf(work, "%s [%s] cannot be granted a combat skill at this time.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(target, combat, 0);
		add_to_experience(target, exp, combat, 40);
	}
}
#endif

#ifdef FX_REVEAL_ARTISAN
static void fx_reveal_artisan(unit_s *unit)
{
	/* Yes, I'm only allowing 20 skills at random */
	skill_s *maybe[20];
	skill_s *temp, *t1;
	static skill_s *artisan;
	experience_s *exp;
	int count = 0;
	int x;

	if(!artisan) {
		synthetic_tag("arti");
		artisan = skill_from_tag(0);
	}

	for(temp = skills_list; temp && (count < 20); temp = temp->next) {
		if(temp->required_skill) {
			t1 = temp;
			while(t1->required_skill) t1 = t1->required_skill;
		} else
			t1 = temp;

		/* We have an artisan skill */
		if(t1 == artisan) {
		        exp = unit_experiences(unit, temp, 0);
			if(exp && (exp->points || exp->studied)) continue;
			if(temp->required_skill) {
				exp = unit_experiences(unit,temp->required_skill, 0);
				if(exp) {
					if(temp->required_at_level <= exp->level)
						maybe[count++] = temp;
				}
			} else {
				maybe[count++] = temp;
			}
		}
	}

	if(count) {
		x = roll_1Dx(count);
		exp = unit_experiences(unit, maybe[x], 1);
		exp->points++;
		exp->studied++;
		sprintf(work, "You are granted knowledge about %s [%s]",
			maybe[x]->name, maybe[x]->tag.text);
		unit_personal_event(unit, today_number, work);
	} else {
		sprintf(work, "There is no skill which can be granted to you at this time.");
		unit_personal_event(unit, today_number, work);
		exp = unit_experiences(unit, artisan, 0);
		add_to_experience(unit, exp, artisan, 40);
	}
}
#endif

#ifdef FX_NATIVES_EYE
static void fx_natives_eye(unit_s *unit)
{
	resource_s *res;
	location_s *loc = unit->true_location;
	unit_personal_event(unit, today_number, "You peer through the eyes of a native.");
	for(res = loc->resources; res; res = res->next) {
		if((res->type != token_entertain) && 
		   (res->type != token_tax) &&
		   (res->type != item_recruit)) {
			sprintf(work, "You see %d %s [%s].",
					res->amount, res->type->name,
					res->type->tag.text);
			unit_personal_event(unit, today_number, work);
			faction_knows_item(unit->faction, res->type);
		}
	}
}
#endif

#ifdef FX_RECRUIT_RACE
static void fx_recruit_race(unit_s *unit, skill_s *skill)
{
	race_s *race;
	unit_s *target;
	static terrain_s *mtow_cache;

	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}

	race = skill->specific.race;

	if(unit->faction && unit->faction->resigned)
	    return;

	if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Target is not a valid unit for recruiting into.");
		return;
	}
	target= unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;
	if(target->race) {
		unit_personal_event(unit, today_number, "Target unit either already has a leader or is a camp.");
		return;
	}

	if(unit->faction->control_current+race->intrinsic.control > unit->faction->control_max) {
		unit_personal_event(unit, today_number, "The new unit is too hard for you to control.");
		return;
	}
	unit->faction->control_current += race->intrinsic.control;

	assign_unit_id(target);
	sprintf(work, "Recruited %s [%s] into unit %s [%s]",
		race->name, race->tag.text, target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	target->same_faction = unit->faction->units;
	unit->faction->units = target;

	if(unit->current->type == mtow_cache)
		move_to_location(target, unit->true_location);
	else
		stack_under(unit, target);
	target->inactive = 0;
	target->dead = 0;
	target->full_day = 1;
	target->size = 1;
	target->race = race;
	sprintf(work, "Recruited by %s [%s]", unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
}
#endif

#ifdef FX_FAR_EYE
/**
 ** FX_FAR_EYE
 **	User casts the FAR EYE
 **/
static void fx_far_eye(unit_s *unit)
{
location_s	*location;
location_s	*current;
direction_s	*dir;
/*
 * Caster must have specified a location, which is forgotten
 */
	if (unit->target_type != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Forgot to specify reconaissance's target");
		return;
	}
	location = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;
/*
 * In range?
 */
	current = unit->true_location;
	if (location != current) {
		for (dir = current->exits; dir; dir = dir->next)
			if (dir->toward == location)
				break;
		if (dir == 0) {
			current = current->outer;
			if (current != location && current) {
				for (dir = current->exits; dir; dir = dir->next)
					if (dir->toward == location)
						break;
				if (!dir)
					current = 0;
			}
		}
		if(!dir) {
			for(current = unit->true_location->inner; current;
					current = current->next_inner) {
				if(current == location)
					break;
			}
		}
	}
	if (!current) {
		unit_personal_event(unit, today_number, "Target out of range");
		return;
	}
/*
 * We are observing at our observation, today, 
 */
	observer_present(unit, location, today_number);
	sprintf(work, "Seen %s [%s]", location->name, location->id.text);
	unit_personal_event(unit, today_number, work);
}
#endif /* FX_FAR_EYE */

#ifdef FX_EAGLE_EYE
static void fx_eagle_eye(unit_s *unit)
{
location_s	*current;
direction_s	*dir;
int		days;
	current = unit->true_location;
	for (dir = current->exits; dir; dir = dir->next) {
	    if(dir->toward->region != current->region) continue;
	    sprintf(work, "You keep an eagle's eye on %s [%s]",
		    dir->toward->name, dir->toward->id.text);
	    unit_personal_event(unit, today_number, work);
	    for(days = today_number; days < 32; days++) {
		observer_present(unit, dir->toward, days);
	    }
	}
}
#endif

#ifdef FX_FEEL_FLOW
static void fx_feel_flow(unit_s *unit)
{
	item_s *item;
	location_s *start;
	location_s *loc/*, *ignore*/;
#if defined(DYNAMICALLY_DEFINED_GAME) || defined(USE_OVERLAND_COORDINATES)
	location_s *outer;
#endif
	
	unit_personal_event(unit, today_number, "You get a sense for the life around you!");
	for(item = item_list; item; item = item->next) {
		if((item->item_type == ITEM_BEAST) && item->token_multiplier) {
			targeted_item = item;
			start = unit->true_location;
			if(search_for_location(start, match_resource, &loc)<0) {
				sprintf(work, "You do not sense any %s [%s].",
					item->name, item->tag.text);
			} else {
				char buf[200];

				outer = loc;
				while(outer->outer) outer = outer->outer;

				if(outer->region) {
					sprintf(buf, " <%s>", visual_enum(outer->region, regions));
				} else
					strcpy(buf, "");

				sprintf(work, "You sense %s [%s] at %s%s [%s] (%d, %d).",
					item->plural, item->tag.text, loc->name, buf,
					loc->id.text, outer->x, outer->y);
			}
			unit_personal_event(unit, today_number, work);
			faction_knows_item(unit->faction, item);
		}
	}
}
#endif

#ifdef FX_ORIENT
static void fx_orient(unit_s *unit)
{
	item_s *item;
	location_s *start;
	location_s *loc/*, *ignore*/;
#if defined(DYNAMICALLY_DEFINED_GAME) || defined(USE_OVERLAND_COORDINATES)
	location_s *outer;
#endif
	static item_s *metal;

	if(!metal) {
		synthetic_tag("metal");
		metal = item_from_tag(0);
	}
	
	unit_personal_event(unit, today_number, "You get a sense for the metals of the earth!");
	for(item = item_list; item; item = item->next) {
		if((item->item_category == 3) && item->token_multiplier) {
			if(item == metal) continue;
			targeted_item = item;
			start = unit->true_location;
			if(search_for_location(start, match_resource, &loc)<0){
				sprintf(work, "You do not sense any %s [%s].",
					item->name, item->tag.text);
			} else {
				char buf[200];
				outer = loc;
				while(outer->outer) outer = outer->outer;

				if(outer->region)
					sprintf(buf, " <%s>", visual_enum(outer->region, regions));
				else
					strcpy(buf, "");

				sprintf(work, "You sense %s [%s] at %s%s [%s] (%d, %d).",
					item->plural, item->tag.text, loc->name, buf,
					loc->id.text, outer->x, outer->y);
			}
			unit_personal_event(unit, today_number, work);
			faction_knows_item(unit->faction, item);
		}
	}
}
#endif

#ifdef FX_SEED_EARTH
static void fx_seed_earth(unit_s *unit)
{
	item_s *item;
	item_s *found[30];
	int count = 0;
	location_s *loc;

	for(item = item_list; item; item = item->next) {
		if(item->token_multiplier &&
		   ((item->item_category == 3) || (item->item_category == 2))) {
			found[count++] = item;
		}
	}
	loc = unit->true_location;
	count = roll_1Dx(count);
	item = found[count];

	count = 1 + roll_1Dx(5);
	fx_increase_resources(loc, item, count);
	sprintf(work, "%d %s form in the earth.", count,
			(count == 1 ? item->name : item->plural));
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%d %s are formed in the earth.", count,
			(count == 1 ? item->name : item->plural));
	location_visible_event(loc, today_number, work);
}
#endif

#ifdef FX_CULTIVATE_RICE
static void fx_cultivate_rice(unit_s *unit)
{
	static item_s *rice_cache;
	int count = 0;
	location_s *loc;

	if(!rice_cache) {
		synthetic_tag("rice");
		rice_cache = item_from_tag(0);
	}
	loc = unit->true_location;

	count = 1 + roll_1Dx(3);
	fx_increase_resources(loc, rice_cache, count);
	unit_personal_event(unit, today_number, "You cultivate rice in the area.");
	sprintf(work, "%d new rice appear.", count);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%d new rice are now grown in the area.", count);
	location_visible_event(loc, today_number, work);
	loc->cultivated = 1;
}
#endif

#ifdef FX_CULTIVATE_WHEAT
static void fx_cultivate_wheat(unit_s *unit)
{
	static item_s *wheat_cache;
	int count = 0;
	location_s *loc;

	if(!wheat_cache) {
		synthetic_tag("whea");
		wheat_cache = item_from_tag(0);
	}
	loc = unit->true_location;

	count = 1 + roll_1Dx(3);
	fx_increase_resources(loc, wheat_cache, count);
	unit_personal_event(unit, today_number, "You cultivate wheat in the area.");
	sprintf(work, "%d new wheat appear.", count);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%d new wheat are now grown in the area.", count);
	location_visible_event(loc, today_number, work);
	loc->cultivated = 1;
}
#endif


#ifdef FX_AID_IN_RITUAL
static void fx_aid_in_ritual(unit_s *unit, int amount)
{
	unit_s *target;
	carry_s *mana;
    target = unit->target.unit;
	mana = unit_possessions(target, item_mana, 1);
	mana->amount += amount;
}
#endif

#ifdef FX_CALL_BEASTS
static void fx_call_the_beasts(unit_s *unit)
{
	item_s *item;
	item_s *found[30];
	int count = 0;
	location_s *loc;

	for(item = item_list; item; item = item->next) {
		if(item->item_type == 2 && item->token_multiplier) {
			found[count++] = item;
		}
	}
	loc = unit->true_location;
	count = roll_1Dx(count);
	item = found[count];

	count = 1 + roll_1Dx(5);
	fx_increase_resources(loc, item, count);
	unit_personal_event(unit, today_number, "You summon beasts to the area.");
	sprintf(work, "%d %s answer your call.", count,
			(count == 1 ? item->name : item->plural));
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%d %s are summoned to the area.", count,
			(count == 1 ? item->name : item->plural));
	location_visible_event(loc, today_number, work);
}
#endif

#ifdef FX_LOCATE_SHELTER
static void fx_locate_shelter(unit_s *unit)
{
	location_s *start;
	location_s *loc, *outer;

	sprintf(work, "You search for the nearest location of a %s",
			unit->target.terrain->name);
    unit_personal_event(unit, today_number, work);

	start = unit->true_location;
	target_terrain = unit->target.terrain;
	if(search_for_location(start, match_terrain, &loc) < 0) {
		sprintf(work, "You do not sense any structures of that type.");
		unit_personal_event(unit, today_number, work);
	} else {
		char buf[200];
		outer = loc;
		while(outer->outer) outer = outer->outer;

		if(outer->region) {
			sprintf(buf, " <%s>", visual_enum(outer->region, regions));
		} else
			strcpy(buf, "");

		sprintf(work, "You see a %s (%s [%s]) at %s%s [%s] (%d, %d).",
				loc->type->name, loc->name, loc->id.text,
				outer->name, buf, outer->id.text, outer->x,
				outer->y);
		unit_personal_event(unit, today_number, work);
	}
}
#endif

#ifdef FX_FIND_LAND
static void fx_find_land(unit_s *unit)
{
	location_s *start;
	location_s *loc;

	sprintf(work, "You search for the nearest location of %s",
			unit->target.terrain->name);
    unit_personal_event(unit, today_number, work);

	start = unit->true_location;
	target_terrain = unit->target.terrain;
	if(search_for_location(start, match_terrain, &loc) < 0) {
		sprintf(work, "You do not sense any land of that type.");
		unit_personal_event(unit, today_number, work);
	} else {
		char buf[200];
		if(loc->region) {
			sprintf(buf, " <%s>", visual_enum(loc->region, regions));
		} else
			strcpy(buf, "");

		sprintf(work, "You sense land of type %s at %s%s [%s] (%d, %d).",
				loc->type->name, loc->name, buf, loc->id.text,
				loc->x, loc->y);
		unit_personal_event(unit, today_number, work);
	}
}
#endif

#ifdef FX_DISTANT_VISION
static void fx_distant_vision(unit_s *unit)
{
	location_s *start;
	location_s *loc;
	location_s *outer;

    unit_personal_event(unit, today_number,
			"You look for the nearest inner location");
	start = unit->true_location;
	if(search_for_location(start, match_inner_loc, &loc) < 0) {
		sprintf(work, "You do not sense any inner locations.");
		unit_personal_event(unit, today_number, work);
	} else {
		char buf[200];

		outer = loc;
		while(outer->outer) outer = outer->outer;

		if(outer->region) {
			sprintf(buf, " <%s>", visual_enum(outer->region, regions));
		} else
			strcpy(buf, "");

		sprintf(work, "You sense a %s at %s%s [%s] (%d, %d).",
				loc->type->name, outer->name, buf, outer->id.text,
				outer->x, outer->y);
		unit_personal_event(unit, today_number, work);
	}
}
#endif

#ifdef FX_GLOW_EYES
static void fx_glow_eyes(unit_s *unit)
{
	item_s *item;
	location_s *start;
	location_s *loc/*, *ignore*/;
#if defined(DYNAMICALLY_DEFINED_GAME) || defined(USE_OVERLAND_COORDINATES)
	location_s *outer;
#endif
	
	unit_personal_event(unit, today_number, "You get a sense for the gems of the earth!");
	for(item = item_list; item; item = item->next) {
		if(item->item_category == 2 && item->item_subcat == 1) {
			targeted_item = item;
			start = unit->true_location;
			if(search_for_location(start, match_resource, &loc)<0){
				sprintf(work, "You do not sense any %s [%s].",
					item->name, item->tag.text);
			} else {
				char buf[200];
				outer = loc;
				while(outer->outer) outer = outer->outer;

				if(outer->region)
					sprintf(buf, " <%s>", visual_enum(outer->region,regions));
				else
					strcpy(buf, "");

				sprintf(work, "You sense %s [%s] at %s%s [%s] (%d, %d).",
					item->plural, item->tag.text, loc->name, buf,
					loc->id.text, outer->x, outer->y);
			}
			unit_personal_event(unit, today_number, work);
			faction_knows_item(unit->faction, item);
		}
	}
}
#endif

static void fx_jump_to_adv_skill(unit_s *unit, skill_s *skill, int cont)
{
	experience_s *exp = unit->skilled;
	int found = 0;

	/*
	 * Make sure the unit a) has dfaf and b) doesn't already have
	 * advanced dfaf
	 */
	while(exp) {
                if(exp->skill == skill) {
			found = 1;
			break;
		}
		exp = exp->next;
	}

	if(found) {
		skill_s *s2 = exp->skill->next_level;
		if(exp->points <= s2->for_level) {
			int diff = s2->for_level - exp->points;
			add_to_experience(unit, exp, exp->skill, diff);
		} else {
			if(!cont) {
				sprintf(work, "%s already attained!", s2->name);
				unit_personal_event(unit, today_number, work);
                                            
				/* Unit already too skilled */
			} else {
				add_to_experience(unit, exp, exp->skill, cont);
			}
		}	
	} else {
		skill_s *s2 = skill->next_level;
		sprintf(work, "Must have %s to gain %s!", skill->name,
			s2->name);
		unit_personal_event(unit, today_number, work);
		/* Unit doesn't have skill */
	}
}

#ifdef FX_MASTER_BEASTS
static void fx_master_beasts(unit_s *unit)
{
	static skill_s *ranching;
	unit_s *targ;

	if(!ranching) {
		synthetic_tag("ranc");
		ranching = skill_from_tag(0);
	}

	/* Target must be a unit */
	if (unit->target_type != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "The target unit does not exist.");
		return;
	}
	targ = unit->target.unit;
	unit->target_type = ARGUMENT_IS_EMPTY;

	fx_jump_to_adv_skill(targ, ranching, 0);

}
#endif

#ifdef FX_BURN_BRIDGE
static void fx_burn_bridges(unit_s *unit)
{
	static skill_s *sk_dmas;

	if(!sk_dmas) {
		synthetic_tag("dmas");
		sk_dmas = skill_from_tag(0);
	}
	fx_jump_to_adv_skill(unit, sk_dmas, 60);
}
#endif

#ifdef FX_FURTHER_EWELIN
static void fx_further_ewelin(unit_s *unit)
{
	static skill_s *sk_dewe;

	if(!sk_dewe) {
		synthetic_tag("dewe");
		sk_dewe= skill_from_tag(0);
	}
	fx_jump_to_adv_skill(unit, sk_dewe, 60);
}
#endif

#ifdef FX_FURTHER_VOLD
static void fx_further_vold(unit_s *unit)
{
	static skill_s *sk_dvol;

	if(!sk_dvol) {
		synthetic_tag("dvol");
		sk_dvol= skill_from_tag(0);
	}
	fx_jump_to_adv_skill(unit, sk_dvol, 60);
}
#endif

#ifdef FX_FURTHER_ALG
static void fx_further_algirdas(unit_s *unit)
{
	static skill_s *sk_dalg;

	if(!sk_dalg) {
		synthetic_tag("dalg");
		sk_dalg = skill_from_tag(0);
	}
	fx_jump_to_adv_skill(unit, sk_dalg, 60);
}
#endif

#ifdef FX_FARTHER_FAFR
static void fx_farther_fafr(unit_s *unit)
{
	static skill_s *sk_dfaf;

	if(!sk_dfaf) {
		synthetic_tag("dfaf");
		sk_dfaf = skill_from_tag(0);
	}
	fx_jump_to_adv_skill(unit, sk_dfaf, 60);
}
#endif

#ifdef FX_TRANSCEND
static void fx_transcend(unit_s *unit)
{
	fx_jump_to_adv_skill(unit, magecraft, 0);
}
#endif

#ifdef FX_ASCEND
static void fx_ascend(unit_s *unit)
{
	experience_s *exp = unit_experiences(unit, magecraft, 0);
	skill_s *s2;
	int diff;

	if(!exp || exp->level < 2) {
		skill_s *s1 = magecraft->next_level;
		s2 = magecraft->next_level->next_level;
		sprintf(work, "Must have %s to gain %s!", s1->name, s2->name);
		unit_personal_event(unit, today_number, work);
		return;
	}
	if(exp->level != 2) {
		sprintf(work, "%s has already been attained!", exp->effective->name);
		unit_personal_event(unit, today_number, work);
		return;
	}

	s2 = exp->effective->next_level;
	diff = s2->for_level - exp->points;
	add_to_experience(unit, exp, exp->skill, diff);
}
#endif

#ifdef FX_APOTHEOSIS
static void fx_apotheosis(unit_s *unit)
{
	experience_s *exp = unit_experiences(unit, magecraft, 0);
	skill_s *s2;
	int diff;

	if(!exp || exp->level < 3) {
		skill_s *s1 = magecraft->next_level->next_level;
		s2 = magecraft->next_level->next_level->next_level;
		sprintf(work, "Must have %s to gain %s!", s1->name, s2->name);
		unit_personal_event(unit, today_number, work);
		return;
	}
	if(exp->level != 3) {
		sprintf(work, "%s has already been attained!", exp->effective->name);
		unit_personal_event(unit, today_number, work);
		return;
	}

	s2 = exp->effective->next_level;
	diff = s2->for_level - exp->points;
	add_to_experience(unit, exp, exp->skill, diff);
}
#endif

#ifdef FX_DENOUNCE_CLAIM
static void fx_denounce_claim(unit_s *unit)
{
	location_s *loc;
	unit_s *camp;
	static race_s *claim;

	if (!claim) {
		synthetic_tag("clai");
		claim = race_from_tag(0);
	}
	if (unit->target_type != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "No location specified to denounce as a claim.");
		return;
	}
	loc = unit->target.location;
	unit->target_type = ARGUMENT_IS_EMPTY;

	who_is_present(loc);
	for (camp = loc->interacting; camp; camp= camp->next_visible)
		if (camp->race == claim)
			break;
	if (!camp) {
		unit_personal_event(unit, today_number, "That area is not claimed!");
		return;
	}
	if(camp->target.unit != unit) {
		unit_personal_event(unit, today_number, "That claim is not yours to denounce!");
		return;
	}

	camp->target_type = ARGUMENT_IS_EMPTY;
	camp->target.unit = 0;
	camp->race = camp_race;

	sprintf(work, "Denounced claim to %s [%s]", loc->name, loc->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(camp, today_number, work);
	sprintf(work, "%s [%s] denounces the claim on this area!", unit->name, unit->id.text);
	location_visible_event(loc, today_number, work);
}
#endif

#ifdef FX_PICKPOCKET
static void fx_pickpocket(unit_s *unit)
{
	unit_s *target;
	int chance;
	carry_s *carry;
	carry_s *stole;

	if (unit->target_type == SKILL_TARGET_UNIT)
		target = unit->target.unit;
	if(!target) {
		return;
	}
	if(target->race->type != RACE_LEADER) {
		sprintf(work, "The unit %s [%s] has no leader to pickpocket.",
			target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		return;
	}

	if(!may_interact_with(unit, target)) {
		sprintf(work, "You wait for %s [%s] to show up, but they never do.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		return;
	}

	/* See what we can get */
	stole = NULL;
	for(carry = target->carrying; carry; carry = carry->next) {
		if(carry->item->item_type && (carry->item->item_type != ITEM_ITEM))
			continue;
		if(!carry->amount) continue;
		if(carry->equipped == carry->amount) continue;
		if(carry->item->weight > 5) continue;
		if(!stole) stole = carry;
		else {
			if(carry->item->market_value < stole->item->market_value)
				continue;
			else if(carry->item->market_value == stole->item->market_value) {
				if(carry->amount > stole->amount)
					stole = carry;
				else if(carry->amount == stole->amount) {
					if(roll_1Dx(2) & 1)
						stole = carry;
				}
			} else
				stole = carry;
		}
	}
	if(stole) {
		sprintf(work, "You stole 1 %s from %s [%s]", stole->item->name,
			target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		stole->amount--;
		stole = unit_possessions(unit, stole->item, 1);
		stole->amount++;
	} else {
		sprintf(work, "%s [%s] had nothing to steal", target->name,
			target->id.text);
		unit_personal_event(unit, today_number, work);
	}

	/* See if we get spotted */
	if(unit->sneaking) chance = 5;
	else chance = 10;

	if(roll_1Dx(100) < chance) {
		unit_personal_event(unit, today_number, "You think you might have been spotted.");
		sprintf(work, "You think you felt %s [%s] stick their hand in your pocket.",
			unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		unit->sneaking = 0;
	}
}
#endif

#ifdef FX_PILFER
static void fx_pilfer(unit_s *unit)
{
	unit_s *target;
	int chance;
	carry_s *carry;
	carry_s *stole;

	if (unit->target_type == SKILL_TARGET_UNIT)
		target = unit->target.unit;
	if(!target) {
		return;
	}
	if(target->race->type == RACE_LEADER) {
		sprintf(work, "The leader %s [%s] is much to watchful.",
			target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		return;
	}

	if(!may_interact_with(unit, target)) {
		sprintf(work, "You wait for %s [%s] to show up, but they never do.", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		return;
	}

	/* See what we can get */
	stole = NULL;
	for(carry = target->carrying; carry; carry = carry->next) {
		if(carry->item->item_type && (carry->item->item_type != ITEM_ITEM))
			continue;
		if(!carry->amount) continue;
		if(carry->equipped == carry->amount) continue;
		if(!stole) stole = carry;
		else {
			if(carry->item->market_value < stole->item->market_value)
				continue;
			else if(carry->item->market_value == stole->item->market_value) {
				if(carry->amount > stole->amount)
					stole = carry;
				else if(carry->amount == stole->amount) {
					if(roll_1Dx(2) & 1)
						stole = carry;
				}
			} else
				stole = carry;
		}
	}
	if(stole) {
		sprintf(work, "You stole 1 %s from %s [%s]", stole->item->name,
			target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		stole->amount--;
		stole = unit_possessions(unit, stole->item, 1);
		stole->amount++;
	} else {
		sprintf(work, "%s [%s] had nothing to steal", target->name,
			target->id.text);
		unit_personal_event(unit, today_number, work);
	}

	/* See if we get spotted */
	if(unit->sneaking) chance = 5;
	else chance = 10;

	if(roll_1Dx(100) < chance) {
		unit_personal_event(unit, today_number, "You think you might have been spotted.");
		sprintf(work, "Someone spotted %s [%s] rifling through your things.",
			unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		unit->sneaking = 0;
	}
}
#endif

#ifdef FX_LAY_CLAIM
/**
 ** FX_CLAIM_AREA
 **	A claim is laid to an area. No other claims may exist there
 **/
static void fx_claim_area(unit_s *unit)
{
unit_s		*camp;
faction_s	*faction;
location_s	*here;
static race_s	*claim;
resource_s	*token, *resource;
static terrain_s *mtow_cache;
/*
 * Validate first claim
 */
	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
	if (!claim) {
		synthetic_tag("clai");
		claim = race_from_tag(0);
	}
	if(unit->faction && unit->faction->resigned)
	    return;
	here = unit->true_location;
	who_is_present(here);
	for (camp = here->interacting; camp; camp = camp->next_visible)
		if (camp->race == claim)
			break;
	if (camp) {
		unit_personal_event(unit, today_number, "This area is already claimed!");
		return;
	}
/*
 * Create a claim or alter a camp?
 */
	if (unit->target_type == SKILL_TARGET_UNIT)
		camp = unit->target.unit;
	if (camp->true_location && camp->true_location != here) {
		unit_personal_event(unit, today_number, "This camp is not here!");
		return;
	}
	if (camp->race && camp->race->type != 0) {
		unit_personal_event(unit, today_number, "This is not a camp!");
		return;
	}
/*
 * Need 1 CP
 */
	faction = unit->faction;
	if (camp->race && camp->size) {
		if (faction != camp->faction) {
			unit_personal_event(unit, today_number, "Camp must be of your faction");
			return;
		}
		if (faction->control_current >= faction->control_max) {
			unit_personal_event(unit, today_number, "Lacks control point to upgrade!");
			return;
		}
		faction->control_current++;
	} else {
		if (faction->control_current + 2 > faction->control_max) {
			unit_personal_event(unit, today_number, "Lacks control point to create!");
			return;
		}
/*
 * Create a camp!
 */
		assign_unit_id(camp);
		camp->same_faction = faction->units;
		faction->units = camp;
		if(here->type == mtow_cache)
			move_to_location(camp, here->outer);	
		else
			move_to_location(camp, here);
		camp->inactive = 0;
		camp->dead = 0;
		camp->full_day = 1;
		camp->size = 1;
		faction->control_current += 2;
	}
/*
 * Target is now a camp
 */
	camp->race = claim;
	camp->size = 1;
	camp->target_type = SKILL_TARGET_UNIT;
	camp->target.unit = unit;
	sprintf(work, "Laid claim to %s [%s]", here->name, here->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(camp, today_number, work);
	sprintf(work, "%s [%s] claimed the area for his clan!", unit->name, unit->id.text);
	location_visible_event(here, today_number, work);

/*
 * Give the claim it's extra taxing coins
 */
	for(resource=here->resources;resource;resource=resource->next) {
		if(resource->type == token_tax) break;
	}
	if(resource) {
		token = new_resource_instance();
		token->next = camp->special_resources;
		camp->special_resources = token;
		token->type = resource->type;
		token->remains = resource->remains * 50;
		token->remains += 50;
		token->remains /= 100;
	}
}
#endif


#ifdef FX_FULL_INFO
/**
 ** FX_OWN_INFO
 **	Figure out information from unit
 **/
static void fx_own_info(unit_s *unit)
{
unit_s		*target;
carry_s		*owns;
/*
 * Validate first claim
 */
	target = unit->target.unit;
	for (owns = target->carrying; owns; owns = owns->next)
		if (owns->amount && owns->item->weight)
			faction_knows_item(unit->faction, owns->item);
}
#endif

/**
 ** ITEM_IS_METAL_MINERAL
 **	Predicates for mineral products
 **/
static int item_is_mineral_metal(item_s *item)
{
	if (item->item_category == 2 || item->item_category == 3)
		return 1;
	return 0;
}

static int item_is_not_mineral_metal(item_s *item)
{
	if (item->item_category != 2 && item->item_category != 3)
		return 1;
	return 0;
}

static int item_is_herb(item_s *item)
{
	if(item->item_category == 5 && item->token_multiplier)
		return 1;
	return 0;
}

/**
 ** ITEM_IS_WOOD
 **	Predicates for wooden products
 **/
static int item_is_wood(item_s *item)
{
	if (item->item_category == 4 && item->token_multiplier)
		return 1;
	return 0;
}

static int item_is_real_wood(item_s *item)
{
	static item_s *wood;
	if(!wood) {
		synthetic_tag("wood");
		wood = item_from_tag(0);
	}
	if(item == wood) return 1;
	return 0;
}

static int item_is_special_wood(item_s *item)
{
	if(item_is_wood(item) && item->item_hidden) return 1;
	return 0;
}

static int item_is_ente(item_s *item)
{
	if(item == token_entertain) return 1;
	return 0;
}

static int item_is_stone(item_s *item)
{
	static item_s *stone;
	if(!stone) {
		synthetic_tag("ston");
		stone = item_from_tag(0);
	}
	if(item == stone) return 1;
	return 0;
}

static int item_is_horse(item_s *item)
{
	static item_s *horse;
	if(!horse) {
		synthetic_tag("hrse");
		horse = item_from_tag(0);
	}
	if(item == horse) return 1;
	return 0;
}

/**
 ** ITEM_IS_SPECIFIC
 **	Predicates for specific products
 **/
static int item_is_specific(item_s *item)
{
	if (item == targeted_item)
		return 1;
	return 0;
}

static int item_is_beast(item_s *item)
{
	if(item->item_type == ITEM_BEAST && item->token_multiplier)
		return 1;
	return 0;
}

static int item_is_gem(item_s *item)
{
	if(item->item_category == 2 && item->item_subcat == 1)
		return 1;
	return 0;
}

static int item_is_not_damageable(item_s *item)
{
    if(item == item_recruit) return 1;
    if(item == token_tax) return 1;
    if(item == token_entertain) return 1;
    return 0;
}

static void fx_damage_resources(location_s *loc, resource_valid cmp, int div)
{
	resource_s *res;
	for(res = loc->resources; res; res = res->next) {
		if(item_is_not_damageable(res->type)) continue;
		if((*cmp)(res->type)) {
			res->amount /= div;
			res->remains /= div;
		}
	}
}

static int fx_resources_exist(location_s *loc, resource_valid cmp)
{
	resource_s *res;
	for(res = loc->resources; res; res = res->next) {
		if((*cmp)(res->type)) return 1;
	}
	return 0;
}

static item_s *fx_create_resources(location_s *loc, resource_valid cmp,
			       int amount, int cchance, int rchance)
{
	item_s *found[100];
	item_s *item;
	location_s *outer;
	int count = 0, tries = 50;
	if(roll_1Dx(100) > cchance) return NULL;
	outer = loc;
	while(outer->type->type == TERRAIN_STRUCTURE)
		outer = outer->outer;

	while (tries-- && !count) {
		for(item = item_list; item && (count < 100); item = item->next) {
			targeted_item = item;
			if(fx_resources_exist(outer, item_is_specific)) continue;
			if((*cmp)(item)) {
				if(roll_1Dx(100) <= rchance) {
					found[count++]=item;
				}
			}
		}
	}
	if(!count) return NULL;
	count = roll_1Dx(count);

	fx_increase_resources(loc, found[count], amount);
	return found[count];
}

static void fx_teach_skill_harvests(location_s *loc, item_s *item, int chance)
{
	skill_s *skill;
	experience_s *exp;
	if(roll_1Dx(100) > chance) return;
	for(skill = skills_list; skill; skill = skill->next) {
		if(!skill->specialist) continue;
		if(skill->student) continue;
		if(skill->harvests == item) {
			exp = new_experience_instance();
			exp->skill = skill;
			exp->points =  skill->for_level;
			exp->next = loc->skills;
			adjust_experience(exp, 1);
			loc->skills = exp;
			return;
		}
	}
	return;
}


/******************************************************************************/
/**
 ** FX_DUPLICATE_RESOURCE
 **	Increase the amount of resource available
 **/
static void fx_duplicate_resource(location_s *location, location_s *outer, resource_valid cmp, int percent, int max)
{
resource_s	*resource;
resource_s	*token;
/*
 * Each ressource may yield a new amount of tokens
 */
	for (resource = outer->resources; resource; resource = resource->next)
		if ((*cmp)(resource->type)) {
			int amt;
			token = location_has_resource(location, resource->type, 1);
			amt = resource->remains * percent;
			amt += 50;
			amt /= 100;
			if (max && amt > max)
				amt *= max;
			token->remains += amt;
		}
}

#ifdef FX_BUILDING_COMPLETE
static void fx_special_building_effects(location_s *loc, location_s *newloc,
					terrain_s *terr)
{
	item_s *created = 0;
	int count;
	switch(terr->special_effect) {
#ifdef FX_MTOWER
		case FX_MTOWER:
			if(!fx_resources_exist(loc, item_is_herb))
				fx_create_resources(newloc, item_is_herb,
						roll_1Dx(10), 50, 20);
			break;
#endif
#ifdef FX_MINE_PRODUCTION
		case FX_MINE_PRODUCTION:
			/* Duplicate resources */
			fx_duplicate_resource(newloc, loc, item_is_mineral_metal, 100, 0);
			/* Decrease all non-mineral production in the area by 50%*/
			fx_damage_resources(loc, item_is_not_mineral_metal, 2);
			/* Add 10 stone only for the owner if no minerals avail */
			if(!fx_resources_exist(loc, item_is_mineral_metal))
				fx_create_resources(newloc, item_is_stone, 10, 100, 100);
			else {
				/* Possibly allow new hidden gems */
				created = fx_create_resources(newloc, item_is_gem,
						2+roll_1Dx(3), 20, 20);
				/* Possibly teach skill */
				if(created) {
					fx_teach_skill_harvests(newloc, created, 25);
				}
			}
			break;
#endif
#ifdef FX_LMYD_PRODUCTION
		case FX_LMYD_PRODUCTION:
			/* Duplicate resources */
			fx_duplicate_resource(newloc, loc, item_is_wood, 100, 0);
			/* Decrease all mineral or metal production in area */
			fx_damage_resources(loc, item_is_mineral_metal, 2);
			/* add 5 wood if location doesn't provide wood */
			if(!fx_resources_exist(loc, item_is_wood))
				fx_create_resources(newloc, item_is_real_wood, 5, 100, 100);
			else {
				/* Possibly create resource for special type of wood */
				created = fx_create_resources(newloc, item_is_special_wood,
						2+roll_1Dx(3), 20, 20);
				/* Possibly teach skill */
				if(created) {
					fx_teach_skill_harvests(newloc, created, 25);
				}
			}
			break;
#endif
#ifdef FX_RANCH_PRODUCTION
		case FX_RANCH_PRODUCTION:
			/* duplicate the existing resources */
			fx_duplicate_resource(newloc, loc, item_is_beast, 50, 0);
			/* Allow up to 5 horses if no beasts at location */
			if(!fx_resources_exist(loc, item_is_beast))
				fx_create_resources(newloc, item_is_horse, 5, 100, 100);
			else {
				/* Allow 1 or 2 beast resources normally not found */
				count = 1 + roll_1Dx(2);
				while(count) {
					created = fx_create_resources(newloc, item_is_beast,
							2+roll_1Dx(3), 100, 20);
					/* Possibly teach skill */
					if(created) {
						fx_teach_skill_harvests(newloc, created, 25);
					}
					count--;
				}
			}
			break;
#endif
#ifdef FX_INN_PRODUCTION
		case FX_INN_PRODUCTION:
			fx_duplicate_resource(newloc, loc, item_is_ente, 50, 0);
			break;
#endif
#ifdef FX_CASTLE
	    case FX_CASTLE:
			targeted_item = token_tax;
			fx_duplicate_resource(newloc, loc, item_is_specific, 50, 0);
			break;
#endif
#ifdef FX_FORTRESS
	    case FX_FORTRESS:
			/* Nothing special to do */
			break;
#endif
#ifdef FX_MARKET_PRODUCTION
	    case FX_MARKET_PRODUCTION:
			/* Start up a local economy */
			loc->first_market = newloc;
			break;
#endif
		default:
			printf("Unimplemented building special FX %d for [%s]\n",
					terr->special_effect, terr->tag.text);
		case 0:
			break;
	}
}

#if defined(FX_CASTLE) || defined(FX_FORTRESS)
static int location_has_fortress(location_s *hex, location_s *loc, unit_s *unit)
{
	location_s *inner;
	for(inner = loc->inner; inner; inner = inner->next_inner) {
		if(inner->type->special_effect == FX_FORTRESS) {
			sprintf(work, "%s [%s] already contains a fortress.",
				hex->name, hex->id.text);
			unit_personal_event(unit, today_number, work);
			return 1;
		}
		if(location_has_fortress(hex, inner, unit))
			return 1;
	}
	return 0;
}

static int location_has_castle(location_s *hex, location_s *loc, unit_s *unit)
{
	location_s *inner;
	for(inner = loc->inner; inner; inner = inner->next_inner) {
		if(inner->type->special_effect == FX_CASTLE) {
			sprintf(work, "%s [%s] already contains a castle.",
				hex->name, hex->id.text);
			unit_personal_event(unit, today_number, work);
			return 1;
		}
		if(location_has_castle(hex, inner, unit))
			return 1;
	}
	return 0;
}
#endif

int fx_race_preconditions(race_s *race, unit_s *unit)
{
	static race_s *cache_trit;
	static terrain_s *cache_ocean;
	static terrain_s *cache_lake;
	location_s *out;

	if(!cache_ocean) {
		synthetic_tag("oceans");
		cache_ocean = terrain_from_tag(0);
	}
	if(!cache_lake) {
		synthetic_tag("lake");
		cache_lake = terrain_from_tag(0);
	}
	if(!cache_trit) {
		synthetic_tag("trit");
		cache_trit = race_from_tag(0);
	}

	if(race == cache_trit) {
		direction_s *exit;
		out = unit->current;
		while(out->outer) out = out->outer;
		if(out->type == cache_lake) return 1;
		if(out->type == cache_ocean) return 1;
		for(exit = out->exits; exit; exit= exit->next) {
			if(exit->toward->type == cache_lake) return 1;
			if(exit->toward->type == cache_ocean) return 1;
		}
		return 0;
	}

	return 1;
}

int fx_product_preconditions(item_s *item, unit_s *unit)
{
	unit_s *target;
	location_s *loc;
	direction_s *dir;
	resource_s *res;
	switch(item->special_effects) {
		case FX_LAY_CLAIM:
			if(unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
			target = unit->target.unit;
			if(!may_interact_with(unit, target)) return 0;
			if(target->size <= 0 || target->dead || target->is_captive)
				return 0;
			if(target->true_location &&
					(target->true_location != unit->true_location)) return 0;
			return 1;
		case FX_CULTIVATE_WHEAT:
		case FX_CULTIVATE_RICE:
			loc = unit->true_location;
			if(loc->cultivated) return 0;
			return 1;
		case FX_FIND_LAND:
		    if(unit->target_type != ARGUMENT_IS_TERRAIN_TAG) return 0;
		    if(unit->target.terrain->type != TERRAIN_COUNTRY) return 0;
		    return 1;
		case FX_LOCATE_SHELTER:
		    if(unit->target_type != ARGUMENT_IS_TERRAIN_TAG) return 0;
		    if(unit->target.terrain->type != TERRAIN_STRUCTURE) return 0;
		    return 1;
		case FX_PILLAGE:
			res = location_has_resource(unit->true_location, token_tax, 0);
			if(res && res->remains) return 1;
			return 0;
		case FX_RANSOM:
		case FX_EXECUTE:
		    /* make sure we have the prisoner */
		    if(unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
			target = unit->target.unit;
		    if(!target->is_captive) return 0;
		    if(target->leader != unit) return 0;
			if(target->size <= 0 || target->dead)
				return 0;
		    return 1;
		case FX_AMBUSH:
		    if(unit->true_location->type == neutral_city) return 0;
			if(!eligible_attacker(unit)) return 0;
			if(unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
			target = unit->target.unit;
			if(!may_interact_with(unit, target)) return 0;
			if(target->size <= 0 || target->dead || target->is_captive)
				return 0;
			if(!eligible_defender(target)) return 0;
		    return 1;
		case FX_PILFER:
		    if(unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
		    target = unit->target.unit;
			if(!may_interact_with(unit, target)) return 0;
			if(target->size <= 0 || target->dead || target->is_captive)
				return 0;
		    if(target->race->type == RACE_LEADER) return 0;
		    return 1;
		case FX_PICKPOCKET:
		    if(unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
		    target = unit->target.unit;
			if(!may_interact_with(unit, target)) return 0;
			if(target->size <= 0 || target->dead || target->is_captive)
				return 0;
		    if(target->race->type != RACE_LEADER) return 0;
		    return 1;
		case FX_WIZARDS_CURSE:
			if(unit->true_location->cursed) return 0;
			if(!unit->true_location->type->solid) return 0;
			return 1;
		case FX_CROP_BLESSING:
		    if(unit->true_location->blessed) return 0;
		    if(!unit->true_location->type->solid) return 0;
		    return 1;
		case FX_HYPNOTIC_CALL:
		case FX_CALL_TO_BATTLE:
		case FX_ILLUSION_TORTURED_ALLY:
			if (unit->target_type != ARGUMENT_IS_UNIT_ID) return 0;
		    target = unit->target.unit;
			if(target->size <= 0 || target->dead || target->is_captive)
				return 0;
		    if(target->race->type != RACE_LEADER) return 0;
			return 1;
		case FX_GATE_OVERWORLD:
			if(unit->true_location->region == REGION_OVERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_OVERWORLD) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_OVERWORLD) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_UNDERWORLD:
			if(unit->true_location->region == REGION_UNDERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_UNDERWORLD) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_OVERWORLD) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_VOID:
			if(unit->true_location->region == REGION_VOID) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_VOID) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_OVERWORLD) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_WATER:
			if(unit->true_location->region == REGION_WATER) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_WATER) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_WATER) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_AIR:
			if(unit->true_location->region == REGION_AIR) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_AIR) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_AIR) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_FIRE:
			if(unit->true_location->region == REGION_FIRE) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_FIRE) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_FIRE) return 0;
				}
				return 1;
			}
			return 0;
		case FX_GATE_EARTH:
			if(unit->true_location->region == REGION_EARTH) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_EARTH) return 0;
				/*
				 * Make sure there are no directions from this location
				 * to the target plane
				 */
				for(dir = unit->true_location->exits; dir; dir = dir->next) {
					if(dir->toward->region == REGION_EARTH) return 0;
				}
				return 1;
			}
			return 0;
		case FX_SENDOTHER_AIR:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_AIR) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_AIR) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDOTHER_FIRE:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_FIRE) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_FIRE) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDOTHER_OVERWORLD:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_OVERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_OVERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDOTHER_VOID:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_VOID) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_VOID) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDOTHER_WATER:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_WATER) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_WATER) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_UNDERWORLD:
		    if(unit->true_location->region == REGION_UNDERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_UNDERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_FIRE:
		    if(unit->true_location->region == REGION_FIRE) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_FIRE) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_VOID:
		    if(unit->true_location->region == REGION_VOID) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_VOID) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_AIR:
		    if(unit->true_location->region == REGION_AIR) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_AIR) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_EARTH:
		    if(unit->true_location->region == REGION_EARTH) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_EARTH) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_WATER:
		    if(unit->true_location->region == REGION_WATER) return 0;
			if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_WATER) return 0;
				return 1;
			}
		    return 0;
		case FX_SENDSELF_OVERWORLD:
		    if(unit->true_location->region == REGION_OVERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_OVERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_WALK_DEAD:
		    if(unit->true_location->region == REGION_UNDERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_UNDERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_SLEEP_WITH_FISH:
		    if(unit->true_location->region == REGION_WATER) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_WATER) return 0;
				return 1;
			}
		    return 0;
		case FX_MUMMERS_DANCE:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_UNDERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_UNDERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_EMPTY_SHELL:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_VOID) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_VOID) return 0;
				return 1;
			}
		    return 0;
		case FX_PIERCE_THE_VEIL:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_OVERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_OVERWORLD) return 0;
				return 1;
			}
		    return 0;
		case FX_DROWNED_CARCASS:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_WATER) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_WATER) return 0;
				return 1;
			}
		    return 0;
		case FX_BURIED_CORPSE:
		    if(!unit->stack) return 0;
		    if(unit->true_location->region == REGION_EARTH) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_EARTH) return 0;
				return 1;
			}
		    return 0;
		case FX_FILL_VOID:
		    if(unit->true_location->region == REGION_VOID) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_VOID) return 0;
				return 1;
			}
		    return 0;
		case FX_PALE_WORLD:
			if(unit->true_location->region == REGION_OVERWORLD) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_OVERWORLD) return 0;
				return 1;
			}
			return 0;
		case FX_SIX_FEET_UNDER:
			if(unit->true_location->region == REGION_EARTH) return 0;
		    if(unit->target_type == ARGUMENT_IS_EMPTY ||
					unit->target_type == ARGUMENT_IS_LOCATION_ID) {
				loc= unit->target.location;
				if(loc && loc->region != REGION_EARTH) return 0;
				return 1;
			}
			return 0;
		default:
			return 1;
	}
	return 1;
}

int fx_building_preconditions(terrain_s *terr, unit_s *unit)
{
	static terrain_s *cache_ocean;
	static terrain_s *cache_lake;
	location_s *out, *in;

	if(!cache_ocean) {
		synthetic_tag("oceans");
		cache_ocean = terrain_from_tag(0);
	}
	if(!cache_lake) {
		synthetic_tag("lake");
		cache_lake = terrain_from_tag(0);
	}

	if(terr->type != TERRAIN_STRUCTURE) return 1;

	/* No building may be built on water */
	if(unit->current->type == cache_ocean ||
	   unit->current->type == cache_lake)
		return 0;

	/* No building may be built if one of that type already exists here */
	out = unit->current;
	while(out->type->type == TERRAIN_STRUCTURE && out->outer)
		out = out->outer;
        for(in = out->inner; in; in = in->next_inner)
		if(in->type == terr)
			return 0;

	switch(terr->special_effect) {
#ifdef FX_CASTLE
	    case FX_CASTLE: {
		/*
		 * A castle can only be built if there are none in neighbor
		 * hexes (or in the inner hex (for inside a city/town)
                 */
		direction_s *exit;
		out = unit->current;
		while(out->outer) out = out->outer;
		if(location_has_castle(out, out, unit)) {
			return 0;	
		}
		if(location_has_fortress(out, out, unit)) {
			return 0;	
		}
		for(exit = unit->current->exits; exit; exit = exit->next) {
			if(location_has_castle(exit->toward, exit->toward, unit))
				return 0;
		}
		return 1;
	    }
#endif
#ifdef FX_FORTRESS
	    case FX_FORTRESS: {
		/*
		 * A fortress can only be built if there are no castles in
		 * the same hex.
                 */
		out = unit->current;
		while(out->outer) out = out->outer;
		if(location_has_castle(out, out, unit)) {
			return 0;	
		}
		return 1;
	    }
#endif
	    default:
		return 1;
	}
	return 1;
}

/**
 ** FX_BUILT
 **	A structure was built locally
 **/
static void fx_built(unit_s *invoker, skill_s *effective)
{
location_s	*here, *inner, *last;
terrain_s	*type;
/*
 * Which terrain
 */
	type = effective->specific.terrain;
	here = invoker->true_location;
	last = 0;
	for (inner = here->inner; inner; inner = inner->next_inner)
		if (inner->type == type) {
			unit_personal_event(invoker, today_number, "Structure already exists here!");
			return;
		} else
			last = inner;
	inner = random_location_id();
	printf("Structure built is: %s at %s\n", type->name, here->id.text);
	if (last)
		last->next_inner = inner;
	else
		here->inner = inner;
	inner->outer = here;
	inner->type  = type;
	inner->name  = strdup(type->name);
	sprintf(work, "%s was built by %s [%s]", type->name, invoker->name, invoker->id.text);
	location_visible_event(here, today_number, work);
	move_to_location(invoker, here);
	fx_special_building_effects(here, inner, type);
}
#endif


/**
 ** FX_EXECUTE_EVENT
 **	Execute special effects
 **/
int fx_execute_event(item_s *fx, int amount, unit_s *invoker,
		skill_s *effective, order_s *current)
{
	switch (fx->special_effects) {
#ifdef FX_FAR_EYE
		case FX_FAR_EYE:
			fx_far_eye(invoker);
			return 1;
#endif
#ifdef FX_TALE_BONES
		case FX_TALE_BONES:
			fx_tale_bones(invoker);
			return 1;
#endif
#ifdef FX_EAGLE_EYE
		case FX_EAGLE_EYE:
			fx_eagle_eye(invoker);
			return 1;
#endif
#ifdef FX_EXECUTE
		case FX_EXECUTE:
			fx_execute(invoker);
			return 1;
#endif
#ifdef FX_RANSOM
		case FX_RANSOM:
			fx_ransom(invoker);
			return 1;
#endif
#ifdef FX_CROP_BLESSING
		case FX_CROP_BLESSING:
			fx_crop_blessing(invoker);
			return 1;
#endif
#ifdef FX_WIZARDS_CURSE
		case FX_WIZARDS_CURSE:
			fx_wizards_curse(invoker);
			return 1;
#endif
#ifdef FX_PIERCE_THE_VEIL
		case FX_PIERCE_THE_VEIL:
			fx_sendother_damage(invoker, REGION_OVERWORLD);
			return 1;
#endif
#ifdef FX_DROWNED_CARCASS
		case FX_DROWNED_CARCASS:
			fx_sendother_damage(invoker, REGION_WATER);
			return 1;
#endif
#ifdef FX_BURIED_CORPSE
		case FX_BURIED_CORPSE:
			fx_sendother_damage(invoker, REGION_EARTH);
			return 1;
#endif
#ifdef FX_MUMMERS_DANCE
		case FX_MUMMERS_DANCE:
			fx_sendother_damage(invoker, REGION_UNDERWORLD);
			return 1;
#endif
#ifdef FX_EMPTY_SHELL
		case FX_EMPTY_SHELL:
			fx_sendother_damage(invoker, REGION_VOID);
			return 1;
#endif
#ifdef FX_SIX_FEET_UNDER
		case FX_SIX_FEET_UNDER:
			fx_sendself_damage(invoker, REGION_EARTH);
			return 1;
#endif
#ifdef FX_PALE_WORLD
		case FX_PALE_WORLD:
			fx_sendself_damage(invoker, REGION_OVERWORLD);
			return 1;
#endif
#ifdef FX_FILL_VOID
		case FX_FILL_VOID:
			fx_sendself_damage(invoker, REGION_VOID);
			return 1;
#endif
#ifdef FX_WALK_DEAD
		case FX_WALK_DEAD:
			fx_sendself_damage(invoker, REGION_UNDERWORLD);
			return 1;
#endif
#ifdef FX_SLEEP_WITH_FISH
		case FX_SLEEP_WITH_FISH:
			fx_sendself_damage(invoker, REGION_WATER);
			return 1;
#endif
#ifdef FX_GATE_OVERWORLD
		case FX_GATE_OVERWORLD:
			fx_gate(invoker, REGION_OVERWORLD);
			return 1;
#endif
#ifdef FX_GATE_UNDERWORLD
		case FX_GATE_UNDERWORLD:
			fx_gate(invoker, REGION_UNDERWORLD);
			return 1;
#endif
#ifdef FX_GATE_VOID
		case FX_GATE_VOID:
			fx_gate(invoker, REGION_VOID);
			return 1;
#endif
#ifdef FX_GATE_WATER
		case FX_GATE_WATER:
			fx_gate(invoker, REGION_WATER);
			return 1;
#endif
#ifdef FX_GATE_AIR
		case FX_GATE_AIR:
			fx_gate(invoker, REGION_AIR);
			return 1;
#endif
#ifdef FX_GATE_FIRE
		case FX_GATE_FIRE:
			fx_gate(invoker, REGION_FIRE);
			return 1;
#endif
#ifdef FX_GATE_EARTH
		case FX_GATE_EARTH:
			fx_gate(invoker, REGION_EARTH);
			return 1;
#endif
#ifdef FX_SENDOTHER_OVERWORLD
		case FX_SENDOTHER_OVERWORLD:
			fx_sendother(invoker, REGION_OVERWORLD);
			return 1;
#endif
#ifdef FX_SENDOTHER_VOID
		case FX_SENDOTHER_VOID:
			fx_sendother(invoker, REGION_VOID);
			return 1;
#endif
#ifdef FX_SENDOTHER_WATER
		case FX_SENDOTHER_WATER:
			fx_sendother(invoker, REGION_WATER);
			return 1;
#endif
#ifdef FX_SENDOTHER_FIRE
		case FX_SENDOTHER_FIRE:
			fx_sendother(invoker, REGION_FIRE);
			return 1;
#endif
#ifdef FX_SENDOTHER_AIR
		case FX_SENDOTHER_AIR:
			fx_sendother(invoker, REGION_AIR);
			return 1;
#endif
#ifdef FX_SENDSELF_EARTH
		case FX_SENDSELF_EARTH:
			fx_sendself(invoker, REGION_EARTH);
			return 1;
#endif
#ifdef FX_SENDSELF_OVERWORLD
	    case FX_SENDSELF_OVERWORLD:
			fx_sendself(invoker, REGION_OVERWORLD);
			return 1;
#endif
#ifdef FX_SENDSELF_UNDERWORLD
		case FX_SENDSELF_UNDERWORLD:
			fx_sendself(invoker, REGION_UNDERWORLD);
			return 1;
#endif
#ifdef FX_SENDSELF_FIRE
		case FX_SENDSELF_FIRE:
			fx_sendself(invoker, REGION_FIRE);
			return 1;
#endif
#ifdef FX_SENDSELF_VOID
		case FX_SENDSELF_VOID:
			fx_sendself(invoker, REGION_VOID);
			return 1;
#endif
#ifdef FX_SENDSELF_AIR
	    case FX_SENDSELF_AIR:
			fx_sendself(invoker, REGION_AIR);
			return 1;
#endif
#ifdef FX_SENDSELF_WATER
		case FX_SENDSELF_WATER:
			fx_sendself(invoker, REGION_WATER);
			return 1;
#endif
#ifdef FX_PILLAGE
	    case FX_PILLAGE:
			fx_pillage(invoker, effective);
			return 1;
#endif
#ifdef FX_AMBUSH
	    case FX_AMBUSH:
			fx_ambush(invoker);
			return 1;
#endif
#ifdef FX_PICKPOCKET
	    case FX_PICKPOCKET:
			fx_pickpocket(invoker);
			return 1;
#endif
#ifdef FX_PILFER
	    case FX_PILFER:
			fx_pilfer(invoker);
			return 1;
#endif
#ifdef FX_LAY_CLAIM
	    case FX_LAY_CLAIM:
			fx_claim_area(invoker);
			return 1;
#endif
#ifdef FX_DENOUNCE_CLAIM
		case FX_DENOUNCE_CLAIM:
			fx_denounce_claim(invoker);
			return 1;
#endif
#ifdef FX_FULL_INFO
		case FX_FULL_INFO:
			fx_own_info(invoker);
			return 1;
#endif
#ifdef FX_BUILDING_COMPLETE
		case FX_BUILDING_COMPLETE:
			fx_built(invoker, effective);
			return 1;
#endif
#ifdef FX_TRANSCEND
		case FX_TRANSCEND:
			fx_transcend(invoker);
			return 1;
#endif
#ifdef FX_ASCEND
	    case FX_ASCEND:
			fx_ascend(invoker);
			return 1;
#endif
#ifdef FX_APOTHEOSIS
		case FX_APOTHEOSIS:
			fx_apotheosis(invoker);
			return 1;
#endif
#ifdef FX_FURTHER_EWELIN
		case FX_FURTHER_EWELIN:
			fx_further_ewelin(invoker);
			return 1;
#endif
#ifdef FX_FURTHER_VOLD
	    case FX_FURTHER_VOLD:
			fx_further_vold(invoker);
			return 1;
#endif
#ifdef FX_FURTHER_ALG
		case FX_FURTHER_ALG:
			fx_further_algirdas(invoker);
			return 1;
#endif
#ifdef FX_FARTHER_FAFR
		case FX_FARTHER_FAFR:
			fx_farther_fafr(invoker);
			return 1;
#endif
#ifdef FX_BURN_BRIDGE
		case FX_BURN_BRIDGE:
			fx_burn_bridges(invoker);
			return 1;
#endif
#ifdef FX_MASTER_BEASTS
		case FX_MASTER_BEASTS:
			fx_master_beasts(invoker);
			return 1;
#endif
#ifdef FX_ORIENT
		case FX_ORIENT:
			fx_orient(invoker);
			return 1;
#endif
#ifdef FX_FIND_LAND
		case FX_FIND_LAND:
			fx_find_land(invoker);
			return 1;

#endif
#ifdef FX_LOCATE_SHELTER
		case FX_LOCATE_SHELTER:
			fx_locate_shelter(invoker);
			return 1;
#endif
#ifdef FX_DISTANT_VISION
		case FX_DISTANT_VISION:
			fx_distant_vision(invoker);
			return 1;
#endif
#ifdef FX_GLOW_EYES
		case FX_GLOW_EYES:
			fx_glow_eyes(invoker);
			return 1;
#endif
#ifdef FX_FEEL_FLOW
		case FX_FEEL_FLOW:
			fx_feel_flow(invoker);
			return 1;
#endif
#ifdef USES_MANA_POINTS
#ifdef FX_EVALUATE_MANA
		case FX_EVALUATE_MANA:
			fx_evaluate_mana(invoker);
			return 1;
#endif
#endif
#ifdef FX_CHANGEMORPH
		case FX_CHANGEMORPH:
			fx_changemorph(invoker);
			return 1;
#endif
#ifdef FX_IDENTIFY
		case FX_IDENTIFY:
			fx_identify(invoker);
			return 1;
#endif
#ifdef FX_REVEAL_ARTISAN
	    case FX_REVEAL_ARTISAN:
			fx_reveal_artisan(invoker);
			return 1;
#endif
#ifdef FX_REVEAL_SAIL
		case FX_REVEAL_SAIL:
			fx_reveal_sailing(invoker);
			return 1;
#endif
#ifdef FX_REVEAL_LEADERSHIP
		case FX_REVEAL_LEADERSHIP:
			fx_reveal_leadership(invoker);
			return 1;
#endif
#ifdef FX_REVEAL_SCOUTING
		case FX_REVEAL_SCOUTING:
			fx_reveal_scouting(invoker);
			return 1;
#endif
#ifdef FX_DIVINE_REVEAL
		case FX_DIVINE_REVEAL:
			fx_divine_revelation(invoker);
			return 1;
#endif
#ifdef FX_ACQUIRE_ARTISAN
		case FX_ACQUIRE_ARTISAN:
			fx_acquire_artisan(invoker);
			return 1;
#endif
#ifdef FX_WARRIOR_REVEAL
		case FX_WARRIOR_REVEAL:
			fx_reveal_combat(invoker);
			return 1;
#endif
#ifdef FX_NATIVES_EYE
		case FX_NATIVES_EYE:
			fx_natives_eye(invoker);
			return 1;
#endif
#ifdef FX_RECRUIT_RACE
		case FX_RECRUIT_RACE:
			fx_recruit_race(invoker, effective);
			return 1;
#endif
#ifdef FX_INCREASE_INT
		case FX_INCREASE_INT:
			fx_increase_int(invoker, amount);
			return 1;
#endif
#ifdef FX_SPYING
		case FX_SPYING:
			fx_spying(invoker, effective);
			return 1;
#endif
#ifdef FX_SEED_EARTH
		case FX_SEED_EARTH:
			fx_seed_earth(invoker);
			return 1;
#endif
#ifdef FX_CULTIVATE_RICE
		case FX_CULTIVATE_RICE:
			fx_cultivate_rice(invoker);
			return 1;
#endif
#ifdef FX_CULTIVATE_WHEAT
		case FX_CULTIVATE_WHEAT:
			fx_cultivate_wheat(invoker);
			return 1;
#endif
#ifdef FX_AID_IN_RITUAL
		case FX_AID_IN_RITUAL:
			fx_aid_in_ritual(invoker, amount);
			return 1;
#endif
#ifdef FX_CALL_BEASTS
		case FX_CALL_BEASTS:
			fx_call_the_beasts(invoker);
			return 1;
#endif
#ifdef FX_UNEARTH_ARCANA
		case FX_UNEARTH_ARCANA:
			fx_unearth_arcana(invoker);
			return 1;
#endif
#ifdef FX_SEARCH
		case FX_SEARCH:
			fx_search(invoker, effective);
			return 1;
#endif
#ifdef FX_DETECT_BEAST
		case FX_DETECT_BEAST:
			fx_detect_beast(invoker);
			return 1;
#endif
#ifdef FX_SENSE_PEOPLE
		case FX_SENSE_PEOPLE:
			fx_sense_people(invoker);
			return 1;
#endif
#ifdef FX_DETECT_LIFE
		case FX_DETECT_LIFE:
			fx_detect_life(invoker);
			return 1;
#endif
#ifdef FX_DETECT_ENEMIES
		case FX_DETECT_ENEMIES:
			fx_detect_enemies(invoker);
			return 1;
#endif
#ifdef FX_ILLUSION_TORTURED_ALLY
		case FX_ILLUSION_TORTURED_ALLY:
			fx_illusion_tortured_ally(invoker);
			return 1;
#endif
#ifdef FX_HYPNOTIC_CALL
		case FX_HYPNOTIC_CALL:
			fx_hypnotic_call(invoker);
			return 1;
#endif
#ifdef FX_CALL_TO_BATTLE
		case FX_CALL_TO_BATTLE:
			fx_call_to_battle(invoker);
			return 1;
#endif
#ifdef FX_INSPIRATION
		case FX_INSPIRATION:
			fx_inspiration(invoker, amount);
			return 1;
#endif
#ifdef FX_ONCE
		case FX_ONCE:
			printf("Unimplemented FX %d for [%s] by %s\n",
					fx->special_effects, fx->tag.text, invoker->id.text);
			return 1;
#endif
		default:
			printf("Unimplemented FX %d for [%s] by %s\n",
					fx->special_effects, fx->tag.text, invoker->id.text);
		case 0:
			break;
	}
	return 0;
}



/**
 ** FX_LOCATION_INIT
 **	Some locations have special properties
 **/
void fx_location_init(location_s *location)
{
	switch (location->type->special_effect) {
#ifdef FX_CASTLE
		case FX_CASTLE:
			targeted_item = token_tax;
			fx_duplicate_resource(location, location->outer,
					item_is_specific, 50, 0);
			break;
#endif
#ifdef FX_FORTRESS
		case FX_FORTRESS:
			break;
#endif
#ifdef FX_MTOWER
		case FX_MTOWER:
			break;
#endif
#ifdef FX_MINE_PRODUCTION
		case FX_MINE_PRODUCTION:
			fx_duplicate_resource(location, location->outer,
					item_is_mineral_metal, 100, 0);
			break;
#endif
#ifdef FX_RANCH_PRODUCTION
		case FX_RANCH_PRODUCTION:
			fx_duplicate_resource(location, location->outer, item_is_beast,
				   	50, 0);
			break;
#endif
#ifdef FX_LMYD_PRODUCTION
		case FX_LMYD_PRODUCTION:
			fx_duplicate_resource(location, location->outer, item_is_wood,
					100, 0);
			break;
#endif
#ifdef FX_INN_PRODUCTION
		case FX_INN_PRODUCTION:
			fx_duplicate_resource(location, location->outer, item_is_ente,
					50, 0);
			break;
#endif
#ifdef FX_MARKET_PRODUCTION
		case FX_MARKET_PRODUCTION:
			/* nothing needs to be done for markets */
			/* Maybe see if a 1 turn buy/sell shows up? */
			break;
#endif
		default:
			printf("Unimplemented FX %d for [%s]\n",
					location->type->special_effect, location->type->tag.text);
		case 0:
			break;
	}
}



/******************************************************************************/

#ifdef FX_SCROLL_XXXX
/**
 ** FX_SCROLL_XXXX
 **	Special: gain experience in a skill
 **/
static void fx_scroll(unit_s *owner, carry_s *item)
{
experience_s	*gained;
/*
 * Add to experience
 */
	gained = unit_experiences(owner, item->item->use_skill, 1);
	(void)add_to_experience(owner, gained, item->item->use_skill, item->equipped * 30 * SKILL_POINTS_PER_DAY);
	item->amount -= item->equipped;
	item->equipped = 0;
}
#endif


/**
 ** FX_END_OF_TURN
 **	Triggers on end-of-turn special FX
 **/
void fx_end_of_turn(unit_s *unit, carry_s *item)
{
	switch (item->item->special_effects) {
#ifdef FX_SEEK_CITY
	    case FX_SEEK_CITY:
		fx_seeking_city(unit);
		return;
#endif
#ifdef FX_WAYFINDER
	    case FX_WAYFINDER:
		if (item->equipped == 0)
			return;
		fx_use_wayfinder(unit);
		return;
#endif
#ifdef FX_SCROLL_XXXX
	    case FX_SCROLL_XXXX:
		if (item->equipped == 0)
			return;
		fx_scroll(unit, item);
		return;
#endif
	    default:
		break;
	}
}
