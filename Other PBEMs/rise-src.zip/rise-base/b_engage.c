/* $Id: b_engage.c,v 1.29 2001/02/11 22:21:43 jtraub Exp $
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "parser.h"


/**
 ** Locally set variables
 **/
static figure_s	*recycle_units;
static actor_s	*recycle_actors;
static skill_s	*tact_cache,
		*stra_cache,
		*fana_cache;
static item_s	*tired_cache,
		*wariness_cache, *treb_cache, *pali_cache;
static terrain_s *tower_cache, *fortr_cache;
figure_s	*acting_units;
side_s		attackers, defenders;
square_s	battlefield[6][3];


/**
 ** ALLOCATE_NEW_FIGURE
 **	Pull from previous battle recycle, or allocate new
 **/
figure_s *allocate_new_figure(void)
{
figure_s	*newest;
/*
 * Anything in cache?
 */
	if ((newest = recycle_units) != 0) {
		recycle_units = newest->same_side;
		memset(newest, 0, sizeof(*newest));
	} else
		newest = mallocator(figure_s);
	return newest;
}


/**
 ** FREE_ALL_SOLDIERS
 **	The battle is over
 **/
void free_all_soldiers(void)
{
figure_s	*unit;
/*
 * Free all
 */
	while ((unit = attackers.units) != 0) {
		attackers.units = unit->same_side;
		unit->same_side = recycle_units;
		recycle_units = unit;
	}
	while ((unit = defenders.units) != 0) {
		defenders.units = unit->same_side;
		unit->same_side = recycle_units;
		recycle_units = unit;
	}
}


/**
 ** ALLOCATE_NEW_ACTOR
 **	Pull from previous battle recycle, or allocate new
 **/
actor_s *allocate_new_actor(void)
{
actor_s	*newest;
/*
 * Anything in cache?
 */
	if ((newest = recycle_actors) != 0) {
		recycle_actors = newest->next;
		memset(newest, 0, sizeof(*newest));
	} else
		newest = mallocator(actor_s);
	return newest;
}


/**
 ** FREE_ACTOR_INSTANCE
 **	Free all actors (self-acting items)
 **/
void free_actor_instance(actor_s *actor)
{
/*
 * End of recursion
 */
	if (!actor)
		return;
/*
 * Recursion
 */
	free_actor_instance(actor->next);
	actor->next = recycle_actors;
	free(actor->damage);
	actor->damage = NULL;
	recycle_actors = actor;
}


/**
 ** REPORT_SIDE
 **	Report one side's forces
 **/
static void report_side(FILE *report, side_s *side, char *name)
{
figure_s	*forces;
unit_s		*unit;
char		*sep;
carry_s		*equipment;
/*
 * Which side?
 */
	fprintf(report, "%s:\n", name);
	for (forces = side->units; forces; forces = forces->same_side) {
		unit = forces->unit;
		start_fold_string(unit->name);
		add_fold_tag(&unit->id);
		if(unit->setting_advert) {
		    add_fold_string(", anonymous");
		} else {
		    add_fold_string(", of ");
		    add_fold_string(unit->faction->name);
		    add_fold_tag(&unit->faction->id);
		}
		add_fold_string(", ");
		if (unit->size > 1) {
			add_fold_integer(unit->size);
			add_fold_char(' ');
			add_fold_string(unit->race->plural);
		} else
			add_fold_string(unit->race->name);
		add_fold_string(comma);
		add_fold_string(visual_enum(forces->rank, battlefield_ranks));
		add_fold_char(' ');
		add_fold_string(visual_enum(forces->file, battlefield_files));
		if (forces->flying)
			add_fold_string(", flying");
		if(forces->fortress) {
			add_fold_string(", in a fortress");
		} else {
			if(forces->tower) {
				add_fold_string(", in a tower");
			}
		}
		if(report == full_report || report == long_report) {
			sep = ", with: ";
			for(equipment = unit->carrying; equipment; equipment=equipment->next) {
				if(equipment->amount &&
			  	   (equipment->item->equip_bonus.melee ||
                          	    equipment->item->equip_bonus.missile ||
			  	    equipment->item->equip_bonus.defense) &&
				   (equipment->item->item_type == ITEM_FOLLOWER ||
				    equipment->item->item_type == ITEM_BEAST ||
					equipment->item == treb_cache ||
					equipment->item == pali_cache)) {
					add_fold_string(sep);
					sep = comma;
					add_fold_item_amount(equipment->amount, equipment->item);
				}
			}
		}
				
		if(report == full_report) {
			sep = ", equipment: ";
			for (equipment = forces->using; equipment; equipment = equipment->next)
				if (equipment->item->item_type == ITEM_ITEM) {
					if (equipment->equipped && equipment->amount) {
						add_fold_string(sep);
						add_fold_item_amount(equipment->equipped, equipment->item);
						sep = comma;
					}
				} else {
					add_fold_string(sep);
					if (strncmp(equipment->item->name, "day of ", 7) == 0)
						add_fold_string(equipment->item->name + 7);
					else
						add_fold_string(equipment->item->name);
					sep = comma;
				}
/*
 * Full report also includes unit stats
 */
			report_stats(&forces->vital, &forces->add, 0);
			/*report_stats(&forces->global, 0, 0);*/
			if (forces->fanatic)
				add_fold_string(", fanatic");
		}
		add_fold_char('.');
		print_folded(report, 8);
	}
/*
 * Report, tactics, strategy!
 */
	if (side->tactician)
		fprintf(report, "    Tactician advantage of %d!!!\n", side->tactician);
	if (side->strategist)
		fprintf(report, "    Strategist advantage of %d!!!\n", side->strategist);
	putc('\n', report);
}


/**
 ** REPORT_ENGAGMENT
 **/
static void report_engagment(FILE *report)
{
	report_side(report, &attackers, "Attacking");
	report_side(report, &defenders, "Defending");
}


/**
 ** RECURSIVE_ATTACKERS
 **	All units with 'fight' setting in the stack are attackers
 **/
static void recursive_attackers(unit_s *stack)
{
	if (stack->participate >= 2 && !stack->is_captive)
		stack->is_attacking = 1;
	for (stack = stack->stack; stack; stack = stack->next_location)
		recursive_attackers(stack);
}


/**
 ** RECURSIVE_DEFENDERS
 **	All units with 'defend' or higher setting in the stack are defenders
 **/
static void recursive_defenders(unit_s *stack)
{
	if (stack->participate > 0 && !stack->is_captive)
		stack->is_defending = 1;
	for (stack = stack->stack; stack; stack = stack->next_location)
		recursive_defenders(stack);
}


/**
 ** SIDE_FACTORS
 **	Determine tactician, strategist
 **/
static void side_factors(side_s *side)
{
figure_s	*figure;
unit_s		*unit;
experience_s	*skill;
int		level;
/*
 * Loop on all units
 */
	for (figure = side->units; figure; figure = figure->same_side) {
		unit = figure->unit;
#ifdef STEALTH_STATS
		side->stealth += unit->size * unit->vital.stealth;
		side->observe += unit->size * unit->vital.observation;
#endif
/*
 * Figure out skills
 */
		if ((skill = unit_experiences(unit, tact_cache, 0)) != 0 &&
		    skill->level > side->tactician)
			side->tactician = skill->level;
		if ((skill = unit_experiences(unit, stra_cache, 0)) != 0 &&
		    skill->level > side->strategist)
			side->strategist = skill->level;
#ifdef USES_FATE_POINTS
/*
 * Check for fate possibility
 */
		if (unit->faction && unit->faction->fate_points)
			side->fate = 1;
#endif
	}
/*
 * Now, get the averages
 */
#ifdef STEALTH_STATS
	side->stealth /= side->size;
	side->observe /= side->size;
#endif
	level = 0;
}


/**
 ** BATTLE_ENGAGEMENT
 **	The forces engage each other.
 **/
void battle_engagement(unit_s *attacker, unit_s *target, int ambush)
{
unit_s		*unit;
unit_s		*allied;
figure_s	*figure;
square_s	*square;
experience_s	*skill;
carry_s		*equipment, *using;
actor_s		*actors;
combat_s	*doing;
faction_s	*faction;
item_s		*type;
int		i;
int		hack;
/*
 * Skill cache
 */
	if (!tact_cache) {
		synthetic_tag("tact");
		tact_cache = skill_from_tag(0);
	}
	if(!stra_cache) {
		synthetic_tag("stra");
		stra_cache = skill_from_tag(0);
	}
	if(!fana_cache) {
		synthetic_tag("fana");
		fana_cache = skill_from_tag(0);
	}
	if(!tired_cache) {
		synthetic_tag("efftird");
		tired_cache = item_from_tag(0);
	}
	if(!treb_cache) {
		synthetic_tag("treb");
		treb_cache = item_from_tag(0);
	}
	if(!pali_cache) {
		synthetic_tag("pali");
		pali_cache = item_from_tag(0);
	}
	if(!wariness_cache) {
		synthetic_tag("effwary");
		wariness_cache = item_from_tag(0);
	}
	if(!tower_cache) {
		synthetic_tag("twer");
		tower_cache = terrain_from_tag(0);
	}
	if(!fortr_cache) {
		synthetic_tag("frtr");
		fortr_cache = terrain_from_tag(0);
	}
/*
 * Prepare
 */
	memset(battlefield, 0, sizeof(battlefield));
	memset(&attackers, 0, sizeof(attackers));
	memset(&defenders, 0, sizeof(defenders));
	attackers.opposing = &defenders;
	defenders.opposing = &attackers;
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
		unit->is_attacking = 0;
		unit->is_defending = 0;
	}
/*
 * Pull in all units that are: guarding, allies of guards or involved units
 */
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
	    if(unit->is_moving) continue;
	    if (unit->participate >= 2 &&
		attitude_vs(unit->faction, attacker) == ATTITUDE_IS_ALLY &&
		!unit->is_captive)
		unit->is_attacking = 1;
	    if (unit->participate >= 1 &&
		attitude_vs(unit->faction, target) == ATTITUDE_IS_ALLY &&
		!unit->is_captive)
		unit->is_defending = 1;
	}
/*
 * Guards? Allies of guards?
 */
	if (battle_location->guarded) {
		for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
			if(unit->is_captive) continue;
			if(unit->is_moving) continue;
			if (unit->is_guarding &&
			    attitude_vs(unit->faction, target) <= ATTITUDE_IS_NEUTRAL &&
			    !unit->is_attacking) {
				unit->is_defending = 1;
				for (allied = battle_location->interacting; allied;
								allied = allied->next_visible) {
					if(allied->is_captive) continue;
					if (allied->participate >= 1 &&
					    attitude_vs(allied->faction, unit) == ATTITUDE_IS_ALLY)
						allied->is_defending = 1;
				}
			}
		}
	}
/*
 * Pull in sub-stack of attacker
 */
	recursive_attackers(attacker);
/*
 * Pull in full stack of defender
 */
	unit = target;
	while (unit->leader)
		unit = unit->leader;
	recursive_defenders(unit);
/*
 *  Ambush
 */
	if (ambush) {
	    for (unit = battle_location->interacting; unit;
		 unit = unit->next_visible) {
		/*
		 * Remove any attacking units which are not allied or
		 * not stacked under the initiater
		 */
		if(unit->is_attacking && unit != attacker) {
		    unit_s *leader;
		    leader = unit;
		    while(leader->leader) leader = leader->leader;
		    if(leader != attacker) {
			unit->is_attacking = 0;
			continue;
		    }
		    if(attitude_vs(unit->faction, attacker)!=ATTITUDE_IS_ALLY){
			unit->is_attacking = 0;
			continue;
		    }
		}

		/* Remove any defending units which are not the target */
		if(unit->is_defending && unit != target)
		    unit->is_defending = 0;
	    }
	}
/*
 * Involve attacker & defender last; they *ALWAYS* are involved! Also,
 * attacking faction is never defending, and defending faction never attacks.
 */
	attacker->is_attacking = 1;
	attacker->is_defending = 0;
	target->is_defending = 1;
	target->is_attacking = 0;
	attackers.overall_strength = 0;
	defenders.overall_strength = 0;
/*
 * A last sweep to insure that a faction has no units on both sides of the battlefield
 */
	for (faction = faction_list; faction; faction = faction->next) {
		faction->attacking = 0;
		faction->defending = 0;
	}
	for (unit = battle_location->interacting; unit; unit = unit->next_visible)
		if (unit->is_attacking != unit->is_defending) {
			if(unit->faction) {
				if (unit->is_attacking)
					unit->faction->attacking = 1;
				else
					unit->faction->defending = 1;
			}
		}

	if(attacker->faction)
		attacker->faction->defending = 0;
	if(target->faction)
		target->faction->attacking = 0;
/*
 * Finally: Seed the battlefield. The attacking/defending faction will not join
 * the opposite side, ever.
 */
	for (unit = battle_location->interacting; unit; unit = unit->next_visible) {
		faction = unit->faction;
		if (faction == attacker->faction)
			unit->is_defending = 0;
		if (faction == target->faction)
			unit->is_attacking = 0;
		if (unit->is_attacking == unit->is_defending)
			continue;
		if (unit->is_attacking && faction && faction->defending)
			continue;
		if (unit->is_defending && faction && faction->attacking)
			continue;
		if (unit->size == 0)
			continue;
		unit->sneaking = 0;
		unit->full_day = 1;
		figure = allocate_new_figure();
		figure->unit = unit;
		if(unit->current->type == fortr_cache) {
			figure->fortress = 1;
		}
		if(unit->current->type == tower_cache) {
			unit_s *owner = unit->current->present;
			figure->tower = 0;
			if(unit == owner) figure->tower = 2;
			else {
				unit_s *leader = unit->leader;
				while(leader) {
					if(leader == owner) {
						figure->tower = 1;
					}
					leader = leader->leader;
				}
			}
		}
		if (unit == attacker)
			attackers.initiator = figure;
		else
			if (unit == target)
				defenders.initiator = figure;
		figure->race = unit->race;
		if (unit->is_attacking) {
			figure->side = &attackers;
			figure->offense = 1;
		} else
			figure->side = &defenders;
		if(figure->tower) figure->side->tower = 1;
		if(figure->fortress) figure->side->fortress = 1;
		figure->same_side = figure->side->units;
		figure->side->units = figure;
		figure->side->size += unit->size;
		figure->movement = unit->movement;

		/* HACK -- Fixup any non leader unit's rank */
		if(unit->rank != 0 && unit->race->type != RACE_LEADER) {
			unit->rank = 0;
		}

		/* HACK -- Attacker must go center front and attack */
		if(unit == attacker) {
			figure->rank = 2;
			figure->file = 1;
			if(figure->movement == 0) figure->movement = 1;
		} else {
			figure->rank = unit->rank;
			figure->file = unit->file;
		}
#ifdef TRACING_REQUIRED
		if(figure->unit->traced_unit) {
			sprintf(work, "%s [%s] Living was %d setting to ",
			       figure->unit->name, figure->unit->id.text,
			       figure->living);
			printf("%s", work);
			start_fold_string(work);
		}
#endif
		if(figure->race->type == RACE_LEADER) {
			figure->living += unit->size;
		}
#ifdef TRACING_REQUIRED
		if(figure->unit->traced_unit) {
			printf("%d\n", figure->living);
			add_fold_integer(figure->living);
			add_fold_string(".\n");
			print_folded(full_report, 5);
		}
#endif
		if (!unit->name || strcasecmp(unit->name, "unit") == 0)
			figure->simplename = 1;
		skill = unit_experiences(unit, fana_cache, 0);
		if (skill && skill->effective)
			figure->fanatic = 1;
		compute_stack_capacity(unit);
		figure->bonus = unit->current->type->local_conditions;
#ifdef BATTLE_INITIATIVE
		if (unit->is_guarding || unit->is_patrolling)
			figure->bonus.initiative++;
#endif
		if (unit->capacity[2] >= unit->weight)
			figure->flying = 1;
		else
			figure->flying = 0;
/*
 * Complete actions with the defaults
 */
		memcpy(figure->actions, unit->combat, sizeof(unit->combat));
		for (i = 0; i < MAX_COMBAT_SETTING-1; i++)
			if (figure->actions[i].option == 0)
				break;
		figure->actions[i++].option = COMBAT_SET_ONCE;
		figure->actions[i].option = 0;
/*
 * Copy any equipment (equipment may be modified during combat) or
 * actors (beasts and followers)
 */
		hack = 1;
		for (equipment = unit->carrying; equipment; equipment = equipment->next) {
			type = equipment->item;
			if (equipment->equipped || (equipment->amount && type->item_type == ITEM_DAYS)) {
				using = new_carry_instance();
				*using = *equipment;
				using->amount = using->equipped;
				using->next = figure->using;
				figure->using = using;
#ifdef FX_SHIELDBREAKER
				if (type->special_effects == FX_SHIELDBREAKER)
					figure->shield_breaker = 1;
#endif
#ifdef FX_COINSPINNER
				if (type->special_effects == FX_SHIELDBREAKER)
					figure->side->fate = 1;
#endif
			}
			if (equipment->amount &&
			    (type->equip_bonus.melee ||
                             type->equip_bonus.missile ||
			     type->equip_bonus.defense) &&
			    (type->item_type == ITEM_FOLLOWER ||
                             type->item_type == ITEM_BEAST ||
							 type == treb_cache) &&
                            !equipment->equipped) {
				actors = allocate_new_actor();
				actors->original = equipment;
				actors->actor    = type;
				actors->amount   = equipment->amount;
				if(type->equip_bonus.life)
					actors->life     = type->equip_bonus.life;
				else
					actors->life = 1;
				actors->damage = (int *)malloc(actors->amount * sizeof(int));
				for(i = 0; i < actors->amount; i++) {
					actors->damage[i] = actors->life;
				}
				actors->vitals   = type->equip_bonus;
				actors->modified = type->equip_bonus;
				/* HACK  -- Fix up hits and damage */
				if(!actors->modified.hits)
					actors->modified.hits = 1;
				if(!actors->modified.damage)
					actors->modified.damage= 1;
				actors->acts     = type->combat_action;
				actors->next     = figure->autonomous;
				if(figure->race->type == RACE_LEADER) {
					if(type != treb_cache) {
						figure->side->size += equipment->amount;
					}
				} else if (type != treb_cache) {
					figure->side->size += equipment->amount-hack;
					hack = 0;
				}
				if(type != treb_cache) {
					figure->active += equipment->amount;
				}
				if(type == treb_cache) {
					actors->trebuch = 1;
				} else {
					actors->trebuch = 0;
				}
				figure->autonomous = actors;
#ifdef TRACING_REQUIRED
				if(figure->unit->traced_unit) {
					sprintf(work, "%s [%s] Living was %d setting to ",
					       figure->unit->name, figure->unit->id.text,
					       figure->living);
					printf("%s", work);
					start_fold_string(work);
				}
#endif
				if(type != treb_cache) {
					figure->living++;
				}
#ifdef TRACING_REQUIRED
				if(figure->unit->traced_unit) {
					printf("%d\n", figure->living);
					add_fold_integer(figure->living);
					add_fold_string(".\n");
					print_folded(full_report, 5);
				}
#endif
			}
		}
/*
 * Leader, if any, is an actor
 */
		if (unit->race->type == RACE_LEADER) {
			actors = allocate_new_actor();
			actors->original = 0;
			actors->actor    = 0;
			actors->amount   = 1;
			actors->life  = unit->vital.life;
			actors->damage = (int *)malloc(actors->amount * sizeof(int));
			for(i = 0; i < actors->amount; i++) {
				actors->damage[i] = actors->life;
			}
			actors->vitals   = unit->vital;
			actors->modified = unit->vital;
			actors->next     = figure->autonomous;
			actors->trebuch = 0;
			figure->autonomous = actors;
			figure->active++;
		}
		compute_battle_stats(figure, 1);
/*
 * Figure out relative strength
 */
		i = figure->vital.melee * figure->vital.hits * figure->vital.damage;
		switch (figure->actions[0].option) {
		    default:
			doing = 0;
			break;
		    case COMBAT_SET_ITEM:
			doing = &figure->actions[0].u.use_item->combat_action;
			break;
		    case COMBAT_SET_SKILL:
			doing = &figure->actions[0].u.use_skill->combat_action;
			break;
		}
		if (doing) {
			if (doing->action.hits)
				i = doing->action.hits;
			else
				i = doing->bonus.hits + figure->vital.melee;
			if (doing->action.damage)
				i *= doing->action.damage;
			else
				i *= doing->bonus.damage + figure->vital.damage;
			switch (doing->effect) {
			    case COMBAT_EFFECT_MELEE:
				if (doing->action.melee)
					i *= doing->action.melee;
				else
					i *= doing->bonus.melee + figure->vital.melee;
				break;
			    case COMBAT_EFFECT_RANGED:
				if (doing->action.missile)
					i *= doing->action.missile;
				else
					i *= doing->bonus.missile + figure->vital.missile;
				i += i / 2;	/* ranged attacks are assumed to be 50% more efficient */
				break;
			    case COMBAT_EFFECT_SPECIAL:
				i = 0;
			}
		}
		figure->side->overall_strength += i;
	}
/*
 * Evaluate tactics and strategy
 */
	side_factors(&attackers);
	side_factors(&defenders);
/*
 * Tactics difference
 */
	if (attackers.tactician > defenders.tactician) {
		attackers.tactician -= defenders.tactician;
		attackers.tactician *= 2;
		defenders.tactician  = 0;
	} else {
		defenders.tactician -= attackers.tactician;
		attackers.tactician  = 0;
		defenders.tactician *= 2;
	}
#ifdef USES_FATE_POINTS
/*
 * Fate doesn't intervene if less than 30 figures are involved in
 * battle.
 */
	if (attackers.size < 30 || defenders.size < 30) {
		attackers.fate = 0;
		defenders.fate = 0;
	}
/*
 * Consume fate?
 */
	if (attackers.fate || defenders.fate) {
		if (attackers.fate > defenders.fate) {
			attackers.fate -= defenders.fate;
			defenders.fate = 0;
		} else {
			defenders.fate -= attackers.fate;
			attackers.fate = 0;
		}
		if (attackers.overall_strength > defenders.overall_strength) {
			attackers.fate = 0;
			printf("fate isn't necessary in battle for attackers\n");
		}
		if (defenders.overall_strength > attackers.overall_strength) {
			defenders.fate = 0;
			printf("fate isn't necessary in battle for defenders\n");
		}
		if (attackers.fate)
			printf("attacks have fate with them! (%d str vs %d)\n", attackers.overall_strength, defenders.overall_strength);
		else
			if (defenders.fate)
				printf("defenders have fate with them (%d str vs %d)!\n", defenders.overall_strength, attackers.overall_strength);
	}
#endif
/*
 * Report involved figures
 */
	report_engagment(full_report);
	report_engagment(long_report);
	report_engagment(terse_report);
/*
 * Place on battlefield
 */
	for (figure = attackers.units; figure; figure = figure->same_side) {
		square = &battlefield[(int)figure->rank][(int)figure->file];
		figure->same_square = square->attackers;
		square->attackers = figure;
	}
	for (figure = defenders.units; figure; figure = figure->same_side) {
		figure->rank = 5 - figure->rank;
		figure->file = 2 - figure->file;
		square = &battlefield[(int)figure->rank][(int)figure->file];
		figure->same_square = square->defenders;
		square->defenders = figure;
	}
/*
 * Finally, how many units may be routed?
 */
#if defined(END_OF_WORLD) && END_OF_WORLD == 4
	attackers.rout = attackers.size * 2;
	defenders.rout = defenders.size * 2;
#else
	attackers.rout = attackers.size / 2;
	if((attackers.size & 1) && (attackers.size > 1)) attackers.rout++;
	if(attackers.rout < 1) attackers.rout = 1;
	defenders.rout = defenders.size / 2;
	if((defenders.size & 1) && (defenders.size > 1)) defenders.rout++;
	if(defenders.rout < 1) defenders.rout = 1;
#endif
}
