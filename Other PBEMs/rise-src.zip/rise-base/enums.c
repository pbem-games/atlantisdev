/* $Id: enums.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Enumerated arrays/values
 */

