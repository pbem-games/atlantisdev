/* $Id: battle.h,v 1.23 2001/02/11 22:21:43 jtraub Exp $
 *	Battle module
 */
#ifndef _overlord_battle_h_
#define _overlord_battle_h_
#include "overlord.h"


/**
 ** Battle units
 **/
struct struct_side {
	faction_s		*factions;
	struct struct_side	*opposing;
	struct struct_fig	*units;
	struct struct_fig	*initiator;
	carry_s			*spoils;
	int			tactician,
				strategist,
				stealth,
				observe;
	int			overall_strength;
	int			size,
				rout,
				casualties,
				turn_casualties;
	char			lost;
	char			fled;
	char			routed;
	char			fate;
	struct struct_fig *fogger;
	char entrenched;
	char burden;		/* burden beasts */
	char			fortress; /* in fortress */
	char			tower; /*  some units are in a tower*/
#ifdef FX_STONE_HEADS
	char			stone_headed; /* occurs only once */
#endif
};
typedef struct struct_side	side_s;

struct struct_targetreport {
	int hits;
	int damage;
	int killed;
	int captured;
	struct struct_actor *target;
	struct struct_fig *figure;
	struct struct_targetreport *next;
};

typedef struct struct_targetreport treport_s;

struct struct_actor {
	struct struct_actor	*next;
	carry_s			*original;
	item_s			*actor;
	int			amount, living;
	int			acted;
	int			life;
	int			*damage;
	treport_s		*attacks;
	stats_s			vitals;
	stats_s			modified;
	stats_s			bonus;
	combat_s		acts;
	char 		trebuch;
	char			summoned;
};
typedef struct struct_actor	actor_s;


struct struct_fig {
	struct struct_fig	*same_square;		/* same location */
	struct struct_fig	*next_initiative,	/* doubly-link list */
				*prev_initiative;
	struct struct_fig	*same_side;		/* same side */
	struct struct_fig	*target,
				*next_target;		/* strike! */
	struct struct_fig	*last_target;		/* keep in memory */
#ifdef FX_ANGEL_OF_DEATH
	struct struct_fig	*angel_called;	/* called an angel */
#endif
	unit_s			*unit;
	race_s			*race;
	side_s			*side;
	carry_s			*using;
	actor_s			*autonomous;
	stats_s			vital;
	stats_s			modified;
	stats_s			bonus;
	stats_s			global;
	stats_s			add;
	int				fog_rounds;
	combat_set_s		actions[MAX_COMBAT_SETTING+2];
	combat_set_s		mandated;
	combat_set_s		*considered;
	long			permanent_effects;
	long			pending_effects;
#ifdef BATTLE_INITIATIVE
	int			tactical_bonus;
	int			current_init;
	int			repeating;
#endif
	int			living, active, deceased;
	int			wounded, hits, losses;
	int			men, beasts;
	int			was_struck, was_wounded, was_hit, has_lost;
	int			combat_exp, melee_exp, parry_exp;
	char			has_moved, has_acted;
	char			has_waited;
	char			reloading, fleeing, fled;
	char			retreat;
	char			ranges, targets;
	char			max_range;
	char			rank, file,
				movement;	/* during combat */
	char			range;		/* of target */
	char			offense;	/* unit attacks or defends? */
	char			fanatic;
	char			flying;
#ifdef PRISONERS_TAKEN
	char			prisoner;	/* was made prisoner */
	struct struct_fig	*captor;	/* who took us */
	struct struct_fig	*captive;	/* Who did we take */
#endif
#ifdef FX_BATTLE_PIKES
	char			piked;
#endif
#ifdef FX_BATTLE_RAISE_ARMOR
	char			armored;
#endif
	char			simplename;	/* report unit ID in battle */
#ifdef FX_BLACK_AURA
	char			black_aura;	/* turns of blackness */
#endif
#ifdef FX_CALL_HELP
	char			help_called;	/* call only once */
#endif
#ifdef FX_ANGEL_OF_DEATH
	char			angel_turns;	/* called an angel */
#endif
#ifdef FX_HEAVINESS
	char			heavy;		/* heaviness has struck */
	char			heavy_penalty;
#endif
#ifdef FX_BATTLE_CONFUSED
	char			friend_or_foe;	/* confuse friend and foe */
#endif
#ifdef FX_SHIELDBREAKER
	char			shield_breaker;	/* has -THAT- sword equipped! */
#endif
	char			fortress;
	char			tower;
#ifdef FX_BATTLE_TREMBLING_HEART
	char			fear;
#endif
#ifdef FX_BATTLE_TORPOR
	char			torpor;
	char			torpor_act;
#endif
};
typedef struct struct_fig	figure_s;


struct struct_square {
	figure_s		*attackers,
				*defenders;
	stats_s			round_modifiers;
	stats_s			battle_modifiers;
};
typedef struct struct_square	square_s;


/**
 ** Battle module variables
 **/
extern FILE		*full_report, *long_report, *terse_report;
extern location_s	*battle_location;
extern figure_s		*acting_units;
extern side_s		attackers, defenders;
extern square_s		battlefield[6][3];
extern int		initiative_level;
extern int		observation_round;
extern int		round_number;
extern char		unit_acted;

/**
 ** Prototypes
 **/
extern void	initiate_attack(unit_s *,unit_s *);
extern void	battle_delay_processing(figure_s *);
extern void	battle_engagement(unit_s *,unit_s *,int);
#ifdef FX_AMBUSH
extern void	initiate_ambush(unit_s *, unit_s *);
#endif
extern void	free_all_soldiers(void);
extern void	free_actor_instance(actor_s *);
extern void	run_battle(int);
extern void	start_fold_unit_segment(figure_s *);
extern int	move_soldier(figure_s *,char);
extern int	figure_moves(figure_s *);
extern int	move_at_random(figure_s *);
extern int	battle_move_retreat(figure_s *);
extern int	unit_may_act(figure_s *);
extern void	unit_away(figure_s *);
extern void	unit_has_acted(figure_s *);
extern void	random_shuffle(side_s *);
extern void	compute_battle_stats(figure_s *,int);
extern void	unit_pick_target(figure_s *unit);

extern int	battle_fx_target_check(figure_s *,int);
extern int	battle_fx_effect(figure_s *, int, int, char *, skill_s *);
extern void	battle_fx_strike(figure_s *, int);
extern int	battle_components_away(unit_s *, skill_s *, int);
extern void	adjust_vitals(actor_s *unit, combat_s *action);

extern void battle_fog_cover(side_s *side);

#ifdef PRISONERS_TAKEN
extern int 	does_capture(figure_s *unit, figure_s *target);
extern int	all_capture_target;
#endif

extern actor_s *allocate_new_actor(void);

#endif /*_overlord_battle_h_*/
