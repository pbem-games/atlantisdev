/* $Id: fxdef.h,v 1.66 2001/02/11 22:21:43 jtraub Exp $
 *	Technicolor special effects constants. Anything defined
 * causes the appropriate thing to be appended.
 */
#ifndef overlord_fxdef_h_
#define overlord_fxdef_h_
#define FX_NONE						0

#define FX_FAR_EYE					1
#define FX_LAY_CLAIM				2
#define FX_SEE_ALL_MAGE				3
#define FX_FULL_INFO				4
#define FX_BUILDING_COMPLETE		5
#define FX_MINE_PRODUCTION			6
#define FX_LMYD_PRODUCTION			7
#define FX_DENOUNCE_CLAIM			8
#define FX_INN_PRODUCTION			9
#define FX_RANCH_PRODUCTION			10
#define FX_MARKET_PRODUCTION		11
#define FX_CASTLE					12
#define FX_FORTRESS					13
#define FX_MTOWER					14
#define FX_RANSOM					15
#define FX_EXECUTE					16
#define FX_IDENTIFY					17
#define FX_AMBUSH					18
#define FX_QUICK_STUDY				19
#define FX_WIZARD_WINGS				20
#define FX_WATER_WALK				21
#define FX_CORNUCOPIA				22
#define FX_HAUNTED_BLADE			23
#define FX_ORB_OF_RESURRECT			24
#define FX_GEWIL_FORGE				25
#define FX_HYSSA_LEVEL				26
#define FX_LUGNARD_PURSE			27

#define FX_TRANSCEND				50
#define FX_ORIENT					51
#define FX_GLOW_EYES				52
#define FX_EVALUATE_MANA			53
#define FX_REVEAL_ARTISAN			54
#define FX_NATIVES_EYE				55
#define FX_RECRUIT_RACE				56
#define FX_CALL_BEASTS				57
#define FX_SEE_RESOURCES			58
#define FX_FEEL_FLOW				59
#define FX_MASTER_BEASTS			60
#define FX_UNEARTH_ARCANA			61
#define FX_FARTHER_FAFR				62
#define FX_BURN_BRIDGE				63
#define FX_WARRIOR_REVEAL			64
#define FX_ACQUIRE_ARTISAN			65
#define FX_SEARCH					66
#define FX_DETECT_ENEMIES			67
#define FX_INCREASE_INT				68
#define FX_REVEAL_SAIL				69
#define FX_FURTHER_ALG				70
#define FX_FURTHER_VOLD				71
#define FX_REVEAL_SCOUTING			72
#define FX_ASCEND					73
#define FX_CALL_TO_BATTLE			74
#define FX_INSPIRATION				75
#define FX_PICKPOCKET				76
#define FX_DETECT_LIFE				77
#define FX_CHANGEMORPH				78
#define FX_SENDOTHER_AIR			79
#define FX_EAGLE_EYE				80
#define FX_SENDSELF_AIR				81
#define FX_SENDSELF_WATER			82
#define FX_DISTANT_VISION			83
#define FX_WALK_DEAD				84
#define FX_FIND_LAND				85
#define FX_LOCATE_SHELTER			86
#define FX_SENDSELF_OVERWORLD		87
#define FX_SENDSELF_EARTH			88
#define FX_CROP_BLESSING			89
#define FX_PALE_WORLD				90
#define FX_DETECT_BEAST				91
#define FX_FURTHER_EWELIN			92
#define FX_SEED_EARTH				93
#define FX_DIVINE_REVEAL			94
#define FX_REVEAL_LEADERSHIP		95
#define FX_GATE_FIRE				96
#define FX_SENSE_PEOPLE				97
#define FX_FILL_VOID				98
#define FX_APOTHEOSIS				99

#define FX_BATTLE_SQUARE_FORMATION	100
#define FX_BATTLE_DIG_ENTRENCH		101
#define FX_BATTLE_ILLUSORY_ARMOR	102
#define FX_BATTLE_ILLUSORY_BOW		103
#define FX_BATTLE_ILLUSORY_SHIELD	104
#define FX_BATTLE_SAPPERS			105
#define FX_BATTLE_PIKES				106
#define FX_BATTLE_IRON_FISTS		107
#define FX_BATTLE_TREMBLING_HEART	108
#define FX_BATTLE_RAISE_ARMOR		109
#define FX_BATTLE_COVER_OF_FOG		110
#define FX_BATTLE_TORPOR			111
#define FX_BATTLE_BURDEN_BEAST		112
#define FX_BATTLE_SUMMON_SWORDMEN   113

#define FX_ONCE						126

#define FX_CULTIVATE_RICE			128
#define FX_WIZARDS_CURSE			129
#define FX_GATE_EARTH				130
#define FX_SENDOTHER_WATER			131
#define FX_SIX_FEET_UNDER			132
#define FX_GATE_OVERWORLD			133
#define FX_GATE_AIR					134
#define FX_HYPNOTIC_CALL			135
#define FX_ILLUSION_TORTURED_ALLY	136
#define FX_GATE_WATER				137
#define FX_CULTIVATE_WHEAT			138
#define FX_AID_IN_RITUAL			139
#define FX_TALE_BONES				140
#define FX_PIERCE_THE_VEIL			141
#define FX_SENDSELF_VOID			142
#define FX_SENDOTHER_OVERWORLD		143
#define FX_SENDOTHER_VOID			144
#define FX_SENDSELF_FIRE			145
#define FX_SENDOTHER_FIRE			146
#define FX_SENDSELF_UNDERWORLD		147
#define FX_GATE_UNDERWORLD			148
#define FX_GATE_VOID				149
#define FX_PILFER					150
#define FX_PILLAGE					151
#define FX_SPYING					152
#define FX_MUMMERS_DANCE			153
#define FX_EMPTY_SHELL				154
#define FX_SLEEP_WITH_FISH			155
#define FX_DROWNED_CARCASS			156
#define FX_BURIED_CORPSE			157

#endif /* overlord_fxdef_h_ */
