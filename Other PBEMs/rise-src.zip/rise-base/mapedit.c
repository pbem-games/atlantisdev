/* $Id: mapedit.c,v 1.16 2000/08/27 16:20:20 jtraub Exp $
 *	Interactive map editor
 */
#include "turn.h"
#include "parser.h"
#include "enumstxt.h"
#include "command_e.h"
#include <time.h>

/**
 ** Special prototype
 **/
extern void	recursive_relative_position(location_s *,int,int);


/**
 ** Private variables
 **/
static location_s	*current_location;
static char		map[255][255];
static int		max_x, max_y;


/**
 ** LIST
 **/
static void list(location_s *l)
{
    location_s *outer, *inner;
    market_s *market;
    direction_s	*direction;
    resource_s *product;
    experience_s *skill;

    printf("[%s] %s, %s", l->id.text, l->name, l->type->name);
#ifdef USE_OVERLAND_COORDINATES
    if(l->type->type == TERRAIN_COUNTRY)
	printf(" (%d,%d)", l->x, l->y);
#endif
    if(l->region) {
	printf(" <%s>", visual_enum(l->region, regions));
    }
    if ((outer = l->outer) != 0) {
	printf(" in [%s] %s, %s", outer->id.text, outer->name,
	       outer->type->name);
#ifdef USE_OVERLAND_COORDINATES
	if(outer->type->type == TERRAIN_COUNTRY)
	    printf(" (%d,%d)", outer->x, outer->y);
#endif
    }
    putchar('\n');
    if(l->racial) {
	printf("Population: %d %s [%s]\n", l->population, l->racial->plural,
	       l->racial->tag.text);
    } else {
	if(l->type->optima || l->population)
	    printf("Population: %d figures\n", l->population);
    }
    
    for (market = l->markets; market; market = market->next) {
	if (market->offered.initial_amount)
	    printf("  Sell: %d %s [%s] at $%d (for %d turns)\n",
		   market->offered.initial_amount,
		   market->type->name, market->type->tag.text,
		   market->offered.negociated_price, market->turns);
	if (market->wanted.initial_amount)
	    printf("   Buy: %d %s [%s] at $%d (for %d turns)\n",
		   market->wanted.initial_amount,
		   market->type->name, market->type->tag.text,
		   market->wanted.negociated_price, market->turns);
    }
    
    for (product = l->resources; product; product = product->next)
	printf("  Resource: %d %s [%s]\n", product->amount,
	       product->type->name, product->type->tag.text);

    for(skill = l->skills; skill; skill = skill->next) {
	printf("  Skill: %s [%s] (%ld points)\n", skill->skill->name,
	       skill->skill->tag.text, skill->points);
    }

    for (direction = l->exits; direction; direction = direction->next) {
	printf("  %s: to %s [%s]", direction->name,
	       direction->toward->name, direction->toward->id.text);
	if(direction->toward->region)
	    printf(" <%s>", visual_enum(direction->toward->region, regions));
	if(direction->mode >= 0)
	    printf(" in %d days (%s)\n", direction->days,
		    visual_enum(direction->mode, movement_modes));
	else
	    printf(" impassable\n");
    }

    for(inner = l->inner; inner; inner = inner->next_inner) {
	printf("  Inner: %s [%s], %s (%s)\n", inner->name, inner->id.text,
	       inner->type->name, inner->type->tag.text);
    }
}

/**
 ** COMPLETE_COMPASS
 **	Interactive compass
 **/
static void complete_compass(location_s *l, int dir, int x, int y)
{
location_s	*added;
terrain_s	*terr;
int xwrap, ywrap;
/*
 * Direction does not exist?
 */
	if ((added = location_from_position(x, y, l->region)) != 0) {
		printf("... connecting %s and %s\n", l->id.text, added->id.text);
		compass_connect(l, added, dir);
		return;
	}

	printf("Direction %s, type: ", compass_names[dir]);
	while (1) {
		if (!file_gets(stdin))
			abort();
		if (!separate_tag())
			return;
		terr = terrain_from_tag(0);
		if(terr)
		    break;
	}
	added = random_location_id();
	added->type = terr;

#ifdef DYNAMICALLY_DEFINED_GAME
	added->partial = 1;
#endif
	added->region = l->region;
	printf("Name: (%s) ", l->name);
	if (!file_gets(stdin))
		abort();
	if (!work[0])
		strcpy(work, l->name);
	added->name = strdup(work);

	xwrap = wrap_x(l->region);
	ywrap = wrap_y(l->region);

	if(xwrap) {
	    if(x < 1) x = xwrap-x;
	    if(x > xwrap) x = x-xwrap;
	}
	if(ywrap) {
	    if(y < 1) y = ywrap-y;
	    if(y > ywrap) y = y-ywrap;
	}
	added->x = x;
	added->y = y;
	all_compass_connect(added);
}

/**
 ** Connect all locations
 **/
static void connect_all_locations(int plane)
{
    location_s *loc;
    for(loc = location_list; loc; loc = loc->next) {
	if(loc->region == plane && loc->type->type == 0) {
	    all_compass_connect(loc);
	}
    }
}

/**
 ** COMPLETE_LOCATION
 **	Make sure location is complete
 **/
static void complete_location(location_s *l, location_s *old)
{
    int frac;

    /*
     * Type?
     */
    while (!l->type) {
	printf("Type: ");
	if (!file_gets(stdin)) abort();
	if (separate_tag()) l->type = terrain_from_tag(0);
    }

    if(l->type->type == TERRAIN_INNER || l->type->type == TERRAIN_STRUCTURE) {
	while(!l->outer) {
	    printf("Outer: [%s] ", old->id.text);
	    if(!file_gets(stdin)) abort();
	    if(separate_tag()) {
		l->outer = location_from_id(0);
	    } else {
		l->outer = old;
	    }
	    if(l->outer) {
		old = l->outer;
		if(!old->inner) {
		    old->inner = l;
		} else {
		    old = old->inner;
		    while(old->next_inner) old = old->next_inner;
		    old->next_inner = l;
		}
	    }
	}
    }

    /*
     * Name?
     */
    while (!l->name) {
	printf("Name: ");
	if (!file_gets(stdin)) abort();
	l->name = strdup(work);
    }

    /*
     * Region
     */
    while(l->region < 0) {
	printf("Region: ");
	if(!file_gets(stdin)) abort();
	if(separate_token())
	    l->region = parsed_enum(token_keyword, regions);
	else
	    l->region = 0;
    }

    /*
     * Population?
     */
    if (!l->population && l->type->optima) {
	printf("Population = (%d) ", l->type->optima);
	if (!file_gets(stdin)) abort();
	if (work[0])
	    l->population = atoi(work);
	else
	    l->population = l->type->optima;
	printf("Racial makeup: ");
	if(old && old->racial) printf(" [%s] ", old->racial->tag.text);
	if (!file_gets(stdin)) abort();
	if (separate_tag())
	    l->racial = race_from_tag(0);
	else
	    if(old) l->racial = old->racial;
    }

    /*
     * location resources
     */
    while (1) {
	printf("Resource: ");
	if (!file_gets(stdin)) abort();
	if (!work[0]) break;
	l->resources = parse_resource_item(l->resources);
    }

    if(l->type->type == TERRAIN_STRUCTURE) {
	while (1) {
	    skill_s *s;
	    experience_s *e, *r;
	    printf("Skill: ");
	    if(!file_gets(stdin)) abort();
	    if(!separate_tag()) break;
	    s = skill_from_tag(0);
	    if(!s) continue;
	    e = new_experience_instance();
	    e->skill = s;
	    e->points = s->for_level;
	    adjust_experience(e, 1);
	    r = l->skills;
	    if(!r) {
		l->skills = e;
	    } else {
		while(r->next) r = r->next;
		r->next = e;
	    }
	}
    }

    /*
     * Complete locations
     */
    if (l->type->type == TERRAIN_COUNTRY) {
#ifdef USE_OVERLAND_COORDINATES
		if (!l->x || !l->y) {
			int	x, y;
			printf("X:");
			file_gets(stdin);
			x = atoi(work);
			printf("Y:");
			file_gets(stdin);
			y = atoi(work);
			if (x && y)
				recursive_relative_position(l, x, y);
		}
#else
		relative_positions_from(l);
#endif
		if (l->x & 1)
			frac = 0;
		else
			frac = 1;
	    complete_compass(l, 0, l->x, l->y-1);
	    complete_compass(l, 1, l->x, l->y+1);
	    complete_compass(l, 2, l->x+1, l->y-frac);
	    complete_compass(l, 3, l->x-1, l->y+1-frac);
	    complete_compass(l, 4, l->x+1, l->y+1-frac);
	    complete_compass(l, 5, l->x-1, l->y-frac);
	}
#ifdef DYNAMICALLY_DEFINED_GAME
    l->partial = 0;
#endif
}


/**
 ** XPM_HEXAMERON
 */
static void xpm_hexameron(int row, int col, int type, char *into)
{
char		ipixel;
/*
 */
	while (type > 3) {
		row++;
		type -= 4;
	}
	ipixel = map[row][col];
	if (ipixel) {
		into[0] = ipixel;
		into[1] = ipixel;
		into[2] = ipixel;
		into[3] = ipixel;
		return;
	}
	if (type == 0)
		ipixel = '.';
	else
		ipixel = '#';
	into[0] = '.';
	into[1] = ipixel;
	into[2] = ipixel;
	into[3] = ipixel;
}


/**
 ** XPM_LINE_FORMATTOR
 **/
static void xpm_line_formattor(FILE *xpm_map, int row)
{
char	*s;
int	col;
int	linetype;

	for (linetype = 0; linetype < 4; linetype++) {
		s = work;
		for (col = 1; col < max_x+1; col += 2) {
			xpm_hexameron(row, col, linetype+2, s);
			s += 4;
			xpm_hexameron(row, col+1, linetype, s);
			s += 4;
		}
		*s = 0;
		fprintf(xpm_map, "\"%s.\",\n", work);
	}
}


/**
 ** GENERATE_MAPPING_INFO
 **	Generate map based on terrains
 **/
static void generate_mapping_info(char plane, char *name)
{
FILE		*xpm_map;
location_s	*location;
terrain_s	*ttype;
char		*s;
int		n;
int		row, col;
/*
 * Open map
 */
	if ((xpm_map = fopen(name, "w")) == 0) {
		perror(name);
		return;
	}
	fprintf(xpm_map, "/* XPM */\n");
	fprintf(xpm_map, "static char *overlord[] = {\n");
/*
 * Count locations, allocate them
 */
	n = 0;
	for (ttype = terrains_list; ttype; ttype = ttype->next)
		if (ttype->type == TERRAIN_COUNTRY && ttype->pixel)
			ttype->special_effect = 'a' + n++;
		else
			ttype->special_effect = 0;
/*
 * Print colors
 */
	fprintf(xpm_map, "/* width height num_colors chars_per_pixel */\n");
	fprintf(xpm_map, "\" %d %d %d 1\",\n", max_x*4+1, max_y*4+1, n+2);
	fprintf(xpm_map, "/* colors */\n");
	fprintf(xpm_map, "\". c #000000\",\n");	/* black */
	fprintf(xpm_map, "\"# c #ffffff\",\n");	/* white */
	for (ttype = terrains_list; ttype; ttype = ttype->next)
		if (ttype->special_effect)
			fprintf(xpm_map, "\"%c c #%06x\",\n", ttype->special_effect, (unsigned int)ttype->pixel);
	fprintf(xpm_map, "/* pixels */\n");
/*
 * Fill in the map
 */
	memset(map, 0, sizeof(map));
	for (location = location_list; location; location = location->next)
		if (location->x > 0 && location->x <= 255 &&
		    location->y > 0 && location->y <= 255 &&
		    location->region == plane)
			map[location->y][location->x-1] = location->type->special_effect;
/*
 * Output the filled map
 */
	for (row = 1; row < max_y+1; row++)
		xpm_line_formattor(xpm_map, row);
/*
 * Done
 */
	s = work;
	for (col = 1; col <= max_x; col += 2) {
		*s++ = '.';
		*s++ = '#';
		*s++ = '#';
		*s++ = '#';
		*s++ = '.';
		*s++ = '.';
		*s++ = '.';
		*s++ = '.';
	}
	*s = 0;
	fprintf(xpm_map, "\"%s.\"\n", work);
	fprintf(xpm_map, "};\n");
	fclose(xpm_map);
}

void fish_in_oceans(void)
{
	static terrain_s *c_ocean;
	static terrain_s *c_lake;
	location_s *location;
	int count, sum = 0;

	if(!c_ocean) {
		synthetic_tag("oceans");
		c_ocean=terrain_from_tag(0);
	}
	if(!c_lake) {
		synthetic_tag("lake");
		c_lake=terrain_from_tag(0);
	}

	for (location = location_list; location; location = location->next) {
		if(!location->partial) continue;
		if(location->type!=c_ocean && location->type != c_lake) continue;
		if(location->resources) continue;
		if(location->type == c_lake) {
			count = 5+roll_1Dx(11);
			sprintf(work, "fish %d", count);
			string_ptr = work;
			location->resources = parse_resource_item(location->resources);
			sum = 1+roll_1Dx(8);
			sprintf(work, "perl %d", sum);
			string_ptr = work;
			location->resources = parse_resource_item(location->resources);
			printf("%s: %d fish, %d perl\n", location->name, count, sum);
			location->partial = 0;
		} else if(location->type == c_ocean) {
			if(strstr(location->name, "Polar")) {
				count = 1;
			} else if(strstr(location->name, "Icy")) {
				count = 2;
				sum = 12;
			} else if(strstr(location->name, "Bleak")) {
				count = 2;
				sum = 6;
			} else {
				count = 7;
				sum = 20;
			}
			while(count--) {
				sum += (1+roll_1Dx(10));
			}
			sprintf(work, "fish %d", sum);
			string_ptr = work;
			location->resources = parse_resource_item(location->resources);
			printf("%s: %d fish\n", location->name, sum);
			location->partial = 0;
		}
	}
}

/**
 ** Map editor entry point
 **/
int main(int argc, char **argv)
{
location_s	*new_location;
direction_s	*direction;
int		x, y;
/*
 * Pre-load
 */
	srand48(time(0));
	load_races();
	load_items();
	load_skills();
#ifdef USES_TITLE_SYSTEM
	load_titles();
#endif
	load_locations();
	current_location = location_list;
/*
 * Processing
 */
	while (1) {
		printf("[%s] > ", current_location->id.text);
		if (!file_gets(stdin))
			break;
		if (keyword("SAVE")) {
			save_locations();
			continue;
		}
		if (keyword("QUIT"))
			break;
		if (keyword("FOCUS")) {
			if (separate_tag()) {
				if ((new_location = location_from_id(0)) == 0)
					printf("No such ID\n");
				else {
					current_location = new_location;
					list(new_location);
				}
			}
			continue;
		}
		if (keyword("LIST")) {
			list(current_location);
			continue;
		}
		if (keyword("GO")) {
			if (keyword("OUT")) {
				if (current_location->outer) {
					current_location = current_location->outer;
					list(current_location);
					continue;
				}
			}
			new_location = 0;
			for (direction = current_location->exits; direction; direction = direction->next)
				if (keyword(direction->name)) {
					new_location = direction->toward;
					break;
				}
			if (new_location) {
				current_location = new_location;
				list(current_location);
				continue;
			}
			if (isdigit(*string_ptr)) {
				x = atoi(string_ptr);
				separate_token();
				y = atoi(string_ptr);
				separate_token();
				if ((new_location = location_from_position(x, y, parsed_enum(string_ptr, regions))) != 0) {
					current_location = new_location;
					list(new_location);
				} else
					printf("No such coordinates\n");
				continue;
			}
			if (separate_tag() &&
			    (new_location = location_from_id(0)) != 0) {
					current_location = new_location;
					list(new_location);
					continue;
				}
			printf("No such direction.\n");
			continue;
		}
		if (keyword("COMPLETE")) {
			complete_location(current_location, NULL);
			continue;
		}
		if (keyword("NEW")) {
		    	location_s *old = current_location;
			current_location = random_location_id();
			current_location->region = -1;
			complete_location(current_location, old);
			continue;
		}
		if(keyword("FULLCONNECT")) {
		    connect_all_locations(current_location->region);
		    continue;
		}
		if(keyword("FISHES")) {
			fish_in_oceans();
			continue;
		}
		if (keyword("MAPGEN")) {
			max_x = atoi(string_ptr);
			if (max_x > 255)
				max_x = 255;
			separate_token();
			max_y = atoi(string_ptr);
			if (max_y > 255)
				max_y = 255;
			separate_token();
			separate_token();
			if(string_ptr && *string_ptr)
			    generate_mapping_info(parsed_enum(token_keyword, regions), string_ptr);
			else
			    generate_mapping_info(0, token_keyword);
			continue;
		}
	}
	return 0;
}
