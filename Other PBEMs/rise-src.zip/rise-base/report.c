/* $Id: report.c,v 1.52 2001/01/27 21:25:50 jtraub Exp $
 *	Report generator
 */
#include "turn.h"
#include "fx.h"
#include "formatter.h"
#include "command_e.h"

/**
 ** Macro fix
 **/
#ifdef REPORT_OVERLAND_COORDINATES
#ifndef USE_OVERLAND_COORDINATES
#undef REPORT_OVERLAND_COORDINATES
#endif
#endif


#if defined(REPORTS_HTML) || !defined(IN_HTML)
#include "enumstxt.h"
/**
 ** Global variables
 **/
FILE			*report;

extern int sword_victory, mage_victory, craft_victory;

/**
 ** Local variables
 **/
static faction_s	*current_faction;
static char		*announce;
#ifdef FX_MAGIC_EYE
char			magic_eye;
#endif
#ifdef FX_SEE_ALL_MAGE
char			evaluate_mage;
#endif
static char		item_types[] = "\n. This is a follower\n. This is a beast\n\n. This is a duration effect\n. This is an instant effect\n. This is an event\n. This is a placeholder tag";


/**
 ** ADD_FOLD_NTH_INTEGER
 **	Special formatting
 **/
#ifdef REPORTS_RANKINGS
static void add_fold_nth_integer(int value)
{
	add_fold_integer(value);
	if (value > 10 && value < 14)
		value = 14;
	switch (value % 10) {
	    case 1:
		add_fold_char('s');
		add_fold_char('t');
		break;
	    case 2:
		add_fold_char('n');
		add_fold_char('d');
		break;
	    case 3:
		add_fold_char('r');
		add_fold_char('d');
		break;
	    default:
		add_fold_char('t');
		add_fold_char('h');
	}
}
#endif

/**
 ** Report for a unit name and component
 **/
#ifdef STEALTH_STATS
static void add_fold_unit_visible(unit_s *unit, int owner, int observe)
#else
static void add_fold_unit_visible(unit_s *unit, int owner)
#endif
{
char		*sep;
carry_s		*items;
race_s		*racial;
item_s		*type;
faction_s	*faction;
int		shown;
/*
 * Unit name
 */
	add_fold_string(unit->name);
	add_fold_tag(&unit->id);
	if (unit->faction && unit->faction != current_faction) {
		if (unit->setting_advert)
			shown = 1;
#ifdef STEALTH_STATS
#ifdef STEALTH_DISCLOSES_FACTION
		else if (unit->vital.stealth + STEALTH_DISCLOSES_FACTION <= observe)
			shown = 1;
#endif
#endif
		else
			shown = 0;
		if (!shown) {
			add_fold_string(" of ");
			faction = unit->faction;
			add_fold_string(faction->name);
			add_fold_tag(&faction->id);
			if (faction->scratchpad[2] > 1) {
				if (faction->scratchpad[2] > 3) {
					if (faction->scratchpad[2] > 9) {
						if (faction->scratchpad[2] > 15) {
							if (faction->scratchpad[2] > 25) {
								add_fold_string(" empire");
							} else
								add_fold_string(" nation");
						} else
							add_fold_string(" kingdom");
					} else
						add_fold_string(" faction");
				} else
					add_fold_string(" tribe");
			}
		}
	}
/*
 * Unit type
 */
	add_fold_char(',');
	add_fold_char(' ');
	if (unit->size <= 0)
		add_fold_string("stockpile");
	else {
		racial = unit->race;
#ifdef REPORTS_RACIAL_KNOWLEDGE
		if (owner)
			faction_knows_race(current_faction, racial);
#endif
#ifdef FX_ALTERED_UNIT
		if (!owner && unit->altered)
			racial = unit->altered;
#endif
		add_fold_string(racial->name);
		add_fold_tag(&racial->tag);
#ifdef FX_ALTERED_UNIT
		if (unit->altered && racial != unit->altered) {
			add_fold_string(" (looking like a ");
			add_fold_string(unit->altered->name);
			add_fold_char(')');
		}
#endif
		if (racial->type == 2 && unit->target_type == SKILL_TARGET_UNIT) {
			add_fold_string(" for ");
			add_fold_string(unit->target.unit->name);
			add_fold_tag(&unit->target.unit->id);
		}
	}
/*
 * Title?
 */
#ifdef USES_TITLE_SYSTEM
	if (unit->title) {
		add_fold_string(comma);
		add_fold_string(unit->title->title->name);
		add_fold_string(" of ");
		add_fold_string(unit->title->name);
		add_fold_tag(&unit->title->id);
	}
#endif
/*
 * Description
 */
	if (unit->description) {
		add_fold_string(comma);
		add_fold_string(unit->description);
	}
/*
 * On guard?
 */
	if (unit->is_captive)
		add_fold_string(", prisoner");
	if (unit->was_guarding) {
		add_fold_string(", standing guard");
		if (unit->faction != current_faction) {
			add_fold_string(comma);
			add_fold_string(visual_enum(attitude_vs_faction(unit->faction, current_faction), stance_arguments));
		}
	}
/*
 * On patrol?
 */
	if (unit->is_patrolling) {
		add_fold_string(", on patrol");
		if (unit->faction != current_faction) {
			add_fold_string(comma);
			add_fold_string(visual_enum(attitude_vs_faction(unit->faction, current_faction), stance_arguments));
		}
	} else
/*
 * Moving out?
 */
		if (unit->toward) {
			add_fold_string(", moving ");
			if (unit->toward == unit->current)
				add_fold_string("to patrol");
			else {
				if (unit->already_moved > unit->move_for_days/2)
					add_fold_string("in from ");
				else
					add_fold_string("out to ");
				add_fold_string(unit->toward->name);
				add_fold_tag(&unit->toward->id);
			}
			add_fold_char(' ');
			add_fold_char('(');
			add_fold_integer(unit->already_moved);
			add_fold_string(" day");
			if (unit->already_moved > 1)
				add_fold_char('s');
			add_fold_char('/');
			add_fold_integer(unit->move_for_days);
			add_fold_char(')');
		}
/*
 * Private flags?
 */
	if (owner) {
		if (unit->setting_advert)
			add_fold_string(", anonymous");
		if (unit->setting_silent)
			add_fold_string(", silent unit");
#ifdef STEALTH_STATS
		if (unit->setting_report)
			add_fold_string(", announcing presence");
#endif
		if(unit->setting_hushgive)
		    add_fold_string(", quiet gives");
		if(unit->setting_miser)
		    add_fold_string(", miser");
#ifdef USES_FACTION_FUND
		if (unit->setting_support)
			add_fold_string(", supported");
#endif
	}
	if (unit->setting_guard)
		add_fold_string(", on guard");
	if (unit->setting_protect)
		add_fold_string(", protecting access");
/*
 * Unit components
 */
	sep = ", with: ";
	for (items = unit->carrying; items; items = items->next) {
		type = items->item;
		if (owner || unit->size == 0 ||
#ifdef STEALTH_STATS
		    observe > (unit->vital.stealth + 4) ||
#endif
	            type->weight ||
		    (unit->is_captive &&
		     unit->leader->faction == current_faction &&
		     !type->item_type)) {
			if (type->name == 0)
				continue;
			if (items->amount == 0 && (!owner || items->tokens < 100))
				continue;
			add_fold_string(sep);
			sep = comma;
			add_fold_item_amount(items->amount, type);
			if (owner && (items->equipped || items->tokens > 99)) {
				add_fold_char(' ');
				add_fold_char('(');
				if (items->equipped) {
					if (items->equipped < items->amount) {
						add_fold_integer(items->equipped);
						add_fold_char(' ');
					}
					add_fold_string("equipped");
				}
				if (items->tokens > 99) {
					if (items->equipped) {
						add_fold_char(',');
						add_fold_char(' ');
					}
					add_fold_integer(items->tokens / 100);
					add_fold_string(" man-day");
					if (items->tokens > 199)
						add_fold_char('s');
				}
				add_fold_char(')');
			}
#ifdef REPORTS_ITEM_KNOWLEDGE
			if (owner)
				faction_knows_item(current_faction, type);
#endif
		}
	}
}


/**
 ** ADD_FOLD_SKILL_TYPE/LEVEL
 **	Inserts skill level (if any), name and tag
 **/
#ifndef USES_SKILL_LEVELS
static void add_fold_skill_type(skill_s *skill)
{
#else
static void add_fold_skill_level(skill_s *skill, int level)
{
#endif
	skill_s *s = skill;
	int i;
	for(i = 1; i < level; i++) s = s->next_level;
	add_fold_string(s->name);
	add_fold_tag(&s->tag);
}


/**
 ** Report for a set of activities
 **/
static void report_on_actions(event_s *act)
{
/*
 * Recursive
 */
	if (!act)
		return;
	sprintf(work, "%d - %s", act->day, act->text);
	start_fold_string(work);
	print_folded(report, act->day > 9 ? 5 : 4);
	report_on_actions(act->next);
}


/**
 ** REPORT_CAPACITY
 **	What is the unit's capacity
 **/
static void report_capacity(int mode, long capacity, long stack)
{
	add_fold_long(stack);
	if (stack != capacity) {
		add_fold_char('(');
		add_fold_long(capacity);
		add_fold_char(')');
	}
	add_fold_char('/');
	add_fold_string(visual_enum(mode, movement_modes));
}


/**
 ** REPORT_UNIT_CAPACITY
 **	Report what are the capacities for a unit
 **/
static void report_unit_capacity(unit_s *unit)
{
int	mode;
char	*sep;

	add_fold_string(". Weight: ");
	add_fold_long(unit->stack_weight);
	if (unit->weight != unit->stack_weight) {
		add_fold_char('(');
		add_fold_long(unit->weight);
		add_fold_char(')');
	}
	sep = ". Capacity: ";
	for (mode = 0; mode < MAX_MOVE_MODES; mode++)
		if (unit->stack_capacity[mode]) {
			add_fold_string(sep);
			report_capacity(mode, unit->capacity[mode], unit->stack_capacity[mode]);
			sep = comma;
		}
}


/**
 ** REPORT_UNIT_SKILLS
 **	Report all skills that a unit has
 **/
static void report_unit_skills(unit_s *unit, int full_report)
{
experience_s *exp;
int size;
skill_s	*skill;
char	*sep;

	exp = unit->skilled;
	size = unit->size;
/*
 * Loop
 */
	if (size <= 0)
		size = 1;
	for (sep = ". Knows: "; exp; exp = exp->next)
		if (exp->points) {
			skill = exp->skill;
			if (!full_report) {
#ifdef FX_SEE_ALL_MAGE
				if (!evaluate_mage || skill != magecraft || unit->masqing)
#endif
					continue;
			}
			//if (exp->effective)
			//	skill = exp->effective;
			add_fold_string(sep);
			sep = comma;
#ifdef REPORTS_EXPERIENCE_POINTS
			if (!exp->effective && full_report) {
				add_fold_long(exp->points / SKILL_POINTS_PER_DAY);
				add_fold_char('/');
				add_fold_long(skill->for_level / SKILL_POINTS_PER_DAY);
				add_fold_string(" day");
				if (exp->points >= 2*SKILL_POINTS_PER_DAY)
					add_fold_char('s');
				add_fold_string(" of ");
			}
#endif
			add_fold_skill_level(skill, exp->level);
#ifdef REPORTS_SKILL_KNOWLEDGE
			faction_knows_skill_level(current_faction, exp->skill, exp->level);
#endif
		}
}


#ifdef USES_REQUIRED_LEVELS
/**
 ** REGISTER_UNIT_FIELDS
 **	Note down for reporting all fields of a unit
 **/
static void register_unit_fields(unit_s *unit)
{
skill_s		*skill;
experience_s	*exp;
/*
 * Study
 */
	for (skill = skills_list; skill; skill = skill->next)
		if (skill->required_skill &&
		    ((exp = unit_experiences(unit, skill, 0)) == 0 || exp->points == 0) &&
		    may_study_skill(unit, skill)) {
			faction_knows_skill_level(current_faction, skill, 1);
		}
}

/**
 ** REPORT_UNIT_FIELDS
 **	Lists all fields a unit may study
 **/
static void report_unit_fields(unit_s *unit)
{
skill_s		*skill;
experience_s	*exp;
char		*sep = ". May learn: ";
/*
 * Study
 */
	if (!unit->race || unit->race->type != RACE_LEADER) return;

	for (skill = skills_list; skill; skill = skill->next)
		if (skill->required_skill &&
		    ((exp = unit_experiences(unit, skill, 0)) == 0 || exp->points == 0) &&
		    may_study_skill(unit, skill)) {
			add_fold_string(sep);
			sep = comma;
			add_fold_string(skill->name);
			add_fold_tag(&skill->tag);
		}
}
#endif /*USES_REQUIRED_LEVELS*/


/**
 ** REPORT_COMBAT_SETTINGS
 **/
static void report_combat_settings(unit_s *unit)
{
combat_set_s	*setting;
char		*sep;
int		n;
/*
 * Battle setting
 */
	add_fold_string(". Combat: ");
	add_fold_string(visual_enum(unit->participate, participate_modes));
	add_fold_char(',');
	add_fold_char(' ');
	add_fold_string(visual_enum(unit->rank, battlefield_ranks));
	add_fold_char(',');
	add_fold_char(' ');
	add_fold_string(visual_enum(unit->file, battlefield_files));
	add_fold_char(',');
	add_fold_char(' ');
	add_fold_string(visual_enum(unit->movement, battlefield_moves));
/*
 * Actions
 */
	sep = ", actions: ";
	setting = unit->combat;
	for (n = 0; n < MAX_COMBAT_SETTING; n++) {
		if (setting->option == 0)
			break;
		add_fold_string(sep);
		if(setting->once) add_fold_string("-");
		switch (setting->option) {
#ifdef COMBAT_SET_MELEE
		    case COMBAT_SET_MELEE:
			add_fold_string("melee");
			break;
#endif
#ifdef COMBAT_SET_PARRY
		    case COMBAT_SET_PARRY:
			add_fold_string("parry");
			break;
#endif
#ifdef COMBAT_SET_RANGED
		    case COMBAT_SET_RANGED:
			add_fold_string("ranged");
			break;
#endif
#ifdef COMBAT_SET_GUARD
		    case COMBAT_SET_GUARD:
			add_fold_string("guard");
			break;
#endif
#ifdef COMBAT_SET_ITEM
		    case COMBAT_SET_ITEM:
			add_fold_string(setting->u.use_item->name);
			add_fold_tag(&setting->u.use_item->tag);
			break;
#endif
#ifdef COMBAT_SET_SKILL
		    case COMBAT_SET_SKILL:
			add_fold_string(setting->u.use_skill->name);
			add_fold_tag(&setting->u.use_skill->tag);
			break;
#endif
		}
		sep = comma;
		setting++;
	}
}


/**
 ** REPORT_STATS
 **	Display base stats
 **/
void report_stats(stats_s *vital, stats_s *added, unit_s *unit)
{
char	*sep = ". ";
int	total;
/*
 * All stats
 */
	if (vital->melee || (added && added->melee)) {
		add_fold_string(sep);
		if (*sep == '.')
			add_fold_char('M');
		else
			add_fold_char('m');
		add_fold_string("elee:");
		sep = comma;
		add_fold_integer(vital->melee);
		if (added && added->melee) {
			add_fold_char('(');
			add_fold_integer(vital->melee+added->melee);
			add_fold_char(')');
		}
	}
	if (vital->missile || (added && added->missile)) {
		add_fold_string(sep);
		if (*sep == '.')
			add_fold_char('M');
		else
			add_fold_char('m');
		add_fold_string("issile:");
		sep = comma;
		add_fold_integer(vital->missile);
		if (added && added->missile) {
			add_fold_char('(');
			add_fold_integer(vital->missile+added->missile);
			add_fold_char(')');
		}
	}
	if (vital->defense || (added && added->defense)) {
		add_fold_string(sep);
		if (*sep == '.')
			add_fold_char('D');
		else
			add_fold_char('d');
		add_fold_string("efense:");
		sep = comma;
		add_fold_integer(vital->defense);
		if (added && added->defense) {
			add_fold_char('(');
			add_fold_integer(vital->defense+added->defense);
			add_fold_char(')');
		}
	}
	if ((vital->hits > 1) || (added && (added->hits > 1))) {
		add_fold_string(sep);
		add_fold_string("hits:");
		sep = comma;
		add_fold_integer(vital->hits);
		if (added && added->hits) {
			add_fold_char('(');
			add_fold_integer(vital->hits+added->hits);
			add_fold_char(')');
		}
	}
	if ((vital->damage > 1) || (added && (added->damage > 1))) {
		add_fold_string(sep);
		add_fold_string("damage:");
		sep = comma;
		add_fold_integer(vital->damage);
		if (added && added->damage) {
			add_fold_char('(');
			add_fold_integer(vital->damage+added->damage);
			add_fold_char(')');
		}
	}
	if ((vital->life > 1) || (added && (added->life > 1))) {
		add_fold_string(sep);
		add_fold_string("life:");
		sep = comma;
		add_fold_integer(vital->life);
		if (added && added->life) {
			add_fold_char('(');
			add_fold_integer(vital->life+added->life);
			add_fold_char(')');
		}
	}
#ifdef BATTLE_INITIATIVE
	if (added)
		total = added->initiative;
	else
		total = 0;
	total += vital->initiative;
	if((added && added->initiative) || (vital && vital->initiative)) {
		add_fold_string(sep);
		add_fold_string("initiative:");
		sep = comma;
		add_fold_integer(total);
	}
#endif
#ifdef USES_CASH_UPKEEP
	if (vital->upkeep) {
		add_fold_string(sep);
		add_fold_string("upkeep: $");
		sep = comma;
		add_fold_integer(vital->upkeep);
	}
#endif
#ifdef STEALTH_STATS
	if (vital->stealth) {
		add_fold_string(sep);
		add_fold_string("stealth:");
		sep = comma;
		if (unit && unit->effective_stealth != vital->stealth) {
			add_fold_integer(unit->effective_stealth);
			add_fold_char('(');
			add_fold_integer(vital->stealth);
			add_fold_char(')');
		} else
			add_fold_integer(vital->stealth);
	}
	if (vital->observation) {
		add_fold_string(sep);
		add_fold_string("observation:");
		sep = comma;
		if (unit && unit->effective_observe != vital->observation) {
			add_fold_integer(unit->effective_observe);
			add_fold_char('(');
			add_fold_integer(vital->observation);
			add_fold_char(')');
		} else
			add_fold_integer(vital->observation);
	}
#endif
#ifdef USES_MANA_POINTS
	if (vital->mana || (added && added->mana)) {
		add_fold_string(sep);
		add_fold_string("mana:");
		sep = comma;
		add_fold_integer(vital->mana);
		if (added && added->mana) {
			add_fold_char('(');
			add_fold_integer(vital->mana+added->mana);
			add_fold_char(')');
		}
	}
#endif
}


/**
 ** REPORT_ON_UNITS
 ** Report for a unit of the faction (or newly of the faction)
 **/
static void report_on_units(unit_s *unit)
{
/*
 * Make sure
 */
	if (unit->faction != current_faction && unit->now_loyal != current_faction)
		return;
	unit->full_day = 1;
	if (unit->inactive)
		return;
/*
 * Unit
 */
	fprintf(report, "%s [%s]'s actions:\n", unit->name, unit->id.text);
	if (!unit->events) {
		fprintf(report, "30 - nothing remarkable\n");
	} else
		if (unit->now_loyal == current_faction && unit->faction != current_faction) {
			fprintf(report, "30 - unit now loyal to you\n");
		} else
			report_on_actions(unit->events);
/*
 * Describe unit
 */
	empty_fold_string();
#ifdef STEALTH_STATS
	add_fold_unit_visible(unit, 1, 0);
#else
	add_fold_unit_visible(unit, 1);
#endif
/*
 * Any skill?
 */
	if (unit->size) {
		if (unit->skilled) {
			report_unit_skills(unit, 1);
			register_unit_fields(unit);
		}
		compute_stack_capacity(unit);
#ifdef STEALTH_STATS
		compute_stack_stealth(unit);
#endif
		report_unit_capacity(unit);
/*
 * Display vital stats
 */
		compute_unit_stats(unit);
		if (unit->race->type == RACE_LEADER)
			report_stats(&unit->vital, &unit->bonus, unit);
		else
			report_stats(&unit->bonus, 0, unit);
		if (unit->vital.control) {
			add_fold_string(", control:");
			add_fold_integer(unit->vital.control);
		}
/*
 * Report battle positions for unit
 */
		report_combat_settings(unit);
	}
/*
 * Done
 */
	add_fold_char('.');
	print_folded(report, 2);
	if (unit->dead)
		fprintf(report, "        (Unit is dead)\n");
	else
		if (unit->now_loyal && unit->now_loyal != current_faction)
			fprintf(report, "        (Unit is now loyal to %s [%s])\n",
					unit->now_loyal->id.text, unit->now_loyal->name);
	putc('\n', report);
}


/**
 ** LOCATION_UNIT_REPORT
 **	Report on the location's units
 **/
#ifdef STEALTH_STATS
static void location_unit_report(unit_s *unit, int indent, int leading, int observe, int guess)
#else
static void location_unit_report(unit_s *unit, int indent)
#endif
{
int	i;
int	report_vitals,
	report_caps,
	report_skills;
/*
 * Unit appears?
 */
	if (!unit)
		return;
#ifdef STEALTH_STATS
	if (unit->faction == current_faction ||
	    unit->now_loyal == current_faction)
		leading = 1;
	if (!unit->setting_report)
		if (!leading && unit->effective_stealth > observe)
			return;
	if (unit->faction != current_faction &&
	    unit->now_loyal != current_faction)
		leading = 0;
#endif
/*
 * Initial indent
 */
	empty_fold_string();
	if(!unit->sneaking || (unit->faction == current_faction) ||
			(unit->now_loyal == current_faction)) {
		for (i = 0; i < indent; i++)
			add_fold_char(' ');
		i = 0;
		if ((unit->faction == current_faction && (unit->now_loyal == 0 || unit->now_loyal == current_faction)) ||
		    unit->now_loyal == current_faction) {
			add_fold_char('*');
			i = 1;
		} else {
			if(attitude_vs(current_faction, unit) == ATTITUDE_IS_ALLY)
				add_fold_char('+');
			else
				add_fold_char('-');
		}
		add_fold_char(' ');
#ifdef STEALTH_STATS
		add_fold_unit_visible(unit, i, guess);
#else
		add_fold_unit_visible(unit, i);
#endif
		report_vitals = i;
		report_caps = i;
		report_skills = i;
		if (i) {
			if (unit->now_loyal && unit->now_loyal != current_faction) {
				add_fold_string(", now loyal to ");
				add_fold_string(unit->now_loyal->name);
				add_fold_tag(&unit->now_loyal->id);
			}
		}
#ifdef FX_MAGIC_EYE
		if (magic_eye)
			report_vitals = 1;
#endif
#ifdef STEALTH_STATS
#ifdef STEALTH_DISCLOSES_STATS
		if (unit->vital.stealth + STEALTH_DISCLOSES_STATS < observe)
			report_vitals = 1;
		if (unit->vital.stealth + STEALTH_DISCLOSES_STATS+1 < observe)
			report_caps = 1;
#endif
#ifdef STEALTH_DISCLOSES_SKILLS
		if (unit->vital.stealth + STEALTH_DISCLOSES_SKILLS < observe)
			report_skills = 1;
#endif
#endif
/*
 * What is visible?
 */
		if (unit->size) {
			if (report_vitals) {
				if (unit->race->type == RACE_LEADER)
					report_stats(&unit->vital, &unit->bonus, unit);
				else
					report_stats(&unit->bonus, 0, unit);
				if (unit->vital.control) {
					add_fold_string(", control:");
					add_fold_integer(unit->vital.control);
				}
			}
			if (unit->skilled)
				report_unit_skills(unit, report_skills);
		}
		if (report_caps)
			report_unit_capacity(unit);
/*
 * Unit is leading a stack?
 */
		if ((unit = unit->stack) != 0)
			add_fold_string(". Leading:");
		else
			add_fold_char('.');
		indent += 2;
	} else {
		unit = unit->stack;
	}
	for (print_folded(report, indent); unit; unit = unit->next_location)
#ifdef STEALTH_STATS
		location_unit_report(unit, indent, leading, observe, guess);
#else
		location_unit_report(unit, indent);
#endif
}


/**
 ** REPORT_ONE_EXIT
 **	Common to local and remote exits.
 **/
static void report_one_exit(location_s *here, direction_s *dir)
{
	start_fold_string("   ");
	add_fold_string(dir->name);
	add_fold_string(", to ");
	add_fold_string(dir->toward->name);
	if(dir->toward->region) {
		add_fold_string(" <");
		add_fold_string(visual_enum(dir->toward->region, regions));
		add_fold_char('>');
	}
	add_fold_tag(&dir->toward->id);
#ifdef REPORT_OVERLAND_COORDINATES
	if(dir->toward->type->type == TERRAIN_COUNTRY) {
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(dir->toward->x);
		add_fold_char(',');
		add_fold_integer(dir->toward->y);
		add_fold_char(')');
	}
#endif
	add_fold_char(',');
	add_fold_char(' ');
	add_fold_string(dir->toward->type->name);
	add_fold_char(',');
	add_fold_char(' ');
	if (dir->skill) {
#ifdef USES_SKILL_LEVELS
		if (is_skill_available(here, current_faction, dir->skill, dir->level)) {
#else
		if (is_skill_available(here, current_faction, dir->skill)) {
#endif
			add_fold_integer(dir->days);
			add_fold_string(" days using ");
#ifdef USES_SKILL_LEVELS
			add_fold_skill_level(dir->skill, dir->level);
#else
			add_fold_skill_type(dir->skill);
#endif
		} else
			add_fold_string(" impassable");
	} else
		if (dir->days >= 0) {
			add_fold_integer(dir->days);
			add_fold_string(" day");
			if (dir->days != 1)
				add_fold_char('s');
			if (dir->mode) {
				add_fold_char(' ');
				add_fold_string(visual_enum(dir->mode, movement_modes));
			}
		} else
			add_fold_string("impassable");
	print_folded(report, 15);
}


/**
 ** REPORT_LOCATIONAL_SKILLS
 **	Skills are available for teaching
 **/
static int report_locational_skills(char *heading, experience_s *skills)
{
char	*sep;
/*
 * Simplest case
 */
	if (!skills)
		return 0;
	start_fold_string(heading);
	sep = "Skills available: ";
/*
 * Many many skills!
 */
	while (skills) {
		add_fold_string(sep);
#ifdef USES_SKILL_LEVELS
		add_fold_skill_level(skills->skill, skills->level);
#ifdef REPORTS_SKILL_KNOWLEDGE
		faction_knows_skill_level(current_faction, skills->skill, skills->level);
#endif
		if (!skills->effective) {
			add_fold_char(' ');
			add_fold_char('(');
			add_fold_integer(skills->points / SKILL_POINTS_PER_DAY);
			add_fold_string(" day");
			if (skills->points >= SKILL_POINTS_PER_DAY)
				add_fold_char('s');
			add_fold_char(')');
		}
#else
		add_fold_skill_type(skills->skill);
#ifdef REPORTS_SKILL_KNOWLEDGE
		faction_knows_skill(current_faction, skills->skill);
#endif
#endif
		sep = comma;
		skills = skills->next;
	}
	return 1;
}


#ifdef USES_TITLE_SYSTEM
/**
 ** REPORT_TITLE
 **/
static void report_title(char *text, title_s *title, unit_s *unit, int margin)
{
	start_fold_string(text);
	add_fold_string(title->name);
	add_fold_tag(&title->tag);
	add_fold_string(" (");
	add_fold_string(visual_enum(title->type, title_kinds));
	add_fold_string(", $");
	add_fold_integer(title->cost);
	add_fold_string(", requires ");
#ifdef USES_SKILL_LEVELS
	add_fold_skill_level(title->required, title->level);
#ifdef REPORTS_SKILL_KNOWLEDGE
	faction_knows_skill_level(current_faction, title->required, title->level);
#endif
#else
	add_fold_skill_type(title->required);
#ifdef REPORTS_SKILL_KNOWLEDGE
	faction_knows_skill(current_faction, title->required);
#endif
#endif
	add_fold_char(')');
	if (unit) {
		add_fold_string(", held by ");
		add_fold_string(unit->name);
		add_fold_tag(&unit->id);
	}
	add_fold_char('.');
	print_folded(report, margin);
}
#endif


#ifdef STEALTH_STATS
/**
 ** RECURSIVE_OBSERVE
 **	Find out at which level the user is observing things' characteristics!
 **/
static int recursive_observe(unit_s *unit, int observe)
{
	while (unit) {
		if (unit->faction == current_faction &&
		    unit->effective_observe > observe)
			observe = unit->effective_observe;
		unit = unit->next_visible;
	}
	return observe;
}
#endif


#ifdef HIDE_RESOURCES
/**
 ** RECURSIVE_DETECTION
 **	Find out if a resource is visible by a faction. To be visible, a
 ** unit must know either the FX_SEE_RESOURCES skill, or be able to
 ** harvest the resource.  Recursive is a misnommer: it's no longer a
 ** recursive check.
 **/
static int recursive_detection(unit_s *unit, item_s *item)
{
/*
 * Loop on all units
 */
	while (unit) {
		if (unit->faction == current_faction)
			if (may_see_item(unit, item))
				return 1;
		unit = unit->next_visible;
	}
	return 0;
}


/**
 ** NO_EXPERT_VISIT
 **	Find out if a resource is visible by a faction. To be visible, a
 ** unit must have visited or looked at the know either the FX_SEE_RESOURCES skill, or be able to
 ** harvest the resource.  Recursive is a misnommer: it's no longer a
 ** recursive check.
 **/
static int no_expert_visit(item_s *item, seen_s *experts)
{
	seen_s *texpert = experts;
/*
 * Loop on all experts that did visit
 */
	while (texpert) {
		if (texpert->expert &&
		    (texpert->expert->faction == current_faction) &&
		    may_see_item(texpert->expert, item))
			return 0;
		texpert = texpert->next;
	}
	return 1;
}

static int location_visible_resource(location_s *loc, item_s *item, location_s *outer)
{
	unit_s *unit;
	seen_s *seen;
	if(loc->type->type == TERRAIN_STRUCTURE) {
		for(unit = loc->present; unit; unit = unit->next_location) {
			/* Maybe they could see it */
			if(unit->faction == current_faction) {
				if(!item->item_hidden) return 1;
				if(no_expert_visit(item, loc->witness))
					return 0;
				return 1;
			}
		}
		/* Okay, no unit currently in the location for them */
		/* Did they even visit the location */
		for(seen = loc->witness; seen; seen = seen->next) {
			if(seen->witness == current_faction) {
				if(!item->item_hidden) return 1;
				if(no_expert_visit(item, loc->witness))
					return 0;
				return 1;
			}
		}
		return 0;
	} else {
		if(item->item_hidden &&
		   no_expert_visit(item, outer->witness)  &&
		   !recursive_detection(outer->interacting, item))
			return 0;
	}
	return 1;
}
#endif


/**
 ** REPORT_ONE_LOCATION
 **	Full report on one location that one of our units visited
 ** this turn.
 **/
static void report_one_location(location_s *location)
{
location_s	*outer,
		*inner;
seen_s		*visit;
direction_s	*exits;
recruit_s	*jobs;
market_s	*market;
resource_s	*products;
event_s		*events;
unit_s		*unit;
item_s		*item;
#ifdef USES_TITLE_SYSTEM
#ifdef LOCATION_FACTION_CONTROL
control_s	*land;
#endif
#endif
char		*sep;
int		type;
#ifdef STEALTH_STATS
int		observe = -99, guess = -99;
#endif
int		civilised;
/*
 * Where are we?
 */
#ifdef DYNAMICALLY_DEFINED_GAME
	if (location->partial)
		printf("Partial location %s [%s] visited by faction %s\n", location->name, location->id.text, current_faction->id.text);
#endif
	start_fold_string(location->name);
	if(location->region) {
		add_fold_string(" <");
		add_fold_string(visual_enum(location->region, regions));
		add_fold_char('>');
	}
	add_fold_tag(&location->id);
#ifdef REPORT_OVERLAND_COORDINATES
	if(location->type->type == TERRAIN_COUNTRY) {
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(location->x);
		add_fold_char(',');
		add_fold_integer(location->y);
		add_fold_char(')');
	}
#endif
	add_fold_string(comma);
/*
 * Prosperity
 */
	add_fold_string(location->type->name);
#if 0
	if (location->optima) {
		if (location->optima < location->type->optima / 3)
			add_fold_string(" (devastated)");
		else if (location->optima*3 < location->type->optima * 2)
			add_fold_string(" (desolate)");
		else if (location->optima*3 > location->type->optima * 5)
			add_fold_string(" (rich)");
		else if (location->optima*3 > location->type->optima * 4)
			add_fold_string(" (prosperous)");
	}
#endif
	type = location->type->type;
	if ((outer = location->outer) != 0) {
		add_fold_string(" located in ");
		add_fold_string(outer->name);
		if(outer->region) {
			add_fold_string(" <");
			add_fold_string(visual_enum(outer->region, regions));
			add_fold_char('>');
		}
		add_fold_tag(&outer->id);
#ifdef REPORT_OVERLAND_COORDINATES
		if(outer->type->type == TERRAIN_COUNTRY) {
			add_fold_char(' ');
			add_fold_char('(');
			add_fold_integer(outer->x);
			add_fold_char(',');
			add_fold_integer(outer->y);
			add_fold_char(')');
		}
#endif
		add_fold_string(comma);
		add_fold_string(outer->type->name);
	}
#ifdef USES_TITLE_SYSTEM
#ifdef LOCATION_FACTION_CONTROL
	else {
		sep = ", lands of the ";
		for (land = location->control_by; land; land = land->next) {
			unit = land->u.unit;
			if (unit->title) {
				if (sep[2] == 't' && !land->next)
					sep = ", and the ";
				add_fold_string(sep);
				add_fold_string(unit->title->title->name);
				add_fold_char(' ');
				add_fold_string(unit->name);
				sep = ", the ";
			}
		}
	}
#endif
#endif
	add_fold_char('.');
	print_folded(report, 6);
	who_is_present(location);
/*
 * Climatic report
 */
	inner = outer ? outer : location;
/*
	if (location->description) {
		start_fold_string(location->description);
		print_folded(report, 2);
	}
*/
/*
 * Title
 */
#ifdef USES_TITLE_SYSTEM
	if (location->title)
		report_title("Title: ", location->title, location->holder, 7);
#endif
/*
 * Population
 */
	if (location->population) {
		start_fold_string("Population: ");
		add_fold_integer(location->population);
		add_fold_char(' ');
		if (location->racial) {
#ifdef REPORTS_RACIAL_KNOWLEDGE
			faction_knows_race(current_faction, location->racial);
#endif
			add_fold_string(location->racial->plural);
			add_fold_tag(&location->racial->tag);
		} else
			add_fold_string("people");
		civilised = location->optima + location->population;
		civilised *= 5;
		civilised /= location->type->optima;
		if (civilised < 7)
			add_fold_string(" in refugee camps.");
		else if (civilised < 9)
			add_fold_string(" in camps");
		else if (civilised < 10)
			add_fold_string(" in tents");
		else if (civilised < 12)
			add_fold_string(" in hovels");
		else if (civilised < 15)
			add_fold_string(" in brick houses");
		else
			add_fold_string(" in stone houses");
		print_folded(report, 2);
/*
 * Recruitment opportunities
 */
		start_fold_string("For hire: ");
		sep = "";
		for (jobs = location->opportunity; jobs; jobs = jobs->next)
			if (jobs->amount) {
				add_fold_string(sep);
				add_fold_integer(jobs->amount);
				add_fold_char(' ');
				add_fold_string(jobs->amount > 1 ? jobs->type->plural :
								 jobs->type->name);
#ifdef REPORTS_RACIAL_KNOWLEDGE
				faction_knows_race(current_faction, jobs->type);
#endif
				add_fold_tag(&jobs->type->tag);
				add_fold_string(" at $");
				add_fold_integer(jobs->price);
				sep = comma;
			}
		if (*sep) {
			add_fold_char('.');
			print_folded(report, 10);
		}
	}
/*
 * Market
 */
	start_fold_string("For sale: ");
	sep = "";
	for (market = location->markets; market; market = market->next)
		if (market->offered.initial_amount && market->turns) {
#ifdef REPORTS_ITEM_KNOWLEDGE
			faction_knows_item(current_faction, market->type);
#endif
			add_fold_string(sep);
			add_fold_item_amount(market->offered.initial_amount, market->type);
			if (market->offered.amount_remains <= 0) add_fold_string("(*)");
			add_fold_string(" at $");
			add_fold_integer(market->offered.negociated_price);
			sep = comma;
		}
	if (*sep) {
		add_fold_char('.');
		print_folded(report, 10);
	}
	start_fold_string("Buying: ");
	sep = "";
	for (market = location->markets; market; market = market->next)
		if (market->wanted.initial_amount && market->turns) {
#ifdef REPORTS_ITEM_KNOWLEDGE
/*			faction_knows_item(current_faction, market->type); */
#endif
			add_fold_string(sep);
			add_fold_item_amount(market->wanted.initial_amount, market->type);
			if (market->wanted.amount_remains <= 0) add_fold_string("(*)");
			add_fold_string(" at $");
			add_fold_integer(market->wanted.negociated_price);
			sep = comma;
		}
	if (*sep) {
		add_fold_char('.');
		print_folded(report, 8);
	}
	start_fold_string("Resources: ");
	sep = "";
	for (products = location->resources; products; products = products->next)
		if (products->amount) {
			item = products->type;
#ifdef HIDE_RESOURCES
			if (item->item_hidden &&
			    no_expert_visit(item, location->witness) &&
			    !recursive_detection(location->interacting, item))
				continue;
#endif
#ifdef REPORTS_ITEM_KNOWLEDGE
			faction_knows_item(current_faction, item);
#endif
			add_fold_string(sep);
			add_fold_item_amount(products->amount, item);
			if (products->remains <= 0) add_fold_string("(*)");
			sep = comma;
		}
	if (*sep) {
		add_fold_char('.');
		print_folded(report, 11);
	}
	if (report_locational_skills("", location->skills))
		print_folded(report, 18);
/*
 * Directions
 */
	fprintf(report, "Directions:\n");
	if (outer) {
		fprintf(report, "   Out, to %s [%s]", outer->name, outer->id.text);
#ifdef REPORT_OVERLAND_COORDINATES
		if(outer->type->type == TERRAIN_COUNTRY)
			fprintf(report, " (%d,%d)", outer->x, outer->y);
#endif
		fprintf(report, ", %s, ", outer->type->name);
		if (type == TERRAIN_STRUCTURE)
			fprintf(report, "immediate\n");
		else
			fprintf(report, "1 day\n");
	}
	for (exits = location->exits; exits; exits = exits->next)
		report_one_exit(location, exits);
	if (outer && (exits = outer->exits) != 0)
		for (fprintf(report, "From outer location:\n"); exits; exits = exits->next)
			report_one_exit(location, exits);
/*
 * Events during period
 */
	fprintf(report, "Events during turn:\n");
	type = 0;
	for (events = location->events; events; events = events->next) {
		visit = location->witness;
		if (!visit)
			break;
		while (visit) {
			if (events->day < visit->day_start) {
				visit = visit->next;
				continue;
			}
			if((visit->witness == current_faction) &&
			   (visit->day_end >= events->day)) {
				break;
			}
			visit = visit->next;
		}
		if (!visit)
			continue;
#ifdef STEALTH_STATS
		if (events->stealth > visit->observation)
			continue;
#endif
		empty_fold_string();
		add_fold_integer(events->day);
		add_fold_string(" - ");
		add_fold_string(events->text);
		print_folded(report, (events->day > 9) ? 5 : 4);
		type = 1;
	}
	if (!type)
		fprintf(report, "30 - nothing notable\n");
/*
 * Final report?
 */
	visit = location->witness;
	while(visit) {
		if(visit->witness == current_faction && visit->day_end >= 31)
			break;
		visit = visit->next;
		
	}
/*
 * All units present
 */
#ifdef FX_MAGIC_EYE
	magic_eye = is_fx_available(location, current_faction, FX_MAGIC_EYE);
#endif
#ifdef FX_EVALUATE_VOID
	evaluate_void = is_fx_available(location, current_faction, FX_EVALUATE_VOID);
#endif
#ifdef FX_SEE_ALL_MAGE
	evaluate_mage = is_fx_available(location, current_faction, FX_SEE_ALL_MAGE);
#endif
	putc('\n', report);
	if (visit) {
#ifdef STEALTH_STATS
		observe = visit->observation;
		guess = recursive_observe(location->interacting, observe);
#endif
		for (unit = location->present; unit; unit = unit->next_location)
#ifdef STEALTH_STATS
			location_unit_report(unit, 0, 0, observe, guess);
#else
			location_unit_report(unit, 0);
#endif
		putc('\n', report);
	}
/*
 * All sub-structures
 */
	for (inner = location->inner; inner; inner = inner->next_inner) {
		fprintf(report, "> %s [%s], %s", inner->name, inner->id.text, inner->type->name);
		if (inner->type->type == TERRAIN_INNER)
			fprintf(report, ", inner location (1 day)");
		putc('.', report);
		putc('\n', report);
		if (inner->partial) {
#ifdef DYNAMICALLY_DEFINED_GAME
			printf("Partial location %s [%s] visited by faction %s\n", inner->name, inner->id.text, current_faction->id.text);
#endif
			start_fold_string("  Unfinished, requires: ");
			sep = "";
			for (products = inner->resources; products; products = products->next)
				if (products->amount) {
#ifdef REPORTS_ITEM_KNOWLEDGE
					faction_knows_item(current_faction, products->type);
#endif
					add_fold_string(sep);
					add_fold_item_amount(products->amount, products->type);
					sep = comma;
				}
			if (*sep) {
				add_fold_char('.');
				print_folded(report, 24);
			}
		} else {
			start_fold_string("  Local resources: ");
			sep = "";
			for (products = inner->resources; products; products = products->next)
				if (products->amount) {
					item = products->type;
#ifdef HIDE_RESOURCES
					if(!location_visible_resource(inner, item, location))
						continue;
#endif
#ifdef REPORTS_ITEM_KNOWLEDGE
					faction_knows_item(current_faction, item);
#endif
					add_fold_string(sep);
					add_fold_item_amount(products->amount, item);
			        if (products->remains <= 0) add_fold_string("(*)");
					sep = comma;
				}
			if (*sep) {
				add_fold_char('.');
				print_folded(report, 19);
			}
		}
#ifdef USES_TITLE_SYSTEM
		if (inner->title)
			report_title("  Title: ", inner->title, inner->holder, 9);
#endif
		if (report_locational_skills("  ", inner->skills))
			print_folded(report, 20);
		if (inner->type->type == TERRAIN_STRUCTURE && visit)
			for (unit = inner->present; unit; unit = unit->next_location)
#ifdef STEALTH_STATS
				location_unit_report(unit, 2, 0, observe, guess);
#else
				location_unit_report(unit, 2);
#endif
		putc('\n', report);
	}
	putc('\n', report);
}


/**
 ** REPORT_ALL_LOCATIONS
 **	Provide a report on all locations visited during turn
 **/
static void report_all_locations(void)
{
location_s	*location;
seen_s		*visited;
int		presence;
/*
 * Go!
 */
	presence = 1;
	for (location = location_list; location; location = location->next)
		if (location->type->type != TERRAIN_STRUCTURE)
			for (visited = location->witness; visited; visited = visited->next)
				if (visited->witness == current_faction) {
					if (presence) {
						fprintf(report, "\nLocations:\n");
						presence = 0;
					}
					report_one_location(location);
					break; /* out of visited loop! */
				}
/*
 * No units anywhere?
 */
	if (presence) {
		fprintf(report, "\nLocations:\nnone\n");
		printf("Faction %s is nowhere\n", current_faction->id.text);
	}
}


#ifdef REPORTS_KNOWLEDGE
/**
 ** REPORT_STAT_BONUS
 **	Common to skill & item reports
 **/
static void report_stat_bonus(stats_s *stat, char *sep)
{
#ifdef BATTLE_INITIATIVE
	if (stat->initiative) {
		add_fold_string(sep);
		add_fold_signed(stat->initiative);
		add_fold_string(" to initiative");
		sep = comma;
	}
#endif
	if (stat->melee) {
		add_fold_string(sep);
		add_fold_signed(stat->melee);
		add_fold_string(" to melee");
		sep = comma;
	}
	if (stat->missile) {
		add_fold_string(sep);
		add_fold_signed(stat->missile);
		add_fold_string(" to missile");
		sep = comma;
	}
	if (stat->defense) {
		add_fold_string(sep);
		add_fold_signed(stat->defense);
		add_fold_string(" to defense");
		sep = comma;
	}
	if (stat->hits) {
		add_fold_string(sep);
		add_fold_signed(stat->hits);
		add_fold_string(" to hits");
		sep = comma;
	}
	if (stat->damage) {
		add_fold_string(sep);
		add_fold_signed(stat->damage);
		add_fold_string(" to damage");
		sep = comma;
	}
	if (stat->life) {
		add_fold_string(sep);
		add_fold_signed(stat->life);
		add_fold_string(" to life");
		sep = comma;
	}
#ifdef STEALTH_STATS
	if (stat->stealth) {
		add_fold_string(sep);
		add_fold_signed(stat->stealth);
		add_fold_string(" to stealth");
		sep = comma;
	}
	if (stat->observation) {
		add_fold_string(sep);
		add_fold_signed(stat->observation);
		add_fold_string(" to observation");
		sep = comma;
	}
#endif
#ifdef USES_CONTROL_POINTS
	if (stat->control) {
		add_fold_string(sep);
		add_fold_signed(stat->control);
		add_fold_string(" to control");
		sep = comma;
	}
#endif
#ifdef USES_MANA_POINTS
	if (stat->mana) {
		add_fold_string(sep);
		add_fold_signed(stat->mana);
		add_fold_string(" to maximum mana");
		sep = comma;
	}
#endif
}


/**
 ** REPORT_COMBAT_ACTION
 **	Use of items or skill during combat is allowed
 **/
static void report_combat_values(combat_s *combat)
{
char	*sep;
/*
 * Initiative is always as a bonus
 */
#ifdef BATTLE_INITIATIVE
	if (combat->bonus.initiative) {
		add_fold_string(". Initiative ");
		add_fold_signed(combat->bonus.initiative);
	}
#endif
/*
 * Target of action
 */
	add_fold_string(". Target: ");
	add_fold_string(visual_enum(combat->target, battlefield_targets));
/*
 * Range
 */
	if (combat->target >= BATTLEFIELD_TARGET_FRIENDLY) {
		add_fold_string(". Range: ");
		add_fold_string(visual_enum(combat->range, battlefield_ranges));
	}
/*
 * Product
 */
	add_fold_string(". Effect: ");
	add_fold_string(visual_enum(combat->effect, battlefield_actions));
	sep = " with modifiers ";
	if (combat->action.melee) {
		add_fold_string(sep);
		add_fold_integer(combat->action.melee);
		add_fold_string(" melee");
		sep = comma;
	} else
		if (combat->bonus.melee) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.melee);
			add_fold_string(" melee");
			sep = comma;
		}
	if (combat->action.missile) {
		add_fold_string(sep);
		add_fold_integer(combat->action.missile);
		add_fold_string(" missile");
		sep = comma;
	} else
		if (combat->bonus.missile) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.missile);
			add_fold_string(" missile");
			sep = comma;
		}
	if (combat->action.defense) {
		add_fold_string(sep);
		add_fold_integer(combat->action.defense);
		add_fold_string(" defense");
		sep = comma;
	} else
		if (combat->bonus.defense) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.defense);
			add_fold_string(" defense");
			sep = comma;
		}
	if (combat->action.hits) {
		add_fold_string(sep);
		add_fold_integer(combat->action.hits);
		add_fold_string(" hits");
		sep = comma;
	} else
		if (combat->bonus.hits) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.hits);
			add_fold_string(" hits");
			sep = comma;
		}
	if (combat->action.damage > 1) {
		add_fold_string(sep);
		add_fold_integer(combat->action.damage);
		add_fold_string(" damage");
		sep = comma;
	} else
		if (combat->bonus.damage) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.damage);
			add_fold_string(" damage");
			sep = comma;
		}
	if (combat->action.life) {
		add_fold_string(sep);
		add_fold_integer(combat->action.life);
		add_fold_string(" life");
		sep = comma;
	} else
		if (combat->bonus.life) {
			add_fold_string(sep);
			add_fold_signed(combat->bonus.life);
			add_fold_string(" life");
			sep = comma;
		}
	if (combat->damage) {
		add_fold_string(sep);
		add_fold_string(visual_enum(combat->damage, battle_damage_types));
		add_fold_string(" damage");
		sep = comma;
	}
}
#endif


#ifdef REPORTS_RACIAL_KNOWLEDGE
/**
 ** REPORT_NEW_RACE_KNOWN
 **/
static void report_new_races_known(raceknow_s *know)
{
race_s		*race;
experience_s	*exp;
char		*sep;
int		i;
/*
 * Loop on all races, report only new ones
 */
	sep = "\nRace knowledge:\n";
	for (; know; know = know->next)
		if (!know->report) {
			race = know->about;
			fprintf(report, "%s\n", sep);
			start_fold_string(race->name);
			add_fold_tag(&race->tag);
			add_fold_char(':');
			add_fold_char(' ');
			if (race->description)
				add_fold_string(race->description);
			else {
#ifdef DYNAMICALLY_DEFINED_GAME
				printf("No description text for %s for faction %s\n", race->tag.text, current_faction->id.text);
#endif
				add_fold_string("No description");
			}
/*
 * Race weight?
 */
			if (race->weight) {
				add_fold_string(". Weight ");
				add_fold_long(race->weight);
			}
/*
 * Race has capacity
 */
			sep = ". Capacity: ";
			for (i = 0; i < MAX_MOVE_MODES; i++)
				if (race->capacity[i]) {
					add_fold_string(sep);
					add_fold_long(race->capacity[i]);
					add_fold_char('/');
					add_fold_string(visual_enum(i, movement_modes));
					sep = comma;
				}
/*
 * Describe
 */
			if (race->base_cost) {
				add_fold_string(". Base recruit price: $");
				add_fold_integer(race->base_cost);
			}
#ifdef USES_CASH_UPKEEP
			if (race->intrinsic.upkeep) {
				add_fold_string(". Upkeep: $");
				add_fold_integer(race->intrinsic.upkeep);
				add_fold_string(" per figure");
			}
#endif
/*
 * Intrinsic benefits
 */
			report_stats(&race->intrinsic, 0, 0);
/*
 * Skills
 */
			sep = ". Racial modifiers: ";
			for (exp = race->skilled; exp; exp = exp->next) {
				add_fold_string(sep);
#ifdef USES_SKILL_LEVELS
				add_fold_skill_level(exp->skill, exp->level);
#else
				add_fold_skill_type(exp->skill);
#endif
				sep = comma;
			}
#ifdef RACE_FAVOR_SKILLS
			for (exp = race->favors; exp; exp = exp->next) {
				add_fold_string(sep);
				add_fold_integer(exp->points);
				add_fold_string("% to ");
				add_fold_string(exp->skill->name);
				add_fold_tag(&exp->skill->tag);
				add_fold_string(" skill");
				sep = comma;
			}
#endif
/*
 * Reported
 */
			add_fold_char('.');
			print_folded(report, 2);
			sep = "";
		}
}
#endif


#ifdef REPORTS_ITEM_KNOWLEDGE
/**
 ** REPORT_NEW_ITEM_KNOWN
 **/
static void report_new_item_known(itemknow_s *know)
{
char	*sep;
item_s	*item;
int	i;
/*
 * Loop on all items, report only new ones
 */
	sep = "\nItem knowledge:\n";
	for (; know; know = know->next)
		if (!know->report) {
			item = know->about;
			if (item->item_type > ITEM_ITEM)
				continue;
			fprintf(report, "%s\n", sep);
			start_fold_string(item->name);
			if (item->item_type <= ITEM_ITEM)
				add_fold_tag(&item->tag);
			add_fold_char(':');
			add_fold_char(' ');
			if (item->description)
				add_fold_string(item->description);
			else {
#ifdef DYNAMICALLY_DEFINED_GAME
				printf("No description text for %s found by %s\n", item->tag.text, current_faction->id.text);
#endif
				add_fold_string("No description");
			}
			add_fold_string(visual_enum(item->item_type, item_types));
/*
 * Equipment requirements
 */
			if ((i = item->equip_category) != 0) {
				add_fold_string(". Equipment: ");
				add_fold_string(visual_enum(i, equipment_categories));
				add_fold_string(" (max ");
				add_fold_integer(item->equip_maximum);
				if (item->equip_skill) {
					add_fold_string("), requires ");
					add_fold_skill_level(item->equip_skill, item->equip_level);
				} else {
					add_fold_string(")");
				}
			}
/*
 * Item is heavy?
 */
			if (item->weight) {
				add_fold_string(". Weight ");
				add_fold_long(item->weight);
			}
/*
 * Item provide capacity
 */
			sep = ". Capacity: ";
			for (i = 0; i < MAX_MOVE_MODES; i++)
				if (item->capacity[i] || item->equip_capacity[i]) {
					add_fold_string(sep);
					add_fold_long(item->capacity[i]);
					add_fold_char('/');
					add_fold_string(visual_enum(i, movement_modes));
					if (item->equip_category && item->equip_capacity[i] != item->capacity[i]) {
						add_fold_char(' ');
						add_fold_char('(');
						add_fold_long(item->equip_capacity[i]);
						add_fold_string(" while equipped)");
					}
					sep = comma;
				}
/*
 * Equipment benefits
 */
			switch (item->item_type) {
			    case ITEM_FOLLOWER:
			    case ITEM_BEAST:
				report_stats(&item->equip_bonus, 0, 0);
				if(item->equip_bonus.control) {
					add_fold_string(", control:");
					add_fold_integer(item->equip_bonus.control);
				}
				if (item->combat_action.effect) {
					add_fold_string(". Attack: ");
					add_fold_string(visual_enum(item->combat_action.effect, battlefield_actions));
					if (item->combat_action.range > 1) {
						add_fold_string(" at range ");
						add_fold_integer(item->combat_action.range);
					}
				}
				break;
			    default:
				if(item->equip_bonus.upkeep) {
					add_fold_string(". Upkeep: $");
					add_fold_integer(item->equip_bonus.upkeep);
				}
				report_stat_bonus(&item->equip_bonus, ". Equipment gives ");
/*
 * Combat item?
 */
				if (item->combat_action.effect) {
					add_fold_string(". This item is used in combat");
					report_combat_values(&item->combat_action);
				}
			}
/*
 * Reported
 */
			add_fold_char('.');
			print_folded(report, 2);
			sep = "";
		}
}
#endif


#ifdef REPORTS_SKILL_KNOWLEDGE
/**
 ** REPORT_NEW_SKILLS_KNOWN
 **/
static void report_new_skills_known(skillknow_s *know)
{
skill_s		*skill;
consume_s	*required;
char		*sep;
int		mode;
/*
 * Loop
 */
	sep = "\nSkill knowledge:\n";
	for (; know; know = know->next) {
#ifdef USES_SKILL_LEVELS
		if (know->at_level <= 0)
			know->at_level = 1;
		while (know->at_level > know->from_level) {
			know->from_level++;
			skill = skill_at_level(know->about, know->from_level);
#else
		if (!know->report) {
			skill = know->about;
#endif
			fprintf(report, "%s\n", sep);
			empty_fold_string();
#ifdef USES_SKILL_LEVELS
			if (!skill) {
#ifdef DYNAMICALLY_DEFINED_GAME
				printf("Undefined level %d for %s\n", know->from_level, know->about->tag.text);
#endif
				add_fold_skill_level(know->about, know->from_level);
				add_fold_string(": Undefined level.");
				print_folded(report, 2);
				sep = "";
				continue;
			}
#endif
			add_fold_skill_level(skill, 1);
			add_fold_string(" skill: ");
			if (skill->describe)
				add_fold_string(skill->describe);
			else {
#ifdef DYNAMICALLY_DEFINED_GAME
				printf("No description for %s", skill->tag.text);
#ifdef USES_SKILL_LEVELS
				printf(" (at level %d)", know->from_level);
#endif
				printf(" found by %s\n", current_faction->id.text);
#endif
				add_fold_string("No description");
			}
			if(skill->flags) {
				int elem = (skill->flags & 0x7) -1;
				int rit = ((skill->flags >> 3) & 0x7)-1;
				char *elems = visual_enum(elem, order_enum_0);
				if(*elems == 'a' || *elems == 'e')
					add_fold_string(". This is an ");
				else
					add_fold_string(". This is a ");
				add_fold_string(elems);
				add_fold_string(" ");
				add_fold_string(visual_enum(rit, order_enum_1));
			}
#ifdef SPECIALIST_SKILLS
			if (skill->specialist)
				add_fold_string(". This skill requires a teacher");
#endif
/*
 * Report how to study
 */
#ifdef USES_SKILL_LEVELS
			if (know->from_level == 1) {
#endif
#ifdef USES_REQUIRED_LEVELS
			if (skill->required_skill) {
				add_fold_string(". Requires ");
				add_fold_skill_level(skill->required_skill, skill->required_at_level);
				add_fold_string(" to study");
			} else
				if (skill->student != 2)
#ifdef USES_SKILL_LEVELS
					if (know->from_level <= 1)
#endif
					add_fold_string(". This is a basic skill");
#endif
#ifdef USES_SKILL_LEVELS
			}
#ifdef SKILL_REQUIRES_BOOK
#ifdef USES_SKILL_LEVELS
			if (know->from_level <= 1)
#endif
				if (skill->required_item) {
					add_fold_string(". Study of the skill requires the possession of ");
					add_fold_item_amount(1, skill->required_item);
				}
#endif
#endif
			if (skill->study_cost) {
				add_fold_string(". Requires ");
				add_fold_integer(skill->for_level/SKILL_POINTS_PER_DAY);
				add_fold_string(" days and $");
				add_fold_integer(skill->study_cost);
				add_fold_string("/day to study");
			} else
				add_fold_string(". This skill cannot be studied");
/*
 * Special handicap
 */
#ifdef SKILLS_REQUIRE_UPKEEP
			if (item->vital.upkeep) {
				add_fold_string(". Additional upkeep: $");
				add_fold_integer(skill->upkeep);
			}
#endif
/*
 * Skill requires a target prior to use
 */
			if (skill->target) {
				add_fold_string(". Use targets ");
				switch (skill->local_target) {
				    case 1:
					add_fold_string(visual_enum(skill->target,
						"\na local unit\nthis location\na local structure\na skill\nan item"));
					break;
				    case 2:
					add_fold_string(visual_enum(skill->target,
						"\na nearby unit\na nearby location\na nearby structure\na skill\nan item"));
					break;
				    default:
					add_fold_string(visual_enum(skill->target,
						"\na unit\na location\na structure\na skill\nan item"));
					break;
				}
			}
/*
 * Producing item
 */
			if ((required = skill->use_consumes) != 0) {
				for (sep = ". Use consumes: "; required; required = required->next)
					if (required->what->item_type <= ITEM_EFFECT) {
						add_fold_string(sep);
						add_fold_item_amount(required->amount,
								required->what);
						sep = comma;
					}
			}
/*
 * Harvesting or producing item
 */
			if (skill->end_product && skill->end_product->name) {
				add_fold_string(". Use produces ");
				if ((mode = skill->multiples) <= 0)
					mode = 1;
				if (skill->tokens_required < skill->multiplier)
					mode *= skill->multiplier;
				add_fold_item_amount(mode, skill->end_product);
				mode = skill->tokens_required;
				if (mode > 0) {
					if (skill->multiplier && skill->multiplier <= mode) {
						mode += skill->multiplier/2;
						mode /= skill->multiplier;
					}
					if (mode <= 1)
						add_fold_string(" per day");
					else {
						add_fold_string(" in ");
						add_fold_integer(mode);
						add_fold_string(" day");
						if (mode > 1)
							add_fold_char('s');
					}
				}
			}
/*
 * Report skill bonus
 */
			report_stat_bonus(&skill->bonus, ". Gives ");
			sep = ". Added capacities: ";
			for (mode = 0; mode < MAX_MOVE_MODES; mode++)
				if (skill->capacity[mode]) {
					add_fold_string(sep);
					add_fold_integer(skill->capacity[mode]);
					add_fold_char('/');
					add_fold_string(visual_enum(mode, movement_modes));
					sep = comma;
				}
/*
 * Combat skills?
 */
			if (skill->combat_action.effect) {
				add_fold_string(". This is a combat action");
				report_combat_values(&skill->combat_action);
			}
#ifdef SKILL_BENEFITS_FROM_TOOL
/*
 * Enhanced skill
 */
			if ((required = skill->enhanced) != 0) {
				for (sep = ". May contribute: "; required; required = required->next) {
					add_fold_string(sep);
					add_fold_item(required->what);
					add_fold_string(" at ");
					add_fold_integer(required->amount);
					add_fold_char('%');
					sep = comma;
				}
			}
#endif
/*
 * Reported
 */
			add_fold_char('.');
			print_folded(report, 2);
			sep = "";
		}
	}
}
#endif


/**
 ** UNIT_ORDER_TEMPLATE
 **	Print an order template for a unit
 **/
static void unit_order_template(unit_s *unit)
{
order_s		*orders;
/*
 * Ensure loyalty
 */
	if (unit->inactive || unit->dead || unit->size == 0)
		return;
	if (unit->now_loyal) {
		if (unit->now_loyal != current_faction)
			return;
	} else
		if (unit->faction != current_faction)
			return;
/*
 * Create unit template
 */
	fprintf(report, "\nUNIT %s\n;     ", unit->id.text);
	unit->full_day = 1;
	start_fold_string(unit->name);
	add_fold_tag(&unit->id);
	if(!unit->is_captive) {
	    add_fold_string(", in ");
	    /* HACK */
	    if(!unit->current) unit->current = unit->true_location;
	    
	    add_fold_string(unit->current->name);
	    if(unit->current->region) {
		add_fold_string(" <");
		add_fold_string(visual_enum(unit->current->region, regions));
		add_fold_char('>');
	    }
	    add_fold_tag(&unit->current->id);
#ifdef REPORT_OVERLAND_COORDINATES
		if(unit->current->type->type == TERRAIN_COUNTRY) {
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(unit->current->x);
		add_fold_char(',');
		add_fold_integer(unit->current->y);
		add_fold_char(')');
	    }
#endif
	    if (unit->leader) {
		add_fold_string(", stacked under ");
		add_fold_string(unit->leader->name);
		add_fold_tag(&unit->leader->id);
	    }
	}
	print_folded(report, 5);
	fprintf(report, "; ");
	empty_fold_string();
#ifdef STEALTH_STATS
	add_fold_unit_visible(unit, 1, 0);
#else
	add_fold_unit_visible(unit, 1);
#endif
/*
 * Any skill?
 */
	if (unit->skilled) {
		report_unit_skills(unit, 1);
	}
	report_unit_capacity(unit);
/*
 * Report battle positions for unit
 */
	report_combat_settings(unit);
/*
 * Done
 */
	report_unit_fields(unit);
	add_fold_char('.');
	print_folded(report, 1);
	if (unit->now_loyal && unit->now_loyal == current_faction && unit->now_loyal != unit->faction)
		return;
	if ((orders = unit->orders) != 0) {
		fprintf(report, "; pending order stack:\n");
		while (orders) {
			write_order_on_file(report, orders);
			orders = orders->next;
		}
	}
}

static char *empire_title(faction_s *f)
{
    if(f->scratchpad[2] > 1) {
	if(f->scratchpad[2] > 25) return "an empire";
	if(f->scratchpad[2] > 15) return "a nation";
	if(f->scratchpad[2] > 9) return "a kingdom";
	if(f->scratchpad[2] > 3) return "a faction";
	return "a tribe";
    }
    return NULL;
}


/**
 ** MAKE_ONE_REPORT
 **	One report is generated for this faction
 **/
static void make_one_report(void)
{
FILE		*battle;
stance_s	*stances;
event_s		*event;
unit_s		*unit;
char		*separator;
faction_s	*others;
#ifdef REPORTS_RANKINGS
int		rank;
int		best;
#endif
char		attitude;
char		flag;
char *emp;
/*
 * Mail headers
 */
	fprintf(report, "Subject: %s report for turn %d\n", game_name, game_turn_number);
	fprintf(report, "From: %s (%s Game server)\n", server_email, game_name);
	fprintf(report, "To: %s\n", current_faction->e_mail);
	fprintf(report, "\n");
/*
 * Standard header
 */
	fprintf(report, "%s turn %d for %s [%s],", game_name, game_turn_number,
	        current_faction->name, current_faction->id.text);
	emp = empire_title(current_faction);
	if(emp) {
		fprintf(report, " %s,", emp);
	}
	fprintf(report, " %s\n", current_faction->e_mail);
#ifdef USES_FACTION_FUND
	fprintf(report, "Faction fund: $%d", current_faction->faction_fund);
	if (current_faction->turn_rewards || current_faction->turn_withdraw)
		fprintf(report, " ($%d reward this turn/$%d withdrawn this turn)\n",
				current_faction->turn_rewards, current_faction->turn_withdraw);
	else
		fprintf(report, " (no change this turn)\n");
#endif
#ifdef USES_FATE_POINTS
	fprintf(report, "Fate points: %d\n", current_faction->fate_points);
#endif
#ifdef USES_CONTROL_POINTS
	fprintf(report, "Control points: %d/%d\n", current_faction->control_current,
						   current_faction->control_max);
#endif
	if (sword_victory || mage_victory || craft_victory) {
		fprintf(report, "Orders deadline: The game has ended.");
	} else if (deadline[0]) {
		fprintf(report, "Orders deadline: %s\n", deadline);
	}
	putc('\n', report);
/*
 * Ranking reports
 */
#ifdef REPORTS_RANKINGS
	fprintf(report, "Rankings:\n");
/*
 * Rank by size in figures
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_size > current_faction->faction_size) {
				rank++;
				if (others->faction_size > best)
					best = others->faction_size;
			}
	start_fold_string("      By faction size: ");
	add_fold_nth_integer(rank);
	add_fold_char(' ');
	add_fold_char('(');
	add_fold_integer(current_faction->faction_size);
	if (rank > 1) {
		add_fold_char('/');
		add_fold_integer(best);
	}
	add_fold_string(" figures)");
	print_folded(report, 23);
/*
 * Rank by skill days
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_skill > current_faction->faction_skill) {
				rank++;
				if (others->faction_skill > best)
					best = others->faction_skill;
			}
	start_fold_string("     By faction skill: ");
	if (current_faction->faction_skill <= 1)
		add_fold_string("meaningless");
	else {
		add_fold_nth_integer(rank);
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(current_faction->faction_skill);
		if (rank > 1) {
			add_fold_char('/');
			add_fold_integer(best);
		}
		add_fold_string(" days)");
	}
	print_folded(report, 23);
/*
 * Rank by military power
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_strength > current_faction->faction_strength) {
				rank++;
				if (others->faction_strength > best)
					best = others->faction_strength;
			}
	start_fold_string("  By faction strength: ");
	if (!current_faction->faction_strength)
		add_fold_string("meaningless");
	else {
		add_fold_nth_integer(rank);
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(current_faction->faction_strength);
		if (rank > 1) {
			add_fold_char('/');
			add_fold_integer(best);
		}
		add_fold_string(" strength)");
	}
	print_folded(report, 23);
#ifdef USES_MANA_POINTS
/*
 * Rank by magic power
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_mana > current_faction->faction_mana) {
				rank++;
				if (others->faction_mana > best)
					best = others->faction_mana;
			}
	start_fold_string("    By faction magics: ");
	if (!current_faction->faction_mana)
		add_fold_string("meaningless");
	else {
		add_fold_nth_integer(rank);
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(current_faction->faction_mana);
		if (rank > 1) {
			add_fold_char('/');
			add_fold_integer(best);
		}
		add_fold_string(" mana)");
	}
	print_folded(report, 23);
/*
 * Rank by mage level
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->mage_mana > current_faction->mage_mana) {
				rank++;
				if (others->mage_mana > best)
					best = others->mage_mana;
			}
	start_fold_string("      By faction mage: ");
	if (current_faction->mage_mana <= 2)
		add_fold_string("meaningless");
	else {
		add_fold_nth_integer(rank);
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_integer(current_faction->mage_mana);
		if (rank > 1) {
			add_fold_char('/');
			add_fold_integer(best);
		}
		add_fold_string(" mana)");
	}
	print_folded(report, 23);
#endif
#ifdef USES_TITLE_SYSTEM
/*
 * Rank by title values
 */
	rank = 1;
	best = 0;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_titles > current_faction->faction_titles) {
				rank++;
				if (others->faction_titles > best)
					best = others->faction_titles;
			}
	start_fold_string("    By faction titles: ");
	if (!current_faction->faction_titles)
		add_fold_string("meaningless");
	else {
		add_fold_nth_integer(rank);
		add_fold_char(' ');
		add_fold_char('(');
		add_fold_char('$');
		add_fold_integer(current_faction->faction_titles);
		if (rank > 1) {
			add_fold_char('/');
			add_fold_integer(best);
		}
		add_fold_char(')');
	}
	print_folded(report, 23);
#endif
/*
 * Rank by wealth
 */
	rank = 1;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_wealth > current_faction->faction_wealth) {
				rank++;
				if (others->faction_wealth > best)
					best = others->faction_wealth;
			}
	start_fold_string("    By faction wealth: ");
	add_fold_nth_integer(rank);
	add_fold_char(' ');
	add_fold_char('(');
	add_fold_integer(current_faction->faction_wealth);
	if (rank > 1) {
		add_fold_char('/');
		add_fold_integer(best);
	}
	add_fold_string("$)");
	print_folded(report, 23);
/*
 * Rank by worth in $
 */
	rank = 1;
	for (others = faction_list; others; others = others->next)
		if (others->id.text[0] != 'n' || others->id.text[1] != 'p' || others->id.text[2] != 'c')
			if (others->faction_worth > current_faction->faction_worth) {
				rank++;
				if (others->faction_worth > best)
					best = others->faction_worth;
			}
	start_fold_string("     By faction worth: ");
	add_fold_nth_integer(rank);
	add_fold_char(' ');
	add_fold_char('(');
	add_fold_integer(current_faction->faction_worth);
	if (rank > 1) {
		add_fold_char('/');
		add_fold_integer(best);
	}
	add_fold_string("$)");
	print_folded(report, 23);
#endif
	putc('\n', report);
/*
 * Diplomacy reports
 */
	fprintf(report, "Attitude is %s", visual_enum(current_faction->attitude,
				"Ally\nFriendly\nNeutral\nHostile\nEnemy"));
	if (current_faction->anon_attitude >= 0)
		fprintf(report, ", %s toward unknowns", visual_enum(current_faction->anon_attitude,
				"Ally\nFriendly\nNeutral\nHostile\nEnemy"));
	putc('\n', report);
	for (attitude = 0; attitude < 5; attitude++) {
		start_fold_string(visual_enum(attitude,
				"Allies\nFriends\nNeutral\nHostility\nEnemies"));
		separator = ": ";
		flag = 0;
		for (stances = current_faction->stances; stances;
				stances = stances->next)
			if (stances->attitude == attitude) {
				if(stances->unit) {
					if(stances->unit->faction->resigned) continue;
					if(stances->unit->faction == current_faction->vassal_of)
						continue;
				} else {
					if(stances->faction->resigned) continue;
					if(stances->faction == current_faction->vassal_of)
						continue;
				}
			    add_fold_string(separator);
			    if (stances->unit) {
					add_fold_string(stances->unit->name);
					add_fold_tag(&stances->unit->id);
			    } else {
					add_fold_string(stances->faction->name);
					add_fold_tag(&stances->faction->id);
			    }
			    separator = comma;
			    flag = 1;
			}
		if (flag)
			print_folded(report, 2);
	}
/*
 * Report oaths
 */
#ifdef OATH_TOWARD_FACTIONS
	if (current_faction->vassal_of) {
		fprintf(report, "Oathed to: %s [%s]%s\n",
			current_faction->vassal_of->name,
			current_faction->vassal_of->id.text,
			(current_faction->vassal_of->resigned ?
			 " (resigned)" : ""));
	}
	separator = "Loyals: ";
	start_fold_string("");
	for (others = faction_list; others; others = others->next) {
		if(others->resigned) continue;
		if (others->vassal_of == current_faction) {
			add_fold_string(separator);
			add_fold_string(others->name);
			add_fold_tag(&others->id);
			separator = comma;
		}
	}
	if (*separator == ',')
		print_folded(report, 8);
#endif
	putc('\n', report);
/*
 * Global events
 */
	separator = "Faction-wide events:\n";
	for (event = current_faction->globals; event; event = event->next) {
		if (event->day < 0) continue;
		fprintf(report, separator);
		if (event->day > 0)
			fprintf(report, "%d - ", event->day);
		start_fold_string(event->text);
		print_folded(report, event->day > 9 ? 5 : 4);
		separator = "";
	}
	if(current_faction->resigned) {
		if(current_faction->resigned == 1) {
			if(*separator) fprintf(report, separator);
			fprintf(report,
				"Faction resigned due to resign order.\n");
			separator = "";
		} else {
			if(*separator) fprintf(report, separator);
			fprintf(report,
				"Faction resigned due to no units.\n");
			separator = "";
		}
	}
	if (!*separator)
		putc('\n', report);
	putc('\n', report);
/*
 * If announcement, insert here
 */
	if (announce)
		fprintf(report, "%s\n", announce);
/*
 * List all units
 */
	fprintf(report, "Units:\n\n");
	for (unit = unit_list; unit; unit = unit->next)
		unit->full_day = 0;
	for (unit = current_faction->units; unit; unit = unit->same_faction)
		report_on_units(unit);
	for (unit = unit_list; unit; unit = unit->next)
		if (!unit->full_day)
			report_on_units(unit);
/*
 * List all visited locations
 */
	report_all_locations();
/*
 * Battle reports are archived separately
 */
	for (event = current_faction->globals; event; event = event->next)
		if (event->day < 0) {
			if ((battle = fopen(event->text, "r")) == 0) {
				perror(event->text);
			} else {
				while (file_gets(battle))
					fprintf(report, "%s\n", work);
				fclose(battle);
			}
		}
/*
 * Report on knowledge
 */
#ifdef REPORTS_ITEM_KNOWLEDGE
	report_new_item_known(current_faction->known_items);
#endif
#ifdef REPORTS_RACIAL_KNOWLEDGE
	report_new_races_known(current_faction->known_races);
#endif
#ifdef REPORTS_SKILL_KNOWLEDGE
	report_new_skills_known(current_faction->known_skills);
#endif
/*
 * Generate an order template only if the faction is still alive
 */
	if(current_faction->resigned)
		return;
	fprintf(report, "\n\n#GAME %s %s\n", current_faction->id.text, current_faction->password);
	header_character = ';';
	for (unit = unit_list; unit; unit = unit->next)
		unit->full_day = 0;
	for (unit = current_faction->units; unit; unit = unit->same_faction)
		unit_order_template(unit);
	for (unit = unit_list; unit; unit = unit->next)
		if (!unit->full_day)
			unit_order_template(unit);
	fprintf(report, "\n#END\n");
}


#ifndef IN_HTML
#ifdef REPORTS_RANKINGS
/**
 ** SUMS_RANK
 **	Compute the ranking summary
 **/
static void sums_rank(void)
{
unit_s		*unit;
experience_s	*exp;
carry_s		*items;
faction_s	*faction;
int		size;
/*
 * Start at zero
 */
/*
 * Loop on all units
 */
	for (unit = unit_list; unit; unit = unit->next) {
		size = unit->size;
		if (!size)
			continue;
		faction = unit->faction;
		faction->faction_size  += size;
		faction->faction_worth += size * unit->race->base_cost;
		if (unit->vital.melee > unit->vital.missile) {
			if (unit->vital.melee > 0)
				faction->faction_strength += size * unit->vital.melee;
		} else {
			if (unit->vital.missile > 0)
				faction->faction_strength += size * unit->vital.missile;
		}
		for (exp = unit->skilled; exp; exp = exp->next)
			faction->faction_skill += exp->points / SKILL_POINTS_PER_DAY;
		for (items = unit->carrying; items; items = items->next)
			if (items->item == item_cash)
				faction->faction_wealth += items->amount;
			else
				faction->faction_worth += items->amount * items->item->suggested_price;
#ifdef USES_MANA_POINTS
		faction->faction_mana += unit->vital.mana;
		if (unit->vital.mana > faction->mage_mana)
			faction->mage_mana = unit->vital.mana;
#endif
#ifdef USES_TITLE_SYSTEM
		if (unit->title)
			faction->faction_titles += unit->title->title->cost;
#endif
	}
}
#endif


/**
 ** CREATE_REPORTS
 **	Create a set of reports
 **/
void create_reports(void)
{
char	*name;
/*
 * End of turn occurs now
 */
	observe_locations(31);
#ifdef REPORTS_RANKINGS
	for (current_faction = faction_list; current_faction; current_faction = current_faction->next) {
		current_faction->faction_size = 0;
		current_faction->faction_strength = 0;
#ifdef USES_FACTION_FUND
		current_faction->faction_wealth = current_faction->faction_fund;
#else
		current_faction->faction_wealth = 0;
#endif
		current_faction->faction_worth = 0;
#ifdef USES_MANA_POINTS
		current_faction->faction_mana = 0;
		current_faction->mage_mana = 0;
#endif
#ifdef USES_TITLE_SYSTEM
		current_faction->faction_titles = 0;
#endif
	}
	sums_rank();
	for (current_faction = faction_list; current_faction; current_faction = current_faction->next)
		if (current_faction->faction_size)
			current_faction->faction_skill /= current_faction->faction_size;
#endif
/*
 * Game-wide announce
 */
	report = fopen("announce.info", "r");
	if (report) {
		work[fread(work, 1, sizeof(work), report)] = 0;
		announce = strdup(work);
		fclose(report);
	} else
		announce = 0;
/*
 * Loop on all factions
 */
	for (current_faction = faction_list; current_faction; current_faction = current_faction->next)
		if (current_faction->e_mail && !current_faction->npc) {
			name = player_specific_file(current_faction, "newrep");
			if ((report = fopen(name, "w")) == 0) {
				perror(name);
				continue;
			}
			header_character = 0;
			make_one_report();
			fclose(report);
#ifdef REPORTS_HTML
/**
 ** HTML generated report
 **/
			strcat(name, ".html");
			if ((report = fopen(name, "w")) == 0) {
				perror(name);
				continue;
			}
			make_one_html_report();
			fclose(report);
#endif
		}
}
#endif
#endif
