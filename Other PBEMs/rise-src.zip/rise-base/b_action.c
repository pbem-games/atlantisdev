/* $Id: b_action.c,v 1.41 2001/02/11 22:21:43 jtraub Exp $b
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "fx.h"

/**
 ** Local scratchpad
 **/
#ifdef FX_SHIELDBREAKER
static char	shieldbreak = 0;
#endif

void add_target_hit(actor_s *killer, figure_s *target_fig, actor_s *target,
		    int hits, int damage, int killed, int captured)
{
	treport_s *temp;
	treport_s *last = NULL;
	for(temp = killer->attacks; temp; temp=temp->next) {
		if(temp->target == target) {
			temp->hits += hits;
			temp->damage += damage;
			temp->killed += killed;
			temp->captured += captured;
			return;
		}
		last = temp;
	}
	temp = mallocator(treport_s);
	temp->hits = hits;
	temp->damage = damage;
	temp->killed = killed;
	temp->captured = captured;
	temp->target = target;
	temp->figure = target_fig;
	temp->next = NULL;
	if(last) {
		last->next = temp;
	} else {
		killer->attacks = temp;
	}
}

void free_target_hits(treport_s *hits) {
	if(hits) {
		free_target_hits(hits->next);
		free(hits);
	}
}

/**
 ** UNIT_HAS_ACTED
 **	Unit no longer has any opportunity to act. Remove from active list
 **/
void unit_has_acted(figure_s *unit)
{
	if (unit->prev_initiative)
		unit->prev_initiative->next_initiative = unit->next_initiative;
	else
		if (acting_units == unit)
			acting_units = unit->next_initiative;
	if (unit->next_initiative)
		unit->next_initiative->prev_initiative = unit->prev_initiative;
	unit->has_acted = 1;
	unit->has_moved = 1;
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d; %s [%s] has acted\n", round_number,
                       unit->unit->name, unit->unit->id.text);
#endif
	unit->prev_initiative = 0;
	unit->next_initiative = 0;
}


#ifdef BATTLE_INITIATIVE
/**
 ** BATTLE_DELAY_PROCESSING
 **	Unit loses initiative
 **/
void battle_delay_processing(figure_s *unit)
{
figure_s	*prev, *next;
int		new_ini;
/*
 * Shift unit downward only if it has less initiated units
 */
	new_ini = unit->current_init;
	next = unit->next_initiative;
	if (next && next->current_init > new_ini) {
/*
 * Unlink from the current position
 */
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d: %s [%s] shifted down to initiative %d\n",
		       round_number, unit->unit->name, unit->unit->id.text, new_ini);
#endif
		prev = unit->prev_initiative;
		next->prev_initiative = prev;
		if (prev == 0) {
			if (acting_units == unit)
				acting_units = next;
		} else
			prev->next_initiative = next;
/*
 * Now, search for the appropriate inititative slot
 */
		for (; next; next = next->next_initiative)
			if (next->current_init > new_ini)
				prev = next;
			else
				break;
/*
 * Insert at this position. Prev is always non zero, the previous loop being
 * always executed at least once, due to the entry condition.
 */
		unit->next_initiative = next;
		unit->prev_initiative = prev;
		prev->next_initiative = unit;
		if (next)
			next->prev_initiative = unit;
	}
}
#endif


/**
 ** TARGET_ADD
 **	Add one or more targets from the battlefield list of allies or enemies
 **/
static void target_add(figure_s *unit, figure_s *list, int kind, int fx, int range)
{
int		skip;
/*
 * Insert all from list!
 */
	while (list) {
		if (list->living > 0) {
/*
 * Check validity of target
 */
			skip = 0;
			switch (kind) {
			    case BATTLEFIELD_TARGET_SELF:
				if (list != unit) {
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d: %s [%s] skipped %s [%s] as a target (not self).\n",
		       round_number, unit->unit->name, unit->unit->id.text, list->unit->name,
                       list->unit->id.text);
#endif
					skip = 1;
				}
				break;
			    case BATTLEFIELD_TARGET_LEADER:
			    case BATTLEFIELD_TARGET_TARGET:
				if (list->race->type != RACE_LEADER) {
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d: %s [%s] skipped %s [%s] as a target (not leader).\n",
		       round_number, unit->unit->name, unit->unit->id.text, list->unit->name,
                       list->unit->id.text);
#endif
					skip = 1;
				}
				break;
			}
			if (!skip && (!fx || !battle_fx_target_check(list, fx)) ) {
/*
 * Target is valid, insert in range list
 */
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d; %s [%s] added %s [%s] as a target.\n",
		       round_number, unit->unit->name, unit->unit->id.text, list->unit->name,
                       list->unit->id.text);
#endif
				list->was_struck = 0;
				list->was_wounded = 0;
				list->was_hit = 0;
				list->has_lost = 0;
				list->next_target = unit->target;
				unit->target = list;
				list->range = range;
			}
		}
		list = list->same_square;
	}
}


/**
 ** ADD_TARGETS
 **	Any target in that specific square?
 **/
static void add_targets(figure_s *unit, int rank, int file, int kind, int fx, int range)
{
square_s	*here;
figure_s	*list, *list2;
/*
 * Do we fall in field?
 */
	if (rank < 0 || rank > 5 || file < 0 || file > 2)
		return;
	here = &battlefield[rank][file];
	if (unit->offense) {
		list = here->defenders;
		list2 = here->attackers;
	} else {
		list = here->attackers;
		list2 = here->defenders;
	}
	switch (kind) {
	    case BATTLEFIELD_TARGET_ALL:
		target_add(unit, list, kind, fx, range);
	    case BATTLEFIELD_TARGET_FRIENDLY:
	    case BATTLEFIELD_TARGET_LEADER:
	    case BATTLEFIELD_TARGET_SELF:
		target_add(unit, list2, kind, fx, range);
		break;
	    default:
		target_add(unit, list, kind, fx, range);
#ifdef FX_BATTLE_CONFUSED
		if (unit->friend_or_foe)
			target_add(unit, list2, kind, fx, range);
#endif
		break;
	}
}


/**
 ** RANDOM_ACTING
 **	Shuffle the list of autonomous actors
 **/
static actor_s *random_acting(actor_s *actor)
{
actor_s	*next;
/*
 * Simple targetting
 */
	if (!actor)
		return 0;
	next = random_acting(actor->next);
	if (!next)
		return actor;
	if (roll_1Dx(2) == 0) {
		actor->next = next;
		return actor;
	}
	actor->next = next->next;
	next->next = actor;
	return next;
}


/**
 ** RANDOM_TARGETING
 **	Shuffle the list of targets
 **/
static figure_s *random_targeting(figure_s *target, figure_s *main)
{
figure_s	*next;
/*
 * Simple targetting
 */
	if (!target)
		return 0;
	target->autonomous = random_acting(target->autonomous);
	next = random_targeting(target->next_target, main);
	if (!next)
		return target;
	if (target == main || (next != main && roll_1Dx(2) == 0)) {
		target->next_target = next;
		return target;
	}
	target->next_target = next->next_target;
	next->next_target = target;
	return next;
}


#ifdef STEALTH_STATS
/**
 ** SORT_BY_STEALTH
 **	Lower stealth first
 **/
static figure_s *sort_by_stealth(figure_s *target, int limit)
{
figure_s	*next;
/*
 * Simple targetting
 */
	if (!target)
		return 0;
	next = sort_by_stealth(target->next_target, limit);
	if (!next)
		return target;
/*
 * Modified stealth?
 */
	if (next->modified.stealth >= target->modified.stealth || next->modified.stealth <= limit) {
		target->next_target = next;
		return target;
	}
	target->next_target = next->next_target;
	next->next_target = target;
	return sort_by_stealth(next, limit);
}
#endif


/**
 ** TARGET_IN_RANGE
 **	Lists all the potential targets, randomised
 **/
static void target_in_range(figure_s *unit, int range, int kind, int fx)
{
/*
 * Link all potential targets
 */
	unit->target = 0;
	switch (range) {
	    default:
		printf("*** Impossible range %d\n", range);
	    case 7:
		add_targets(unit, unit->rank-5, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-5, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file+2, kind, fx, 1);
	    case 6:
		add_targets(unit, unit->rank-5, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-5, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file+1, kind, fx, 1);
	    case 5:
		add_targets(unit, unit->rank-5, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file, kind, fx, 1);
	    case 4:
		add_targets(unit, unit->rank-4, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file, kind, fx, 1);
	    case 3:
		add_targets(unit, unit->rank-3, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file, kind, fx, 1);
	    case 2:
		add_targets(unit, unit->rank-2, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file, kind, fx, 1);
	    case 1:
		add_targets(unit, unit->rank-1, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file, kind, fx, 1);
	    case 0:
		add_targets(unit, unit->rank, unit->file, kind, fx, 0);
	}
/*
 * Shuffle the target list around
 */
	unit->target = random_targeting(unit->target, unit->last_target);
#ifdef STEALTH_STATS
	unit->target = sort_by_stealth(unit->target, unit->modified.observation);
#endif
}


/**
 ** UNIT_PICK_TARGET
 **	Unit selects the appropriate target, according to its settings
 **/
void unit_pick_target(figure_s *unit)
{
figure_s	*potential_target;
actor_s		*actors;
int		target;
int		factor, weight;
/*
 * Unit has a target assignment
 */
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("Round %d: %s [%s] getting ready to pick a target.\n",
		       round_number, unit->unit->name, unit->unit->id.text);
#endif
	target = unit->movement;
/*
 * The TARGET is special
 */
	if (target == BATTLEFIELD_MOVE_TARGET) {
		if (unit->offense) {
			if (defenders.initiator->living && !defenders.initiator->fled && !defenders.initiator->prisoner) {
				unit->last_target = defenders.initiator;
				return;
			} else
				target = BATTLEFIELD_MOVE_NEAREST;
		} else {
			if (attackers.initiator->living && !attackers.initiator->fled && !attackers.initiator->prisoner) {
				unit->last_target = attackers.initiator;
				return;
			} else
				target = BATTLEFIELD_MOVE_NEAREST;
		}
	}
/*
 * Pick target
 */
	factor = 0;
	if (unit->offense)
		potential_target = defenders.units;
	else
		potential_target = attackers.units;
	switch (target) {
	    case BATTLEFIELD_MOVE_RANDOM:
		for (; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			factor++;
			if (factor == 1 || roll_1Dx(factor) == 1)
				unit->last_target = potential_target;
		}
		break;
	    default:
		printf("WARNING! Unknown target type %d for %s\n", target, unit->unit->id.text);
	    case BATTLEFIELD_MOVE_FLEE:
	    case BATTLEFIELD_MOVE_TARGET:
	    case BATTLEFIELD_MOVE_NEAREST:
		for (target = 8; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			if (potential_target->rank < unit->rank)
				weight = unit->rank - potential_target->rank;
			else
				weight = potential_target->rank - unit->rank;
			if (potential_target->file < unit->file)
				weight += unit->file - potential_target->file;
			else
				weight -= potential_target->file - unit->file;
			if (weight < target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want high offense
 */
	    case BATTLEFIELD_MOVE_STRONGEST:
		for (target = 0; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			if (potential_target->global.melee > potential_target->global.missile)
				weight = potential_target->global.melee;
			else
				weight = potential_target->global.missile;
			if (weight > target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want low offense
 */
	    case BATTLEFIELD_MOVE_WEAKEST:
		for (target = 0x7fffffff; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = 1;
			if (potential_target->global.melee > potential_target->global.missile)
				weight = potential_target->global.melee;
			else
				weight = potential_target->global.missile;
			if (weight < target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want high defense
 */
	    case BATTLEFIELD_MOVE_DEFENDED:
		for (target = 0; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = potential_target->global.defense;
			if (weight > target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want low defense
 */
	    case BATTLEFIELD_MOVE_VULNERABLE:
		for (target = 0x7fffffff; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = potential_target->global.defense;
			if (weight < target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want many actors
 */
	    case BATTLEFIELD_MOVE_BIGGEST:
		for (target = 0; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = potential_target->active;
			if (weight > target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want few actors
 */
	    case BATTLEFIELD_MOVE_SMALLEST:
		for (target = 99999; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = potential_target->active;
			if (weight < target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want many actor types
 */
	    case BATTLEFIELD_MOVE_VARIED:
		for (target = 0; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = 0;
			for (actors = potential_target->autonomous; actors; actors = actors->next)
				if (actors->amount)
					weight++;
			if (weight > target) {
				unit->last_target = potential_target;
				target = weight;
				factor = 1;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
/*
 * Want few actor types
 */
	    case BATTLEFIELD_MOVE_HOMOGENOUS:
		for (target = 9999; potential_target; potential_target = potential_target->same_side) {
			if (!potential_target->living || potential_target->fled || potential_target->prisoner)
				continue;
			weight = 0;
			for (actors = potential_target->autonomous; actors; actors = actors->next)
				if (actors->amount)
					weight++;
			if (weight < target) {
				unit->last_target = potential_target;
				factor = 1;
				target = weight;
			} else
				if (weight == target) {
					factor++;
					if (factor == 1 || roll_1Dx(factor) == 1)
						unit->last_target = potential_target;
				}
		}
		break;
	}
}


/**
 ** MELEE_STRIKES
 **	Strike against targets!
 **/
static void melee_strikes(figure_s *unit, int hitting, int fx)
{
figure_s	*target;
actor_s		*striking;
actor_s		*ranks;
char		*separator;
int		defense;
int		strikes, hits, wounds, captures;
int		i;
int		value, deadly;
int		looped, struck;
int		roll;
int		range;
int		tot_hits = 0, tot_kills = 0, tot_capts = 0;
actor_s		*actor;
int		man, j;

/*
 * We strikes how many times?
 */
	target = unit->target;
	looped = 0;
	struck = 0;
	while (hitting) {
/*
 * Strike once against target. Strike against all autonomous actors
 * and randomly against the leader, if any
 */
		if (target->rank > unit->rank)
			range = target->rank - unit->rank;
		else
			range = unit->rank - target->rank;
		if (target->file > unit->file)
			range += target->file - unit->file;
		else
			range += unit->file - target->file;
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("Round %d: %s [%s] strikes at range %d\n", round_number, unit->unit->name,
			       unit->unit->id.text, range);
#endif
		ranks = target->autonomous;
/*
 * Go strike!
 */
		for (striking = unit->autonomous; striking; striking = striking->next) {
			int missval;

			/* Hack for trebuchet */
			if(striking->trebuch) {
				int amt = unit->men/3;
				if(striking->amount > amt) {
					striking->amount = amt;
					striking->acted = amt;
				}
			}

			if (!striking->acted) {
				continue;
			}
			if (range > striking->acts.range) {
				continue;
			}
			value = striking->modified.melee;

			missval = striking->modified.missile;
			if(unit->fortress) {
				if(striking->original || striking->summoned) {
					missval ++;
				} else {
					missval += (missval/20);
				}
			}


			if (missval > value) {
				value = missval;
			}
			if (value == 0) {
				continue;
			}
			strikes = striking->acted;
			if (strikes > hitting)
				strikes = hitting;
			while (ranks && !target->prisoner) {
				if(ranks->trebuch) {
					ranks = ranks->next;
					continue;
				}

				if ((wounds = ranks->amount) > 0) {
/*
 * We may shoot that actor
 */
					defense = ranks->modified.defense;
					if(target->fortress) {
						if(ranks->original || ranks->summoned) {
							defense += 2;
						} else {
							/* leader */
							defense += (defense/10);
						}
					}
					if(target->tower) {
						if(ranks->original || ranks->summoned) {
							defense += target->tower;
						} else {
							/* leader */
							defense += (defense/(20/target->tower));
						}
					}
					defense += battlefield[(int)target->rank][(int)target->file].round_modifiers.defense;
					defense += battlefield[(int)target->rank][(int)target->file].battle_modifiers.defense;
					if (wounds > strikes)
						wounds = strikes;
					strikes -= wounds;
					hitting -= wounds;
/*
 * How many wounds hit?
 */
					hits = 0;
					captures = 0;
					for (i = 0; i < wounds; i++) {
						roll = roll_1Dx(value+defense);
						if (roll >= defense)
							hits++;
					}
					struck += hits;
					target->was_struck += hits;
					looped = 1;
#ifdef FX_HAUNTED_BLADE
/*
 * Check for special effect of haunted blade
 */
					if(hits && !striking->original && !ranks->original &&
							!striking->summoned && !ranks->summoned &&
							unit->unit->race->type == RACE_LEADER &&
							target->unit->race->type == RACE_LEADER &&
							fx_equipped_on_unit(unit->unit, FX_HAUNTED_BLADE)) {
						/* 30 % chance of permanent wound */
						if(roll_1Dx(100) < 30) {
							printf("%s (%s) of [%s] is taking a permanent wound!",
									unit->unit->name, unit->unit->id.text,
									unit->unit->faction->id.text);
						}
					}
#endif

#ifdef PRISONERS_TAKEN
/*
 * Check for capture of a leader
 */
					if(hits && !ranks->actor) {
						if((captures = does_capture(unit, target))) {
							hits = 0;
							target->has_lost += captures;
						}
					}
#endif
/*
 * How many hits killed?
 */
					deadly = 0;
					i = hits;
/*
 * We have a proportion of chances of slaying N people
 */
					/* Pick a person to slay */
					while(i-- && ranks->amount) {
						man = roll_1Dx(ranks->amount);
						ranks->damage[man] -= striking->modified.damage;
						if(ranks->damage[man] <= 0) {
							ranks->damage[man] = 0;
							deadly++;
							for(j = man; j < ranks->amount-1; j++)
								ranks->damage[j] = ranks->damage[j+1];
							ranks->amount--;
						}
					}
/*
 * How many did we slay?
 */
					hits -= deadly;
					ranks->acted -= deadly;
					ranks->living -= deadly;
					if(ranks->living <= 0) {
						ranks->living = 0;
						ranks->life = 0;
					}
/*
 * Immediately thin out the actors
 */
					if (deadly) {
						if (ranks->original) {
							ranks->original->amount = ranks->amount;
							if(!ranks->amount) {
								target->living--;
							}
							if(ranks->original->item->item_type == ITEM_FOLLOWER) {
								target->men -= deadly;	
							} else {
								target->beasts -= deadly;	
							}
						} else {
							target->living--;
							target->men--;	
						}
					}
					target->has_lost += deadly;
					target->was_hit  += hits;
					if(hits || deadly || captures) {
						add_target_hit(striking, target,
							       ranks, hits,
							       (hits+deadly)*striking->modified.damage,
							       deadly,
							       captures);
					}
				}
/*
 * Fire on next set of actors, if any
 */
				ranks = ranks->next;
				if (!strikes)
					break;
			}
/*
 * Memorise how many strikes remain.
 */
			striking->acted = strikes;
			if (!ranks)
				break;
		}
/*
 * We have exhausted actors on this target, move on to the next
 */
		if ((target = target->next_target) == 0) {
			if (!looped)
				break;
			looped = 0;
			target = unit->target;
		}
	}
/*
 * Now, report on what happened
 */
	for(actor = unit->autonomous; actor; actor = actor->next) {
		treport_s *targ;
		if(!actor->amount) continue;
		if(!actor->attacks) {
			if(actor->modified.melee || actor->modified.missile) {
				start_fold_unit_segment(unit);
				if(actor->actor) {
					add_fold_char('(');
					add_fold_item_amount(actor->amount,
							     actor->actor);
					add_fold_char(')');
					add_fold_char(' ');
				}
				add_fold_string("missed completely.");
				print_folded(full_report, 5);
			}
		}
		for(targ = actor->attacks; targ; targ = targ->next) {
			tot_hits += targ->hits;
			tot_hits += targ->killed;
			tot_kills += targ->killed;
			tot_capts += targ->captured;
			start_fold_unit_segment(unit);
			if(actor->actor) {
				add_fold_char('(');
				add_fold_item_amount(actor->amount,
						     actor->actor);
				add_fold_char(')');
				add_fold_char(' ');
			}
			if(targ->captured) {
				add_fold_string("captured ");
				add_fold_string(targ->figure->unit->name);
				if(targ->figure->simplename)
					add_fold_tag(&targ->figure->unit->id);
				add_fold_char('.');
			} else if(targ->hits || targ->killed) {
				int count = targ->hits + targ->killed;
				if(count == 1) {
					add_fold_string("hit once");
				} else {
					add_fold_string("hit ");
					add_fold_integer(count);
					add_fold_string(" times");
				}
				add_fold_string(" against ");
				add_fold_string(targ->figure->unit->name);
				if(targ->figure->simplename)
					add_fold_tag(&targ->figure->unit->id);
				add_fold_char(' ');
				if(targ->target->actor) {
					add_fold_char('(');
					add_fold_item_amount(targ->target->amount + targ->killed,
						     targ->target->actor);
					add_fold_char(')');
				}
				separator = "";
				if(targ->damage) {
					separator = " and ";
					add_fold_string("doing ");
					add_fold_integer(targ->damage);
					add_fold_string(" points of damage");
				}
				if(targ->killed) {
					add_fold_string(separator);
					add_fold_string("killing ");
					add_fold_integer(targ->killed);
				}
				add_fold_char('.');
			} else {
				add_fold_string("missed.");
			}
			print_folded(full_report, 5);
		}
		free_target_hits(actor->attacks);
		actor->attacks = NULL;
	}
	start_fold_unit_segment(unit);
	if(!tot_hits && !tot_capts) {
		add_fold_string("missed completely.");
	} else {
		if(tot_hits == 1) {
			add_fold_string("hit once");
		} else {
			if(tot_hits == 0 && tot_capts != 0) {
				add_fold_string("hit once");
			} else {
				add_fold_string("hit ");
				add_fold_integer(tot_hits);
				add_fold_string(" times");
			}
		}
		add_fold_string(" killing ");
		add_fold_integer(tot_kills);
		add_fold_char('.');
	}
	print_folded(long_report, 5);
	if(tot_capts) {
		start_fold_unit_segment(unit);
		add_fold_string("captured ");
		add_fold_string(unit->captive->unit->name);
		if(unit->captive->simplename)
			add_fold_tag(&unit->captive->unit->id);
		add_fold_char('.');
		print_folded(long_report, 5);
	}

	if(struck) {
		observation_round = 0;
		for (target = unit->target;target;target = target->next_target)
			if(target->was_struck) {
				if(target->prisoner) {
					/*target->side->casualties++;*/
					/* announce the capture */
					start_fold_unit_segment(unit);
					add_fold_string("captured ");
					add_fold_string(target->unit->name);
					if(target->simplename)
						add_fold_tag(&target->unit->id);
					add_fold_char('.');
					print_folded(terse_report, 5);
				}
				target->fleeing = 0;
				target->fled = 0;
				if(fx)
					battle_fx_strike(target, fx);
				if (target->has_lost) {
					target->side->casualties += target->has_lost;
					target->side->turn_casualties += target->has_lost;
					if (!target->fanatic)
						target->side->rout -= target->has_lost;
					if (target->living <= 0) {
						target->fleeing = 0;
						unit_away(target);
					} 
				}
			}
	}
}


/**
 ** ADJUST_VITALS
 **	Adjust the actor's vital stats, according to bonuses and settings
 **/
void adjust_vitals(actor_s *unit, combat_s *does)
{
/*
 * Set or modifies?
 */
	if(unit->vitals.melee || unit->vitals.missile) {
		if (does->action.melee)
			unit->modified.melee = does->action.melee;
		else
			unit->modified.melee += does->bonus.melee;
		if (does->action.missile)
			unit->modified.missile = does->action.missile;
		else
			unit->modified.missile += does->bonus.missile;
	}
	if (does->action.defense)
		unit->modified.defense = does->action.defense;
	else
		unit->modified.defense += does->bonus.defense;
	if (does->action.life)
		unit->modified.life = does->action.life;
	else
		unit->modified.life += does->bonus.life;
	if (does->action.hits)
		unit->modified.hits = does->action.hits;
	else
		unit->modified.hits += does->bonus.hits;

	/* fix up the acted */
	unit->acted = unit->amount;
	if(unit->modified.hits) unit->acted *= unit->modified.hits;

	if(does->range > unit->acts.range) unit->acts.range = does->range;

	if (does->action.damage)
		unit->modified.damage = does->action.damage;
	else
		unit->modified.damage += does->bonus.damage;
#ifdef STEALTH_STATS
	if (does->action.stealth)
		unit->modified.stealth = does->action.stealth;
	else
		unit->modified.stealth += does->bonus.stealth;
	if (does->action.observation)
		unit->modified.observation = does->action.observation;
	else
		unit->modified.observation += does->bonus.observation;
#endif
}


/**
 ** COMBAT_SPECIAL
 **	A skill or combat item is being used!
 **/
static int combat_special(figure_s *unit, int amount, combat_s *does, int fx, char *name, skill_s *effective)
{
	actor_s *act;
/*
 * If no one is using, we skip this!
 */
#ifdef FX_SHIELDBREAKER
	shieldbreak = 0;
#endif
	if (amount == 0)
		return 1;
/*
 * Compute the target
 */
	if (does->target) {
		target_in_range(unit, does->range, does->target, fx);
#ifdef FX_SHIELDBREAKER
		if (unit->target && unit->target->shield_breaker) {
			shieldbreak = 1;
			return 1;
		}
#endif
	}
/*
 * Ok, so an effect is likely. What is the target, however?
 */
	switch (does->effect) {
	    case COMBAT_EFFECT_MELEE:
	    case COMBAT_EFFECT_RANGED:
		if (!unit->target) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("Round %d: [%s] has no melee target for %s at range %d\n", round_number, unit->unit->id.text, effective->tag.text, does->range);
#endif
			unit->considered++;
			return 1;
		}
		start_fold_unit_segment(unit);
		add_fold_string("uses ");
		add_fold_string(name);
		print_folded(full_report, 5);
		print_folded(long_report, 5);
		/* adjust_vitals(unit, does); */
		for(act = unit->autonomous; act; act = act->next) {
			if(!act->actor) adjust_vitals(act, does);
			if(act->actor && effective) {
				adjust_vitals(act, does);
			}
		}
	
		melee_strikes(unit, 0x7fffffff, fx);
		return 0;
	    case COMBAT_EFFECT_SPECIAL:
		if ((!unit->target && does->target) ||
				battle_fx_effect(unit, amount, fx, name, effective)) {
			unit->considered++;
			return 1;
		}
		return 0;
	    default:
		printf("Impossible combat effect %d\n", does->effect);
	}
	return 1;
}


/**
 ** BATTLE_COMPONENTS_AWAY
 **	We check if all required components are present. If required, we also
 ** remove these (it is assumed we did check first).
 **/
int battle_components_away(unit_s *unit, skill_s *skill, int removal)
{
consume_s	*component;
carry_s		*owns;
/*
 * Loop on all
 */
	for (component = skill->use_consumes; component; component = component->next)
		if ((owns = unit_possessions(unit, component->what, 0)) == 0 ||
		    owns->amount < component->amount) {
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("Round %d: [%s] lacks components for %s\n", round_number, unit->id.text, skill->tag.text);
#endif
			return 1;
		} else
			if (removal)
				owns->amount -= component->amount;
/*
 * it is assumed that components are never equippable
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("Round %d: [%s] has components for %s\n", round_number, unit->id.text, skill->tag.text);
#endif
	return 0;
}


/**
 ** UNIT_MAY_ACT
 **	Unit has an opportunity to act
 **/
int unit_may_act(figure_s *unit)
{
int		new_ini;
unit_s		*real;
carry_s		*equipment;
experience_s	*used;
combat_set_s	*doing;
skill_s		*used_skill;
item_s		*used_item;
int		moves, moved;
/*
 * Simplest case
 */
	if(unit->unit->traced_unit) {
		printf("Round %d: Unit may act called for %s\n",
		       round_number, unit->unit->id.text);
	}

	if (unit->active <= 0) {
		if(unit->unit->traced_unit) {
			printf("Round %d: unit->active <= 0 ([%s], %d)\n",
			       round_number, unit->unit->id.text,unit->active);
		}
		unit_has_acted(unit);
	}
	if(unit->prisoner) {
	    if(unit->unit->traced_unit) {
		printf("Round %d: unit->prisoner is true ([%s])\n",
			round_number, unit->unit->id.text);
	    }
	    unit_has_acted(unit);
	}
	if (unit->has_acted) {
		if(unit->unit->traced_unit) {
			printf("Round %d: unit [%s] has already acted (%d)\n",
			       round_number, unit->unit->id.text, unit->active);
		}
		return 0;
	}

/*
 * Has unit moved? If not, unit may move toward target
 */
	doing = unit->considered;

	if(doing->skill_used || doing->disabled) {
		if(unit->unit->traced_unit) {
			printf("Round %d: unit [%s] considered incrementing\n",
			       round_number, unit->unit->id.text);
		}
		unit->considered++;
#ifdef BATTLE_INITIATIVE
		if ((new_ini = unit->considered->initiative) < initiative_level) {
			unit->current_init = new_ini;
			battle_delay_processing(unit);
			return 0;
		}
#endif
		return 1;
	}

	if (!unit->has_moved) {
		if (!unit->last_target)
			unit_pick_target(unit);
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit) {
			if(unit->last_target) {
				printf("Round %d: %s [%s] has chosen %s [%s] as target.\n", round_number,
				       unit->unit->name, unit->unit->id.text,
				       unit->last_target->unit->name,
				       unit->last_target->unit->id.text);
			} else {
				printf("Round %d: %s [%s] has no target.\n",
				       round_number, unit->unit->name, unit->unit->id.text);
			}
		}
#endif
		moves = figure_moves(unit);
		moved = 1;
		while(moves && moved ) {
			moved = move_soldier(unit, doing->option);
			moves--;
		}
		unit->has_moved = 1;
	}
	if(unit->retreat) {
		if(unit->unit->traced_unit) {
			printf("Round %d: unit [%s] is retreating\n",
			       round_number, unit->unit->id.text);
		}
		unit_has_acted(unit);
	}

	/* Okay -- handle torpor */
	if(unit->torpor) {
		if(unit->torpor_act) {
			start_fold_unit_segment(unit);
			add_fold_string(" unable to attack due to torpor.");
			print_folded(full_report, 5);
			print_folded(long_report, 5);
			print_folded(terse_report, 5);
		    unit_has_acted(unit);
		}
		unit->torpor_act = 1-unit->torpor_act;
		if(!unit->torpor_act)
			return 0;
	}
/*
 * Various actions
 */
	if (doing->skill_used || doing->disabled) {
		if(unit->unit->traced_unit) {
			printf("Round %d: unit [%s] considered incrementing\n",
			       round_number, unit->unit->id.text);
		}
		unit->considered++;
	} else {
	switch (doing->option) {
/*
 * Easy options
 */
	    case COMBAT_SET_RELOAD:
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("Round %d: [%s] reloads\n", round_number, unit->unit->id.text);
#endif
		start_fold_unit_segment(unit);
		add_fold_string("reloads");
		print_folded(full_report, 5);
		print_folded(long_report, 5);
		unit_has_acted(unit);
		return 0;
/*
 * More complex
 */
	    case COMBAT_SET_MELEE:
	    case COMBAT_SET_RANGED:
	    case COMBAT_SET_ONCE:
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("Round %d; [%s] attempts to strike\n", round_number, unit->unit->id.text);
#endif
		if (unit->global.melee + unit->global.missile <= 0) {
			unit->considered++;
			break;
		}
		target_in_range(unit, unit->max_range, BATTLEFIELD_TARGET_OPPOSING, 0);
		if (!unit->target) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("Round %d: [%s] has no melee targets\n", round_number, unit->unit->id.text);
#endif
			unit->considered++;
			break;
		}
		if(doing->once) doing->disabled = 1;
		unit->melee_exp++;
		melee_strikes(unit, 0x7ffffff, 0);
		unit_has_acted(unit);
		return 0;
	    case COMBAT_SET_GUARD:
		if (unit->global.melee + unit->global.missile <= 0) {
			unit->considered++;
			break;
		}
		target_in_range(unit, unit->max_range, BATTLEFIELD_TARGET_OPPOSING, 0);
		if (!unit->target) {
			if (unit->unit->traced_unit)
				printf("Round %d: [%s] has no guard targets\n", round_number, unit->unit->id.text);
		} else {
			unit->melee_exp++;
			melee_strikes(unit, 0x7ffffff, 0);
		}
		if(doing->once) doing->disabled = 1;
		unit_has_acted(unit);
		return 0;
		
/*
 * Special skills
 */
	    case COMBAT_SET_SKILL:
/*
 * Does the combat skill require components? If so, do we have them?
 */
		real = unit->unit;
		used_skill = doing->u.use_skill;
		used = unit_experiences(real, used_skill, 0);
		if (!used || !used->effective) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("Round %d: [%s] does not master skill %s\n", round_number, unit->unit->id.text, used_skill->tag.text);
#endif
			unit->considered++;
			break;
		}
		if (battle_components_away(real, used->effective, 0)) {
			unit->considered++;
			break;
		}
		if(combat_special(unit, unit->active,
		    		     &used->effective->combat_action,
				     used->effective->special_effects,
				     used->effective->name, used->effective)) {
#ifdef FX_SHIELDBREAKER
			if (shieldbreak) {
				start_fold_unit_segment(unit);
				add_fold_string("falls against Shieldbreaker and cannot use ");
				add_fold_string(used->effective->name);
				print_folded(full_report, 5);
				unit->considered->disabled = 1;
			}
#endif
			if(doing->once) doing->disabled = 1;
			break;
		}
		(void)battle_components_away(real, used->effective, 1);
/*
 * The combat skill was acted upon, we consume the material
 */
		if (round_number <= 20)
			add_to_experience(unit->unit, used, used_skill, unit->unit->size*(SKILL_POINTS_PER_DAY/2));

/*
 * The action calls for a repeat?
 */
		if (unit->considered == &unit->mandated)
			break;
		if(doing->once) doing->disabled = 1;
		if (used_skill->type == 2) {
			unit->considered->skill_used = 1;
			unit->considered->avoid_action = 1;
		}
		unit_has_acted(unit);
		return 0;
/*
 * Special items
 */
	    case COMBAT_SET_ITEM:
		real = unit->unit;
		used_item = doing->u.use_item;
		for (equipment = unit->using; equipment; equipment = equipment->next)
			if (equipment->item == used_item)
				break;
		if (!equipment || !equipment->equipped) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("Round %d: [%s] has no equipment %s\n", round_number, unit->unit->id.text, used_item->tag.text);
#endif
			unit->considered++;
			break;
		}
		if (equipment->equipped > unit->active)
			equipment->equipped = unit->active;
		if (combat_special(unit, equipment->equipped, &used_item->combat_action, used_item->special_effects, equipment->equipped > 1 ? used_item->plural : used_item->name, 0)) {
#ifdef FX_SHIELDBREAKER
			if (shieldbreak) {
			carry_s	*owns;
				start_fold_unit_segment(unit);
				add_fold_string("falls against Shieldbreaker and loses its ");
				if (equipment->equipped > 1)
					add_fold_string(used_item->plural);
				else
					add_fold_string(used_item->name);
				print_folded(full_report, 5);
				unit->considered->disabled = 1;
				equipment->equipped = 0;
				equipment->amount = 0;
				owns = unit_possessions(unit->unit, used_item, 0);
				if (owns) {
					owns->equipped = 0;
					owns->amount = 0;
				}
			}
#endif
			if(doing->once) doing->disabled = 1;
			break;
		}
/*
 * We performed the action
 */
		if (used_item->equip_skill && round_number <= 20) {
			/* Hack to prevent camps from experiencing */
			if(real->race->type == RACE_LEADER) {
				used = unit_experiences(real, used_item->equip_skill, 1);
				add_to_experience(real, used, used_item->equip_skill, equipment->equipped*(SKILL_POINTS_PER_DAY/2));
			}
		}
/*
 * The action calls for a repeat?
 */
		if (unit->considered == &unit->mandated)
			break;
		unit_has_acted(unit);
		if(doing->once) doing->disabled = 1;
		return 0;
/*
 * Anything else constitues the end of activities for that unit
 */
	    default:
		if(unit->next_initiative) {
			unit->considered = unit->actions;
			unit->considered->initiative = unit->next_initiative->current_init;
			unit->current_init = unit->next_initiative->current_init;
			battle_delay_processing(unit);
			
		} else {
			unit_has_acted(unit);
		}
		return 0;
	}
	}
/*
 * None? Next action then.
 */
#ifdef BATTLE_INITIATIVE
	if ((new_ini = unit->considered->initiative) < initiative_level) {
		unit->current_init = new_ini;
		battle_delay_processing(unit);
		return 0;
	}
#endif
	return 1;
}
