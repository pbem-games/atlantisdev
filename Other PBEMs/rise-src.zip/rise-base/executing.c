/* $Id: executing.c,v 1.101 2001/02/05 04:38:53 jtraub Exp $
 *	Commands execution module.
 */
#include "turn.h"
#include "battle.h"
#include "parser.h"
#include "command_u.h"
#include "command_e.h"
#include "faction.h"


/**
 ** Special protos
 **/
extern void special_adjust_faction(void);
extern int escape_chance(unit_s *target, int transfer);

/**
 ** UNEXECUTABLE
 **	Default call for orders
 **/
int unexecutable(unit_s *unit, order_s *current)
{
#ifdef DYNAMICALLY_DEFINED_GAME
	printf("Unexecutable order %s for unit %s\n", current->executing.keyword, unit->id.text);
#endif
	current->considered = 1;
	return 0;
}

/**
 ** EXECUTING_TRANSFER 
 ** Unit is attempting to transfer a prisoner
 **/
int execute_transfer(unit_s *unit, order_s *current)
{
    unit_s *prisoner, *overall_leader;
    unit_s *new_gaoler;
    int chance1, chance2;

    if(unit->is_captive) return 0;
    if(current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
       current->executing.types[1] != ARGUMENT_IS_UNIT_ID) {
        unit_personal_event(unit, today_number, "Invalid TRANSFER order");
        order_is_error(unit, current);
        return 1;
    }
    prisoner = current->arguments[0].unit;
    if(!prisoner->is_captive) return 0;
    if(prisoner->leader != unit) return 0;

    new_gaoler = current->arguments[1].unit;
    if(!may_interact_with(unit, new_gaoler)) return 0;
    unit->sneaking = 0;
    if(attitude_vs(new_gaoler->faction, unit) >= ATTITUDE_IS_NEUTRAL) {
        sprintf(work, "%s [%s] will not accept your prisoner",
                new_gaoler->name, new_gaoler->id.text);
        unit_personal_event(unit, today_number, work);
        sprintf(work, "Refused prisoner transfer from %s [%s]", unit->name,
                unit->id.text);
        unit_personal_event(new_gaoler, today_number, work);
        order_is_error(unit, current);
        return 1;
    }
    chance1 = escape_chance(new_gaoler, 1);
    chance2 = escape_chance(unit, 1);

    if(chance2 > chance1) chance1 = chance2;

    if(chance1 && (roll_1Dx(100) < chance1)) {
        /* We have an escape */
        sprintf(work, "Prisoner %s [%s] escaped during transfer to %s [%s]",
                prisoner->name, prisoner->id.text, new_gaoler->name,
                new_gaoler->id.text);
        unit_personal_event(unit, today_number, work);
        sprintf(work, "Prisoner %s [%s] escaped during transfer from %s [%s]",
                prisoner->name, prisoner->id.text, unit->name, unit->id.text);
        unit_personal_event(new_gaoler, today_number, work);
        sprintf(work, "You escape from %s [%s] during a prisoner transfer.",
                unit->name, unit->id.text);
        unit_personal_event(prisoner, today_number, work);
		prisoner->escaping = 2;
        overall_leader = prisoner->leader;
        while (overall_leader->leader)
            overall_leader = overall_leader->leader;
        unstack_unit(prisoner);
        prisoner->next_location = overall_leader->next_location;
        overall_leader->next_location = prisoner;
    } else {
        sprintf(work, "Prisoner %s [%s] transferred to %s [%s]",
                prisoner->name, prisoner->id.text, new_gaoler->name,
                new_gaoler->id.text);
        unit_personal_event(unit, today_number, work);
        sprintf(work, "Prisoner %s [%s] transferred from %s [%s]",
                prisoner->name, prisoner->id.text, unit->name,
                unit->id.text);
        unit_personal_event(new_gaoler, today_number, work);
        sprintf(work, "You have been transferred to the custody of %s [%s]",
                new_gaoler->name, new_gaoler->id.text);
        unit_personal_event(prisoner, today_number, work);
        stack_under(new_gaoler, prisoner);
        prisoner->is_captive = 1;
    }
    order_was_executed(unit, current);
    return 1;
}


/**
 ** EXECUTING_RETREAT
 **	The unit is attempting to cancel the movement
 **/
int execute_retreat(unit_s *unit, order_s *current)
{
	unit_personal_event(unit, today_number, "Cannot RETREAT");
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EJECT_UNIT
 **	Sub-routine for ejection
 **/
static void eject_unit(unit_s *unit, unit_s *target)
{
/*
 * Ejection proceeeds
 */
	unit->sneaking = 0;
	sprintf(work, "%s [%s] is no longer welcome in stack", target->name, target->id.text);
	(void)execute_unstack(target, 0);
	if (unit->leader) {
		stack_under(unit->leader, target);
		sprintf(work, "%s [%s] is now stacked under your leadership", target->name, target->id.text);
		unit_personal_event(unit->leader, today_number, work);
	}
}


/**
 ** EXECUTING_DISBAND
 **	The unit is attempting to vanish
 **/
int execute_disband(unit_s *unit, order_s *current)
{
experience_s	*exp;
carry_s		*has;
#if defined(USES_CONTROL_POINTS) && defined(PRISONERS_TAKEN)
int cp_diff;
#endif
/*
 * Match
 */
	if (current && (current->executing.types[0] != ARGUMENT_IS_STRING ||
	    strcasecmp(current->arguments[0].string, "unit") )) {
		unit_personal_event(unit, today_number, "Invalid DISBAND; confirm by DISBAND UNIT");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Must exist
 */
	if (unit->size == 0) {
		unit_personal_event(unit, today_number, "Already disbanded");
		order_is_complete(unit, current);
		return 1;
	}
#ifdef PRISONERS_TAKEN
	if(unit->attempted_suicide)
		return 0;

	unit->sneaking = 0;
/*
 * Captive units do not disband
 */
	if (unit->is_captive) {
		unit->attempted_suicide = 1;
		if (roll_1Dx(5)) {
			unit_personal_event(unit, today_number, "Attempted suicide unsuccessful.");
			order_is_complete(unit, current);
			return 1;
		}
#ifdef USES_CONTROL_POINTS
		/* Unit suicided, handle the cp loss */
		cp_diff = unit->vital.control - unit->race->intrinsic.control;
		unit->faction->control_bonus -= cp_diff/2;
		if(unit->faction->control_bonus < 0)
			unit->faction->control_bonus = 0;
#endif
	}
#endif

/*
 * Add to local population
 */
	unit->size = 0;
	unit->disbanded = 1;
	unit_personal_event(unit, today_number, "Disbands!");
	for (exp = unit->skilled; exp; exp = exp->next) {
		exp->points = 0;
		exp->effective = 0;
#ifdef USES_SKILL_LEVELS
		exp->level = 0;
#endif
	}
	for (has = unit->carrying; has; has = has->next) {
		has->amount = 0;
		has->tokens = 0;
	}
	unit->wages = 0;
/*
 * Finally no flags
 */
	unit->setting_guard = 0;
	unit->setting_protect = 0;
	while (unit->stack)
		eject_unit(unit, unit->stack);
	move_to_location(unit, 0);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_STANCE
 **	The faction changes its stances
 **/
int execute_stance(unit_s *unit, order_s *current)
{
stance_s	*stance;
faction_s	*toward;
unit_s		*specific;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_STANCE) {
		unit_personal_event(unit, today_number, "Invalid STANCE order");
		order_is_error(unit, current);
		return 1;
	}
	if (current->executing.types[1] != ARGUMENT_IS_FACTION_ID
#ifdef STANCE_TOWARD_UNITS
	    && current->executing.types[1] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid STANCE order; need faction or unit ID");
#else
	) {
		unit_personal_event(unit, today_number, "Invalid STANCE order; need faction ID");
#endif
		order_is_error(unit, current);
		return 1;
	}
/*
 * Which stance
 */
	if (current->executing.types[1] == ARGUMENT_IS_FACTION_ID) {
		toward = current->arguments[1].faction;
		if (toward == unit->faction || strcasecmp(toward->id.text, "default") == 0)
			toward = 0;
		specific = 0;
	} else {
		toward = 0;
		specific = current->arguments[1].unit;
	}

	if(toward && (toward == unit->faction->vassal_of)) {
		unit_personal_event(unit, today_number, "Invalid STANCE order; Cannot change stance toward liege");
		order_is_error(unit, current);
		return 1;
	}
	if(specific && (specific->faction == unit->faction->vassal_of)) {
	    if(!specific->setting_advert) {
		unit_personal_event(unit, today_number, "Invalid STANCE order; Cannot change stance toward liege");
		order_is_error(unit, current);
		return 1;
	    }
	}
/*
 * Special case (default or self)?
 */
	if (!toward && !specific) {
		if (current->arguments[0].number == 5)
			unit_personal_event(unit, today_number, "Can't default the default stance");
		else {
			unit->faction->attitude = current->arguments[0].number;
			unit_personal_event(unit, today_number, "Default stance changed");
		}
		order_is_complete(unit, current);
		if(unit->faction->attitude == ATTITUDE_IS_ENEMY)
			unit->faction->has_enemies = 1;
		return 1;
	}
/* 
 * Special "unknown" case
 */
	if (toward && strcasecmp(toward->id.text, "unknown") == 0) {
		unit->faction->anon_attitude = current->arguments[0].number;
		unit_personal_event(unit, today_number, "Stance toward unknowns changed");
		if(unit->faction->anon_attitude == ATTITUDE_IS_ENEMY)
			unit->faction->has_enemies = 1;
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Other faction stance!
 */
	if (specific)
		stance = find_unit_stance_for(unit->faction, specific, 1);
	else
		stance = find_stance_for(unit->faction, toward, 1);
	if (current->arguments[0].number == 5) {
		stance->attitude = -1;
		if (specific)
			sprintf(work, "Attitude toward %s [%s] reverted to default", specific->name, specific->id.text);
		else
			sprintf(work, "Attitude toward %s [%s] reverted to default", toward->name, toward->id.text);
		unit_personal_event(unit, today_number, work);
	} else {
		stance->attitude = current->arguments[0].number;
		if (specific)
			sprintf(work, "Attitude toward %s [%s] specified", specific->name, specific->id.text);
		else
			sprintf(work, "Attitude toward %s [%s] specified", toward->name, toward->id.text);
		unit_personal_event(unit, today_number, work);
	}

	if(stance->attitude == ATTITUDE_IS_ENEMY) {
		unit->faction->has_enemies = 1;
	}

	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_COMBAT
 **	The unit changes its combat actions
 **/
int execute_combat(unit_s *unit, order_s *current)
{
combat_set_s	*c;
int		n;
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	c = unit->combat;
	for (n = 0; n < MAX_COMBAT_SETTING; n++) {
		if (current->executing.types[n] == 0)
			break;
		if(current->combat_once[n])
		    c->once = 1;
		if (current->executing.types[n] == ARGUMENT_IS_COMBAT_OPTION) {
			c->option = current->arguments[n].number;
			c++;
			continue;
		}
		if (current->executing.types[n] == ARGUMENT_IS_SKILL_TAG) {
			c->u.use_skill = current->arguments[n].skill;
			if (!c->u.use_skill->combat_action.effect) {
				sprintf(work, "Skill %s isn't a combat action, skipped", c->u.use_skill->name);
				unit_personal_event(unit, today_number, work);
			} else {
				c->option = COMBAT_SET_SKILL;
				c++;
			}
			continue;
		}
		if (current->executing.types[n] == ARGUMENT_IS_ITEM_TAG) {
			c->u.use_item = current->arguments[n].item;
			if (!c->u.use_item->combat_action.effect) {
				sprintf(work, "Item %s cannot be used in combat, skipped", c->u.use_item->name);
				unit_personal_event(unit, today_number, work);
			} else {
				c->option = COMBAT_SET_ITEM;
				c++;
			}
			continue;
		}
	}
	if (c != unit->combat)
		unit_personal_event(unit, today_number, "Combat actions selected");
	else
		unit_personal_event(unit, today_number, "Default combat action now used");
	c->option = 0;
/*
 * Done
 */
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_TACTIC
 **	The unit is changing its tactics
 **/
int execute_tactic(unit_s *unit, order_s *current)
{
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_BATTLE ||
	    current->executing.types[1] != ARGUMENT_IS_RANK ||
	    current->executing.types[2] != ARGUMENT_IS_FILE ||
	    current->executing.types[3] != ARGUMENT_IS_MOVE) {
		unit_personal_event(unit, today_number, "Invalid TACTIC order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Just copy the settings
 */
	unit->participate = current->arguments[0].number;
	unit->rank = current->arguments[1].number;
	if(unit->rank != 0 && unit->race->type != RACE_LEADER) {
		unit->rank = 0;
		unit_personal_event(unit, today_number, "Camps must remain on the rear rank; rank changed to rear.");
	}
	unit->file = current->arguments[2].number;
	unit->movement = current->arguments[3].number;
	unit_personal_event(unit, today_number, "New tactics selected");
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_SETTING
 **	The unit changes its settings
 **/
int execute_setting(unit_s *unit, order_s *current)
{
int	n;
/*
 * Validate argument
 */
	if (current->executing.types[0] != ARGUMENT_IS_SETTING ||
	    current->executing.types[1] != ARGUMENT_IS_BOOLEAN) {
		unit_personal_event(unit, today_number, "Invalid SETTING order");
		order_is_error(unit, current);
		return 1;
	}

	if (unit->is_captive)
		return 0;
/*
 * Execute
 */
	n = current->arguments[1].number;
	switch (current->arguments[0].number) {
#ifdef UNIT_SETTING_HUSHGIVE
	    case UNIT_SETTING_HUSHGIVE:
		sprintf(work, "Hushgive is now %s", n ? "true" : "false");
		unit->setting_hushgive = n;
		break;
#endif
#ifdef UNIT_SETTING_ANNOUNCE
	    case UNIT_SETTING_ANNOUNCE:
		sprintf(work, "Anonymous is now %s", n ? "true" : "false");
		unit->setting_advert = n;
		break;
#endif
#ifdef UNIT_SETTING_GUARD
	    case UNIT_SETTING_GUARD:
		if (unit->true_location->type == neutral_city) {
			strcpy(work, "Cannot guard in neutral cities");
			unit->setting_guard = 0;
			break;
		}
		if(unit->race != garrison_race && unit->race->type != RACE_LEADER) {
			/* see if we should be a garrison */
			carry_s *carry;
			int garr = 0;
			for(carry = unit->carrying; carry; carry = carry->next) {
				if(carry->item->item_type == ITEM_FOLLOWER &&
				   (carry->item->equip_bonus.melee ||
				    carry->item->equip_bonus.missile) &&
				   carry->amount) {
					garr = 1;
				}
			}
			if(!garr) {
				strcpy(work, "Only garrisons can gaurd");
				unit->setting_guard = 0;
				break;
			}
		}
		sprintf(work, "Guarding location is now %s", n ? "true" : "false");
		unit->setting_guard = n;
		if(unit->setting_guard) {
			unit->true_location->guarded = 1;
			unit->sneaking = 0;
		}
		break;
#endif
#ifdef UNIT_SETTING_HTML
	    case UNIT_SETTING_HTML:
		printf("Panic: HTML used!\n");
		break;
#endif
#ifdef UNIT_SETTING_MISER
	    case UNIT_SETTING_MISER:
		sprintf(work, "Avoid fund use is now %s", n ? "true" : "false");
		unit->setting_miser = n;
		break;
#endif
#ifdef UNIT_SETTING_PROTECT
	    case UNIT_SETTING_PROTECT:
		if(unit->race != garrison_race && unit->race->type != RACE_LEADER) {
			/* see if we should be a garrison */
			carry_s *carry;
			int garr = 0;
			for(carry = unit->carrying; carry; carry = carry->next) {
				if(carry->item->item_type == ITEM_FOLLOWER &&
				   (carry->item->equip_bonus.melee ||
				    carry->item->equip_bonus.missile) &&
				   carry->amount) {
					garr = 1;
				}
			}
			if(!garr) {
				strcpy(work, "Only garrisons can protect structures");
				unit->setting_protect= 0;
				break;
			}
		}
		sprintf(work, "Structure protection is now %s", n ? "true" : "false");
		unit->setting_protect = n;
		if(unit->setting_protect) {
			unit->sneaking = 0;
		}
		break;
#endif
#ifdef UNIT_SETTING_SILENT
	    case UNIT_SETTING_SILENT:
		sprintf(work, "Silence on activities is now %s", n ? "true" : "false");
		unit->setting_silent = n;
		break;
#endif
#ifdef UNIT_SETTING_SUPPORT
	    case UNIT_SETTING_SUPPORT:
		sprintf(work, "Prefer fund support is now %s", n ? "true" : "false");
		unit->setting_support = n;
		break;
#endif
#ifdef UNIT_SETTING_TERSE
	    case UNIT_SETTING_TERSE:
		sprintf(work, "Short battle reports is now %s", n ? "true" : "false");
		unit->faction->setting_terse = n;
		break;
#endif
	    default:
		sprintf(work, "BEWARE! Incoherency within game engine");
		printf("%s!!!\n", work);
	}
	unit_personal_event(unit, today_number, work);
/*
 * Done
 */
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_STAY
 **	Wants to remain in place
 **/
int execute_stay(unit_s *unit, order_s *current)
{
	if (unit->is_captive)
		return 0;
	unit->wants_stay = 1;
	current->considered = 1;
	order_was_executed(unit, current);
	return 0;
}


/**
 ** EXECUTING_LOYAL
 **	The unit wants to follows another's rule
 **/
int execute_loyal(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid LOYAL order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
	if (target->faction == unit->faction)
		return 0;
	if(target->is_captive)
		return 0;

	compute_unit_stats(unit);
	if(target->faction->control_current + unit->vital.control > target->faction->control_max)
		return 0;
	if(attitude_vs(target->faction, unit) >= ATTITUDE_IS_NEUTRAL)
		return 0;
	if(attitude_vs(unit->faction, target) >= ATTITUDE_IS_NEUTRAL)
		return 0;

	unit->sneaking = 0;
/*
 * Unit is now loyal to...
 */
	sprintf(work, "Now loyal to %s [%s]", target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit->now_loyal = target->faction;
	sprintf(work, "%s [%s] declared its loyalty to your cause", unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_UNSTACK
 **	The unit is attempting to leave the stack
 **/
int execute_unstack(unit_s *unit, order_s *current)
{
unit_s	*overall_leader;
/*
 * Valid condition?
 */
	if (unit->is_captive && current)
		return 0;
	if (unit->leader) {
		if (current) {
			if (current->executing.routine == execute_stay)
				sprintf(work, "%s [%s] stays in place", unit->name, unit->id.text);
			else
				sprintf(work, "%s [%s] unstacks", unit->name, unit->id.text);
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("%s executes %s\n", unit->id.text, current->executing.keyword);
#endif
		}
#ifdef TRACING_REQUIRED
		else
			if (unit->traced_unit)
				printf("%s auto-unstacks\n", unit->id.text);
#endif
/*
 * If no current order, the calling execute_xxx has already filled in some for us
 */
		unit_personal_event(unit, today_number, work);
		unit_personal_event(unit->leader, today_number, work);
		overall_leader = unit->leader;
		while (overall_leader->leader)
			overall_leader = overall_leader->leader;
		unstack_unit(unit);
		unit->next_location = overall_leader->next_location;
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s copies leader %s->next_location (0x%x)\n", unit->id.text,overall_leader->id.text,(unsigned)unit->next_location);
#endif
		overall_leader->next_location = unit;
#ifdef TRACING_REQUIRED
		if (overall_leader->traced_unit)
			printf("%s->next_location is now %s (0x%x)\n", overall_leader->id.text,unit->id.text,(unsigned)unit);
#endif
	} else
		unit_personal_event(unit, today_number, "Already unstacked!");
	if (current)
		order_is_complete(unit, current);
	return 1;
}

static void unstack_nonmages(unit_s *stack)
{
	unit_s *next;
	experience_s *exp;
/*
 * Stacking is scanned depth-first, then breadth-first
 */
	while (stack) {
		next = stack->next_location;
		exp = unit_experiences(stack, magecraft, 0);
		if(!exp) {
			sprintf(work, "%s [%s] cannot enter the mage tower and unstacks",
				stack->name, stack->id.text);
			(void)execute_unstack(stack, NULL);
		} else
			unstack_nonmages(stack->stack);
		stack = next;
	}
}

/**
 ** UNSTACK_STAYS
 **	Unstack any unit that wants to stay in place. This is recursive
 **/
static void unstack_stays(unit_s *stack)
{
unit_s	*next;
order_s	*stay;
/*
 * Stacking is scanned depth-first, then breadth-first
 */
	while (stack) {
		next = stack->next_location;
/*
 * Unit wants to stay, it executes again STAY, but as UNSTACK
 */
		if (stack->wants_stay || stack->has_recruited || stack->race->type != RACE_LEADER) {
			for (stay = stack->orders; stay; stay = stay->next)
				if (stay->considered && stay->executing.routine == execute_stay)
					break;
			sprintf(work, "%s [%s] unstacks", stack->name, stack->id.text);
			(void)execute_unstack(stack, stay);
		} else
			unstack_stays(stack->stack);
		stack = next;
	}
}


/**
 ** EXECUTING_EJECT
 **	We throw out the unit
 **/
int execute_eject(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Valid condition?
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		while (unit->stack)
			eject_unit(unit, unit->stack);
		order_is_complete(unit, current);
		return 1;
	}

/*
 * We want to eject someone from out stack!
 */
	target = current->arguments[0].unit;
	if (target == unit) {
		unit_personal_event(unit, today_number, "Invalid EJECT; cannot eject self");
		order_is_error(unit, current);
		return 1;
	}

	if(target->size <=0) return 0;

	if (target->leader == unit) {
		eject_unit(unit, target);
		order_is_complete(unit, current);
		return 1;
	}
/*
 * That someone is located in a structure we are owner and it is not
 * the title holder!
 */
	if (target->current == target->true_location)
		return 0;
	if (target->current->present == unit) {
#ifdef USES_TITLE_SYSTEM
		if (target->title == target->current) {
			unit_personal_event(unit, today_number, "Invalid EJECT; cannot eject title owner");
			order_is_error(unit, current);
			return 1;
		} else
#endif
			{
			unit->sneaking = 0;
			sprintf(work, "%s [%s] expells you", unit->name, unit->id.text);
			unit_personal_event(target, today_number, work);
			execute_leave(target, 0);
		}
		order_is_complete(unit, current);
		return 1;
	}
/*
 * That someone is located in a structure and we are the title owner
 */
#ifdef USES_TITLE_SYSTEM
	if (unit->title == target->current && unit->true_location == target->true_location) {
		sprintf(work, "%s [%s] expells you", unit->name, unit->id.text);
		unit_personal_event(target, today_number, work);
		execute_leave(target, 0);
		order_is_complete(unit, current);
		return 1;
	}
#endif
	return 0;
}


/**
 ** EXECUTING_PROMOTE
 **	The unit is attempting to promote someone
 **/
int execute_promote(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*prior, *scan;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid PROMOTE order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same stack level and at the same location!
 */
	target = current->arguments[0].unit;
	if (target->current != unit->current ||
	    target->leader != unit->leader)
		return 0;
/*
 * Stealth intervenes: we have to see the promoted unit
 */
	if(target->sneaking) return 0;
#ifdef STEALTH_STATS
	if (!target->setting_report)
		if (unit->vital.observation < target->effective_stealth)
			return 0;
#endif
/*
 * Furthermore, the next unit must be following us
 */
	prior = unit;
	for (scan = unit->next_location; scan; scan = scan->next_location)
		if (scan == target)
			break;
		else
			prior = scan;
	if (!scan)
		return 0;
	unit->sneaking = 0;
/*
 * We do promote!
 */
	prior->next_location = target->next_location;
#ifdef TRACING_REQUIRED
	if (prior->traced_unit)
		printf("dropping unit %s from %s->next_location (now 0x%x)\n", target->id.text, prior->id.text, (unsigned)prior->next_location);
#endif
	prior = 0;
	if (unit->leader)
		scan = unit->leader->stack;
	else
		scan = unit->current->present;
	while (scan)
		if (scan == unit)
			break;
		else {
			prior = scan;
			scan = scan->next_location;
		}
/*
 * Impossibility
 */
	if (!scan)
		abort();
	if (prior) {
		prior->next_location = target;
#ifdef TRACING_REQUIRED
		if (prior->traced_unit)
			printf("inserted unit %s at %s->next_location (now 0x%x)\n", target->id.text, prior->id.text, (unsigned)prior->next_location);
#endif
	} else
		if (unit->leader)
			unit->leader->stack = target;
		else
			unit->current->present = target;
	target->next_location = unit;
#ifdef TRACING_REQUIRED
	if (target->traced_unit)
		printf("unit %s now precedes unit %s\n", target->id.text, unit->id.text);
#endif
/*
 * Report promotion
 */
	sprintf(work, "%s [%s] promotes %s [%s]", unit->name, unit->id.text,
				target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_ACCEPT
 **	The unit accepts someone
 **/
int execute_accept(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid ACCEPT order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	if(unit->race->type != RACE_LEADER) {
	    unit_personal_event(unit, today_number, "Invalid ACCEPT order; Only leaders can accept");
	    order_is_error(unit, current);
	    return 1;
	}
	target = current->arguments[0].unit;
	if (target->faction == unit->faction) {
		unit_personal_event(unit, today_number, "Accept ignored within the same faction");
		order_is_complete(unit, current);
		return 1;
	}
	if (!may_interact_with(unit, target))
		return 0;
	unit->sneaking = 0;
	current->considered = 1;
	return 1;
}


/**
 ** EXECUTING_LEADER
 **	The unit must be led by X (at any level)
 **/
int execute_leader(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*leader;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid LEADER order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must have the target in the leader links
 */
	target = current->arguments[0].unit;
	for (leader = unit->leader; leader; leader = leader->leader)
		if (leader == target)
			break;
	if (leader == 0)
		return 0;
/*
 * True
 */
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** HAS_FOLLOWER
 **	Check for follower presence in stack
 **/
static int has_follower(unit_s *follower, unit_s *target)
{
	while (follower) {
		if (follower == target)
			return 1;
		if (has_follower(follower->stack, target))
			return 1;
		follower = follower->next_location;
	}
	return 0;
}


/**
 ** EXECUTING_LEADING
 **	The unit must have X as a follower
 **/
int execute_leading(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid LEADING order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must have the target in the stack list
 */
	target = current->arguments[0].unit;
	if (!has_follower(unit->stack, target))
		return 0;
/*
 * True
 */
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SYNCHRO
 **	The unit waits the other one to catch up
 **/
int execute_synchro(unit_s *unit, order_s *current)
{
unit_s	*target;
order_s	*order;
char	*string;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if(unit->synchro) return 0;

	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid SYNCHRO order; missing unit ID");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (target == unit) {
		if (!unit->setting_silent)
			unit_personal_event(unit, today_number, "Self-synchronise");
		order_was_executed(unit, current);
		return 1;
	}
	if (target->inactive || target->dead)
		return 0;
	if(target->synchro) return 0;

	if (unit->faction != target->faction && !may_interact_with(unit, target))
		return 0;
	if (current->executing.types[1] == ARGUMENT_IS_STRING)
		string = current->arguments[1].string;
	else
		string = 0;
/*
 * Find out if the target has the reciprocal order
 */
	for (order = target->orders; order; order = order->next)
		if (order->executing.routine == execute_synchro &&
		    !order->conditional&&
		    !order->considered &&
		    (!order->limit_low || (order->limit_low <= today_number && order->limit_high >= today_number)) &&
		    order->executing.types[0] == ARGUMENT_IS_UNIT_ID &&
		    order->arguments[0].unit == unit &&
		    order->executing.types[1] == current->executing.types[1] &&
		    (!string || strcasecmp(order->arguments[1].string, string) == 0) )
			break;
	if (!order)
		return 0;
	unit->sneaking = 0;
/*
 * We do synchronise
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit || target->traced_unit)
		printf("Synchro between %s [%s] and %s [%s] occurs\n", unit->id.text, unit->name, target->id.text, target->name);
#endif
	if (!unit->setting_silent) {
		sprintf(work, "Synchronise with %s [%s]", target->name, target->id.text);
		if (string)
			sprintf(work+strlen(work), ", keyword %s", string);
		unit_personal_event(unit, today_number, work);
	}
	unit->synchro = 1;
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
/*
 * The other unit also executes!
 */
	if (!target->setting_silent) {
		sprintf(work, "Synchronise with %s [%s]", unit->name, unit->id.text);
		if (string)
			sprintf(work+strlen(work), ", keyword %s", string);
		unit_personal_event(target, today_number, work);
	}
	target->synchro = 1;
	if (order->days < 0)
		infinite_conditional(target, order);
	else
		order_was_executed(target, order);
	return 1;
}


/**
 ** EXECUTING_AT
 **	Wait for the location
 **/
int execute_at(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid AT order");
		order_is_error(unit, current);
		return 0;
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s executes AT %s\n", unit->id.text, current->arguments[0].location->id.text);
#endif
/*
 * Valid
 */
	if (unit->current == current->arguments[0].location) {
		current->considered = 1;
		if (current->days < 0)
			infinite_conditional(unit, current);
		else
			order_was_executed(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTE_EXACTLY
 **	Wait for exaxtly X items
 **/
int execute_exactly(unit_s *unit, order_s *current)
{
carry_s	*has;
int	amount, count;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number,
				    "Invalid EXACTLY order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Amount?
 */
	amount = current->arguments[0].number;
	if (amount < 0)
		amount = 0;

	if(current->arguments[1].item->item_type == ITEM_DAYS ||
	   current->arguments[1].item->item_type > ITEM_EFFECT)
		return 0;
/*
 * Owns?
 */
	has = unit_possessions(unit, current->arguments[1].item, 0);
	if(!has)
	    count = 0;
	else
	    count = has->amount;

	if(count != amount)
	    return 0;
	current->considered = 1;
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}

/**
 ** EXECUTE_HAVE
 **	Wait for more than or equal to X items
 **/
int execute_have(unit_s *unit, order_s *current)
{
carry_s	*has;
int	amount, count;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid HAVE order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Amount?
 */
	amount = current->arguments[0].number;
	if (amount <= 0)
		amount = 1;

	if(current->arguments[1].item->item_type == ITEM_DAYS ||
	   current->arguments[1].item->item_type > ITEM_EFFECT)
		return 0;
/*
 * Owns?
 */
	has = unit_possessions(unit, current->arguments[1].item, 0);
	if(has)
	    count = has->amount;
	else
	    count = 0;
	if(count < amount)
		return 0;
	current->considered = 1;
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_LESS
 **	Wait for less than or equal to X items
 **/
int execute_less(unit_s *unit, order_s *current)
{
carry_s	*has;
int	amount, count;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid LESS order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Amount?
 */
	amount = current->arguments[0].number;
	if (amount <= 0)
		amount = 1;

	if(current->arguments[1].item->item_type == ITEM_DAYS ||
	   current->arguments[1].item->item_type > ITEM_EFFECT)
		return 0;
/*
 * Owns?
 */
	has = unit_possessions(unit, current->arguments[1].item, 0);
	if(has)
	    count = has->amount;
	else
	    count = 0;
	if(count > amount)
		return 0;
	current->considered = 1;
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SIZE
 **	Count followers
 **/
int execute_size(unit_s *unit, order_s *current)
{
carry_s	*has;
int	amount;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid SIZE order; not a number");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Amount?
 */
	amount = current->arguments[0].number;
	if (amount <= 0)
		amount = 1;
/*
 * Leader counts as one
 */
	if (unit->race && unit->race->type == RACE_LEADER)
		amount -= unit->size;
/*
 * Owns followers?
 */
	for (has = unit->carrying; has; has = has->next)
		if (has->amount && has->item->item_type == ITEM_FOLLOWER)
			amount -= has->amount;
	if (amount > 0)
		return 0;
	current->considered = 1;
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SEE
 **	The unit looks around for someone
 **/
int execute_see(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid SEE order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
	if (!unit->setting_silent) {
		sprintf(work, "Saw %s [%s]", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
	}
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SKILL
 **	The unit checks its skill advance
 **/
int execute_skill(unit_s *unit, order_s *current)
{
experience_s	*exp;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid SKILL order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must have the skill
 */
	if ((exp = unit_experiences(unit, current->arguments[0].skill, 0)) == 0 || exp->points == 0)
		return 0;
	if (exp->effective == 0)
		return 0;
/*
 * We do have the required skill
 */
	if (current->days < 0)
		infinite_conditional(unit, current);
	else
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_DAY
 **	Wait for the specific day of the month
 **/
int execute_day(unit_s *unit, order_s *current)
{
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid DAY order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Valid
 */
	current->considered = 1;
	if (today_number == current->arguments[0].number) {
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTE_WITHDRAW
 **	The unit is gettings free stuff
 **/
int execute_withdraw(unit_s *unit, order_s *current)
{
carry_s	*goods;
item_s	*special;
int	amount;
int	funds;
/*
 * Validate argument
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid WITHDRAW order");
		order_is_error(unit, current);
		return 1;
	}
	amount = current->arguments[0].number;
	if (amount <= 0)
		return 0;
/*
 * Special items?
 */
	funds = amount;
	special = item_cash;
	if (current->executing.types[1] == ARGUMENT_IS_ITEM_TAG) {
		special = current->arguments[1].item;
		if (!special->suggested_price || !special->item_live) {
			sprintf(work, "Invalid WITHDRAW order; %s cannot be withdrawn", special->name);
			unit_personal_event(unit, today_number, work);
			order_is_error(unit, current);
			return 1;
		}
		funds *= special->suggested_price;
	}
	if (funds > unit->faction->faction_fund) {
		amount = unit->faction->faction_fund / special->suggested_price;
		if (amount > 0)
			funds = amount * special->suggested_price;
	}
	if (amount <= 0) {
		sprintf(work, "$%d exceeds faction funds ($%d)", funds, unit->faction->faction_fund);
		unit_personal_event(unit, today_number, work);
		order_is_error(unit, current);
		return 1;
	}
/*
 * Carrying
 */
	goods = unit_possessions(unit, special, 1);
	goods->amount += amount;
	sprintf(work, "Withdrawing %d %s ($%d value)", amount, amount > 1 ? special->plural : special->name, funds);
	unit->faction->faction_fund -= funds;
	unit->faction->turn_withdraw += funds;

	unit_personal_event(unit, today_number, work);
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_GET
 **	Unit gives something to another unit. Both must be at the same location
 ** and the other must treat the first as friendly.
 **/
int execute_get(unit_s *unit, order_s *current)
{
unit_s	*recipient;
carry_s	*items;
carry_s	*handed;
int	garr;
item_s	*type;
int	given, kept;
static item_s *orb;

	if(!orb) {
	    synthetic_tag("orbr");
	    orb = item_from_tag(0);
	}
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[1] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[2] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid GET order");
		order_is_error(unit, current);
		return 1;
	}
	recipient = current->arguments[0].unit;
/*
 * Interaction
 */
	if(recipient->size == 0)
		return 0;
	if (!may_interact_with(unit, recipient))
		return 0;

	if (recipient->faction && recipient->faction != unit->faction && (!recipient->is_captive || unit != recipient->leader)) {
		unit_personal_event(unit, today_number, "GET is allowed only within same faction or from your prisoners");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Validate item amounts
 */
	type = current->arguments[2].item;
	items = unit_possessions(recipient, type, 0);
	if (!items)
		return 0;
	if(items->item == orb && recipient->is_captive)
	    return 0;
	kept = 0;
	given = current->arguments[1].number;
	if (current->executing.types[3] == ARGUMENT_IS_NUMBER)
		kept = current->arguments[3].number;
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given > items->amount)
		return 0;
	current->considered = 1;
/*
 * Carrying
 */
	handed = unit_possessions(unit, type, 1);
	items->amount -= given;
	if (type == item_mana)
		given = 0;
	handed->amount += given;
	if (given > 0 && !unit->setting_silent && ((current->days >=0) || !unit->setting_hushgive)) {
		sprintf(work, "Getting %d %s [%s] from %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
	}
	if (!recipient->setting_silent && ((current->days >=0) || !recipient->setting_hushgive)) {
	    if(recipient->is_captive && unit == recipient->leader) {
		sprintf(work, "%s [%s] took %d %s [%s] from you", unit->name,
			unit->id.text, given,
			given > 1 ? type->plural : type->name,
			type->tag.text);
	    } else {
		sprintf(work, "Handed %d %s [%s] to %s [%s]", given,
			given > 1 ? type->plural : type->name,
			type->tag.text, unit->name, unit->id.text);
	    }
	    unit_personal_event(recipient, today_number, work);
	}
	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(recipient);
	}

	if(handed->equipped && handed->equipped < handed->item->equip_maximum) {
		if(handed->amount >= handed->item->equip_maximum)
			handed->equipped = handed->item->equip_maximum;
		else
			handed->equipped = handed->amount;
		compute_unit_stats(unit);
	}
	unit->sneaking = 0;
	garr = 0;
	if(recipient->race->type == RACE_LEADER) garr = 1;
	for(items = recipient->carrying; items; items= items->next) {
		if(items->item->item_type == ITEM_FOLLOWER &&
		   items->amount &&
		   (items->item->equip_bonus.missile || 
		    items->item->equip_bonus.melee))
			garr = 1;
	}
	if(!garr) {
		if(recipient->setting_guard) {
			sprintf(work, "Unable to continue guarding with no troops");
			unit_personal_event(recipient, today_number, work);
			recipient->setting_guard = 0;
		}
		if(recipient->setting_protect) {
			sprintf(work, "Unable to continue protecting access with no troops");
			unit_personal_event(recipient, today_number, work);
			recipient->setting_protect = 0;
		}
	}
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_SWAP
 **	The units want a secure trade
 **/
int execute_swap(unit_s *unit, order_s *current)
{
order_s	*order;
unit_s	*target;
item_s	*giving, *getting;
carry_s	*mine, *yours, *hand;
int	garr;
int	given, expected;
/*
 * Invalid arguments. Delete the order
 */
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG ||
	    current->executing.types[2] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[3] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[4] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid SWAP order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[2].unit;
	if (target == unit) {
		unit_personal_event(unit, today_number, "Invalid SWAP order; Can't swap with yourself");
		order_is_error(unit, current);
		return 1;
	}
	if (target->inactive || target->dead)
		return 0;
	if (!may_interact_with(unit, target))
		return 0;

	given  = current->arguments[0].number;
	giving = current->arguments[1].item;
	expected = current->arguments[3].number;
	getting  = current->arguments[4].item;
/*
 * Both must have the items!
 */
	mine = unit_possessions(unit, giving, 0);
	if (!mine || mine->amount < given)
		return 0;
	yours = unit_possessions(target, getting, 0);
	if (!yours || yours->amount < expected)
		return 0;
/*
 * Find out if the target has the reciprocal order
 */
	for (order = target->orders; order; order = order->next)
		if (order->executing.routine == execute_swap &&
		    !order->conditional&&
		    !order->considered &&
		    (!order->limit_low || (order->limit_low <= today_number && order->limit_high >= today_number)) &&
		    order->executing.types[0] == ARGUMENT_IS_NUMBER &&
		    order->arguments[0].number == expected &&
		    order->executing.types[1] == ARGUMENT_IS_ITEM_TAG &&
		    order->arguments[1].item == getting &&
		    order->executing.types[2] == ARGUMENT_IS_UNIT_ID &&
		    order->arguments[2].unit == unit &&
		    order->executing.types[3] == ARGUMENT_IS_NUMBER &&
		    order->arguments[3].number == given &&
		    order->executing.types[4] == ARGUMENT_IS_ITEM_TAG &&
		    order->arguments[4].item == giving)
			break;
	if (!order)
		return 0;
	unit->sneaking = 0;
/*
 * We do swap!
 */
	sprintf(work, "Swapped %d %s for %d %s from %s [%s]", given,
			(given > 1 ? giving->plural : giving->name), expected,
			(expected > 1 ? getting->plural : getting->name), target->name,
			target->id.text);
	unit_personal_event(unit, today_number, work);

	sprintf(work, "Swapped %d %s for %d %s from %s [%s]", expected,
			(expected > 1 ? getting->plural : getting->name), given,
			(given > 1 ? giving->plural : giving->name), unit->name,
			unit->id.text);
	unit_personal_event(target, today_number, work);
	hand = unit_possessions(target, giving, 1);
	hand->amount += given;
	mine->amount -= given;
	hand = unit_possessions(unit, getting, 1);
	hand->amount += expected;
	yours->amount -= expected;
/*
 * Did we swap equipment?
 */
	if (mine->equipped > mine->amount) {
		mine->equipped = mine->amount;
		compute_unit_stats(unit);
	}
	if (yours->equipped > yours->amount) {
		yours->equipped = yours->amount;
		compute_unit_stats(target);
	}
/*
 * The other unit also executes!
 */
	order_was_executed(unit, current);
	order_was_executed(target, order);
	garr = 0;
	if(target->race->type == RACE_LEADER) garr = 1;
	for(hand = target->carrying; hand; hand = hand->next) {
		if(hand->item->item_type == ITEM_FOLLOWER &&
		   hand->amount &&
		   (hand->item->equip_bonus.missile || 
		    hand->item->equip_bonus.melee))
			garr = 1;
	}
	if(!garr) {
		if(target->setting_guard) {
			sprintf(work, "Unable to continue guarding with no troops");
			unit_personal_event(target, today_number, work);
			target->setting_guard = 0;
		}
		if(target->setting_protect) {
			sprintf(work, "Unable to continue protecting access with no troops");
			unit_personal_event(target, today_number, work);
			target->setting_protect = 0;
		}
	}
	garr = 0;
	if(unit->race->type == RACE_LEADER) garr = 1;
	for(hand = unit->carrying; hand; hand = hand->next) {
		if(hand->item->item_type == ITEM_FOLLOWER &&
		   hand->amount &&
		   (hand->item->equip_bonus.missile || 
		    hand->item->equip_bonus.melee))
			garr = 1;
	}
	if(!garr) {
		if(unit->setting_guard) {
			sprintf(work, "Unable to continue guarding with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_guard = 0;
		}
		if(unit->setting_protect) {
			sprintf(work, "Unable to continue protecting access with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_protect = 0;
		}
	}
	return 1;
}


/**
 ** EXECUTE_GIVE
 **	Unit gives something to another unit. Both must be at the same location
 ** and the other must treat the first as friendly.
 **/
int execute_give(unit_s *unit, order_s *current)
{
unit_s	*recipient;
carry_s	*items;
carry_s	*handed;
item_s	*type;
int	garr;
int	given, kept;
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID ||
	    current->executing.types[1] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[2] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid GIVE order");
		order_is_error(unit, current);
		return 1;
	}
	recipient = current->arguments[0].unit;
	type = current->arguments[2].item;

	if(type->item_type > ITEM_ITEM) {
		unit_personal_event(unit, today_number, "Only physical items may be given");
		order_is_error(unit, current);
		return 1;
	}

	if (!may_interact_with(unit, recipient)) {
/*
 * Special: CLAIMS may give to their target
 */
		if (unit->race->type != 2 || unit->target.unit != recipient || type != item_cash)
			return 0;
	}

	if(recipient->is_captive)
		return 0;

/*
 * Validate item amounts
 */
	items = unit_possessions(unit, type, 0);
	if (!items)
		return 0;

	kept = 0;
	given = current->arguments[1].number;
	if (current->executing.types[3] == ARGUMENT_IS_NUMBER)
		kept = current->arguments[3].number;
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given+kept > items->amount)
		return 0;
	unit->sneaking = 0;
	current->considered = 1;
	if (attitude_vs(recipient->faction, unit) >= ATTITUDE_IS_NEUTRAL) {
		sprintf(work, "%s [%s] does not accept gifts", recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
		sprintf(work, "Refused gifts from %s [%s]", unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
		order_is_error(unit, current);
		return 1;
	}
/*
 * Carrying
 */
	handed = unit_possessions(recipient, type, 1);
	if (type == item_mana)
		given = 0;
	items->amount -= given;
	if (!unit->setting_silent && ((current->days >= 0) || !unit->setting_hushgive)) {
		sprintf(work, "Giving %d %s [%s] to %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, recipient->name, recipient->id.text);
		unit_personal_event(unit, today_number, work);
	}
	handed->amount += given;
	if (given && !recipient->setting_silent && ((current->days >=0) || !recipient->setting_hushgive)) {
		sprintf(work, "Received %d %s [%s] from %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text, unit->name, unit->id.text);
		unit_personal_event(recipient, today_number, work);
	}
	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(unit);
	}
	if(handed->equipped && handed->equipped < handed->item->equip_maximum) {
		if(handed->amount >= handed->item->equip_maximum)
			handed->equipped = handed->item->equip_maximum;
		else
			handed->equipped = handed->amount;
		compute_unit_stats(recipient);
	}
	order_was_executed(unit, current);
	garr = 0;
	if(unit->race->type == RACE_LEADER) garr = 1;
	for(handed = unit->carrying; handed; handed = handed->next) {
		if(handed->item->item_type == ITEM_FOLLOWER &&
		   handed->amount &&
		   (handed->item->equip_bonus.missile || 
		    handed->item->equip_bonus.melee))
			garr = 1;
	}
	if(!garr) {
		if(unit->setting_guard) {
			sprintf(work, "Unable to continue guarding with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_guard = 0;
		}
		if(unit->setting_protect) {
			sprintf(work, "Unable to continue protecting access with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_protect = 0;
		}
	}
	return 1;
}


/**
 ** EXECUTE_DROP
 **	Unit gives drops something.
 **/
int execute_drop(unit_s *unit, order_s *current)
{
carry_s	*items;
item_s	*type;
int	garr;
int	given, kept;
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER) {
		unit_personal_event(unit, today_number, "Invalid DROP order; missing amount");
		order_is_error(unit, current);
		return 1;
	}
	if (current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid DROP order; invalid tag");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Validate item amounts
 */
	type = current->arguments[1].item;
	items = unit_possessions(unit, type, 0);
	if (!items)
		return 0;
	given = current->arguments[0].number;
	kept = 0;
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
		kept = current->arguments[2].number;
	if (given == 0)
		given = items->amount - kept;
	if (given <= 0 || given > items->amount)
		return 0;
	current->considered = 1;
/*
 * Carrying
 */
	items->amount -= given;
	if (type == item_mana)
		given = 0;
	if (!unit->setting_silent) {
		sprintf(work, "Dropping %d %s [%s]", given, given > 1 ? type->plural : type->name,
				type->tag.text);
		unit_personal_event(unit, today_number, work);
	}

	if(items->item->unique) {
	    return_unique_item(items->item);
	}

	if (items->amount < items->equipped) {
		items->equipped = items->amount;
		compute_unit_stats(unit);
	}

	order_was_executed(unit, current);
	garr = 0;
	if(unit->race->type == RACE_LEADER) garr = 1;
	for(items= unit->carrying; items; items = items->next) {
		if(items->item->item_type == ITEM_FOLLOWER &&
		   items->amount &&
		   (items->item->equip_bonus.missile || 
		    items->item->equip_bonus.melee))
			garr = 1;
	}
	if(!garr) {
		if(unit->setting_guard) {
			sprintf(work, "Unable to continue guarding with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_guard = 0;
		}
		if(unit->setting_protect) {
			sprintf(work, "Unable to continue protecting access with no troops");
			unit_personal_event(unit, today_number, work);
			unit->setting_protect = 0;
		}
	}
	return 1;
}


/**
 ** EXECUTING_EQUIP
 **	The unit puts some equipment around
 **/
int execute_equip(unit_s *unit, order_s *current)
{
experience_s	*requirement;
carry_s		*owns, *others;
item_s		*item;
int		amount;
int		max;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid EQUIP order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Find out about the items
 */
	item = current->arguments[0].item;
	if (!item->equip_category) {
		sprintf(work, "INVALID EQUIP order; It is impossible to equip %s [%s]", item->name, item->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_error(unit, current);
		return 1;
	}
/*
 * Skill requirement?
 */
	if (item->equip_skill) {
		requirement = unit_experiences(unit, item->equip_skill, 0);
		if (!requirement || requirement->points == 0 || requirement->level < item->equip_level)
			return 0;
	}
/*
 * How many items
 */
	owns = unit_possessions(unit, item, 0);
	if (!owns || (amount = owns->amount) == 0)
		return 0;
/*
 * Increase equipment amount... Check maximas
 */
	max = item->equip_maximum;
	for (others = unit->carrying; others; others = others->next)
		if (others != owns && others->equipped && others->item->equip_category == item->equip_category) {
			sprintf(work, "%d %s [%s] automatically unequipped.",
					others->equipped,
					(others->equipped > 1 ? others->item->plural :
					 						others->item->name),
					others->item->tag.text);
			others->equipped = 0;
			unit_personal_event(unit, today_number, work);
		}
	if (amount > max)
		amount = max;
	if (amount < 0)
		amount = 0;
/*
 * Equipment change
 */
	if (amount != owns->equipped) {
		sprintf(work, "Now equipped %d %s [%s]", amount, amount > 1 ? item->plural : item->name, item->tag.text);
		unit_personal_event(unit, today_number, work);
		owns->equipped = amount;
/*
 * Combat items become the default action
 */
#ifdef ITEMS_USED_IN_BATTLE
		if (item->item_type == ITEM_ITEM && item->combat_action.effect && unit->combat[0].option == 0) {
			unit->combat[0].option = COMBAT_SET_ITEM;
			unit->combat[0].u.use_item = item;
			unit->combat[1].option = 0;
		}
#endif
		order_was_executed(unit, current);
	} else
		current->considered = 1;
	return 1;
}


/**
 ** EXECUTE_CAMP
 **	Create a camp. Camps will automagically execute USE
 **/
int execute_camp(unit_s *unit, order_s *current)
{
unit_s		*target;
item_s		*type;
carry_s		*has;
skill_s		*skill;
experience_s	*knows;
faction_s	*faction;
int		amount;
static terrain_s *mtow_cache;

	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if(unit->faction && unit->faction->resigned)
	    return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid CAMP order; missing unit ID");
		order_is_error(unit, current);
		return 1;
	}
	target = current->arguments[0].unit;
	if(unit->race->type != RACE_LEADER) {
	    unit_personal_event(unit, today_number, "Invalid CAMP order; Only leaders can form camps");
	    order_is_error(unit, current);
	    return 1;
	}
/*
 * Can recruit only once
 */
	if (target->size && !target->inactive)
		return execute_give(unit, current);
	faction = unit->faction;
	if (target->faction != faction) {
		unit_personal_event(unit, today_number, "Invalid CAMP order; can't establish camp for a different faction");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Must have followers
 */
	amount = current->arguments[1].number;
	if (current->executing.types[1] != ARGUMENT_IS_NUMBER || amount < 0) {
		unit_personal_event(unit, today_number, "Invalid CAMP order; invalid amount");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Which followers
 */
	type = current->arguments[2].item;
	if (current->executing.types[2] != ARGUMENT_IS_ITEM_TAG || type->item_type != ITEM_FOLLOWER) {
		unit_personal_event(unit, today_number, "Invalid CAMP order; invalid follower type");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Any skill?
 */
	skill = 0;
	if (current->executing.types[3] == ARGUMENT_IS_SKILL_TAG) {
		skill = current->arguments[3].skill;
		if (skill->end_product == 0 || skill->enhanced == 0) {
			unit_personal_event(unit, today_number, "Invalid CAMP order; not a follower producing skill");
			order_is_error(unit, current);
			return 1;
		}
		if(skill->type == 2 || skill->student) {
			unit_personal_event(unit, today_number, "Invalid CAMP order; camps may not cast magic");
			order_is_error(unit, current);
			return 1;
		}
	}
/*
 * Need the amount of followers, and the skill, if any
 */
	if ((has = unit_possessions(unit, type, 0)) == 0)
		return 0;
	if (amount == 0)
		amount = has->amount;
	if (amount == 0 || has->amount < amount)
		return 0;
	current->considered = 1;
	if (skill) {
		if ((knows = unit_experiences(unit, skill, 0)) == 0 || !knows->effective)
			return 0;
	}
/*
 * Do we have 1 free control point
 */
	if (faction->control_current >= faction->control_max)
		return 0;

/*
 * Ok, the camp is created
 */
	unit->sneaking = 0;
	assign_unit_id(target);
	sprintf(work, "Setting up camp [%s] with %d %s", target->id.text,
			amount, amount > 1 ? type->plural : type->name);
	unit_personal_event(unit, today_number, work);
	if(!target->disbanded) {
	    target->same_faction = faction->units;
	    faction->units = target;
	}
	if(unit->current->type == mtow_cache)
		move_to_location(target, unit->true_location);
	else
		move_to_location(target, unit->current);
	target->inactive = 0;
	target->dead = 0;
	target->full_day = 1;
	target->size = 1;
	target->disbanded = 0;
	faction->control_current++;
	target->race = camp_race;
	sprintf(work, "Set up by %s [%s]", unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
/*
 * Transfer followers and skill
 */
	has->amount -= amount;
	has = unit_possessions(target, type, 1);
	has->amount += amount;
	if (skill) {
		knows = unit_experiences(target, skill, 1);
		(void)add_to_experience(target, knows, skill, skill->for_level);
	}
/*
 * Order complete
 */
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_RECRUIT
 **	Recruiting draws a leader from the local population, if any
 **/
int execute_recruit(unit_s *unit, order_s *current)
{
unit_s		*target;
location_s	*here;
race_s		*race;
faction_s	*faction;
static terrain_s *mtow_cache;

        if(!mtow_cache) {
                synthetic_tag("mtow");
                mtow_cache = terrain_from_tag(0);
        }
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if(unit->faction && unit->faction->resigned)
	    return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order; missing unit ID");
		order_is_error(unit, current);
		return 1;
	}
	if(unit->race->type != RACE_LEADER) {
	    unit_personal_event(unit, today_number, "Invalid RECRUIT order; Only leaders can recruit");
	    order_is_error(unit, current);
	    return 1;
	}
	target = current->arguments[0].unit;
/*
 * Can recruit only once
 */
	if (target->size && !target->inactive) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order; unit is already active");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Can't recruit for a different faction
 */
	faction = unit->faction;
	if (target->faction != faction) {
		unit_personal_event(unit, today_number, "Invalid RECRUIT order; can't recruit for a different faction");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Where are we?
 */
	here = unit->true_location;
	current->considered = 1;
	if (!here->population || !(race = here->racial))
		return 0;
/*
 * Check CP cost
 */
	if (faction->control_current + race->intrinsic.control > faction->control_max)
		return 0;
	faction->control_current += race->intrinsic.control;
/*
 * Activate the unit
 */
	unit->sneaking = 0;
	assign_unit_id(target);
	sprintf(work, "Recruiting %s [%s]", race->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	if(!target->disbanded) {
		target->same_faction = faction->units;
		faction->units = target;
	}
	if(unit->current->type == mtow_cache)
		move_to_location(target, unit->true_location);
	else
		stack_under(unit, target);
	target->inactive = 0;
	target->dead = 0;
	target->full_day = 1;
	target->size = 1;
	target->disbanded = 0;
	target->race = race;
	sprintf(work, "Recruited by %s [%s]", unit->name, unit->id.text);
	unit_personal_event(target, today_number, work);
	compute_unit_stats(target);
/*
 * Order complete
 */
	order_was_executed(unit, current);
	unit->has_recruited = 1;
	return 1;
}


/**
 ** EXECUTE_OATHING_PROCESS
 **	A clan oaths to another
 **
 **/
void execute_oathing_process(unit_s *unit, int day, faction_s *vassal, faction_s *lord)
{
faction_s	*loop;
/*
 * Fix that
 */
	if (lord == vassal)
		lord = 0;
/*
 * Do we want to oath to someone who is our vassal?
 */
	if (lord) {
		for (loop = lord; loop; loop = loop->vassal_of)
			if (loop == vassal)
				break;
		if (loop) {
			if (unit)
				unit_personal_event(unit, day, "Cannot oath to our vassal");
			else
				faction_wide_event(vassal, day, "Cannot oath to our vassal");
			return;
		}
	}
/*
 * Were we oathed to someone?
 */
	if (vassal->vassal_of) {
		if (vassal->vassal_of == lord)
			return;	/* silly us */
		vassal->scratchpad[0] = 0;
		sprintf(work, "%s [%s] denounced its oath to us", vassal->name, vassal->id.text);
		faction_wide_event(vassal->vassal_of, day, work);
	}
	vassal->scratchpad[1] = 0;
/*
 * We are now oathed to someone
 */
	vassal->vassal_of = lord;
	if (lord) {
		sprintf(work, "%s [%s] oathed itself to our mighty clan", vassal->name, vassal->id.text);
		faction_wide_event(lord, day, work);
		sprintf(work, "Declaring oath to our new patron, %s [%s]", lord->name, lord->id.text);
	} else
		strcpy(work, "Denouncing all oaths");
	if (unit)
		unit_personal_event(unit, day, work);
	else
		faction_wide_event(vassal, day, work);
/*
 * Recompute all the control costs
 */
	/*compute_control_points();
	special_adjust_faction();*/
}


/**
 ** EXECUTING_OATH
 **	The unit is attempting to oath
 **/
int execute_oath(unit_s *unit, order_s *current)
{
faction_s	*faction;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_FACTION_ID) {
		unit_personal_event(unit, today_number, "Invalid OATH order; missing clan ID");
		order_is_error(unit, current);
		return 1;
	}
	current->considered = 1;
	if (unit->faction->scratchpad[1] == 0)
		return 0;
	faction = current->arguments[0].faction;
	if (faction->npc) {
		unit_personal_event(unit, today_number, "Invalid OATH order; cannot oath to NPCs");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Ok, oath now
 */
	unit->sneaking = 0;
	execute_oathing_process(unit, today_number, unit->faction, faction);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** ANY_FORGOTTEN
 **	Forget the specified skill. Recursively, if we have dependent skills
 **/
static int any_forgotten(unit_s *unit, skill_s *skill)
{
experience_s	*exp;
int		controls;
#ifdef USES_REQUIRED_LEVELS
skill_s		*depend;
#endif
/*
 * Do!
 */
	exp = unit_experiences(unit, skill, 0);
	if (!exp || exp->points <= 0)
		return 0;
	sprintf(work, "All knowledge about %s [%s] forgotten.", skill->name,
		skill->tag.text);
	unit_personal_event(unit, today_number, work);
	exp->points = 0;
	exp->effective = 0;
	controls = 0;
	controls = skill->bonus.control;
	exp->level = 0;
	for (depend = skills_list; depend; depend = depend->next)
		if (depend->required_skill == skill)
			controls += any_forgotten(unit, depend);
	return controls;
}


/**
 ** EXECUTE_FORGET
 **	Unit wants to forget a skill.
 **/
int execute_forget(unit_s *unit, order_s *current)
{
int	controls;
/*
 * Invalid argument? Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid FORGET order");
		order_is_error(unit, current);
		return 1;
	}
	if(unit->race->type != RACE_LEADER) {
	    unit_personal_event(unit, today_number, "Invalid FORGET order; Only leaders can forget skills");
	    order_is_error(unit, current);
	    return 1;
	}
/*
 * Get the experience
 */
	current->considered = 1;
	controls = any_forgotten(unit, current->arguments[0].skill);
	order_is_complete(unit, current);
	if (controls) {
		unit->faction->control_current -= controls;
	}
	return 1;
}


/**
 ** EXECUTING_STACK
 **	The unit is attempting to enter the stack
 **/
int execute_stack(unit_s *unit, order_s *current)
{
unit_s	*target;
unit_s	*leader;
order_s	*accepting;
static terrain_s *mtow_cache;

	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID)
		return execute_unstack(unit, current);
	if(unit->race->type != RACE_LEADER) {
	    unit_personal_event(unit, today_number, "Invalid STACK order; Only leaders can stack");
	    order_is_error(unit, current);
	    return 1;
	}
/*
 * To execute, we must be at the same location
 */
	target = current->arguments[0].unit;
	if (!may_interact_with(unit, target))
		return 0;
	if (unit->leader == target) {
		sprintf(work, "Already stacked under %s [%s]'s leadership", target->name, target->id.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 1;
	}
	unit->sneaking = 0;

	/*
	 * If the new leader is in a mage tower and we are not a mage do not
	 * allow the stacking
	 */
	if(target->current->type == mtow_cache) {
		experience_s *exp = unit_experiences(unit, magecraft, 0);
		if(!exp) {
			unit_personal_event(unit, today_number,
					"You may not stack under a mage in a mage tower unless you are a mage.");
			return 0;
		}
	}

/*
 * If new leader is already stacked beneath us, unstack the leader first!
 */
	for (leader = target->leader; leader; leader = leader->leader)
		if (leader == unit)
			break;
	if (leader) {
		sprintf(work, "%s [%s] unstacks to allow stack swapping", target->name, target->id.text);
		(void)execute_unstack(target, 0);
	}
/*
 * The leader must accept us
 */
	if (target->faction != unit->faction) {
		if (attitude_vs(target->faction, unit) > ATTITUDE_IS_ALLY) {
			for (accepting = target->orders; accepting; accepting = accepting->next)
				if (accepting->executing.routine == execute_accept &&
				    !accepting->conditional && accepting->arguments[0].unit == unit)
					break;
			if (!accepting) {
				sprintf(work, "%s [%s] tried to stack beneath you!", unit->name, unit->id.text);
				unit_personal_event(target, today_number, work);
				sprintf(work, "%s [%s] will not lead you", target->name, target->id.text);
				unit_personal_event(unit, today_number, work);
				order_is_error(unit, current);
				return 1;
			}
			order_is_complete(target, accepting);
		}
	}
/*
 * Unstack first
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s executes STACK %s\n", unit->id.text, target->id.text);
#endif
	if (unit->leader) {
		sprintf(work, "%s [%s] first unstacks", unit->name, unit->id.text);
		(void)execute_unstack(unit, 0);
	}
	stack_under(target, unit);
	sprintf(work, "%s [%s] stacks under %s [%s]", unit->name, unit->id.text,
				target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTING_LEAVE
 **	The unit is attempting to get out of the location
 **/
int execute_leave(unit_s *unit, order_s *current)
{
	if (unit->is_captive)
		return 0;
	if(!unit->current)
		return 0;

	if (unit->current->type->type == TERRAIN_STRUCTURE) {
		if (current)
			current->considered = 1;
		unstack_stays(unit->stack);
		sprintf(work, "%s [%s] leaves %s [%s]", unit->name, unit->id.text,
					unit->current->name, unit->current->id.text);
		unit_personal_event(unit, today_number, work);
		if(!unit->sneaking)
			location_global_event(unit, today_number, work);
		move_to_location(unit, unit->current->outer);
		if (current)
			order_is_complete(unit, current);
		unit->setting_protect = 0;
		return 1;
	}
	return 0;
}


/**
 ** EXECUTING_ENTER
 **	The unit is attempting to move into a location.
 **/
int execute_enter(unit_s *unit, order_s *current)
{
location_s	*entering;
direction_s	*direction;
unit_s		*guard;
experience_s	*exp;
static terrain_s *mtow_cache;

	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid ENTER order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Special case: "enter" outward location
 */
	if (unit->true_location == current->arguments[0].location &&
	    unit->true_location != unit->current)
		return execute_leave(unit, current);
/*
 * Search thru inner locations
 */
	for (entering = unit->true_location->inner; entering; entering = entering->next_inner)
		if (entering == current->arguments[0].location &&
		    entering->type->type == TERRAIN_STRUCTURE) {
			current->considered = 1;
			if (entering->partial)
				return 0;
/*
 * Guards may prevent entering, unless you are the holder of the title!
 */
			if ((guard = entering->present) &&
			    guard->setting_protect &&
			    !unit->sneaking &&
			    attitude_vs_faction(guard->faction, unit->faction) > ATTITUDE_IS_NEUTRAL) {
				sprintf(work, "%s [%s] prevents you from entering %s [%s]", guard->name, guard->id.text,
						entering->name, entering->id.text);
				unit_personal_event(unit, today_number, work);
				sprintf(work, "%s [%s] attempted to enter", unit->name, unit->id.text);
				unit_personal_event(guard, today_number, work);
				order_is_error(unit, current);
				return 1;
			}

			/* Check building preconditions */
			if(entering->type == mtow_cache) {
				exp = unit_experiences(unit, magecraft, 0);
				if(!exp) {
					unit_personal_event(unit, today_number, "Only mages may enter a magic tower.");
					order_is_complete(unit, current);
					return 1;
				}
				unstack_nonmages(unit->stack);
			}
/*
 * Enter occurs
 */
			unstack_stays(unit->stack);
			sprintf(work, "%s [%s] enters %s [%s]", unit->name, unit->id.text,
					entering->name, entering->id.text);
			unit_personal_event(unit, today_number, work);
			if(!unit->sneaking)
				location_global_event(unit, today_number, work);
			unit->setting_protect = 0;
			move_to_location(unit, entering);
			order_is_complete(unit, current);
			return 1;
		}
/*
 * Special 0-day movement
 */
	for (direction = unit->true_location->exits; direction; direction = direction->next)
		if (direction->days == 0 &&
		    direction->toward == current->arguments[0].location) {
			current->considered = 1;
			sprintf(work, "%s [%s] departs", unit->name, unit->id.text);
			if(!unit->sneaking)
				location_global_event(unit, today_number, work);
			move_to_location(unit, direction->toward);
			sprintf(work, "%s [%s] arrives at %s [%s]", unit->name, unit->id.text,
					direction->toward->name, direction->toward->id.text);
			unit_personal_event(unit, today_number, work);
			if(!unit->sneaking)
				location_global_event(unit, today_number, work);
			order_is_complete(unit, current);
			return 1;
		}
	return 0;
}


/**
 ** NAME_CLEANUP
 **	Cut any spurious characters from names.
 **/
static void name_cleanup(char *name)
{
	while (*name) {
                unsigned char t = *name;
		switch (*name) {
		    case '[':
		    case ']':
		    case ';':
		    case ':':
		    case ',':
			*name = ' ';
		}
		if (t < 32 || t > 128)
			*name = ' ';
		name++;
	}
}


/**
 ** EXECUTING_CHRISTEN
 **	The unit is attempting to rename a location
 **/
int execute_christen(unit_s *unit, order_s *current)
{
location_s	*local;
char		*name;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Invalid CHRISTEN order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Make sure name is ok
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
/*
 * Valid
 */
	local = unit->current;
	if (local->present == unit) {
		if (local->type->type != TERRAIN_STRUCTURE && strcasecmp(local->name, local->type->name)) {
			unit_personal_event(unit, today_number, "Location already has a name");
			order_is_complete(unit, current);
			return 1;
		}
		unit->sneaking = 0;
		current->considered = 1;
		sprintf(work, "%s [%s] christen %s as %s", unit->name, unit->id.text,
					local->id.text, name);
		unit_personal_event(unit, today_number, work);
		location_global_event(unit, today_number, work);
		free(local->name);
		local->name = name;
		order_is_complete(unit, current);
		return 1;
	}
	return 0;
}


/**
 ** EXECUTE_DESCRIBE
 **	Unit changes its description
 **/
int execute_describe(unit_s *unit, order_s *current)
{
char	*name;
/*
 * Invalid argument? Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Removed description");
		if (unit->description) {
			free(unit->description);
			unit->description = 0;
		}
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Do it quick
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
	if (unit->description)
		free(unit->description);
	unit->description = name;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_NAME
 **	Unit changes its name
 **/
int execute_name(unit_s *unit, order_s *current)
{
char	*name;
/*
 * Invalid argument? Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_STRING) {
		unit_personal_event(unit, today_number, "Invalid NAME order");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Do it quick
 */
	name = current->arguments[0].string;
	name_cleanup(name);
	if (!*name) {
		current->executing.types[0] = ARGUMENT_IS_EMPTY;
		return 0;
	}
	free(unit->name);
	unit->name = name;
	order_is_complete(unit, current);
	return 1;
}


/**
 ** EXECUTE_BUY
 **	Unit wants to buy.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed! Furthermore, buy occurs only
 ** during market day.
 **/
int execute_buy(unit_s *unit, order_s *current)
{
market_s	*possible;
request_s	*pending;
int		price, amount, tamount;
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid BUY order");
		order_is_error(unit, current);
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid BUY order; Only leaders may BUY");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Occur only if market present
 */
	if (!unit->true_location->first_market)
		return 0;
/*
 * Validate elements
 */
	amount = current->arguments[0].number;
/*
 * Process a request only once
 */
	current->considered = 1;
	for (possible = unit->true_location->markets; possible; possible = possible->next)
		if (possible->type == current->arguments[1].item)
			break;
	if (!possible)
		possible = new_market_at_location(unit->true_location, current->arguments[1].item);
/*
 * Must be allowed
 */
	unit->sneaking = 0;
	if (unit->true_location->type != neutral_city && guarded_against_activity(unit, unit->true_location, ATTITUDE_IS_NEUTRAL)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent buying");
		return 0;
	}
/*
 * BUY is tentative...
 */
	if (unit->coins == 0)
		unit->coins = unit_possessions(unit, item_cash, 1);
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
		price = current->arguments[2].number;
	else
		price = 0;
	if (price <= 0)
		price = possible->offered.negociated_price;
	if (price <= 0)
		return 0;
	if (amount == 0) {
		tamount = -1;
		amount = unit->coins->amount / price;
	} else {
		tamount = amount;
	}
	if (amount) {
		pending = new_request_instance();
		pending->validated_order = current;
		pending->asked = unit;
		pending->price = price;
		pending->amount = tamount;
		pending->next = possible->offered.shopping;
		possible->offered.shopping = pending;
		unit->has_recruited = 1;
	}
/*
 * Offer recorded
 */
	return 1;
}


/**
 ** EXECUTE_SELL
 **	Unit wants to sell.
 ** Recruit/Sell/Buy are specials: they occur only on markets, and are executed only
 ** after all immediate orders have executed! Furthermore, sell occurs only
 ** during market day.
 **/
int execute_sell(unit_s *unit, order_s *current)
{
market_s	*possible;
request_s	*pending;
carry_s		*owns;
int		price, amount;
/*
 * Validate arguments
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_NUMBER ||
	    current->executing.types[1] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid SELL order");
		order_is_error(unit, current);
		return 1;
	}
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid SELL order; Only leaders may SELL");
		order_is_error(unit, current);
		return 1;
	}
/*
 * Occur on correct day
 */
	if (!unit->true_location->first_market)
		return 0;
	owns = unit_possessions(unit, current->arguments[1].item, 0);
	if (!owns || owns->amount == 0)
		return 0;
/*
 * Must be allowed
 */
	unit->sneaking = 0;
	current->considered = 1;
	if (unit->true_location->type != neutral_city && guarded_against_activity(unit, unit->true_location, ATTITUDE_IS_NEUTRAL)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent selling");
		return 0;
	}
/*
 * Validate elements
 */
	amount = current->arguments[0].number;
	if (!amount)
		amount = owns->amount;
/*
 * Process a request only once
 */
	for (possible = unit->true_location->markets; possible; possible = possible->next)
		if (possible->type == current->arguments[1].item)
			break;
	if (!possible)
		possible = new_market_at_location(unit->true_location, current->arguments[1].item);
/*
 * SELL is tentative...
 */
	if (unit->coins == 0)
		unit->coins = unit_possessions(unit, item_cash, 1);
	if (current->executing.types[2] == ARGUMENT_IS_NUMBER)
		price = current->arguments[2].number;
	else
		price = 0;
	if (price <= 0)
		price = possible->wanted.negociated_price;
	if (price <= 0)
		price = 9999999;
	if (amount == 0)
		amount = unit->coins->amount / price;
	if (amount) {
		pending = new_request_instance();
		pending->validated_order = current;
		pending->asked = unit;
		pending->price = price;
		pending->amount = amount;
		pending->next = possible->wanted.shopping;
		possible->wanted.shopping = pending;
		unit->has_recruited = 1;
	}
/*
 * Offer recorded
 */
	return 1;
}


/**
 ** DO_THE_MOVE
 **	Start the movement
 **/
static int do_the_move(unit_s *unit, location_s *toward, direction_s *dir, int march)
{
experience_s	*scouts;
int		mode;
char		best_mode, best_time;
char		durations[MAX_MOVE_MODES];
/*
 * Last minute check
 */
	if (unit->race->type != RACE_LEADER) {
		return 0;
	}
	if(unit->wants_stay) {
		unit_personal_event(unit, today_number, "Movement prohibited while a STAY order is in effect.");
		return 0;

	}
	if (unit->has_recruited) {
		unit_personal_event(unit, today_number, "Movement prohibited while shopping");
		return 0;
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s [%s] attempts to move to %s\n", unit->name, unit->id.text, toward->id.text);
#endif
	unstack_stays(unit->stack);
/*
 * How long to move toward that?
 */
	for (mode = 0; mode < MAX_MOVE_MODES; mode++) {
		durations[mode] = 0;
		if (!dir)
			durations[mode] = 1;
		else {
			if(dir->days < 0) {
				durations[mode] = 0;
				continue;
			}
			if (dir->mode) {
				if (mode == dir->mode)
					durations[mode] = dir->days;
				else
					if (mode == 2 && dir->mode == 3)
						durations[mode] = (dir->days + 1)/ 2;
					else
						durations[mode] = 0;
			} else {
				switch (mode) {
				    case 0:
					durations[mode] = dir->days;
					break;
				    case 1:
					durations[mode] = (dir->days + 1)/ 2;
					break;
				    case 2:
					durations[mode] = (dir->days + 2)/ 3;
					break;
				}
			}
		}
	}
/*
 * Capacity plays a role!
 */
	compute_stack_capacity(unit);
	for (mode = 0; mode < MAX_MOVE_MODES; mode++)
		if (unit->stack_capacity[mode] < unit->stack_weight)
			durations[mode] = 0;
/*
 * Apply skill criteria:
 *	Uncovered locations and mundane skill: modes 0,1,3 forbidden
 *	Covered locations or magical skill: all modes forbidden
 */
	if (dir && dir->skill) {
		scouts = unit_experiences(unit, dir->skill, 0);
#ifdef USES_SKILL_LEVELS
		if (!scouts || scouts->level < dir->level) {
#else
		if (!scouts || !scouts->effective) {
#endif
			durations[0] = 0;
			durations[1] = 0;
			durations[3] = 0;
			if (toward->outer || dir->skill->type == 2)
				durations[2] = 0;
			if (dir->skill->required_skill == magecraft)
				durations[2] = 0;
		}
	}
/*
 * What mode will we have?
 */
	best_mode = -1;
	best_time = 99;
	for (mode = 0; mode < MAX_MOVE_MODES; mode++)
		if (durations[mode] &&
		    durations[mode] < best_time) {
			best_time = durations[mode];
			best_mode = mode;
		}
/*
 * Did we find a mode?
 */
	if (best_mode < 0) {
		unit_personal_event(unit, today_number, "Unit unable to move due to capacity or exit restrictions.");
		return 0;
	}
/*
 * YESSSS! We move!
 */
	if (unit->leader) {
		sprintf(work, "%s [%s] unstacks to move", unit->name, unit->id.text);
		(void)execute_unstack(unit, 0);
	}
	unit->toward = toward;
	unit->move_for_days = best_time;
	unit->moving_by = best_mode;
	unit->already_moved = 0;
	set_stack_movement(unit, 1+march);
	unit->executing = 0;
	if (dir)
		sprintf(work, "%s [%s] departs %s to %s [%s]", unit->name, unit->id.text, dir->name,
			toward->name, toward->id.text);
	else
		sprintf(work, "%s [%s] departs to %s [%s]", unit->name, unit->id.text,
			toward->name, toward->id.text);
	if(!unit->sneaking)
		location_global_event(unit, today_number, work);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "Movement will take %d days", best_time);
	if (best_time > 1)
		unit_personal_event(unit, today_number, work);
/*
 * Now, finish this day's movement!
 */
	unit->full_day = 1;

/* 
 * Okay.. We can move, update our ability to sneak flag
 */
	if(unit->no_sneak) {
		if(toward != unit->current &&
                   toward != unit->true_location &&
                   toward->outer != unit->true_location) {
			unit->no_sneak = 0;
		}	
        }
	execute_movement_advances(unit);
	return 1;
}


/**
 ** EXECUTING_MOVE
 **	The unit is attempting to move.
 **/
int execute_move(unit_s *unit, order_s *current)
{
location_s	*here, *toward;
location_s	*inner;
terrain_s	*desired;
direction_s	*dir;
char		*direction;
int		march;
/*
 * Validity
 */
	if (unit->is_guarding)
		return 0;
	if (unit->is_captive)
		return 0;
	if (current->executing.routine == execute_move)
		march = 0;
	else
		march = 1;
	dir = 0;
	here = unit->true_location;
	switch (current->executing.types[0]) {
	    case ARGUMENT_IS_LOCATION_ID:
		toward = current->arguments[0].location;
		for (dir = here->exits; dir; dir = dir->next)
			if (dir->toward == toward)
				break;
		if (!dir) {
			if (toward == here->outer)
				break;
			if(toward == unit->current->outer)
				break;
			for (inner = here->inner; inner; inner = inner->next_inner)
				if (inner == toward)
					break;
			if (!inner) {
/*
 * Special. Maybe we forgot "MOVE OUT"?
 */
				if ((inner = here->outer) == 0)
					return 0;
				for (dir = inner->exits; dir; dir = dir->next)
					if (dir->toward == toward)
						break;
				if (!dir)
					return 0;
/*
 * We did. Fake MOVE OUT
 */
				if(!do_the_move(unit, inner, 0, march))
					return 0;
				/* check if the unit moved */
				if(unit->true_location != inner) {
					if (current->executing.routine && current->days >= 0)
						order_is_complete(unit, current);
					unit->executing = 0;
					return 0;
				}
			}
		}
		break;
/*
 * Move toward a certain terrain type
 */
	    case ARGUMENT_IS_TERRAIN_TAG:
		desired = current->arguments[0].terrain;
		for (dir = here->exits; dir; dir = dir->next)
			if ((toward = dir->toward)->type == desired)
				break;
		if (!dir) {
			if ((toward = here->outer) != 0 && desired == toward->type)
				break;
			for (toward = here->inner; toward; toward = toward->next_inner)
				if (desired == toward->type)
					break;
			if (!toward)
				return 0;
		}
		break;
/*
 * Move toward a certain direction name
 */
	    case ARGUMENT_IS_STRING:
		direction = current->arguments[0].string;
/*
 * Special case: MOVE OUT
 */
		if (strcasecmp(direction, "OUT") == 0) {
			if (here->outer != 0) {
				toward = here->outer;
				break;
			}
		}
/*
 * Special case: MOVE IN
 */
		if (strcasecmp(direction, "IN") == 0) {
			for (inner = here->inner; inner; inner = inner->next_inner)
				if (inner->type->type == TERRAIN_INNER)
					break;
			if (inner) {
				toward = inner;
				break;
			}
		}
/*
 * Special case: MOVE RANDOM
 */
		if (strcasecmp(direction, "RANDOM") == 0) {
printf("somebody moved at random!\n");
		}
/*
 * Direction is full direction or terrain type?
 */
		for (dir = here->exits; dir; dir = dir->next)
			if (strcasecmp(dir->name, direction) == 0)
				break;
		if (!dir)
			for (dir = here->exits; dir; dir = dir->next)
				if (abbreviated_keyword(dir->name, direction))
					break;
/*
 * Maybe we forgot to move out first?
 */
		if (!dir) {
			if ((inner = here->outer) == 0)
				return 0;
			for (dir = inner->exits; dir; dir = dir->next)
				if (strcasecmp(dir->name, direction) == 0)
					break;
			if (!dir)
				for (dir = inner->exits; dir; dir = dir->next)
					if (abbreviated_keyword(dir->name, direction))
						break;
			if (!dir)
				return 0;
			if(!do_the_move(unit, inner, 0, march))
				return 0;
			if(unit->true_location != inner) {
				if (current->executing.routine && current->days >= 0)
					order_is_complete(unit, current);
				unit->executing = 0;
				return 0;
			}
		}
		toward = dir->toward;
		break;
/*
 * Invalid arguments. Delete the order
 */
	    default:
		unit_personal_event(unit, today_number, "Invalid MOVE order");
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Now, execute a movement
 */
	if (!do_the_move(unit, toward, dir, march))
		return 0;
	if (current->executing.routine && current->days >= 0)
		order_is_complete(unit, current);
	unit->executing = 0;
	return 1;
}
int execute_march(unit_s *unit, order_s *current)
{
	return execute_move(unit,current);
}


/**
 ** EXECUTING_CARAVAN
 **	The unit is moving along a regular route
 **/
int execute_caravan(unit_s *unit, order_s *current)
{
location_s	*toward, *inner;
direction_s	*dir;
t_argument	swapped[MAX_ORDER_ARGUMENTS];
int		j, n;
/*
 * Validity
 */
	if (unit->is_guarding)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID ||
	    current->executing.types[1] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid CARAVAN, require at least two locations");
		order_is_error(unit, current);
		return 0;
	}
/*
 * Search for original location
 */
	for (n = 0; n < MAX_ORDER_ARGUMENTS-1; n++)
		if (current->executing.types[n] != ARGUMENT_IS_LOCATION_ID) {
			unit_personal_event(unit, today_number, "CARAVAN outside of normal route!");
			return 0;
		} else
			if (current->arguments[n].location == unit->true_location)
				break;
/*
 * We've found a location. End of caravaning map? Reverse the caravan and execute
 */
	if (current->executing.types[n+1] != ARGUMENT_IS_LOCATION_ID) {
		if (current->days == 0 || current->days == 1) {
			order_is_complete(unit, current);
			return 0;
		}
		for (j = 0; j <= n; j++)
			swapped[n-j].location = current->arguments[j].location;
		swapped[++n].number = 0;
		memcpy(current->arguments, swapped, sizeof(current->arguments));
		if (current->days > 0)
			current->days--;
/*
 * We are now on position 0 (previously n-1), moving toward position 1 (previously n)
 */
		unit_personal_event(unit, today_number, "End of caravan route, turning back");
		n = 1;
	} else {
		n++;
	}
/*
 * Direction is found?
 */
	toward = current->arguments[n].location;
	for (dir = unit->true_location->exits; dir; dir = dir->next)
		if (dir->toward == toward)
			break;
	if (dir == 0 && toward != unit->true_location->outer) {
		for (inner = unit->true_location->inner; inner; inner = inner->next_inner)
			if (inner == toward)
				break;
		if (inner == 0) {
			unit_personal_event(unit, today_number, "CARAVAN next step isn't there!");
			order_is_error(unit, current);
			return 1;
		}
	}
/*
 * Now, execute a movement
 */
	return do_the_move(unit, toward, dir, 0);
}


/**
 ** EXECUTING_RESEARCH
 **	Unit attempts to divine skills
 **/
int execute_research(unit_s *unit, order_s *current)
{
experience_s	*found;
experience_s *ded;
carry_s		*days, *owns;
skill_s		*extra_hint, *arcane, *success, *tskill;
item_s		*reagent, *target_i;
consume_s	*component;
int		roll, r, saved_trace,
		difficulty, best,
		distance = 0, match = 0, fitness = 0;
char		dedicated;
char		element,
		ritual,
		flags;
/*
 * Validate argument
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_ENUM_0) {
		unit_personal_event(unit, today_number, "Invalid RESEARCH order; not an element");
		order_is_error(unit, current);
		return 0;
	}
	if (current->executing.types[1] != ARGUMENT_IS_ENUM_1) {
		unit_personal_event(unit, today_number, "Invalid RESEARCH order; not a ritual");
		order_is_error(unit, current);
		return 0;
	}
	if (current->executing.types[2] != ARGUMENT_IS_ITEM_TAG) {
		unit_personal_event(unit, today_number, "Invalid RESEARCH order; not a reagent");
		order_is_error(unit, current);
		return 0;
	}
	if (current->executing.types[3] == 0) {
		unit_personal_event(unit, today_number, "Invalid RESEARCH order; not a target");
		order_is_error(unit, current);
		return 0;
	}
	reagent =  current->arguments[2].item;
	if (reagent != item_mana && reagent->item_category < 2) { 
		unit_personal_event(unit, today_number, "Invalid RESEARCH order; not a valid reagent");
		order_is_error(unit, current);
		return 0;
	}
/*
 * Find our dedication. Until dedicated, RESEARCH is skipped
 */
	for (found = unit->skilled; found; found = found->next)
		if (found->effective && found->skill->student &&
				found->skill->required_skill == magecraft)
			break;
	if (!found)
		return 0;
	dedicated = found->skill->student;
	ded = found;
/*
 * Already dedicated
 */
	days = unit_possessions(unit, item_mstudy, 1);
	if (unit->executing != current) {
		unit_personal_event(unit, today_number, "Now buries itself into arcane research");
		if (today_number > 1)
			days->amount /= 2;
		unit->executing = current;
	}

/*
 * Now roll for success
 */
	days->amount++;
	if (unit->traced_unit) {
		printf("%s [%s] researching with %d days of research.\n",
				unit->name, unit->id.text, days->amount);
	}

	r = roll_1Dx(100);
	roll = days->amount - r;

	if(unit->traced_unit) {
		printf("Research roll was %d (days-roll) (d100 roll was %d)\n", roll, r);
	}

	unit->full_day = 1;
/*
 * What are we researching?
 */
	element =  current->arguments[0].number + 1;
	ritual  = (current->arguments[1].number + 1) * 8;
	if (current->executing.types[4] == ARGUMENT_IS_SKILL_TAG)
		extra_hint = current->arguments[4].skill;
	else
		extra_hint = 0;
/*
 * Loop on all skills
 */
	success = 0;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s [%s] attempts to research\n", unit->name, unit->id.text);
#endif

	saved_trace = unit->traced_unit;

	for (arcane = skills_list; arcane; arcane = arcane->next) {

		if(extra_hint) {
			unit->traced_unit = 0;
			if(arcane == extra_hint) {
				unit->traced_unit = saved_trace;
			}
		}

		if (arcane->student != dedicated)
			continue;
		if ((found = unit_experiences(unit, arcane, 0)) != 0 && found->points != 0)
			continue;
/*
 * A skill of our dedication that we do not know!!! Measure difficulty
 */
		difficulty = roll;
		flags = arcane->flags & 0x7;
/*
 * First part is the element
 */
		if(unit->traced_unit) {
			printf("Element selected was %d (%s), Spell is %d (%s)\n",
					element, visual_enum(element-1, order_enum_0),
					flags, visual_enum(flags-1, order_enum_0));
		}
		if (element == flags) {
			difficulty++;
			if(unit->traced_unit) {
				printf("Correct element -1 difficulty (%s) (D=%+d)\n",
						visual_enum(element-1, order_enum_0), difficulty);
			}
		} else {
			switch (element) {
				case 1:
					if (flags == 2 || flags == 4) {
						difficulty -= 8;
						r = 8;
					} else {
						difficulty -= 2;
						r = 2;
					}
					break;
				case 2:
					if (flags == 1 || flags == 5) {
						difficulty -= 8;
						r = 8;
					} else {
						difficulty -= 2;
						r = 2;
					}
					break;
				case 3:
					if (flags == 4 || flags == 5) {
						difficulty -= 8;
						r = 8;
					} else {
						difficulty -= 2;
						r = 2;
					}
					break;
				case 4:
					if (flags == 1 || flags == 3) {
						difficulty -= 8;
						r = 8;
					} else {
						difficulty -= 2;
						r = 2;
					}
					break;
				case 5:
					if (flags == 2 || flags == 3) {
						difficulty -= 8;
						r = 8;
					} else {
						difficulty -= 2;
						r = 2;
					}
					break;
			}
			if(unit->traced_unit) {
				printf("%s element +%d difficulty (%s vs %s) (D=%+d)\n",
						(r == 2 ? "Allied" : "Opposed"), r,
						visual_enum(element-1, order_enum_0),
						visual_enum(flags-1, order_enum_0), difficulty);
			}
		}

		if(unit->traced_unit) {
			printf("Favored element was %d (%s), Spell is %d (%s)\n",
					dedicated, visual_enum(dedicated-1, order_enum_0),
					flags, visual_enum(flags-1, order_enum_0));
		}
		if (flags == dedicated) {
			difficulty++;
			if(unit->traced_unit) {
				printf("Favored element -1 difficulty (%s) (D=%+d)\n",
						visual_enum(flags, order_enum_0), difficulty);
			}
		} else {
			r = 0;
			switch (flags) {
			    case 1:
					if (flags == 2 || flags == 4) {
						difficulty -= 3;
						r = 3;
					}
					break;
				case 2:
					if (flags == 1 || flags == 5) {
						difficulty -= 3;
						r = 3;
					}
					break;
			    case 3:
					if (flags == 4 || flags == 5) {
						difficulty -= 3;
						r = 3;
					}
					break;
			    case 4:
					if (flags == 1 || flags == 3) {
						difficulty -= 3;
						r = 3;
					}
					break;
			    case 5:
					if (flags == 2 || flags == 3) {
						difficulty -= 3;
						r = 3;
					}
					break;
			}
			if(unit->traced_unit) {
				printf("%s element of school +%d difficulty (%s vs %s) (D=%+d)\n",
						(r == 0 ? "Allied" : "Opposed"), r,
						visual_enum(dedicated-1, order_enum_0),
						visual_enum(flags-1, order_enum_0), difficulty);
			}
		}
/*
 * The ritual
 */
		flags = arcane->flags & 0x38;

		if(unit->traced_unit) {
			printf("Ritual was %d (%s), Spell is %d (%s)\n",
					(ritual/8), visual_enum(ritual/8, order_enum_1),
					flags/8, visual_enum(flags/8, order_enum_1));
		}

		if (ritual == flags) {
			difficulty += 2;
			if(unit->traced_unit) {
				printf("Matched ritual -2 difficulty (%s) (D=%+d)\n",
						visual_enum(flags/8, order_enum_1), difficulty);
			}
		} else {
			difficulty -= 8;
			if(unit->traced_unit) {
				printf("Different ritual +8 difficulty (%s vs %s) (D=%+d)\n",
						visual_enum(ritual/8, order_enum_1),
						visual_enum(flags/8, order_enum_1), difficulty);
			}
		}

		r = 0;
		switch (dedicated) {
		    case 1:
				if (flags == 0x18 || flags == 0x20) {
					difficulty++;
					r = 1;
				}
				break;
		    case 2:
				if (flags == 0x08 || flags == 0x10 || flags == 0x18) {
					difficulty++;
					r = 1;
				}
				break;
		    case 3:
				if (flags == 0x10) {
					difficulty++;
					r = 1;
				}
				break;
		    case 4:
				if (flags == 0x10 || flags == 0x28) {
					difficulty++;
					r = 1;
				}
				break;
		    case 5:
				if (flags == 0x10 || flags == 0x20 || flags == 0x28) {
					difficulty++;
					r = 1;
				}
				break;
		}
		if(unit->traced_unit && r) {
			printf("Favored ritual -1 difficulty (%s) (D=%+d)\n",
					visual_enum(flags/8, order_enum_1), difficulty);
		}
/*
 * Reagent. Here, we need the best match.
 */
		best = -10;
		for (component = arcane->use_consumes; component;
				component = component->next) {
			if (component->what == reagent) {
				best = 1;
				continue;
			}
			if (component->what == item_mana)
				continue;
			if ((owns = unit_possessions(unit, component->what, 0)) != 0 &&
					owns->amount) {
				difficulty++;
				if(unit->traced_unit) {
					printf("%s [%s] carrying %s [%s] (-1 difficulty) (D=%+d)\n",
							unit->name, unit->id.text, component->what->name,
							component->what->tag.text, difficulty);
				}
			}
			if (component->what->item_category == reagent->item_category) {
				if (best < -2)
					best = -2;
				if (reagent->item_type == ITEM_TOKEN)
					best = -1;
				continue;
			}
			if ((component->what->item_category|1) == (reagent->item_category|1)) {
				if (best < -6)
					best = -6;
				continue;
			}
		}
		difficulty += best;
		if(unit->traced_unit) {
			printf("Difficulty modification for components is %+d (D=%+d)\n",
					-best, difficulty);
		}
/*
 * Mana levels
 */
		for (component = arcane->use_consumes; component;
				component = component->next) {
			if (component->what == item_mana) {
				difficulty += unit->vital.mana - component->amount;
				if(unit->traced_unit) {
					printf("Difficulty for mana is %+d (vital mana is %d) (D=%+d)\n",
							-(unit->vital.mana - component->amount),
							unit->vital.mana, difficulty);
				}
				break;
			}
		}
/*
 * Final target...
 */
		switch (current->executing.types[3]) {
		    case ARGUMENT_IS_ITEM_TAG:
				target_i = current->arguments[3].item;
				best = -10;
				if (target_i == arcane->specific.item)
					best = 1;
				if (arcane->end_product == target_i)
					best = 1;
				/* this was broken before */
				for(owns = unit->carrying; owns; owns = owns->next) {
					if(owns->item == item_mana) continue;
					if(owns->item == arcane->specific.item) {
						difficulty++;
						if(unit->traced_unit) {
							printf("%s [%s] carrying %s [%s] (-1 difficulty) (D=%+d)\n",
									unit->name, unit->id.text,
									component->what->name,
									component->what->tag.text, difficulty);
						}

					}
					if(owns->item == arcane->end_product) {
						difficulty++;
						if(unit->traced_unit) {
							printf("%s [%s] carrying %s [%s] (-1 difficulty) (D=%+d)\n",
									unit->name, unit->id.text,
									component->what->name,
									component->what->tag.text, difficulty);
						}
					}
					if(best < -4 && arcane->specific.item) {
						if((owns->item->item_type==arcane->specific.item->item_type) &&
								(owns->item->item_category == arcane->specific.item->item_category)) {
							if(owns->amount)
								best = -4;
						}
					}
					if(best < -4 && arcane->end_product) {
						if((owns->item->item_type == arcane->end_product->item_type) &&
								(owns->item->item_category == arcane->end_product->item_category)) {
							if(owns->amount)
								best = -4;
						}
					}
				}
				difficulty += best;
				if(unit->traced_unit) {
					printf("Difficulty adjustment for target is %+d (D=%+d)\n",
							-best, difficulty);
				}
				break;
			case ARGUMENT_IS_RACE_TAG:
				if (current->arguments[3].race == unit->race) {
					difficulty++;
					if(unit->traced_unit) {
						printf("Target is unit's race: -1 difficulty (D=%+d)\n",
								difficulty);
					}
				}
				if (arcane->specific.race == current->arguments[3].race) {
					difficulty++;
					if(unit->traced_unit) {
						printf("Target is spell's race: -1 difficulty (D=%+d)\n",
								difficulty);
					}
					break;
				}
				if (arcane->target == SKILL_TARGET_UNIT ||
						(arcane->flags & 0x80)) {
					difficulty--;
					if(unit->traced_unit) {
						printf("Target is similar race: +1 difficulty (D=%+d)\n",
								difficulty);
					}
				} else {
					difficulty -= 10;
					if(unit->traced_unit) {
						printf("Target is different race: +10 difficulty (D=%+d)\n",
								difficulty);
					}
				}
				break;
			case ARGUMENT_IS_TERRAIN_TAG:
				if (arcane->specific.terrain == current->arguments[3].terrain) {
					difficulty++;
					if(unit->traced_unit) {
						printf("Target is identical terrain : -1 difficulty (D=%+d)\n",
								difficulty);
					}
					break;
				}
				if (arcane->target == SKILL_TARGET_LOCATION || (arcane->flags & 0x40)) {
					difficulty--;
					if(unit->traced_unit) {
						printf("Target is similar terrain : +1 difficulty (D=%+d)\n",
								difficulty);
					}
				} else {
					difficulty -= 10;
					if(unit->traced_unit) {
						printf("Target is dissimilar terrain : +10 difficulty (D=%+d)\n",
								difficulty);
					}
				}
				break;
			default:
				difficulty -= 10;
				if(unit->traced_unit) {
					printf("Target is dissimilar: +10 difficulty (D=%+d)\n",
							difficulty);
				}
		}
/*
 * Finally, we have a hint
 */
		if (extra_hint) {
			if (extra_hint == arcane) {
				difficulty++;
				if(unit->traced_unit) {
					printf("Hint given and correct: -1 difficulty (D=%+d)\n",
							difficulty);
				}
			} else {
				difficulty -= 20;
				if(unit->traced_unit) {
					printf("Hint given and wrong: +20 difficulty (D=%+d)\n",
							difficulty);
				}
			}
		}

		/* 
		 * Okay.   Here we have a hack.. make it REALLY hard to discover
		 * info about a spell that depends on something higher than your
		 * current dedication level
		 */
		tskill = arcane;
		while(tskill->required_skill != ded->skill)
			tskill = tskill->required_skill;
		if(ded->level < tskill->required_at_level) {
			difficulty -= 50;
			if(unit->traced_unit) {
				printf("Researching too high level: +50 difficulty (D=%+d)\n",
						difficulty);
			}
		}

		if(unit->traced_unit) {
			printf("Difficulty for %s [%s] was %d\n", arcane->name,
					arcane->tag.text, difficulty);
		}
/*
 * We miserably failed to find that skill
 */
		if (difficulty < 0)
			continue;
/*
 * FOUND OUT!
 */
		fitness = difficulty - roll;
/*
 * Distance is?
 */
		difficulty = 0;
		flags = arcane->flags & 0x7;
/*
 * First part is the element
 */
		if (element != flags)
			switch (element) {
			    case 1:
				if (flags == 2 || flags == 4)
					difficulty = 3;
				else
					difficulty = 1;
				break;
			    case 2:
				if (flags == 1 || flags == 5)
					difficulty = 3;
				else
					difficulty = 1;
				break;
			    case 3:
				if (flags == 4 || flags == 5)
					difficulty = 3;
				else
					difficulty = 1;
				break;
			    case 4:
				if (flags == 1 || flags == 3)
					difficulty = 3;
				else
					difficulty = 1;
				break;
			    case 5:
				if (flags == 2 || flags == 3)
					difficulty = 3;
				else
					difficulty = 1;
				break;
			}
		flags = arcane->flags & 0x28;
		if (ritual != flags)
			difficulty += 2;
		best = 3;
		for (component = arcane->use_consumes; component; component = component->next) {
			if (component->what == reagent) {
				best = 0;
				break;
			}
			if (component->what == item_mana)
				continue;
			if (component->what->item_type != reagent->item_type)
				continue;
			if (component->what->item_category == reagent->item_category) {
				best = 1;
				continue;
			}
			if (reagent->item_category < 2)
				continue;
			if ((component->what->item_category|1) == (reagent->item_category|1)) {
				if (best > 2)
				best = 2;
				continue;
			}
		}
		difficulty += best;
		switch (current->executing.types[3]) {
		    case ARGUMENT_IS_ITEM_TAG:
			target_i = current->arguments[3].item;
			if (target_i == arcane->specific.item)
				break;
			if (arcane->end_product == target_i)
				break;
			best = 3;
			for (component = arcane->use_consumes; component; component = component->next) {
				if (component->what == item_mana)
					continue;
				if (component->what == target_i) {
					best = 0;
					break;
				}
				if (component->what->item_type == target_i->item_type &&
				    component->what->item_category == target_i->item_category)
					best = 1;
			}
			if (best > 1 &&
			    arcane->end_product &&
			    arcane->end_product->item_type == target_i->item_type &&
			    arcane->end_product->item_category == target_i->item_category)
				best = 1;
			difficulty += best;
			break;
		    case ARGUMENT_IS_RACE_TAG:
			if (current->arguments[3].race == arcane->specific.race)
				break;
			if (arcane->target == SKILL_TARGET_UNIT)
				difficulty++;
			else
				difficulty += 3;
			break;
		    case ARGUMENT_IS_TERRAIN_TAG:
			if (current->arguments[3].terrain == arcane->specific.terrain)
				break;
			if (arcane->target == SKILL_TARGET_LOCATION)
				difficulty++;
			else
				difficulty += 3;
			break;
		    default:
			difficulty += 3;
		}
		if (extra_hint)
			if (extra_hint != arcane)
				difficulty += 10;
/*
 * Best distance?
 */
		if(unit->traced_unit) {
			printf("distance %d difficulty %d fitness %d match %d\n", 
					distance, difficulty, fitness, match);
		}
		if (!success ||
		    distance > difficulty ||
		    (distance == difficulty && fitness > match)) {
			skill_s *temp;

/*
printf("Research success after %d days by %s for %s, roll %d, difficulty %d\n", days->amount, unit->id.text, arcane->tag.text, roll, difficulty);
printf("research for %d was %s ", dedicated, visual_enum(element-1, order_enum_0));
printf("%s %s %s @ %d", visual_enum((ritual/8)-1, order_enum_1), reagent->tag.text, current->arguments[3].item->tag.text, unit->vital.mana);
printf(" vs %s", visual_enum((arcane->flags & 7)-1, order_enum_0));
printf(" %s ", visual_enum(((arcane->flags/8) & 7)-1, order_enum_1));
if (arcane->flags & 0x40) printf("terrains ");
if (arcane->flags & 0x80) printf("racials ");
putchar('\n');
printf("(selected, distance = %d)\n", distance);
*/
			for (temp = arcane->required_skill; temp; temp=temp->required_skill) {
				found = unit_experiences(unit, temp, 0);
				if (found && found->effective)
					break;
			}
#if 0
			if(found->level < arcane->required_at_level) {
			    /*
			    printf("Continuing because %s (level %d) less than %s (level %d)\n", found->skill->tag.text, found->level, arcane->tag.text, arcane->required_at_level);
			    */
				if(!success) {
					success = arcane;
					distance = difficulty;
					match = fitness;
				}
				continue;
			}
			/*
			} else {
			    printf("Narrowing %s (level %d) greater than or equal %s (level %d)\n", found->skill->tag.text, found->level, arcane->tag.text, arcane->required_at_level);
			}
			*/
#endif
			if(unit->traced_unit) {
				printf("Setting best match so far to %s [%s]\n", arcane->name,
						arcane->tag.text);
			}
			success = arcane;
			distance = difficulty;
			match = fitness;
			continue;
		}
	}

	unit->traced_unit = saved_trace;
/*
 * Did we find something?
 */
	if (success) {
/*
 * Does this skill need a level we cannot master yet?
 */
		roll = 0;
		for (arcane = success->required_skill; arcane; arcane = success->required_skill) {
			found = unit_experiences(unit, arcane, 0);
			if (found && found->effective)
				break;
			success = arcane;
			roll++;
		}
		if(found->level < success->required_at_level) {
			sprintf(work, "You discover information about %s [%s]", 
				success->name, success->tag.text);
			unit_personal_event(unit, today_number, work);
			sprintf(work, "You discover that you are not adept enough at %s [%s] to proceed further.", success->required_skill->name, success->required_skill->tag.text);
			unit_personal_event(unit, today_number, work);
			found->points++;
			days->amount = 0;
			faction_knows_skill_level(unit->faction, success, 1);
			order_is_complete(unit, current);
			return 1;
		}
		switch(roll) {
		    case 0:
			sprintf(work, "Your research reveals the existence of %s [%s]", success->name, success->tag.text);
			break;
		    case 1:
			sprintf(work, "Your experiences reveal the need to master %s [%s]", success->name, success->tag.text);
			break;
		    default:
			sprintf(work, "You feel on the right track, but only %s [%s] seems achievable", success->name, success->tag.text); 
		}
		unit_personal_event(unit, today_number, work);
		days->amount = 0;
		found = unit_experiences(unit, success, 1);
		found->points++;
		found->studied++;
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Done
 */
	current->considered = 1;
	if (current->days)
		order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTING_STUDY
 **	The unit is attempting to study a skill. Allow that to proceed
 **/
int execute_study(unit_s *unit, order_s *current)
{
skill_s		*skill;
experience_s	*exp;
faction_s	*faction;
#ifdef USES_SKILL_LEVELS
int		max;
unit_s		*teacher;
int		was_taught;
#endif
/*
 * Validate argument. Missing argument means "study anything"
 */
	if (unit->is_captive)
		return 0;
	if(current->executing.types[0] != ARGUMENT_IS_SKILL_TAG &&
	   current->executing.types[0] != ARGUMENT_IS_EMPTY) {
		unit_personal_event(unit, today_number, "Invalid STUDY order");
		order_is_error(unit, current);
		return 0;
	}
	skill = current->arguments[0].skill;
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		for (exp = unit->skilled; exp; exp = exp->next)
			if (exp->points && !exp->effective)
				break;
		if(!exp) return 0;
		skill = exp->skill;
	}
/*
 * May study the skill?
 */
	if (unit->race->type != RACE_LEADER) {
		sprintf(work, "Non leaders cannot study");
		unit_personal_event(unit, today_number, work);
		order_is_error(unit, current);
		return 0;
	}
	if(skill->type == 1) {
		sprintf(work, "%s [%s] is an elementary skill and may not be studied",
				skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_error(unit, current);
		return 0;
	}

#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s trying to study %s\n", unit->id.text, skill->tag.text);
#endif
/*
 * Can we study the skill if we exceed control points?
 */
	faction = unit->faction;
	if (skill->bonus.control && faction->control_current + skill->bonus.control > faction->control_max) {
		current->considered = 1;
		return 0;
	}
/*
 * Great! Do we study the skill, or did we reach the level?
 */
	exp = unit_experiences(unit, skill, 1);
	if (exp->points == 0 && !may_study_skill(unit, skill))
		return 0;
#ifdef USES_SKILL_LEVELS
	if ((max = max_level_allowed(unit, skill)) <= exp->level) {
		sprintf(work, "Maximum level already reached in %s [%s]", skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
	max = 1;	/* effective infinity */
	if (max <= exp->level) {
		sprintf(work, "Unit already mastered %s", skill->name);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
#endif
/*
 * Report
 */
	if (exp->effective)
		faction = 0;
	if (unit->executing != current)
		unit->executing = 0;
	if (unit_studies_skill(unit, exp, skill))
		return 0;
        unit->studying = skill;
	was_taught = 0;
	teacher = unit_was_taught(unit, skill, &was_taught);
	if(was_taught) {
		unit->sneaking = 0;
		unit_study_again(unit, exp, skill, unit->size, 0);
		if(teacher) {
			experience_s *limits = unit_experiences(teacher, skill, 0);
			sprintf(work, "%s [%s] was taught %s [%s] by you",
				unit->name, unit->id.text, skill->name,
				skill->tag.text);
			unit_personal_event(teacher, today_number, work);
			add_to_experience(teacher, limits, limits->skill, 1);
		}
	}
	while(unit->intelligent--) {
	    unit_study_again(unit, exp, skill, unit->size, 0);
        }
	unit->executing = current;
	unit->full_day = 1;
/*
 * Fix control points requirements
 */
	if (exp->effective && faction)
		faction->control_current += exp->effective->bonus.control;
/*
 * Stopgap
 */
#ifdef USES_SKILL_LEVELS
	if (max <= exp->level) {
		if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
			order_was_executed(unit, current);
			unit->executing = 0;
		} else {
			order_is_complete(unit, current);
		}
		return 1;
	}
/*
 * STUDY without duration is equivalent to @STUDY
 */
	if (max < 99 && current->days == 0) {
		current->considered = 1;
		return 1;
	}
#endif
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_TEACH
 **	Unit teaches another, if that other studies
 **/
int execute_teach(unit_s *unit, order_s *current)
{
unit_s		*student;
skill_s		*skill;
experience_s	*limits, *learned;
static terrain_s *mtow_cache, *guild_cache;

	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
	if(!guild_cache) {
		synthetic_tag("hall");
		guild_cache = terrain_from_tag(0);
	}
/*
 * Cannot TEACH while guarding
 */
	if (unit->is_guarding)
		return 0;
	if (unit->is_captive)
		return 0;
/*
 * Validate argument
 */
	if (unit->race->type != RACE_LEADER) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; only leaders may teach");
		order_is_error(unit, current);
		return 1;
	}

	if (current->executing.types[0] == ARGUMENT_IS_LOCATION_ID) {
		location_s *here;
		skill_s *base;
		if(current->executing.types[1] != ARGUMENT_IS_SKILL_TAG) {
			unit_personal_event(unit, today_number, "Invalid TEACH order; missing skill");
			order_is_error(unit, current);
			return 1;
		}
		skill = current->arguments[1].skill;
		here = current->arguments[0].location;
		if(here->dedicated) {
			unit_personal_event(unit, today_number, "Invalid TEACH order; building may only be dedicated once a turn.");
			order_is_error(unit, current);
			return 1;
		}
		if(here->type != mtow_cache && here->type != guild_cache) {
			unit_personal_event(unit, today_number, "Invalid TEACH order; that building is not teachable.");
			order_is_error(unit, current);
			return 1;
		}
		if(unit->current != here || here->present != unit) {
			unit_personal_event(unit, today_number, "Invalid TEACH order; must be the owner of the building to teach it.");
			order_is_error(unit, current);
			return 1;
		}
		base = skill;
		while(base != magecraft && base->required_skill)
			base = base->required_skill;
		if(here->type == mtow_cache) {
			if(base != magecraft) {
				unit_personal_event(unit, today_number, "Invalid TEACH order; magical towers can only be taught mage skills.");
				order_is_error(unit, current);
				return 1;
			}
		} else {
			if(base == magecraft) {
				unit_personal_event(unit, today_number, "Invalid TEACH order; magical towers can only be taught mage skills.");
				order_is_error(unit, current);
				return 1;
			}
		}

		free_experience_instance(here->skills);
		here->skills = NULL;
		here->dedicated = 1;
		learned = new_experience_instance();
		learned->skill = skill;
		learned->points = skill->for_level;
		adjust_experience(learned, 1);
		here->skills = learned;
		unit->full_day = 1;
		sprintf(work, "%s [%s] taught to %s [%s]", skill->name,
			skill->tag.text, here->name, here->id.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 1;
	}

	if (current->executing.types[0] != ARGUMENT_IS_UNIT_ID) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing unit-id or location-id");
		order_is_error(unit, current);
		return 1;
	}
	if (current->executing.types[1] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid TEACH order; missing skill");
		order_is_error(unit, current);
		return 1;
	}
	student = current->arguments[0].unit;
	skill  = current->arguments[1].skill;
	if (!unit->size || !may_interact_with(unit, student))
		return 0;
	if ((limits = unit_experiences(unit, skill, 0)) == 0)
		return 0;
#ifdef USES_SKILL_LEVELS
	if (limits->level < 1)
		return 0;
	if ((learned = unit_experiences(student, skill, 0)) != 0 && learned->level > 0) {
			sprintf(work, "%s [%s] cannot be taught, %s is mastered", student->name,
					student->id.text, skill->name);
			unit_personal_event(unit, today_number, work);
			order_is_complete(unit, current);
			return 0;
		}
#else
	learned = 0;
#endif
/*
 * Target unit must execute some skill
 */
	if (student->is_guarding || student->inactive || student->dead || student->size == 0)
		return 0;
	unit->full_day = 1;
	/* We still fail teaching if the student already executed */
	if(student->full_day) return 0;
	unit->sneaking = 0;
	add_unit_teaching(student, unit, limits);
/*
 * At LAST! We're teaching!
 */
	sprintf(work, "Attempting to teach %s [%s] to %s [%s]",
		skill->name, skill->tag.text, student->name,
		student->id.text);
	unit_personal_event(unit, today_number, work);
	sprintf(work, "%s [%s] attempts to teach you %s [%s]",
		unit->name, unit->id.text, skill->name,
		skill->tag.text);
	unit_personal_event(student, today_number, work);
/*
 * Teaching done for today
 */
	unit->executing = current;
	order_was_executed(unit, current);
#ifdef DYNAMIC_ECONOMY
	unit->true_location->economy ++;
#endif
	return 1;
}


/**
 ** EXECUTING_ATTACK
 **	The unit looks around for someone to slay
 **/
int execute_attack(unit_s *unit, order_s *current)
{
unit_s	*target;
/*
 * Invalid arguments. Delete the order
 */
	if ((current->executing.types[0] != ARGUMENT_IS_UNIT_ID) &&
	    (current->executing.types[0] != ARGUMENT_IS_FACTION_ID) &&
	    (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) &&
	    (current->executing.types[0] != ARGUMENT_IS_TERRAIN_TAG)) {
		unit_personal_event(unit, today_number, "Invalid ATTACK order");
		order_is_error(unit, current);
		return 1;
	}

	if(unit->true_location->type == neutral_city)
		return 0;
	if(!eligible_attacker(unit)) return 0;

	if(current->executing.types[0] == ARGUMENT_IS_UNIT_ID) {
		/*
		 * To execute, we must be at the same location
		 */
		target = current->arguments[0].unit;
	} else if(current->executing.types[0] == ARGUMENT_IS_FACTION_ID) {
		/* See if there are any units of that faction in the location */
		who_is_present(unit->current);
		for(target = unit->current->interacting; target; target = target->next_visible) {
			if(target->setting_advert) continue;
			if(target->faction != current->arguments[0].faction)
				continue;
			if (!may_interact_with(unit, target) || target->size <= 0 ||
					target->dead)
				continue;
			if(target->is_captive) continue;
			if(!eligible_defender(target)) continue;
			break;
		}
		if(!target) {
			/* Okay, now try the outer location and any inners */
			who_is_present(unit->true_location);
			for(target = unit->true_location->interacting; target; target = target->next_visible) {
				if(target->setting_advert) continue;
				if(target->faction != current->arguments[0].faction)
					continue;
				if (!may_interact_with(unit, target) ||
						target->size <= 0 || target->dead)
					continue;
				if(target->is_captive) continue;
				if(!eligible_defender(target)) continue;
				break;
			}
		}
		if(!target) return 0;
	} else if(current->executing.types[0] == ARGUMENT_IS_LOCATION_ID) {
		location_s *loc = current->arguments[0].location;
		if(loc->type->type != TERRAIN_STRUCTURE) {
			unit_personal_event(unit, today_number,
					"Invalid ATTACK order; location is not a building");
			order_is_error(unit, current);
			return 1;
		}
		target = loc->present;
		if(!target) return 0;
	} else if(current->executing.types[0] == ARGUMENT_IS_TERRAIN_TAG) {
		location_s *loc;
		if(current->arguments[0].terrain->type != TERRAIN_STRUCTURE) {
			unit_personal_event(unit, today_number,
					"Invalid ATTACK order; terrain is not a building");
			order_is_error(unit, current);
			return 1;
		}
		for(loc = unit->true_location->inner; loc; loc = loc->next_inner) {
			if(loc->type != current->arguments[0].terrain) continue;
		}
		if(!loc) return 0;
		target = loc->present;
		if(!target) return 0;
	}

	if (!may_interact_with(unit, target) || target->size <= 0 || target->dead)
		return 0;

	if(target->is_captive) return 0;
	if(!eligible_defender(target)) return 0;

	if (unit->faction == target->faction) {
		unit_personal_event(unit, today_number,
				"Cannot attack your own units");
		order_is_complete(unit, current);
		return 1;
	}
/*
 * Stealth intervenes
 */
	sprintf(work, "%s [%s] attacks %s [%s]", unit->name, unit->id.text, target->name, target->id.text);
	unit_personal_event(unit, today_number, work);
	unit_personal_event(target, today_number, work);
	unit->sneaking = 0;
#ifdef PRISONERS_TAKEN
	if(current->executing.routine == execute_capture)
	   all_capture_target = 1;
#endif
	initiate_attack(unit, target);
#ifdef PRISONERS_TAKEN
	all_capture_target = 0;
#endif
	unit->full_day = 1;
	unit->executing = 0;
	order_was_executed(unit, current);
	return 1;
}


/**
 ** EXECUTE_WORK
 **	This is the default order. It might be called with an order pointer
 **/
int execute_work(unit_s *unit, order_s *current)
{
experience_s	*exp;
order_s		fake;
/*
 * Camps do @use skill
 */
	if (unit->race->type != RACE_LEADER)
		for (exp = unit->skilled; exp; exp = exp->next)
			if (exp->effective) {
				memset(&fake, 0, sizeof(fake));
				fake.arguments[0].skill = exp->skill;
				fake.executing.types[0] = ARGUMENT_IS_SKILL_TAG;
				fake.days = -1;
				if (execute_use(unit, &fake))
					return 1;
			}
/*
 * Carrying on
 */
	if (current)
		order_was_executed(unit, current);
	unit->executing = 0;
	unit->full_day = 1;
	return 1;
}

int execute_unequip(unit_s *unit, order_s *current)
{
carry_s         *owns;
item_s          *item;
int             amount;
/*
 * Invalid arguments. Delete the order
 */
        if (unit->is_captive)
                return 0;
        if (current->executing.types[0] != ARGUMENT_IS_ITEM_TAG) {
                unit_personal_event(unit, today_number, "Invalid EQUIP order");
                order_is_error(unit, current);
                return 1;
        }
	item = current->arguments[0].item;
	owns = unit_possessions(unit, item, 0);
	if(!owns || (owns->amount == 0)) {
		return 0;
	}
	if(!owns->equipped)
		return 0;
	amount = owns->equipped;
	owns->equipped = 0;
	sprintf(work, "%d %s [%s] now unequipped.", amount,
		(amount > 1 ? item->plural : item->name), item->tag.text);
	unit_personal_event(unit, today_number, work);
	order_was_executed(unit, current);
	return 1;
}

/**
 ** EXECUTING_WITHIN
 **	Wait for the location
 **/
int execute_within(unit_s *unit, order_s *current)
{
	location_s *loc;
/*
 * Invalid arguments. Delete the order
 */
	if (unit->is_captive)
		return 0;
	if (current->executing.types[0] != ARGUMENT_IS_LOCATION_ID) {
		unit_personal_event(unit, today_number, "Invalid WITHIN order");
		order_is_error(unit, current);
		return 0;
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s executes WITHIN %s\n", unit->id.text, current->arguments[0].location->id.text);
#endif
/*
 * Valid
 */
	loc = unit->current;
	while(loc) {
		if(loc == current->arguments[0].location) {
			current->considered = 1;
			if (current->days < 0)
				infinite_conditional(unit, current);
			else
				order_was_executed(unit, current);
			return 1;
		}
		loc = loc->outer;
	}
	return 0;
}


int execute_capture(unit_s *unit, order_s *current)
{
	return execute_attack(unit,current);
}

int execute_kill(unit_s *unit, order_s *current)
{
	return execute_attack(unit,current);
}
