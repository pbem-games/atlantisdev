/* $Id: enumstxt.c,v 1.3 2000/06/23 23:50:59 jtraub Exp $
 *	Strings
 */

/**
 ** This is visual, and appear in the report generator
 **/
#ifndef SYNTAX_CHECKER
char		battlefield_targets[] = "\nbattlefield\nself\narmy\nopposing army\nfriendly unit\nopposing unit\nfriendly leader\nopposing leader";
char		battlefield_ranges[] = "\nmelee\nranged\nlong range (2)\nfar range (3)\nfield range (4)\nextreme range (5)\ncomplete range (6)\nbattlefield";
char		battlefield_actions[] = "\nmelee attack\nranged attack\nspecial";
char		battle_damage_types[] = "standard\nair\nearth\nfire\nvoid\nwater";
char		equipment_categories[] = "\nfood\nmount\ntool\nship\nweapon\narmor\nhelmet\nshield\ngloves\nboots\namulet\nring\nmisc.\nscroll";

#ifdef WORLD_HAS_CLIMAT
char		season_names[] = "spring\nsummer\nautumn\nwinter";
char		climatic_conditions[] = "standard\nfair\nsunny\nrainy\nwindy\nstormy\nblizzard\ntwilight\nbland";
#endif
#ifdef USES_TITLE_SYSTEM
char		title_kinds[] = "minor\nstandard\nmajor\noverlord";
#endif
#ifndef TURN_PROCESSOR
char		skill_types[] = "\ncombat\nmagic\ncreature";
char		race_types[] = "\nleader\nfollower\nbeast\ncreature\nmonster\nbattle-only entity";
#endif
#endif
char		regions[] = "overworld\nair\nearth\nfire\nwater\nvoid\nunderworld\nnexus";
