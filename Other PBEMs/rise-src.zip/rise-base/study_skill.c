/* $Id: study_skill.c,v 1.10 2000/08/06 19:48:47 jtraub Exp $
 *	Plug for skill learning.
 */
#include "turn.h"
#include "fx.h"
#include "parser.h"


#ifdef USES_REQUIRED_LEVELS
/**
 ** MAX_LEVEL_ALLOWED
 **	Reports the maximum level allowed for studies. Takes teacher
 ** into account, if one.
 **/
int max_level_allowed(unit_s *unit, skill_s *skill)
{
/*
 * Default is zero (for creatures)
 */
	return 1;
}
#endif


/**
 ** MAY_STUDY_SKILL
 **	Reports TRUE if a skill may be learned by the unit
 **/
int may_study_skill(unit_s *unit, skill_s *skill)
{
experience_s	*exp;
taught_s	*teachers;
#ifdef USES_REQUIRED_LEVELS
skill_s		*required;
int		numbers;
#endif
#ifdef SKILL_REQUIRES_BOOK
carry_s		*holds;
#endif
/*
 * Creatures may never study skills
 */
	if (!unit->race || unit->race->type >= RACE_CREATURE)
		return 0;
/*
 * Skill is leader-only
 */
#if 0
	if (skill->student && unit->race->type != skill->student)
		return 0;
#endif
/*
 * Study
 */
#ifdef USES_REQUIRED_LEVELS
	if ((required = skill->required_skill) != 0) {
		for (exp = unit->skilled; exp; exp = exp->next)
			if (exp->skill == required)
#ifdef USES_SKILL_LEVELS
			    	if (exp->level >= skill->required_at_level)
#else
				if (exp->effective)
#endif
					break;
		if (!exp)
			return 0;
/*
 * Special magecraft rules. Only one "non-magical" skill per magecraft level.
 */
		if (required == magecraft && skill->type != 2) {
			numbers = 1;
			for (exp = unit->skilled; exp; exp = exp->next)
				if (exp->skill->required_skill == magecraft &&
				    exp->points != 0 &&
				    exp->skill->type != 2 &&
				    exp->skill != skill)
					numbers--;
			if (numbers <= 0)
				return 0;
		}
	}
#endif
/*
 * Specialist skills?
 */
#ifdef SPECIALIST_SKILLS
	if (skill->specialist) {
		if(unit->current) {
			for (exp = unit->current->skills; exp; exp = exp->next)
				if (exp->skill == skill && exp->effective)
					break;
		}
		/*
		 * Not taught by the inner location, let's see if it's
		 * taught by the outer, but only if we are a terrain building
                 */
		if(!exp &&
                   (!unit->current ||
                    (unit->current->type->type == TERRAIN_STRUCTURE))) {
			for(exp = unit->true_location->skills; exp; exp = exp->next)
				if(exp->skill == skill && exp->effective)
					break;
		}
/*
 * Not taught by location, maybe a teacher then?
 */
		if (!exp) {
			for(teachers = unit->taught; teachers; teachers = teachers->next) {
				if(teachers->exp->skill == skill)
					break;
				
			}
			if(!teachers) return 0;
		}
	}
#endif
/*
 * Item-enabled skills?
 */
#ifdef SKILL_REQUIRES_BOOK
	if (skill->required_item) {
		if ((holds = unit_possessions(unit, skill->required_item, 0)) == 0 ||
		     holds->amount < unit->size)
			return 0;
	}
#endif
/*
 * Default is: may study
 */
	return 1;
}


/**
 ** ADD_TO_EXPERIENCE
 **	Unit gains experience!
 **/
int add_to_experience(unit_s *unit, experience_s *exp, skill_s *skill, long points)
{
skill_s	*achieved;
/*
 * How many points gained?
 */
/*** HACK ***/
	if (!points)
		return 0;
	if (!unit->size)
		return 0;
	exp->points += points;
	exp->studied += points;
	points = exp->points;
	points /= unit->size;
#ifdef USES_SKILL_LEVELS
	if (exp->effective)
		achieved = exp->effective->next_level;
	else
#endif
		achieved = skill;
/*
 * Level changes
 */
	if (achieved && achieved->for_level <= points) {
#ifdef USES_SKILL_LEVELS
		exp->level++;
		sprintf(work, "%s mastered %s [%s]", unit->name, 
				achieved->name, skill->tag.text);
#else
		sprintf(work, "%s learns %s [%s]", unit->name,
				achieved->name, skill->tag.text);
#endif
		unit_personal_event(unit, today_number, work);
		exp->effective = achieved;
		return 1;
	}
/*
 * Done
 */
	return 0;
}


/**
 ** UNIT_STUDIES_AGAIN
 **	Requires cash. It is assumed that check has been made.
 **/
void unit_study_again(unit_s *unit, experience_s *exp, skill_s *skill, int cap, int reduced)
{
experience_s	*bonus;
skill_s		*tree;
#if defined(SKILL_BENEFITS_FROM_BOOK) || defined(FX_QUICK_STUDY)
carry_s		*owns;
#endif
#ifdef FX_QUICK_STUDY
int studiers;
int quick_bonus = 0;
#endif
long		points;
long		base_points;
int		recompute;
static terrain_s *mtow_cache;
int		tower_bonus;
int got_race_bonus = 0;


	if(!mtow_cache) {
		synthetic_tag("mtow");
		mtow_cache = terrain_from_tag(0);
	}
/*
 * Points are gained
 */
	points = unit->size;
	if (points > cap)
		points = cap;
	points *= SKILL_POINTS_PER_DAY;
	base_points = points;
	tower_bonus = 0;
/*
 * These depend on skill trees
 */
#ifdef USES_REQUIRED_LEVELS
	for (tree = skill; tree; tree = tree->required_skill) {

	/* Bonus for magical tower */
	    if(tree == magecraft) {
#ifdef FX_QUICK_STUDY
		quick_bonus = 1;
#endif
		if(unit->current->type == mtow_cache) {
		    tower_bonus = 1;
		}
	    }
#ifdef USES_TITLE_SYSTEM
/*
 * Title bonus
 */
		if (unit->title)
			if (unit->title->title->required == tree)
				points += points / 10;
#endif
#ifdef RACE_FAVOR_SKILLS
/*
 * Racial advantages
 */
		for (bonus = unit->race->favors; bonus; bonus = bonus->next)
			if (tree == bonus->skill)
				break;
		if (bonus && !got_race_bonus) {
			points *= bonus->points;
			points += 50;
			points /= 100;
			got_race_bonus = 1;
		}
#endif
/*
 * Widsdom is imparted by an object
 */
#ifdef SKILL_BENEFITS_FROM_BOOK
		if (tree->wisdom) {
			owns = unit_possessions(unit, tree->wisdom, 0);
			if (owns && owns->equipped) {
				if (skill->type == 2 || skill->required_skill == magecraft)
					points += owns->equipped;
				else
					points += 4 * owns->equipped;
			}
		}
#endif
	}
#endif
/*
 * Reduction in points?
 */
	if (reduced) {
		points *= reduced;
		points += 50;
		points /= 100;
	}

	if(tower_bonus) {
		points *= 133;
		points += 50;
		points /= 100;
	}

#ifdef FX_QUICK_STUDY
	if(quick_bonus) {
	    studiers = 0;
	    for(owns = unit->carrying; owns; owns = owns->next) {
		if(owns->equipped && owns->amount &&
		   owns->item->special_effects == FX_QUICK_STUDY) {
		    studiers += owns->equipped;
		}
	    }
	    if(studiers) {
		points *= (100 + 10*studiers);
		points += 50;
		points /= 100;
	    }
	}
#endif

/*
 * Now add to points
 */
	if (unit->is_guarding)
		points /= 2;
	if (add_to_experience(unit, exp, skill, points))
		recompute = 1;
	else
		recompute = 0;
#ifdef USES_REQUIRED_LEVELS
	base_points /= 10;
	while ((skill = skill->required_skill) != 0) {
		exp = unit_experiences(unit, skill, 1);
		if (add_to_experience(unit, exp, skill, base_points))
			recompute = 1;
	}
#endif
/*
 * At least one level was achieved
 */
	if (recompute) {
		compute_unit_stats(unit);
#ifdef STEALTH_STATS
		compute_overall_stealth(unit);
#endif
	}
/*
 * Done
 */
}


/**
 ** UNIT_STUDIES_SKILL
 **	Requires cash. It is assumed that check has been made.
 **/
int unit_studies_skill(unit_s *unit, experience_s *exp, skill_s *skill)
{
long	cash;
/*
 * Cash requirements
 */
	cash = unit->size * skill->study_cost;
	if (payment_required(unit, cash))
		return 1;
	if (unit->executing == 0) {
		sprintf(work, "%s studies %s [%s]", unit->name, skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
	}
	if(unit->withdrawn) {
		sprintf(work, "$%d funds used to study %s [%s]", unit->withdrawn,
				skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		unit->withdrawn = 0;
	}
	unit_study_again(unit, exp, skill, unit->size, 0);
	return 0;
}


/**
 ** ADD_LANDWALK_EXPERIENCE
 **	Adds to experience to current land, if already known!
 **/
int add_landwalk_experience(unit_s *stack, skill_s *land, int points)
{
experience_s	*exp;
int		recompute;
/*
 * Does the unit has some experience in landwalk?
 */
	recompute = 0;
	if ((exp = unit_experiences(stack, land, 0)) != 0 && exp->points != 0) {
		if (add_to_experience(stack, exp, land, points)) {
			compute_unit_stats(stack);
			recompute = 1;
		}
	}
	for (stack = stack->stack; stack; stack = stack->next_location)
		if (add_landwalk_experience(stack, land, points))
			recompute = 1;
	return recompute;
}


#ifdef FX_MIND_READING
/**
 ** Pick a skill you could study under the target's tutelage, and get 150%
 ** study speed of it.
 **/
void fx_mind_reading(unit_s *mindreader, int speed)
{
experience_s	*mind, *choice;
experience_s	*elect;
unit_s		*target;
int		type, chances;
/*
 * Study now
 */
	target = mindreader->target.unit;
	choice = 0;
	chances = 0;
	type = -1;
	for (mind = target->skilled; mind; mind = mind->next) {
/*
 * Must have at least full skill to pick it
 */
		if (!mind->effective)
			continue;
		mindreader->taught = mind;
		if (!may_study_skill(mindreader, mind->skill))
			continue;
		elect = unit_experiences(mindreader, mind->skill, 0);
		if (elect) {
#ifdef USES_SKILL_LEVELS
			if (elect->level >= mind->level)
#else
			if (elect->effective)
#endif
				continue;
		}
/*
 * Potentially correct!
 */
		if (mind->skill->type < type)
			continue;
		if (mind->skill->type > type) {
			choice = 0;
			chances = 0;
			type = mind->skill->type;
		}
/*
 * Roll at random. We have a decreasing chance of picking the skill
 */
		chances++;
		if (choice && roll_1Dx(chances) != 1)
			continue;
		choice = mind;
	}
/*
 * No choice! Mind reading wasted!
 */
	if (!choice) {
		unit_personal_event(mindreader, today_number, "No useful knowledge obtained!");
		return;
	}
	sprintf(work, "Picks some knowledge of %s", choice->skill->name);
	unit_personal_event(mindreader, today_number, work);
	speed *= SKILL_POINTS_PER_DAY;
	speed /= 100;
	choice = unit_experiences(mindreader, choice->skill, 1);
	if (add_to_experience(mindreader, choice, choice->skill, speed)) {
		compute_unit_stats(mindreader);
#ifdef STEALTH_STATS
		compute_overall_stealth(mindreader);
#endif
	}
}
#endif /* FX_MIND_READING */
