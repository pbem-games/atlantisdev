/* $Id: command_e.c,v 1.3 2000/06/14 07:30:46 jtraub Exp $
 *	Command argument strings
 */

char		stance_arguments[] = 
			"ally\nfriend\nneutral\nhostile\nenemy\ndefault";
static char	boolean_arguments[] =
			"off\non";
char		participate_modes[] = "avoid\ndefend\nfight\nkill\ncapture";
char		battlefield_ranks[] = "rear\nmiddle\nfront";
char		battlefield_files[] = "left\ncenter\nright";
char		battlefield_moves[] = "escape\ntarget\nnearest\nrandom\nstrongest\nweakest\ndefended\nvulnerable\nbiggest\nsmallest\nvaried\nhomogenous";
char		possible_settings[] = "anonymous\nguard\nhtml\nmiser\nprotect\nsilent\nsupport\nterse\nhushgive";
static char	combat_arguments[] =
			"default\nonce\nmelee\nranged\nguard";
char		movement_modes[] = "walking\nriding\nflying\nsailing";
char		order_enum_0[] = "air\nearth\nfire\nvoid\nwater";
char		order_enum_1[] = "enchantment\ninstant\nmass\nmeditation\nsummoning";
