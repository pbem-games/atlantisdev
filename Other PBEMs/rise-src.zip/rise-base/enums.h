/* $Id: enums.h,v 1.4 2000/06/23 23:50:59 jtraub Exp $
 *	Define bounds. Note that MAX_MOVE_MODES is defined in config.h
 */
#define MAX_EQUIP_CATEGORIES	20

/**
 ** Item types
 **/
#define ITEM_FOLLOWER		1
#define ITEM_BEAST		2
#define ITEM_ITEM		3
#define ITEM_DAYS		4
#define ITEM_EFFECT		5
#define ITEM_EVENT		6
#define ITEM_TOKEN		7

/**
 ** Region types
 **/
#define REGION_OVERWORLD	0
#define REGION_AIR		1
#define REGION_EARTH		2
#define REGION_FIRE		3
#define REGION_WATER		4
#define REGION_VOID		5
#define REGION_UNDERWORLD	6
#define REGION_NEXUS		7

/**
 ** Battlefield Targets (see enumstxt)
 **/
#define BATTLEFIELD_TARGET_ALL		1
#define BATTLEFIELD_TARGET_SELF		2
#define BATTLEFIELD_TARGET_ARMY		3
#define BATTLEFIELD_TARGET_ENEMIES	4
#define BATTLEFIELD_TARGET_FRIENDLY	5
#define BATTLEFIELD_TARGET_OPPOSING	6
#define BATTLEFIELD_TARGET_LEADER	7
#define BATTLEFIELD_TARGET_TARGET	8

/**
 ** Unit types
 **/
#define RACE_LEADER	1
#define RACE_FOLLOWER	2
#define RACE_CREATURE	3


/**
 ** Categories of equipment, for specials
 **/
#define EQUIP_CATEGORY_FOOD	1
#define EQUIP_CATEGORY_MOUNT	2
#define EQUIP_CATEGORY_TOOL	3
#define EQUIP_CATEGORY_SHIP	4
#define EQUIP_CATEGORY_WEAPON	5
#define EQUIP_CATEGORY_ARMOR	6
#define EQUIP_CATEGORY_HERMET	7
#define EQUIP_CATEGORY_SHIELD	8
#define EQUIP_CATEGORY_GLOVES	9
#define EQUIP_CATEGORY_BOOTS	10
#define EQUIP_CATEGORY_AMULET	11
#define EQUIP_CATEGORY_RING	12
#define EQUIP_CATEGORY_MISC	13
#define EQUIP_CATEGORY_END	13

/**
 ** Battle movements
 **/
#define BATTLEFIELD_MOVE_FLEE		0
#define BATTLEFIELD_MOVE_TARGET		1
#define BATTLEFIELD_MOVE_NEAREST	2
#define BATTLEFIELD_MOVE_RANDOM		3
#define BATTLEFIELD_MOVE_STRONGEST	4
#define BATTLEFIELD_MOVE_WEAKEST	5
#define BATTLEFIELD_MOVE_DEFENDED	6
#define BATTLEFIELD_MOVE_VULNERABLE	7
#define BATTLEFIELD_MOVE_BIGGEST	8
#define BATTLEFIELD_MOVE_SMALLEST	9
#define BATTLEFIELD_MOVE_VARIED		10
#define BATTLEFIELD_MOVE_HOMOGENOUS	11
