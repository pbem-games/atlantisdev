/* $Id: battle.c,v 1.39 2001/01/12 20:20:10 jtraub Exp $
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "fx.h"

/**
 ** Internal variables
 **/
FILE		*full_report, *long_report, *terse_report;
location_s	*battle_location;
extern item_s	*tired_cache,
		*wariness_cache;
static char	*sep;
static int	battle_number;
static char	path_full[256];
static char	path_long[256];
static char	path_short[256];

#ifdef PRISONERS_TAKEN
int all_capture_target = 0;
#endif

/**
 ** RANDOM_UNIT_SWAPS
 **	The real meat of the next function
 **/
static figure_s *random_unit_swaps(figure_s *unit)
{
figure_s	*two;
/*
 * End of recursions
 */
	if (!unit)
		return 0;
	if (!unit->same_side)
		return unit;
/*
 * Do we swap?
 */
	two = random_unit_swaps(unit->same_side);
	if (roll_1Dx(2) & 1) {
		unit->same_side = two;
		return unit;
	}
	unit->same_side = two->same_side;
	two->same_side  = unit;
	return two;
}


/**
 ** BATTLE_RANDOM_SHUFFLE
 **	Shuffle all units on a side, to help distributing hits and spoils.
 ** We aren't very sophisticated: all units have 50% chance of swapping
 ** positions.
 **/
void random_shuffle(side_s *side)
{
/*
 * Use a recursion. i'm lazy, so sue me.
 */
	side->units = random_unit_swaps(side->units);
}


/**
 ** START_FOLD_UNIT_SEGMENT
 **	Start a unit segment report
 **/
void start_fold_unit_segment(figure_s *unit)
{
	empty_fold_string();
#ifdef BATTLE_INITIATIVE
	add_fold_integer(initiative_level);
	add_fold_char(':');
	add_fold_char(' ');
#endif
	add_fold_string(unit->unit->name);
	if (unit->simplename)
		add_fold_tag(&unit->unit->id);
	add_fold_char(' ');
}

#ifdef PRISONERS_TAKEN
int count_troops(figure_s *unit)
{
    actor_s *a;
    int troops = 0;
    for(a = unit->autonomous; a; a = a->next) {
        if(a->actor) {
            if((a->actor->item_type == ITEM_FOLLOWER) &&
               (a->vitals.melee || a->vitals.missile)) {
                troops += a->amount;
            }
        } else {
            troops++;
        }
    }
    return troops;
}

/**
 ** DOES_CAPTURE
 **     Does the unit capture the target
 **/
int does_capture(figure_s *unit, figure_s *target)
{
	int troops;
	/* Is the unit already a prisoner? */
	if(unit->prisoner) return 0;
	if(unit->unit->is_captive) return 0;
	/* Does the unit already have a prisoner */
	if(unit->captive) return 0;
	/* Was the target already captured */
	if(target->prisoner) return 0;
	if(target->unit->is_captive) return 0;
	/* if the target isn't a leader */
	if(target->unit->race->type != RACE_LEADER) return 0;
	/*
	 * If the unit isn't a leader and the target isn't *the* target.
	 */
	if((unit->unit->race->type != RACE_LEADER) &&
	   target != unit->side->opposing->initiator) return 0;

	/*
	 * If we are a defending unit and are not set capture, don't capture
	 */
	if(unit->unit->participate < 4 && unit->side == &defenders) return 0;
	/*
	 * At this point we are an attacking unit, or a defender with capture
	 * If we're not in all_capture mode, and the units setting
	 * isn't capture, don't capture 
	 */
	if(!all_capture_target && unit->unit->participate < 4) return 0;
	/*
	 * Does the target have any followers?
	 */
	if(target->men != 1) return 0;
	/*
         * Do we have enough soldiers?
	 */
	troops = count_troops(unit);
	if(troops < 4+target->beasts) return 0;

	/* We succeed in capturing */
	target->prisoner = 1;
	target->captor = unit;
	unit->captive = target;
	unit_away(target);
	return target->beasts+1;
}
#endif

/**
 ** WITNESSES
 **	Who saw the battle?
 **/
static void witnesses(faction_s *faction, char *lpath, char *event)
{
event_s		*reported, *last, *r2;
/*
 * Loop on all present
 */
	if (!faction)
		return;
	last = 0;
	for (reported = faction->globals; reported; reported = reported->next)
		if (strcmp(reported->text, path_long) == 0 ||
		    strcmp(reported->text, path_full) == 0 ||
		    strcmp(reported->text, path_short) == 0)
			break;
		else
			last = reported;
	if (!reported) {
		r2 = new_dated_event();
		r2->day = today_number;
		r2->text = strdup(event);
		reported = new_dated_event();
		reported->day = -1;
		reported->next = r2;
		if (faction->setting_terse)
			lpath = path_short;
		reported->text = strdup(lpath);
		if (last)
			last->next = reported;
		else
			faction->globals = reported;
	} else {
	    if(lpath == path_full) {
		if(faction->setting_terse)
		    lpath = path_short;
		free(reported->text);
		reported->text = strdup(lpath);
	    }
	}
}


/**
 ** FINALISE_UNIT
 **	Check what happened to this unit
 **/
static void finalise_unit(side_s *sides, figure_s *unit, int figure_cap)
{
#ifdef REPORTS_RACIAL_KNOWLEDGE
figure_s	*encounter;
#endif
#ifdef PRISONERS_TAKEN
figure_s	*gaoler;
#endif
#ifdef USES_TITLE_SYSTEM
figure_s	*claim;
title_s		*title;
unit_s		*leader;
#endif
unit_s		*original, *stack, *captor, *next;
carry_s		*spoils, *treasure;
item_s		*equipment;
experience_s	*exp;
long		points;
int		category, max, captive;
int		equipped[MAX_EQUIP_CATEGORIES];
location_s	*battle_location;
/*
 * Is that unit wounded? If so, any healing?
 */
/*** HACK ***/
/*
 * Free the equipment lists, we don't need them anymore (and might reuse
 * for spoils right now)
 */
	free_carry_instance(unit->using);
	free_actor_instance(unit->autonomous);
	unit->using = 0;
/*
 * Fanatic unit at a losing side?
 */
	if (sides->lost && unit->fanatic) {
		sides->casualties += unit->living;
		unit->living = 0;
	}

	original = unit->unit;

#ifdef REPORTS_RACIAL_KNOWLEDGE
/*
 * Report all kind of critters we encountered or got ourselves ally of
 */
	for (encounter = attackers.units; encounter; encounter = encounter->same_side)
		faction_knows_race(original->faction, encounter->race);
	for (encounter = defenders.units; encounter; encounter = encounter->same_side)
		faction_knows_race(original->faction, encounter->race);
#endif
/*
 * If we want long reports, then we get a report with the kind of enemies we got
 */
        battle_location = original->true_location;
        sprintf(work, "Battle at %s [%s]", battle_location->name,
                battle_location->id.text);
        witnesses(original->faction, path_full, work);
/*
 * Is that unit dead?
 */
	original = unit->unit;

	unit_set_victor(original, !sides->lost);

	if (unit->living <= 0) {
		/* Special code for orb of ressurection */
		if(fx_equipped_on_unit(original, FX_ORB_OF_RESURRECT)) {
			printf("Unit %s (%s) of [%s] needs to be resurrected!\n",
					original->name, original->id.text,
					original->faction->id.text);
		}

#ifdef USES_CONTROL_POINTS
		if(original->race->type == RACE_LEADER) {
			if(original->faction) {
				/* handle the control point penalty */
				int diff = original->vital.control - original->race->intrinsic.control;
				original->faction->control_bonus -= diff/2;
				if(original->faction->control_bonus < 0)
					original->faction->control_bonus = 0;
				}
		}
#endif
		unit_is_now_dead(original, 0);
		unit_personal_event(original, today_number, "Slain in battle");
/*
 * Add half its possessions to spoils list
 */
		for (spoils = original->carrying; spoils; spoils = spoils->next) {
			if (spoils->amount && !spoils->item->item_type &&
			    spoils->item->item_category) {
				for (treasure = sides->spoils; treasure; treasure = treasure->next)
					if (treasure->item == spoils->item)
						break;
				if (!treasure) {
					treasure = new_carry_instance();
					treasure->item = spoils->item;
					treasure->next = sides->spoils;
					sides->spoils = treasure;
				}
/*
 * Unique items are never shared
 */
				if (spoils->item->unique)
					treasure->amount += spoils->amount;
				else {
					treasure->amount += spoils->amount / 2;
					if ((spoils->amount & 1) != 0 && roll_1Dx(2) == 0)
						treasure->amount++;
				}
			}
		}
		free_carry_instance(original->carrying);
		original->carrying = 0;
		return;
	}

	/* Unit retreated -- Lose half their items, add 1/4 to the loot */
	if(unit->retreat) {
		/* see if they can still move */
		compute_overall_capacity(original);
		if(original->weight > original->capacity[0]) {
			for (spoils = original->carrying;
			     spoils; spoils = spoils->next) {
				if (spoils->amount && !spoils->item->item_type &&
				    spoils->item->item_category) {
					if(spoils->item->unique) {
						if(roll_1Dx(2) & 1) continue;
					}
					for (treasure = sides->spoils;
					     treasure;
					     treasure = treasure->next)
						if (treasure->item == spoils->item)
							break;
					if (!treasure) {
						treasure = new_carry_instance();
						treasure->item = spoils->item;
						treasure->next = sides->spoils;
						sides->spoils = treasure;
					}
					/* Unique items are never shared */
					if (spoils->item->unique) {
						treasure->amount += spoils->amount;
						spoils->amount--;
						if(spoils->equipped > spoils->amount)
							spoils->equipped = spoils->amount;
					} else {
						treasure->amount += spoils->amount / 4;
						if ((spoils->amount & 1) != 0 && roll_1Dx(2) == 0)
							treasure->amount++;
						spoils->amount /= 2;
						if(spoils->equipped > spoils->amount)
							spoils->equipped = spoils->amount;
					}
				}
			}
		}
	}
/*
 * Virtual units now disappear
 */
	if (original->virtual) {
		unit_is_now_dead(original, 0);
		return;
	}
#ifdef BATTLE_INITIATIVE
	unit_increment_battles(original);
#endif

/*
 * Unit survived. Losses cause proportional experience loss...
 */
#ifdef PRISONERS_TAKEN
	if (unit->prisoner) {
		gaoler = unit->captor;
		sprintf(work, "Captured by %s [%s]", gaoler->unit->name,
			gaoler->unit->id.text);
		unit_personal_event(original, today_number, work);
		if(unit == defenders.initiator) {
			if(unit->captor != attackers.initiator) {
				gaoler = attackers.initiator;
				if(gaoler->unit->dead || gaoler->living <= 0) {
					/* Find a different gaoler */
					random_shuffle(&attackers);
					gaoler = attackers.units;
					while(gaoler && (gaoler->unit->dead || gaoler->living <= 0)) {
						gaoler = gaoler->same_side;
					}
				}
			}
		}
		if(!gaoler) {
			sprintf(work, "Freed because no one is alive to keep you prisoner.");
			unit_personal_event(original, today_number, work);

		} else if(gaoler->unit->dead || gaoler->living <= 0) {
			sprintf(work, "Freed because captor is no longer alive.");
			unit_personal_event(original, today_number, work);
		} else {
			if(gaoler != unit->captor) {
				sprintf(work, "%s [%s] takes custody of you.",
					gaoler->unit->name,
					gaoler->unit->id.text);
				unit_personal_event(original, today_number, work);
				sprintf(work, "%s [%s] takes custody of %s [%s] from you.",
						gaoler->unit->name, gaoler->unit->id.text,
						original->name, original->id.text);
				unit_personal_event(unit->captor->unit, today_number, work);
				sprintf(work, "You take custody of %s [%s] from %s [%s].",
						original->name, original->id.text,
						unit->captor->unit->name, unit->captor->unit->id.text);
				unit_personal_event(gaoler->unit, today_number, work);
			}
			/*
			 * First free any beasts that this unit had
			 */
			for(spoils = original->carrying; spoils; spoils = spoils->next)
				if(spoils->item->item_type == ITEM_BEAST)
					spoils->amount = 0;
			/*
			 * Does the unit have any prisoners?
			 */
			if(unit->captive) {
				unit->captive->prisoner = 0;
				unit->captive->captor = 0;
				captor = unit->captor->unit;
				sprintf(work, "Your captor was captured.");
				unit_personal_event(unit->captive->unit,
						    today_number, work);
				if(attitude_vs(captor->faction, unit->captive->unit) < ATTITUDE_IS_NEUTRAL) {
					/* This is a friend.. Free them */
					sprintf(work, "Freed because your captor was captured.");
					unit_personal_event(unit->captive->unit, today_number, work);
					sprintf(work, "%s [%s] is freed by your captor.", unit->captive->unit->name, unit->captive->unit->id.text);
					unit_personal_event(original, today_number, work);
					sprintf(work, "You free %s [%s] who was a prisoner of %s [%s].",
						unit->captive->unit->name, unit->captive->unit->id.text,
						original->name, original->id.text);
					unit_personal_event(captor, today_number, work);
				} else {
					/* Not a friend.. Keep them prisoner */
					sprintf(work, "Now prisoner of %s [%s].",
						captor->name, captor->id.text);
					unit_personal_event(unit->captive->unit, today_number, work);
					sprintf(work, "%s [%s] is also taken prisoner by your captor.", unit->captive->unit->name, unit->captive->unit->id.text);
					unit_personal_event(original, today_number, work);
					unit->captive->captor = unit->captor;
					unit->captive->prisoner = 1;
					sprintf(work, "%s [%s], a prisoner of %s [%s] was also captured.",
						unit->captive->unit->name,
						unit->captive->unit->id.text,
						original->name, original->id.text);
					unit_personal_event(captor, today_number, work);
				}
					
				
			}

			/*
			 * Make sure that any unstacked get put in the right
			 * place.
			 */
			if(original->is_moving) {
				move_to_location(original, original->move_from);
				set_stack_movement(original, 0);
				original->is_moving = 0;
				original->toward = NULL;
				original->move_for_days = 0;
				original->already_moved = 0;
				original->moving_by = 0;
			}

			stack = original->stack;
			while(stack) {
				next = stack->next_location;
				captive = stack->is_captive;
				unstack_unit(stack);
				captor = unit->captor->unit;
				if(captive) {
					sprintf(work, "Your captor was captured.");
					unit_personal_event(stack, today_number, work);
					if(attitude_vs(captor->faction, stack) < ATTITUDE_IS_NEUTRAL) {
						/* This is a friend.. Free them */
						sprintf(work, "Freed because your captor was captured.");
						unit_personal_event(stack, today_number, work);
						sprintf(work, "%s [%s] is freed by your captor.", stack->name, stack->id.text);
						unit_personal_event(original, today_number, work);
						sprintf(work, "You free %s [%s] who was a prisoner of %s [%s].",
							stack->name, stack->id.text,
							original->name, original->id.text);
						unit_personal_event(captor, today_number, work);
						move_to_location(stack, original->current);
					} else {
						/* Not a friend.. Keep them prisoner */
						sprintf(work, "Now prisoner of %s [%s].",
							captor->name, captor->id.text);
						unit_personal_event(stack, today_number, work);
						sprintf(work, "%s [%s] is also taken prisoner by your captor.", stack->name, stack->id.text);
						unit_personal_event(original, today_number, work);
						stack_under(captor, stack);
						stack->is_captive = 1;
						sprintf(work, "%s [%s], a prisoner of %s [%s] was also captured.",
							stack->name,
							stack->id.text,
							original->name, original->id.text);
						unit_personal_event(captor, today_number, work);
					}
				} else {
					sprintf(work, "Unstacked since your leader has been captured.");
					unit_personal_event(stack, today_number, work);
					move_to_location(stack, original->current);
				}
				stack = next;
			}
			/* Unstack if the unit was stacked under anyone */
			unstack_unit(original);

			original->is_captive = 1;
			stack_under(gaoler->unit, original);
			unit->prisoner = 0;
			unit->captor = 0;
			unit->captive = 0;
			/* Tell the gaoler they captured someone */
			sprintf(work, "You captured %s [%s] in battle.",
				original->name, original->id.text);
			unit_personal_event(gaoler->unit, today_number, work);
		}
	}
#endif
	if (unit->deceased) {
		for (exp = original->skilled; exp; exp = exp->next)
			exp->points = fractional(exp->points, unit->living, original->size);
		original->size = unit->living;
		sprintf(work, "%d died in battle", unit->deceased);
		unit_personal_event(original, today_number, work);
		memset(equipped, 0, sizeof(equipped));
/*
 * Drop any extra equipment...
 */
		for (spoils = original->carrying; spoils; spoils = spoils->next) {
			if (spoils->equipped > original->size)
				spoils->equipped = original->size;
			if (spoils->equipped) {
				equipment = spoils->item;
				category = equipment->equip_category;
				max = original->size * equipment->equip_maximum;
				if (spoils->equipped + equipped[category] > max) {
					spoils->equipped = max - equipped[category];
					if (spoils->equipped <= 0)
						spoils->equipped = 0;
				}
				equipped[category] += spoils->equipped;
			}
		}
	}
/*
 * Add combat experience, which makes great veterans
 */
	if(original->race->type == RACE_LEADER) {
		exp = unit_experiences(original, combat_skill, 1);
		if (unit->combat_exp > 20)
			unit->combat_exp = 20;
		points = (SKILL_POINTS_PER_DAY / 2) * unit->combat_exp;
		if (exp->effective == 0)
			points *= 2;
		if (points > figure_cap)
			points = figure_cap;
		add_to_experience(original, exp, combat_skill, points * original->size);
	}
/*
 * Redo the unit value
 */
	compute_unit_stats(original);
#ifdef STEALTH_STATS
	compute_overall_stealth(original);
#endif
	compute_overall_capacity(original);
}

static carry_s *random_item_shuffle(carry_s *item)
{
	carry_s *two;

	/* stop recursing */
	if(!item) return 0;
	if(!item->next) return item;

	/* see if we swap */
	two = random_item_shuffle(item->next);
	if(roll_1Dx(2) & 1) {
		item->next = two;
		return item;
	}
	item->next = two->next;
	two->next = item;
	return two;
}

static carry_s *random_shuffle_spoils(carry_s *spoils)
{
	return random_item_shuffle(spoils);
}

/**
 ** DISTRIBUTE_SPOILS_TO
 **	Any remaining spoils are handed to a unit that may make use of it
 **/
static void distribute_spoils_to(side_s *winner, carry_s *spoils)
{
	carry_s		*spoil;
	figure_s	*force;
	carry_s		*earned;
	unit_s		*unit;
	item_s		*item;
	int		w;
	int		last_amount, can_carry;
	char		loot[256];

	/* Enumerate the spoils in the report */
	for(spoil = spoils; spoil; spoil = spoil->next) {
		if(spoil->amount) {
			add_fold_string(sep);
			item = spoil->item;
			add_fold_item_amount(spoil->amount, item);
			sep = comma;
		}
	}

	/* Shuffle the spoils */
	spoils = random_shuffle_spoils(spoils);

	/* First pass distribution */
	force = winner->units;
	for (spoil = spoils; spoil; spoil = spoil->next) {
		item = spoil->item;
		last_amount = spoil->amount;
		while (spoil->amount) {
			if(!force) {
				force = winner->units;
				if(spoil->amount == last_amount)
					break;
				else
					last_amount = spoil->amount;
			}
			if(force->living <= 0) {
				force = force->same_side;
				continue;
			}
			unit = force->unit;
			can_carry = 1;
			if(unit->race->type == RACE_LEADER) {
				w = item->capacity[0] - item->weight;
				if(unit->weight + w > unit->capacity[0])
					can_carry = 0;
			}
			if(can_carry) {
				/* give it to the unit */
				earned = unit_possessions(unit, item, 1);
				earned->amount++;
				/* record the spoils */
				earned = unit_spoils(unit, item, 1);
				earned->amount++;
				/* recompute capacity */
				compute_overall_capacity(unit);
				spoil->amount--;
			}
			force = force->same_side;
		}
	}

	/* Second pass */
	for (spoil = spoils; spoil; spoil = spoil->next) {
		item = spoil->item;
		while (spoil->amount) {
			if(!force) {
				force = winner->units;
			}
			if(force->living <= 0) {
				force = force->same_side;
				continue;
			}
			unit = force->unit;
			earned = unit_possessions(unit, item, 1);
			earned->amount++;
			/* record the spoils */
			earned = unit_spoils(unit, item, 1);
			earned->amount++;
			/* recompute capacity */
			compute_overall_capacity(unit);
			spoil->amount--;
		}
	}

	/* Report to the unit their spoils */
	for(force = winner->units; force; force = force->same_side) {
		if(force->living <= 0) continue;
		unit = force->unit;
		if(!unit->spoils) continue;
		for(spoil = unit->spoils; spoil; spoil = spoil->next) {
			item = spoil->item;
			sprintf(loot, "Recovered %d %s loot", spoil->amount,
				((spoil->amount)>1?item->plural:item->name));
			unit_personal_event(unit, today_number, loot);
		}
		/* wipe the spoils */
		free_carry_instance(unit->spoils);
		unit->spoils = NULL;
	}
}


/**
 ** AFTERMATH
 **	The battle is over.
 **/
static void aftermath(void)
{
figure_s	*unit;
int		attack_cmbt, defense_cmbt;
/*
 * Survivors gain experience: 15 days/slain enemy, 1 per surviving enemy
 */
	if (attackers.lost && defenders.lost)
		attackers.lost = defenders.lost = 0;
	attack_cmbt = defenders.size + defenders.casualties * 14;
	attack_cmbt *= SKILL_POINTS_PER_DAY;
	attack_cmbt += (attackers.size - attackers.casualties) / 2;
	if (attackers.size > attackers.casualties)
		attack_cmbt /= (attackers.size - attackers.casualties);
	defense_cmbt = attackers.size + attackers.casualties * 14;
	defense_cmbt *= SKILL_POINTS_PER_DAY;
	defense_cmbt += (defenders.size - defenders.casualties) / 2;
	if (defenders.size > defenders.casualties)
		defense_cmbt /= (defenders.size - defenders.casualties);
/*
 * Mark all units dead. Add experience to any survivors and fatigue to
 * attackers
 */
	for (unit = attackers.units; unit; unit = unit->same_side) {
		finalise_unit(&attackers, unit, attack_cmbt);
	}
	for (unit = defenders.units; unit; unit = unit->same_side) {
		finalise_unit(&defenders, unit, defense_cmbt);
	}
/*
 * Report spoils!
 */
	start_fold_string("Loot: ");
	sep = "";
	if (attackers.lost)
		distribute_spoils_to(&defenders, attackers.spoils);
	else if(defenders.lost)
		distribute_spoils_to(&attackers, attackers.spoils);
	free_carry_instance(attackers.spoils);
	if (defenders.lost)
		distribute_spoils_to(&attackers, defenders.spoils);
	else if(attackers.lost)
		distribute_spoils_to(&defenders, defenders.spoils);
	free_carry_instance(defenders.spoils);
	if (!*sep)
		add_fold_string("none.");
	else
		add_fold_char('.');
	print_folded(full_report, 6);
	print_folded(long_report, 6);
	print_folded(terse_report, 6);
/*
 * Finally, free units for next battle. All factions involved witnessed the
 * battle, survivors already have a full witness report.
 */
	free_all_soldiers();
/*
 * Litter the corpses around...
 */
}


/**
 ** INITIATE_ATTACK
 **	A unit is always attacked by another one
 **/
void initiate_attack(unit_s *attacker, unit_s *target)
{
unit_s	*unit;
/*
 * Quick 'n dirty
 */
	battle_location = attacker->true_location;
	printf("Battle at %s [%s]\n", battle_location->name, battle_location->id.text);

	sprintf(work, "%s [%s] attacks %s [%s]", attacker->name,
		attacker->id.text, target->name, target->id.text);

	location_visible_event(battle_location, today_number, work);
/*
 * Prepare the battle reports
 */
	battle_number++;
	sprintf(path_full , "battles/full.%d", battle_number);
	sprintf(path_long , "battles/report.%d", battle_number);
	sprintf(path_short , "battles/terse.%d", battle_number);
	if ((full_report = fopen(path_full, "w")) == 0) {
		perror(path_full);
		exit(1);
	}
	if ((long_report = fopen(path_long, "w")) == 0) {
		perror(path_long);
		exit(1);
	}
	if ((terse_report = fopen(path_short, "w")) == 0) {
		perror(path_short);
		exit(1);
	}
/*
 * Battle occurs
 */
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	start_fold_string("Battle at ");
	add_fold_string(battle_location->name);
	add_fold_tag(&battle_location->id);
	add_fold_string(" on day ");
	add_fold_integer(today_number);
	add_fold_string(" of the month.");
	print_folded(full_report, 0);
	print_folded(long_report, 0);
	print_folded(terse_report, 0);
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
/*
 * Who will gets a report or become involved?
 */
	who_is_present(battle_location);
/*
 * Add witnesses to the battle
 */
        sprintf(work, "Battle at %s [%s].", battle_location->name,
                battle_location->id.text);
	for (unit = battle_location->interacting; unit; unit = unit->next_visible)
	    if(!unit->is_captive)
		witnesses(unit->faction, path_long, work);

	battle_engagement(attacker, target, 0);
	run_battle(0);
	aftermath();
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	fclose(full_report);
	fclose(long_report);
	fclose(terse_report);
#ifdef DYNAMIC_ECONOMY
	battle_location->economy -= 100;
#endif
}


#ifdef FX_AMBUSH
/**
 ** INITIATE_AMBUSH
 **	This is similar to a battle, but involves chiefly two units.
 **/
void initiate_ambush(unit_s *killer, unit_s *target)
{
unit_s	*unit;
/*
 * Quick 'n dirty
 */
	battle_location = killer->true_location;
	all_capture_target=1;
	printf("Ambush at %s [%s]\n", battle_location->name, battle_location->id.text);

	sprintf(work, "%s [%s] ambushes %s [%s]", killer->name,
		killer->id.text, target->name, target->id.text);
	location_visible_event(battle_location, today_number, work);
/*
 * Prepare the battle reports
 */
	battle_number++;
	sprintf(path_full , "battles/full.%d", battle_number);
	sprintf(path_long , "battles/report.%d", battle_number);
	sprintf(path_short , "battles/terse.%d", battle_number);
	if ((full_report = fopen(path_full, "w")) == 0) {
		perror(path_full);
		exit(1);
	}
	if ((long_report = fopen(path_long, "w")) == 0) {
		perror(path_long);
		exit(1);
	}
	if ((terse_report = fopen(path_short, "w")) == 0) {
		perror(path_short);
		exit(1);
	}
/*
 * Battle occurs
 */
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	start_fold_string("Ambush at ");
	add_fold_string(battle_location->name);
	add_fold_tag(&battle_location->id);
	add_fold_string(" on day ");
	add_fold_integer(today_number);
	add_fold_string(" of the month.");
	print_folded(full_report, 0);
	print_folded(long_report, 0);
	print_folded(terse_report, 0);
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
/*
 * Who will gets a report or become involved?
 */
	who_is_present(battle_location);

	/* Add witnesses to the battle */
	sprintf(work, "Ambush at %s [%s].", battle_location->name,
		battle_location->id.text);
	for (unit = battle_location->interacting; unit && !unit->is_captive;
	     unit = unit->next_visible)
	    witnesses(unit->faction, path_long, work);

	battle_engagement(killer, target, 1);
	run_battle(1);
	aftermath();
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	fclose(full_report);
	fclose(long_report);
	fclose(terse_report);
#ifdef DYNAMIC_ECONOMY
	battle_location->economy -= 50;
#endif
	all_capture_target=0;
}
#endif
