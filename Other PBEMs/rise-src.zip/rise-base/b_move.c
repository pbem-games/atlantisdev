/* $Id: b_move.c,v 1.9 2000/09/10 17:51:47 jtraub Exp $
 *	Battle module: Process movements
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"


/**
 ** Placeholder
 **/
static char	tt;

/**
 ** FIGURE_MOVES
 **
 **/
int figure_moves(figure_s *figure)
{
	if(!figure || !figure->unit) return 0;
	compute_stack_capacity(figure->unit);
	/* Is the unit flying? */
	if(figure->unit->weight <= figure->unit->capacity[2])
		return 3;
	/* Is the unit riding */
	if(figure->unit->weight <= figure->unit->capacity[1])
		return 2;
	/* Nope.. walk */
	return 1;
}

/**
 ** UNIT_AWAY
 **	Unit has moved away from its location
 **/
void unit_away(figure_s *unit)
{
square_s	*move_from;
figure_s	*last, *on_loc;
/*
 * Where do we move from?
 */
	move_from = &battlefield[(int)unit->rank][(int)unit->file];
	last = 0;
	if (unit->offense) {
		for (on_loc = move_from->attackers; on_loc; on_loc = on_loc->same_square)
			if (on_loc == unit)
				break;
			else
				last = on_loc;
		if (on_loc) {
			if (last)
				last->same_square = unit->same_square;
			else
				move_from->attackers = unit->same_square;
		}
	} else {
		for (on_loc = move_from->defenders; on_loc; on_loc = on_loc->same_square)
			if (on_loc == unit)
				break;
			else
				last = on_loc;
		if (on_loc) {
			if (last)
				last->same_square = unit->same_square;
			else
				move_from->defenders = unit->same_square;
		}
	}
}


/**
 ** ATTEMPT_MOVE
 **	The unit attempts to move to a specific rank and file
 **/
static int attempt_move(figure_s *unit, int rank, int file)
{
square_s	*move_to;
/*
 * Make sure we don't move out of the battlefield!
 */
	if (rank < 0 || rank > 5 || file < 0 || file > 2)
		return 0;
/*
 * Where do we move to?
 */
	move_to = &battlefield[rank][file];
	if (unit->offense) {
#ifdef FX_BIT_WALKTHRU
		if (move_to->defenders && !(unit->pending_effects & FX_BIT_WALKTHRU))
#else
		if (move_to->defenders)
#endif
			return 0;
		unit_away(unit);
		unit->same_square = move_to->attackers;
		move_to->attackers = unit;
	} else {
#ifdef FX_BIT_WALKTHRU
		if (move_to->attackers && !(unit->pending_effects & FX_BIT_WALKTHRU))
#else
		if (move_to->attackers)
#endif
			return 0;
		unit_away(unit);
		unit->same_square = move_to->defenders;
		move_to->defenders = unit;
	}
/*
 * Unit has moved!
 */
	unit->fleeing = 0;
	unit->rank = rank;
	unit->file = file;
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("[%s] move to %d/%d\n", unit->unit->id.text, rank, file);
#endif
	start_fold_unit_segment(unit);
	add_fold_string("move to ");
	if (rank > 2) {
		rank = 5 - rank;
		file = 2 - file;
		add_fold_string("defender's ");
	} else
		add_fold_string("attacker's ");
	add_fold_string(visual_enum(rank, battlefield_ranks));
	add_fold_char(' ');
	add_fold_string(visual_enum(file, battlefield_files));
	print_folded(full_report, 5);
	print_folded(long_report, 5);
	return 1;
}


/**
 ** MOVE_AT_RANDOM
 **	Unit is confused, and moves at random, even if engaging a target!
 **/
int move_at_random(figure_s *unit)
{
int	dir, i;
/*
 * Start in one random direction
 */
	dir = roll_1Dx(4);
	for (i = 0; i < 4; i++) {
		switch (dir & 3) {
		    case 0:
			if (attempt_move(unit, unit->rank, unit->file-1))
				return 1;
			break;
		    case 1:
			if (attempt_move(unit, unit->rank+1, unit->file))
				return 1;
			break;
		    case 2:
			if (attempt_move(unit, unit->rank, unit->file+1))
				return 1;
			break;
		    case 3:
			if (attempt_move(unit, unit->rank-1, unit->file))
				return 1;
			break;
		}
		dir++;
	}
	return 0;
}


/**
 ** MOVE_RETREAT
 **	The unit attempts to move back one rank if possible.
 ** If not, it attempts to move to the flank that has the least enemies.
 **/
int battle_move_retreat(figure_s *unit)
{
int	left_flank, right_flank;
int	rank;
/*
 * Move ranks?
 */
	left_flank = right_flank = 0;
	if (unit->offense) {
		if (unit->rank) {
			unit->fleeing = 0;
			if (attempt_move(unit, unit->rank-1, unit->file))
				return 1;
		}
		for (rank = 5; rank >= 0; rank--) {
			if (battlefield[rank][0].defenders)
				left_flank = rank;
			if (battlefield[rank][2].defenders)
				right_flank = rank;
		}
	} else {
		if (unit->rank < 5) {
			unit->fleeing = 0;
			if (attempt_move(unit, unit->rank+1, unit->file))
				return 1;
		}
		for (rank = 0; rank < 6; rank++) {
			if (battlefield[rank][0].attackers)
				left_flank = 6-rank;
			if (battlefield[rank][2].attackers)
				right_flank = 6-rank;
		}
	}
/*
 * Fanatic no longer retreat
 */
	if (unit->fanatic)
		unit->movement = unit->unit->movement;
/*
 * Count in each rank, and move. If centered and equal forces, move to random flank
 */
	if (left_flank < right_flank) {
		if (unit->file)
			return attempt_move(unit, unit->rank, unit->file-1);
	} else
		if (left_flank > right_flank) {
			if (unit->file < 2)
				return attempt_move(unit, unit->rank, unit->file+1);
		} else
			if (unit->file == 1) {
				if (roll_1Dx(2) == 0)
					return attempt_move(unit, unit->rank, 0);
				else
					return attempt_move(unit, unit->rank, 2);
			}
	return 0;
}


/**
 ** MOVE_ADVANCE
 **	The unit attempts to move forward one rank if possible.
 **/
static int move_advance(figure_s *unit)
{
/*
 * Move ranks?
 */
	if (unit->offense) {
		if (unit->rank < 5)
			return attempt_move(unit, unit->rank+1, unit->file);
	} else {
		if (unit->rank)
			return attempt_move(unit, unit->rank-1, unit->file);
	}
	return 0;
}


/**
 ** MOVE_SWEEP
 **	The unit attempts to move forward one rank if no other targets exits.
 ** It moves toward the center if possible too.
 **/
static int move_sweep(figure_s *unit)
{
/*
 * Common move: center if possible
 */
	if (unit->file != 1) {
		return attempt_move(unit, unit->rank, 1);
	}
/*
 * Move ranks? Only if no one adjacent!
 */
	if (unit->offense) {
		if (battlefield[(int)unit->rank][0].defenders ||
		    battlefield[(int)unit->rank][2].defenders)
			return 0;
		if (unit->rank < 5)
			return attempt_move(unit, unit->rank+1, unit->file);
	} else {
		if (battlefield[(int)unit->rank][0].attackers ||
		    battlefield[(int)unit->rank][2].attackers)
			return 0;
		if (unit->rank)
			return attempt_move(unit, unit->rank-1, unit->file);
	}
	return 0;
}


/**
 ** MOVE_FIRE_RANGE
 **	The unit attempts to move forward, keeping within range 2. It will also
 ** try to move backward if engaged!
 **/
static int move_fire_range(figure_s *unit, int retreat)
{
/*
 * First, we fall back if defenders close in.
 */
	if (unit->offense) {
		if (unit->rank == 5)
			return attempt_move(unit, unit->rank-1, unit->file);
		if ((battlefield[(int)unit->rank+1][(int)unit->file].defenders) ||
		    (unit->file && battlefield[(int)unit->rank][(int)unit->file-1].defenders) ||
		    (unit->file < 2 && battlefield[(int)unit->rank][(int)unit->file+1].defenders) )
			return battle_move_retreat(unit);
/*
 * Next, if we're in range, stop there.
 */
		if (unit->rank < 4 && battlefield[(int)unit->rank+2][(int)unit->file].defenders)
			return 0;
		else
			switch (unit->file) {
			    case 0:
				if (battlefield[(int)unit->rank+1][(int)unit->file+1].defenders ||
				    battlefield[(int)unit->rank][(int)unit->file+2].defenders)
					return 0;
				break;
			    case 1:
				if (battlefield[(int)unit->rank+1][(int)unit->file-1].defenders ||
				    battlefield[(int)unit->rank+1][(int)unit->file+1].defenders)
					return 0;
				break;
			    case 2:
				if (battlefield[(int)unit->rank+1][(int)unit->file-1].defenders ||
				    battlefield[(int)unit->rank][(int)unit->file-2].defenders)
					return 0;
				break;
			}
/*
 * Then, if no one in range, we center, then advance.
 */
		if (unit->file != 1)
			return attempt_move(unit, unit->rank, 1);
		else
			if (unit->rank < 4)
				return attempt_move(unit, unit->rank+1, unit->file);
/*
 * For defenders, the signs are reversed
 */
	} else {
		if (unit->rank == 0)
			return attempt_move(unit, unit->rank+1, unit->file);
		if ((battlefield[(int)unit->rank-1][(int)unit->file].attackers) ||
		    (unit->file && battlefield[(int)unit->rank][(int)unit->file-1].attackers) ||
		    (unit->file < 2 && battlefield[(int)unit->rank][(int)unit->file+1].attackers) )
			return battle_move_retreat(unit);
/*
 * Next, if we're in range, stop there.
 */
		if (unit->rank > 1 && battlefield[(int)unit->rank-2][(int)unit->file].attackers)
			return 0;
		else
			switch (unit->file) {
			    case 0:
				if (battlefield[(int)unit->rank-1][(int)unit->file+1].attackers ||
				    battlefield[(int)unit->rank][(int)unit->file+2].attackers)
					return 0;
				break;
			    case 1:
				if (battlefield[(int)unit->rank-1][(int)unit->file-1].attackers ||
				    battlefield[(int)unit->rank-1][(int)unit->file+1].attackers)
					return 0;
				break;
			    case 2:
				if (battlefield[(int)unit->rank-1][(int)unit->file-1].attackers ||
				    battlefield[(int)unit->rank][(int)unit->file-2].attackers)
					return 0;
				break;
			}
/*
 * Then, if no one in range, we center, then advance.
 */
		if (unit->file != 1)
			return attempt_move(unit, unit->rank, 1);
		else
			if (unit->rank > 1)
				return attempt_move(unit, unit->rank-1, unit->file);
	}
	return 0;
}


/**
 ** ANY_TARGET
 **	Simple checker
 **/
static int any_target(int rank, int file, int leader)
{
figure_s	*figs;
/*
 * Out of bounds?
 */
	if (rank < 0 || rank > 5 || file < 0 || file > 2)
		return 0;
	if (tt)
		figs = battlefield[rank][file].defenders;
	else
		figs = battlefield[rank][file].attackers;
/*
 * Leaders only?
 */
	if (leader) {
		while (figs)
			if (figs && figs->living && figs->race->type == RACE_LEADER)
				break;
			else
				figs = figs->same_square;
	}
/*
 * Any target spotted
 */
	if (figs)
		return 1;
	return 0;
}


/**
 ** MOVE_NEAREST
 **	Move toward the nearest enemy unit.
 ** This function is perfectly identical for attackers & defenders
 **/
static int move_nearest(figure_s *unit, int leader)
{
/*
 * First, do we move, or do we have things to clean up :)
 */
	tt = unit->offense;
	if (any_target(unit->rank-1, unit->file, leader) ||
	    any_target(unit->rank, unit->file+1, leader) ||
	    any_target(unit->rank, unit->file-1, leader) ||
	    any_target(unit->rank+1, unit->file, leader))
		return 0;
/*
 * Nothing here. Move toward range 2?
 */
	if (any_target(unit->rank, unit->file-2, leader) ||
	    any_target(unit->rank-1, unit->file-1, leader))
		return attempt_move(unit, unit->rank, unit->file-1);
	if (any_target(unit->rank+1, unit->file-1, leader) ||
	    any_target(unit->rank+2, unit->file, leader))
		return attempt_move(unit, unit->rank+1, unit->file);
	if (any_target(unit->rank+1, unit->file+1, leader) ||
	    any_target(unit->rank, unit->file+2, leader))
		return attempt_move(unit, unit->rank, unit->file+1);
	if (any_target(unit->rank-1, unit->file+1, leader) ||
	    any_target(unit->rank-2, unit->file, leader))
		return attempt_move(unit, unit->rank-1, unit->file);
/*
 * Nothing either. Move front or back?
 */
	if (any_target(unit->rank+1, unit->file-2, leader) ||
	    any_target(unit->rank+2, unit->file-1, leader) ||
	    any_target(unit->rank+3, unit->file, leader) ||
	    any_target(unit->rank+2, unit->file+1, leader) ||
	    any_target(unit->rank+1, unit->file+2, leader))
		return attempt_move(unit, unit->rank+1, unit->file);
	if (any_target(unit->rank-1, unit->file-2, leader) ||
	    any_target(unit->rank-2, unit->file-1, leader) ||
	    any_target(unit->rank-3, unit->file, leader) ||
	    any_target(unit->rank-2, unit->file+1, leader) ||
	    any_target(unit->rank-1, unit->file+2, leader))
		return attempt_move(unit, unit->rank-1, unit->file);
/*
 * Range is now 4. We're a long way from our target...
 */
	if (any_target(unit->rank+2, unit->file-2, leader) ||
	    any_target(unit->rank+3, unit->file-1, leader) ||
	    any_target(unit->rank+4, unit->file, leader) ||
	    any_target(unit->rank+3, unit->file+1, leader) ||
	    any_target(unit->rank+2, unit->file+2, leader))
		return attempt_move(unit, unit->rank+1, unit->file);
	if (any_target(unit->rank-2, unit->file-2, leader) ||
	    any_target(unit->rank-3, unit->file-1, leader) ||
	    any_target(unit->rank-4, unit->file, leader) ||
	    any_target(unit->rank-3, unit->file+1, leader) ||
	    any_target(unit->rank-2, unit->file+2, leader))
		return attempt_move(unit, unit->rank-1, unit->file);
/*
 * After range 5, there's magic: If we're on attacker side, there's no one
 * behind us, so we advance. If we're on defender side, there's no one in
 * front, so we move back.
 */
	/*** HACK ***/
	if (unit->rank < 3)
		return attempt_move(unit, unit->rank+1, unit->file);
	else
		return attempt_move(unit, unit->rank-1, unit->file);
	return 0;
}


/**
 ** MOVE_TOWARD_RANK
 **	Move across the ranks toward a specific target
 **/
static int move_toward_rank(figure_s *unit, figure_s *target)
{
	if (unit->rank > target->rank)
		return attempt_move(unit, unit->rank-1, unit->file);
	return attempt_move(unit, unit->rank+1, unit->file);
}


/**
 ** MOVE_TOWARD_FILE
 **	Move across the files toward a specific target
 **/
static int move_toward_file(figure_s *unit, figure_s *target)
{
	if (unit->file > target->file)
		return attempt_move(unit, unit->rank, unit->file-1);
	return attempt_move(unit, unit->rank, unit->file+1);
}


/**
 ** MOVE_TOWARD
 **	Move toward a specific target
 **/
static int move_toward(figure_s *unit, figure_s *target)
{
int	dx, dy;
/*
 * Simple cases
 */
	dx = unit->file - target->file;
	if (dx == 0)
		return move_toward_rank(unit, target);
/*
 * Same with ranks
 */
	dy = unit->rank - target->rank;
	if (dy == 0)
		return move_toward_file(unit, target);
/*
 * Which is larger?
 */
	if (dx < 0)
		dx = -dx;
	if (dy < 0)
		dy = -dy;
	if (dx < dy) {
		if (move_toward_rank(unit, target))
			return 1;
		return move_toward_file(unit, target);
	}
	if (dx > dy || (dx == dy && roll_1Dx(2) == 0)) {
		if (move_toward_file(unit, target))
			return 1;
		return move_toward_rank(unit, target);
	}
	if (move_toward_rank(unit, target))
		return 1;
	return move_toward_file(unit, target);
}


/**
 ** MOVE_SOLDIER
 **	One unit moves
 **/
int move_soldier(figure_s *unit, char intent)
{
figure_s	*target;
int		range;
/*
 * Unit has moved now
 */
	unit->has_moved = 1;

	if(unit->fear) {
		unit->fear--;
		return battle_move_retreat(unit);
	}

	switch (unit->movement) {
	    case BATTLEFIELD_MOVE_FLEE:
		unit->fleeing++;
		return battle_move_retreat(unit);
	    default:
/*
 * Move toward the selected target. May stop when in range, or continue
 */
		target = unit->last_target;
		if(!target) {
			return 0;
		}
		if (target->rank > unit->rank)
			range = target->rank - unit->rank;
		else
			range = unit->rank - target->rank;
		if (target->file > unit->file)
			range += target->file - unit->file;
		else
			range += unit->file - target->file;
		switch (intent) {
		    case COMBAT_SET_GUARD:
			return 0;
		    case COMBAT_SET_DEFAULT:
		    case COMBAT_SET_ONCE:
			if (unit->global.missile >= unit->global.melee) {
				if (range > unit->max_range)
					return move_toward(unit, target);
				break;
			}
		    default:
			if (range > 1)
				return move_toward(unit, target);
			break;
		    case COMBAT_SET_RANGED:
			if (range > unit->max_range)
				return move_toward(unit, target);
		}
	}
	return 0;
}
