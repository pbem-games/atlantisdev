/* $Id: b_round.c,v 1.27 2001/02/05 04:24:35 jtraub Exp $
 *	Battle module: Process rounds
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"
#include "parser.h"


/**
 ** Locally set variables
 **/
int			observation_round;
int			initiative_level;
int			round_number;
char			unit_acted;


/**
 ** FIGURE_POSSESSIONS
 **	Figure possess the given object!
 **/
carry_s *figure_possessions(figure_s *unit, item_s *item)
{
carry_s	*has, *previous;
/*
 * Go
 */
	if (!item) abort();
	previous = 0;
	for (has = unit->using; has; has = has->next)
		if (has->item == item)
			return has;
		else
			previous = has;
	return has;
}


/**
 ** COMPUTE_BATTLE_STATS
 **	Compute the appropriate stats value at the start of a battle round
 **/
void compute_battle_stats(figure_s *figure, int reinit)
{
experience_s	*skill;
skill_s		*known;
carry_s		*load;
item_s		*kind;
unit_s		*unit;
actor_s		*actors;
int		size, equipped;
#ifdef BATTLE_INITIATIVE
int		battles;
int		penalty;
int		men, beasts;
actor_s *has_trebuch = 0;
carry_s *has_pali;
static item_s *cache_pali;
#endif

	if(!cache_pali) {
		synthetic_tag("pali");
		cache_pali = item_from_tag(0);
	}
/*
 * Compute stats
 */
	unit = figure->unit;
#ifdef BATTLE_INITIATIVE
	battles = unit->num_battles;
	penalty = 0;
#endif
	men = 0;
	beasts = 0;
	if (unit->race->type == RACE_LEADER)
		size = 1;
	else
		size = 0;
	if (!figure->race || !size) {
		memset(&figure->vital, 0, sizeof(figure->vital));
		memset(&figure->add, 0, sizeof(figure->add));
	}
	figure->vital  = figure->race->intrinsic;
	if(unit->race->type != RACE_LEADER) {
		figure->vital.hits--;
		figure->vital.damage--;
	}
#ifdef FX_HEAVINESS
	figure->vital.melee   -= figure->heavy_penalty * 2;
	figure->vital.defense -= figure->heavy_penalty;
	figure->vital.missile -= figure->heavy_penalty;
#endif
	figure->vital.melee   += figure->bonus.melee;
	figure->vital.defense += figure->bonus.defense;
	figure->vital.missile += figure->bonus.missile;
	figure->vital.life    += figure->bonus.life;
	figure->vital.damage  += figure->bonus.damage;
	figure->vital.hits    += figure->bonus.hits;
#ifdef BATTLE_INITIATIVE
	figure->vital.initiative += figure->bonus.initiative;
#ifdef FX_HEAVINESS
	figure->vital.initiative -= figure->heavy_penalty;
#endif
#endif
#ifdef STEALTH_STATS
        figure->vital.stealth += figure->bonus.stealth;
        figure->vital.observation += figure->bonus.observation;
#endif
#ifdef USES_MANA_POINTS
        figure->vital.mana    += figure->bonus.mana;
#endif
/*
 * Flying units have a bonus to initiative
 */
	if (figure->flying)
		figure->vital.initiative += 2;
/*
 * Apply skill knowledge
 */
	for (skill = unit->skilled; skill; skill = skill->next)
		if ((known = skill->effective) != 0) {
			add_to_stats(&figure->vital, &known->bonus);
/*
 * Factor in "dread" factor
 */
#ifdef STEALTH_STATS
			if (known->combat_action.bonus.stealth && !known->combat_action.effect)
				unit->vital.stealth += known->combat_action.bonus.stealth;
#endif
		}
/*
 * Add equipment bonus
 */
	for (load = figure->using; load; load = load->next) {
		if ((kind = load->item)->item_type == ITEM_DAYS) {
			add_to_stats(&figure->vital, &kind->equip_bonus);
			continue;
		}
		if (load->amount == 0)
			continue;
		if (load->amount > size)
			load->amount = size;
		if (load->equipped > size)
			load->equipped = size;
		if (reinit)
			load->equipped = load->amount;
		if ((equipped = load->equipped) != 0)
			add_proportional_stats(&figure->vital, &kind->equip_bonus, equipped, size);
	}
/*
 * Add actors potential
 */
	figure->global = figure->vital;
	for (actors = figure->autonomous; actors; actors = actors->next) {
		if (actors->trebuch) {
			has_trebuch = actors;
			actors->amount = 0;
		}
		if (actors->actor) {
			if(actors->actor->item_type == ITEM_FOLLOWER) {
				men += actors->amount;
			}
			if(actors->actor->item_type == ITEM_BEAST) {
				beasts += actors->amount;
			}
			add_multiple_stats(&figure->global, &actors->vitals, actors->amount);
			/*figure->global.initiative -= actors->vitals.initiative*actors->amount; */
			add_multiple_stats(&figure->add, &actors->vitals, actors->amount);
		    figure->add.initiative = 0;
			actors->modified = actors->vitals;
			if(!actors->modified.hits)
				actors->modified.hits = 1;
			if(!actors->modified.damage)
				actors->modified.damage= 1;
		} else {
			men++;
			actors->vitals = figure->vital;
			actors->modified = actors->vitals;
			if (actors->vitals.missile)
				actors->acts.range = 2;
			else
				actors->acts.range = 1;
		}
	}
	/*figure->vital = figure->global;*/
#ifdef BATTLE_INITIATIVE
	figure->vital.initiative = figure->global.initiative;
	penalty = men * battles;
	figure->vital.initiative -= penalty;
	figure->global.initiative -= penalty;
	if(figure->side->burden) {
		figure->vital.initiative -= beasts;
		figure->global.initiative -= beasts;
	}
#endif
	figure->vital.upkeep = 0;
	figure->add.upkeep = 0;

	figure->men = men;
	figure->beasts = beasts;

	has_pali = unit_possessions(figure->unit, cache_pali, 0);
	if(has_pali) {
		add_multiple_stats(&figure->global, &has_pali->item->equip_bonus,
				has_pali->amount);
		add_multiple_stats(&figure->add, &has_pali->item->equip_bonus,
				has_pali->amount);
		figure->add.initiative = 0;
		figure->add.life -= has_pali->amount;
		figure->vital.initiative = figure->global.initiative;
	}

	if(has_trebuch) {
		int amt = has_trebuch->original->amount;
		if(figure->men/3 < amt) amt = figure->men/3;
		has_trebuch->amount = amt;
		has_trebuch->acted = amt;
		add_multiple_stats(&figure->global, &has_trebuch->vitals,
				has_trebuch->amount);
		add_multiple_stats(&figure->add, &has_trebuch->vitals,
				has_trebuch->amount);
		figure->add.initiative = 0;
		figure->add.life -= has_trebuch->amount;
		/*hack2*/
		figure->vital.initiative = figure->global.initiative;
		has_trebuch->modified = has_trebuch->vitals;
		if(!has_trebuch->modified.hits)
			has_trebuch->modified.hits = 1;
		if(!has_trebuch->modified.damage)
			has_trebuch->modified.damage= 1;
	}
}


/**
 ** INITIATIVE_SEGMENT
 **	Rounds are further sub-divided into various segments!
 **/
static void initiative_segment(void)
{
figure_s	*next;
figure_s	*unit;
/*
 * We are running at this initiative level
 */
#ifdef BATTLE_INITIATIVE
	initiative_level = acting_units->current_init;
#endif
/*
 * What action, if any
 */
	for (unit = acting_units; unit; unit = next) {
#ifdef BATTLE_INITIATIVE
		if (unit->current_init < initiative_level)
			break;
#endif
		next = unit->next_initiative;
		if (unit->last_target && (unit->last_target->living <= 0 || unit->last_target->fled))
			unit->last_target = 0;
		while (unit_may_act(unit))
			;
		if (next && next->has_acted)
			break;
	}
/*
 * Initiative segment has ended, tally losses. Units had a last chance to
 * strike against their foes.
 */
	for (unit = acting_units; unit; unit = next) {
		next = unit->next_initiative;
		if (unit->living <= 0) {
#ifdef TRACING_REQUIRED
			if(unit->unit->traced_unit) {
				sprintf(work, "Unit %s [%s] -- living was %d.\n",
					unit->unit->name, unit->unit->id.text,
					unit->living);
				printf("%s", work);
				start_fold_string(work);
				print_folded(full_report, 5);
			}
#endif
			unit_away(unit);
			unit->living = 0;
			unit_has_acted(unit);
		}
	}
}


/**
 ** ACTIVATE_THIS_UNIT
 **	One unit joins the rank of activated units
 **/
static void activate_this_unit(figure_s *unit)
{
figure_s	*last, *insert;
combat_set_s	*actions;
unit_s		*real;
experience_s	*knows;
carry_s		*holds;
actor_s		*actors;
int		i;
#ifdef BATTLE_INITIATIVE
int		upper, base, value;
#endif
/*
 * Dead units do not activate, nor fled units
 */
	if (unit->prisoner) {
		return;
	}

	if(unit->retreat) {
		if(unit->unit->traced_unit) {
			printf("Round %d: Checking for retreated unit '%s'\n",
			       round_number, unit->unit->id.text);
		}
		if(unit->rank == 0 && unit->side == &attackers) unit->fled++;
		if(unit->rank == 5 && unit->side == &defenders) unit->fled++;
		if(unit->unit->traced_unit && unit->fled) {
			printf("Round %d: '%s' successfully fled battle\n",
			       round_number, unit->unit->id.text);
		}
		if(unit->fled) return;
	}

	if (unit->living <= 0) {
		if(unit->unit->traced_unit) {
			printf("Round %d: '%s' flees due to living <= 0\n",
			       round_number, unit->unit->id.text);
		}
		unit->fleeing++;
		return;
	}
	if (unit->fleeing >= 3) {
		if(unit->unit->traced_unit) {
			printf("Round %d: '%s' successfully flees battle\n",
			       round_number, unit->unit->id.text);
		}
		unit->fled++;
		return;
	}
#ifdef FX_BLACK_AURA
	if (unit->black_aura > 0)
		unit->black_aura--;
#endif
#ifdef FX_HEAVINESS
	if (unit->heavy > 0)
		unit->heavy--;
#endif
#ifdef FX_BATTLE_CONFUSED
	unit->friend_or_foe = 0;
#endif
	compute_battle_stats(unit, 1);
	unit->modified = unit->vital;
	unit->modified.initiative += battlefield[(int)unit->rank][(int)unit->file].round_modifiers.initiative;
	unit->modified.initiative += battlefield[(int)unit->rank][(int)unit->file].battle_modifiers.initiative;
	real = unit->unit;
/*
 * If the unit has mana power, and we're not on the starting round, then one
 * mana is regained each round!
 */
#ifdef USES_MANA_POINTS
	if (real->vital.mana) {
		if (!real->power)
			real->power = unit_possessions(real, item_mana, 1);
		if (real->power->amount < real->vital.mana)
			real->power->amount++;
	}
#endif
	unit->pending_effects = unit->permanent_effects;
/*
 * Actions
 */
	if (unit->reloading) {
		unit->reloading--;
		unit->mandated.option = COMBAT_SET_RELOAD;
		unit->considered = &unit->mandated;
	} else {
/*
 * Make sure all actions are allowed
 */
		unit->mandated.option = 0;
		unit->considered = unit->actions;
		for (actions = unit->actions; actions->option; actions++) {
			actions->skill_used = 0;
			switch (actions->option) {
			    case COMBAT_SET_SKILL:
				if (!(knows = unit_experiences(real, actions->u.use_skill, 0)) ||
				    !knows->effective)
					actions->disabled = 1;
				break;
			    case COMBAT_SET_ITEM:
				if (!(holds = figure_possessions(unit, actions->u.use_item)) ||
				    !holds->equipped)
					actions->disabled = 1;
				else
					actions->disabled = 0;
				break;
			}
		}
	}
	unit->repeating = 0;
#ifdef BATTLE_INITIATIVE
	/* base = unit->vital.initiative + unit->add.initiative + unit->side->tactician + unit->side->strategist +
		unit->tactical_bonus; */
	 base = unit->modified.initiative + unit->side->tactician +
		 unit->side->strategist + unit->tactical_bonus;
	if (unit->tactical_bonus > 0)
		unit->tactical_bonus--;
	else
		if (unit->tactical_bonus < 0)
		unit->tactical_bonus++;
	unit->mandated.initiative = base - 1;
	upper = 999;
	for (i = 0; i < MAX_COMBAT_SETTING; i++) {
		switch(unit->actions[i].option) {
		    case COMBAT_SET_RELOAD:
			value = base - 1;
			break;
		    case COMBAT_SET_SKILL:
			value = base + unit->actions[i].u.use_skill->combat_action.bonus.initiative;
			break;
		    case COMBAT_SET_ITEM:
			value = base + unit->actions[i].u.use_item->combat_action.bonus.initiative;
			break;
		    default:
			value = base;
		}
		if (value > upper)
			value = upper;
		unit->actions[i].initiative = value;
		upper = value;
	}
	value = unit->considered->initiative;
	unit->current_init = value;
/*
 * Insertion sort
 */
	last = 0;
	for (insert = acting_units; insert; insert = insert->next_initiative)
		if (insert->current_init < value)
			break;
		else
			last = insert;
	if (insert)
		insert->prev_initiative = unit;
	unit->next_initiative = insert;
	if (last)
		last->next_initiative = unit;
	else
		acting_units = unit;
	unit->prev_initiative = last;
#else /* not BATTLE_INITIATIVE */
	if ((unit->next_initiative = acting_units) != 0)
		acting_units->prev_initiative = unit;
	unit->prev_initiative = 0;
	acting_units = unit;
#endif
/*
 * Unit hasn't done anything yet
 */
#ifdef FX_HEAVINESS
	if (unit->heavy)
		unit->has_moved = 1;
	else
#endif
	unit->has_moved = 0;
	unit->has_acted = 0;
	unit->has_waited = 0;
	unit->active = 0;
	if (unit->vital.missile)
		unit->max_range = 2;
	else
		unit->max_range = 1;
	for (actors = unit->autonomous; actors; actors = actors->next) {
		actors->acted = actors->amount;
		if (actors->modified.hits)
			actors->acted *= actors->modified.hits;
		actors->living = actors->amount;
		if (actors->acts.range > unit->max_range)
			unit->max_range = actors->acts.range;
		unit->active += actors->amount;
	}
	unit->combat_exp++;
}

/**
 ** PROCESS_FREE_MOVES
 **    We get a free round of moves for ambush
 **/
static void process_free_moves(void)
{
    figure_s *unit;
    int i, j, moves, moved;

    acting_units = 0;
    for (unit = attackers.units; unit; unit = unit->same_side)
	activate_this_unit(unit);

    for (i = 0; i < 6; i++)
	for (j = 0; j < 3; j++)
	    memset(&battlefield[i][j].round_modifiers, 0, sizeof(stats_s));

    fprintf(full_report, "Ambush Movement Round:\n");
    fprintf(long_report, "Ambush Movement Round:\n");
    fprintf(terse_report, "Ambush Movmeent Round:\n");
    for(unit = acting_units; unit; unit = unit->next_initiative) {
		initiative_level = unit->current_init;
		unit_pick_target(unit);
		moves = figure_moves(unit);
		moved = 1;
		while(moves && moved) {
			moved = move_soldier(unit, unit->considered->option);
			moves--;
		}
    }
    putc('\n', terse_report);
    putc('\n', full_report);
    putc('\n', long_report);
}

void battle_fog_cover(side_s *side)
{
	side_s *other = side->opposing;
	figure_s *fig;
	int val = -999999;
	int found = 0;
	if(side->fogger) {
		side->fogger->fog_rounds--;
		if(!side->fogger->fog_rounds) {
			side->fogger = NULL;
		}
        for(fig = side->units; fig; fig = fig->same_side) {
			if(!fig->living) continue;
			if(fig->captor) continue;
			if(fig->current_init > val) {
				val = fig->current_init;
				found = 1;
			}
		}
		if(found) {
			for(fig = other->units; fig; fig = fig->same_side) {
				if(!fig->living) continue;
				if(fig->captor) continue;
				if(fig->has_acted) continue;
				if(fig->current_init > val) {
					int diff = fig->current_init - val + 1;
					combat_set_s *c;
					fig->current_init -= diff;
					for(c = fig->considered; c->option; c++)
						c->initiative -= diff;
					fig->mandated.initiative -= diff;
					battle_delay_processing(fig);
				}
			}
		}
	}
	return;
}

/**
 ** PROCESS_ONE_ROUND
 **	We process one round in two steps: First, we sort by
 ** initiative. Then, we run each initiative segment
 **/
static void process_one_round(void)
{
figure_s	*unit;
int		i, j;
/*
 * Create the list of acting units. Only live units are considered
 */
	acting_units = 0;
	for (unit = attackers.units; unit; unit = unit->same_side)
		activate_this_unit(unit);
	for (unit = defenders.units; unit; unit = unit->same_side)
		activate_this_unit(unit);
	for (i = 0; i < 6; i++)
		for (j = 0; j < 3; j++)
			memset(&battlefield[i][j].round_modifiers, 0, sizeof(stats_s));
/*
 * Report heading
 */
	round_number++;
	observation_round++;
	fprintf(full_report, "Round %d:\n", round_number);
	fprintf(long_report, "Round %d:\n", round_number);
	fprintf(terse_report, "Round %d:\n", round_number);
#ifdef FX_STONE_HEADS
	attackers.stone_headed = 0;
	defenders.stone_headed = 0;
#endif

	/* Okay, handle the delay due to fogging */
	battle_fog_cover(&attackers);
	battle_fog_cover(&defenders);

/*
 * All units now start to move, then fight
 */
	while (acting_units) {
		unit_acted = 0;
		initiative_segment();
		if (attackers.size <= attackers.casualties  ||
		    defenders.size <= defenders.casualties)
			break;
	}
/*
 * Now sums the casualties, and check if battle ends now!
 */
	putc('\n', full_report);
	putc('\n', long_report);
	fprintf(terse_report, "Attacking casualties: %d\n", attackers.turn_casualties);
	if (attackers.turn_casualties) {
		fprintf(full_report, "Attacking casualties: %d\n", attackers.turn_casualties);
		fprintf(long_report, "Attacking casualties: %d\n", attackers.turn_casualties);
	}
	fprintf(terse_report, "Defending casualties: %d\n", defenders.turn_casualties);
	if (defenders.turn_casualties) {
		fprintf(full_report, "Defending casualties: %d\n", defenders.turn_casualties);
		fprintf(long_report, "Defending casualties: %d\n", defenders.turn_casualties);
	}
	attackers.turn_casualties = 0;
	defenders.turn_casualties = 0;
	putc('\n', terse_report);
	putc('\n', full_report);
	putc('\n', long_report);
/*
 * Decrease the amount of tactical advantage
 */
	if (attackers.tactician)
		attackers.tactician--;
	if (defenders.tactician)
		defenders.tactician--;
	fflush(full_report);
}


/**
 ** ROUT_ORDERS
 **	Rout orders are quite simple: all units except fanatics are
 ** switched to "flee", two-third have "parry" as order, the rest has
 ** none.
 **/
static void rout_orders(figure_s *unit)
{
/*int	parry; */
/*
 * Loop
 */
	while (unit) {
		if (!unit->fanatic) {
			unit->movement = 0; /* is flee */
			unit->retreat = 1;
/*
			parry = roll_1Dx(3);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
			if (unit->side->fate)
				parry |= roll_1Dx(3);
#endif
			if (parry) {
				unit->actions[0].option = 0;
				unit->actions[0].disabled = 0;
				unit->actions[0].avoid_action = 0;
				unit->actions[1].option = 0;
			} else
				unit->actions[0].option = 0;
*/
		}
		unit = unit->same_side;
	}
}


/**
 ** RUN_BATTLE
 **/
void run_battle(int ambush)
{
	figure_s *fig;
	int count = 0;
	int fled = 0;
/*
 * Rounds
 */
	round_number = 0;
	observation_round = 0;

	if(ambush)
	    process_free_moves();

	while (!attackers.lost && !defenders.lost && round_number < 100) {
		process_one_round();

/*
 * Battle ends in a tie?
 */
		if (observation_round >= 10) {
			fprintf(full_report, "No hits for 10 rounds...\n");
			fprintf(long_report, "No hits for 10 rounds...\n");
			fprintf(terse_report, "No hits for 10 rounds...\n");
			attackers.lost = 1;
			defenders.lost = 1;
			break;
		}
/*
 * Attackers are all dead? Or in rout?
 */
		if (attackers.casualties >= attackers.size) {
			attackers.lost = 1;
		} else
			if (attackers.rout <= 0) {
				attackers.routed = 1;
				rout_orders(attackers.units);
			}
/*
 * Defenders are all dead?
 */
		if (defenders.casualties >= defenders.size) {
			defenders.lost = 1;
		} else
			if (defenders.rout <= 0) {
				defenders.routed = 1;
				rout_orders(defenders.units);
			}

		fled = count = 0;
		/* check all units */
		for(fig = attackers.units; fig; fig = fig->same_side) {
			if((fig->living > 0) && !fig->prisoner) {
				count++;
				if(fig->fled) fled++;
				else if(fig->retreat && fig->rank == 0) fled++;
			}
		}
		if(fled && fled == count) {
			attackers.fled = 1;
			attackers.lost = 1;
		}
		fled = count = 0;
		for(fig = defenders.units; fig; fig = fig->same_side) {
			if((fig->living > 0) && !fig->prisoner) {
				count++;
				if(fig->fled) fled++;
				else if(fig->retreat && fig->rank == 5) fled++;
			}
		}
		if(fled && fled == count) {
			defenders.fled = 1;
			defenders.lost = 1;
		}
	}

	/*
	if(defenders.fled || defenders.routed) {
		attackers.lost = 0;
		attackers.fled = 0;
		attackers.routed = 0;
		defenders.lost = 1;
	}
	if((attackers.fled || attackers.routed) && attackers.lost) {
		defenders.lost = 0;
		defenders.routed = 0;
		defenders.fled = 0;
		attackers.lost = 1;
	}
	*/
/*
 * The fanatics may still cause a Pyrrhic victory after rout!
 */
/*
	if (attackers.casualties >= attackers.size) {
		attackers.lost = 1;
		defenders.lost = 0;
	}
	if (defenders.casualties >= defenders.size) {
		defenders.lost = 1;
		if (attackers.casualties < attackers.size)
			attackers.lost = 0;
	}
*/
/*
 * Reporting ties.
 */
	if (attackers.lost == defenders.lost) {
		fprintf(long_report, "\nBattle ends as a tie; no victors.\n");
		fprintf(full_report, "\nBattle ends as a tie; no victors.\n");
		fprintf(terse_report, "\nBattle ends as a tie; no victors.\n");
		attackers.lost = 0;
		defenders.lost = 0;
	} else {
		if(attackers.lost) {
			fprintf(long_report, "\nBattle won by defenders.\n");
			fprintf(full_report, "\nBattle won by defenders.\n");
			fprintf(terse_report, "\nBattle won by defenders.\n");
		} else {
			fprintf(long_report, "\nBattle won by attackers.\n");
			fprintf(full_report, "\nBattle won by attackers.\n");
			fprintf(terse_report, "\nBattle won by attackers.\n");
		}
	}
	if (attackers.fled) {
		if(attackers.routed) {
			fprintf(long_report, "Attackers were routed!\n");
			fprintf(full_report, "Attackers were routed!\n");
			fprintf(terse_report, "Attackers were routed!\n");
		} else {
			fprintf(long_report, "Attackers fled the battle.\n");
			fprintf(full_report, "Attackers fled the battle.\n");
			fprintf(terse_report, "Attackers fled the battle.\n");
		}
		attackers.lost = 1;
	}
	if (defenders.fled) {
		if(defenders.routed) {
			fprintf(long_report, "Defenders were routed!\n");
			fprintf(full_report, "Defenders were routed!\n");
			fprintf(terse_report, "Defenders were routed!\n");
		} else {
			fprintf(long_report, "Defenders fled the battle.\n");
			fprintf(full_report, "Defenders fled the battle.\n");
			fprintf(terse_report, "Defenders fled the battle.\n");
		}
		defenders.lost = 1;
	}
}
