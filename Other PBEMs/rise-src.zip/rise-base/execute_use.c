/* $Id: execute_use.c,v 1.34 2000/11/20 23:55:48 jtraub Exp $
 *	Using a skill
 */
#include "turn.h"
#include "command_u.h"
#include "parser.h"
#include "fx.h"


/**
 ** INVALID_STRUCTURE_TARGET
 **	Checks if a structure is invalid for the skill
 **/
static int invalid_structure_target(unit_s *unit, skill_s *skill)
{
terrain_s	*terrain;
location_s	*last, *inner;
resource_s	*required;
resource_s	*unfinished;
/*
 * What is targeted?
 */
	switch (unit->target_type) {
	    default:
		return 1;
	    case ARGUMENT_IS_TERRAIN_TAG:
		terrain = unit->target.terrain;
		last = 0;
		for (inner = unit->true_location->inner; inner; inner = inner->next_inner)
			if (inner->type == terrain &&
			    inner->partial &&
			    (required = location_has_resource(inner, skill->end_product, 0)) != 0 &&
			    required->amount > 0)
				break;
			else
				last = inner;
/*
 * Create the inner location?
 */
		if (!inner) {
			for (required = terrain->required; required; required = required->next)
				if (required->type == skill->end_product)
					break;
			if (!required)
				return 0;
			inner = random_location_id();
			if (last)
				last->next_inner = inner;
			else
				unit->true_location->inner = inner;
			inner->outer = unit->true_location;
			inner->type  = terrain;
			inner->name  = strdup(terrain->name);
			inner->partial = 1;
			for (required = terrain->required; required; required = required->next) {
				unfinished = new_resource_instance();
				unfinished->type = required->type;
				unfinished->amount = required->amount;
				unfinished->next = inner->resources;
				inner->resources = unfinished;
			}
		}
/*
 * Target refined
 */
		unit->target_type = ARGUMENT_IS_LOCATION_ID;
		unit->target.location = inner;
		break;
/*
 * Work all done on that location?
 */
	    case ARGUMENT_IS_LOCATION_ID:
		if (unit->target.location->outer != unit->true_location)
			return 0;
		if (skill->end_product->special_effects)
			return 0;
		if ((required = location_has_resource(unit->target.location, skill->end_product, 0)) == 0 || required->amount == 0) {
			unit->target_type = ARGUMENT_IS_EMPTY;
			unit_personal_event(unit, today_number, "Building work is finished");
			return -1;
		}
		break;
	}
	return 0;
}


#ifdef SKILL_USE_POINTS
/**
 ** SKILL_WAS_USED
 **	Unit gains some experience
 **/
static void skill_was_used(unit_s *unit, experience_s *exp, int man_day)
{
skill_s		*effective;
long		points;
int		gained;
/*
 * Gain experience in the skill, and half in dependent skills
 */
	if (unit->race->type != RACE_LEADER)
		return;

#ifdef TRACING_REQUIRED
	if(unit->traced_unit) {
		printf("%s [%s] -- used skill %s for %d man days\n",
		       unit->name, unit->id.text, exp->skill->name,
		       man_day);
	}
#endif
	points = man_day * 10;
	points += 50;
	points /= 100;
	effective = exp->skill;
	gained = add_to_experience(unit, exp, effective, points);
#ifdef USES_REQUIRED_LEVELS
	points *= 50;
	points += 50;
	points /= 100;
	for (effective = effective->required_skill; effective; effective = effective->required_skill) {
		exp = unit_experiences(unit, effective, 0);
		if (exp && add_to_experience(unit, exp, effective, points))
			gained = 1;
	}
#endif
	if (gained) {
		compute_unit_stats(unit);
#ifdef STEALTH_STATS
		compute_overall_stealth(unit);
#endif
	}
}
#endif


/**
 ** PRODUCE_REPORT
 **	Production occured. Report all details.
 **/
static void produce_report(unit_s *unit, item_s *product, int amount, skill_s *effective, char *extra)
{
char		*end;
/*
 * Base report
 */
	sprintf(work, "%d %s produced", amount, amount > 1 ? product->plural : product->name);
	end = work + strlen(work);
/*
 * Report any target
 */
	switch (effective->target) {
	    case SKILL_TARGET_UNIT:
		sprintf(end, " for %s [%s]", unit->target.unit->name, unit->target.unit->id.text);
		break;
	    case SKILL_TARGET_LOCATION:
	    case SKILL_TARGET_STRUCTURE:
		sprintf(end, " for %s [%s]", unit->target.location->name, unit->target.location->id.text);
		break;
	}
/*
 * Add special
 */
	if (extra)
		strcat(work, extra);
	unit_personal_event(unit, today_number, work);
}


/**
 ** EXECUTE_USE
 **	Using skills is the most complicated thing there is.
 ** You can use a skill to harvest or produce things
 **/
int execute_use(unit_s *unit, order_s *current)
{
item_s		*product;
experience_s	*exp;
skill_s		*effective;
consume_s	*enhanced;
consume_s	*consumed;
resource_s	*harvest;
carry_s		*uses;
carry_s		*results,
		*materials;
item_s		*what;
int		man_days, max_days;
int		stop_point, maybe_stop = 0;
int		amount,
		required,
		multiple;
char		soldier;
int has_forge;
int has_level;
static skill_s *skill_medi;
static item_s *item_crft, *item_maso, *item_arch;
static item_s *item_arts;

	if(!skill_medi) {
		synthetic_tag("medi");
		skill_medi=skill_from_tag(0);
	}
	if(!item_crft) {
		synthetic_tag("crft");
		item_crft = item_from_tag(0);
	}
	if(!item_arts) {
		synthetic_tag("arts");
		item_arts = item_from_tag(0);
	}
	if(!item_maso) {
		synthetic_tag("maso");
		item_maso = item_from_tag(0);
	}
	if(!item_arch) {
		synthetic_tag("arch");
		item_arch = item_from_tag(0);
	}

/*
 * Validate argument
 */
	if (unit->dead || unit->size == 0 || unit->is_captive) {
		unit->full_day = 1;
		return 1;
	}
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid USE order");
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s: USE lacks skill\n", unit->name);
#endif
		order_is_error(unit, current);
		return 0;
	}
#ifdef SKILL_USE_POINTS
	effective = current->arguments[0].skill;
	exp = 0;
	if (effective->for_level != 0)
#endif
	{	exp = unit_experiences(unit, current->arguments[0].skill, 0);
		if (exp == 0 || (effective = exp->effective) == 0)
			return 0;
	}
/*
 * Non-producing skill!
 */
	if ((product = effective->end_product) == 0) {
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s uses wrong skill %s\n", unit->name, effective->name);
#endif
		sprintf(work, "%s [%s] cannot be used", effective->name, effective->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_error(unit, current);
		return 0;
	}

	if(product == item_cash && unit->true_location->pillaged) {
		return 0;
	}
/*
 * Does the skill require a target?
 */
	if (current->executing.types[1] != ARGUMENT_IS_NUMBER)
		current->executing.types[2] = 0;
	switch (effective->target) {
		case SKILL_TARGET_UNIT:
			if (current->executing.types[2] == ARGUMENT_IS_UNIT_ID) {
				unit->target_type = ARGUMENT_IS_UNIT_ID;
				unit->target.unit = current->arguments[2].unit;
			}
#define invalid_unit_target(u,s) (u->target_type != ARGUMENT_IS_UNIT_ID)
			if (invalid_unit_target(unit, effective)) {
#ifdef TRACING_REQUIRED
				if (unit->traced_unit)
					printf("skill use lacks unit target\n");
#endif
				return 0;
			}
#if 0
			switch (effective->local_target) {
				case 1:
					if (unit->target.unit->true_location &&
						unit->target.unit->true_location!=unit->true_location){
						return 0;
					}
					break;
				case 0:
					break;
				default:
					break;
			}
#endif
			break;
		case SKILL_TARGET_TERRAIN:
			if(current->executing.types[2] == ARGUMENT_IS_TERRAIN_TAG) {
				unit->target_type = ARGUMENT_IS_TERRAIN_TAG;
				unit->target.terrain = current->arguments[2].terrain;
			}
			if(unit->target_type != ARGUMENT_IS_TERRAIN_TAG) {
#ifdef TRACING_REQUIRED
				if (unit->traced_unit)
					printf("skill use lacks terrain target\n");
#endif
				return 0;
			}
			break;
		case SKILL_TARGET_LOCATION:
			if (current->executing.types[2] == ARGUMENT_IS_LOCATION_ID) {
				unit->target_type = ARGUMENT_IS_LOCATION_ID;
				unit->target.location = current->arguments[2].location;
			}
#define invalid_location_target(u,s) (u->target_type != ARGUMENT_IS_LOCATION_ID)
			if (invalid_location_target(unit, effective)) {
#ifdef TRACING_REQUIRED
				if (unit->traced_unit)
					printf("skill use lacks location target\n");
#endif
				return 0;
			}
			break;
		case SKILL_TARGET_STRUCTURE:
			if (current->executing.types[2] == ARGUMENT_IS_LOCATION_ID ||
				current->executing.types[2] == ARGUMENT_IS_TERRAIN_TAG) {
				unit->target_type = current->executing.types[2];
				unit->target = current->arguments[2];
			}
			switch (invalid_structure_target(unit, effective)) {
				case -1:
					order_is_complete(unit, current);
				case 1:
					return 0;
			}
			break;
		case SKILL_TARGET_ITEM:
			if (current->executing.types[2] == ARGUMENT_IS_ITEM_TAG) {
				unit->target_type = ARGUMENT_IS_ITEM_TAG;
				unit->target.item = current->arguments[2].item;
			}
#define invalid_item_target(u,s) (u->target_type != ARGUMENT_IS_ITEM_TAG)
			if (invalid_item_target(unit, effective))
				return 0;
			break;
		case SKILL_TARGET_SKILL:
			if (current->executing.types[2] == ARGUMENT_IS_SKILL_TAG) {
				unit->target_type = ARGUMENT_IS_SKILL_TAG;
				unit->target.skill = current->arguments[2].skill;
			}
#define invalid_skill_target(u,s) (u->target_type != ARGUMENT_IS_SKILL_TAG)
			if (invalid_skill_target(unit, effective))
				return 0;
			break;
#ifdef SKILL_TARGET_RACE
		case SKILL_TARGET_RACE:
			if (current->executing.types[2] == ARGUMENT_IS_RACE_TAG) {
				unit->target_type = ARGUMENT_IS_RACE_TAG;
				unit->target.race = current->arguments[2].race;
			}
#define invalid_race_target(u,s) (u->target_type != ARGUMENT_IS_RACE_TAG)
			if (invalid_race_target(unit, effective))
				return 0;
			break;
#endif
		default:
		/* HACK!!!!! */
		/*
		 * We don't have a target, so if we have an argument, treat it
		 * as a location
		 */
			if(current->executing.types[2] == ARGUMENT_IS_LOCATION_ID) {
				unit->target_type = ARGUMENT_IS_LOCATION_ID;
				unit->target.location = current->arguments[2].location;
			} else {
				if(unit->race->type == RACE_LEADER) {
					unit->target_type = ARGUMENT_IS_EMPTY;
					unit->target.unit = NULL;
				}
			}
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s uses skill %s\n", unit->name, effective->name);
#endif

	current->considered = 1;
	has_forge = fx_equipped_on_unit(unit, FX_GEWIL_FORGE);
	has_level = fx_equipped_on_unit(unit, FX_HYSSA_LEVEL);
/*
 * Does this skill build a new terrain structure?   Make sure we are allowed.
 */
	if(effective->specific_type == ARGUMENT_IS_TERRAIN_TAG) {
		if(!fx_building_preconditions(effective->specific.terrain,
					      unit))
			return 0;
        } else if (effective->specific_type == ARGUMENT_IS_RACE_TAG) {
		if(!fx_race_preconditions(effective->specific.race, unit))
			return 0;
	} else  if (effective->specific_type == ARGUMENT_IS_ITEM_TAG) {
		/* do nothing */
	} else  if (effective->specific_type == ARGUMENT_IS_SKILL_TAG) {
		/* do nothing */
	}
#ifdef USES_MANA_POINTS
	if(effective->end_product == item_mana && effective == skill_medi) {
		int max_mana;
		carry_s *power;
		compute_unit_stats(unit);
		max_mana = compute_max_mana(&unit->vital, &unit->bonus, unit->size);
		if ((power = unit->power) == 0)
			power = unit->power = unit_possessions(unit, item_mana, 1);
		if(power->amount >= max_mana) return 0;
	}
#endif

	if(effective->end_product->special_effects) {
		/* Check skill use preconditions */
		if(!fx_product_preconditions(effective->end_product, unit))
			return 0;
	}

	/* Check sneak here */
	switch (unit->target_type) {
		case ARGUMENT_IS_UNIT_ID:
			if(effective->special_effects == FX_PILFER) break;
			if(effective->special_effects == FX_PICKPOCKET) break;
			if(effective->special_effects == FX_AMBUSH) break;
			unit->sneaking = 0;
			break;
		case ARGUMENT_IS_LOCATION_ID:
			unit->sneaking = 0;
			break;
		case ARGUMENT_IS_TERRAIN_TAG:
			unit->sneaking = 0;
			break;
	}

/*
 * Does this skill harvest something, and we are guarded
 */
	if(effective->harvests) {
		resource_s *res;
		location_s *loc = NULL;
		res = location_has_resource(unit->current, effective->harvests, 0);
		if(res && res->remains) loc = unit->current;
		if(!loc) {
			res = location_has_resource(unit->true_location,
						    effective->harvests, 0);
			if(res && res->remains) loc = unit->true_location;
		}
		if(loc && guarded_against_activity(unit, loc, ATTITUDE_IS_NEUTRAL)) {
			unit_personal_event(unit, today_number, "Hostile guards prevent harvesting");
			return 0;
		}
	}
/*
	if (effective->harvests && guarded_against_activity(unit, unit->true_location, ATTITUDE_IS_NEUTRAL)) {
		unit_personal_event(unit, today_number, "Hostile guards prevent harvesting");
		return 0;
	}
*/
/*
 * Count how many man-days (in 0.05 units) we can marshal
 */
	if (unit->race->type == RACE_LEADER)
		man_days = 100 * unit->size;
	else
		man_days = 0;
/*
 * Enhancements to skill
 */
	for(uses = unit->carrying; uses; uses = uses->next) {
		uses->contributed = 0;
	}
	for (enhanced = effective->enhanced; enhanced; enhanced = enhanced->next) {
		what = enhanced->what;
		if (what->item_type == ITEM_TOKEN) {
/* soldier? recruit? */
			if (what->tag.text[0] == 'w')
				soldier = 0;
			else
				soldier = 1;
			for (uses = unit->carrying; uses; uses = uses->next) {
				if(uses->contributed) continue;
				if (uses->amount && uses->item->item_type == ITEM_FOLLOWER && uses->item != item_recruit) {
					if (soldier) {
						if (!uses->item->equip_bonus.melee && !uses->item->equip_bonus.missile)
							continue;
					} else {
						if (uses->item->equip_bonus.melee || uses->item->equip_bonus.missile)
							continue;
					}
					uses->contributed = uses->amount * enhanced->amount;
					if(has_forge && ((uses->item == item_crft) ||
								     (uses->item == item_arts))) {
						uses->contributed *= 2;
					}
					if(has_level && ((uses->item == item_arch) ||
								     (uses->item == item_maso))) {
						uses->contributed *= 2;
					}
				}
			}
		} else {
			uses = unit_possessions(unit, what, 0);
			if (uses) {
				uses->contributed = uses->amount * enhanced->amount;
				if(has_forge && ((uses->item == item_crft) ||
							     (uses->item == item_arts))) {
					uses->contributed *= 2;
				}
			}
			
		}
	}
	for(uses = unit->carrying; uses; uses = uses->next) {
		man_days += uses->contributed;
		uses->contributed = 0;
	}
	if (man_days == 0)
		return 0;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s -- Base man days is %d\n", unit->name, man_days);
#endif
/*
 * We can draw X% man days of work
 */
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		stop_point = current->arguments[1].number;
	else
		stop_point = 0;

	/*
	 * Okay.. Only set the stop point if we don't have enough man days
	 * to make 1
	 */
	if (stop_point == 0 && !current->days)
		maybe_stop = 1;

    results = unit_possessions(unit, effective->end_product, 1);

/*
 * Effective tokens
 */
	max_days = man_days;
	harvest = 0;
	amount  = 0;
	required = effective->tokens_required * 100;
	multiple = effective->multiples;
	if (multiple == 0)
		multiple = 1;
/*
 * Start the loop
 */
	while (man_days) {
/*
 * Consumption of items is required?
 */
		for (consumed = effective->use_consumes; consumed; consumed = consumed->next) {
			materials = unit_possessions(unit, consumed->what, 0);
			if (!materials || materials->amount < consumed->amount)
				break;
		}
		if (consumed)
			break;
/*
 * Harvesting of tokens?
 */
		if (effective->harvests) {
			unit->sneaking = 0;
			if(unit->special_resources) {
				harvest = unit_has_resource(unit, effective->harvests);
			}
			if(!harvest || harvest->remains <=0) {
				if(unit->current->type->type == TERRAIN_STRUCTURE) {
					if(unit->current->type->special_effect == FX_CASTLE) {
						if(unit->current->present == unit && unit->race->type == RACE_LEADER)
							harvest = location_has_resource(unit->current, effective->harvests, 0);
					} else if(unit->current->present == unit) {
						harvest = location_has_resource(unit->current, effective->harvests, 0);
					}
				}
			}
			if (!harvest || harvest->remains <= 0) {
				harvest = location_has_resource(unit->true_location, effective->harvests, 0);
				if (!harvest || harvest->remains <= 0) {
#ifdef TRACING_REQUIRED
					if (unit->traced_unit)
						printf("no harvestable tokens\n");
#endif
					break;
				}
			}
		} else
			harvest = 0;
/*
 * We cannot complete one item
 */
		if (results->tokens + man_days < required) {
			results->tokens += man_days;
			man_days = 0;
			if(maybe_stop) {
				stop_point = 1;
			}
			break;
		}
/*
 * We DO complete at least one item: Harvest, consume, produce
 */
		for (consumed = effective->use_consumes; consumed; consumed = consumed->next) {
			materials = unit_possessions(unit, consumed->what, 0);
			materials->amount -= consumed->amount;
			if (materials->amount < materials->equipped)
				materials->equipped = materials->amount;
		}
		if (harvest)
			harvest->remains--;
/*
 * Ok, do away with that
 */
		man_days -= required - results->tokens;
		results->tokens = 0;
		results->amount += multiple;

		/* Okay.   Do the auto-equip if we need to */
		if(results->equipped &&
				results->equipped < results->item->equip_maximum) {
			if(results->amount >= results->item->equip_maximum)
				results->equipped = results->item->equip_maximum;
			else
				results->equipped = results->amount;
			compute_unit_stats(unit);
		}

		amount += multiple;
/*
 * Stop point?
 */
		if (stop_point && stop_point <= amount && 
                    !(effective->type == 2 || effective->student))
			break;
	}
/*
 * Did we produce something?
 */
	if (man_days >= max_days)
		return 0;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s -- Max man days is %d, Base man days is %d\n",
		       unit->name, max_days, man_days);
#endif

/*
 * Order was executed
 */
	unit->full_day = 1;
	unit->executing = 0;
#ifdef SKILL_USE_POINTS
	man_days = max_days - man_days;
	man_days *= SKILL_POINTS_PER_DAY;
	if(man_days > (200*SKILL_POINTS_PER_DAY)) {
		int extra = man_days - (200*SKILL_POINTS_PER_DAY);
		extra /= 4;
		man_days = 200*SKILL_POINTS_PER_DAY + extra;
	}
	man_days += 50;
	man_days /= 100;
	if (exp)
		skill_was_used(unit, exp, man_days);
/*
	man_days = max_days - man_days;
	man_days *= SKILL_POINTS_PER_DAY;
	if (man_days > 3000)
		man_days = 2000 + (man_days / 3);
	man_days += 50;
	man_days /= 100;
	if (exp)
		skill_was_used(unit, exp, man_days);
*/
#endif
	if (!amount) {
		if (!stop_point || current->days > 0)
			order_was_executed(unit, current);
		return 1;
	}
/*
 * Normal use is "no target". Other targets?
 */
	switch (effective->target) {
	    case SKILL_TARGET_LOCATION:
		break;
/*
 * Location is either a FX effect, or a building
 */
	    case SKILL_TARGET_STRUCTURE:
		printf("Unimplemented TARGET STRUCTURE NEAR\n");
		break;
/*
 * Unit gains something (potentially bad?)
 */
	    case SKILL_TARGET_UNIT:
		results->amount -= amount;
		results = unit_possessions(unit->target.unit, product, 1);
		switch (effective->local_target) {
		    case 1:
			if (unit->target.unit->true_location &&
			    unit->target.unit->true_location != unit->true_location) {
				sprintf(work, "Use of %s [%s] fizzles because target is out of range.",	effective->name, effective->tag.text);
				unit_personal_event(unit, today_number, work);
				results = 0;
				unit->target_type = 0;
				unit->target.unit = 0;
			}
		    case 0:
			break;
		    default:
			printf("Unimplemented TARGET UNIT NEAR\n");
		}
		if (product->item_type == ITEM_DAYS && unit->target.unit)
			unit->target.unit->has_effects = 1;
		if (!results)
			break;
		results->amount += amount;
	    default:
		if (results->amount < 0)
			results->amount = 0;
		if (results->item->auto_equip)
			results->equipped = results->amount;
		if (product->item_type == ITEM_DAYS)
			unit->has_effects = 1;
	}
/*
 * Production is reported
 */
	if (results) {
		if (product->name && !unit->setting_silent)
			produce_report(unit, product, amount, effective, 0);
		if (product->item_type == ITEM_EVENT && results && product->special_effects) {
			fx_execute_event(product, results->amount, unit, effective, current);
			
			results->amount = 0;
		}
	}
/*
 * Order executed
 */
	if (!stop_point)
		order_was_executed(unit, current);
	else {
		if(effective->type == 2 || effective->student) {
			current->arguments[1].number--;
			if(current->arguments[1].number <= 0)
				order_is_complete(unit, current);
		} else if (amount >= stop_point)
			order_is_complete(unit, current);
		else {
			current->arguments[1].number -= amount;
			if (current->arguments[1].number <= 0)
				order_is_complete(unit, current);
			else
				if (current->days > 0)
					order_was_executed(unit, current);
		}
	}
	return 1;
}
