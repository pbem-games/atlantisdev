/* $Id: command_e.h,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Command argument strings
 */

extern char		movement_modes[];
extern char		stance_arguments[];
extern char		participate_modes[];
extern char		battlefield_ranks[];
extern char		battlefield_files[];
extern char		battlefield_moves[];
extern char		possible_settings[];
#define battle_arguments	participate_modes
#define rank_arguments		battlefield_ranks
#define file_arguments		battlefield_files
#define move_arguments		battlefield_moves

#define UNIT_SETTING_ADVERTISE	0
#define UNIT_SETTING_ANNOUNCE	1
#define UNIT_SETTING_HTML	2
#define UNIT_SETTING_MISER	3
#define UNIT_SETTING_SILENT	4
#define UNIT_SETTING_SUPPORT	5
#define UNIT_SETTING_TERSE	6
