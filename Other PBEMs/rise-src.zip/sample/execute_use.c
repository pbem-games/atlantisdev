/* $Id: execute_use.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Using a skill
 */
#include "turn.h"
#include "command_u.h"
#include "fx.h"


/**
 ** INVALID_STRUCTURE_TARGET
 **	Checks if a structure is invalid for the skill
 **/
static int invalid_structure_target(unit_s *unit, skill_s *skill)
{
terrain_s	*terrain;
location_s	*last, *inner;
resource_s	*required;
resource_s	*unfinished;
/*
 * What is targeted?
 */
	switch (unit->target_type) {
	    default:
		return 1;
	    case ARGUMENT_IS_TERRAIN_TAG:
		terrain = unit->target.terrain;
		last = 0;
		for (inner = unit->true_location->inner; inner; inner = inner->next_inner)
			if (inner->type == terrain &&
			    inner->partial &&
			    (required = location_has_resource(inner, skill->end_product, 0)) != 0 &&
			    required->amount > 0)
				break;
			else
				last = inner;
/*
 * Create the inner location?
 */
		if (!inner) {
			for (required = terrain->required; required; required = required->next)
				if (required->type == skill->end_product)
					break;
			if (!required)
				return 0;
			inner = random_location_id();
			if (last)
				last->next_inner = inner;
			else
				unit->true_location->inner = inner;
			inner->outer = unit->true_location;
			inner->type  = terrain;
			inner->name  = strdup(terrain->name);
			inner->partial = 1;
			for (required = terrain->required; required; required = required->next) {
				unfinished = new_resource_instance();
				unfinished->type = required->type;
				unfinished->amount = required->amount;
				unfinished->next = inner->resources;
				inner->resources = unfinished;
			}
		}
/*
 * Target refined
 */
		unit->target_type = ARGUMENT_IS_LOCATION_ID;
		unit->target.location = inner;
		break;
/*
 * Work all done on that location?
 */
	    case ARGUMENT_IS_LOCATION_ID:
		if (unit->target.location->outer != unit->true_location)
			return 0;
		if (skill->end_product->special_effects)
			return 0;
		if ((required = location_has_resource(unit->target.location, skill->end_product, 0)) == 0 || required->amount == 0) {
			unit->target_type = ARGUMENT_IS_EMPTY;
			unit_personal_event(unit, today_number, "Building work is finished");
			return -1;
		}
		break;
	}
	return 0;
}


/**
 ** USE_HARVESTS
 **	Harvesting is simply a mark as "want to use this"
 **/
static int use_harvests(unit_s *unit, order_s *current, skill_s *effective, item_s *product)
{
resource_s	*harvest;
unit_s		*guards;
carry_s		*materials;
int		active_size;
/*
 * Mark off "wanted" size.
 */
	harvest = location_has_resource(unit->true_location, effective->harvests, 0);
	if (!harvest || harvest->tokens <= 0) {
		harvest = location_has_resource(unit->current, effective->harvests, 0);
		if (!harvest || harvest->tokens <= 0) {
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("no harvestable tokens\n");
#endif
			return 0;
		}
	}
/*
 * Is the location under guard?
 */
	if (unit->true_location->guarded)
		for (guards = unit->true_location->present; guards; guards = guards->next_location)
			if (guards->is_guarding)
				switch (attitude_vs_faction(guards->faction, unit->faction)) {
				    case ATTITUDE_IS_NEUTRAL: /* allow only entertainment */
					if (effective->harvests != token_entertain)
						return 0;
				    case ATTITUDE_IS_FRIEND: /* forbid only taxing */
					if (effective->harvests == token_tax)
						return 0;
				    case ATTITUDE_IS_ALLY: /* all harvests are allowed */
					break;
				    default:
					return 0;
				}
/*
 * Effective size of harvest
 */
	active_size = unit->size;
	if (unit->is_guarding)
		active_size /= 2;
	if (!active_size)
		return 0;
/*
 * We want that many tokens. We'll see after everyone had a chance
 */
#ifdef SKILL_BENEFITS_FROM_TOOL
	if (effective->enhanced &&
	    (materials = unit_possessions(unit, effective->enhanced, 0)) != 0 &&
	    materials->equipped) {
		active_size += materials->equipped / 2;
		if ((materials->equipped & 1) && (today_number & 1))
			active_size++;
	}
#endif
	harvest->wanted += active_size * effective->multiplier;
	unit->executing = current;
	unit->full_day = 1;
	unit->true_location->harvesting = 1;
	return 1;
}


#ifdef SKILL_USE_POINTS
/**
 ** SKILL_WAS_USED
 **	Unit gains some experience
 **/
static void skill_was_used(unit_s *unit, experience_s *exp, int man_day)
{
skill_s		*effective;
long		points;
int		gained;
/*
 * Gain experience in the skill, and half in dependent skills
 */
	points = man_day * (SKILL_POINTS_PER_DAY/10);
	effective = exp->skill;
	gained = add_to_experience(unit, exp, effective, points);
#ifdef USES_REQUIRED_LEVELS
	points /= 2;
	for (effective = effective->required_skill; effective; effective = effective->required_skill) {
		exp = unit_experiences(unit, effective, 0);
		if (exp && add_to_experience(unit, exp, effective, points))
			gained = 1;
	}
#endif
	if (gained) {
		compute_unit_stats(unit);
#ifdef STEALTH_STATS
		compute_overall_stealth(unit);
#endif
	}
}
#endif


/**
 ** PRODUCE_REPORT
 **	Production occured. Report all details.
 **/
static void produce_report(unit_s *unit, item_s *product, int amount, skill_s *effective, char *extra)
{
char		*end;
/*
 * Base report
 */
	sprintf(work, "%d %s produced", amount, amount > 1 ? product->plural : product->name);
	end = work + strlen(work);
/*
 * Report any target
 */
	switch (effective->target) {
	    case SKILL_TARGET_UNIT:
		sprintf(end, " for %s [%s]", unit->target.unit->name, unit->target.unit->id.text);
		break;
	    case SKILL_TARGET_LOCATION:
	    case SKILL_TARGET_STRUCTURE:
		sprintf(end, " for %s [%s]", unit->target.location->name, unit->target.location->id.text);
		break;
	}
/*
 * Add special
 */
	if (extra)
		strcat(work, extra);
	unit_personal_event(unit, today_number, work);
}


/**
 ** USE_CRAFT
 **	Use a crafting skill
 **/
static int use_craft(unit_s *unit, skill_s *effective, experience_s *exp, item_s *product,
					order_s *current)
{
carry_s		*results,
		*materials;
resource_s	*harvest;
consume_s	*consumed;
order_s		*stay;
int		man_days, days_spent;
int		stop_point;
int		amount,
		required,
		multiple,
		toked,
		active_size;
char		ended;
#ifdef FX_SPEEDUP_STRUCTURE
char		improved = 0;
#endif
/*
 * Effective tokens
 */
	if (current->executing.types[1] == ARGUMENT_IS_NUMBER)
		stop_point = current->arguments[1].number;
	else
		stop_point = 0;
	results = unit_possessions(unit, product, 1);
	active_size = unit->size;
	if (unit->is_guarding)
		active_size /= 2;
	man_days = active_size;
	harvest = 0;
	amount  = 0;
	days_spent = 0;
	required = effective->tokens_required;
#ifdef SKILL_BENEFITS_FROM_TOOL
	if (effective->enhanced &&
	    (materials = unit_possessions(unit, effective->enhanced, 0)) != 0 &&
	    materials->equipped) {
		man_days += materials->equipped / 2;
		if ((materials->equipped & 1) && (today_number & 1))
			man_days++;
	}
#endif
	multiple = effective->multiples;
	if (multiple == 0)
		multiple = 1;
	while (man_days) {
/*
 * Continue work started
 */
		if (!results->tokens) {
/*
 * Start a new item?
 */
			for (consumed = effective->use_consumes; consumed; consumed = consumed->next) {
				materials = unit_possessions(unit, consumed->what, 0);
				if (!materials || materials->amount < consumed->amount)
					break;
			}
			if (consumed)
				break;
			for (consumed = effective->use_consumes; consumed; consumed = consumed->next) {
				materials = unit_possessions(unit, consumed->what, 0);
				materials->amount -= consumed->amount;
				if (materials->amount < materials->equipped)
					materials->equipped = materials->amount;
			}
		}
#ifdef FX_SPEEDUP_STRUCTURE
/*
 * Double building speed if speedup in action
 */
		if (effective->target == SKILL_TARGET_STRUCTURE && !effective->special_effects &&
		    unit->target.location->speedup) {
			results->tokens++;
			improved = 1;
		}
#endif
		results->tokens++;
		man_days--;
		days_spent++;
/*
 * Unit of product completed?
 */
		if (results->tokens >= required) {
			amount += multiple;
			results->tokens -= required;
			if (stop_point && amount >= stop_point)
				break;
		}
	}
/*
 * Did we produce something?
 */
	if (!days_spent)
		return 0;
	if (man_days > active_size)
		man_days = active_size;
	unit->wages += man_days / 2;
	ended = 0;
/*
 * Produced final product?
 */
	if (amount || results->tokens >= required) {
		amount += multiple * (results->tokens / required);
		results->tokens %= required;
/*
 * Normal use is "no target". Other targets?
 */
		switch (effective->target) {
		    case SKILL_TARGET_LOCATION:
			break;
/*
 * Location is either a FX effect, or a building
 */
		    case SKILL_TARGET_STRUCTURE:
			switch (effective->local_target) {
			    case 1:
				if (unit->target.location->outer != unit->true_location) {
					unit_personal_event(unit, today_number, "effect fizzles");
					results = 0;
					unit->target_type = 0;
					unit->target.location = 0;
				}
			    case 0:
				break;
			    default:
				printf("Unimplemented TARGET STRUCTURE NEAR\n");
			}
			if (!unit->target.location || effective->special_effects)
				break;
			harvest = location_has_resource(unit->target.location, product, 0);
			if (!harvest)
				break;
			if (amount > harvest->amount) {
				toked = amount - harvest->amount;
				results->tokens += toked * required;
				amount -= toked;
			}
			harvest->amount -= amount;
/*
 * Building is complete? If so, order is, too (or would be, next time)
 */
			if (!harvest->amount) {
				for (harvest = unit->target.location->resources; harvest; harvest = harvest->next)
					if (harvest->amount && harvest->type->item_type == 3)
						break;
				if (!harvest) {
					sprintf(work, "%s [%s] is finished!", unit->target.location->name, unit->target.location->id.text);
					unit_personal_event(unit, today_number, work);
					location_visible_event(unit->true_location, today_number, work);
					printf("%s\n", work);
/*
 * Builder had a "stay", moved as first unit into location
 */
					if (unit->wants_stay) {
						for (stay = unit->orders; stay; stay = stay->next)
							if (stay->considered && stay->executing.routine == execute_stay)
								break;
						if (stay)
							order_is_complete(unit, stay);
						if (unit->leader)
							execute_unstack(unit, 0);
						move_to_location(unit, unit->target.location);
					}
					unit->target.location->partial = 0;
				}
				stop_point = amount;
			}
			break;
/*
 * Unit gains something (potentially bad?)
 */
		    case SKILL_TARGET_UNIT:
			results = unit_possessions(unit->target.unit, product, 1);
			switch (effective->local_target) {
			    case 1:
				if (unit->target.unit->true_location &&
				    unit->target.unit->true_location != unit->true_location) {
					unit_personal_event(unit, today_number, "effect fizzles");
					results = 0;
					unit->target_type = 0;
					unit->target.unit = 0;
				}
			    case 0:
				break;
			    default:
				printf("Unimplemented TARGET UNIT NEAR\n");
			}
			if (product->item_type == ITEM_DAYS && unit->target.unit)
				unit->target.unit->has_effects = 1;
		    default:
			if (!results)
				break;
			results->amount += amount;
			if (results->amount < 0)
				results->amount = 0;
			if (results->item->auto_equip)
				results->equipped = results->amount;
			if (product->item_type == ITEM_DAYS)
				unit->has_effects = 1;
		}
/*
 * Production is reported
 */
		if (results) {
			if (product->name && !unit->setting_silent)
#ifdef FX_SPEEDUP_STRUCTURE
				if (improved)
					produce_report(unit, product, amount, effective, " (improved)");
				else
#endif
					produce_report(unit, product, amount, effective, 0);
			if (product->item_type == ITEM_EVENT && results && product->special_effects) {
				ended = fx_execute_event(product, results->amount, unit, effective, current);
				results->amount = 0;
			}
		}
	}
	if (days_spent > active_size)
		days_spent = active_size;
#ifdef SKILL_USE_POINTS
	skill_was_used(unit, exp, days_spent);
#endif
/*
 * Order executed
 */
	if (ended)
		order_is_complete(unit, current);
	else
		if (stop_point) {
			current->arguments[1].number -= amount;
			if (current->arguments[1].number <= 0)
				order_is_complete(unit, current);
			else
				if (current->days > 0)
					order_was_executed(unit, current);
		} else
			order_was_executed(unit, current);
	unit->full_day = 1;
	unit->executing = 0;
	return 1;
}


/**
 ** EXECUTE_USE
 **	Using skills is the most complicated thing there is.
 ** You can use a skill to harvest or produce things
 **/
int execute_use(unit_s *unit, order_s *current)
{
skill_s		*effective;
item_s		*product;
experience_s	*exp;
/*
 * Validate argument
 */
	if (unit->dead || unit->size == 0) {
		unit->full_day = 1;
		return 1;
	}
	if (current->executing.types[0] != ARGUMENT_IS_SKILL_TAG) {
		unit_personal_event(unit, today_number, "Invalid USE order");
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s: USE lacks skill\n", unit->name);
#endif
		order_is_complete(unit, current);
		return 0;
	}
	exp = unit_experiences(unit, current->arguments[0].skill, 0);
	if (exp == 0 || (effective = exp->effective) == 0)
		return 0;
/*
 * Non-producing skill!
 */
	if ((product = effective->end_product) == 0) {
#ifdef TRACING_REQUIRED
		if (unit->traced_unit)
			printf("%s uses wrong skill %s\n", unit->name, effective->name);
#endif
		sprintf(work, "%s [%s] cannot be used", effective->name, effective->tag.text);
		unit_personal_event(unit, today_number, work);
		order_is_complete(unit, current);
		return 0;
	}
/*
 * Does the skill require a target?
 */
	switch (effective->target) {
	    case SKILL_TARGET_UNIT:
		if (current->executing.types[2] == ARGUMENT_IS_UNIT_ID) {
			unit->target_type = ARGUMENT_IS_UNIT_ID;
			unit->target.unit = current->arguments[2].unit;
		}
#define invalid_unit_target(u,s) (u->target_type != ARGUMENT_IS_UNIT_ID)
		if (invalid_unit_target(unit, effective)) {
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("skill use lacks unit target\n");
#endif
			return 0;
		}
		break;
	    case SKILL_TARGET_LOCATION:
		if (current->executing.types[2] == ARGUMENT_IS_LOCATION_ID) {
			unit->target_type = ARGUMENT_IS_LOCATION_ID;
			unit->target.location = current->arguments[2].location;
		}
#define invalid_location_target(u,s) (u->target_type != ARGUMENT_IS_LOCATION_ID)
		if (invalid_location_target(unit, effective)) {
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("skill use lacks location target\n");
#endif
			return 0;
		}
		break;
	    case SKILL_TARGET_STRUCTURE:
		if (current->executing.types[2] == ARGUMENT_IS_LOCATION_ID ||
		    current->executing.types[2] == ARGUMENT_IS_TERRAIN_TAG) {
			unit->target_type = current->executing.types[2];
			unit->target = current->arguments[2];
		}
		switch (invalid_structure_target(unit, effective)) {
		    case -1:
			order_is_complete(unit, current);
		    case 1:
			return 0;
		}
		break;
	    case SKILL_TARGET_ITEM:
		if (current->executing.types[2] == ARGUMENT_IS_ITEM_TAG) {
			unit->target_type = ARGUMENT_IS_ITEM_TAG;
			unit->target.item = current->arguments[2].item;
		}
#define invalid_item_target(u,s) (u->target_type != ARGUMENT_IS_ITEM_TAG)
		if (invalid_item_target(unit, effective))
			return 0;
		break;
	    case SKILL_TARGET_SKILL:
		if (current->executing.types[2] == ARGUMENT_IS_SKILL_TAG) {
			unit->target_type = ARGUMENT_IS_SKILL_TAG;
			unit->target.skill = current->arguments[2].skill;
		}
#define invalid_skill_target(u,s) (u->target_type != ARGUMENT_IS_SKILL_TAG)
		if (invalid_skill_target(unit, effective))
			return 0;
		break;
#ifdef SKILL_TARGET_RACE
	    case SKILL_TARGET_RACE:
		if (current->executing.types[2] == ARGUMENT_IS_RACE_TAG) {
			unit->target_type = ARGUMENT_IS_RACE_TAG;
			unit->target.race = current->arguments[2].race;
		}
#define invalid_race_target(u,s) (u->target_type != ARGUMENT_IS_RACE_TAG)
		if (invalid_race_target(unit, effective))
			return 0;
		break;
#endif
	}
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s uses skill %s\n", unit->name, effective->name);
#endif
/*
 * Harvesting skill or craft skill.
 */
	if (effective->harvests)
		return use_harvests(unit, current, effective, product);
	return use_craft(unit, effective, exp, product, current);
}


/**
 ** PARTIAL_HARVESTED
 **	The unit has harvested
 **/
static void partial_harvested(unit_s *unit)
{
experience_s	*exp;
skill_s		*effective;
item_s		*product;
resource_s	*harvest;
carry_s		*result;
order_s		*current;
int		toked, maxt,
		gotten, grabbed,
		amount, man_days, active_size;
char		stop;
/*
 * Mark off "wanted" size.
 */
	active_size = unit->size;
	if (unit->is_guarding)
		active_size /= 2;
	man_days = active_size;
	if (active_size <= 0)
		return;
/*
 * Get experience
 */
	exp = unit_experiences(unit, unit->executing->arguments[0].skill, 0);
	if (exp == 0) {
		unit_personal_event(unit, today_number, "Unit lost skill");
		return;
	}
	effective = exp->effective;
	if (effective == 0) {
		unit_personal_event(unit, today_number, "Unit reverted to novice level");
		return;
	}
	product = effective->end_product;
/*
 * Tool increase the active_size...
 */
#ifdef SKILL_BENEFITS_FROM_TOOL
	if (effective->enhanced &&
	    (result = unit_possessions(unit, effective->enhanced, 0)) != 0 &&
	    result->equipped) {
		man_days += result->equipped / 2;
		if ((result->equipped & 1) && (today_number & 1))
			man_days++;
	}
#endif
/*
 * Do we have a stop point?
 */
	result = unit_possessions(unit, product, 1);
	toked = effective->multiplier * man_days;
	stop = 0;
	if (unit->executing->executing.types[1] == ARGUMENT_IS_NUMBER) {
		maxt = unit->executing->arguments[1].number;
		if (maxt == 0)
			maxt = toked;
		else {
			if (effective->multiples > 1) {
				maxt += effective->multiples - 1;
				maxt /= effective->multiples;
			}
			maxt *= effective->tokens_required;
			maxt -= result->tokens;
			if (maxt < 0)
				maxt = 0;
			stop = 1;
		}
	} else
		maxt = toked;
/*
 * First: harvest from local structure, if any
 */
	if (unit->current != unit->true_location &&
	    (harvest = location_has_resource(unit->current, effective->harvests, 0)) != 0 &&
	    (gotten = harvest->tokens) != 0) {
		if (gotten > maxt)
			gotten = maxt;
		if (gotten > toked)
			gotten = toked;
		harvest->tokens -= gotten;
		result->tokens += gotten;
/*
 * Note: We requested toked from the overall location. The gotten tokens are no longer needed
 */
		harvest = location_has_resource(unit->true_location, effective->harvests, 0);
		if (harvest)
			harvest->wanted -= gotten;
		maxt -= gotten;
		grabbed = gotten;
		toked -= gotten;
	} else
		grabbed = 0;
/*
 * We want that many tokens. We'll see about sharing
 */
	harvest = location_has_resource(unit->true_location, effective->harvests, 0);
	if (harvest) {
		if (harvest->tokens < harvest->wanted)
			gotten = fractional(toked, harvest->tokens, harvest->wanted);
		else
			gotten = toked;
		if (gotten > maxt)
			gotten = maxt;
		if (gotten < 0) {
			abort();
			gotten = 0;
		}
		harvest->wanted -= toked;
		harvest->tokens -= gotten;
		result->tokens += gotten;
/*
 * We had local tokens, but no global tokens
 */
	} else
		gotten = 0;
	grabbed += gotten;
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("%s gets %d %s tokens\n", unit->name, grabbed, result->item->name);
#endif
/*
 * Not everyone harvested? The rest are put to work at half efficiency
 */
	toked -= gotten;
	if (effective->multiplier)
		toked /= effective->multiplier;
	if (toked == 1 && (today_number & 1))
		toked++;
	unit->wages += toked / 2;
/*
 * Any new tokens harvested?
 */
	if (grabbed) {
#ifdef FX_SPEEDUP_HARVEST
/*
 * Add 50% harvest if speedup in action
 */
		if (result->item->item_live && unit->true_location->speedup)
			result->tokens += grabbed / 2;
#endif
		amount = (result->tokens / effective->tokens_required);
/*
 * Production is reported
 */
		if (amount) {
			if (effective->multiples)
				amount *= effective->multiples;
			result->tokens %= effective->tokens_required;
			result->amount += amount;
			if (result->item->auto_equip) {
				result->equipped = result->amount;
				if (result->equipped > unit->size)
					result->equipped = unit->size;
			}
			if (product->name && !unit->setting_silent)
				produce_report(unit, product, amount, effective, 0);
			if (product->item_type == ITEM_EVENT && product->special_effects) {
				fx_execute_event(product, result->amount, unit, effective, current);
				result->amount = 0;
			}
		}
/*
 * Experience was gained
 */
		if (effective->multiplier > 1) {
			grabbed += effective->multiplier / 2;
			grabbed /= effective->multiplier;
		}
		if (grabbed > active_size)
			grabbed = active_size;
#ifdef SKILL_USE_POINTS
		skill_was_used(unit, exp, grabbed);
#endif
	} else {
		sprintf(work, "Failed to get any %s", product->plural);
		unit_personal_event(unit, today_number, work);
		amount = 0;
	}
/*
 * Order executed
 */
	for (current = unit->orders; current; current = current->next)
		if (current == unit->executing)
			break;
	if (current)
		if (stop) {
			current->arguments[1].number -= amount;
			if (current->arguments[1].number <= 0)
				order_is_complete(unit, current);
			else
				if (current->days > 0)
					order_was_executed(unit, current);
		} else
			order_was_executed(unit, current);
}


/**
 ** HARVEST_LOCATION
 **	Harvesting people lead to resource sharing
 **/
void harvest_location(unit_s *unit)
{
/*
 * This is recursed
 */
	while (unit) {
		if (unit->executing && unit->executing->executing.routine == execute_use)
			partial_harvested(unit);
		harvest_location(unit->stack);
		unit = unit->next_location;
	}
}
