/* $Id: mapedit.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Interactive map editor
 */
#include "turn.h"
#include "parser.h"


/**
 ** Special prototype
 **/
extern void	recursive_relative_position(location_s *,int,int);


/**
 ** Private variables
 **/
static location_s	*current_location;


/**
 ** LIST
 **/
static void list(location_s *l)
{
location_s	*outer;
recruit_s	*jobs;
market_s	*market;
direction_s	*direction;
resource_s	*product;

	printf("[%s] %s, %s", l->id.text, l->name, l->type->name);
#ifdef USE_OVERLAND_COORDINATES
	printf(" (%d,%d)", l->x, l->y);
#endif
	putchar('\n');
	if ((outer = l->outer) != 0)
		printf(" in [%s] %s, %s\n", outer->id.text,
					outer->name,
					outer->type->name);
	printf("Population: %d figures\n", l->population);
	for (jobs = l->opportunity; jobs; jobs = jobs->next)
		printf("  Job: %d %s [%s] at $%d\n", jobs->amount, jobs->type->name,
				jobs->type->tag.text, jobs->price);
	for (market = l->markets; market; market = market->next) {
		if (market->offered.initial_amount)
			printf("  Sell: %d %s [%s] at %d\n", market->offered.initial_amount,
						market->type->name, market->type->tag.text,
						market->offered.negociated_price);
		if (market->wanted.initial_amount)
			printf("   Buy: %d %s [%s] at %d\n", market->wanted.initial_amount,
						market->type->name, market->type->tag.text,
						market->wanted.negociated_price);
	}
	for (product = l->resources; product; product = product->next)
		printf("  Resource: %d %s [%s]\n", product->amount, product->type->name,
				product->type->tag.text);
	for (direction = l->exits; direction; direction = direction->next)
		printf("  Move: %s to %s [%s] in %d days\n", direction->name,
				direction->toward->name, direction->toward->id.text,
				direction->days);
}


/**
 ** COMPLETE_COMPASS
 **	Interactive compass
 **/
static void complete_compass(location_s *l, int dir, int x, int y)
{
location_s	*added;
/*
 * Direction does not exist?
 */
	if ((added = location_from_position(x, y)) != 0) {
		printf("... connecting %s and %s\n", l->id.text, added->id.text);
		compass_connect(l, added, dir);
		return;
	}
	added = random_location_id();
#ifdef DYNAMICALLY_DEFINED_GAME
	added->partial = 1;
#endif
	printf("Direction %s, type: ", compass_names[dir]);
	while (1) {
		if (!file_gets(stdin))
			abort();
		if (!separate_tag())
			continue;
		if ((added->type = terrain_from_tag(0)) != 0)
			break;
	}
#ifdef WORLD_HAS_CLIMATE
	if (added->type->type == TERRAIN_COUNTRY)
		added->next_climate = 1;
#endif
	printf("Name: (%s) ", l->name);
	if (!file_gets(stdin))
		abort();
	if (!work[0])
		strcpy(work, l->name);
	added->name = strdup(work);
	added->x = x;
	added->y = y;
	all_compass_connect(added);
}


/**
 ** COMPLETE_LOCATION
 **	Make sure location is complete
 **/
static void complete_location(location_s *l)
{
race_s		*race;
int		frac;
/*
 * Type?
 */
	while (!l->type) {
		printf("Type: ");
		if (!file_gets(stdin))
			abort();
		if (separate_tag())
			l->type = terrain_from_tag(0);
	}
#ifdef WORLD_HAS_CLIMATE
	if (l->type->type == TERRAIN_COUNTRY)
		l->next_climate = 1;
#endif
/*
 * Name?
 */
	while (!l->name) {
		printf("Name: ");
		if (!file_gets(stdin))
			abort();
		l->name = strdup(work);
	}
/*
 * Population?
 */
	if (!l->population) {
		printf("Population = (%d) ", l->type->optima);
		if (!file_gets(stdin))
			return;
		if (work[0])
			l->population = atoi(work);
		else
			l->population = l->type->optima;
	}
/*
 * Wages?
 */
	if (l->population && !l->wages) {
		printf("Wages = $");
		if (!file_gets(stdin))
			return;
		l->wages = atoi(work);
	}
/*
 * Recruitment
 */
	if (!(l->opportunity)) {
		while (1) {
			printf("Recruiting: ");
			if (!file_gets(stdin))
				return;
			if (!work[0])
				break;
			if (separate_tag() && (race = race_from_tag(0)) != 0) {
				frac = race->fraction;
				if (frac < 10)
					frac = 10;
				l->opportunity = parse_recruits(l->opportunity, race,
								l->population / frac,
								race->base_cost);
			}
		}
	}
/*
 * Overland resources
 */
	if (l->type->type == TERRAIN_COUNTRY) {
		while (1) {
			printf("Resource: ");
			if (!file_gets(stdin))
				return;
			if (!work[0])
				break;
			l->resources = parse_resource_item(l->resources);
		}
	}
/*
 * Complete locations
 */
	if (l->type->type == TERRAIN_COUNTRY) {
#ifdef USE_OVERLAND_COORDINATES
		if (!l->x || !l->y) {
		int	x, y;
			printf("X:");
			file_gets(stdin);
			x = atoi(work);
			printf("Y:");
			file_gets(stdin);
			y = atoi(work);
			if (x && y)
				recursive_relative_position(l, x, y);
		}
#else
		relative_positions_from(l);
#endif
		if (l->x && l->y) {
			if (l->x & 1)
				frac = 0;
			else
				frac = 1;
			complete_compass(l, 0, l->x, l->y-1);
			complete_compass(l, 1, l->x, l->y+1);
			complete_compass(l, 2, l->x+1, l->y-frac);
			complete_compass(l, 3, l->x-1, l->y+1-frac);
			complete_compass(l, 4, l->x+1, l->y+1-frac);
			complete_compass(l, 5, l->x-1, l->y-frac);
		}
	}
#ifdef DYNAMICALLY_DEFINED_GAME
	l->partial = 0;
#endif
}


/**
 ** Map editor entry point
 **/
int main(int argc, char **argv)
{
location_s	*new_location;
direction_s	*direction;
int		x;
/*
 * Pre-load
 */
	srand48(time(0));
	load_races();
	load_items();
	load_skills();
	load_titles();
	load_locations();
	current_location = location_list;
/*
 * Processing
 */
	while (1) {
		printf("[%s] > ", current_location->id.text);
		if (!file_gets(stdin))
			break;
		if (keyword("SAVE")) {
			save_locations();
			continue;
		}
		if (keyword("QUIT"))
			break;
		if (keyword("FOCUS")) {
			if (separate_tag()) {
				if ((new_location = location_from_id(0)) == 0)
					printf("No such ID\n");
				else {
					current_location = new_location;
					list(new_location);
				}
			}
			continue;
		}
		if (keyword("LIST")) {
			list(current_location);
			continue;
		}
		if (keyword("GO")) {
			if (keyword("OUT")) {
				if (current_location->outer) {
					current_location = current_location->outer;
					list(current_location);
					continue;
				}
			}
			new_location = 0;
			for (direction = current_location->exits; direction; direction = direction->next)
				if (keyword(direction->name)) {
					new_location = direction->toward;
					break;
				}
			if (new_location) {
				current_location = new_location;
				list(current_location);
				continue;
			}
			if (isdigit(*string_ptr)) {
				x = atoi(string_ptr);
				separate_token();
				if ((new_location = location_from_position(x, atoi(string_ptr))) != 0) {
					current_location = new_location;
					list(new_location);
				} else
					printf("No such coordinates\n");
				continue;
			}
			if (separate_tag() &&
			    (new_location = location_from_id(0)) != 0) {
					current_location = new_location;
					list(new_location);
					continue;
				}
			printf("No such direction.\n");
			continue;
		}
		if (keyword("COMPLETE")) {
			complete_location(current_location);
			continue;
		}
		if (keyword("NEW")) {
			current_location = random_location_id();
			complete_location(current_location);
		}
	}
	return 0;
}
