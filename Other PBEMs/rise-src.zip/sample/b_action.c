/* $Id: b_action.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $b
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"


/**
 ** Local scratchpad
 **/
#ifdef FX_SHIELDBREAKER
static char	shieldbreak = 0;
#endif

/**
 ** UNIT_HAS_ACTED
 **	Unit no longer has any opportunity to act. Remove from active list
 **/
void unit_has_acted(figure_s *unit)
{
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("[%s] has acted\n", unit->unit->id.text);
#endif
	if (unit->prev_initiative)
		unit->prev_initiative->next_initiative = unit->next_initiative;
	else
		if (acting_units == unit)
			acting_units = unit->next_initiative;
	if (unit->next_initiative)
		unit->next_initiative->prev_initiative = unit->prev_initiative;
	unit->has_acted = 1;
	unit->prev_initiative = 0;
	unit->next_initiative = 0;
}


#ifdef BATTLE_INITIATIVE
/**
 ** BATTLE_DELAY_PROCESSING
 **	Unit loses initiative
 **/
void battle_delay_processing(figure_s *unit)
{
figure_s	*prev, *next;
int		new_ini;
/*
 * Shift unit downward only if it has less initiated units
 */
	new_ini = unit->current_init;
	next = unit->next_initiative;
	if (next && next->current_init > new_ini) {
/*
 * Unlink from the current position
 */
		prev = unit->prev_initiative;
		next->prev_initiative = prev;
		if (prev == 0) {
			if (acting_units == unit)
				acting_units = next;
		} else
			prev->next_initiative = next;
/*
 * Now, search for the appropriate inititative slot
 */
		for (; next; next = next->next_initiative)
			if (next->current_init > new_ini)
				prev = next;
			else
				break;
/*
 * Insert at this position. Prev is always non zero, the previous loop being
 * always executed at least once, due to the entry condition.
 */
		unit->next_initiative = next;
		unit->prev_initiative = prev;
		prev->next_initiative = unit;
		if (next)
			next->prev_initiative = unit;
	}
}
#endif


/**
 ** TARGET_ADD
 **	Add one or more targets from the battlefield list of allies or ennemies
 **/
static void target_add(figure_s *unit, figure_s *list, int kind, int fx, int range)
{
int		skip;
/*
 * Insert all from list!
 */
	while (list) {
		if (list->living > 0) {
/*
 * Check validity of target
 */
			skip = 0;
			switch (kind) {
			    case BATTLEFIELD_TARGET_SELF:
				if (list != unit)
					skip = 1;
				break;
			    case BATTLEFIELD_TARGET_LEADER:
			    case BATTLEFIELD_TARGET_TARGET:
				if (list->race->type != RACE_LEADER)
					skip = 1;
				break;
			}
			if (!skip && (!fx || !battle_fx_target_check(list, fx)) ) {
/*
 * Target is valid, insert in range list
 */
				list->was_struck = 0;
				list->was_wounded = 0;
				list->was_hit = 0;
				list->has_lost = 0;
				list->next_target = unit->target;
				unit->target = list;
				list->range = range;
			}
		}
		list = list->same_square;
	}
}


/**
 ** ADD_TARGETS
 **	Any target in that specific square?
 **/
static void add_targets(figure_s *unit, int rank, int file, int kind, int fx, int range)
{
square_s	*here;
figure_s	*list, *list2;
/*
 * Do we fall in field?
 */
	if (rank < 0 || rank > 5 || file < 0 || file > 2)
		return;
	here = &battlefield[rank][file];
	if (unit->offense) {
		list = here->defenders;
		list2 = here->attackers;
	} else {
		list = here->attackers;
		list2 = here->defenders;
	}
	switch (kind) {
	    case BATTLEFIELD_TARGET_ALL:
		target_add(unit, list, kind, fx, range);
	    case BATTLEFIELD_TARGET_FRIENDLY:
	    case BATTLEFIELD_TARGET_LEADER:
	    case BATTLEFIELD_TARGET_SELF:
		target_add(unit, list2, kind, fx, range);
		break;
	    default:
		target_add(unit, list, kind, fx, range);
#ifdef FX_BATTLE_CONFUSED
		if (unit->friend_or_foe)
			target_add(unit, list2, kind, fx, range);
#endif
		break;
	}
}


/**
 ** RANDOM_TARGETING
 **	Shuffle the list of targets
 **/
static figure_s *random_targeting(figure_s *target)
{
figure_s	*next;
/*
 * Simple targetting
 */
	if (!target)
		return 0;
	next = random_targeting(target->next_target);
	if (!next)
		return target;
	if (roll_1Dx(2) == 0) {
		target->next_target = next;
		return target;
	}
	target->next_target = next->next_target;
	next->next_target = target;
	return next;
}


#ifdef STEALTH_STATS
/**
 ** SORT_BY_STEALTH
 **	Lower stealth first
 **/
static figure_s *sort_by_stealth(figure_s *target, int limit)
{
figure_s	*next;
/*
 * Simple targetting
 */
	if (!target)
		return 0;
	next = sort_by_stealth(target->next_target, limit);
	if (!next)
		return target;
/*
 * Modified stealth?
 */
	if (next->modified.stealth >= target->modified.stealth || next->modified.stealth <= limit) {
		target->next_target = next;
		return target;
	}
	target->next_target = next->next_target;
	next->next_target = target;
	return sort_by_stealth(next, limit);
}
#endif


/**
 ** TARGET_IN_RANGE
 **	Lists all the potential targets, randomised
 **/
static void target_in_range(figure_s *unit, int range, int kind, int fx)
{
/*
 * Link all potential targets
 */
	unit->target = 0;
	switch (range) {
	    default:
		printf("*** Impossible range %d\n", range);
	    case 7:
		add_targets(unit, unit->rank-5, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-5, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file+2, kind, fx, 1);
	    case 6:
		add_targets(unit, unit->rank-5, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-5, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file+1, kind, fx, 1);
	    case 5:
		add_targets(unit, unit->rank-5, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-4, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+5, unit->file, kind, fx, 1);
	    case 4:
		add_targets(unit, unit->rank-4, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-3, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+4, unit->file, kind, fx, 1);
	    case 3:
		add_targets(unit, unit->rank-3, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-2, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+3, unit->file, kind, fx, 1);
	    case 2:
		add_targets(unit, unit->rank-2, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank-1, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file-2, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file+2, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+2, unit->file, kind, fx, 1);
	    case 1:
		add_targets(unit, unit->rank-1, unit->file, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file-1, kind, fx, 1);
		add_targets(unit, unit->rank, unit->file+1, kind, fx, 1);
		add_targets(unit, unit->rank+1, unit->file, kind, fx, 1);
	    case 0:
		add_targets(unit, unit->rank, unit->file, kind, fx, 0);
	}
/*
 * Shuffle the target list around
 */
	unit->target = random_targeting(unit->target);
#ifdef STEALTH_STATS
	unit->target = sort_by_stealth(unit->target, unit->modified.observation);
#endif
}


/**
 ** MELEE_STRIKES
 **	Strike against targets!
 **/
static void melee_strikes(figure_s *unit, int hitting, int ranged, int fx)
{
figure_s	*target;
char		*separator;
int		defense;
int		size;
int		strikes, hits, wounds;
int		i;
int		cut_off;
int		value, deadly;
int		looped;
int		struck;
int		roll;
/*
 * We strikes how many times?
 */
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("[%s] strikes %d times (%s) with fx %d\n", unit->unit->id.text, hitting, ranged?"ranged":"melee", fx);
#endif
	target = unit->target;
	looped = 0;
	struck = 0;
	while (hitting) {
/*
 * Strike once against target, unless that target is the only in range
 */
		size = target->living;
		if (size > 0) {
			if (size > hitting)
				size = hitting;
			if (hitting > size && unit->target == target && !target->next_target)
				size = hitting;
			looped = 1;
/*
 * Go striking!
 */
			strikes = 0;
			if (ranged) {
				value = 40 + 4*unit->modified.missile;
				value += 4 * battlefield[unit->rank][unit->file].local_modifiers.missile;
			} else {
				value = 40 + 4*unit->modified.melee;
				value += 4 * battlefield[unit->rank][unit->file].local_modifiers.melee;
			}
			if (fx)
				value = 100;
			if (value >= 100)
				strikes = size;
			else
				for (i = 0; i < size; i++) {
					roll = roll_1Dx(100);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
					if (roll >= value && unit->side->fate)
						roll = roll_1Dx(100);
#endif
					if (roll < value)
						strikes++;
				}
/*
 * Strike attempt may fail due to aura of blackness
 */
#ifdef FX_BLACK_AURA
			if (target->black_aura) {
				for (i = strikes; i > 0; i--)
					roll = roll_1Dx(100);
					value = 70 - unit->modified.observation * 10;
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
					if (roll < value && unit->side->fate)
						roll = roll_1Dx(100);
#endif
					if (roll < value)
						strikes--;
			}
#endif
/*
 * Compute air-borne defense
 */
			defense = target->modified.defense;
			defense += battlefield[target->rank][target->file].local_modifiers.defense;
#ifdef FX_SHIELDBREAKER
			if (target->shield_breaker)
				defense -= 5;
#endif
			if (target->flying && !unit->flying)
				if (ranged)
					defense += 2;
				else
					defense += 5;
/*
 * How many hits and wounds?
 */
			if (defense <= 0) {
				hits = strikes;
				wounds = 0;
			} else {
				hits = 0;
				wounds = 0;
				if (ranged) {
					value = unit->modified.missile - (defense/2);
					value += battlefield[unit->rank][unit->file].local_modifiers.missile;
				} else {
					value = unit->modified.melee - defense;
					value += battlefield[unit->rank][unit->file].local_modifiers.melee;
				}
				if (unit->flying && !target->flying)
					value++;
				if (value > 0) {
					value += 2;
					for (i = 0; i < strikes; i++) {
						roll = roll_1Dx(value);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
						if (!roll && unit->side->fate)
							roll = roll_1Dx(value);
#endif
						if (roll != 0)
							hits++;
					}
				} else {
					value = 2 - value;
					deadly = 40 + 4 * unit->unit->vital.melee;
					for (i = 0; i < strikes; i++) {
						roll = roll_1Dx(value);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
						if (roll != 0 && unit->side->fate)
							roll = roll_1Dx(value);
#endif
						if (roll == 0) {
							roll = roll_1Dx(100);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
							if (roll >= deadly && unit->side->fate)
								roll = roll_1Dx(100);
#endif
							if (roll < deadly)
								hits++;
							else
								wounds++;
						}
					}
				}
			}
/*
 * If we hit, and we do damage above the unit's life, all hits are deadly,
 * and the over-hit is lost...
 */
			deadly = 0;
			if (unit->modified.damage >= target->modified.life) {
				deadly = hits;
				hits = 0;
			}
			cut_off = hits;
/*
 * Modified damage is equal to 0 or less?
 */
			if (unit->modified.damage > 0) {
				hits *= unit->modified.damage;
/*
 * Convert wounds to hits
 */
				if (target->wounded > target->living)
					target->wounded = target->living;
				if (wounds) {
					observation_round = 0;
					hits += (unit->modified.damage - 1) * wounds;
					value = target->living - target->wounded;
					if (wounds > value) {
					hits += wounds - value;
						cut_off += wounds - value;
						wounds = value;
					}
					target->wounded += wounds;
				}
/*
 * If we hit, we may make make casualties
 */
				if (hits) {
					observation_round = 0;
					target->hits += hits;
/*
 * Simplest case: accumulated enough hits to guarantee kills?
 */
					value = (target->modified.life - 1) * target->living;
					if (target->hits > value) {
						i = target->hits - value;
						if (i > target->living)
							i = target->living;
						target->hits -= target->modified.life * i;
						cut_off -= i;
						while (cut_off > target->hits)
							cut_off -= i;
						deadly += i;
					}
/*
 * If enough hits can kill at least one figure, we have a probability of
 * slaying some (equal to hits / total life points). We can't slay more than
 * hits.
 */
					while (cut_off > 0 && target->hits >= target->modified.life) {
						value = target->modified.life * (target->living - deadly);
						if (value <= 0)
							break;
						roll = roll_1Dx(value);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
						if (roll >= target->hits && unit->side->fate)
							roll = roll_1Dx(value);
#endif
						if (roll >= target->hits)
							break;
						deadly++;
						target->hits -= target->modified.life;
						cut_off--;
					}
				}
			}
/*
 * Collect kills
 */
			if (deadly >= target->living)
				deadly = target->living;
/*
 * Report results
 */
			struck += strikes;
			target->was_struck  += strikes;
			target->was_wounded += wounds;
			target->was_hit     += hits;
			target->has_lost    += deadly;
			target->living      -= deadly;
			target->deceased    += deadly;
/*
 * Next target, please...
 */
			hitting -= size;
		}
		if ((target = target->next_target) == 0) {
			if (!looped)
				break;
			looped = 0;
			target = unit->target;
		}
#ifdef STEALTH_STATS
		  else
/*
 * Target stealth above our observation rate, and other potential targets? Don't consider it
 */
			if (target->modified.stealth > unit->modified.observation && looped) {
				looped = 0;
				target = unit->target;
			}
#endif
	}
/*
 * Now, report on what happened
 */
	start_fold_unit_segment(unit);
	separator = "";
	if (!struck) {
		if (ranged)
			add_fold_string("fail to fire");
		else
			add_fold_string("fail to strike");
	} else
		for (target = unit->target; target; target = target->next_target)
			if (target->was_struck) {
				add_fold_string(separator);
				switch (target->was_struck) {
				    case 1:
					if (ranged)
						add_fold_string("fire once");
					else
						add_fold_string("strike once");
					break;
				    default:
					if (ranged)
						add_fold_string("fire ");
					else
						add_fold_string("strike ");
					add_fold_integer(target->was_struck);
					add_fold_string(" times");
				}
				target->fleeing = 0;
				add_fold_string(" against ");
				add_fold_string(target->unit->name);
				if (target->simplename)
					add_fold_tag(&target->unit->id);
				if (fx)
					battle_fx_strike(target, fx);
				if (!target->was_hit && !target->was_wounded && !target->has_lost && unit->modified.damage)
					add_fold_string(", missing");
				if (target->was_hit) {
					add_fold_string(" for ");
					add_fold_integer(target->was_hit);
					add_fold_string(" damage");
				}
				if (target->was_wounded) {
					if (target->was_hit)
						add_fold_string(" and ");
					else
						add_fold_string(" for ");
					add_fold_integer(target->was_wounded);
					add_fold_string(" wound");
					if (target->was_wounded > 1)
						add_fold_char('s');
				}
				if (target->has_lost) {
					observation_round = 0;
					target->side->casualties += target->has_lost;
					target->side->turn_casualties += target->has_lost;
					if (!target->fanatic)
						target->side->rout -= target->has_lost;
					add_fold_string(", slaying ");
					if (target->living <= 0) {
						add_fold_string("it");
						target->fleeing = 0;
						unit_away(target);
					} else
						add_fold_integer(target->has_lost);
				}
				separator = ", then ";
			}
	print_folded(full_report, 5);
	print_folded(long_report, 5);
}


/**
 ** FIRST_MELEE_STRIKE
 **	We start the first (if many hit) strike of the melee
 **/
static int first_melee_strike(figure_s *unit, int amount, int fx)
{
	melee_strikes(unit, amount, 0, fx);
	if (unit->modified.hits > 1) {
#ifdef TRACING_REQUIRED
	if (unit->unit->traced_unit)
		printf("[%s] restrikes\n", unit->unit->id.text);
#endif
		unit->mandated.option = COMBAT_SET_RESTRIKE;
		unit->mandated.initiative = initiative_level-1;
		unit->repeating = unit->modified.hits - 1;
		unit->considered = &unit->mandated;
		return 1;
	}
	return 0;
}


/**
 ** ADJUST_VITALS
 **	Adjust the unit's vital stats, according to bonuses and settings
 **/
static void adjust_vitals(figure_s *unit, combat_s *does)
{
/*
 * Set or modifies?
 */
	if (does->action.melee)
		unit->modified.melee = does->action.melee;
	else
		unit->modified.melee += does->bonus.melee;
	if (does->action.missile)
		unit->modified.missile = does->action.missile;
	else
		unit->modified.missile += does->bonus.missile;
	if (does->action.defense)
		unit->modified.defense = does->action.defense;
	else
		unit->modified.defense += does->bonus.defense;
	if (does->action.life)
		unit->modified.life = does->action.life;
	else
		unit->modified.life += does->bonus.life;
	if (does->action.hits)
		unit->modified.hits = does->action.hits;
	else
		unit->modified.hits += does->bonus.hits;
	if (does->action.damage)
		unit->modified.damage = does->action.damage;
	else
		unit->modified.damage += does->bonus.damage;
#ifdef STEALTH_STATS
	if (does->action.stealth)
		unit->modified.stealth = does->action.stealth;
	else
		unit->modified.stealth += does->bonus.stealth;
	if (does->action.observation)
		unit->modified.observation = does->action.observation;
	else
		unit->modified.observation += does->bonus.observation;
#endif
}


/**
 ** COMBAT_SPECIAL
 **	A skill or combat item is being used!
 **/
static int combat_special(figure_s *unit, int amount, combat_s *does, int fx, char *name, skill_s *effective)
{
/*
 * If no one is using, we skip this!
 */
#ifdef FX_SHIELDBREAKER
	shieldbreak = 0;
#endif
	if (amount == 0)
		return 1;
/*
 * Compute the target
 */
	if (does->target) {
		target_in_range(unit, does->range, does->target, fx);
#ifdef FX_SHIELDBREAKER
		if (unit->target && unit->target->shield_breaker) {
			shieldbreak = 1;
			return 1;
		}
#endif
	}
/*
 * Ok, so an effect is likely. What is the target, however?
 */
	switch (does->effect) {
	    case COMBAT_EFFECT_MELEE:
		if (!unit->target) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("[%s] has no melee target for %s at range %d\n", unit->unit->id.text, effective->tag.text, does->range);
#endif
			unit->considered++;
			return 1;
		}
		start_fold_unit_segment(unit);
		add_fold_string("use ");
		add_fold_string(name);
		print_folded(full_report, 5);
		print_folded(long_report, 5);
		adjust_vitals(unit, does);
		(void)first_melee_strike(unit, amount, fx);
		return 0;
	    case COMBAT_EFFECT_RANGED:
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("[%s] has no ranged target for %s at range %d\n", unit->unit->id.text, effective->tag.text, does->range);
#endif
		if (!unit->target) {
			unit->considered++;
			return 1;
		}
		start_fold_unit_segment(unit);
		add_fold_string("use ");
		add_fold_string(name);
		print_folded(full_report, 5);
		print_folded(long_report, 5);
		adjust_vitals(unit, does);
		melee_strikes(unit, amount, 1, fx);
		if (unit->modified.hits > 1) {
			unit->mandated.option = COMBAT_SET_RESHOOT;
			unit->mandated.initiative = initiative_level-1;
			unit->repeating = unit->modified.hits - 1;
			unit->considered = &unit->mandated;
			unit->targets = does->target;
			unit->ranges  = does->range;
		}
		return 0;
	    case COMBAT_EFFECT_SPECIAL:
		if (battle_fx_effect(unit, amount, fx, name, effective)) {
			unit->considered++;
			return 1;
		}
		return 0;
	    default:
		printf("Impossible combat effect %d\n", does->effect);
	}
	return 1;
}


/**
 ** BATTLE_COMPONENTS_AWAY
 **	We check if all required components are present. If required, we also
 ** remove these (it is assumed we did check first).
 **/
int battle_components_away(unit_s *unit, skill_s *skill, int removal)
{
consume_s	*component;
carry_s		*owns;
/*
 * Loop on all
 */
	for (component = skill->use_consumes; component; component = component->next)
		if ((owns = unit_possessions(unit, component->what, 0)) == 0 ||
		    owns->amount < component->amount) {
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("[%s] lacks components for %s\n", unit->id.text, skill->tag.text);
#endif
			return 1;
		} else
			if (removal)
				owns->amount -= component->amount;
/*
 * it is assumed that components are never equippable
 */
#ifdef TRACING_REQUIRED
	if (unit->traced_unit)
		printf("[%s] has components for %s\n", unit->id.text, skill->tag.text);
#endif
	return 0;
}


/**
 ** UNIT_MAY_ACT
 **	Unit has an opportunity to act
 **/
int unit_may_act(figure_s *unit)
{
int		new_ini;
unit_s		*real;
carry_s		*equipment;
experience_s	*used;
combat_set_s	*doing;
skill_s		*used_skill;
item_s		*used_item;
/*
 * Simplest case
 */
	if (unit->active <= 0)
		unit_has_acted(unit);
	if (unit->has_acted)
		return 0;
/*
 * Various actions
 */
	doing = unit->considered;
	if (doing->skill_used || doing->disabled)
		unit->considered++;
	else
	switch (doing->option) {
/*
 * Easy options
 */
	    case COMBAT_SET_PARRY:
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("[%s] parries\n", unit->unit->id.text);
#endif
		if (unit->modified.melee > 0) {
			start_fold_unit_segment(unit);
			add_fold_string("parries");
			print_folded(full_report, 5);
			print_folded(long_report, 5);
			unit->modified.defense += unit->modified.melee;
			unit->parry_exp++;
		}
		unit_has_acted(unit);
		return 0;
	    case COMBAT_SET_RELOAD:
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("[%s] reloads\n", unit->unit->id.text);
#endif
		start_fold_unit_segment(unit);
		add_fold_string("reloads");
		print_folded(full_report, 5);
		print_folded(long_report, 5);
		unit_has_acted(unit);
		return 0;
/*
 * More complex
 */
	    case COMBAT_SET_MELEE:
#ifdef TRACING_REQUIRED
		if (unit->unit->traced_unit)
			printf("[%s] attempts to strike\n", unit->unit->id.text);
#endif
		if (unit->modified.melee <= 0) {
			unit->considered++;
			break;
		}
		target_in_range(unit, 1, BATTLEFIELD_TARGET_OPPOSING, 0);
		if (!unit->target) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("[%s] has no targets\n", unit->unit->id.text);
#endif
			unit->considered++;
			break;
		}
		unit->melee_exp++;
		if (first_melee_strike(unit, unit->active, 0))
			break;
		unit_has_acted(unit);
		return 0;
	    case COMBAT_SET_RESTRIKE:
		if (unit->modified.melee <= 0)
			break;
		target_in_range(unit, 1, BATTLEFIELD_TARGET_OPPOSING, 0);
		if (unit->target) {
			melee_strikes(unit, unit->active, 0, 0);
			unit->repeating--;
			if (unit->repeating ) {
				unit->mandated.initiative = initiative_level-1;
				break;
			}
		}
		unit_has_acted(unit);
		return 0;
	    case COMBAT_SET_RESHOOT:
		if (unit->modified.missile <= 0)
			break;
		target_in_range(unit, unit->ranges, unit->targets, 0);
		if (unit->target) {
			melee_strikes(unit, unit->active, 1, 0);
			unit->repeating--;
			if (unit->repeating ) {
				unit->mandated.initiative = initiative_level-1;
				break;
			}
		}
		unit_has_acted(unit);
		return 0;
/*
 * Special skills
 */
	    case COMBAT_SET_SKILL:
/*
 * Does the combat skill require components? If so, do we have them?
 */
		real = unit->unit;
		used_skill = doing->u.use_skill;
		used = unit_experiences(real, used_skill, 0);
		if (!used || !used->effective) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("[%s] does not master skill %s\n", unit->unit->id.text, used_skill->tag.text);
#endif
			unit->considered++;
			break;
		}
		if (battle_components_away(real, used->effective, 0)) {
			unit->considered++;
			break;
		}
		if (combat_special(unit, unit->active, &used_skill->combat_action, used_skill->special_effects, used_skill->name, used->effective)) {
#ifdef FX_SHIELDBREAKER
			if (shieldbreak) {
				start_fold_unit_segment(unit);
				add_fold_string("falls against Shieldbreaker and cannot use ");
				add_fold_string(used_skill->name);
				print_folded(full_report, 5);
				unit->considered->disabled = 1;
			}
#endif
			unit->considered++;
			break;
		}
/*
 * The combat skill was acted upon, we consume the material
 */
		(void)battle_components_away(real, used->effective, 1);
		if (round_number <= 20)
			used->points += unit->active * (SKILL_POINTS_PER_DAY / 2);
/*
 * The action calls for a repeat?
 */
		if (unit->considered == &unit->mandated)
			break;
		if (used_skill->type == 2) {
			unit->considered->skill_used = 1;
			unit->considered->avoid_action = 1;
		}
		unit_has_acted(unit);
		return 0;
/*
 * Special items
 */
	    case COMBAT_SET_ITEM:
		real = unit->unit;
		used_item = doing->u.use_item;
		for (equipment = unit->using; equipment; equipment = equipment->next)
			if (equipment->item == used_item)
				break;
		if (!equipment || !equipment->equipped) {
#ifdef TRACING_REQUIRED
			if (unit->unit->traced_unit)
				printf("[%s] has no equipment %s\n", unit->unit->id.text, used_item->tag.text);
#endif
			unit->considered++;
			break;
		}
		if (equipment->equipped > unit->active)
			equipment->equipped = unit->active;
		if (combat_special(unit, equipment->equipped, &used_item->combat_action, used_item->special_effects, equipment->equipped > 1 ? used_item->plural : used_item->name, 0)) {
#ifdef FX_SHIELDBREAKER
			if (shieldbreak) {
			carry_s	*owns;
				start_fold_unit_segment(unit);
				add_fold_string("falls against Shieldbreaker and loses its ");
				if (equipment->equipped > 1)
					add_fold_string(used_item->plural);
				else
					add_fold_string(used_item->name);
				print_folded(full_report, 5);
				unit->considered->disabled = 1;
				equipment->equipped = 0;
				equipment->amount = 0;
				owns = unit_possessions(unit->unit, used_item, 0);
				if (owns) {
					owns->equipped = 0;
					owns->amount = 0;
				}
			}
#endif
			unit->considered++;
			break;
		}
/*
 * We performed the action
 */
		if (used_item->equip_skill && round_number <= 20) {
			used = unit_experiences(real, used_item->equip_skill, 1);
			used->points += equipment->equipped * (SKILL_POINTS_PER_DAY / 2);
		}
/*
 * The action calls for a repeat?
 */
		if (unit->considered == &unit->mandated)
			break;
		unit_has_acted(unit);
		return 0;
/*
 * Anything else constitues the end of activities for that unit
 */
	    default:
		unit_has_acted(unit);
		return 0;
	}
/*
 * None? Next action then.
 */
#ifdef BATTLE_INITIATIVE
	if ((new_ini = unit->considered->initiative) < initiative_level) {
		unit->current_init = new_ini;
		battle_delay_processing(unit);
		return 0;
	}
#endif
	return 1;
}
