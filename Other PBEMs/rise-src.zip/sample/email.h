/* $Id: email.h,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	User-configurable file
 *
 * This file sets the appropriate global behaviour of the game server.
 * It defines how the game_server executable is called.
 */

/**
 **	MAIL_VIRTUAL_HOST
 ** Use this setting if the game server can be called as a virtual host.  This
 ** requires admin privileges to configure your mail system, and ownership of
 ** your DNS.  The game server then works as "xxxx@gamename.domainname", where
 ** xxxx is either a faction tag, a unit tag, or one of: "gm" (game master)
 ** or "game" (order/press submission).
 ** You must arrange for the game_server binary to be called by the MTA with
 ** one of the following forms:
 **	.../game_server xxxx@gamename.domainname
 ** or
 **	.../game_server xxxx
 ** or
 **	.../game_server xxxx@gamename.domainname /what/ever/path/is/used
 **
 ** The pathname of the game directory will be the pathname used to start the
 ** game_server binary, or the supplied pathname.
 **/
#define MAIL_VIRTUAL_HOST


/**
 **	ANONYMOUS_PLAY
 ** If this is set, the players remain anonymous. This mainly concerns the
 ** html index generator
 **/
#undef ANONYMOUS_PLAY


/**
 **	MAIL_VIRTUAL_NAME
 ** If you are using a MAIL_VIRTUAL_HOST, this is the order/press email address
 ** that players specify.  If left unspecified, it defaults to "server".
 **/
#undef MAIL_VIRTUAL_NAME


/**
 **	MAIL_VIRTUAL_GM
 ** If you are using a MAIL_VIRTUAL_GM, this is the gamemaster email address
 ** that players specify.  If left unspecified, it defaults to "gm".  It is
 ** used only if MAIL_GM_ADDRESS is also defined.
 **/
#undef MAIL_VIRTUAL_GM


/**
 **	MAIL_GM_ADDRESS
 ** Specify here the email address of the game master.  It is used only if you
 ** are a MAIL_VIRTUAL_HOST to forward any message sent to "gm".  If left
 ** undefined, the "gm@gamename..." address will not exist.
 **/
#undef MAIL_GM_ADDRESS


/**
 **	MAIL_ALIAS_OR_FORWARD
 ** Use this setting if the game server is called whenever a mail is addressed
 ** to someuser@your-mail-host.  You can set this as a system-wide alias, or
 ** as a .forward in an account or maybe preferably as some rule system in a
 ** procmail delivery.  You must arrange from the game_server binary to be
 ** called with the following form: .../game_server
 **	or
 ** .../game_server /what/ever/path/is/used
 **
 ** The pathname of the game directory will be the pathname used to start the
 ** game_server binary, or the supplied pathname.  The server will determine
 ** its function from the Subject line.
 **
 ** This is the default setting!
 **/
#undef MAIL_ALIAS_OR_FORWARD


/**
 **	MAIL_PROCESS_FILES
 ** Use this setting if the game server is called off-line at times to process
 ** the contents of a mailbox.  It is essentially equivalent to MAIL_ALIAS_...
 ** but the server doesn't need to lock or prevent concurrent access, as the
 ** game master is supposed to do that.
 **
 ** It is assumed that files are processed in chronological order. 
 **/
#undef MAIL_PROCESS_FILES


/**
 **	MAIL_USER_ID
 ** Use this setting to specify under whatever user id is needed.  Specify this
 ** if your are a MAIL_VIRTUAL_HOST or MAIL_ALIAS_OR_FORWARD with alias (not
 ** forward/procmail).  The very first thing the game_server will do is to
 ** switch its user id from 0 to the MAIL_USER_ID.
 ** It must be a numerical value.
 **/
#define MAIL_USER_ID 200


/**
 **	MAIL_NO_CHECK
 ** Use this setting to disable the syntax checker.  The syntax checker will
 ** not be called for player orders.  It is a borderline case, when mail is
 ** processed so infrequently that a user will not get a syntax check back in
 ** time to change its orders.
 **/
#undef MAIL_NO_CHECK


/**
 **	KEEP_CHECKER_OUTPUT
 ** Use this to keep a copy of the last checker output for players in their
 ** game directory. Meaningful only if MAIL_NO_CHECK isn't defined, and
 ** probably only if the users are allowed access to their game directories.
 **/
#define KEEP_CHECKER_OUTPUT


