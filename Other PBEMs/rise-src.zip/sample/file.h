/* $Id: file.h,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	File routines include. Many Overlord modules include it.
 */
#ifndef overlord_file_h
#define overlord_file_h


/*
 * Prototypes
 */
extern int		file_gets(FILE *);
extern char		*new_file(char *);


/*
 * Global variables
 */
extern char		*string_ptr;
extern char		work[8192];


#endif/*overlord_file_h*/
