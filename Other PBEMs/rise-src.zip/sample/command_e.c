/* $Id: command_e.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Command argument strings
 */

char		stance_arguments[] = 
			"ally\nfriend\nneutral\nhostile\nennemy";
static char	boolean_arguments[] =
			"off\non";
char		participate_modes[] = "avoid\ndefend\nfight\nguard";
char		battlefield_ranks[] = "rear\nmiddle\nfront";
char		battlefield_files[] = "left\ncenter\nright";
char		battlefield_moves[] = "flee\nretreat\nstand\nadvance\nsweep\nflank\ncharge\nfire\nsupport";
char		possible_settings[] = "advertise\nannounce\nhtml\nmiser\nsilent\nsupport\nterse";
static char	combat_arguments[] =
			"reload\nmelee\nparry";
char		movement_modes[] = "walking\nriding\nflying\nsailing";
