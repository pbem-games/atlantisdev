/* $Id: b_round.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Battle module: Process rounds
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"


/**
 ** Locally set variables
 **/
int			observation_round;
int			initiative_level;
int			round_number;
static char		routed;


/**
 ** FIGURE_POSSESSIONS
 **	Figure possess the given object!
 **/
carry_s *figure_possessions(figure_s *unit, item_s *item)
{
carry_s	*has, *previous;
/*
 * Go
 */
	if (!item) abort();
	previous = 0;
	for (has = unit->using; has; has = has->next)
		if (has->item == item)
			return has;
		else
			previous = has;
	return has;
}


/**
 ** COMPUTE_BATTLE_STATS
 **	Compute the appropriate stats value at the start of a battle round
 **/
void compute_battle_stats(figure_s *figure, int reinit)
{
experience_s	*skill;
skill_s		*known;
carry_s		*load;
item_s		*kind;
unit_s		*unit;
int		size, equipped;
/*
 * Compute stats
 */
	unit = figure->unit;
	size = figure->active;
	if (!figure->race || !size) {
		memset(&figure->vital, 0, sizeof(figure->vital));
		return;
	}
	figure->vital = figure->race->intrinsic;
#ifdef FX_HEAVINESS
	figure->vital.melee   -= figure->heavy_penalty * 2;
	figure->vital.defense -= figure->heavy_penalty;
	figure->vital.missile -= figure->heavy_penalty;
#endif
	figure->vital.melee   += figure->bonus.melee;
	figure->vital.defense += figure->bonus.defense;
	figure->vital.missile += figure->bonus.missile;
	figure->vital.life    += figure->bonus.life;
	figure->vital.damage  += figure->bonus.damage;
	figure->vital.hits    += figure->bonus.hits;
#ifdef BATTLE_INITIATIVE
	figure->vital.initiative += figure->bonus.initiative;
#ifdef FX_HEAVINESS
	figure->vital.initiative -= figure->heavy_penalty;
#endif
#endif
#ifdef STEALTH_STATS
        figure->vital.stealth += figure->bonus.stealth;
        figure->vital.observation += figure->bonus.observation;
#endif
#ifdef USES_MANA_POINTS
        figure->vital.mana    += figure->bonus.mana;
#endif
/*
 * Flying units have a bonus to initiative
 */
	if (figure->flying)
		figure->vital.initiative += 2;
/*
 * Apply skill knowledge
 */
	for (skill = unit->skilled; skill; skill = skill->next)
		if ((known = skill->effective) != 0) {
			add_to_stats(&figure->vital, &known->bonus);
/*
 * Factor in "dread" factor
 */
#ifdef STEALTH_STATS
			if (known->combat_action.bonus.stealth && !known->combat_action.effect)
				unit->vital.stealth += known->combat_action.bonus.stealth;
#endif
		}
/*
 * Add equipment bonus
 */
	for (load = figure->using; load; load = load->next) {
		if ((kind = load->item)->item_type == ITEM_DAYS) {
			add_to_stats(&figure->vital, &kind->equip_bonus);
			continue;
		}
		if (load->amount == 0)
			continue;
		if (load->amount > size)
			load->amount = size;
		if (load->equipped > size)
			load->equipped = size;
		if (reinit)
			load->equipped = load->amount;
		if ((equipped = load->equipped) != 0)
			add_proportional_stats(&figure->vital, &kind->equip_bonus, equipped, size);
	}
}


/**
 ** INITIATIVE_SEGMENT
 **	Rounds are further sub-divided into various segments!
 **/
static void initiative_segment(void)
{
figure_s	*next;
figure_s	*unit;
int		max;
/*
 * We are running at this initiative level
 */
#ifdef BATTLE_INITIATIVE
	initiative_level = acting_units->current_init;
#endif
/*
 * Move all units
 */
	for (unit = acting_units; unit; unit = next) {
#ifdef BATTLE_INITIATIVE
		if (unit->current_init < initiative_level)
			break;
#endif
		next = unit->next_initiative;
		unit->active = unit->living;
		if (unit->has_moved || unit->living < 0)
			continue;
		if (unit->flying) {
			max = 7;
			while (move_soldier(unit))
				if (max-- < 0)
					break;
		} else
			(void)move_soldier(unit);
	}
/*
 * All movements have concluded. Any action?
 */
	for (unit = acting_units; unit; unit = next) {
#ifdef BATTLE_INITIATIVE
		if (unit->current_init < initiative_level)
			break;
#endif
		next = unit->next_initiative;
		while (unit_may_act(unit))
			;
		if (next && next->has_acted)
			break;
	}
/*
 * Initiative segment has ended, tally losses. Units had a last chance to
 * strike against their foes.
 */
	for (unit = acting_units; unit; unit = next) {
		next = unit->next_initiative;
		if (unit->living <= 0) {
			unit_away(unit);
			unit->living = 0;
			unit_has_acted(unit);
		}
	}
}


/**
 ** ACTIVATE_THIS_UNIT
 **	One unit joins the rank of activated units
 **/
static void activate_this_unit(figure_s *unit)
{
figure_s	*last, *insert;
combat_set_s	*actions;
unit_s		*real;
experience_s	*knows;
carry_s		*holds;
int		i;
#ifdef BATTLE_INITIATIVE
int		upper, base, value;
#endif
/*
 * Dead units do not activate, nor fled units
 */
	if (unit->living <= 0) {
		unit->fleeing++;
		return;
	}
	if (unit->fleeing >= 3) {
		unit->fled++;
		return;
	}
	unit->active = unit->living;
#ifdef FX_BLACK_AURA
	if (unit->black_aura > 0)
		unit->black_aura--;
#endif
#ifdef FX_HEAVINESS
	if (unit->heavy > 0)
		unit->heavy--;
#endif
#ifdef FX_BATTLE_CONFUSED
	unit->friend_or_foe = 0;
#endif
	compute_battle_stats(unit, 1);
	unit->modified = unit->vital;
	unit->modified.initiative += battlefield[unit->rank][unit->file].local_modifiers.initiative;
	real = unit->unit;
/*
 * If the unit has mana power, and we're not on the starting round, then one
 * mana is regained each round!
 */
#ifdef USES_MANA_POINTS
	if (real->vital.mana) {
		if (!real->power)
			real->power = unit_possessions(real, item_mana, 1);
		if (real->power->amount < real->vital.mana)
			real->power->amount++;
	}
#endif
	unit->pending_effects = unit->permanent_effects;
/*
 * Actions
 */
	if (unit->reloading) {
		unit->reloading--;
		unit->mandated.option = COMBAT_SET_RELOAD;
		unit->considered = &unit->mandated;
	} else {
/*
 * Make sure all actions are allowed
 */
		unit->mandated.option = COMBAT_SET_NONE;
		unit->considered = unit->actions;
		for (actions = unit->actions; actions->option; actions++) {
			actions->skill_used = 0;
			switch (actions->option) {
			    case COMBAT_SET_SKILL:
				if (!(knows = unit_experiences(real, actions->u.use_skill, 0)) ||
				    !knows->effective)
					actions->disabled = 1;
				break;
			    case COMBAT_SET_ITEM:
				if (!(holds = figure_possessions(unit, actions->u.use_item)) ||
				    !holds->equipped)
					actions->disabled = 1;
				else
					actions->disabled = 0;
				break;
			}
		}
	}
	unit->repeating = 0;
#ifdef BATTLE_INITIATIVE
	base = unit->vital.initiative + unit->side->tactician + unit->side->strategist +
		unit->tactical_bonus;
	if (unit->tactical_bonus > 0)
		unit->tactical_bonus--;
	else
		if (unit->tactical_bonus < 0)
		unit->tactical_bonus++;
	unit->mandated.initiative = base - 1;
	upper = 999;
	for (i = 0; i < MAX_COMBAT_SETTING; i++) {
		switch(unit->actions[i].option) {
		    case COMBAT_SET_RELOAD:
			value = base - 1;
			break;
		    case COMBAT_SET_PARRY:
			value = base + 2;
			break;
		    case COMBAT_SET_SKILL:
			value = base + unit->actions[i].u.use_skill->combat_action.bonus.initiative;
			break;
		    case COMBAT_SET_ITEM:
			value = base + unit->actions[i].u.use_item->combat_action.bonus.initiative;
			break;
		    default:
			value = base;
		}
		if (value > upper)
			value = upper;
		unit->actions[i].initiative = value;
		upper = value;
	}
	value = unit->considered->initiative;
	unit->current_init = value;
/*
 * Insertion sort
 */
	last = 0;
	for (insert = acting_units; insert; insert = insert->next_initiative)
		if (insert->current_init < value)
			break;
		else
			last = insert;
	if (insert)
		insert->prev_initiative = unit;
	unit->next_initiative = insert;
	if (last)
		last->next_initiative = unit;
	else
		acting_units = unit;
	unit->prev_initiative = last;
#else /* not BATTLE_INITIATIVE */
	if ((unit->next_initiative = acting_units) != 0)
		acting_units->prev_initiative = unit;
	unit->prev_initiative = 0;
	acting_units = unit;
#endif
/*
 * Unit hasn't done anything yet
 */
#ifdef FX_HEAVINESS
	if (unit->heavy)
		unit->has_moved = 1;
	else
#endif
	unit->has_moved = 0;
	unit->has_acted = 0;
	unit->combat_exp++;
}


/**
 ** PROCESS_ONE_ROUND
 **	We process one round in two steps: First, we sort by
 ** initiative. Then, we run each initiative segment
 **/
static void process_one_round(void)
{
figure_s	*unit;
int		i, j;
/*
 * Create the list of acting units. Only live units are considered
 */
	acting_units = 0;
	for (unit = attackers.units; unit; unit = unit->same_side)
		activate_this_unit(unit);
	for (unit = defenders.units; unit; unit = unit->same_side)
		activate_this_unit(unit);
	for (i = 0; i < 6; i++)
		for (j = 0; j < 3; j++)
			memset(&battlefield[i][j].local_modifiers, 0, sizeof(stats_s));
/*
 * Report heading
 */
	round_number++;
	observation_round++;
	fprintf(full_report, "Round %d:\n", round_number);
	fprintf(long_report, "Round %d:\n", round_number);
	fprintf(terse_report, "Round %d:\n", round_number);
#ifdef FX_STONE_HEADS
	attackers.stone_headed = 0;
	defenders.stone_headed = 0;
#endif
/*
 * All units now start to move, then fight
 */
	while (acting_units) {
		initiative_segment();
		if (attackers.size <= attackers.casualties  ||
		    defenders.size <= defenders.casualties)
			break;
	}
/*
 * Now sums the casualties, and check if battle ends now!
 */
	putc('\n', full_report);
	putc('\n', long_report);
	fprintf(terse_report, "Attacking casualties: %d\n", attackers.turn_casualties);
	if (attackers.turn_casualties) {
		fprintf(full_report, "Attacking casualties: %d\n", attackers.turn_casualties);
		fprintf(long_report, "Attacking casualties: %d\n", attackers.turn_casualties);
	}
	fprintf(terse_report, "Defending casualties: %d\n", defenders.turn_casualties);
	if (defenders.turn_casualties) {
		fprintf(full_report, "Defending casualties: %d\n", defenders.turn_casualties);
		fprintf(long_report, "Defending casualties: %d\n", defenders.turn_casualties);
	}
	attackers.turn_casualties = 0;
	defenders.turn_casualties = 0;
	putc('\n', terse_report);
	putc('\n', full_report);
	putc('\n', long_report);
/*
 * Decrease the amount of tactical advantage
 */
	if (attackers.tactician)
		attackers.tactician--;
	if (defenders.tactician)
		defenders.tactician--;
	fflush(full_report);
}


/**
 ** ROUT_ORDERS
 **	Rout orders are quite simple: all units except fanatics are
 ** switched to "flee", two-third have "parry" as order, the rest has
 ** none.
 **/
static void rout_orders(figure_s *unit)
{
int	parry;
/*
 * Loop
 */
	while (unit) {
		if (!unit->fanatic) {
			unit->movement = 0; /* is flee */
			parry = roll_1Dx(3);
#if defined(FX_COINSPINNER) || defined(USES_FATE_POINTS)
			if (unit->side->fate)
				parry |= roll_1Dx(3);
#endif
			if (parry) {
				unit->actions[0].option = COMBAT_SET_PARRY;
				unit->actions[0].disabled = 0;
				unit->actions[0].avoid_action = 0;
				unit->actions[1].option = 0;
			} else
				unit->actions[0].option = 0;
		}
		unit = unit->same_side;
	}
}


/**
 ** RUN_BATTLE
 **/
void run_battle(void)
{
/*
 * Rounds
 */
	round_number = 0;
	routed = 0;
	observation_round = 0;
	while (!attackers.lost && !defenders.lost && round_number < 100) {
		process_one_round();
/*
 * Battle ends in a tie?
 */
		if (observation_round >= 10) {
			fprintf(full_report, "No hits for 10 rounds...\n");
			fprintf(long_report, "No hits for 10 rounds...\n");
			fprintf(terse_report, "No hits for 10 rounds...\n");
			attackers.lost = 1;
			defenders.lost = 1;
			break;
		}
/*
 * Attackers are all dead? Or in rout?
 */
		if (attackers.casualties >= attackers.size) {
			attackers.lost = 1;
		} else
			if (attackers.rout < 0) {
/*** HACK ***/
				attackers.lost = 1;
				routed = 1;
			}
/*
 * Defenders are all dead?
 */
		if (defenders.casualties >= defenders.size) {
			defenders.lost = 1;
		} else
			if (defenders.rout < 0) {
/*** HACK ***/
				defenders.lost = 1;
				routed = 1;
			}
	}
/*
 * Rout round? Only if one side lost, and not the other
 */
	if (routed) {
		if (attackers.lost) {
			if (!defenders.lost) {
				fprintf(long_report, "\nAttackers are routed!\n");
				fprintf(full_report, "\nAttackers are routed!\n");
				fprintf(terse_report, "\nAttackers are routed!\n");
				rout_orders(attackers.units);
				process_one_round();
			}
		} else
			if (defenders.lost) {
				fprintf(long_report, "\nDefenders are routed!\n");
				fprintf(full_report, "\nDefenders are routed!\n");
				fprintf(terse_report, "\nDefenders are routed!\n");
				rout_orders(defenders.units);
				process_one_round();
			}
	}
/*
 * The fanatics may still cause a Pyrrhic victory after rout!
 */
	if (attackers.casualties >= attackers.size) {
		attackers.lost = 1;
		defenders.lost = 0;
	}
	if (defenders.casualties >= defenders.size) {
		defenders.lost = 1;
		if (attackers.casualties < attackers.size)
			attackers.lost = 0;
	}
/*
 * Reporting ties.
 */
	if (attackers.lost == defenders.lost) {
		fprintf(long_report, "\nBattle ends as a tie; no victors.\n");
		fprintf(full_report, "\nBattle ends as a tie; no victors.\n");
		fprintf(terse_report, "\nBattle ends as a tie; no victors.\n");
		attackers.lost = 0;
		defenders.lost = 0;
	}
}
