/* $Id: turn.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Turn processor main module.
 */
#include "turn.h"
#include "parser.h"
#include "fx.h"
#include "battle.h"
#include <time.h>


/**
 ** Globals
 **/
int		today_number;
item_s		*token_tax,
		*token_entertain,
		*discontent_effect,
		*item_dead, *item_corpse,
		*item_mstudy,
		*item_fish,
		*item_cash;
#ifdef USES_MANA_POINTS
item_s		*item_mana;
#endif
skill_s		*magecraft,
		*combat_skill,
		*melee_skill,
		*parry_skill,
		*marketing_skill,
		*scouting_skill;
skill_s		*air_skill,
		*earth_skill,
		*fire_skill,
		*void_skill,
		*water_skill;
terrain_s	*terrain_city;
faction_s	*outlaw_faction;


#if defined(END_OF_WORLD) && (END_OF_WORLD == 3)
/**
 ** DREAM_TIME
 **	It is the end of the world. For each non-NPC faction, create a
 **	dream plains, and connect to L0
 **/
static void dream_time(void)
{
location_s	*neverneverland;
location_s	*dream_plains;
direction_s	*exits;
faction_s	*factions;
unit_s		*units;
/*
 * Create headquarters
 */
	synthetic_tag("L0");
	neverneverland = location_from_id(0);
	for (factions = faction_list; factions; factions = factions->next)
		if (!factions->npc) {
			dream_plains = random_location_id();
			dream_plains->type = neverneverland->type;
			dream_plains->name = "Dream Plains";
			exits = new_direction_from_location();
			exits->toward = neverneverland;
			exits->name = "TrueWest";
			exits->days = 1;
			dream_plains->exits = exits;
			factions->headquarters = dream_plains;
		}
/*
 * Move all units to their destination
 */
	for (units = unit_list; units; units = units->next)
		if (units->size && !units->dead && !units->inactive) {
			factions = units->faction;
			if (factions->npc)
				continue;
			if (units->leader)
				unstack_unit(units);
			while (units->stack)
				unstack_unit(units->stack);
			move_to_location(units, factions->headquarters);
			units->is_moving = 0;
			units->move_for_days = 0;
			units->toward = 0;
			sprintf(work, "That night, %s experience%s a vivid dream", units->name,
					units->size == 1 ? "s" : "");
			unit_personal_event(units, 30, work);
		}
}
#endif


/**
 ** WAGES_ARE_PAID
 **	Wages are paid
 **/
static void wages_are_paid(void)
{
unit_s		*unit;
carry_s		*pay;
long		cash;
/*
 * Collect wages
 */
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead)
			continue;
		if (unit->wages) {
			if ((pay = unit->coins) == 0)
				unit->coins = pay = unit_possessions(unit, item_cash, 1);
			cash = unit->wages * unit->true_location->wages;
			cash /= 30;
			if (cash) {
#ifdef TRACING_REQUIRED
				if (unit->traced_unit)
					printf("%s earns $%ld\n", unit->name, cash);
#endif
				pay->amount += cash;
				sprintf(work, "Earns $%ld", cash);
				unit_personal_event(unit, 30, work);
			}
		}
/*
 * Special end-of-turn fx
 */
		for (pay = unit->carrying; pay; pay = pay->next)
			if (pay->amount && pay->item->special_effects)
				fx_end_of_turn(unit, pay);
#ifdef USES_FACTION_FUND
		if (unit->withdrawn) {
			sprintf(work, "Withdrawn $%d this turn", unit->withdrawn);
			unit_personal_event(unit, 30, work);
		}
#endif
	}
/*
 * Pay upkeep
 */
#ifdef USES_CASH_UPKEEP
	for (unit = unit_list; unit; unit = unit->next)
		unit->full_day = 0;
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead || !unit->size || !unit->race || unit->full_day)
			continue;
		pay_upkeep(unit);
	}
#endif
}


/**
 ** CLEANUP_LOCATIONS
 **	Locations are adjusted
 **/
static void cleanup_locations(void)
{
location_s	*local;
/*
 * Description is purely local
 */
	for (local = location_list; local; local = local->next)
		local->description = 0;
}


/**
 ** CLEANUP_UNITS
 **	Units are adjusted. Stockpiles vanish over time (the more people,
 ** the faster), unit finish switching sides.
 **/
static void cleanup_units(void)
{
unit_s		*unit;
carry_s		*had;
/*
 * Collect wages
 */
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead)
			continue;
/*
 * Meanwhile, change our loyalty... Any pending order
 * is dropped. Don't care about recycling, we're going to exit
 * in a few seconds...
 */
		if (unit->now_loyal) {
			unit->faction = unit->now_loyal;
			unit->orders = 0;
		}
/*
 * Stockpiles might vanish
 */
		if (unit->size == 0) {
			unit->faction = 0;
			for (had = unit->carrying; had; had = had->next) {
				had->tokens = 0;
				had->equipped = 0;
				if (had->item->item_type)
					had->amount = 0;
				if (had->amount
#ifdef UNIQUE_ARTEFACTS
				    && !had->item->unique
#endif
					) {
/*
 * Units may end up recreated for some odd reasons. If so, it has no location
 */
					if (unit->true_location) {
						if (unit->true_location->population) {
							had->amount *= 5000;
							had->amount /= 6000 + unit->true_location->population;
						}
					} else
						had->amount = 0;
				}
				if (had->amount)
					break;
			}
			if (had)
				continue;
/*
 * Stockpile is now empty and vanishes...
 */
#ifdef TRACING_REQUIRED
			if (unit->traced_unit)
				printf("stockpile %s wiped\n", unit->name);
#endif
			unit->dead = 1;
			move_to_location(unit, 0);
			continue;
		}
	}
}


/**
 ** SET_STACK_MOVEMENT
 **	The entire stack is either moving or not
 **/
void set_stack_movement(unit_s *stack, int flag)
{
carry_s	*partial;
/*
 * Loop
 */
	if (stack) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s movement is now %s\n",stack->name, flag?"on":"off");
#endif
		stack->is_moving = flag;
		stack->full_day  = 1;
		stack->was_guarding = 0;
		stack->is_guarding = 0;
		stack->executing = 0;
		if (flag)
			for (partial = stack->carrying; partial; partial = partial->next)
				partial->tokens = 0;
		for (stack = stack->stack; stack; stack = stack->next_location)
			set_stack_movement(stack, flag);
	}
}


/**
 ** ON_PATROL
 **	Stack process a patrol
 **/
static void on_patrol(unit_s *stack)
{
location_s	*current;
extern int	execute_patrol(unit_s *,order_s *);
/*
 * Gain half landwalk experience, half combat experience
 */
	current = stack->current;
	if (current->type->attached_skill)
		(void)add_landwalk_experience(stack, current->type->attached_skill, SKILL_POINTS_PER_DAY/20);
	(void)add_landwalk_experience(stack, combat_skill, SKILL_POINTS_PER_DAY/20);
/*
 * PATROL ends?
 */
	if (!stack->executing || stack->executing->executing.routine != execute_patrol) {
		if (stack->already_moved <= 1) {
#ifdef TRACING_REQUIRED
			if (stack->traced_unit)
				printf("%s stops patrol\n", stack->name);
#endif
			sprintf(work, "%s [%s] came back from patrol", stack->name, stack->id.text);
			location_global_event(stack, today_number, work);
			unit_personal_event(stack, today_number, work);
			stack->toward = 0;
			stack->already_moved = 0;
			stack->move_for_days = 0;
			stack->moving_by = 0;
			set_stack_movement(stack, 0);
#ifdef STEALTH_STATS
			compute_stack_stealth(stack);
#endif
		} else
			stack->already_moved--;
		return;
	}
/*
 * Recursively set full-day processed
 */
	set_stack_movement(stack, 1);
	if (stack->already_moved >= stack->move_for_days) {
		current->patrolled = 1;
		stack->is_patrolling = 1;
		if (stack->executing->days > 0)
			order_was_executed(stack, stack->executing);
	} else {
		stack->already_moved++;
		if (stack->already_moved >= stack->move_for_days) {
			sprintf(work, "%s [%s] is now patrolling", stack->name, stack->id.text);
			unit_personal_event(stack, today_number, work);
		}
	}
}


/**
 ** EXECUTE_MOVEMENT_ADVANCES
 **	Stack process a movement
 **/
void execute_movement_advances(unit_s *stack)
{
location_s	*current,
		*toward;
extern int	execute_retreat(unit_s *,order_s *);
/*
 * Movement is done using -1: patrol move...
 */
	if (stack->moving_by < 0) {
		on_patrol(stack);
		return;
	}
/*
 * RETREAT is scheduled?
 */
	current = stack->current;
	toward  = stack->toward;
	if (stack->orders && stack->orders->executing.routine == execute_retreat) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s retreats\n", stack->name);
#endif
		order_is_complete(stack, stack->orders);
		unit_personal_event(stack, today_number, "Retreating!");
/*** HACK ***/
		stack->already_moved = stack->move_for_days - stack->already_moved;
	}
/*
 * Switchover?
 */
	if ((stack->move_for_days / 2) == stack->already_moved) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s is now in %s [%s]\n", stack->name, toward->name, toward->id.text);
#endif
		move_to_location(stack, toward);
		stack->toward = current;
		current = toward;
	}
/*
 * Movement finished?
 */
	stack->full_day = 1;
	stack->already_moved++;
	if (current->type->attached_skill) {
		if (add_landwalk_experience(stack, current->type->attached_skill, SKILL_POINTS_PER_DAY/10))
			compute_stack_capacity(stack);
	}
	if (stack->already_moved >= stack->move_for_days) {
#ifdef TRACING_REQUIRED
		if (stack->traced_unit)
			printf("%s arrives\n", stack->name);
#endif
		sprintf(work, "%s [%s] arrived from %s [%s]", stack->name, stack->id.text,
				stack->toward->name, stack->toward->id.text);
		location_global_event(stack, today_number, work);
		unit_personal_event(stack, today_number, work);
		stack->toward = 0;
		stack->already_moved = 0;
		stack->move_for_days = 0;
		stack->moving_by = 0;
		set_stack_movement(stack, 0);
#ifdef STEALTH_STATS
		compute_stack_stealth(stack);
#endif
/*
 * Recursively set full-day processed
 */
	} else
		set_stack_movement(stack, 1);
}


/**
 ** FULL_DAY_ORDER_BY_UNIT
 **	One unit selects a full day order. It has to, we might be called
 ** by execute_teach
 **/
int full_day_order_by_unit(unit_s *unit)
{
order_s		*order, *next;
unit_s		*target;
/*
 * Has ennemies and is ready to pounce! Maybe this unit will attack...
 */
	if (unit->participate == 2 && unit->faction->has_enemies) {
		who_is_present(unit->true_location);
		for (target = unit->true_location->interacting; target; target = target->next_visible) {
			if (!may_interact_with(unit, target) || target->size <= 0)
				continue;
			if (attitude_vs(unit->faction, target) != ATTITUDE_IS_ENNEMY)
				continue;
/*
 * Do an attack!
 */
			sprintf(work, "Spotted %s [%s], an ennemy!", target->name, target->id.text);
			unit_personal_event(unit, today_number, work);
			initiate_attack(unit, target);
			return 1;
		}
		if (unit->full_day || unit->dead)
			return 0;
	}
/*
 * Find an order to process
 */
	for (order = unit->orders; order; order = next) {
		next = order->next;
		if (order->executing.full_day_order &&
		    !order->enabled &&
		    (!order->limited || order->limited == today_number) &&
	    	    (*order->executing.routine)(unit, order)) {
			return 1;
		}
/*
 * We do have something that was unexecuted, and but the next orders have
 * been dropped! Reloop
 */
		if (next && !next->executing.routine)
			next = unit->orders;
	}
/*
 * Fall back to default
 */
	if (!order) {
		(void)execute_work(unit, 0);
		unit->full_day = 1;
	}
	return 1;
}


/**
 ** FULL_DAY_ORDER_BY_STACK
 **	Stack process a full day order
 **/
static int full_day_order_by_stack(unit_s *stack)
{
unit_s		*sibling;
int		all_done;
/*
 * Loop on all of the stack
 */
	all_done = 0;
	while (stack) {
/*
 * Unit looks dead? Retry
 */
		if (stack->dead || !stack->size) {
			stack->executing = 0;
			stack->full_day = 1;
		}
/*
 * Search for a full-day order
 */
		sibling = stack->next_location;
		if (!stack->full_day) {
			if (stack->is_moving) {
				if (stack->toward)
					execute_movement_advances(stack);
				else
					stack->full_day = 1;
				all_done = 1;
			} else {
				all_done |= full_day_order_by_unit(stack);
				if (stack->full_day || stack->dead)
					break;
			}
		}
		if (stack->dead)
			break;
		if (full_day_order_by_stack(stack->stack))
			all_done = 1;
		stack = sibling;
	}
	return all_done;
}


/**
 ** FULL_DAY_PROCESSING
 **	Process one complete day
 **/
static void full_day_processing(void)
{
location_s	*location, *sublocation;
unit_s		*unit;
order_s		*order, *next;
carry_s		*effect;
int		reloop;
/*
 * Prepare units for the day
 */
	printf("Processing day %d\n", today_number);
	for (unit = unit_list; unit; unit = unit->next) {
		if (unit->inactive || unit->dead)
			continue;
/*
 * No orders were executed (so far)
 */
		for (order = unit->orders; order; order = order->next) {
			order->considered = 0;
			order->enabled = order->conditional;
		}
/*
 * Unit is not executing GUARD
 */
		unit->is_guarding = 0;
		unit->full_day = 0;
		unit->marketer = 0;
		unit->has_recruited = 0;
		unit->wants_stay = 0;
	}
/*
 * No market or location effect pending
 */
	for (location = location_list; location; location = location->next) {
		location->harvesting = 0;
		location->guarded = 0;
		location->patrolled = 0;
#ifdef REQUIRE_SPEEDUP
		location->speedup = 0;
#endif
		clean_markets(location);
	}
/*
 * Process immediate orders. No specific unit order is required here...
 */
	reloop = 1;
	while (reloop) {
		reloop = 0;
		for (unit = unit_list; unit; unit = unit->next) {
			if (unit->inactive  || unit->dead || unit->is_moving)
				continue;
			for (order = unit->orders; order; order = next) {
				next = order->next;
				if (!order->executing.full_day_order &&
				    !order->enabled &&
				    (!order->limited || order->limited == today_number) &&
				    !order->considered &&
				    (*order->executing.routine)(unit, order)) {
					reloop = 1;
					break;
				}
/*
 * We do have something that was unexecuted, and but the next orders have
 * been dropped! Reloop
 */
				if (next && !next->executing.routine)
					next = unit->orders;
			}
		}
	}
/*
 * Process day orders.
 */
	if (today_number == 1)
		for (location = location_list; location; location = location->next)
			location_harvest_tokens(location);
	for (location = location_list; location; location = location->next) {
/*
 * Tokens
 */
		tokens_allocated(location);
		if (location->type->type == TERRAIN_STRUCTURE)
			continue;
/*
 * Full-day orders
 */
		while (full_day_order_by_stack(location->present))
			;
		for (sublocation = location->inner; sublocation; sublocation = sublocation->next_inner)
			if (sublocation->type->type == TERRAIN_STRUCTURE)
				while (full_day_order_by_stack(sublocation->present))
					;
/*
 * Recruitment/Market/Harvest?
 */
		if (location->market_days && (today_number % location->market_days) == 0)
			process_markets(location);
		if (location->harvesting) {
			for (sublocation = location->inner; sublocation; sublocation = sublocation->next_inner)
				if (sublocation->type->type == TERRAIN_STRUCTURE)
					harvest_location(sublocation->present);
			harvest_location(location->present);
		}
		process_recruitment(location);
	}
/*
 * Turn is done
 */
	for (unit = unit_list; unit; unit = unit->next) {
#ifdef USES_MANA_POINTS
carry_s		*power;
int		divider;
int		max_mana;
#endif
		if (unit->inactive || unit->dead)
			continue;
		if (unit->has_effects)
			for (effect = unit->carrying; effect; effect = effect->next)
				if (effect->amount && effect->item->item_type == ITEM_DAYS)
					effect->amount--;
#ifdef USES_MANA_POINTS
/*
 * Mana changes?
 */
		if ((max_mana = unit->vital.mana) != 0)
			continue;
		max_mana *= unit->size;
		if ((power = unit->power) == 0)
			power = unit->power = unit_possessions(unit, item_mana, 1);
		if (power->amount < max_mana) {
			if ((today_number & 1) == 0)
				power->amount++;
		} else
			if (power->amount > max_mana) {
				divider = power->amount / max_mana;
				power->amount -= divider / 2;
				if ((divider & 1) != 0 && (today_number & 1) == 0)
					power->amount--;
			}
#endif /*USES_MANA_POINTS*/
	}
	observe_locations(today_number);
}


/**
 ** ITEM_CACHING
 **	All these items are used regularly
 **/
static void item_caching(void)
{
	synthetic_tag("coin");
	item_cash = item_from_tag(1);
#ifdef USES_MANA_POINTS
	synthetic_tag("mana");
	item_mana = item_from_tag(1);
#endif
	synthetic_tag("mage");
	magecraft = skill_from_tag(1);
	synthetic_tag("cmbt");
	combat_skill = skill_from_tag(1);
	synthetic_tag("mele");
	melee_skill = skill_from_tag(1);
	synthetic_tag("parr");
	parry_skill = skill_from_tag(1);
	synthetic_tag("mktg");
	marketing_skill = skill_from_tag(1);
	synthetic_tag("scou");
	scouting_skill = skill_from_tag(1);
	synthetic_tag("airs");
	air_skill = skill_from_tag(1);
	synthetic_tag("eart");
	earth_skill = skill_from_tag(1);
	synthetic_tag("fire");
	fire_skill = skill_from_tag(1);
	synthetic_tag("void");
	void_skill = skill_from_tag(1);
	synthetic_tag("wate");
	water_skill = skill_from_tag(1);
	synthetic_tag("city");
	terrain_city = terrain_from_tag(1);
	synthetic_tag("npc5");
	outlaw_faction = faction_from_id(1);
	synthetic_tag("toktaxe");
	token_tax = item_from_tag(1);
	synthetic_tag("tokente");
	token_entertain = item_from_tag(1);
	synthetic_tag("effdisc");
	discontent_effect = item_from_tag(1);
	synthetic_tag("dead");
	item_dead = item_from_tag(1);
	synthetic_tag("bone");
	item_corpse = item_from_tag(1);
	synthetic_tag("fish");
	item_fish = item_from_tag(1);
	synthetic_tag("effmktg");
	item_mstudy = item_from_tag(1);
}


/**
 ** MAIN
 **	Entry point for the turn processor
 **/
int main(int argc, char **argv)
{
int	day_per_month = 30;
/*
 * How many days? Default to 30
 */
	if (argc > 1)
		day_per_month = atoi(argv[1]);
	if (day_per_month < 0)
		day_per_month = 30;
	srand48(time(0));
/*
 * Turn processor begins in the game directory
 */
	load_game_info();
	printf("Now processing game turn %d\n", game_turn_number);
	save_game_info();
/*
 * We now have locked the game turn. Load all info
 */
	load_items();
	printf("items loaded...\n");
	load_skills();
	printf("skills loaded...\n");
	load_races();
	printf("races loaded...\n");
	load_factions();
	printf("factions loaded...\n");
	load_titles();
	printf("titles loaded...\n");
	load_locations();
	printf("locations loaded...\n");
	load_units();
	printf("units loaded...\n");
	load_orders();
	printf("orders loaded...\n");
/*
 * Global values
 */
	adjust_items();
	adjust_factions();
	adjust_units();
	adjust_locations();
/***HACK***/
/*
 * Process the turn. Yikes!
 */
#ifdef WORLD_HAS_CLIMATE
	season_number = ((game_turn_number) % 12) / 3;
#endif
	item_caching();
	location_values();
	select_climate();
	today_number = 1;
	if (day_per_month > 0)
		full_day_processing();
/***HACK***/
	while (today_number < day_per_month) {
		today_number++;
		full_day_processing();
	}
#ifdef USES_CONTROL_POINTS
	compute_control_points();
#endif
#if !defined(END_OF_WORLD) || (END_OF_WORLD < 3)
#ifdef USES_CASH_UPKEEP
	if (day_per_month > 1)
		compute_upkeep();
#endif
	wages_are_paid();
#endif
#ifdef WORLD_HAS_CLIMATE
	season_number = ((game_turn_number+1) % 12) / 3;
#ifdef USES_CASH_UPKEEP
#ifdef SEASONAL_UPKEEP
	compute_upkeep();
#endif
#endif
#endif
#if defined(END_OF_WORLD) && (END_OF_WORLD == 3)
	dream_time();
#endif
	location_evolves();
	location_values();
/*
 * Turn is done. Now, generate the reports
 */
	create_reports();
	cleanup_locations();
	cleanup_units();
/*
 * Save the databases
 */
	save_game_info();
	save_factions();
	save_units();
	save_locations();
	return 0;
}
