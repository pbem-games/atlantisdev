/* $Id: study_skill.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Plug for skill learning.
 */
#include "turn.h"
#include "fx.h"


#ifdef USES_REQUIRED_LEVELS
/**
 ** MAX_LEVEL_ALLOWED
 **	Reports the maximum level allowed for studies. Takes teacher
 ** into account, if one.
 **/
int max_level_allowed(unit_s *unit, skill_s *skill)
{
experience_s	*exp;
skill_s		*tree;
int		local;
/*
 * Specific codes
 */
	if (unit->size <= 10 && unit->taught && unit->taught->skill == skill)
		return unit->taught->level;
/*
 * Location limits
 */
	local = 0;
	for (exp = unit->current->skills; exp; exp = exp->next)
		if (exp->skill == skill) {
			local = exp->level;
			break;
		}
	switch (unit->race->type) {
/*
 * Special follower code. Any basic skill?
 */
	    case RACE_FOLLOWER:
		for (exp = unit->skilled; exp; exp = exp->next)
			if (exp->skill != skill && exp->points)
				if (!exp->skill->type && !exp->skill->required_skill)
					break;
/*
 * Cannot mix two basic skills (but can still learn known skill)
 */
		if (!skill->required_skill) {
			if (exp && !skill->type)
				return 0;
		}
/*
 * Combat skill. Max 1 if basic skill, else max 2
 */
		if (skill->type)
			if (!exp)
				if (local > 2)
					return local;
				else
					return 2;
/*
 * Other skill? max 1
 */
		if (local)
			return local;
		return 1;
	    case RACE_LEADER:
/*
 * Magic is level 1, combat 3/4, craft is 2
 */
		switch (skill->type) {
		    case 0:/* craft skill */
/* special elemental */
			if (skill->required_skill == magecraft) {
				if (local)
					return local;
				return 1;
			}
			if (local > 2)
				return local;
#ifdef USES_TITLE_SYSTEM
			if (unit->title) {
#ifdef USES_REQUIRED_LEVELS
				for (tree = skill; tree; tree = tree->required_skill)
					if (unit->title->title->required == tree)
#else
					if (unit->title->title->required == skill)
#endif
						return 3;
			}
#endif
			return 2;
		    case 1:/* combat skill */
			if (unit->race->tag.text[0] == 'l') {
				if (local > 3)
					return local;
				else
					return 3;
			}
			if (local > 4)
				return local;
			return 4;
		    case 2:/* magic skill */
			if (local)
				return local;
			return 1;
		}
		break;
	}
/*
 * Default is zero (for creatures)
 */
	return 0;
}
#endif


/**
 ** MAY_STUDY_SKILL
 **	Reports TRUE if a skill may be learned by the unit
 **/
int may_study_skill(unit_s *unit, skill_s *skill)
{
experience_s	*exp;
#ifdef USES_REQUIRED_LEVELS
skill_s		*required;
int		numbers;
#endif
#ifdef SKILL_REQUIRES_BOOK
carry_s		*holds;
#endif
/*
 * Creatures may never study skills
 */
	if (!unit->race || unit->race->type >= RACE_CREATURE)
		return 0;
/*
 * Skill is leader-only
 */
	if (skill->student && unit->race->type != skill->student)
		return 0;
/*
 * Study
 */
#ifdef USES_REQUIRED_LEVELS
	if ((required = skill->required_skill) != 0) {
		for (exp = unit->skilled; exp; exp = exp->next)
			if (exp->skill == required)
#ifdef USES_SKILL_LEVELS
			    	if (exp->level >= skill->required_at_level)
#endif
					break;
		if (!exp)
			return 0;
/*
 * Special magecraft rules. Only one "non-magical" skill per magecraft level.
 */
		if (required == magecraft && skill->type != 2) {
			numbers = exp->level;
			for (exp = unit->skilled; exp; exp = exp->next)
				if (exp->skill->required_skill == magecraft &&
				    exp->points != 0 &&
				    exp->skill->type != 2 &&
				    exp->skill != skill)
					numbers--;
			if (numbers <= 0)
				return 0;
		}
	}
#endif
/*
 * Specialist skills?
 */
#ifdef SPECIALIST_SKILLS
	if (skill->specialist) {
		for (exp = unit->current->skills; exp; exp = exp->next)
			if (exp->skill == skill && exp->effective)
				break;
/*
 * Not taught by location, maybe a teacher then?
 */
		if (!exp)
			if (!unit->taught || unit->taught->skill != skill)
				return 0;
	}
#endif
/*
 * Item-enabled skills?
 */
#ifdef SKILL_REQUIRES_BOOK
	if (skill->required_item) {
		if ((holds = unit_possessions(unit, skill->required_item, 0)) == 0 ||
		     holds->amount < unit->size)
			return 0;
	}
#endif
/*
 * Default is: may study
 */
	return 1;
}


/**
 ** ADD_TO_EXPERIENCE
 **	Unit gains experience!
 **/
int add_to_experience(unit_s *unit, experience_s *exp, skill_s *skill, long points)
{
skill_s	*achieved;
/*
 * How many points gained?
 */
/*** HACK ***/
	if (!points)
		return 0;
	if (!unit->size)
		return 0;
	exp->points += points;
	exp->studied += points;
	points = exp->points;
	points /= unit->size;
#ifdef USES_SKILL_LEVELS
	if (exp->effective)
		achieved = exp->effective->next_level;
	else
#endif
		achieved = skill;
/*
 * Level changes
 */
	if (achieved && achieved->for_level <= points) {
#ifdef USES_SKILL_LEVELS
		exp->level++;
		sprintf(work, "%s reached level %d in %s [%s]", unit->name, exp->level,
#else
		sprintf(work, "%s learns %s [%s]", unit->name,
#endif
				skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
		exp->effective = achieved;
		return 1;
	}
/*
 * Done
 */
	return 0;
}


/**
 ** UNIT_STUDIES_AGAIN
 **	Requires cash. It is assumed that check has been made.
 **/
void unit_study_again(unit_s *unit, experience_s *exp, skill_s *skill, int cap, int reduced)
{
experience_s	*bonus;
skill_s		*tree;
unit_s		*leader;
carry_s		*owns;
long		points;
int		recompute;
/*
 * Points are gained
 */
	points = unit->size;
	if (points > cap)
		points = cap;
	points *= SKILL_POINTS_PER_DAY;
/*
 * Locational bonus?
 */
	for (bonus = unit->current->skills; bonus; bonus = bonus->next) {
		if (bonus->skill == skill) {
#ifdef USES_SKILL_LEVELS
			if (bonus->level > exp->level)
#endif
			points += points / 5;
			break;
		}
	}
/*
 * Leadership bonus
 */
	for (leader = unit->leader; leader; leader = leader->leader) {
		for (bonus = leader->skilled; bonus; bonus = bonus->next)
			if (bonus->skill == skill) {
#ifdef USES_SKILL_LEVELS
				if (bonus->level > exp->level)
#endif
				break;
			}
		if (bonus) {
			points += points / 10;
			break;
		}
	}
/*
 * These depend on skill trees
 */
#ifdef USES_REQUIRED_LEVELS
	for (tree = skill; tree; tree = tree->required_skill) {
/*
 * Seasonal bonus for magic
 */
#ifdef WORLD_HAS_CLIMATE
		if (skill->type == 2 || skill->required_skill == magecraft) {
			if (tree == earth_skill && season_number == 0)
				points += points / 10;
			else if (tree == fire_skill && season_number == 1)
				points += points / 10;
			else if (tree == water_skill && season_number == 2)
				points += points / 10;
			else if (tree == air_skill && season_number == 3)
				points += points / 10;
			else if (tree == void_skill && unit->true_location->last_climate == 5)
				points += points / 10;
		}
#endif
#ifdef USES_TITLE_SYSTEM
/*
 * Title bonus
 */
		if (unit->title)
			if (unit->title->title->required == tree)
				points += points / 10;
#endif
#ifdef RACE_FAVOR_SKILLS
/*
 * Racial advantages
 */
		for (bonus = unit->race->favors; bonus; bonus = bonus->next)
			if (tree == bonus->skill)
				break;
		if (bonus) {
			points *= bonus->points;
			points += 50;
			points /= 100;
		}
#endif
/*
 * Widsdom is imparted by an object
 */
#ifdef SKILL_BENEFITS_FROM_BOOK
		if (tree->wisdom) {
			owns = unit_possessions(unit, tree->wisdom, 0);
			if (owns && owns->equipped) {
				if (skill->type == 2 || skill->required_skill == magecraft)
					points += owns->equipped;
				else
					points += 4 * owns->equipped;
			}
		}
#endif
	}
#endif
/*
 * Reduction in points?
 */
	if (reduced) {
		points *= reduced;
		points += 50;
		points /= 100;
	}
/*
 * Now add to points
 */
	if (unit->is_guarding)
		points /= 2;
	if (add_to_experience(unit, exp, skill, points))
		recompute = 1;
	else
		recompute = 0;
#ifdef USES_REQUIRED_LEVELS
	points /= 10;
	while ((skill = skill->required_skill) != 0) {
		exp = unit_experiences(unit, skill, 1);
		if (add_to_experience(unit, exp, skill, points))
			recompute = 1;
	}
#endif
/*
 * At least one level was achieved
 */
	if (recompute) {
		compute_unit_stats(unit);
#ifdef STEALTH_STATS
		compute_overall_stealth(unit);
#endif
	}
/*
 * Done
 */
}


/**
 ** UNIT_STUDIES_SKILL
 **	Requires cash. It is assumed that check has been made.
 **/
int unit_studies_skill(unit_s *unit, experience_s *exp, skill_s *skill)
{
long	cash;
/*
 * Cash requirements
 */
	cash = unit->size * skill->study_cost;
	if (payment_required(unit, cash))
		return 1;
	if (unit->executing == 0) {
		sprintf(work, "%s studies %s [%s]", unit->name, skill->name, skill->tag.text);
		unit_personal_event(unit, today_number, work);
	}
	unit_study_again(unit, exp, skill, unit->size, 0);
	return 0;
}


/**
 ** ADD_LANDWALK_EXPERIENCE
 **	Adds to experience to current land, if already known!
 **/
int add_landwalk_experience(unit_s *stack, skill_s *land, int points)
{
experience_s	*exp;
int		recompute;
/*
 * Does the unit has some experience in landwalk?
 */
	recompute = 0;
	if ((exp = unit_experiences(stack, land, 0)) != 0 && exp->points != 0) {
		if (add_to_experience(stack, exp, land, points)) {
			compute_unit_stats(stack);
			recompute = 1;
		}
	}
	for (stack = stack->stack; stack; stack = stack->next_location)
		if (add_landwalk_experience(stack, land, points))
			recompute = 1;
	return recompute;
}


#ifdef FX_MIND_READING
/**
 ** Pick a skill you could study under the target's tutelage, and get 150%
 ** study speed of it.
 **/
void fx_mind_reading(unit_s *mindreader, int speed)
{
experience_s	*mind, *choice;
experience_s	*elect;
unit_s		*target;
int		type, chances;
/*
 * Study now
 */
	target = mindreader->target.unit;
	choice = 0;
	chances = 0;
	type = -1;
	for (mind = target->skilled; mind; mind = mind->next) {
/*
 * Must have at least full skill to pick it
 */
		if (!mind->effective)
			continue;
		mindreader->taught = mind;
		if (!may_study_skill(mindreader, mind->skill))
			continue;
		elect = unit_experiences(mindreader, mind->skill, 0);
		if (elect) {
#ifdef USES_SKILL_LEVELS
			if (elect->level >= mind->level)
#else
			if (elect->effective)
#endif
				continue;
		}
/*
 * Potentially correct!
 */
		if (mind->skill->type < type)
			continue;
		if (mind->skill->type > type) {
			choice = 0;
			chances = 0;
			type = mind->skill->type;
		}
/*
 * Roll at random. We have a decreasing chance of picking the skill
 */
		chances++;
		if (choice && roll_1Dx(chances) != 1)
			continue;
		choice = mind;
	}
/*
 * No choice! Mind reading wasted!
 */
	if (!choice) {
		unit_personal_event(mindreader, today_number, "No useful knowledge obtained!");
		return;
	}
	sprintf(work, "Picks some knowledge of %s", choice->skill->name);
	unit_personal_event(mindreader, today_number, work);
	speed *= SKILL_POINTS_PER_DAY;
	speed /= 100;
	choice = unit_experiences(mindreader, choice->skill, 1);
	if (add_to_experience(mindreader, choice, choice->skill, speed)) {
		compute_unit_stats(mindreader);
#ifdef STEALTH_STATS
		compute_overall_stealth(mindreader);
#endif
	}
}
#endif /* FX_MIND_READING */
