/* $Id: battle.c,v 1.1.1.1 2000/02/04 19:39:44 jtraub Exp $
 *	Battle module
 */
#include "turn.h"
#include "battle.h"
#include "formatter.h"
#include "command_e.h"


/**
 ** Internal variables
 **/
FILE		*full_report, *long_report, *terse_report;
location_s	*battle_location;
extern item_s	*tired_cache,
		*wariness_cache;
static char	*sep;
static int	battle_number;
static char	path_full[256];
static char	path_long[256];
static char	path_short[256];


/**
 ** RANDOM_UNIT_SWAPS
 **	The real meat of the next function
 **/
static figure_s *random_unit_swaps(figure_s *unit)
{
figure_s	*two;
/*
 * End of recursions
 */
	if (!unit)
		return 0;
	if (!unit->same_side)
		return unit;
/*
 * Do we swap?
 */
	two = random_unit_swaps(unit->same_side);
	if (roll_1Dx(2) & 1) {
		unit->same_side = two;
		return unit;
	}
	unit->same_side = two->same_side;
	two->same_side  = unit;
	return two;
}


/**
 ** BATTLE_RANDOM_SHUFFLE
 **	Shuffle all units on a side, to help distributing hits and spoils.
 ** We aren't very sophisticated: all units have 50% chance of swapping
 ** positions.
 **/
void random_shuffle(side_s *side)
{
/*
 * Use a recursion. i'm lazy, so sue me.
 */
	side->units = random_unit_swaps(side->units);
}


/**
 ** START_FOLD_UNIT_SEGMENT
 **	Start a unit segment report
 **/
void start_fold_unit_segment(figure_s *unit)
{
	empty_fold_string();
#ifdef BATTLE_INITIATIVE
	add_fold_integer(initiative_level);
	add_fold_char(':');
	add_fold_char(' ');
#endif
	add_fold_string(unit->unit->name);
	if (unit->simplename)
		add_fold_tag(&unit->unit->id);
	add_fold_char(' ');
}


/**
 ** WITNESSES
 **	Who saw the battle?
 **/
static void witnesses(faction_s *faction, char *lpath)
{
event_s		*reported, *last;
/*
 * Loop on all present
 */
	if (!faction)
		return;
	last = 0;
	for (reported = faction->globals; reported; reported = reported->next)
		if (strcmp(reported->text, path_long) == 0 ||
		    strcmp(reported->text, path_full) == 0 ||
		    strcmp(reported->text, path_short) == 0)
			break;
		else
			last = reported;
	if (!reported) {
		reported = new_dated_event();
		reported->day = -1;
		if (faction->setting_terse)
			lpath = path_short;
		reported->text = strdup(lpath);
		if (last)
			last->next = reported;
		else
			faction->globals = reported;
	}
}


/**
 ** FINALISE_UNIT
 **	Check what happened to this unit
 **/
static void finalise_unit(side_s *sides, figure_s *unit, int figure_cap)
{
#ifdef REPORTS_RACIAL_KNOWLEDGE
figure_s	*encounter;
#endif
#ifdef USES_TITLE_SYSTEM
figure_s	*claim;
title_s		*title;
unit_s		*leader;
#endif
unit_s		*original;
carry_s		*spoils, *treasure;
item_s		*equipment;
experience_s	*exp;
long		points;
int		category, max;
int		equipped[MAX_EQUIP_CATEGORIES];
/*
 * Is that unit wounded? If so, any healing?
 */
/*** HACK ***/
/*
 * Free the equipment lists, we don't need them anymore (and might reuse
 * for spoils right now)
 */
	free_carry_instance(unit->using);
	unit->using = 0;
/*
 * Fanatic unit at a losing side?
 */
	if (sides->lost && unit->fanatic) {
		sides->casualties += unit->living;
		unit->living = 0;
	}
/*
 * Is that unit dead?
 */
	original = unit->unit;
	if (unit->living <= 0) {
		unit_is_now_dead(original, 0);
		unit_personal_event(original, today_number, "Slain in battle");
/*
 * Add half its possessions to spoils list
 */
		for (spoils = original->carrying; spoils; spoils = spoils->next) {
			if (spoils->amount &&
			    spoils->item->item_type == ITEM_ITEM &&
			    spoils->item->item_category < 2) {
				for (treasure = sides->spoils; treasure; treasure = treasure->next)
					if (treasure->item == spoils->item)
						break;
				if (!treasure) {
					treasure = new_carry_instance();
					treasure->item = spoils->item;
					treasure->next = sides->spoils;
					sides->spoils = treasure;
				}
/*
 * Unique items are never shared
 */
				if (spoils->item->unique)
					treasure->amount += spoils->amount;
				else {
					treasure->amount += spoils->amount / 2;
					if ((spoils->amount & 1) != 0 && roll_1Dx(2) == 0)
						treasure->amount++;
				}
			}
		}
#ifdef USES_TITLE_SYSTEM
/*
 * Title is lost
 */
		if (original->title) {
			original->title->holder = 0;
			title = original->title->title;
/*
 * Survivors may catch the titles
 */
			if (attackers.lost)
				if (defenders.lost)
					claim = sides->units;
				else
					claim = defenders.units;
			else
				claim = attackers.units;
			for (; claim; claim = claim->same_side) {
				if (claim->living != 1)
					continue;
				leader = claim->unit;
				if (leader->race->type != RACE_LEADER)
					continue;
				if (leader->title)
					continue;
#if !defined(END_OF_WORLD) || END_OF_WORLD < 4
				if (roll_1Dx(2) == 0 && title->level < 4)
					continue;
#endif
				exp = unit_experiences(leader, title->required, 0);
				if (!exp || !exp->effective)
					continue;
#ifdef USES_SKILL_LEVELS
				if (exp->level < title->level)
					continue;
#endif
				leader->title = original->title;
				original->title->holder = leader;
				sprintf(work, "%s [%s] recovered the title of %s of %s [%s] in battle!",
						leader->name, leader->id.text, title->name,
						original->title->name, original->title->id.text);
				printf("%s\n", work);
				fprintf(full_report, "%s\n", work);
				fprintf(long_report, "%s\n", work);
				fprintf(terse_report, "%s\n", work);
				unit_personal_event(leader, today_number, work);
				location_visible_event(leader->title, today_number, work);
				break;
			}
/*
 * The title might be lost, and must be claimed again
 */
			original->title = 0;
		}
#endif
		free_carry_instance(original->carrying);
		original->carrying = 0;
		return;
	}
/*
 * Virtual units now disappear
 */
	if (original->virtual) {
		unit_is_now_dead(original, 0);
		return;
	}
#ifdef REPORTS_RACIAL_KNOWLEDGE
/*
 * Report all kind of critters we encountered or got ourselves ally of
 */
	for (encounter = attackers.units; encounter; encounter = encounter->same_side)
		faction_knows_race(original->faction, encounter->race);
	for (encounter = defenders.units; encounter; encounter = encounter->same_side)
		faction_knows_race(original->faction, encounter->race);
#endif
/*
 * If we want long reports, then we get a report with the kind of ennemies we got
 */
	witnesses(original->faction, path_full);
/*
 * Unit survived. Losses cause proportional experience loss...
 */
	if (unit->deceased) {
		for (exp = original->skilled; exp; exp = exp->next)
			exp->points = fractional(exp->points, unit->living, original->size);
		original->size = unit->living;
		sprintf(work, "%d died in battle", unit->deceased);
		unit_personal_event(original, today_number, work);
		memset(equipped, 0, sizeof(equipped));
/*
 * Drop any extra equipment...
 */
		for (spoils = original->carrying; spoils; spoils = spoils->next) {
			if (spoils->equipped > original->size)
				spoils->equipped = original->size;
			if (spoils->equipped) {
				equipment = spoils->item;
				category = equipment->equip_category;
				max = original->size * equipment->equip_maximum;
				if (spoils->equipped + equipped[category] > max) {
					spoils->equipped = max - equipped[category];
					if (spoils->equipped <= 0)
						spoils->equipped = 0;
				}
				equipped[category] += spoils->equipped;
			}
		}
	}
/*
 * Add combat experience, which makes great veterans
 */
	exp = unit_experiences(original, combat_skill, 1);
	if (unit->combat_exp > 20)
		unit->combat_exp = 20;
	points = (SKILL_POINTS_PER_DAY / 2) * unit->combat_exp;
	if (exp->effective == 0)
		points *= 2;
	if (points > figure_cap)
		points = figure_cap;
	add_to_experience(original, exp, combat_skill, points * original->size);
/*
 * Melee is not capped: you have to strike to use it
 */
	if (unit->melee_exp && exp->effective) {
		exp = unit_experiences(original, melee_skill, 1);
		if (unit->melee_exp > 20)
			unit->melee_exp = 20;
		points = (SKILL_POINTS_PER_DAY / 2) * original->size * unit->melee_exp;
		add_to_experience(original, exp, melee_skill, points);
	}
/*
 * Parry is capped
 */
	if (unit->parry_exp && (exp = unit_experiences(original, parry_skill, 0)) != 0 && exp->points) {
		if (unit->parry_exp > 20)
			unit->parry_exp = 20;
		points = (SKILL_POINTS_PER_DAY / 2) * unit->parry_exp;
		if (points > figure_cap)
			points = figure_cap;
		add_to_experience(original, exp, parry_skill, points * original->size);
	}
/*
 * Redo the unit value
 */
	compute_unit_stats(original);
#ifdef STEALTH_STATS
	compute_overall_stealth(original);
#endif
	compute_overall_capacity(original);
}


/**
 ** DISTRIBUTE_SPOILS_TO
 **	Any remaining spoils are handed to a unit that may make use of it
 **/
static void distribute_spoils_to(side_s *winner, carry_s *spoils)
{
figure_s	*force;
carry_s		*earned;
unit_s		*unit;
item_s		*item;
int		pass;
int		w, max;
char		loot[256];
/*
 * Go!
 */
	for (; spoils; spoils = spoils->next)
		if (spoils->amount) {
			random_shuffle(winner);
			add_fold_string(sep);
			item = spoils->item;
			add_fold_item_amount(spoils->amount, item);
			sep = comma;
/*
 * Distribute the spoils
 */
			pass = 0;
			force = winner->units;
			while (spoils->amount) {
				if (!force) {
					force = winner->units;
					if (pass)
						return;
					pass = 1;
				}
				if (force->living <= 0) {
					force = force->same_side;
					continue;
				}
				unit = force->unit;
/*
 * For the first pass, distribute only to units that can carry the loot!
 */
				max = spoils->amount;
				if (!pass) {
					w = item->capacity[0] - item->weight;
					if (w > 0)
						max = (unit->capacity[0] - unit->weight) / w;
					if (max < 0)
						max = 0;
					if (max > spoils->amount)
						max = spoils->amount;
				}
/*
 * Some spoils are possible
 */
				if (max) {
					earned = unit_possessions(unit, item, 1);
					earned->amount += max;
					compute_overall_capacity(unit);
					spoils->amount -= max;
					sprintf(loot, "Recovered %d %s loot", max, max > 1 ? item->plural : item->name);
					unit_personal_event(unit, today_number, loot);
				} else
					force = force->same_side;
			}
		}
}


/**
 ** AFTERMATH
 **	The battle is over.
 **/
static void aftermath(void)
{
figure_s	*unit;
resource_s	*deads;
carry_s		*tired;
int		bodies;
int		attack_cmbt, defense_cmbt;
/*
 * Survivors gain experience: 15 days/slain enemy, 1 per surviving enemy
 */
	if (attackers.lost && defenders.lost)
		attackers.lost = defenders.lost = 0;
	attack_cmbt = defenders.size + defenders.casualties * 14;
	attack_cmbt *= SKILL_POINTS_PER_DAY;
	attack_cmbt += (attackers.size - attackers.casualties) / 2;
	if (attackers.size > attackers.casualties)
		attack_cmbt /= (attackers.size - attackers.casualties);
	defense_cmbt = attackers.size + attackers.casualties * 14;
	defense_cmbt *= SKILL_POINTS_PER_DAY;
	defense_cmbt += (defenders.size - defenders.casualties) / 2;
	if (defenders.size > defenders.casualties)
		defense_cmbt /= (defenders.size - defenders.casualties);
/*
 * Mark all units dead. Add experience to any survivors and fatigue to
 * attackers
 */
	for (unit = attackers.units; unit; unit = unit->same_side) {
		finalise_unit(&attackers, unit, attack_cmbt);
		tired = unit_possessions(unit->unit, tired_cache, 1);
		tired->amount += 1 + roll_1Dx(2);
		unit->unit->has_effects = 1;
	}
	for (unit = defenders.units; unit; unit = unit->same_side) {
		finalise_unit(&defenders, unit, defense_cmbt);
		tired = unit_possessions(unit->unit, wariness_cache, 1);
		tired->amount = 1;
		unit->unit->has_effects = 1;
	}
/*
 * Report spoils!
 */
	start_fold_string("Loot: ");
	sep = "";
	if (attackers.lost)
		distribute_spoils_to(&defenders, attackers.spoils);
	else
		distribute_spoils_to(&attackers, attackers.spoils);
	free_carry_instance(attackers.spoils);
	if (defenders.lost)
		distribute_spoils_to(&attackers, defenders.spoils);
	else
		distribute_spoils_to(&defenders, defenders.spoils);
	free_carry_instance(defenders.spoils);
	if (!*sep)
		add_fold_string("none.");
	else
		add_fold_char('.');
	print_folded(full_report, 6);
	print_folded(long_report, 6);
	print_folded(terse_report, 6);
/*
 * Finally, free units for next battle. All factions involved witnessed the
 * battle, survivors already have a full witness report.
 */
	free_all_soldiers();
/*
 * Litter the corpses around...
 */
	deads = location_has_resource(battle_location, item_dead, 1);
	bodies = attackers.casualties + defenders.casualties;
	deads->amount += bodies;
	deads->remains += bodies * item_dead->token_multiplier;
}


/**
 ** INITIATE_ATTACK
 **	A unit is always attacked by another one
 **/
void initiate_attack(unit_s *attacker, unit_s *target)
{
unit_s	*unit;
/*
 * Quick 'n dirty
 */
	battle_location = attacker->true_location;
	printf("Battle at %s [%s]\n", battle_location->name, battle_location->id.text);
/*
 * Prepare the battle reports
 */
	battle_number++;
	sprintf(path_full , "battles/full.%d", battle_number);
	sprintf(path_long , "battles/report.%d", battle_number);
	sprintf(path_short , "battles/terse.%d", battle_number);
	if ((full_report = fopen(path_full, "w")) == 0) {
		perror(path_full);
		exit(1);
	}
	if ((long_report = fopen(path_long, "w")) == 0) {
		perror(path_long);
		exit(1);
	}
	if ((terse_report = fopen(path_short, "w")) == 0) {
		perror(path_short);
		exit(1);
	}
/*
 * Battle occurs
 */
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	start_fold_string("Battle at ");
	add_fold_string(battle_location->name);
	add_fold_tag(&battle_location->id);
	add_fold_string(" on day ");
	add_fold_integer(today_number);
	add_fold_string(" of the month.");
	print_folded(full_report, 0);
	print_folded(long_report, 0);
	print_folded(terse_report, 0);
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
/*
 * Who will gets a report or become involved?
 */
	who_is_present(battle_location);
	battle_engagement(attacker, target, 0);
	run_battle();
	aftermath();
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	fclose(full_report);
	fclose(long_report);
	fclose(terse_report);
/*
 * Finally, add witnesses to the battle
 */
	for (unit = battle_location->interacting; unit; unit = unit->next_visible)
		witnesses(unit->faction, path_long);
#ifdef DYNAMIC_ECONOMY
	battle_location->economy -= 100;
#endif
}


#ifdef FX_ASSASSINATION
/**
 ** BATTLE_ASSASSINATION
 **	This is similar to a battle, but involves chiefly two units.
 **/
void battle_assassination(unit_s *killer, unit_s *target, int tactics)
{
unit_s	*unit;
/*
 * Quick 'n dirty
 */
	battle_location = killer->true_location;
	printf("Assationation at %s [%s]\n", battle_location->name, battle_location->id.text);
/*
 * Prepare the battle reports
 */
	battle_number++;
	sprintf(path_full , "battles/full.%d", battle_number);
	sprintf(path_long , "battles/report.%d", battle_number);
	sprintf(path_short , "battles/terse.%d", battle_number);
	if ((full_report = fopen(path_full, "w")) == 0) {
		perror(path_full);
		exit(1);
	}
	if ((long_report = fopen(path_long, "w")) == 0) {
		perror(path_long);
		exit(1);
	}
	if ((terse_report = fopen(path_short, "w")) == 0) {
		perror(path_short);
		exit(1);
	}
/*
 * Battle occurs
 */
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	start_fold_string("Assasination at ");
	add_fold_string(battle_location->name);
	add_fold_tag(&battle_location->id);
	add_fold_string(" on day ");
	add_fold_integer(today_number);
	add_fold_string(" of the month.");
	print_folded(full_report, 0);
	print_folded(long_report, 0);
	print_folded(terse_report, 0);
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
/*
 * Who will gets a report or become involved?
 */
	who_is_present(battle_location);
	battle_engagement(killer, target, 1);
	run_battle();
	aftermath();
	putc('\n', full_report);
	putc('\n', long_report);
	putc('\n', terse_report);
	fclose(full_report);
	fclose(long_report);
	fclose(terse_report);
#ifdef DYNAMIC_ECONOMY
	battle_location->economy -= 10;
#endif
}
#endif
