#if !defined(AFX_BATTLEREPORT_H__4C7B543C_990D_11D4_9E23_0008C7C6E4AD__INCLUDED_)
#define AFX_BATTLEREPORT_H__4C7B543C_990D_11D4_9E23_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BattleReport.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBattleReport form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CBattleReport : public CFormView
{
protected:
	CBattleReport();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CBattleReport)

// Form Data
public:
	//{{AFX_DATA(CBattleReport)
	enum { IDD = IDD_BATTLE_VIEW };
	CButton	m_btnClose;
	CButton	m_btnUpdate;
	CListBox	m_lstBattle;
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBattleReport)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CBattleReport();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CBattleReport)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnBattleCloseresults();
	afx_msg void OnBattleUpdatearmies();
	afx_msg void OnUpdateBattleUpdatearmies(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BATTLEREPORT_H__4C7B543C_990D_11D4_9E23_0008C7C6E4AD__INCLUDED_)
