// MainFrame.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "MainFrame.h"
#include "SplitterWndEx.h"
#include "MainDoc.h"
#include "helper.h"
#include "AboutDlg.h"
#include "MainForm.h"
#include "BattleReport.h"
#include "TurnTreeView.h"
#include "UnitListView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};
*/
#define SAFE_HOOK_WINDOW(pwin) \
if (pwin != NULL) \
{	if (pwin->GetParent() != this) \
	{	pwin->SetParent(this); \
	} \
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

CMainFrame::CMainFrame()
{	m_bUpdating = false;
	m_pMainForm = NULL;
	m_pBattleReport = NULL;
	m_pwndSplitter = NULL;
	m_iCurrentView = viewNone;
}

CMainFrame::~CMainFrame()
{
}

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_CLOSE()
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_WM_WINDOWPOSCHANGING()
	ON_MESSAGE(WM_APP, OnChangeView)
	ON_UPDATE_COMMAND_UI(ID_BATTLE_UPDATEARMIES, OnUpdateBattleUpdatearmies)
	ON_COMMAND(ID_BATTLE_UPDATEARMIES, OnBattleUpdatearmies)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
/*	typedef struct tagCREATESTRUCT {
	   LPVOID    lpCreateParams; // (CCreateContext *)
	   HANDLE    hInstance;
	   HMENU     hMenu;
	   HWND      hwndParent;
	   int       cy; // height
	   int       cx; // width
	   int       y;  // top
	   int       x;  // left
	   LONG      style;
	   LPCSTR    lpszName;
	   LPCSTR    lpszClass;
	   DWORD     dwExStyle;
	} CREATESTRUCT;
*/
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	/*if (!m_wndStatusBar.Create(this))/* ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))*/
	/*{
		TRACE0("Failed to create status bar\n");
		return -1;
	}
	*/
	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{	if (pContext == NULL) return FALSE;
	if (pContext->m_pNewViewClass == NULL) return FALSE;
	StartUpdate();
	BOOL bRes = CreateNewView(pContext);
	EndUpdate();
	return bRes;
}

/*void CMainFrame::LoadView()
{	if (m_wndSplitter.CreateStatic(this, 1, 2) == FALSE) return FALSE;
	StartUpdate();

	BOOL bRes = FALSE;
	if (m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CTurnTreeView), csPane1, &m_Context)
		!= FALSE)
	{	m_Context.m_pNewViewClass = RUNTIME_CLASS(CUnitListView);
		if (m_wndSplitter.CreateView(0, 1, m_Context.m_pNewViewClass, csPane2, &m_Context)
			!= FALSE)
		{	m_wndSplitter.SetActivePane(0, 1);
			m_wndSplitter.RecalcLayout();
			CMainDoc *pDoc = GetDocument();
			if (pDoc != NULL)
			{	pDoc->UpdateAllViews(NULL, 0, NULL);
				bRes = TRUE;
			}
		}
	}
	EndUpdate();
}*/

void CMainFrame::StartUpdate()
{	m_bUpdating = true;
	if (m_pwndSplitter != NULL) m_pwndSplitter->StartUpdate();
	if (m_pMainForm != NULL) m_pMainForm->StartUpdate();
	//if (m_pBattleReport != NULL) m_pBattleReport->StartUpdate();
}

void CMainFrame::EndUpdate()
{	m_bUpdating = false;
	if (m_pwndSplitter != NULL)	m_pwndSplitter->EndUpdate();
	if (m_pMainForm != NULL) m_pMainForm->EndUpdate();
	//if (m_pBattleReport != NULL) m_pBattleReport->EndUpdate();
	Invalidate();
}

BOOL CMainFrame::RedrawWindow( LPCRECT lpRectUpdate, CRgn* prgnUpdate, UINT flags)
{
	if (m_bUpdating) return FALSE;
	flags |= RDW_ALLCHILDREN;
	return CWnd::RedrawWindow(lpRectUpdate, prgnUpdate, flags);
}

void CMainFrame::UpdateWindow()
{
	if (m_bUpdating) return;
	CWnd::UpdateWindow();
}

/*void CMainFrame::SetStatusText(CString strText)
{	//m_wndStatusBar.GetWindowText(m_strOldStatus);
	m_wndStatusBar.SetWindowText(strText);
	m_wndStatusBar.RedrawWindow();
}
*/
void CMainFrame::OnDestroy()
{
	m_bUpdating = false;
	SAFE_HOOK_WINDOW(m_pMainForm);
	SAFE_HOOK_WINDOW(m_pBattleReport);
	SAFE_HOOK_WINDOW(m_pwndSplitter);
	CFrameWnd::OnDestroy();
}

void CMainFrame::OnClose()
{
	CFrameWnd::OnClose();
}

void CMainFrame::OnAppAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style&=~FWS_ADDTOTITLE;
	return CFrameWnd::PreCreateWindow(cs);
}

CRuntimeClass *CMainFrame::GetViewClass(int iView)
{	switch (iView)
	{	case viewMainForm: return RUNTIME_CLASS(CMainForm);
		case viewReport: return RUNTIME_CLASS(CBattleReport);
		case viewSplitter: return RUNTIME_CLASS(CTurnTreeView);
	}
	return NULL;
}

int CMainFrame::GetViewType(CRuntimeClass *pClass)
{	CView *pView = GetActiveView();
	if (pClass == RUNTIME_CLASS(CMainForm)) return viewMainForm;
	else if (pClass == RUNTIME_CLASS(CBattleReport)) return viewReport;
	else if (pClass == RUNTIME_CLASS(CTurnTreeView)) return viewSplitter;
	else if (pClass == RUNTIME_CLASS(CUnitListView)) return viewSplitter;
	else return viewNone;
}

int CMainFrame::GetViewType()
{	CView *pView = GetActiveView();
	if (pView->IsKindOf(RUNTIME_CLASS(CMainForm))) return viewMainForm;
	else if (pView->IsKindOf(RUNTIME_CLASS(CBattleReport))) return viewReport;
	else if (pView->IsKindOf(RUNTIME_CLASS(CTurnTreeView))) return viewSplitter;
	else if (pView->IsKindOf(RUNTIME_CLASS(CUnitListView))) return viewSplitter;
	else return viewNone;
}

void CMainFrame::SetCreateContext(CCreateContext *pContext, int iView)
{	if (pContext == NULL) return;
	pContext->m_pNewViewClass = GetViewClass(iView);
	pContext->m_pCurrentDoc = GetActiveDocument();
	if (pContext->m_pCurrentDoc != NULL)
		pContext->m_pNewDocTemplate = pContext->m_pCurrentDoc->GetDocTemplate();
	else pContext->m_pNewDocTemplate = NULL; 
	pContext->m_pLastView = NULL;
	pContext->m_pCurrentFrame = this;
}

LRESULT CMainFrame::OnChangeView(WPARAM wParam, LPARAM lParam)
{	int iView = (int)lParam;
	int iData = (int)wParam;
	ChangeView(iView, iData);
	return lParam;
}

void CMainFrame::ChangeView(int iView, int iData)
{	if ((iView <= viewNone) || (iView >= viewMax)) return;
	int iOldView = GetViewType();
	if (iOldView == iView) return;
	CCreateContext oContext;
	SetCreateContext(&oContext, iView);
	if (oContext.m_pNewViewClass == NULL) return;
	CMainDoc *pDoc = (CMainDoc *)GetActiveDocument();
	if (pDoc == NULL) return;
	StartUpdate();
	m_iCurrentView = iView;
	switch (iView)
	{	case viewMainForm:
			if (m_pMainForm == NULL) CreateMainFormView(&oContext);
			else pDoc->AddView(m_pMainForm);
			ModifyStyle(WS_THICKFRAME, WS_EX_DLGMODALFRAME);
			m_pMainForm->SetParent(this);
			m_pMainForm->ShowWindow(SW_SHOWMAXIMIZED);
			SetActiveView(m_pMainForm);
			m_pMainForm->SetFocus();
			break;
		case viewReport:
			if (m_pBattleReport == NULL) CreateBattleReport(&oContext);
			else pDoc->AddView(m_pBattleReport);
			ModifyStyle(WS_EX_DLGMODALFRAME, WS_THICKFRAME);
			m_pBattleReport->SetParent(this);
			m_pBattleReport->ShowWindow(SW_SHOWMAXIMIZED);
			SetActiveView(m_pBattleReport);
			m_pBattleReport->SetFocus();
			break;
		case viewSplitter:
			if (m_pwndSplitter == NULL) CreateSplitterView(&oContext);
			pDoc->AddView((CView *)m_pwndSplitter->GetPane(0, 0));
			pDoc->AddView((CView *)m_pwndSplitter->GetPane(0, 1));
			ModifyStyle(WS_EX_DLGMODALFRAME, WS_THICKFRAME);
			m_pwndSplitter->SetParent(this);
			m_pwndSplitter->RecalcLayout();
			m_pwndSplitter->ShowWindow(SW_SHOWMAXIMIZED);
			m_pwndSplitter->SetFocus();
			m_pwndSplitter->SetActivePane(0,0);
			SetActiveView((CView *)m_pwndSplitter->GetActivePane());
			break;
		default:
			break;
	}
	switch (iOldView)
	{	case viewMainForm:
			m_pMainForm->ShowWindow(SW_HIDE);
			pDoc->RemoveView(m_pMainForm);
			m_pMainForm->SetParent(NULL);
			break;
		case viewReport:
			m_pBattleReport->ShowWindow(SW_HIDE);
			pDoc->RemoveView(m_pBattleReport);
			m_pBattleReport->SetParent(NULL);
			break;
		case viewSplitter:
			m_pwndSplitter->ShowWindow(SW_HIDE);
			CView *pView1 = (CView *)m_pwndSplitter->GetPane(0, 0);
			CView *pView2 = (CView *)m_pwndSplitter->GetPane(0, 1);
			pDoc->RemoveView(pView1);
			pDoc->RemoveView(pView2);
			m_pwndSplitter->SetParent(NULL);
			break;
	}
	pDoc->UpdateAllViews(NULL, iData, NULL);
	EndUpdate();
}

BOOL CMainFrame::CreateNewView(CCreateContext *pContext)
{	
	if (pContext == NULL) return FALSE;
	BOOL bRes = FALSE;
	int iView = GetViewType(pContext->m_pNewViewClass);
	StartUpdate();
	switch (iView)
	{	case viewMainForm:
			if (CreateMainFormView(pContext)) bRes = TRUE;
			ModifyStyle(WS_THICKFRAME, WS_EX_DLGMODALFRAME);
			m_pMainForm->SetParent(this);
			m_pMainForm->ShowWindow(SW_SHOWMAXIMIZED);
			SetActiveView(m_pMainForm);
			break;
		case viewReport:
			if (CreateBattleReport(pContext)) bRes = TRUE;
			ModifyStyle(WS_EX_DLGMODALFRAME, WS_THICKFRAME);
			m_pBattleReport->SetParent(this);
			m_pBattleReport->ShowWindow(SW_SHOWMAXIMIZED);
			SetActiveView(m_pBattleReport);
			break;
		case viewSplitter:
			if (CreateSplitterView(pContext)) bRes = TRUE;
			ModifyStyle(WS_EX_DLGMODALFRAME, WS_THICKFRAME);
			m_pwndSplitter->RecalcLayout();
			m_pwndSplitter->SetParent(this);
			m_pwndSplitter->ShowWindow(SW_SHOWMAXIMIZED);
			m_pwndSplitter->SetActivePane(0, 0);
			SetActiveView((CView *)m_pwndSplitter->GetActivePane());
			break;
	}
	EndUpdate();
	return bRes;
}

bool CMainFrame::CreateMainFormView(CCreateContext *pContext)
{	
	if (pContext->m_pNewViewClass != RUNTIME_CLASS(CMainForm)) return false;
	if (m_pMainForm != NULL) return false;
	CView *pView = (CView *)CreateView(pContext, AFX_IDW_PANE_FIRST);
	m_pMainForm = (CMainForm *)pView;
	m_iCurrentView = viewMainForm;
	return true;
}

bool CMainFrame::CreateBattleReport(CCreateContext *pContext)
{	
	if (pContext->m_pNewViewClass != RUNTIME_CLASS(CBattleReport)) return false;
	if (m_pBattleReport != NULL) return false;
	CView *pView = (CView *)CreateView(pContext, AFX_IDW_PANE_FIRST);
	m_pBattleReport = (CBattleReport *)pView;
	m_iCurrentView = viewReport;
	return true;
}

bool CMainFrame::CreateSplitterView(CCreateContext *pContext)
{	
	int iActivePane;
	if (pContext->m_pNewViewClass == RUNTIME_CLASS(CTurnTreeView)) iActivePane = 0;
	else if (pContext->m_pNewViewClass == RUNTIME_CLASS(CUnitListView)) iActivePane = 1;
	else return false;
	if (m_pwndSplitter != NULL) return false;
	m_pwndSplitter = new CSplitterWndEx();
	if (m_pwndSplitter->CreateStatic(this, 1, 2) == FALSE)
	{	SAFE_DELETE(m_pwndSplitter);
		return false;
	}
	int iX = 200;
	CSize csPane1(iX, 0);
	iX = 100;
	CSize csPane2(iX, 0);
	pContext->m_pNewViewClass = RUNTIME_CLASS(CTurnTreeView);
	if (m_pwndSplitter->CreateView(0, 0, RUNTIME_CLASS(CTurnTreeView), csPane1, pContext) == FALSE)
	{	SAFE_DELETE(m_pwndSplitter);
		return false;
	}
	pContext->m_pNewViewClass = RUNTIME_CLASS(CUnitListView);
	if (m_pwndSplitter->CreateView(0, 1, RUNTIME_CLASS(CUnitListView), csPane2, pContext) == FALSE)
	{	SAFE_DELETE(m_pwndSplitter);
		return false;
	}
	m_iCurrentView = viewSplitter;
	return true;
}

void CMainFrame::OnUpdateBattleUpdatearmies(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	IF_GET_DOC(bEn = pDoc->CanGetSurvivors());
	pCmdUI->Enable(bEn);
}

void CMainFrame::OnBattleUpdatearmies() 
{
	IF_GET_DOC(pDoc->GetSurvivors());
	if (m_iCurrentView == viewMainForm) pDoc->UpdateAllViews(NULL, viewMainForm, NULL);
	else theApp.ChangeView(viewMainForm, viewReport);
}

void CMainFrame::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	if (m_iCurrentView == viewMainForm) pCmdUI->Enable(TRUE);
	else pCmdUI->Enable(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// Check the minimum size
/////////////////////////////////////////////////////////////////////////////
void CMainFrame::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CRect lRect;
	int iMinX = 0;
	int iMinY = 0;
	int iMaxX = 9999;
	int iMaxY = 9999;
	switch (m_iCurrentView)
	{	case viewMainForm:
			break;
		case viewReport:
			iMinX = 264;
			iMinY = 256;
			break;
		case viewSplitter:
			break;
		default:
			break;
	}

	if (lpwndpos->cx < iMinX) lpwndpos->cx = iMinX;
	if (lpwndpos->cx > iMaxX) lpwndpos->cx = iMaxX;
	if (lpwndpos->cy < iMinY) lpwndpos->cy = iMinY;
	if (lpwndpos->cy > iMaxY) lpwndpos->cy = iMaxY;

	CFrameWnd::OnWindowPosChanging(lpwndpos);
}