// abattlesim.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "abattlesim.h"
#include "MainDoc.h"
#include "MainFrame.h"
#include "MainForm.h"
#include "helper.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAbattlesimApp

BEGIN_MESSAGE_MAP(CAbattlesimApp, CWinApp)
	//{{AFX_MSG_MAP(CAbattlesimApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAbattlesimApp construction

CAbattlesimApp::CAbattlesimApp()
{
	// Get a copy of the command line, as MFC messes it up
	LPTSTR pszCmdLine = _tcsdup(GetCommandLine());
	LPTSTR pszStart = pszCmdLine;
	bool bQuoted = false;
	while (iswspace(*pszStart) || (*pszStart == '\"'))
	{	if (*pszStart == '\"') bQuoted = true;
		pszStart++;
	}
	LPTSTR pszEnd = pszStart;
	while (*pszEnd)
	{	if (bQuoted)
		{	if (*pszEnd == '\"') break;
		}
		else
		{	if (iswspace(*pszEnd)) break;
		}
		pszEnd++;
	}
	int iLen = pszEnd - pszStart;
	m_szAppFilename = new char[iLen + 1];
	strncpy(m_szAppFilename, pszStart, iLen);
	m_szAppFilename[iLen] = 0;
	free(pszCmdLine);
	ASSERT(iLen > 0);
	char path[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char fname[_MAX_FNAME];
	char ext[_MAX_EXT];
	_splitpath(m_szAppFilename, drive, dir, fname, ext);
	_makepath(path, drive, dir, "", "");
	iLen = strlen(path);
	m_szAppPath = new char[iLen + 1];
	strncpy(m_szAppPath, path, iLen);
	m_szAppPath[iLen] = 0;
	ASSERT(iLen > 0);
}

CAbattlesimApp::~CAbattlesimApp()
{	delete [] m_szAppFilename;
	delete [] m_szAppPath;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CAbattlesimApp object

CAbattlesimApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CAbattlesimApp initialization

BOOL CAbattlesimApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMainDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMainForm));
	AddDocTemplate(pDocTemplate);
	OnFileNew();
	if (m_pMainWnd == NULL) return FALSE;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}

BOOL CAbattlesimApp::OnIdle(LONG lCount) 
{
	return CWinApp::OnIdle(lCount);
}

int CAbattlesimApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWinApp::ExitInstance();
}

void CAbattlesimApp::ChangeView(int iView, int iData)
{	if (m_pMainWnd == NULL) return;
	m_pMainWnd->PostMessage((UINT)WM_APP, (WPARAM)iData, (LPARAM)iView);
}
