// SplitterWndEx.h: interface for the CSplitterWndEx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPLITTERWNDEX_H__8EAEBE6F_3852_11D3_A3FE_0008C7C6E4AD__INCLUDED_)
#define AFX_SPLITTERWNDEX_H__8EAEBE6F_3852_11D3_A3FE_0008C7C6E4AD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSplitterWndEx : public CSplitterWnd  
{
protected:
	bool m_bUpdating;
public:
	
	CSplitterWndEx();
	virtual ~CSplitterWndEx();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitterWndEx)
	public:
	virtual void OnDrawSplitter( CDC* pDC, ESplitType nType, const CRect& rect );
	virtual BOOL RedrawWindow( LPCRECT lpRectUpdate = NULL, CRgn* prgnUpdate = NULL, UINT flags = RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE );
	virtual void UpdateWindow();
	//}}AFX_VIRTUAL

	void StartUpdate();
	void EndUpdate();
};

#endif // !defined(AFX_SPLITTERWNDEX_H__8EAEBE6F_3852_11D3_A3FE_0008C7C6E4AD__INCLUDED_)
