// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#include "object.h"
#include "items.h"
#include "skills.h"
#include "rules.h"
#include "unit.h"

Object::Object()
{
	elem_type = eobject;
    num = 0;
    type = O_DUMMY;
    basename = new AString("Dummy");
	name = AString::Copy(basename);
    describe = 0;
    capacity = 0;
    inner = -1;
    runes = 0;
}

Object::Object(int t, int r)
{
	elem_type = eobject;
    num = 0;
    type = t;
    basename = new AString(ObjectDefs[t].name);
	name = AString::Copy(basename);
    describe = 0;
    capacity = 0;
    incomplete = 0;
    inner = -1;
    runes = 0;
	if (r)
    {	switch (type)
		{	case O_MFORTRESS:
				runes = 5;
				break;
			case O_CITADEL:
			case O_CASTLE:
			case O_FORT:
			case O_TOWER:
				runes = 3;
				break;
		}
	}
}


Object::~Object()
{
	SAFE_DELETE(basename);
    SAFE_DELETE(name);
    SAFE_DELETE(describe);
	units.DeleteAll();
}

void Object::SetName(AString * s) {
  if (s && (CanModify())) {
    AString * newname = s->getlegal();
    if (!newname) {
      delete s;
      return;
    }
	SAFE_DELETE(basename);
	SAFE_DELETE(name);
	basename = newname;
	name = AString::Copy(basename);
	if (num > 0) *name += AString(" [") + num + "]";
    delete s;
  }
}


void Object::SetId(int id)
{
	num = id;
	SAFE_DELETE(name);
	name = AString::Copy(basename);
	if (num > 0) *name += AString(" [") + num + "]";
}


void Object::SetDescribe(AString * s) {
  if (CanModify()) {
    if (describe) delete describe;
    if (s) {
      AString * newname = s->getlegal();
      delete s;
      describe = newname;
    } else describe = 0;
  }
}

int Object::IsBoat() {
  if (ObjectDefs[type].capacity)
    return 1;
  return 0;
}

int Object::IsBuilding() {
  if (ObjectDefs[type].protect)
    return 1;
  return 0;
}

int Object::CanModify() {
  if (type == O_DUMMY) return 0;
  if (type == O_SHAFT) return 0;
  if (ObjectDefs[type].monster == -1) return 1;
  return 0;
} 

Unit * Object::GetUnit(int num) {
  forlist((&units))
    if (((Unit *) elem)->num == num) return ((Unit *) elem);
  return 0;
}

Unit *Object::GetOwner()
{
    Unit *owner = (Unit *) units.First();
    while( owner && !owner->GetMen() )
    {
        owner = (Unit *) units.Next( owner );
    }
    return( owner );
}

void Object::Report(Areport * f)
{
    if (type != O_DUMMY) {
        AString temp = AString("+ ") + *name + " : " +
            ObjectDefs[type].name;
        if (incomplete) {
            temp += AString(", needs ") + incomplete;
        }
        if (inner != -1) {
            temp += ", contains an inner location";
        }
        if (runes) {
            temp += ", engraved with Runes of Warding";
        }
        if (describe) {
            temp += AString("; ") + *describe;
        }
        if (!ObjectDefs[type].canenter) {
            temp += ", closed to player units";
        }
        temp += ".";
        f->PutStr(temp);
        f->AddTab();
    }
  
    forlist ((&units)) {
        Unit * u = (Unit *) elem;
        u->WriteReport(f);
    }
    f->EndLine();
    if (type != O_DUMMY) {
        f->DropTab();
    }
}

void Object::WriteReport(Areport * f)
{
    if (type != O_DUMMY) {
        AString temp = AString("+ ") + *name + " : " +
            ObjectDefs[type].name;
        if (incomplete) {
            temp += AString(", needs ") + incomplete;
        }
        if (inner != -1) {
            temp += ", contains an inner location";
        }
        if (runes) {
            temp += ", engraved with Runes of Warding";
        }
        if (describe) {
            temp += AString("; ") + *describe;
        }
        if (!ObjectDefs[type].canenter) {
            temp += ", closed to player units";
        }
        temp += ".";
        f->PutStr(temp);
    }
}

/*Object *Object::Copy()
{	Object *obj = new Object();
	SAFE_DELETE(obj->basename);
	SAFE_DELETE(obj->name);
	SAFE_DELETE(obj->describe);
	obj->basename = AString::Copy(basename);
	obj->name = AString::Copy(name);
	obj->describe = AString::Copy(describe);
    obj->inner = inner;
    obj->num = num;
    obj->type = type;
    obj->incomplete = incomplete;
    obj->capacity = capacity;
    obj->runes = runes;
    obj->units.DeleteAll();
	return obj;
}

Object *Object::Copy(Object *obj)
{	if (obj == NULL) return NULL;
	return obj->Copy();
}
*/
void Object::Writeout(Aoutfile *f)
{
	f->PushKey("Object");
		f->PushVal("Name", *basename);
		if (describe) f->PushVal("Description", *describe);
		else f->PushVal("Description", "None");
		f->PushVal("Number", AString(num));
		f->PushVal("Type", ObjectDefs[type].name);
		f->PushVal("Incomplete", AString(incomplete));
		f->PushVal("Runes", (runes ? "Yes" : "No"));
		units.Writeout(f);
    f->PopKey();
}

void Object::Readin(Ainfile *f)
{
	SAFE_DELETE(basename);
	SAFE_DELETE(name);
	SAFE_DELETE(describe);
    delete f->GetStr();
    num = f->GetInt();
    type = f->GetInt();
    incomplete = f->GetInt();
    basename = f->GetStr();
	name = AString::Copy(basename);
 	if (num > 0) *name += AString(" [") + num + "]";
    describe = f->GetStr();
    if (*describe == "none") {
        delete describe;
        describe = 0;
    }
    inner = f->GetInt();
    runes = f->GetInt();
    delete f->GetStr();
    int i = f->GetInt();
    for (int j=0; j<i; j++) {
        Unit * u = new Unit;
        u->Readin(f);
        u->MoveUnit(this);
    }
}

void ObjectList::Writeout(Aoutfile * f) {
  f->PushKey("Objects", "Number", Num());
	  forlist (this)
		((Object *) elem)->Writeout(f);
  f->PopKey();
}

void ObjectList::Readin(Ainfile * f) {
  delete f->GetStr();
  int i = f->GetInt();
  for (int j=0; j<i; j++) {
    Object * temp = new Object;
    temp->Readin(f);
    Add(temp);
  }
}

int ObjectList::Renumber(int from)
{  
	Object *p;
	forlist (this)
	{	p = (Object *) elem;
		if (p) p->SetId(from++);
	}
	return from;
}  

int ObjectList::RenumberUnits(int from)
{
	Object *p;
	forlist(this)
	{	p = (Object *) elem;
		if (p) from = p->units.Renumber(from);
	}
	return from;
}

void ObjectList::DeleteAllUnits()
{
	Object *p;
	forlist(this)
	{	p = (Object *) elem;
		if (p) p->units.DeleteAll();
	}
}