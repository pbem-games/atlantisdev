// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#ifndef OBJECT_CLASS
#define OBJECT_CLASS

class Object;

#include "alist.h"
#include "fileio.h"
#include "gamedefs.h"
#include "unit.h"

#define I_WOOD_OR_STONE -2

class ObjectType {
public:
  char * name;
  int protect;
  int capacity;
  int item;
  int cost;
  int level;
  int skill;
  int sailors;
  int canenter;
  int monster;
  int production;
};

extern ObjectType * ObjectDefs;

class Object : public ADynListElem
{
public:
    Object();
	Object(int,int);
    ~Object();
  
    void Writeout( Aoutfile *f );
    void Readin( Ainfile *s );

	void SetName(AString *);
    void SetDescribe(AString *);
	void SetId(int);
  
    Unit *GetUnit(int);

	//Object *Copy(); // Copy the object, but not the list of units
	//static Object *Copy(Object *);

    int IsBoat();
    int IsBuilding();
	int CanModify();
    Unit *GetOwner();
	void Report(Areport * f);
	void WriteReport(Areport * f); // Doesn't do units

    AString * name;
	AString * basename;
    AString * describe;
    int inner;
    int num;
    int type;
    int incomplete;
    int capacity;
    int runes;
    UnitList units;
};

class ObjectList : public AList
{
public:
    void Readin(Ainfile *);
    void Writeout(Aoutfile *);
	int Renumber(int );
	int RenumberUnits(int );
	void DeleteAllUnits();
};


#endif
