// ReportView.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "ReportView.h"
#include "MainDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReportView

IMPLEMENT_DYNCREATE(CReportView, CEditView)

CReportView::CReportView()
{
}

CReportView::~CReportView()
{
}


BEGIN_MESSAGE_MAP(CReportView, CEditView)
	//{{AFX_MSG_MAP(CReportView)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReportView drawing

void CReportView::OnDraw(CDC* pDC)
{
	//CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CReportView diagnostics

#ifdef _DEBUG
void CReportView::AssertValid() const
{
	CEditView::AssertValid();
}

void CReportView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CReportView message handlers

void CReportView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	GET_DOC_OR_RETURN;
	CEdit &m_Edit = GetEditCtrl();
	char *szText = pDoc->GetBattleReportText();
	m_Edit.SetWindowText(szText);
	m_Edit.RedrawWindow();
	RedrawWindow();
}

void CReportView::OnInitialUpdate() 
{
	CEditView::OnInitialUpdate();
}

BOOL CReportView::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.style |= WS_BORDER | ES_READONLY | ES_MULTILINE;
	return CEditView::PreCreateWindow(cs);
}
