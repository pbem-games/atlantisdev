// MainForm.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "MainFrame.h"
#include "MainForm.h"
#include "MainDoc.h"
#include "Utils.h"
#include "rules.h"
#include "aregion.h"
#include "unit.h"
#include "object.h"
#include "army.h"
#include "battle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define MAX_CB_HEIGHT 200

/////////////////////////////////////////////////////////////////////////////
// CMainForm

IMPLEMENT_DYNCREATE(CMainForm, CFormView)

CMainForm::CMainForm()
	: CFormView(CMainForm::IDD)
{	m_bUpdating = false;
	//{{AFX_DATA_INIT(CMainForm)
	m_iNumber = 1;
	m_strUnitDesc = _T("");
	m_strName = _T("");
	m_bBehind = FALSE;
	m_bRunes = FALSE;
	m_strBldName = _T("");
	m_iMonths = 0;
	m_bBattleItems = TRUE;
	m_bCombatSkills = TRUE;
	m_bMagicSkills = FALSE;
	m_bMen = TRUE;
	m_bMonsters = TRUE;
	m_bNormal = FALSE;
	m_bOtherItems = FALSE;
	m_bCanLearn = TRUE;
	m_bCombatMagic = TRUE;
	m_bArmour = FALSE;
	m_bMounts = FALSE;
	m_bWeapons = FALSE;
	//}}AFX_DATA_INIT
	m_pUnit = NULL;
	m_pAttList = NULL;
	m_pDefList = NULL;
	m_pAttBld = NULL;
	m_pDefBld = NULL;
	m_iSkill = S_COMBAT;
	m_iDays = 30;
	m_iItem = I_LEADERS;
	m_iBld = O_TOWER;
	m_iTerrain = R_PLAIN;
}

CMainForm::~CMainForm()
{
}

void CMainForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMainForm)
	DDX_Control(pDX, IDC_CHK_RUNES, m_chkRunes);
	DDX_Control(pDX, IDC_LIST_DEF, m_lstDef);
	DDX_Control(pDX, IDC_LIST_ATT, m_lstAtt);
	DDX_Control(pDX, IDC_LIST_UNIT, m_lstUnit);
	DDX_Control(pDX, IDC_CB_TERRAIN, m_cbTerrain);
	DDX_Control(pDX, IDC_CB_BUILDING, m_cbBuilding);
	DDX_Control(pDX, IDC_ED_NUMBER, m_edNumber);
	DDX_Control(pDX, IDC_CB_SPELLS, m_cbSpells);
	DDX_Control(pDX, IDC_CB_ITEMS, m_cbItems);
	DDX_Control(pDX, IDC_CB_MONTHS, m_cbMonths);
	DDX_Control(pDX, IDC_CB_SKILLS, m_cbSkills);
	DDX_Text(pDX, IDC_ED_NUMBER, m_iNumber);
	DDX_LBString(pDX, IDC_LIST_UNIT, m_strUnitDesc);
	DDX_Text(pDX, IDC_ED_NAME, m_strName);
	DDX_Check(pDX, IDC_CHK_BEHIND, m_bBehind);
	DDX_Check(pDX, IDC_CHK_RUNES, m_bRunes);
	DDX_Text(pDX, IDC_EDBLD_NAME, m_strBldName);
	DDX_CBIndex(pDX, IDC_CB_MONTHS, m_iMonths);
	DDX_Check(pDX, IDC_CHK_BATTLE_ITEMS, m_bBattleItems);
	DDX_Check(pDX, IDC_CHK_COMBAT_SKILLS, m_bCombatSkills);
	DDX_Check(pDX, IDC_CHK_MAGIC_SKILLS, m_bMagicSkills);
	DDX_Check(pDX, IDC_CHK_MEN, m_bMen);
	DDX_Check(pDX, IDC_CHK_MONSTERS, m_bMonsters);
	DDX_Check(pDX, IDC_CHK_NORMAL_SKILLS, m_bNormal);
	DDX_Check(pDX, IDC_CHK_OTHER_ITEMS, m_bOtherItems);
	DDX_Check(pDX, IDC_CHK_CAN_LEARN_SKILLS, m_bCanLearn);
	DDX_Check(pDX, IDC_CHK_COMBAT_MAGIC_SKILLS, m_bCombatMagic);
	DDX_Check(pDX, IDC_CHK_ARMOUR, m_bArmour);
	DDX_Check(pDX, IDC_CHK_MOUNTS, m_bMounts);
	DDX_Check(pDX, IDC_CHK_WEAPONS, m_bWeapons);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMainForm, CFormView)
	//{{AFX_MSG_MAP(CMainForm)
	ON_BN_CLICKED(IDC_BTN_STUDY, OnBtnStudy)
	ON_CBN_SELCHANGE(IDC_CB_SKILLS, OnSelchangeCbSkills)
	ON_CBN_SELCHANGE(IDC_CB_MONTHS, OnSelchangeCbMonths)
	ON_CBN_SELCHANGE(IDC_CB_ITEMS, OnSelchangeCbItems)
	ON_BN_CLICKED(IDC_BTN_ADD, OnBtnAdd)
	ON_CBN_SELCHANGE(IDC_CB_SPELLS, OnSelchangeCbSpells)
	ON_EN_CHANGE(IDC_ED_NUMBER, OnChangeEdNumber)
	ON_BN_CLICKED(IDC_BTN_REMOVE, OnBtnRemove)
	ON_BN_CLICKED(IDC_BTN_FORGET, OnBtnForget)
	ON_CBN_SELCHANGE(IDC_CB_BUILDING, OnSelchangeCbBuilding)
	ON_CBN_SELCHANGE(IDC_CB_TERRAIN, OnSelchangeCbTerrain)
	ON_BN_CLICKED(ID_DESIGN_ADDUNITTOATTACKERS, OnBtnAttUnit)
	ON_BN_CLICKED(ID_DESIGN_ADDUNITTODEFENDERS, OnBtnDefUnit)
	ON_BN_CLICKED(ID_DESIGN_CLEARUNIT, OnBtnClear)
	ON_BN_CLICKED(ID_ATTACKERS_MOVETODESIGN, OnBtnAttRemove)
	ON_BN_CLICKED(ID_DEFENDERS_MOVETODESIGN, OnBtnDefRemove)
	ON_BN_CLICKED(ID_ATTACKERS_COPYTODESIGN, OnBtnCopyAtt)
	ON_BN_CLICKED(ID_DEFENDERS_COPYTODESIGN, OnBtnCopyDef)
	ON_BN_CLICKED(IDC_CHK_BEHIND, OnChkBehind)
	ON_BN_CLICKED(ID_ATTACKERS_DELETE, OnBtnDelAtt)
	ON_BN_CLICKED(ID_DEFENDERS_DELETE, OnBtnDelDef)
	ON_BN_CLICKED(ID_DESIGN_ATTACKERSBUILDING, OnBtnAttBld)
	ON_BN_CLICKED(ID_DESIGN_DEFENDERSBUILDING, OnBtnDefBld)
	ON_EN_CHANGE(IDC_EDBLD_NAME, OnChangeEdbldName)
	ON_EN_CHANGE(IDC_ED_NAME, OnChangeEdName)
	ON_BN_CLICKED(IDC_CHK_BATTLE_ITEMS, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_COMBAT_SKILLS, OnChkShowSkills)
	ON_BN_CLICKED(IDC_CHK_RUNES, OnChkRunes)
	ON_BN_CLICKED(ID_ATTACKERS_CLEAR, OnBtnClearAtt)
	ON_BN_CLICKED(ID_DEFENDERS_CLEAR, OnBtnClearDef)
	ON_BN_CLICKED(ID_FILE_LOADUNITS, OnBtnLoadReport)
	ON_BN_CLICKED(ID_RUN_BATTLE, OnRunBattle)
	ON_BN_CLICKED(ID_APP_EXIT, OnAppExit)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_BN_CLICKED(ID_FILE_OPEN, OnFileOpen)
	ON_BN_CLICKED(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_RUN_BATTLE, OnUpdateRunBattle)
	ON_WM_SIZE()
	ON_UPDATE_COMMAND_UI(ID_ATTACKERS_CLEAR, OnUpdateAttackers)
	ON_UPDATE_COMMAND_UI(ID_ATTACKERS_COPYTODESIGN, OnUpdateAttackerSelected)
	ON_UPDATE_COMMAND_UI(ID_ATTACKERS_DELETE, OnUpdateAttackerOrBldSelected)
	ON_UPDATE_COMMAND_UI(ID_DEFENDERS_CLEAR, OnUpdateDefenders)
	ON_UPDATE_COMMAND_UI(ID_DEFENDERS_COPYTODESIGN, OnUpdateDefenderSelected)
	ON_UPDATE_COMMAND_UI(ID_DEFENDERS_DELETE, OnUpdateDefenderOrBldSelected)
	ON_UPDATE_COMMAND_UI(ID_DESIGN_ADDUNITTOATTACKERS, OnUpdateUnitExists)
	ON_WM_CLOSE()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BTN_LOADUNIT, OnBtnLoadunit)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHK_MONSTERS, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_OTHER_ITEMS, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_MEN, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_MAGIC_SKILLS, OnChkShowSkills)
	ON_BN_CLICKED(IDC_CHK_NORMAL_SKILLS, OnChkShowSkills)
	ON_BN_CLICKED(IDC_CHK_ARMOUR, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_CAN_LEARN_SKILLS, OnChkShowSkills)
	ON_BN_CLICKED(IDC_CHK_COMBAT_MAGIC_SKILLS, OnChkShowSkills)
	ON_BN_CLICKED(IDC_CHK_MOUNTS, OnChkShowItems)
	ON_BN_CLICKED(IDC_CHK_WEAPONS, OnChkShowItems)
	ON_COMMAND(ID_RUN_BATTLE, OnRunBattle)
	ON_UPDATE_COMMAND_UI(ID_ATTACKERS_MOVETODESIGN, OnUpdateAttackerSelected)
	ON_UPDATE_COMMAND_UI(ID_DEFENDERS_MOVETODESIGN, OnUpdateDefenderSelected)
	ON_UPDATE_COMMAND_UI(ID_DESIGN_ADDUNITTODEFENDERS, OnUpdateUnitExists)
	ON_BN_CLICKED(IDC_BTN_SAVEUNIT, OnBtnSaveunit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainForm diagnostics

#ifdef _DEBUG
void CMainForm::AssertValid() const
{
	CFormView::AssertValid();
}

void CMainForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainForm message handlers
void CMainForm::StartUpdate()
{	m_bUpdating = true;
}

void CMainForm::EndUpdate()
{	m_bUpdating = false;
	Invalidate();
}

BOOL CMainForm::RedrawWindow( LPCRECT lpRectUpdate, CRgn* prgnUpdate, UINT flags)
{
	if (m_bUpdating) return FALSE;
	return CWnd::RedrawWindow(lpRectUpdate, prgnUpdate, flags);
}

void CMainForm::UpdateWindow()
{
	if (m_bUpdating) return;
	CWnd::UpdateWindow();
}

void CMainForm::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	/*StartUpdate();
	ResizeParentToFit(FALSE);
	ResizeParentToFit(FALSE); // remove the scrollbars
	EndUpdate();
	*/
}

void CMainForm::SetDescription()
{
	StartUpdate();
	m_lstUnit.ResetContent();
	CUtils::AddUnitToList(m_lstUnit, m_pUnit);
	UpdateData(FALSE);
	EndUpdate();
}

void CMainForm::SetEdits()
{
	if (m_pUnit == NULL) return;
	StartUpdate();
	m_strName = m_pUnit->GetBasename();
	m_bBehind = (BOOL)m_pUnit->GetFlag(FLAG_BEHIND);
	UpdateData(FALSE);
	EndUpdate();
}

void CMainForm::OnBtnStudy() 
{
	if (m_pUnit == NULL) return;
	if (m_iSkill < 0) return;
	StartUpdate();
	m_pUnit->StudyOrder(m_iSkill, m_iDays);
	SetSkillList();
	SetSpellList();
	SetDescription();
	EndUpdate();
}

void CMainForm::OnBtnForget() 
{
	if (m_pUnit == NULL) return;
	if (m_iSkill < 0) return;
	StartUpdate();
	m_pUnit->ForgetSkill(m_iSkill);
	SetSkillList();
	SetSpellList();
	SetDescription();
	EndUpdate();
}

void CMainForm::OnChkBehind() 
{
	if (m_pUnit == NULL) return;
	StartUpdate();
	UpdateData(TRUE);
	m_pUnit->SetFlag(FLAG_BEHIND, (int)m_bBehind);
	SetDescription();
	EndUpdate();
}

void CMainForm::SetSkillList()
{	if (m_cbSkills.GetSafeHwnd() == NULL) return;
	StartUpdate();
	m_cbSkills.ResetContent();
	int iCanStudy;
	int skill;
	int index;
	int iHeight = 0;
	for (skill = 0; skill < NSKILLS; skill++)
	{	if (m_pUnit != NULL) iCanStudy = m_pUnit->CanStudy(skill);
		else iCanStudy = 0;
		if (CheckFlags(SkillDefs[skill].flags, iCanStudy))
		{	index = m_cbSkills.AddString(SkillStrs(skill).Str());
			m_cbSkills.SetItemData(index, (DWORD)skill);
			iHeight += m_cbSkills.GetItemHeight(index);
		}
	}
	int selindex = 0;
	int count = m_cbSkills.GetCount();
	for (index = 0; index < count; index++)
	{	skill = m_cbSkills.GetItemData(index);
		if (m_iSkill == skill)
		{	selindex = index;
			break;
		}
	}
	m_cbSkills.SetCurSel(selindex);
	if (iHeight > MAX_CB_HEIGHT) iHeight = MAX_CB_HEIGHT;
	RECT lRect;
	m_cbSkills.GetWindowRect(&lRect);
	lRect.bottom = lRect.bottom + iHeight + 8;
	ScreenToClient(&lRect);
	m_cbSkills.SetWindowPos(NULL, lRect.left, lRect.top,
		lRect.right - lRect.left, lRect.bottom - lRect.top,
		SWP_NOOWNERZORDER|SWP_NOZORDER);
	OnSelchangeCbSkills();
	EndUpdate();
}

void CMainForm::OnSelchangeCbSkills() 
{
	if (m_cbSkills.GetSafeHwnd() == NULL) return;
	int index = m_cbSkills.GetCurSel();
	if (index >= 0) m_iSkill = m_cbSkills.GetItemData(index);
	else m_iSkill = -1;
}

void CMainForm::OnSelchangeCbMonths() 
{
	if (m_cbMonths.GetSafeHwnd() == NULL) return;
	UpdateData(TRUE);
	m_iDays = 30 * (m_iMonths+1);
}

void CMainForm::SetItemList()
{	if (m_cbItems.GetSafeHwnd() == NULL) return;
	StartUpdate();
	m_cbItems.ResetContent();
	int item;
	int index;
	int iHeight = 0;
	for (item = 0; item < NITEMS; item++)
	{	if (CheckItemType(ItemDefs[item].type))
		{	index = m_cbItems.AddString(ItemStr(item, 1).Str());
			m_cbItems.SetItemData(index, (DWORD)item);
			iHeight += m_cbItems.GetItemHeight(index);
		}
	}
	int selindex = 0;
	int count = m_cbItems.GetCount();
	for (index = 0; index < count; index++)
	{	item = m_cbItems.GetItemData(index);
		if (m_iItem == item)
		{	selindex = index;
			break;
		}
	}
	m_cbItems.SetCurSel(selindex);
	if (iHeight > MAX_CB_HEIGHT) iHeight = MAX_CB_HEIGHT;
	RECT lRect;
	m_cbItems.GetWindowRect(&lRect);
	lRect.bottom = lRect.bottom + iHeight + 8;
	ScreenToClient(&lRect);
	m_cbItems.SetWindowPos(NULL, lRect.left, lRect.top,
		lRect.right - lRect.left, lRect.bottom - lRect.top,
		SWP_NOOWNERZORDER|SWP_NOZORDER);
	OnSelchangeCbItems();
	EndUpdate();
}

void CMainForm::OnSelchangeCbItems() 
{
	if (m_cbItems.GetSafeHwnd() == NULL) return;
	int index = m_cbItems.GetCurSel();
	if (index >= 0) m_iItem = m_cbItems.GetItemData(index);
	else m_iItem = -1;
}

void CMainForm::OnBtnAdd() 
{
	if (m_pUnit == NULL) return;
	if (m_iItem < 0) return;
	int items = m_pUnit->GetMen(m_iItem);
	if ((m_pUnit->type == U_MAGE) && (ItemDefs[m_iItem].type & IT_MAN))
	{	m_pUnit->Error("Add: Mages must be 1 leader units");
		return;
	}
	if (m_iNumber <= 0) m_iNumber = 1;
	StartUpdate();
	m_pUnit->SetMen(m_iItem, items + m_iNumber);
	if (m_pUnit->GetMen() <= 0) m_pUnit->type = U_WMON;
	else if (m_pUnit->type == U_WMON) m_pUnit->type = U_NORMAL;
	SetSkillList();
	SetDescription();
	EndUpdate();
}

void CMainForm::OnBtnRemove() 
{
	if (m_pUnit == NULL) return;
	if (m_iItem < 0) return;
	int items = m_pUnit->GetMen(m_iItem);
	if (m_iNumber <= 0) m_iNumber = 1;
	items -= m_iNumber;
	if (items < 0) items = 0;
	StartUpdate();
	m_pUnit->SetMen(m_iItem, items);
	SetSkillList();
	SetDescription();
	EndUpdate();
}

void CMainForm::SetSpellList()
{	if (m_cbSpells.GetSafeHwnd() == NULL) return;
	StartUpdate();
	UpdateData(TRUE);
	m_cbSpells.ResetContent();
	int index;
	int iHeight = 0;
	int skill;
	for (skill = 0; skill < NSKILLS; skill++)
	{	if (m_pUnit != NULL)
		{	if (m_pUnit->GetSkill(skill) &&
				(SkillDefs[skill].flags & SkillType::COMBAT) &&
				(SkillDefs[skill].flags & SkillType::MAGIC))
			{	index = m_cbSpells.AddString(SkillStrs(skill).Str());
				m_cbSpells.SetItemData(index, (DWORD)skill);
				iHeight += m_cbSpells.GetItemHeight(index);
			}
		}
	}
	int selindex = -1;
	int count = m_cbSpells.GetCount();
	for (index = 0; index < count; index++)
	{	skill = m_cbSpells.GetItemData(index);
		if (m_pUnit != NULL)
		{	if (m_pUnit->combat == skill)
			{	selindex = index;
				break;
			}
		}
	}
	m_cbSpells.SetCurSel(selindex);
	RECT lRect;
	m_cbSpells.GetWindowRect(&lRect);
	lRect.bottom = lRect.bottom + iHeight + 8;
	ScreenToClient(&lRect);
	m_cbSpells.SetWindowPos(NULL, lRect.left, lRect.top,
		lRect.right - lRect.left, lRect.bottom - lRect.top,
		SWP_NOOWNERZORDER|SWP_NOZORDER);
	OnSelchangeCbSpells();
	EndUpdate();
}

void CMainForm::OnSelchangeCbSpells() 
{
	if (m_cbSpells.GetSafeHwnd() == NULL) return;
	int index = m_cbSpells.GetCurSel();
	int iCombat = -1;
	if (index >= 0) iCombat = m_cbSpells.GetItemData(index);
	if (m_pUnit == NULL) return;
	StartUpdate();
	if ((m_pUnit->type != U_MAGE) || (iCombat < -1))
	{	iCombat = -1;
		m_cbSpells.SetCurSel(-1);
	}
	m_pUnit->CombatOrder(iCombat);
	SetDescription();
	EndUpdate();
}

void CMainForm::OnChangeEdNumber() 
{
	if (m_edNumber.GetSafeHwnd() == NULL) return;
	UpdateData(TRUE);
}

bool CMainForm::CheckFlags(int iFlags, int iCanStudy)
{	
	if (!iCanStudy && (m_bCanLearn == TRUE)) return false;
	int iCombat = iFlags & SkillType::AFFECTS_COMBAT;
	int iCombatMagic = iFlags & (SkillType::COMBAT | SkillType::FOUNDATION);
	int iMagic = iFlags & SkillType::MAGIC;
	if (iCombat && (m_bCombatSkills == TRUE)) return true;
	if (iCombatMagic && (m_bCombatMagic == TRUE)) return true;
	if (iMagic && (m_bMagicSkills == TRUE)) return true;
	if (!iMagic && !iCombatMagic && (m_bNormal == TRUE)) return true;
	return false;
}

bool CMainForm::CheckItemType(int iType)
{	
	if ((m_bBattleItems == TRUE) && (iType & IT_BATTLE)) return true;
	if ((m_bMen == TRUE) && (iType & IT_MAN)) return true;
	if ((m_bMonsters == TRUE) && (iType & IT_MONSTER)) return true;
	if ((m_bWeapons == TRUE) && (iType & IT_WEAPON)) return true;
	if ((m_bArmour == TRUE) && (iType & IT_ARMOR)) return true;
	if ((m_bMounts == TRUE) && (iType & IT_MOUNT)) return true;
	if ((m_bBattleItems == TRUE) && (iType & IT_BATTLE)) return true;
	if ((m_bOtherItems == TRUE) && !(iType &
		(IT_MAN | IT_MONSTER | IT_WEAPON | IT_ARMOR | IT_MOUNT | IT_BATTLE))) return true;
	return false;
}

void CMainForm::SetTerrainList()
{	if (m_cbTerrain.GetSafeHwnd() == NULL) return;
	StartUpdate();
	m_cbTerrain.ResetContent();
	int index;
	int ter;
	int iHeight = 0;
	for (ter = 0; ter < R_NUM; ter++)
	{	index = m_cbTerrain.AddString(TerrainDefs[ter].name);
		m_cbTerrain.SetItemData(index, (DWORD)ter);
		iHeight += m_cbTerrain.GetItemHeight(index);
	}
	int selindex = 0;
	int count = m_cbTerrain.GetCount();
	for (index = 0; index < count; index++)
	{	ter = m_cbTerrain.GetItemData(index);
		if (m_iTerrain == ter)
		{	selindex = index;
			break;
		}
	}
	m_cbTerrain.SetCurSel(selindex);
	RECT lRect;
	m_cbTerrain.GetWindowRect(&lRect);
	lRect.bottom = lRect.bottom + iHeight + 8;
	ScreenToClient(&lRect);
	m_cbTerrain.SetWindowPos(NULL, lRect.left, lRect.top,
		lRect.right - lRect.left, lRect.bottom - lRect.top,
		SWP_NOOWNERZORDER|SWP_NOZORDER);
	OnSelchangeCbTerrain();
	EndUpdate();
}

void CMainForm::SetBuildingList()
{	if (m_cbBuilding.GetSafeHwnd() == NULL) return;
	StartUpdate();
	m_cbBuilding.ResetContent();
	int index;
	int iHeight = 0;
	int bld;
	for (bld = 0; bld < NOBJECTS; bld++)
	{	if ((ObjectDefs[bld].skill ==  S_SHIPBUILDING) ||
			(ObjectDefs[bld].skill ==  S_BUILDING))
		{	index = m_cbBuilding.AddString(ObjectDefs[bld].name);
			m_cbBuilding.SetItemData(index, (DWORD)bld);
			iHeight += m_cbBuilding.GetItemHeight(index);
		}
	}
	int selindex = 0;
	int count = m_cbBuilding.GetCount(); 
	for (index = 0; index < count; index++)
	{	{	bld = m_cbBuilding.GetItemData(index);
			if (bld == m_iBld) selindex = index;
		}
	}
	m_cbBuilding.SetCurSel(selindex);
	RECT lRect;
	m_cbBuilding.GetWindowRect(&lRect);
	lRect.bottom = lRect.bottom + iHeight + 8;
	ScreenToClient(&lRect);
	m_cbBuilding.SetWindowPos(NULL, lRect.left, lRect.top,
		lRect.right - lRect.left, lRect.bottom - lRect.top,
		SWP_NOOWNERZORDER|SWP_NOZORDER);
	OnSelchangeCbBuilding();
	EndUpdate();
}

void CMainForm::OnSelchangeCbBuilding() 
{
	if (m_cbBuilding.GetSafeHwnd() == NULL) return;
	int index = m_cbBuilding.GetCurSel();
	if (index >= 0) m_iBld = m_cbBuilding.GetItemData(index);
	else m_iBld = -1;
	switch (m_iBld)
	{	case O_MFORTRESS:
		case O_CITADEL:
		case O_CASTLE:
		case O_FORT:
		case O_TOWER:
			m_chkRunes.EnableWindow(TRUE);
			break;
		default:
			m_chkRunes.EnableWindow(FALSE);
			break;
	}
}

void CMainForm::OnSelchangeCbTerrain() 
{
	UpdateData(TRUE);
	int index = m_cbTerrain.GetCurSel();
	if (index >= 0) m_iTerrain = m_cbTerrain.GetItemData(index);
	else m_iTerrain = R_PLAIN;
}

void CMainForm::OnChangeEdbldName() 
{
	UpdateData(TRUE);	
}

void CMainForm::OnBtnAttUnit() 
{
	if (m_pUnit == NULL) return;
	if (!m_pUnit->IsAlive()) return;
	StartUpdate();
	Unit *pUnit = new Unit(*m_pUnit);
	Object *pBld = CUtils::GetSelectedBuilding(m_lstAtt);
	if (pBld != NULL) pUnit->MoveUnit(pBld);
	else m_pAttList->Add(pUnit);
	RenumberAtt();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	EndUpdate();
}

void CMainForm::OnBtnDefUnit() 
{
	if (m_pUnit == NULL) return;
	if (!m_pUnit->IsAlive()) return;
	StartUpdate();
	Unit *pUnit = new Unit(*m_pUnit);
	Object *pBld = CUtils::GetSelectedBuilding(m_lstDef);
	if (pBld != NULL) pUnit->MoveUnit(pBld);
	else m_pDefList->Add(pUnit);
	RenumberDef();
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
	EndUpdate();
}

void CMainForm::OnBtnClear() 
{
	if (m_pUnit == NULL) return;
	StartUpdate();
	m_pUnit->Clear();
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	EndUpdate();
}

void CMainForm::OnBtnAttRemove() 
{
	/*ADynListElem *pElem = GetSelectedObject(m_lstAtt);
	if (pElem == NULL) return;
	if (pElem->elem_type == eunit)
	{	Unit *pUnit = (Unit *)pElem;
		m_pAttList->Remove(pUnit);
		pUnit->MoveUnit(NULL);
		m_pUnit->Copy(*pUnit);
		m_pUnit->SetId(0);
		delete pUnit;
		SetDescription();
		SetEdits();
		SetSkillList();
		SetSpellList();
	}
	else if (pElem->elem_type == eobject)
	{	Object *pBld = (Object *)pElem;
	}*/
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstAtt);
	if (pUnit == NULL) return;
	StartUpdate();
	m_pAttList->Remove(pUnit);
	pUnit->MoveUnit(NULL);
	m_pUnit->Copy(*pUnit);
	m_pUnit->SetId(0);
	delete pUnit;
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	RenumberAtt();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	EndUpdate();
}

void CMainForm::OnBtnDefRemove() 
{
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstDef);
	if (pUnit == NULL) return;
	StartUpdate();
	m_pDefList->Remove(pUnit);
	pUnit->MoveUnit(NULL);
	m_pUnit->Copy(*pUnit);
	m_pUnit->SetId(0);
	delete pUnit;
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	RenumberDef();
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
	EndUpdate();
}

void CMainForm::OnBtnDelAtt() 
{
	ADynListElem *pElem = CUtils::GetSelectedObject(m_lstAtt);
	if (pElem == NULL) return;
	StartUpdate();
	Unit *pUnit;
	if (pElem->elem_type == eunit)
	{	pUnit = (Unit *)pElem;
		pUnit->MoveUnit(NULL);
		m_pAttList->Remove(pUnit);
		delete pUnit;
	}
	else if (pElem->elem_type == eobject)
	{	Object *pBld = (Object *)pElem;
		m_pAttBld->Remove(pBld);
		forlist(&(pBld->units))
		{	pUnit = new Unit((Unit &)*elem);
			pUnit->MoveUnit(NULL);
			m_pAttList->Add(pUnit);
		}
		delete pBld;
	}
	RenumberAtt();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	EndUpdate();
}

void CMainForm::OnBtnClearAtt() 
{
	StartUpdate();
	m_pAttList->DeleteAll();
	m_pAttBld->DeleteAll();
	RenumberAtt();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	EndUpdate();
}

void CMainForm::OnBtnDelDef() 
{
	ADynListElem *pElem = CUtils::GetSelectedObject(m_lstDef);
	if (pElem == NULL) return;
	StartUpdate();
	Unit *pUnit;
	if (pElem->elem_type == eunit)
	{	pUnit = (Unit *)pElem;
		pUnit->MoveUnit(NULL);
		m_pDefList->Remove(pUnit);
		delete pUnit;
	}
	else if (pElem->elem_type == eobject)
	{	Object *pBld = (Object *)pElem;
		m_pDefBld->Remove(pBld);
		forlist(&(pBld->units))
		{	pUnit = new Unit((Unit &)*elem);
			pUnit->MoveUnit(NULL);
			m_pDefList->Add(pUnit);
		}
		delete pBld;
	}
	RenumberDef();
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
	EndUpdate();
}

void CMainForm::OnBtnClearDef() 
{
	StartUpdate();
	m_pDefList->DeleteAll();
	m_pDefBld->DeleteAll();
	RenumberDef();
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
	EndUpdate();
}

void CMainForm::OnBtnCopyAtt() 
{
	/*ADynListElem *pElem = GetSelectedObject(m_lstAtt);
	if (pElem == NULL) return;
	if (pElem->elem_type == eunit)
	{	Unit *pUnit = (Unit *)pElem;
		m_pUnit->Copy(*pUnit);
		SetDescription();
		SetEdits();
		SetSkillList();
		SetSpellList();
	}
	*/
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstAtt);
	if (pUnit == NULL) return;
	StartUpdate();
	m_pUnit->Copy(*pUnit);
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	EndUpdate();
}

void CMainForm::OnBtnCopyDef() 
{
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstDef);
	if (pUnit == NULL) return;
	StartUpdate();
	m_pUnit->Copy(*pUnit);
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	EndUpdate();
}

void CMainForm::OnBtnAttBld() 
{
	StartUpdate();
	Object *pObj = new Object(m_iBld, (int)m_bRunes);
	if (!m_strBldName.IsEmpty())
	{	AString *s = new AString((LPCSTR)m_strBldName);
		pObj->SetName(s);
	}
	m_pAttBld->Add(pObj);
	RenumberAtt();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	EndUpdate();
}

void CMainForm::OnBtnDefBld() 
{
	StartUpdate();
	Object *pObj = new Object(m_iBld, (int)m_bRunes);
	if (!m_strBldName.IsEmpty())
	{	AString *s = new AString((LPCSTR)m_strBldName);
		pObj->SetName(s);
	}
	m_pDefBld->Add(pObj);
	RenumberDef();
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
	EndUpdate();
}

void CMainForm::OnChangeEdName() 
{
	if (m_pUnit == NULL) return;
	UpdateData(TRUE);
	if (m_strName.IsEmpty()) return;
	AString *temp = new AString(m_strName);
	m_pUnit->SetName(temp);
	SetDescription();
}

void CMainForm::OnChkShowItems() 
{
	UpdateData(TRUE);
	SetItemList();
}

void CMainForm::OnChkShowSkills() 
{
	UpdateData(TRUE);
	SetSkillList();
}

void CMainForm::OnChkRunes() 
{
	UpdateData(TRUE);
}

static const char szFilters2[] = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*|";

void CMainForm::OnBtnLoadReport() 
{
	GET_DOC_OR_RETURN;

	CFileDialog dlgFile(TRUE, "txt", /*LPCTSTR lpszFileName = */NULL,
		OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY, szFilters2, this);
	dlgFile.m_ofn.lpstrTitle = "Load Units From Report";
	dlgFile.m_ofn.nFilterIndex = 1;
	if (dlgFile.DoModal() != IDOK) return;
	CString strFile(dlgFile.GetPathName());
	pDoc->OnLoadReport((char *)strFile.GetBuffer(0));
}

void CMainForm::RenumberAtt()
{
	GET_DOC_OR_RETURN;
	pDoc->RenumberAtt();
	UpdateData(FALSE);
}

void CMainForm::RenumberDef()
{
	GET_DOC_OR_RETURN;
	pDoc->RenumberDef();
	UpdateData(FALSE);
}

void CMainForm::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	//if ((lHint == 0) && (pHint == NULL)) return;

	GET_DOC_OR_RETURN;

	StartUpdate();

	m_pUnit = pDoc->m_pUnit;
	m_pAttList = pDoc->m_pAttList;
	m_pDefList = pDoc->m_pDefList;
	m_pAttBld = pDoc->m_pAttBld;
	m_pDefBld = pDoc->m_pDefBld;

	pDoc->GetItemsAndObjects(m_iNumber, m_bRunes, m_strBldName, m_iMonths, m_iDays,
		m_iSkill, m_iItem, m_iBld, m_iTerrain, m_bBattleItems, m_bCombatSkills,
		m_bMagicSkills, m_bMen, m_bMonsters, m_bNormal, m_bOtherItems, m_bCanLearn,
		m_bCombatMagic, m_bArmour, m_bMounts, m_bWeapons);
	UpdateData(FALSE);

	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	SetItemList();
	SetBuildingList();
	SetTerrainList();
	pDoc->RenumberAtt();
	pDoc->RenumberDef();

	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);

	ResizeParentToFit(FALSE);
	ResizeParentToFit(FALSE); // remove the scrollbars

	EndUpdate();
}

void CMainForm::OnUpdateRunBattle(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	IF_GET_DOC(bEn = pDoc->CanRunBattle());
	pCmdUI->Enable(bEn);
}

void CMainForm::OnRunBattle() 
{
	GET_DOC_OR_RETURN;
	if (!pDoc->CanRunBattle()) return;
	pDoc->RunBattle();
	theApp.ChangeView(viewReport, viewMainForm);
}

void CMainForm::OnAppExit() 
{
	SynchDoc();
	theApp.HideApplication();
	theApp.CloseAllDocuments(TRUE);
}

void CMainForm::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable();
}

static const char szFilters[] = "Battle Files (*.btl)|*.btl|Text Files (*.txt)|*.txt|Data Files (*.dat)|*.dat|All Files (*.*)|*.*|";

void CMainForm::OnFileOpen() 
{
	GET_DOC_OR_RETURN;
	CFileDialog dlgFile(TRUE, "btl", NULL,
		OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY, szFilters, this);
	dlgFile.m_ofn.lpstrTitle = "Load Battle File";
	dlgFile.m_ofn.nFilterIndex = 1;
	if (dlgFile.DoModal() != IDOK) return;
	CString strFile(dlgFile.GetPathName());
	pDoc->OnOpenDocument((char *)strFile.GetBuffer(0));
	m_pUnit = pDoc->m_pUnit;
	m_pAttList = pDoc->m_pAttList;
	m_pDefList = pDoc->m_pDefList;
	m_pAttBld = pDoc->m_pAttBld;
	m_pDefBld = pDoc->m_pDefBld;
	pDoc->GetItemsAndObjects(m_iNumber, m_bRunes, m_strBldName, m_iMonths, m_iDays,
		m_iSkill, m_iItem, m_iBld, m_iTerrain, m_bBattleItems, m_bCombatSkills,
		m_bMagicSkills, m_bMen, m_bMonsters, m_bNormal, m_bOtherItems, m_bCanLearn,
		m_bCombatMagic, m_bArmour, m_bMounts, m_bWeapons);
	UpdateData(FALSE);
	RenumberAtt();
	RenumberDef();
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	SetItemList();
	SetBuildingList();
	SetTerrainList();
	CUtils::UpdateList(m_lstAtt, m_pAttBld, m_pAttList);
	CUtils::UpdateList(m_lstDef, m_pDefBld, m_pDefList);
}

void CMainForm::OnFileSaveAs() 
{
	GET_DOC_OR_RETURN;
	CFileDialog dlgFile(FALSE, "btl", NULL,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilters, this);
	dlgFile.m_ofn.lpstrTitle = "Save Battle File";
	dlgFile.m_ofn.nFilterIndex = 1;
	if (dlgFile.DoModal() != IDOK) return;
	CString strFile(dlgFile.GetPathName());
	UpdateData(TRUE);
	pDoc->SetItemsAndObjects(m_iNumber, m_bRunes, m_strBldName, m_iMonths, m_iDays,
		m_iSkill, m_iItem, m_iBld, m_iTerrain, m_bBattleItems, m_bCombatSkills,
		m_bMagicSkills, m_bMen, m_bMonsters, m_bNormal, m_bOtherItems, m_bCanLearn,
		m_bCombatMagic, m_bArmour, m_bMounts, m_bWeapons);
	pDoc->OnSaveDocument((char *)strFile.GetBuffer(0));
}

void CMainForm::SynchDoc()
{
	GET_DOC_OR_RETURN;
	UpdateData(TRUE);
	pDoc->SetItemsAndObjects(m_iNumber, m_bRunes, m_strBldName, m_iMonths, m_iDays,
		m_iSkill, m_iItem, m_iBld, m_iTerrain, m_bBattleItems, m_bCombatSkills,
		m_bMagicSkills, m_bMen, m_bMonsters, m_bNormal, m_bOtherItems, m_bCanLearn,
		m_bCombatMagic, m_bArmour, m_bMounts, m_bWeapons);
}

void CMainForm::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);
}

void CMainForm::OnUpdateAttackers(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	if (m_pAttList != NULL)
		if (m_pAttList->Num() > 0) bEn = TRUE;
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateAttackerSelected(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstAtt);
	if (pUnit != NULL) bEn = TRUE;	
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateAttackerOrBldSelected(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	ADynListElem *pObj = CUtils::GetSelectedObject(m_lstAtt);
	if (pObj != NULL) bEn = TRUE;	
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateDefenders(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	if (m_pDefList != NULL)
		if (m_pDefList->Num() > 0) bEn = TRUE;
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateDefenderSelected(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	Unit *pUnit = CUtils::GetSelectedUnit(m_lstDef);
	if (pUnit != NULL) bEn = TRUE;	
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateDefenderOrBldSelected(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	ADynListElem *pObj = CUtils::GetSelectedObject(m_lstDef);
	if (pObj != NULL) bEn = TRUE;	
	pCmdUI->Enable(bEn);
}

void CMainForm::OnUpdateUnitExists(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	if (m_pUnit != NULL)
		if (m_pUnit->IsAlive()) bEn = TRUE;
	pCmdUI->Enable(bEn);
}

void CMainForm::OnClose() 
{
	SynchDoc();
	CFormView::OnClose();
}

void CMainForm::OnDestroy() 
{
	SynchDoc();
	CFormView::OnDestroy();
}

void CMainForm::OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView) 
{
	if (bActivate == FALSE) SynchDoc();
	CFormView::OnActivateView(bActivate, pActivateView, pDeactiveView);
}

static const char szFilters3[] = "Unit Files (*.unt)|*.unt|Text Files (*.txt)|*.txt|Data Files (*.dat)|*.dat|All Files (*.*)|*.*|";

void CMainForm::OnBtnLoadunit() 
{
	GET_DOC_OR_RETURN;
	CFileDialog dlgFile(TRUE, "unt", NULL,
		OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY, szFilters3, this);
	dlgFile.m_ofn.lpstrTitle = "Load Unit";
	dlgFile.m_ofn.nFilterIndex = 1;
	if (dlgFile.DoModal() != IDOK) return;
	CString strFile(dlgFile.GetPathName());
	pDoc->LoadUnit((char *)strFile.GetBuffer(0));
	m_pUnit = pDoc->m_pUnit;
	UpdateData(FALSE);
	StartUpdate();
	SetSkillList();
	SetSpellList();
	SetDescription();
	SetEdits();
	EndUpdate();
}

void CMainForm::OnBtnSaveunit() 
{
	GET_DOC_OR_RETURN;
	CFileDialog dlgFile(FALSE, "unt", NULL,
		OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilters3, this);
	dlgFile.m_ofn.lpstrTitle = "Save Unit File";
	dlgFile.m_ofn.nFilterIndex = 1;
	if (dlgFile.DoModal() != IDOK) return;
	CString strFile(dlgFile.GetPathName());
	UpdateData(TRUE);
	pDoc->SaveUnit((char *)strFile.GetBuffer(0));
	
}
