// UnitListView.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "UnitListView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUnitListView

IMPLEMENT_DYNCREATE(CUnitListView, CListView)

CUnitListView::CUnitListView()
{
}

CUnitListView::~CUnitListView()
{
}


BEGIN_MESSAGE_MAP(CUnitListView, CListView)
	//{{AFX_MSG_MAP(CUnitListView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUnitListView drawing

void CUnitListView::OnDraw(CDC* pDC)
{
	//CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CUnitListView diagnostics

#ifdef _DEBUG
void CUnitListView::AssertValid() const
{
	CListView::AssertValid();
}

void CUnitListView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUnitListView message handlers
