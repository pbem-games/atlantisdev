// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#ifndef UNIT_CLASS
#define UNIT_CLASS

class Unit;

#include "alist.h"
#include "gameio.h"
#include "fileio.h"
#include "skills.h"
#include "items.h"

class Object;

enum {
  U_NORMAL,
  U_MAGE,
  U_GUARD,
  U_WMON,
  NUMITTYPES
};

#define FLAG_BEHIND 1
#define FLAG_AUTOTAX 4
#define FLAG_HOLDING 8
#define FLAG_NOAID 16
#define FLAG_INVIS 32
#define FLAG_CONSUMING_UNIT 64
#define FLAG_CONSUMING_FACTION 128

class UnitPtr : public AListElem {
public:
  Unit * ptr;
};

UnitPtr *GetUnitList(AList *, Unit *);

class Unit : public ADynListElem
{
public:
    Unit();
    Unit(int);
	Unit(const Unit &oUnit); // Copy Constructor
    ~Unit();
	
	Unit& operator= (const Unit &oUnit);
	void Copy(const Unit &oUnit);
	void Clear();

    void Writeout( Aoutfile *f );
    void Readin( Ainfile *f );
	void WriteReport( Aoutfile *f );

    void WriteReport(Areport *);
    AString MageReport();
    AString * BattleReport();

    void SetName(AString *);
    void SetDescribe(AString *);
	void SetId(int);

	char *GetName() { return AString::GetStr(name); };
	char *GetBasename() { return AString::GetStr(basename); };
	char *GetDescribe() { return AString::GetStr(describe); };
    
    int IsLeader();
    int IsNormal();
    int GetMons();
    int GetMen();
    int GetSoldiers();
    int GetMen(int);
    void SetMen(int,int);
    int GetMoney();
    void SetMoney(int);
    int IsAlive();

    int GetStealth();
	int GetStealthBonus();
    int GetTactics();
    int GetObservation();
	int GetObservationBonus();
    int GetEntertainment();
    int GetAttackRiding();
    int GetDefenseRiding();

	void Error(AString &string);
	void Event(AString &string);
	void Error(char *string) { Error(AString(string)); };
	void Event(char *string) { Event(AString(string)); };

    int GetSkill(int);
    void SetSkill(int,int);
    void SetSkillDays(int,int);
    int GetRealSkill(int);
    void ForgetSkill(int);
    int CheckDepend(int,int,int);
    int CanStudy(int);
    int Study(int,int); /* Returns 1 if it succeeds */
    void AdjustSkills();
	void MoveUnit(Object *);

	void StudyOrder(int,int);
	void CombatOrder(int sk);
	

    int Hostile();
    int Weight();
    int CanFly(int);
    int CanFly();
    int CanRide(int);
    int CanWalk(int);
    int CanSwim();
    int MoveType();
    int GetFlag(int);
    void SetFlag(int,int);
    void CopyFlags(Unit *);
	int GetBattleItem( int batType, int index );
	int CanUseWeapon(WeaponType *pWep, int riding);
	int CanUseWeapon(WeaponType *pWep);
    
    Object * object;
    AString * name;
    AString * describe;
	AString * basename;
    int num;
    int type;
    int flags;
    int movepoints;
    int canattack;
    int nomove;
    SkillList skills;
    ItemList items;
    int combat;
    int losses;
    
};


class UnitList : public AList
{
public:
    void Readin(Ainfile *);
    void Writeout(Aoutfile *);
	int Renumber(int );
};

#endif
