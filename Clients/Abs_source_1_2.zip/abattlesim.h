// abattlesim.h : main header file for the ABATTLESIM application
//

#if !defined(AFX_ABATTLESIM_H__189B5049_1B70_11D4_9E26_0008C7C6E4AD__INCLUDED_)
#define AFX_ABATTLESIM_H__189B5049_1B70_11D4_9E26_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CAbattlesimApp:
// See abattlesim.cpp for the implementation of this class
//

class CAbattlesimApp : public CWinApp
{
public:
	CAbattlesimApp();
	virtual ~CAbattlesimApp();

public:
	LPTSTR m_szAppFilename; // Contains the full path to the application, and the exe name.
	LPTSTR m_szAppPath; // Contains the full path to the application

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAbattlesimApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
public:
	void ChangeView(int iView, int iData = 1);

	//{{AFX_MSG(CAbattlesimApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.
extern CAbattlesimApp theApp;

#endif // !defined(AFX_ABATTLESIM_H__189B5049_1B70_11D4_9E26_0008C7C6E4AD__INCLUDED_)
