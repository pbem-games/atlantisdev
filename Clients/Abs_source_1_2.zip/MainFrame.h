#if !defined(AFX_MainFrame_H__013D56B5_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
#define AFX_MainFrame_H__013D56B5_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainFrame.h : header file
//

class CMainDoc;
class CMainForm;
class CBattleReport;
class CSplitterWndEx;

/////////////////////////////////////////////////////////////////////////////
// CMainFrame frame

class CMainFrame : public CFrameWnd
{
	DECLARE_DYNCREATE(CMainFrame)
protected:
	CMainFrame();           // protected constructor used by dynamic creation

protected:  // control bar embedded members
	//CStatusBar  m_wndStatusBar;
	//CToolBar    m_wndToolBar;
	CMainForm *m_pMainForm;
	CBattleReport *m_pBattleReport;
	CSplitterWndEx *m_pwndSplitter;
	CRect m_lMainFormRect;
	
// Attributes
	//CCreateContext m_Context;
	bool m_bUpdating;
	int m_iCurrentView;

// Operations
public:
	//void SetStatusText(CString strText);
	void StartUpdate();
	void EndUpdate();
	CMainDoc *GetDocument();
	//CDocTemplate *GetDocTemplate();
	//CTurnTreeView *GetTreeView();
	//CUnitListView *GetListView();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual BOOL RedrawWindow( LPCRECT lpRectUpdate = NULL, CRgn* prgnUpdate = NULL, UINT flags = RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE );
	virtual void UpdateWindow();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CMainFrame();

	CRuntimeClass *GetViewClass(int iView);
	int GetViewType();
	int GetViewType(CRuntimeClass *pClass);
	void ChangeView(int iView, int iData);
	void SetCreateContext(CCreateContext *pContext, int iView);
	BOOL CreateNewView(CCreateContext *pContext);
	bool CreateMainFormView(CCreateContext *pContext);
	bool CreateBattleReport(CCreateContext *pContext);
	bool CreateSplitterView(CCreateContext *pContext);

	// Generated message map functions
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnClose();
	afx_msg void OnAppAbout();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	afx_msg LRESULT OnChangeView(WPARAM wParam, LPARAM lParam);
	afx_msg void OnUpdateBattleUpdatearmies(CCmdUI* pCmdUI);
	afx_msg void OnBattleUpdatearmies();
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

inline CMainDoc *CMainFrame::GetDocument()
	{	return (CMainDoc *)GetActiveDocument(); }
/*inline CTurnTreeView *CMainFrame::GetTreeView()
	{	return (CTurnTreeView *)m_wndSplitter.GetPane(0, 0); }
inline CUnitListView *CMainFrame::GetListView()
	{	return (CUnitListView *)m_wndSplitter.GetPane(0, 1); }
*/
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MainFrame_H__013D56B5_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
