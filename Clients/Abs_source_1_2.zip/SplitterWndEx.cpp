// SplitterWndEx.cpp: implementation of the CSplitterWndEx class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "abattlesim.h"
#include "SplitterWndEx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSplitterWndEx::CSplitterWndEx() : CSplitterWnd()
{
	m_bUpdating = false;
}

CSplitterWndEx::~CSplitterWndEx()
{	for (int iRow = 0; iRow < m_nMaxRows; iRow++)
	{	for (int iCol = 0; iCol < m_nMaxCols; iCol++)
		{	DeleteView(iRow, iCol);
		}
	}
}

void CSplitterWndEx::OnDrawSplitter( CDC* pDC, ESplitType nType, const CRect& rect )
{	if (m_bUpdating) return;
	CSplitterWnd::OnDrawSplitter(pDC, nType, rect);
}

void CSplitterWndEx::StartUpdate()
{	m_bUpdating = true;
	LockWindowUpdate();
}

void CSplitterWndEx::EndUpdate()
{	m_bUpdating = false;
	Invalidate();
	UnlockWindowUpdate();
}

BOOL CSplitterWndEx::RedrawWindow( LPCRECT lpRectUpdate, CRgn* prgnUpdate, UINT flags)
{
	if (m_bUpdating) return FALSE;
	return CWnd::RedrawWindow(lpRectUpdate, prgnUpdate, flags); 
}

void CSplitterWndEx::UpdateWindow()
{
	if (m_bUpdating) return;
	CWnd::UpdateWindow();
}