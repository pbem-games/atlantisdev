//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by abattlesim.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ABATTLESIM_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_HEXES                       136
#define IDD_BATTLE_VIEW                 139
#define IDC_BTN_STUDY                   1002
#define IDC_BTN_FORGET                  1003
#define IDC_CB_SKILLS                   1005
#define IDC_CB_MONTHS                   1006
#define IDC_CB_ITEMS                    1007
#define IDC_BTN_ADD                     1008
#define IDC_BTN_REMOVE                  1009
#define IDC_CB_SPELLS                   1011
#define IDC_SPIN1                       1012
#define IDC_ED_NUMBER                   1013
#define IDC_CB_TERRAIN                  1014
#define IDC_CB_BUILDING                 1016
#define IDC_LIST_UNIT                   1022
#define IDC_LIST_ATT                    1023
#define IDC_LIST_DEF                    1026
#define ID_RUN_BATTLE                   1028
#define IDC_ED_NAME                     1030
#define IDC_CHK_BEHIND                  1036
#define IDC_CHK_RUNES                   1042
#define IDC_EDBLD_NAME                  1043
#define IDC_CHK_MEN                     1046
#define IDC_CHK_MONSTERS                1047
#define IDC_CHK_BATTLE_ITEMS            1048
#define IDC_CHK_OTHER_ITEMS             1049
#define IDC_CHK_COMBAT_SKILLS           1050
#define IDC_CHK_NORMAL_SKILLS           1051
#define IDC_CHK_MAGIC_SKILLS            1052
#define IDC_CHK_WEAPONS                 1053
#define IDC_CHK_ARMOUR                  1054
#define IDC_CHK_MOUNTS                  1055
#define IDC_CHK_CAN_LEARN_SKILLS        1056
#define IDC_CHK_COMBAT_MAGIC_SKILLS     1058
#define IDC_LIST_B                      1062
#define IDC_BTN_LOADUNIT                1065
#define IDC_BTN_SAVEUNIT                1066
#define ID_BATTLE_RUNBATTLE             32772
#define ID_FILE_LOADUNITS               32773
#define ID_BATTLE_CLOSERESULTS          32774
#define ID_BATTLE_UPDATEARMIES          32775
#define ID_UNIT_ADDTOATTACKERS          32776
#define ID_UNIT_ADDTODEFENDERS          32777
#define ID_UNIT_CLEARUNIT               32778
#define ID_ATTACKERS_CLEAR              32779
#define ID_DEFENDERS_CLEAR              32780
#define ID_ATTACKERS_ADDUNITTOATTACKERS 32781
#define ID_DEFENDERS_ADDUNITTODEFENDERS 32782
#define ID_DESIGN_GIVEBUILDINGTOATTACKERS 32783
#define ID_DESIGN_DEFENDERSBUILDING     32784
#define ID_DESIGN_ATTACKERSBUILDING     32785
#define ID_DESIGN_CLEARUNIT             32786
#define ID_DESIGN_ADDUNITTODEFENDERS    32787
#define ID_DESIGN_ADDUNITTOATTACKERS    32788
#define ID_ATTACKERS_COPYTODESIGN       32789
#define ID_ATTACKERS_MOVETODESIGN       32790
#define ID_ATTACKERS_DELETE             32791
#define ID_DEFENDERS_COPYTODESIGN       32792
#define ID_DEFENDERS_MOVETODESIGN       32793
#define ID_DEFENDERS_DELETE             32794

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
