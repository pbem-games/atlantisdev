// Utils.cpp: implementation of the CUtils class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "abattlesim.h"
#include "Utils.h"
#include "alist.h"
#include "unit.h"
#include "object.h"
#include "aregion.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
void CUtils::AddUnitToList(CListBox &oListBox, Unit *pUnit, bool bTab)
{
	if (pUnit == NULL) return;
	Areport *report = new Areport();
	if (bTab) report->AddTab();
	pUnit->WriteReport(report);
	if (bTab) report->DropTab();
	AddReportToList(oListBox, report, (void *)pUnit);
	delete report;
}

//////////////////////////////////////////////////////////////////////
void CUtils::AddObjectToList(CListBox &oListBox, Object *pObj)
{
	if (pObj == NULL) return;
	Areport *report = new Areport();
	pObj->WriteReport(report);
	AddReportToList(oListBox, report, (void *)pObj);
	delete report;
	Unit *u;
	forlist(&(pObj->units))
	{	u = (Unit  *) elem;
		AddUnitToList(oListBox, u, true);
	}
}

//////////////////////////////////////////////////////////////////////
void CUtils::AddReportToList(CListBox &oListBox, Areport *pReport, void *pObj)
{	char *start = pReport->text;
	char *end = start;
	char c;
	bool b = false;
	int iItem;
	while (c = *end)
	{	if (!isspace(c)) b = true;
		if ((c == '\r') || (c == '\n'))
		{	if (end>start)
			{	*end = 0;
				iItem = oListBox.AddString(start);
				if ((pObj != NULL) && b) oListBox.SetItemDataPtr(iItem, (void *)pObj);
				*end = c;
				b = false;
			}
			else oListBox.AddString("");
			start = ++end;
		}
		else end++;
	}
	if (end>start)
	{	iItem = oListBox.AddString(start);
		if ((pObj != NULL) && b) oListBox.SetItemDataPtr(iItem, (void *)pObj);
	}
}

//////////////////////////////////////////////////////////////////////
void CUtils::UpdateList(CListBox &oListBox, ObjectList *pBld, UnitList *pList)
{
	oListBox.ResetContent();
	bool b = false;
	{	Unit *u;
		forlist(pList)
		{	u = (Unit  *) elem;
			CUtils::AddUnitToList(oListBox, u);
			b = true;
		}
	}
	{	Object *obj;
		forlist(pBld)
		{	obj = (Object  *) elem;
			if (b) oListBox.AddString("");
			else b = true;
			CUtils::AddObjectToList(oListBox, obj);
		}
	}
}

//////////////////////////////////////////////////////////////////////
ADynListElem *CUtils::GetSelectedObject(CListBox &oListBox) 
{
	ADynListElem *pElem = NULL;
	int iIndex = oListBox.GetCurSel();
	if (iIndex >= 0) pElem = (ADynListElem *)oListBox.GetItemDataPtr(iIndex);
	return pElem;
}

//////////////////////////////////////////////////////////////////////
Unit *CUtils::GetSelectedUnit(CListBox &oListBox) 
{
	ADynListElem *pElem = NULL;
	int iIndex = oListBox.GetCurSel();
	if (iIndex >= 0) pElem = (ADynListElem *)oListBox.GetItemDataPtr(iIndex);
	if (pElem == NULL) return NULL;
	if (pElem->elem_type != eunit) return NULL;
	return (Unit *)pElem;
}

//////////////////////////////////////////////////////////////////////
Object *CUtils::GetSelectedBuilding(CListBox &oListBox) 
{
	ADynListElem *pElem = NULL;
	int iIndex = oListBox.GetCurSel();
	if (iIndex >= 0) pElem = (ADynListElem *)oListBox.GetItemDataPtr(iIndex);
	if (pElem == NULL) return NULL;
	if (pElem->elem_type != eobject) return NULL;
	return (Object *)pElem;
}

//////////////////////////////////////////////////////////////////////
void CUtils::AddUnitListToList(CListBox &oListBox, UnitList *pUnitList, CString strTitle)
{
	bool b = false;
	oListBox.AddString("");
	oListBox.AddString(strTitle);
	Unit *pUnit;
	forlist(pUnitList)
	{	pUnit = (Unit *)elem;
		if (pUnit != NULL)
		{	if (pUnit->IsAlive())
			{	AddUnitToList(oListBox, pUnit);
				b = true;
			}
		}
	}
	if (!b) oListBox.AddString("None");
}