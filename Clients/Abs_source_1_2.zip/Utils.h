// Utils.h: interface for the Utils class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UTILS_H__BB10BB3F_8A23_11D4_9E21_0008C7C6E4AD__INCLUDED_)
#define AFX_UTILS_H__BB10BB3F_8A23_11D4_9E21_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ADynListElem;
class Unit;
class UnitList;
class Aoutfile;
class Areport;
class Object;
class ObjectList;

class CUtils  
{
public:
	static void AddUnitToList(CListBox &oListBox, Unit * pUnit, bool bTab = false);
	static void AddObjectToList(CListBox &oListBox, Object *pObj);
	static void AddReportToList(CListBox &oListBox, Areport *pReport, void *pObj = NULL);
	static void AddUnitListToList(CListBox &oListBox, UnitList *pUnitList, CString strTitle);
	static void UpdateList(CListBox &oListBox, ObjectList *pBld, UnitList *pList);
	static ADynListElem *GetSelectedObject(CListBox &oListBox);
	static Object *GetSelectedBuilding(CListBox &oListBox);
	static Unit *GetSelectedUnit(CListBox &oListBox);
};

#endif // !defined(AFX_UTILS_H__BB10BB3F_8A23_11D4_9E21_0008C7C6E4AD__INCLUDED_)
