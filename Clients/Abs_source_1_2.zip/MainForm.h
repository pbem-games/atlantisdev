#if !defined(AFX_MAINFORM_H__013D56C3_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
#define AFX_MAINFORM_H__013D56C3_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMainForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CMainDoc;
class Unit;
class UnitList;
class ObjectList;

class CMainForm : public CFormView
{
protected:
	CMainForm();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMainForm)

// Form Data
public:
	//{{AFX_DATA(CMainForm)
	enum { IDD = IDD_ABATTLESIM_DIALOG };
	CButton	m_chkRunes;
	CListBox	m_lstDef;
	CListBox	m_lstAtt;
	CListBox	m_lstUnit;
	CComboBox	m_cbTerrain;
	CComboBox	m_cbBuilding;
	CEdit	m_edNumber;
	CComboBox	m_cbSpells;
	CComboBox	m_cbItems;
	CComboBox	m_cbMonths;
	CComboBox	m_cbSkills;
	int		m_iNumber;
	CString	m_strUnitDesc;
	CString	m_strName;
	BOOL	m_bBehind;
	BOOL	m_bRunes;
	CString	m_strBldName;
	int		m_iMonths;
	BOOL	m_bBattleItems;
	BOOL	m_bCombatSkills;
	BOOL	m_bMagicSkills;
	BOOL	m_bMen;
	BOOL	m_bMonsters;
	BOOL	m_bNormal;
	BOOL	m_bOtherItems;
	BOOL	m_bCanLearn;
	BOOL	m_bCombatMagic;
	BOOL	m_bArmour;
	BOOL	m_bMounts;
	BOOL	m_bWeapons;
	//}}AFX_DATA

// Attributes
protected:
	bool m_bUpdating;

	Unit *m_pUnit;
	UnitList *m_pAttList;
	UnitList *m_pDefList;
	ObjectList *m_pAttBld;
	ObjectList *m_pDefBld;
	int m_iSkill, m_iDays, m_iItem, m_iTerrain, m_iBld;//, m_iShow, m_iShowItems,
		//m_iNumber;

// Operations
public:
	CMainDoc *GetDoc() { return (CMainDoc *)GetDocument(); };
	void StartUpdate();
	void EndUpdate();
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainForm)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual BOOL RedrawWindow( LPCRECT lpRectUpdate = NULL, CRgn* prgnUpdate = NULL, UINT flags = RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE );
	virtual void UpdateWindow();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SetDescription();
	void SetEdits();
	void SetSkillList();
	void SetItemList();
	void SetSpellList();
	void SetTerrainList();
	void SetBuildingList();
	bool CheckFlags(int iFlags, int iCanStudy);
	bool CheckItemType(int iType);
	void RenumberAtt();
	void RenumberDef();
	void SynchDoc();

	virtual ~CMainForm();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CMainForm)
	afx_msg void OnBtnStudy();
	afx_msg void OnSelchangeCbSkills();
	afx_msg void OnSelchangeCbMonths();
	afx_msg void OnSelchangeCbItems();
	afx_msg void OnBtnAdd();
	afx_msg void OnSelchangeCbSpells();
	afx_msg void OnChangeEdNumber();
	afx_msg void OnBtnRemove();
	afx_msg void OnBtnForget();
	afx_msg void OnSelchangeCbBuilding();
	afx_msg void OnSelchangeCbTerrain();
	afx_msg void OnBtnAttUnit();
	afx_msg void OnBtnDefUnit();
	afx_msg void OnBtnClear();
	afx_msg void OnBtnAttRemove();
	afx_msg void OnBtnDefRemove();
	afx_msg void OnBtnCopyAtt();
	afx_msg void OnBtnCopyDef();
	afx_msg void OnChkBehind();
	afx_msg void OnBtnDelAtt();
	afx_msg void OnBtnDelDef();
	afx_msg void OnBtnAttBld();
	afx_msg void OnBtnDefBld();
	afx_msg void OnChangeEdbldName();
	afx_msg void OnChangeEdName();
	afx_msg void OnChkShowItems();
	afx_msg void OnChkShowSkills();
	afx_msg void OnChkRunes();
	afx_msg void OnBtnClearAtt();
	afx_msg void OnBtnClearDef();
	afx_msg void OnBtnLoadReport();
	afx_msg void OnRunBattle();
	afx_msg void OnAppExit();
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnFileOpen();
	afx_msg void OnFileSaveAs();
	afx_msg void OnUpdateRunBattle(CCmdUI* pCmdUI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnUpdateAttackers(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAttackerSelected(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAttackerOrBldSelected(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDefenders(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDefenderSelected(CCmdUI* pCmdUI);
	afx_msg void OnUpdateDefenderOrBldSelected(CCmdUI* pCmdUI);
	afx_msg void OnUpdateUnitExists(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnBtnLoadunit();
	afx_msg void OnBtnSaveunit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFORM_H__013D56C3_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
