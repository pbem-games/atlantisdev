// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#ifndef REGION_CLASS
#define REGION_CLASS

#include "alist.h"
#include "astring.h"

class ARegion : public AListElem
{
public:
    ARegion();
	ARegion(char *szname, int regtype, int x, int y, int z);
    ~ARegion();
	void SetName(char *);

	AString * name;
    int type;
	int xloc,yloc,zloc;
	AList objects;
};

class TerrainType
{
public:
    char * name;

    enum {
        RIDINGMOUNTS = 0x1,
        FLYINGMOUNTS = 0x2,
    };
    int flags;

    int pop;
    int wages;
    int economy;
    int movepoints;
    int prod1;
    int chance1;
    int amt1;
    int prod2;
    int chance2;
    int amt2;
    int prod3;
    int chance3;
    int amt3;
    int prod4;
    int chance4;
    int amt4;
    int prod5;
    int chance5;
    int amt5;
    int race1;
    int race2;
    int race3;
    int coastalrace1;
    int coastalrace2;
    int wmonfreq;
    int smallmon;
    int bigmon;
    int humanoid;
    int lairChance;
    int lair1;
    int lair2;
    int lair3;
    int lair4;
};

extern TerrainType * TerrainDefs;

class Unit;
class Object;

class Location : public AListElem
{
public:
    Unit * unit;
    Object * obj;
    ARegion * region;
};

#endif

