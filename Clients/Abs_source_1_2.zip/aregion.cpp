// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#include "aregion.h"
#include "unit.h"
#include "object.h"

ARegion::ARegion()
{
	name = 0;
	type = 0;
	xloc = 0;
	yloc = 0;
	zloc = 0;
	Object * obj = new Object(); // Make the dummy object
	objects.Add(obj);
}


ARegion::ARegion(char *szname, int regtype, int x, int y, int z)
{
	name = new AString(szname);
	type = regtype;
	xloc = x;
	yloc = y;
	zloc = z;
	Object * obj = new Object(); // Make the dummy object
	objects.Add(obj);
}

ARegion::~ARegion()
{	if (name)
	{	delete name;
		name = 0;
	}	
}

void ARegion::SetName(char * c)
{
	if (name) delete name;
	name = new AString(c);
}
