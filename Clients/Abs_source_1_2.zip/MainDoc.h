#if !defined(AFX_MainDoc_H__013D56B4_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
#define AFX_MainDoc_H__013D56B4_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MainDoc.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// class declarations

class ADynListElem;
class Unit;
class UnitList;
class Aoutfile;
class Areport;
class AList;
class Object;
class ObjectList;

typedef enum eView { viewNone = 0, viewMainForm, viewReport, viewSplitter, viewMax };

#define GET_DOC CMainDoc *pDoc = (CMainDoc *)GetDocument();
#define IF_GET_DOC(code) CMainDoc *pDoc = (CMainDoc *)GetDocument(); if (pDoc != NULL) { code; };
#define GET_DOC_OR_RETURN CMainDoc *pDoc = (CMainDoc *)GetDocument(); if (pDoc == NULL) return;

/////////////////////////////////////////////////////////////////////////////
// CMainDoc document

class CMainDoc : public CDocument
{
protected:
	CMainDoc();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CMainDoc)

protected:
	char *m_pszReport;

// Attributes
public:
	Unit *m_pUnit;
	UnitList *m_pAttList;
	UnitList *m_pDefList;
	ObjectList *m_pAttBld;
	ObjectList *m_pDefBld;
	UnitList *m_pAtts;
	UnitList *m_pDefs;
	Areport *m_pBattleReport;
	AList *m_pRegionList;
	
	int m_iSkill, m_iDays, m_iMonths, m_iItem, m_iBld, m_iShow, m_iShowItems, m_iTerrain,
		m_iNumber;
	CString	m_strBldName;
	bool m_bCreated, m_bLoaded, m_bRunes; /*, m_bBattleItems, m_bCombatSkills, m_bMagicSkills,
		m_bMen, m_bMonsters, m_bNormal, m_bOtherItems, m_bCanLearn, m_bCombatMagic,
		m_bArmour, m_bMounts, m_bWeapons;*/

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainDoc)
	public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void OnChangedViewList();
	protected:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainDoc();

	virtual BOOL OnLoadReport(LPCTSTR lpszPathName);

	void CreateArmies();
	void DestroyArmies();
	void DestroyReport();
	bool ReadIn(const char *szFilename);
	bool WriteOut(const char *szFilename);
	bool LoadUnit(const char *szFilename);
	bool SaveUnit(const char *szFilename);

	void GetItemsAndObjects(int &iNumber, BOOL &bRunes, CString &strBldName,
		int &iMonths, int &iDays, int &iSkill, int &iItem, int &iBld, int &iTerrain,
		BOOL &bBattleItems, BOOL &bCombatSkills, BOOL &bMagicSkills, BOOL &bMen, BOOL &bMonsters,
		BOOL &bNormal, BOOL &bOtherItems, BOOL &bCanLearn, BOOL &bCombatMagic, BOOL &bArmour,
		BOOL &bMounts, BOOL &bWeapons);
	void SetItemsAndObjects(int iNumber, BOOL bRunes, CString strBldName,
		int iMonths, int iDays,	int iSkill, int iItem, int iBld, int iTerrain,
		BOOL bBattleItems, BOOL bCombatSkills, BOOL bMagicSkills, BOOL bMen, BOOL bMonsters,
		BOOL bNormal, BOOL bOtherItems, BOOL bCanLearn,	BOOL bCombatMagic, BOOL bArmour,
		BOOL bMounts, BOOL bWeapons);

	void RenumberAtt();
	void RenumberDef();

	BOOL CanRunBattle();
	void RunBattle();
	BOOL CanGetSurvivors();
	void GetSurvivors();
	BOOL CanWriteBattleReport();
	void WriteBattleReport();
	char *GetBattleReportText();

protected:
	bool ExtractReportData(char *pszData, long lSize);
	static int CheckTerrain(char *pszLine);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CMainDoc)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MainDoc_H__013D56B4_938C_11D4_9E22_0008C7C6E4AD__INCLUDED_)
