// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
//#include "game.h"
#include "battle.h"
#include "army.h"
#include "gamedefs.h"
#include "rules.h"
#include "aregion.h"

Battle::Battle()
{
    asstext = 0;
}

Battle::~Battle()
{
    if (asstext)
    {
        delete asstext;
    }
}

void Battle::FreeRound(Army * att,Army * def)
{
    /* Write header */
    AddLine(*(att->leader->name) + " gets a free round of attacks.");
    
    /* Update both army's shields */
    att->shields.DeleteAll();
    UpdateShields(att);
    
    def->shields.DeleteAll();
    UpdateShields(def);

    //
    // Update the attacking armies round counter
    //
    att->round++;

    /* Run attacks until done */
    int alv = def->NumAlive();
    while (att->CanAttack() && def->NumAlive())
    {
        int num = getrandom(att->CanAttack());
        int behind;
        Soldier * a = att->GetAttacker(num, behind);
        DoAttack(att->round, a, att, def, behind);
    }
    
    /* Write losses */
    alv -= def->NumAlive();
    AddLine(*(def->leader->name) + " loses " + alv + ".");
    AddLine("");
    att->Reset();
}

void Battle::DoAttack( int round, 
                       Soldier *a,
                       Army *attackers,
                       Army *def, 
                       int behind )
{
    DoSpecialAttack( round, a, attackers, def, behind );
    if (!def->NumAlive()) return;
    
    if (a->HasEffect(EFFECT_DAZZLE)) a->askill -= 2;
	#ifdef _CAMELS
	if (!behind && (a->riding == I_CAMEL))
		def->DoAnAttack(0, 1, ATTACK_RIDING, 3, SPECIAL_FLAGS, SPECIAL_CLASS, EFFECT_CAMEL_FEAR);
	#endif

    int numAttacks = a->attacks;
    if( a->attacks < 0 )
    {
        if( round % ( -1 * a->attacks ) == 1 )
        {
            numAttacks = 1;
        }
        else
        {
            numAttacks = 0;
        }
    }

	for (int i = 0; i < numAttacks; i++ )
    {
        WeaponType *pWep = 0;
        if( a->weapon != -1 )
        {
            pWep = &WeaponDefs[ ItemDefs[ a->weapon ].index ];
        }

        if( behind )
        {
            if( !pWep )
            {
                break;
            }

            if( !( pWep->flags & WeaponType::RANGED ))
            {
                break;
            }
        }

        int flags = 0;
		int attackType = ATTACK_COMBAT;
		int attackClass = AT_SLASHING;
		int mountBonus = 0;
        if( pWep ) {
			flags = pWep->flags;
			attackType = pWep->attackType;
			mountBonus = pWep->mountBonus;
			attackClass = pWep->weapClass;
		}
		def->DoAnAttack( 0, 1, attackType, a->askill, flags, attackClass, 0, mountBonus );
        if (!def->NumAlive()) break;
    }
    
    if (a->HasEffect(EFFECT_DAZZLE)) {
        a->ClearEffect(EFFECT_DAZZLE);
        a->askill += 2;
    }
}

void Battle::NormalRound(int round,Army * a,Army * b)
{
    /* Write round header */
    AddLine(AString("Round ") + round + ":");
    
    /* Update both army's shields */
    UpdateShields(a);
    UpdateShields(b);
	
    /* Initialize variables */
    a->round++;
    b->round++;
    int aalive = a->NumAlive();
    int aialive = aalive;
    int balive = b->NumAlive();
    int bialive = balive;
    int aatt = a->CanAttack();
    int batt = b->CanAttack();
	
    /* Run attacks until done */
    while (aalive && balive && (aatt || batt))
    {
        int num = getrandom(aatt + batt);
        int behind;
        if (num >= aatt)
        {
            num -= aatt;
            Soldier * s = b->GetAttacker(num, behind);
            DoAttack(b->round, s, b, a, behind);
        } 
        else
        {
            Soldier * s = a->GetAttacker(num, behind);
            DoAttack(a->round, s, a, b, behind);
        }
        aalive = a->NumAlive();
        balive = b->NumAlive();
        aatt = a->CanAttack();
        batt = b->CanAttack();
    }
    
    /* Finish round */
    aialive -= aalive;
    AddLine(*(a->leader->name) + " loses " + aialive + ".");
    bialive -= balive;
    AddLine(*(b->leader->name) + " loses " + bialive + ".");
    AddLine("");
    a->Reset();
    b->Reset();
}

void Battle::GetSpoils(AList * losers, ItemList *spoils) {
  forlist(losers) {
    Unit * u = ((Location *) elem)->unit;
    int numalive = u->GetSoldiers();
    int numdead = u->losses;
    forlist(&u->items) {
      Item * i = (Item *) elem;
      if (!IsSoldier(i->type)) {
	int num = (i->num * numdead + getrandom(numalive + numdead)) /
	  (numalive + numdead);
	int itype = i->type;
	int inum = i->num;
	u->items.SetNum(itype,inum - num);
	num = (num + getrandom(2)) / 2;
	spoils->SetNum(itype,spoils->GetNum(itype) + num);
      }
    }
  }
}

void Battle::Run( AList * atts,
                  AList * defs,
                  int ass)
{
	Unit * att = ((Location *) atts->First())->unit;
	Unit * tar = ((Location *) defs->First())->unit;
    int regiontype = ((Location *) atts->First())->region->type;

	Army * armies[2];
    assassination = ASS_NONE;

    armies[0] = new Army(att,atts,regiontype,ass);
    armies[1] = new Army(tar,defs,regiontype,ass);
  
    if (ass) {
        FreeRound(armies[0],armies[1]);
    } else {
        if (armies[0]->tac > armies[1]->tac) FreeRound(armies[0],armies[1]);
        if (armies[1]->tac > armies[0]->tac) FreeRound(armies[1],armies[0]);
    }
  
    int round = 1;
    while (!armies[0]->Broken() && !armies[1]->Broken() && round < 101) {
        NormalRound(round++,armies[0],armies[1]);
    }
  
    if ((armies[0]->Broken() && !armies[1]->Broken()) ||
        (!armies[0]->NumAlive() && armies[1]->NumAlive())) {
        if (ass) assassination = ASS_FAIL;
        AddLine(*(armies[0]->leader->name) + " is routed!");
        if (armies[0]->NumAlive())
            FreeRound(armies[1],armies[0]);
        AddLine("Total Casualties:");
        ItemList *spoils = new ItemList;
        armies[0]->Lose(this,spoils);
        GetSpoils(atts, spoils);
        AString temp;
        if (spoils->Num()) {
            temp = AString("Spoils: ") + spoils->Report(2,0,1) + ".";
        } else {
            temp = "No spoils.";
        }
        armies[1]->Win(this,spoils);
        AddLine("");
        AddLine(temp);
        AddLine("");
        delete spoils;
        delete armies[0];
        delete armies[1];
        return;
    }

    if ((armies[1]->Broken() && !armies[0]->Broken()) ||
        (!armies[1]->NumAlive() && armies[0]->NumAlive())) {
        if (ass) {
            assassination = ASS_SUCC;
            asstext = new AString(*(armies[1]->leader->name) +
                                  " is assassinated in Simulation!");
        }
        AddLine(*(armies[1]->leader->name) + " is routed!");
        if (armies[1]->NumAlive())
            FreeRound(armies[0],armies[1]);
        AddLine("Total Casualties:");
        ItemList *spoils = new ItemList;
        armies[1]->Lose(this,spoils);
        GetSpoils(defs,spoils);
        AString temp;
        if (spoils->Num()) {
            temp = AString("Spoils: ") + spoils->Report(2,0,1) + ".";
        } else {
            temp = "No spoils.";
        }
        armies[0]->Win(this,spoils);
        AddLine("");
        AddLine(temp);
        AddLine("");
        delete spoils;
        delete armies[0];
        delete armies[1];
        return;
    }
  
    AddLine("The battle ends indecisively.");
    AddLine("");
    AddLine("Total Casualties:");
    armies[0]->Tie(this);
    armies[1]->Tie(this);
    AddLine("");
    delete armies[0];
    delete armies[1];
    return;
}

void Battle::WriteSides(AList * atts,
                        AList * defs,
                        int ass)
{
  AString *attname = ((Location *) atts->First())->unit->name;
  AString *defname = ((Location *) defs->First())->unit->name;
  int ter = ((Location *) atts->First())->region->type;
  
  AString loc(TerrainDefs[ter].name);
 
  if (ass) {
    AddLine(*attname + " attempts to assassinate " + *defname + " in a " + loc + " region!");
  } else {
	AddLine(*attname + " attacks " + *defname + " in a " + loc + " region!");
  }
  AddLine("");
  AddLine("Attackers:");
  {	
    forlist(atts) {
      AString * temp = ((Location *) elem)->unit->BattleReport();
      AddLine(*temp);
      delete temp;
    }
  }
  AddLine("");
  AddLine("Defenders:");
  {	
    forlist(defs) {
      AString * temp = ((Location *) elem)->unit->BattleReport();
      AddLine(*temp);
      delete temp;
    }
  }
  AddLine("");
}

void Battle::Report(Areport * f) {
  if (assassination == ASS_SUCC) {
    f->PutStr(*asstext);
    f->PutStr("");
    return;
  }
  forlist(&text) {
    AString * s = (AString *) elem;
    f->PutStr(*s);
  }
}

void Battle::AddLine(const AString & s) {
  AString * temp = new AString(s);
  text.Add(temp);
}
