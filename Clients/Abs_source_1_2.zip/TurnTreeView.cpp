// TurnTreeView.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "TurnTreeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTurnTreeView

IMPLEMENT_DYNCREATE(CTurnTreeView, CTreeView)

CTurnTreeView::CTurnTreeView()
{
}

CTurnTreeView::~CTurnTreeView()
{
}


BEGIN_MESSAGE_MAP(CTurnTreeView, CTreeView)
	//{{AFX_MSG_MAP(CTurnTreeView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTurnTreeView drawing

void CTurnTreeView::OnDraw(CDC* pDC)
{
	//CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTurnTreeView diagnostics

#ifdef _DEBUG
void CTurnTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CTurnTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTurnTreeView message handlers
