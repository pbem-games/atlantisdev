// MainDoc.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "MainDoc.h"
#include "rules.h"
#include "aregion.h"
#include "unit.h"
#include "object.h"
#include "army.h"
#include "battle.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define VERSION ("Atlantis Battle Simulator v1.1")
#define UNITVERSION ("ABS Unit v1.1")

typedef enum eShowItems { siMen = 1, siMonsters = 2, siWeapons = 4, siArmour = 8, siMounts = 16, siBattleItems = 32, siOtherItems = 64 };
typedef enum eShowSkills { ssCombat = 1, ssNormal = 2, ssCombatMagic = 4, ssMagic = 8, ssCanStudy = 16 };

static const char szDefaultFilename[] = "abs.dat";
static const char szBattleFilename[] = "battle.txt";

/////////////////////////////////////////////////////////////////////////////
// CMainDoc

IMPLEMENT_DYNCREATE(CMainDoc, CDocument)

CMainDoc::CMainDoc()
{	
	m_bCreated = false;
	m_bLoaded = false;
	
	m_pszReport = NULL;
	m_pRegionList = NULL;

	m_iNumber = 1;
	m_bRunes = false;
	m_strBldName = _T("");
	m_iSkill = S_COMBAT;
	m_iDays = 30;
	m_iMonths = 0;
	m_iItem = I_LEADERS;
	m_iBld = O_TOWER;
	m_iTerrain = R_PLAIN;
	m_iShow = (ssCombat | ssCombatMagic | ssCanStudy);
	m_iShowItems = (siMen | siMonsters | siWeapons | siArmour | siMounts | siBattleItems);
	m_pUnit = NULL;
	m_pAttList = NULL;
	m_pDefList = NULL;
	m_pAttBld = NULL;
	m_pDefBld = NULL;
	m_pAtts = NULL;
	m_pDefs = NULL;
	m_pBattleReport = NULL;

}

CMainDoc::~CMainDoc()
{	DestroyArmies();
	DestroyReport();
}


BEGIN_MESSAGE_MAP(CMainDoc, CDocument)
	//{{AFX_MSG_MAP(CMainDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainDoc diagnostics

#ifdef _DEBUG
void CMainDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMainDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainDoc serialization

BOOL CMainDoc::OnNewDocument()
{
	//if (!CDocument::OnNewDocument()) return FALSE;
	DeleteContents();
	m_strPathName.Empty();
	SetModifiedFlag();
	CreateArmies();
	if (!m_bCreated) return FALSE;
	AString name(theApp.m_szAppPath);
	name += AString(szDefaultFilename);
	ReadIn(name.Str());
	SetModifiedFlag(FALSE);
	return TRUE;
}

BOOL CMainDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	//if (!CDocument::OnOpenDocument(lpszPathName)) return FALSE;
	DeleteContents();
	SetModifiedFlag();
	if (!ReadIn(lpszPathName)) return FALSE;
	SetModifiedFlag(FALSE);
	return TRUE;
}

BOOL CMainDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	if (!WriteOut((char *)lpszPathName)) return FALSE;
	SetModifiedFlag(FALSE);
	return TRUE;
	//return CDocument::OnSaveDocument(lpszPathName);
}

BOOL CMainDoc::OnLoadReport(LPCTSTR lpszPathName)
{
	FILE *pFile = fopen(lpszPathName, "rb");
	if (pFile == NULL) return FALSE;
	fseek(pFile, 0, SEEK_END);
	long lSize = ftell(pFile);
	fseek(pFile, 0, SEEK_SET);
	DestroyReport();
	m_pszReport = new char[lSize + 1];
	memset(m_pszReport, 0, lSize);
	fread(m_pszReport, sizeof(char), lSize, pFile);
	fclose(pFile);
	m_pszReport[lSize] = 0;
	if (!ExtractReportData(m_pszReport, lSize)) return FALSE;
	return TRUE;
}

void CMainDoc::GetItemsAndObjects(int &iNumber, BOOL &bRunes, CString &strBldName,
	int &iMonths, int &iDays, int &iSkill, int &iItem, int &iBld, int &iTerrain,
	BOOL &bBattleItems, BOOL &bCombatSkills, BOOL &bMagicSkills, BOOL &bMen, BOOL &bMonsters,
	BOOL &bNormal, BOOL &bOtherItems, BOOL &bCanLearn, BOOL &bCombatMagic, BOOL &bArmour,
	BOOL &bMounts, BOOL &bWeapons)
{	iNumber = m_iNumber;
	bRunes = (m_bRunes ? TRUE : FALSE);
	strBldName = m_strBldName;
	iMonths = m_iMonths;
	iDays = m_iDays;
	iSkill = m_iSkill;
	iItem = m_iItem;
	iBld = m_iBld;
	iTerrain = m_iTerrain;
	bMen = ((m_iShowItems & siMen) ? TRUE : FALSE);
	bMonsters = ((m_iShowItems & siMonsters) ? TRUE : FALSE);
	bWeapons = ((m_iShowItems & siWeapons) ? TRUE : FALSE);
	bArmour = ((m_iShowItems & siArmour) ? TRUE : FALSE);
	bMounts = ((m_iShowItems & siMounts) ? TRUE : FALSE);
	bBattleItems = ((m_iShowItems & siBattleItems) ? TRUE : FALSE);
	bOtherItems = ((m_iShowItems & siOtherItems) ? TRUE : FALSE);
	bCombatSkills = ((m_iShow & ssCombat) ? TRUE : FALSE);
	bMagicSkills = ((m_iShow & ssNormal) ? TRUE : FALSE);
	bCombatMagic = ((m_iShow & ssCombatMagic) ? TRUE : FALSE);
	bNormal = ((m_iShow & ssMagic) ? TRUE : FALSE);
	bCanLearn = ((m_iShow & ssCanStudy) ? TRUE : FALSE);
}

void CMainDoc::SetItemsAndObjects(int iNumber, BOOL bRunes, CString strBldName,
	int iMonths, int iDays,	int iSkill, int iItem, int iBld, int iTerrain,
	BOOL bBattleItems, BOOL bCombatSkills, BOOL bMagicSkills, BOOL bMen, BOOL bMonsters,
	BOOL bNormal, BOOL bOtherItems, BOOL bCanLearn,	BOOL bCombatMagic, BOOL bArmour,
	BOOL bMounts, BOOL bWeapons)
{	m_iNumber = iNumber;
	m_bRunes = (bRunes != FALSE);
	m_strBldName = strBldName;
	m_iMonths = iMonths;
	m_iDays = iDays;
	m_iSkill = iSkill;
	m_iItem = iItem;
	m_iBld = iBld;
	m_iTerrain = iTerrain;
	m_iShowItems = 0;
	if (bMen != FALSE) m_iShowItems |= siMen;
	if (bMonsters != FALSE) m_iShowItems |= siMonsters;
	if (bWeapons != FALSE) m_iShowItems |= siWeapons;
	if (bArmour != FALSE) m_iShowItems |= siArmour;
	if (bMounts != FALSE) m_iShowItems |= siMounts;
	if (bBattleItems != FALSE) m_iShowItems |= siBattleItems;
	if (bOtherItems != FALSE) m_iShowItems |= siOtherItems;
	m_iShow = 0;
	if (bCombatSkills != FALSE) m_iShow |= ssCombat;
	if (bMagicSkills != FALSE) m_iShow |= ssNormal;
	if (bCombatMagic != FALSE) m_iShow |= ssCombatMagic;
	if (bNormal != FALSE) m_iShow |= ssMagic;
	if (bCanLearn != FALSE) m_iShow |= ssCanStudy;
}

bool CMainDoc::ReadIn(const char *szFilename)
{
	if (!m_bCreated) return false;
	Ainfile *f = new Ainfile();
	bool bResult = false;
	if( f->OpenByName(szFilename) != -1 )
	{	AString *ver = f->GetStr();
		if (ver)
		{	if (*ver == AString(VERSION))
			{	m_pUnit->Readin(f);
				m_pAttList->DeleteAll();
				m_pAttList->Readin(f);
				m_pAttBld->DeleteAll();
				m_pAttBld->Readin(f);
				m_pDefList->DeleteAll();
				m_pDefList->Readin(f);
				m_pDefBld->DeleteAll();
				m_pDefBld->Readin(f);
				delete f->GetStr();
				m_iTerrain = f->GetInt();
				if ((m_iTerrain < 0) || (m_iTerrain >= R_NUM)) m_iTerrain = R_PLAIN;
				m_iNumber = f->GetInt();
				m_iShow = f->GetInt();
				m_iShowItems = f->GetInt();
				m_iSkill = f->GetInt();
				m_iDays = f->GetInt();
				m_iMonths = f->GetInt();
				m_iDays = 30 * (m_iMonths+1);;
				m_iItem = f->GetInt();
				m_iBld = f->GetInt();
				m_bRunes = (f->GetInt() != 0);
				AString *s = f->GetStr();
				if (s)
				{	m_strBldName = CString(s->Str());
					delete s;
				}
				m_bLoaded = true;
				bResult = true;
			}
			else
			{	CString strMsg("Incorrect Battle File Format:\r\n");
				strMsg += szFilename;
				if (*ver == "VERSION,2.31") strMsg += "\r\nThis appears to be an AtMap battle file.";
				::MessageBox(GetFocus(), strMsg, "Load Error", MB_OK|MB_ICONSTOP);
			}
			delete ver;
		}
		f->Close();
	}
	delete f;
	return bResult;
}

bool CMainDoc::WriteOut(const char *szFilename)
{
	Aoutfile *f = new Aoutfile();
	bool bResult = false;
	if( f->OpenByName(szFilename) != -1 )
	{	f->PushKey(VERSION);
			f->PushKey("Design");
				m_pUnit->Writeout(f);
			f->PopKey();
			f->PushKey("Attackers");
				m_pAttList->Writeout(f);
				m_pAttBld->Writeout(f);
			f->PopKey();
			f->PushKey("Defenders");
				m_pDefList->Writeout(f);
				m_pDefBld->Writeout(f);
			f->PopKey();
			f->PushKey("Settings");
				f->PushVal("Terrain", TerrainDefs[m_iTerrain].name);
				f->PushVal("Number", m_iNumber);
				f->PushVal("Show", m_iShow);
				f->PushVal("ShowItems", m_iShowItems);
				f->PushVal("Skill", SkillDefs[m_iSkill].abbr);
				f->PushVal("Months", m_iMonths);
				f->PushVal("Item", ItemDefs[m_iItem].abr);
				f->PushKey("Building");
					f->PushVal("Type", ObjectDefs[m_iBld].name);
					f->PushVal("Runes", (m_bRunes ? "Yes" : "No"));
					f->PushVal("Name", AString(m_strBldName.GetBuffer(0)));
					m_strBldName.ReleaseBuffer();
				f->PopKey();
			f->PopKey();
		f->PopKey();
		f->Close();
		bResult = true;
	}
	delete f;
	return bResult;
}

bool CMainDoc::LoadUnit(const char *szFilename)
{
	if (!m_bCreated) return false;
	Ainfile *f = new Ainfile();
	bool bResult = false;
	if( f->OpenByName(szFilename) != -1 )
	{	AString *ver = f->GetStr();
		if (ver)
		{	if (*ver == AString(UNITVERSION) || *ver == AString(VERSION))
			{	m_pUnit->Readin(f);
				bResult = true;
			}
			else
			{	CString strMsg("Incorrect Unit File Format:\r\n");
				strMsg += szFilename;
				if (*ver == "VERSION,2.31") strMsg += "\r\nThis appears to be an AtMap battle file.";
				::MessageBox(GetFocus(), strMsg, "Load Error", MB_OK|MB_ICONSTOP);
			}
			delete ver;
		}
		f->Close();
	}
	delete f;
	return bResult;
}

bool CMainDoc::SaveUnit(const char *szFilename)
{
	Aoutfile *f = new Aoutfile();
	bool bResult = false;
	if( f->OpenByName(szFilename) != -1 )
	{	f->PutStr(UNITVERSION);
		m_pUnit->Writeout(f);
		f->Close();
		bResult = true;
	}
	delete f;
	return bResult;
}


void CMainDoc::CreateArmies()
{
	ASSERT(m_pUnit == NULL);
	m_pUnit = new Unit();
	m_pAttList = new UnitList();
	m_pDefList = new UnitList();
	m_pAttBld = new ObjectList();
	m_pDefBld = new ObjectList();
	m_bCreated = true;
}

void CMainDoc::DestroyArmies()
{
	if (m_bLoaded)
	{	AString name(theApp.m_szAppPath);
		name += AString(szDefaultFilename);
		WriteOut(name.Str());
	}
	SAFE_DELETE(m_pUnit);
	SAFE_DELETE(m_pAttList);
	SAFE_DELETE(m_pAttBld);
	SAFE_DELETE(m_pDefList);
	SAFE_DELETE(m_pDefBld);
	SAFE_DELETE(m_pAtts);
	SAFE_DELETE(m_pDefs);
	SAFE_DELETE(m_pBattleReport);

	m_bLoaded = false;
	m_bCreated = false;
}

void CMainDoc::DestroyReport()
{	SAFE_DELETE(m_pszReport);
	SAFE_DELETE(m_pRegionList);
}

void CMainDoc::RenumberAtt()
{	if (m_pAttList == NULL) return;
	int from = m_pAttList->Renumber(1000);
	m_pAttBld->RenumberUnits(from);
	m_pAttBld->Renumber(100);
}

void CMainDoc::RenumberDef()
{	if (m_pDefList == NULL) return;
	int from = m_pDefList->Renumber(2000);
	m_pDefBld->RenumberUnits(from);
	m_pDefBld->Renumber(200);
}

BOOL CMainDoc::CanRunBattle() 
{
	if ((m_pAttList == NULL) || (m_pDefList == NULL) ||
		(m_pAttBld == NULL) || (m_pDefBld == NULL)) return FALSE;
	int iAtts = m_pAttList->Num();
	Object *pBld;
	UnitList *pList;
	{	forlist(m_pAttBld)
		{	pBld = (Object*)elem;
			if (pBld)
			{	pList = (UnitList *)(&(pBld->units));
				iAtts += pList->Num();
			}
		}
	}
	int iDefs = m_pDefList->Num();
	{	forlist(m_pDefBld)
		{	pBld = (Object*)elem;
			if (pBld)
			{	pList = (UnitList *)(&(pBld->units));
				iDefs += pList->Num();
			}
		}
	}
	if ((iAtts <= 0) || (iDefs <= 0)) return FALSE;
	return TRUE;
}

void CMainDoc::RunBattle() 
{
	if (CanRunBattle() != TRUE) return;

	SAFE_DELETE(m_pAtts);
	SAFE_DELETE(m_pDefs);
	SAFE_DELETE(m_pBattleReport);

	Unit *pUnit;
	Object *pBld;
	UnitList *pList;
    Battle battle;
	AList atts;
	AList defs;
	m_pAtts = new UnitList();
	m_pDefs = new UnitList();
	ARegion region;
	Location *loc;
	region.type = m_iTerrain;
	{	forlist(m_pAttList)
		{	pUnit = new Unit((Unit &)*elem);
			m_pAtts->Add(pUnit);
			loc = new Location;
			loc->unit = pUnit;
			loc->obj = NULL;
			loc->region = &region;
			atts.Add(loc);
		}
	}
	{	forlist(m_pAttBld)
		{	pBld = (Object*)elem;
			if (pBld)
			{	pList = (UnitList *)(&(pBld->units));
				forlistin(pList)
				{	pUnit = new Unit((Unit &)*elemin);
					m_pAtts->Add(pUnit);
					loc = new Location;
					loc->unit = pUnit;
					loc->obj = NULL;
					loc->region = &region;
					atts.Add(loc);
				}
			}
		}
	}
	{	forlist(m_pDefList)
		{	pUnit = new Unit((Unit &)*elem);
			m_pDefs->Add(pUnit);
			loc = new Location;
			loc->unit = pUnit;
			loc->obj = NULL;
			loc->region = &region;
			defs.Add(loc);
		}
	}
	{	forlist(m_pDefBld)
		{	pBld = (Object*)elem;
			if (pBld)
			{	pList = (UnitList *)(&(pBld->units));
				forlistin(pList)
				{	pUnit = new Unit((Unit &)*elemin);
					m_pDefs->Add(pUnit);
					loc = new Location;
					loc->unit = pUnit;
					loc->obj = NULL;
					loc->region = &region;
					defs.Add(loc);
				}
			}
		}
	}
	if ((atts.Num() <= 0) || (defs.Num() <= 0)) return;
	battle.WriteSides(&atts, &defs, 0);
	battle.Run(&atts, &defs, 0);
	m_pBattleReport = new Areport();
	battle.Report(m_pBattleReport);
	WriteBattleReport();
}

//////////////////////////////////////////////////////////////////////
BOOL CMainDoc::CanGetSurvivors()
{	if ((m_pAtts == NULL) || (m_pDefs == NULL)) return FALSE;
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
void CMainDoc::GetSurvivors() 
{	if (CanGetSurvivors() != TRUE) return;
	// Copy survivors back
	m_pAttList->DeleteAll();
	m_pAttBld->DeleteAllUnits();
	m_pDefList->DeleteAll();
	m_pDefBld->DeleteAllUnits();
	Unit *pUnit;
	{	while (pUnit = (Unit *)m_pAtts->First())
		{	m_pAtts->Remove(pUnit);
			if (!pUnit->IsAlive()) delete pUnit;
			else if (pUnit->object) pUnit->object->units.Add(pUnit);
			else m_pAttList->Add(pUnit);
		}
	}
	{	while (pUnit = (Unit *)m_pDefs->First())
		{	m_pDefs->Remove(pUnit);
			if (!pUnit->IsAlive()) delete pUnit;
			else if (pUnit->object) pUnit->object->units.Add(pUnit);
			else m_pDefList->Add(pUnit);
		}
	}
	RenumberAtt();
	RenumberDef();
	SAFE_DELETE(m_pAtts);
	SAFE_DELETE(m_pDefs);
}

//////////////////////////////////////////////////////////////////////
BOOL CMainDoc::CanWriteBattleReport()
{	if ((m_pBattleReport == NULL) || (m_pAtts == NULL) || (m_pDefs == NULL)) return FALSE;
	return TRUE;
}

//////////////////////////////////////////////////////////////////////
void CMainDoc::WriteBattleReport()
{	if (CanWriteBattleReport() != TRUE) return;
	Aoutfile f;
	AString name(theApp.m_szAppPath);
	name += AString(szBattleFilename);
	if ( f.OpenByName( name ) == -1 ) return;
	f.PutStr(m_pBattleReport->text);
	Unit *pUnit;
	bool b = false;
	{	f.PutStr("");
		f.PutStr("Surviving Attackers:");
		forlist(m_pAtts)
		{	pUnit = (Unit *)elem;
			if (pUnit != NULL)
			{	if (pUnit->IsAlive())
				{	pUnit->WriteReport(&f);
					b = true;
				}
			}
		}
		if (!b) f.PutStr("None");
	}
	{	b = false;
		f.PutStr("");
		f.PutStr("Surviving Defenders:");
		forlist(m_pDefs)
		{	pUnit = (Unit *)elem;
			if (pUnit != NULL)
			{	if (pUnit->IsAlive())
				{	pUnit->WriteReport(&f);
					b = true;
				}
			}
		}
		if (!b) f.PutStr("None");
	}
	f.Close();
}

//////////////////////////////////////////////////////////////////////
char *CMainDoc::GetBattleReportText()
{	if (m_pBattleReport == NULL) return "";
	if (m_pBattleReport->text == NULL) return "";
	return m_pBattleReport->text;
}

//////////////////////////////////////////////////////////////////////
void CMainDoc::OnChangedViewList() 
{
	//CDocument::OnChangedViewList();
}

//////////////////////////////////////////////////////////////////////
bool CMainDoc::ExtractReportData(char *pszData, long lSize)
{
	char *pszPos = strstr(pszData, "Unclaimed silver:");
	
	if (pszPos != NULL)
	{	while ((*pszPos) && (*pszPos != '\r') && (*pszPos != '\n'))
		{	pszPos++;
		}
	}
	else pszPos = pszData;
	while (isspace(*pszPos)) pszPos++; // first non-blank line
	char *pszLine = NULL;
	int iState = 0;
	int iRegType = 0;
	int x,y,z;
	ARegion *pReg = NULL;
	Object *pBld = NULL;
	char *pszTemp;
	char *pszEnd;
	int iLen, iCount;
	AString name;
	while (*pszPos)
	{	pszEnd = pszPos;
		while (pszEnd != NULL)
		{	pszEnd = strchr(pszEnd, '.');
			if (pszEnd != NULL)
			{	pszEnd++;
				if ((*pszEnd == '\r') || (*pszEnd == '\n')) break;
			}
		}
		if (pszEnd == NULL) iLen = strlen(pszPos);
		else iLen = (int)(pszEnd - pszPos);
		if (iLen <= 0) break;
		ASSERT(pszLine == NULL);
		pszLine = new char[iLen+1];
		pszTemp = pszLine;
		memset(pszLine, 0, iLen + 1);
		iCount = 0;
		while (*pszPos && (iCount < iLen))
		{	if ((*pszPos == '\r') || (*pszPos == '\n'))
			{	if ((iCount > 0) && (*(pszPos-1) == '.')) break;
				*pszTemp++ = ' ';
				while (isspace(*pszPos)) pszPos++;
			}
			else *pszTemp++ = *pszPos++;
			iCount++;
		}
		while (isspace(*pszPos)) pszPos++;
		pszTemp = pszLine;
		// now, pszLine is a copy of the object, with newlines stripped, and must not be changed
		// pszTemp points to pszLine, and pszPos is moved to the start of the next object
		if (((pszTemp[0] == '*') || (pszTemp[0] == '-')) && (pszTemp[1] == ' ')) // Read Units
		{	pszTemp += 2;
			pszEnd = strchr(pszTemp, ',');
			if (pszEnd == NULL) break;
			*pszEnd = 0;
			name = AString(pszTemp);
			*pszEnd = ',';
			pszTemp = pszEnd + 1;
			// now load the unit
		}
		else if ((pszTemp[0] == '+') && (pszTemp[1] == ' ')) // Read Buildings
		{	pszTemp += 2;
			pszEnd = strstr(pszTemp, " : ");
			if (pszEnd == NULL) break;
			*pszEnd = 0;
			name = AString(pszTemp);
			*pszEnd = ' ';
			pszTemp = pszEnd + sizeof(" : ");
			// now define the building - all further units get added to the building
		}
		else // Check for a new region
		{	iRegType = CheckTerrain(pszTemp);
			if ((iRegType >= 0) && (iRegType < R_NUM)) // Read region
			{	while ((*pszTemp) && (*pszTemp != '(')) pszTemp++;
				if ((*pszTemp) != '(') break;
				pszTemp++;
				x = 0;
				while (isdigit(*pszTemp))
				{	x *= 10;
					x += (int)(*pszTemp++)-(int)'0';
				}
				if ((*pszTemp) != ',') break;
				pszTemp++;
				y = 0;
				while (isdigit(*pszTemp))
				{	y *= 10;
					y += (int)(*pszTemp++)-(int)'0';
				}
				if ((*pszTemp) == ',')
				{	pszTemp++;
					if (strncmp(pszTemp,"underworld", sizeof("underworld")) == 0)
					{	pszTemp += sizeof("underworld");
						z = 2;
					}
					else if (strncmp(pszTemp,"nexus", sizeof("nexus")) == 0)
					{	pszTemp += sizeof("nexus");
						z = 0;
					}
				}
				else z = 1;
				if ((*pszTemp) != ')') break;
				pszTemp = strchr(pszTemp, ',');
				if (pszTemp != NULL)
				{	if (strstr(pszTemp, "contains") != NULL) pszTemp = strchr(++pszTemp, ',');
					if (pszTemp != NULL) *pszTemp = 0;
				}
				pReg = new ARegion(pszLine, iRegType, x, y, z);
				if (m_pRegionList == NULL) m_pRegionList = new AList;
				m_pRegionList->Add(pReg);
				pBld = (Object *)(pReg->objects.First());
			}
		}
		delete [] pszLine;
		pszLine = NULL;
	}
	return true;
}

//////////////////////////////////////////////////////////////////////
int CMainDoc::CheckTerrain(char *pszLine)
{
	char *szTerrain;
	for (int reg = 0; reg < R_NUM; reg++)
	{	szTerrain = TerrainDefs[reg].name;
		if (strncmp(pszLine, szTerrain, strlen(szTerrain))==0) return reg;
	}
	return -1;
}

//////////////////////////////////////////////////////////////////////
