// BattleReport.cpp : implementation file
//

#include "stdafx.h"
#include "abattlesim.h"
#include "BattleReport.h"
#include "Utils.h"
#include "MainDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBattleReport

IMPLEMENT_DYNCREATE(CBattleReport, CFormView)

CBattleReport::CBattleReport()
	: CFormView(CBattleReport::IDD)
{
	//{{AFX_DATA_INIT(CBattleReport)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CBattleReport::~CBattleReport()
{
}

void CBattleReport::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBattleReport)
	DDX_Control(pDX, ID_BATTLE_CLOSERESULTS, m_btnClose);
	DDX_Control(pDX, ID_BATTLE_UPDATEARMIES, m_btnUpdate);
	DDX_Control(pDX, IDC_LIST_B, m_lstBattle);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBattleReport, CFormView)
	//{{AFX_MSG_MAP(CBattleReport)
	ON_WM_SIZE()
	ON_BN_CLICKED(ID_BATTLE_CLOSERESULTS, OnBattleCloseresults)
	ON_BN_CLICKED(ID_BATTLE_UPDATEARMIES, OnBattleUpdatearmies)
	ON_UPDATE_COMMAND_UI(ID_BATTLE_UPDATEARMIES, OnUpdateBattleUpdatearmies)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBattleReport diagnostics

#ifdef _DEBUG
void CBattleReport::AssertValid() const
{
	CFormView::AssertValid();
}

void CBattleReport::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBattleReport message handlers

/*#define SIZE_RESTORED       0
#define SIZE_MINIMIZED      1
#define SIZE_MAXIMIZED      2
#define SIZE_MAXSHOW        3
#define SIZE_MAXHIDE        4*/

void CBattleReport::OnSize(UINT nType, int cx, int cy) 
{
	CFormView::OnSize(nType, cx, cy);
	if ((nType == SIZE_MINIMIZED) || (nType == SIZE_MAXHIDE) || (nType == SIZE_MAXSHOW)) return;
	if (m_lstBattle.GetSafeHwnd() == NULL)
	{	if (nType != SIZE_MAXIMIZED) return;
		UpdateData(FALSE);
		if (m_lstBattle.GetSafeHwnd() == NULL) return;
	}
	CRect lRect;
	m_btnUpdate.GetWindowRect(&lRect);
	ScreenToClient(&lRect);
	int iBtnHeight = lRect.Height();;
	int iBtnWidth = lRect.Width();
	int iBorderWidth = 7;
	int iMid = cy - iBtnHeight - iBorderWidth*2;
	int iWidth = cx - iBorderWidth * 2;
	m_btnClose.GetWindowRect(&lRect);
	int iCloseWidth = lRect.Width();
	m_lstBattle.SetWindowPos(NULL, iBorderWidth, iBorderWidth, iWidth, iMid - iBorderWidth, SWP_NOOWNERZORDER|SWP_NOZORDER);
	m_btnUpdate.SetWindowPos(NULL, iBorderWidth, iMid + iBorderWidth, 0, 0, SWP_NOSIZE|SWP_NOOWNERZORDER|SWP_NOZORDER);
	int iTemp = iBorderWidth + iBtnWidth + 4;
	int iTemp2 = cx - iBorderWidth - iCloseWidth;
	if (iTemp2 > iTemp) iTemp = iTemp2;
	m_btnClose.SetWindowPos(NULL, iTemp2, iMid + iBorderWidth, 0, 0, SWP_NOSIZE|SWP_NOOWNERZORDER|SWP_NOZORDER);
	lRect.left = iBorderWidth; 
	lRect.top = iMid;
	lRect.right = cx - iBorderWidth; 
	lRect.bottom = cy - iBorderWidth;
	InvalidateRect(&lRect);
}

void CBattleReport::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	UpdateData(FALSE);
	if (m_lstBattle.GetSafeHwnd() == NULL) return;
	m_lstBattle.ResetContent();
	GET_DOC_OR_RETURN;
	CUtils::AddReportToList(m_lstBattle, pDoc->m_pBattleReport);
	CUtils::AddUnitListToList(m_lstBattle, pDoc->m_pAtts, "Surviving Attackers:");
	CUtils::AddUnitListToList(m_lstBattle, pDoc->m_pDefs, "Surviving Defenders:");
	RedrawWindow();	
}

void CBattleReport::OnBattleCloseresults() 
{
	theApp.ChangeView(viewMainForm, viewReport);
}

void CBattleReport::OnBattleUpdatearmies() 
{
	IF_GET_DOC(pDoc->GetSurvivors());
	theApp.ChangeView(viewMainForm, viewReport);
}

void CBattleReport::OnUpdateBattleUpdatearmies(CCmdUI* pCmdUI) 
{
	BOOL bEn = FALSE;
	IF_GET_DOC(bEn = pDoc->CanGetSurvivors());
	pCmdUI->Enable(bEn);
}


void CBattleReport::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	CRect lRect;
	GetWindowRect(&lRect);
	MoveWindow(&lRect);
}
