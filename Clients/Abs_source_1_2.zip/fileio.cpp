// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#include <memory.h>
#include <string.h>
#include "fileio.h"
#include "gameio.h"
#include <iostream.h>
#include <fstream.h>

#define F_ENDLINE '\n'

extern long _ftype,_fcreator;

static char buf[1024];

Aoutfile::Aoutfile() {
	file = new ofstream;
	indent = 0;
}

Aoutfile::~Aoutfile() {
	stack.DeleteAll();
	delete file;
}

Ainfile::Ainfile() {
	file = new ifstream;
}

Ainfile::~Ainfile() {
	delete file;
}

/*Aorders::Aorders() {
	file = new ifstream;
}

Aorders::~Aorders() {
	delete file;
}
*/

#define DEFAULT_SIZE 256

Areport::Areport() {
	//file = new ofstream;
	size = DEFAULT_SIZE;
	text = new char[size + 1];
	memset(text, 0, size);
	ptr = text;
	end = text + size;
	tabs = 0;
}

Areport::~Areport() {
	//delete file;
	delete text;
}

Areport::Expand(int newsize)
{	if (newsize < DEFAULT_SIZE) newsize = DEFAULT_SIZE;
	newsize += size;
	char *temp = new char[newsize + 1];
	strncpy(temp, text, newsize);
	int iptr = ptr-text;
	delete text;
	text = temp;
	end = text + size;
	ptr = text + iptr;
	if (ptr > end) ptr = end;
	size = newsize;
}

void Aoutfile::Open(const AString & s) {
  while (! (file->rdbuf()->is_open())) {
    AString * name = getfilename(s);
    file->open(name->Str(),ios::noreplace | ios::out);
    delete name;
  }
}

int Aoutfile::OpenByName(const AString & s) {
  AString temp = s;
  file->open(temp.Str(), ios::out);
  if (!file->rdbuf()->is_open()) return -1;
  return 0;
}

void Ainfile::Open(const AString & s) {
  while (! (file->rdbuf()->is_open())) {
    AString * name = getfilename(s);
    file->open(name->Str(),ios::in | ios::nocreate);
    delete name;
  }
}

int Ainfile::OpenByName(const AString & s) {
  AString temp = s;
  file->open(temp.Str(),ios::in | ios::nocreate);
  if (! (file->rdbuf()->is_open())) return -1;
  return 0;
}

void Aoutfile::Close() {
	file->close();
}

void Ainfile::Close() {
	file->close();
}

/*void Aorders::Close() {
	file->close();
}

void Areport::Close() {
	file->close();
}
*/

void skipwhite(ifstream * f) {
  if (f->eof()) return;
  int ch = f->peek();
  while(((ch == ' ') || (ch == '\n') || (ch == '\t')
	 || (ch == '\r') || (ch == '\0'))) {
    f->get();
    if (f->eof()) return;
    ch = f->peek();
  }
}

AString * Ainfile::GetStr() {
  skipwhite(file);
  if (file->peek() == -1 || file->eof()) return 0;
  file->getline(buf,1023,F_ENDLINE);
  AString * s = new AString((char *) &(buf[0]));
  return s;
}

AString * Ainfile::GetStrNoSkip() {
  if (file->peek() == -1 || file->eof()) return 0;
  file->getline(buf,1023,F_ENDLINE);
  AString * s = new AString((char *) &(buf[0]));
  return s;
}

int Ainfile::GetInt() {
  int x;
  *file >> x;
  return x;
}

void Aoutfile::PutInt(int x) {
  *file << x;
  *file << F_ENDLINE;
}

void Aoutfile::PutStr(char * s) {
  *file << s << F_ENDLINE;
}

void Aoutfile::PutStr(const AString & s) {
  *file << s << F_ENDLINE;
}

void Aoutfile::Indent() {
	int i = indent;
	while (i-- > 0) *file << "  ";
}

void Aoutfile::PushKey(char * key) {
	Indent();
	stack.Insert(new AString(key));
	*file << "<" << key << ">" << F_ENDLINE;
	++indent;
}

void Aoutfile::PushKey(char * key, char * param, int val) {
	Indent();
	stack.Insert(new AString(key));
	*file << "<" << key << " " << param << "=" << val << ">" << F_ENDLINE;
	++indent;
}

void Aoutfile::PushKey(const AString & key, const AString & param, int val) {
	Indent();
	stack.Insert(new AString(key));
	*file << "<" << key << " " << param << "=" << val << ">" << F_ENDLINE;
	++indent;
}

void Aoutfile::PushKey(const AString & key, const AString & param, const AString & val) {
	Indent();
	stack.Insert(new AString(key));
	*file << "<" << key << " " << param << "=" << val << ">" << F_ENDLINE;
	++indent;
}

int Aoutfile::PopKey() {
	AString *key = (AString *)stack.RemoveFirst();
	if (key) {
		--indent;
		Indent();
		*file << "</" << *key << ">" << F_ENDLINE;
		delete key;
		return 1;
	}
	return 0;
}


void Aoutfile::PushVal(char * key, char * val) {
	Indent();
	*file << "<" << key << ">" << val << "</" << key << ">" << F_ENDLINE;
}

void Aoutfile::PushVal(char * key, const AString & val) {
	PushVal(key, (char *)((AString &)val).Str());
}

void Aoutfile::PushVal(const AString & key, char * val) {
	PushVal((char *)((AString &)key).Str(), val);
}

void Aoutfile::PushVal(const AString & key, const AString & val) {
	PushVal((char *)((AString &)key).Str(), (char *)((AString &)val).Str());
}

void Aoutfile::PushVal(const AString & key, int val) {
	PushVal((char *)((AString &)key).Str(), AString(val));
}

void Aoutfile::PushVal(char * key, int val) {
	PushVal(key, AString(val));
}

/*void Aorders::Open(const AString & s)
{
    while (! (file->rdbuf()->is_open()))
    {
        AString * name = getfilename(s);
        file->open(name->Str(),ios::in | ios::nocreate);
        delete name;
    }
}

int Aorders::OpenByName(const AString & s)
{
    AString temp = s;
    file->open(temp.Str(),ios::in | ios::nocreate);
    if (! (file->rdbuf()->is_open())) return -1;
    return 0;
}

AString * Aorders::GetLine() {
  skipwhite(file);
  if (file->eof()) return 0;
  if (file->peek() == -1) return 0;
  file->getline(buf,1023,F_ENDLINE);
  AString * s = new AString((char *) &(buf[0]));
  return s;
}
*/

/*void Areport::Open(const AString & s)
{
    while (! (file->rdbuf()->is_open()))
    {
        AString * name = getfilename(s);
        file->open(name->Str(),ios::noreplace | ios::out);
        delete name;
    }
    tabs = 0;
}

int Areport::OpenByName(const AString & s)
{
    AString temp = s;
    file->open(temp.Str(),ios::noreplace | ios::out);
    tabs = 0;
    if (!file->rdbuf()->is_open()) return -1;
    return 0;
}*/

void Areport::AddTab() {
  tabs++;
}

void Areport::DropTab() {
  if (tabs > 0) tabs--;
}

void Areport::ClearTab() {
  tabs = 0;
}

void Areport::PutStr(const AString & s,int comment)
{
    AString temp;
    for (int i=0; i<tabs; i++) temp += "  ";
    temp += s;
    AString * temp2 = temp.Trunc(70);
    if (comment) *ptr++ = ';';
	int idiff = ((ptr - text) + temp.Len()) - size + 10;
	if (idiff > 0) Expand(idiff);
	strcpy(ptr, temp.Str());
	ptr += temp.Len();
	*ptr++ = F_ENDLINE;
    while (temp2) {
        temp = "  ";
        for (int i=0; i<tabs; i++) temp += "  ";
        temp += *temp2;
        delete temp2;
        temp2 = temp.Trunc(70);
		idiff = ((ptr - text) + temp.Len()) - size + 10;
		if (idiff > 0) Expand(idiff);
		if (comment) *ptr++ = ';';
		strcpy(ptr, temp.Str());
		ptr += temp.Len();
		*ptr++ = F_ENDLINE;
    }
	*ptr = 0;
}

void Areport::PutNoFormat(const AString & s) {
	int len = ((const AString)s).Len();
	int idiff = ((ptr - text) + len) - size + 10;
	if (idiff > 0) Expand(idiff);
	strcpy(ptr, ((const AString)s).Str());
	ptr += len;
	*ptr++ = F_ENDLINE;
	*ptr = 0;
}

void Areport::EndLine() {
	*ptr++ = F_ENDLINE;
	*ptr = 0;
}
