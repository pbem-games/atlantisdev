from utils1 import loadconfig, buildconfig, stringtolist
from configutils import checkconfigname, checkconfigfile

def flag_check(settings,newmaster,ordertemplate,standard_out):

    basedir = settings['basedir']                       # root directory for everything else to be dependant on
    typefile= basedir + settings['typefile']          # the file containing the unit types and flag settings
    if typefile==basedir:
        standard_out.putout('No file for unit definitions specified.\n')
        standard_out.putout("That's pretty fatal so I'm exiting.\n\n")
        return newmaster

    if  settings['unittypes']=='':
        standard_out.putout('No unit types were specified.\n')
        standard_out.putout( "I can't work with that so I'm exiting.\n\n")
        return newmaster

    flagname=settings['flagname'].lower()
    unittypes=settings['unittypes']



    # Next we need to load in the unit type definitions.
    # We need to build the config spec.
    # This uses the 'unittypes' to tell us what
    # types to expect in the 'typefile'.

    typefilespec=buildconfig(unittypes)

    # typefilespec now contains a dictionary that 
    # the configutils can use to fetch in the
    # parameters from the typefile.

    typefilereader=loadconfig(typefile)
    unittypedict={}                                           # set up the empty dictionary for the unit type details
    unittypedict=checkconfigfile(typefilereader, typefilespec)

    # Let's check the unittype definitions are correct.
    # They need to be 8 character strings of 1 and 0

    #print unittypes
    for member in unittypes:
        if len(unittypedict[member]) != 8:
            standard_out.putout( member + ' : ' + unittypedict[member])
            standard_out.putout("This isn't a valid 8 character flag definition.")
            standard_out.putout("So I'm going to stop.")
            return newmaster
        a=0
        while a<len(unittypedict[member]):
            if  unittypedict[member][a] !='0' and unittypedict[member][a] !='1':
                standard_out.putout( member+' : '+ unittypedict[member])
                standard_out.putout("This has some unexpected characters in it.")
                standard_out.putout("So I'm going to stop. \nIt should consist of 1s and 0s")
                return newmaster 
            a=a+1

    # Let's make sure the unittypes are all lowercase
    tempunittypes=[]
    tempunittypedict={}
    a=0
    for member in unittypes:
        if member != member.lower():
            tempunittypes.append(member.lower())
            tempunittypedict[member.lower()]=unittypedict[member]
            a=1
        else:
            tempunittypes.append(member)
            tempunittypedict[member]=unittypedict[member]
    if a==1:
        unittypes=tempunittypes
        unittypedict=tempunittypedict


    ##############################

    standard_out.putout("\nOutput from flag_checker.\nAn Automated Atlantis Assistant script from the atlantibot project.\nBy Fuzzyman\n\n")

    ##############################



    flagnameunits=[]

    if flagname !='':
        for unit in ordertemplate.ourunitbynum:
            thisunit=ordertemplate.ourunitbynum[unit]
            if thisunit['name'].find(flagname)!=-1:
                flagnameunits.append(unit)

    flagcommandunits=[]
    for unit in ordertemplate.ourunitbynum:
        thisunit=ordertemplate.ourunitbynum[unit]
        for line in thisunit['commands']:
            if line.lower().startswith('flag ')==1 and unit not in flagnameunits:
                flagcommandunits.append(unit)
                
    ourunittypedict={}
    for unit in flagnameunits:
        unitname=ordertemplate.ourunitbynum[unit]['name']
        thistype=unitname[unitname.find(flagname)+len(flagname):].strip()
        if thistype in unittypes:
            ourunittypedict[unit]=thistype

    for unit in flagcommandunits:
        unitcommands=ordertemplate.ourunitbynum[unit]['commands']
        for line in unitcommands:
            if line.lower().startswith('flag ')==1:
                thistype=line[5:].strip()
                if thistype.lower() in unittypes:
                    ourunittypedict[unit]=thistype
                    
    # ourunittypedict now contains a dicionary with all the units we're checking and their type (which must be one of the
    # ones we loaded from the users unit type file).
    # unittypedict contains all the types we loaded with the flag settings.
    

    

    flags=['revealing faction','avoiding','behind','holding','taxing','on guard','receiving no aid',"won't cross water"]
    flags1=['REVEAL','AVOID','BEHIND','HOLD','AUTOTAX','GUARD','NOAID','NOCROSS']

    if ourunittypedict =={}:
        standard_out.putout("No units have been given to me to work with.\n\n")
        return newmaster
    else:
        correctunits=[]
        for unit in ourunittypedict:
            settype=ourunittypedict[unit]
            thisunitflags=ordertemplate.ourunitbynum[unit]['flags']
            testflag=stringtolist(unittypedict[settype.lower()])        #   We'll jst change the flag definition into a list.....

        # flags contains the text for the 8 flags
        # flags1 contains the equivalent command to change the flag setting
        # thistypeflags contains the flag settings for this unittype
        # testflag contains the current flag settings for this unit
        # each of them in a list.

            if testflag != thisunitflags:
                standard_out.putout('\n\nUnit '+str(unit)+' : '+ordertemplate.ourunitbynum[unit]['name'])
                standard_out.putout(' is a unit of type : '+ settype +'\n')
                standard_out.putout('Flags are currently as follows :\n')
                c=0
#                print thisunitflags
                while c<8:
                    if thisunitflags[c]=='1':
                        standard_out.putout(flags[c]+' ')
                    c=c+1
                standard_out.putout('\nFlags for this type should be :\n')
                

                c=0
                while c<8:
                    if testflag[c]=='1':
                        standard_out.putout(flags[c]+' ')
                    c=c+1
                standard_out.putout('\nIssuing the following commands :\n')

        # The little routine below strips blank lines from the bottom of the orders before we add any...
        
                if ordertemplate.ourunitbynum[unit]['orders']!=[]:
                    while ordertemplate.ourunitbynum[unit]['orders']!=[] and ordertemplate.ourunitbynum[unit]['orders'][-1].strip()=='':
                            ordertemplate.ourunitbynum[unit]['orders']=ordertemplate.ourunitbynum[unit]['orders'][:-1]

                if thisunitflags[0]!=testflag[0]:
                    if testflag[0]=='0':
                        ordertemplate.ourunitbynum[unit]['orders'].append('REVEAL')
                        standard_out.putout('REVEAL'+'\n')
                    if testflag[0]=='1':
                        ordertemplate.ourunitbynum[unit]['orders'].append('REVEAL FACTION')
                        standard_out.putout('REVEAL FACTION'+'\n')

                c=1
                while c<8:
                    if testflag[c]!=thisunitflags[c]:
                        ordertemplate.ourunitbynum[unit]['orders'].append(flags1[c]+' '+testflag[c])
                        standard_out.putout(flags1[c]+' '+testflag[c]+'\n')
                    c=c+1
            else:
                correctunits.append(unit)
                
    correctchildren=[]
#    print '\n\n\n\n\n\n\n\n\n'
#    print ordertemplate.parentlist
#    print '\n\n\n\n\n\n\n\n\n'
    for unit in ordertemplate.parentlist:
        for child in ordertemplate.ourunitbynum[unit]['children']:
            thischild=ordertemplate.ourunitbynum[unit]['children'][child]
            for line in thischild['commands']:              # We can only check for commands - names will have to wait until next time
                if line.lower().startswith('flag ')==1:
                    thistype=line[5:].strip()
                    if thistype.lower() in unittypes:   # The Child has a flag setting - and we know it will inherit it's flag settigns from it's parent.
                        childflags=ordertemplate.ourunitbynum[unit]['flags']
                        thistypeflags=unittypedict[thistype.lower()]
                        testflag=stringtolist(thistypeflags)

                        if testflag == childflags:
                            correctchildren.append('New Unit '+ str(child)+' formed by - '+str(unit)+'      ')
                        else:
                            standard_out.putout('\nNew Unit '+ str(child) +', formed by '+str(unit)+'.\n')
                            standard_out.putout('This is a unit of type : '+ thistype +'\n')
                            standard_out.putout('Flags of the parent unit are set as follows :\n')
                            c=0
                            while c<8:
                                if childflags[c]=='1':
                                    standard_out.putout(flags[c]+' ')
                                c=c+1

                            if thischild['orders']!=[]:
                                while thischild['orders']!=[] and thischild['orders'][-1].strip()=='':
                                        thischild['orders']=thischild['orders'][:-1]


                            standard_out.putout('\nFlags for this type should be :\n')
                            c=0
                            while c<8:
                                if thistypeflags[c]=='1':
                                    standard_out.putout(flags[c]+' ')
                                c=c+1
                            standard_out.putout('\nIssuing the following commands :\n')
                            if thistypeflags[0]!=childflags[0]:
                                if thistypeflags[0]=='0':
                                    thischild['orders'].append('REVEAL')
                                    standard_out.putout('REVEAL'+'\n')
                                if thistypeflags[0]=='1':
                                    thischild['orders'].append('REVEAL FACTION')
                                    standard_out.putout('REVEAL FACTION'+'\n')

                            c=1
                            while c<8:
                                if thistypeflags[c]!=childflags[c]:
                                    thischild['orders'].append(flags1[c]+' '+thistypeflags[c])
                                    standard_out.putout(flags1[c]+' '+thistypeflags[c]+'\n')
                                c=c+1
            


        
           
    if correctunits != []:
        standard_out.putout('\nThe following units were checked and had the correct flag settings :\n')
        for unit in correctunits:
            standard_out.putout(str(unit)+' ')

    standard_out.putout('\n')

    if correctchildren != []:
        standard_out.putout('\nThe following NEW units were checked and had the correct flag settings :\n')
        for unit in correctchildren:
            standard_out.putout(unit)

            


    standard_out.putout('\n\nAll units checked.\n\n')


    ##############################

    newordertemplate=ordertemplate.buildordertemplate()

    newmaster[3]=newordertemplate


    return newmaster
