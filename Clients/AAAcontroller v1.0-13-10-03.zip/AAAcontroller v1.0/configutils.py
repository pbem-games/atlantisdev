#!/usr/local/bin/python

# configutils - a group of utilities to help load in the program configuration
#       and make sure that we get all teh configuration and setup details we 
#       need to run the app
# Copyright (C) 2003 Rob McNeur
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at rob@caverock.net.nz

# do our imports at the start
import  os, sys, re, string
from fileutils import readfile

#  lets check and see whether we have been given a config file in the first command argument and read it in
def checkconfigname():

#first lets see if the user specified a config file
    configfilename = None                               # set to blank
    try:
        if sys.argv[1]>=True:                           # we got at least one argument
            configfilename = sys.argv[1]                # our filename is the argument we received
    except:
        pass
    if configfilename == None:                          # no file specified for some reason
        print 'No config file was specified. Using the default file "config.txt"'
        configfilename='config.txt'                     # so we use a default file
    configfilereader=readfile(configfilename)           # read the file in (if it exists)
    if configfilereader == '':                          # for some reason the returned file contents are blank
        print 'No config file found, or file is empty'
        sys.exit(1)                                     # so just close down and finish
    return configfilereader                             # success ! return the config file we have found

def cleanline(inline):
    if inline.find('#',0) >=0:                          # find any comments in the string
        inline,ignored=inline.split('#',1)              # discard the whole comment
    inline=inline.strip()                               # discard unnecessary whitespace at start and end
    return inline

def grabparam(inchunk):
    ignore1,inparam=str(inchunk).split('\'',1)          # get the initial parameter name
    if inparam.find('\'',0) >=0:                        # find any additional single quotes in the string
         inparam,ignore1=inparam.split('\'',1)          # discard the bits past the quote
    return inparam

def checkconfigfile(inconfigfile, configspecs):
    configdict = {}                                     # initialise the array
    for line in inconfigfile:                           # go through all lines in the config file
        lineindex=inconfigfile.index(line)              # get the current line we are on 
                                                        # as some lines may flow onto multiple lines
        workline=cleanline(line)                        # discard comments and whitespace
        if len(workline) < 1:                           # if there is nothing left of the line
            continue                                    # then go to the next one
        while workline[-1:]==',':                       # if the end of the current line is a comma
                                                        # then the parameter value is continued on the next line
            workline=workline+cleanline(inconfigfile[lineindex+1])       # concatenate the cleaned next line
            lineindex+=1                                                 # and check again
        inparam = inparamvals = ''                      # initialise the parameter values
        if workline.find('[',0) >=0:                    # if we have a multi-value dictionary in the parameter
            inparamvals={}
            leftbit,rightbit=workline.split('[',1)      # get the start of the dictionary of values
            inparam=grabparam(cleanline(leftbit.strip()))          # parameter name is in the first bit
            workvals,ignored=rightbit.split(']',1)      # dictionary parameter values are the end of the string
            workvals=workvals.replace("'",'')           # get rid of single quotes
            workvals=workvals.replace(" ",'')           # get rid of spaces
            itemlist = workvals.split(',')              # break them into a list
            inparamvals = itemlist                      # store it in the region dictionary
            #print "for [] vals:"+str(inparamvals)+"  param:"+str(inparam)
        elif workline.find(':',0) >=0:                  # find the separator in the string
            leftbit,rightbit=workline.split(':',1)      # get the start of the dictionary of values
            inparam=grabparam(cleanline(leftbit.strip()))         # get the parameter name from the start
            inparamvals=grabparam(cleanline(rightbit.strip()))    # get the parameter values from the end
        else:
            continue                                    # don't know what we got, lets ignore it
        for param in configspecs:                       # now go through each value in the configuration spec
            #print 'processing param:'+str(param)
            if inparam==param:                          # see if we can find a matching specification
                configdict[param]=inparamvals           # if so, we store the read in params into the config
                break                                   # then go and try again

    if len(configdict) < len(configspecs):              # for some reason the faction details are incomplete
        print 'The required configuration parameters are incomplete or missing.'
        print 'We expected '+str(len(configspecs))+' parameters and only found '+str(len(configdict))+'.'
        print 'See the supplied "config.txt" as an example of the required values.'
        print 'Expected configuration parameters are :'
        print str(configspecs)
        sys.exit(1)                                      # so just close down and finish

    return configdict                                    # return a dictionary holding the completed config values 
