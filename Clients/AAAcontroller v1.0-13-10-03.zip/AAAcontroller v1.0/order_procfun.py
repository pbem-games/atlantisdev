# 13-10-03

from utils1 import  getdigits



#
# The main order_processor function
# Understands - 
# @;# 2 ATLANTIS ORDER ; Means do Atlantis Order in two months
# @;# *3 ATLANTIS ORDER ; Means repeat Atlantis Order three times
# @;# 2*3 ATLANTIS ORDER ; Means wait two months and then repeat Atlantis order three times
#
# If setting 'beforeproc' is set to 'yes' it assumes you write your orders *before* running orderprocessor 
# i.e. It waits till mnth 0 before doing things. It starts repeats the month you issue the order.
#
# If 'beforeproc' is set to 'no' then it assumes you are runnning orderprocessor before you write your orders
# i.e. It performs actions that have reached month 1 but can only start repeats the month after you write them.
#
# It is an important distinction.
#

def order_proc(settings, newmaster, ordertemplate, standard_out):


    beforeproc=settings['beforeproc'].lower().strip()
    switch=settings['switch'].lower().strip()
    ##############################



    print
    standard_out.putout("\nOutput from order_processor script.\n\n")

    ##############################

    addturn=0
    if beforeproc=='yes':
        addturn=1
        
    for unit in ordertemplate.ourunitbynum:              # Let's process each unit
        thisunit=ordertemplate.ourunitbynum[unit]
        commands=thisunit['commands']
        orders=thisunit['orders']
        procced=procunit(commands,orders,addturn,switch)
        commandsdone=procced[0]
        newcommands=procced[1]
        orders=procced[2]

        thisunit['commands']=newcommands         # Put the new orders and commands back into the unit
        thisunit['orders']=orders
        if commandsdone==1:
            standard_out.putout('1 Command found and processed in unit : '+ str(unit)+'\n')
        elif commandsdone>1:
            standard_out.putout(str(commandsdone) + ' Commands found and processed in unit : '+ str(unit)+'\n')



        # What if the unit has children... we can deal with these seperately.............. but it means repeating the whole stretch of code - ungainly... yuck

        if thisunit['children'] != {}:
            for child in thisunit['children']:
                if thisunit['children'][child]['commands']!=[]:
                    childcommands=thisunit['children'][child]['commands']
                    childorders=thisunit['children'][child]['orders']
                    procced=procunit(childcommands,childorders,addturn,switch)
                    childcommandsdone=procced[0]
                    newcommands=procced[1]
                    neworders=procced[2]
                    thisunit['children'][child]['commands']=newcommands
                    thisunit['children'][child]['orders']=neworders

                    if childcommandsdone==1:
                        standard_out.putout('1 Command found and processed in NEW Unit '+str(child) + ' formed by Unit ' + str(unit) +'\n')
                    elif childcommandsdone>1:
                        standard_out.putout(str(childcommandsdone) + ' Commands found and processed in NEW Unit '+ str(child)+' formed by Unit ' + str(unit) +'\n')



 

                
                    


    ###############################
    
    ordertemplate.buildordertemplate()

    standard_out.putout('\nAll units checked.\n\n')

     

    ##############################


    return newmaster




# addturn=1 means beforeproc= 'yes'
#
# This function goes through the commands of a unit and adds the appropriate orders where it finds commands that need processing
#
def procunit(commands,orders,addturn,switch):
    commandsdone=0
    while orders[-1:]=='':
        orders=orders[:-1]
    newcommands=[]
    for line in commands:
        newline=line.strip()
        if newline[0]=='*':              # First possibility - it is a straight repeat command
            if switch=='yes' and addturn==0:                # If you are changing from beforeproc 'no' to 'yes' - ignore repeats
                newcommands.append(line)
            else:                                           # Even if you are changing from 'yes' to no - repeat orders run as usual
                newline=newline[1:].strip()
                numtimestring=getdigits(newline)
                if numtimestring=='':
                    numtimestring='1'
                    newline='1'+newline
                commandsdone=commandsdone+1
                numtimes=int(numtimestring) - 1
                if numtimes>0:                  # This isn't the last time
                    comm=newline[len(numtimestring):].lstrip()
                    newcommands.append(' * '+ str(numtimes)+' '+comm)   # Write the changed command
                    orders.append(comm)         # Write the order
                else:                           # This is the last time
                    comm=newline[len(numtimestring):].lstrip()
                    orders.append(comm)         # Write the order

                
        elif newline[0].isdigit()==1:           # This is some kind of wait command
            if switch=='yes' and addturn==1:        # If we are switching from beforeproc 'yes' to beforeproc 'no' we *only* want to execute wait orders that have got to 0
                numwaitstring=getdigits(newline)
                numwait=int(numwaitstring)
                comm=newline[len(numwaitstring):].lstrip()
                if numwait>0:                       # It's not our time yet
                    newcommands.append(str(numwait)+' '+comm)   # Write the *UNCHANGED* command
                else:                               # This is the last time.... bugger
                    if comm[0]!='*':                # It's not a repeat command
                        orders.append(comm)         # Just add the order
                        commandsdone=commandsdone+1
                    else:                           # It *is* a repeat command
                        newline=comm[1:].strip()
                        numtimestring=getdigits(newline)
                        if numtimestring=='':           # It's a repeat without a number of times !!
                            numtimestring='1'
                            newline='1'+newline
                        commandsdone=commandsdone+1
                        numtimes=int(numtimestring) - 1
                        if numtimes>0:                  # This isn't the last time
                            comm=newline[len(numtimestring):].lstrip()
                            newcommands.append(' * '+ str(numtimes)+' '+comm)   # Write the new command
                            orders.append(comm)         # And write the order
                        else:                           # This is the last time (only happens if numtimes was 1, 0 or not present !!)
                            comm=newline[len(numtimestring):].lstrip()
                            orders.append(comm)         # So just write the order                
            else:
                commandsdone=commandsdone+1
                numwaitstring=str(getdigits(newline))
#                print numwaitstring
                numwait=int(numwaitstring) + addturn -1
                comm=newline[len(numwaitstring):].lstrip()
                if numwait>0:                       # It's not our time yet
                    newcommands.append(str(numwait-addturn)+' '+comm)   # Write the changed command
                else:                               # This is the last time.... bugger
                    if comm[0]!='*':                # It's not a repeat command
                        orders.append(comm)         # Just add the order
                    else:                           # It *is* a repeat command
                        if switch=='yes' and addturn==0:    # If we're switching from beforeproc no to yes we don't want to perform repeat orders
                            newcommands.append(comm.strip())    # So we'll just add the command 
                        else:
                            newline=comm[1:].strip()
                            numtimestring=getdigits(newline)
                            if numtimestring=='':           # It's a repeat without a number of times !!
                                numtimestring='1'
                                newline='1'+newline
                            numtimes=int(numtimestring)- 1
                            if numtimes>0:                  # This isn't the last time
                                comm=newline[len(numtimestring):].lstrip()
                                newcommands.append(' * '+ str(numtimes)+' '+comm)   # Write the new command
                                orders.append(comm)         # And write the order
                            else:                           # This is the last time (only time - numtimes was 1 or less !!)
                                comm=newline[len(numtimestring):].lstrip()
                                orders.append(comm)         # So just write the order

            

        else:                                   # It's not one of our commands at all
            newcommands.append(line)

    return [commandsdone, newcommands, orders]


# Code to test the procfun function - to see that it returns the right 'answer' in every case

# addturn=1 means beforeproc= 'yes' (write orders before processing)
#




def test_orderproc():
    testorder=[['no',1],['no',0],['yes',1],['yes',0]]
    testcommands=['0 TESTa', '1 TESTb', '2 TESTc', '* TESTd', '*1 TESTe', '*2 TESTf', '0*1 TESTg', '0*2 TESTh', '1*2 TESTi', '2*2 TESTj', '1*1 TESTk']
    
    print testcommands
    print

    for pattern in testorder:
        testresult= procunit(testcommands,[], pattern[1],pattern[0])
        print testresult[0]
        print testresult[1]
        print testresult[2]
        print pattern
        print
        print

    return
                        

