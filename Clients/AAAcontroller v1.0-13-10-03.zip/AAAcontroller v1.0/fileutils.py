#!/usr/local/bin/python

# fileutils - A group of file handling utility functions for Atlantis scripts
# Copyright (C) 2003 Rob McNeur
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at rob@caverock.net.nz

import os, string, re

### Some simple functions ###
months = ['January','February','March','April','May','June','July',
          'August','September','October','November','December']

def getturnno(infile):
                 # reads through a turn file looking for the month and year to determine the turn number
                 # turn numbers are in the format "September, Year 5"

    yearno = 0
    monthno = 0
    turnnumber=0
    isreport = 0
    for line in infile:
        if line.startswith('Atlantis Report'):
            isreport = 1
        if yearno > 0:
           break
        monthno = 0
        for month in months:
            monthno = monthno+1
            x = len(month)
            if line[0:len(month)] == month:
                sppos = line.rfind(' ',5,72)
                yearno = int(line[sppos:])
                break
    if not isreport:
        print "This file is not a valid Atlantis report file"
        yearno=0
        monthno=0
    turnnumber=(yearno-1)*12+monthno
    print 'month:'+str(monthno)+'   year:'+str(yearno)+'    turn:'+str(turnnumber)
    return turnnumber                            # should be the number of the turn or 0 if not found

def readfile(filename):
                 # function to read in a file if it exists and load it into a list of strings
    mystring = ''
    try:
        input = open(filename, 'r')                              # open file in read mode
        mystring = input.readlines()                             # read all lines into a list of strings
        input.close()                                            # close the file
        print "opened file "+filename
    except IOError:                               #possibly tried to read a directory, or file does not exist
        print "Couldn't open file "+filename
    if len(mystring)>1:                                          # as long as we found some data lines
      mystring[(len(mystring)-1)] +='\n'                         # make sure the last one has a line-feed on it
                                                                 # otherwise the last line gets ignored
    return mystring                                              # will be list of strings

def wrapline (outfile, inline):
                    # function to cut a line of text into sections, splitting at the last space found 
                    # before character position 72, write out that line, then repeat until the whole 
                    # line has been output
    indent=0
    if inline.startswith('  *') or inline.startswith('  -'):     # its a unit inside a building, so needs indenting
        indent=1
    while len(inline)> 0:                                        # keep going until the line has been fully wrapped
        if len(inline) <=72:                                     # doesn't need wrapping
            outfile.write(inline)                                # so just print it out
            inline = ''
        else:
            sppos = inline.rfind(' ',5,72)                       # look for the last space before pos 72 for wrapping
            if (sppos == -1):                                    # no spaces found ???
                outfile.write(inline)                            # write the line out
                inline = ''
            elif (sppos == len(inline)):                         # space at the end of the line
                outfile.write(inline[:sppos-1])                  # so truncate that space off, back to real text
                inline = ''
            else:                                                # last space found at right end
                workline=inline[:sppos]                          # cut off the line up to the space
                outfile.write(workline+'\n')                     # write it out
                if indent:                                       # units in buildings need indenting in the report
                  inline='    '+inline[sppos+1:]                 # new line = right side of line after wrap
                else:
                  inline='  '+inline[sppos+1:]                   # new line = right side of line after wrap

    return

def outputunit(workunit, factionid):
                                   # function to format a unit record, ready for writing to file
    notmyunit2 = ['= ', ': ', '- ', '% ', '! ']
    myunit2 = ['* ']
    myunit3 = [' * ']
    notmyunit3 = [' - ', ' : ', ' = ', ' % ', ' ! ']
    outline=workunit['main']+'.'
    if outline[:2] in notmyunit2:
        if int(workunit['faction'])==int(factionid):
           outline="* "+ outline[2:]
    elif outline[:2] in myunit2:
        if int(workunit['faction'])!=int(factionid):
           outline="- "+ outline[2:]
    elif outline[:3] in notmyunit3:
        if int(workunit['faction'])==int(factionid):
           outline=" * "+ outline[3:]
    elif outline[:3] in myunit3:
        if int(workunit['faction'])!=int(factionid):
           outline=" - "+ outline[3:]
    if workunit['weight'] != None:
        outline=outline+workunit['weight']+'.'
    if workunit['capacity'] != None:
        outline=outline+workunit['capacity']+'.'
    if workunit['skillbit'] != None:
        outline=outline+' Skills:'+workunit['skillbit']+'.'
    if workunit['combatspell'] != None:
        outline=outline+workunit['combatspell']+'.'
    if workunit['spells'] != None:
        outline=outline+workunit['spells']+'.'
    return outline

def writefile(filename,fullreport, settings, factionno):
                          # Writes out the parsed 'fullreport' into the specified filename
                          # using the 'settings' for any required configuration parameters
    mystring = ''
    region = fullreport[1]
    units = fullreport[2]
    template = fullreport[3]
    prelude = fullreport[4]
    buildings = fullreport[5]
    unitbynum = fullreport[6]
    skilllist = fullreport[7]
    faction = fullreport[8]
    itemlist = fullreport[9]
    battles = fullreport[10]
    buildingunits={}
    try:
        print "writing to file "+filename
        fout = open(filename, 'w')
        donebattle=0
        if settings['doevents']=='Yes':
            while len(prelude)>0:
                outline=prelude.pop(0)
                if (not donebattle) and outline.startswith('Events during'):
                    donebattle=1
                    for x in range(len(battles)):
                        wrapline(fout,battles[x])
                wrapline(fout,'')
                wrapline(fout,outline)
                if outline.startswith('Battles during'):
                    donebattle=1
                    x=0
                    for x in range(len(battles)):
                        wrapline(fout,battles[x])
                    wrapline(fout,'')
                    while len(prelude)>0 and not outline.startswith('Events during'):
                        outline=prelude.pop(0)
                    wrapline(fout,outline)

        logging=0
        # print 'nexus:'+settings['donexus']
        # print 'surface:'+settings['dosurface']
        # print 'underworld:'+settings['dounder']
        if settings['printskills']=='Yes':
            wrapline(fout, 'Skill reports:\n\n')
            sortlist = [(k,x) for k,x in skilllist.items()]
            sortlist.sort()
            while len(sortlist)>0:
                skillitem = sortlist.pop(0)
                k=skillitem[0]
                x=skillitem[1]
                outline = x['skillname']+k+':'+x['skilldesc']+'\n\n'
                wrapline(fout, outline)

                   #  Now to write out all the declared attitudes for this faction
        if settings['dofaction']=='Yes':
            attitudelist=['hostile','unfriendly','neutral','friendly','ally']
            attitudes=faction['attitudes']
            wrapline(fout, 'Declared Attitudes (default '+attitudes['default']+'):\n')
            for x in range(5):
                 firstone = 0
                 outline = ''
                 while len(attitudes[attitudelist[x]])>0:
                     if outline > '':
                         outline += ', '
                     outline += attitudes[attitudelist[x]].pop(0)
                 fulloutline=attitudelist[x].capitalize()+' : '+outline
                 wrapline(fout, fulloutline+'.\n')

            wrapline(fout, '\n')
            wrapline(fout, 'Unclaimed silver: '+str(faction['unclaimedsilver'])+'.\n\n')

        for underworld in ['nexus','no','yes']:                   # first the nexus, then surface, then underworld
            if (underworld=='nexus') and (settings['donexus'] != 'Yes'):     # only output if specified in the config
                continue 
            elif (underworld=='no') and (settings['dosurface'] != 'Yes'):    # only output if specified in the config
                continue 
            elif (underworld=='yes') and (settings['dounder'] != 'Yes'):     # only output if specified in the config
                continue 
            for y in range(200):                                            # assumes a maximum map size of 100x100
                for x in range(200):
                    if underworld == 'nexus':
                        location = str(x)+","+str(y)+",nexus"               # build up the region key
                    elif underworld == 'no':
                        location = str(x)+","+str(y)
                    else:
                        location = str(x)+","+str(y)+",underworld"
                    if region.has_key(location):
                        #print "processing:"+location
                        if underworld == 'nexus':
                            outline='nexus ('+location+') in '+str(region[location]['province'])+'.\n'
                        else:
                            outline=str(region[location]['terrain'])+' ('+location+') in '
                            if region[location]['terrain']=='ocean':
                                outline+= str(region[location]['province'])+'.\n'
                            else:
                                outline+= str(region[location]['province'])+', '
                                if region[location]['settlename'] != None:
                                    outline += 'contains '+str(region[location]['settlename'])+' ['
                                    outline += str(region[location]['settletype'])+'], '
                                outline += str(region[location]['pop'])+' peasants ('+str(region[location]['race'])+'), $'
                                outline=outline+str(region[location]['maxtax'])+'.\n'
                        #print str(region[location])
                        wrapline(fout,outline)
                        wrapline(fout,'------------------------------------------------------------\n')
                        if region[location]['lastweather'] == 'clear':
                           wrapline(fout,'  It was clear last month;')
                        else:
                           wrapline(fout,'  It was winter last month;')
                        if region[location]['weather'] == 'clear':
                           wrapline(fout,' it will be clear next month.\n')
                        else:
                            wrapline(fout,' it will be winter next month.\n')

                        if underworld == 'nexus':
                            wrapline(fout,'\n')
                            wrapline(fout,'  '+region[location]['comment']+'\n')
                            wrapline(fout,'\n')

                        if underworld == 'nexus' or region[location]['terrain']=='ocean':
                            # print 'Nexus:'+str(region[location])
                            wrapline(fout,'  Wages: $'+str(region[location]['wages'])+'.\n')
                        else:
                            wrapline(fout,'  Wages: $'+str(region[location]['wages']))
                            wrapline(fout,'  (Max: $'+str(region[location]['wagesmax'])+').\n')

                        outline='  Wanted: '
                        first = 1
                        if underworld == 'nexus':
                             outline=outline+'none'
                        else:
                            for wanted in region[location]['wanted']:
                               if not first:
                                  outline=outline+', '
                               outline=outline+wanted
                               first = 0
                        wrapline(fout,outline+'.\n')

                        outline='  For Sale: '
                        first = 1
                        if underworld == 'nexus':
                             outline=outline+'none'
                        else:
                            for forsale in region[location]['forsale']:
                               if not first:
                                  outline=outline+', '
                               outline=outline+forsale
                               first = 0
                        wrapline(fout,outline+'.\n')

                        if (underworld != 'nexus') and (region[location]['terrain'] != 'ocean'):
                            wrapline(fout,'  Entertainment available: $'+str(region[location]['entertain'])+'.\n')

                        outline='  Products: '
                        first = 1
                        if underworld == 'nexus':
                             outline=outline+'none'
                        else:
                            for prod in region[location]['products']:
                               if not first:
                                  outline=outline+', '
                               outline=outline+prod
                               first = 0
                        wrapline(fout,outline+'.\n')
                        fout.write('\n')
                        fout.write('Exits:\n')
                        for diry in region[location]['directions']:
                           outline='  '+diry+' : '
                           count = 0
                           for dirbit in region[location]['directions'][diry]:
                               if count == 2:
                                   outline=outline+'in '
                               outline=outline+dirbit
                               if count < 2:
                                   outline=outline+' '
                               count = count + 1
                           wrapline(fout,outline+'.\n')
                        wrapline(fout,'\n')

                        buildingunits[location]=[]
                        if units.has_key(location):
                            workunits = units[location]
                            #print 'in units:'+str(len(workunits))+' '+str(workunits)
                            for count in range(len(workunits)):
                                workunit=workunits.pop(0)
                                if int(workunit['building'])==0:
                                    outline=outputunit(workunit, factionno)
                                    wrapline(fout,outline+'\n')
                                else:
                                    buildingunits[location].append(workunit)
                            wrapline(fout,'\n')

                        if buildings.has_key(location):
                            workbuildings = buildings[location]
                            for count in range(len(workbuildings)):
                                workbuilding=workbuildings.pop(0)
                                outline='+ '+workbuilding['name']+' ['+str(workbuilding['id'])+'] : '
                                outline=outline+workbuilding['type']
                                if workbuilding['comment'] > '':
                                    outline=outline+', '+workbuilding['comment']
                                wrapline(fout,outline+'.\n')
                                #print 'building:'+outline
                                if buildingunits.has_key(location):
                                    buildunits = buildingunits[location]
                                    #print 'units:'+str(len(buildunits))+' '+str(buildunits)
                                    for count2 in range(len(buildunits)):
                                        workunit=buildunits.pop(0)
                                        #print 'checking:'+workunit['main']+' build:'+str(workunit['building'])
                                        if int(workunit['building'])==int(workbuilding['id']):
                                            outline=outputunit(workunit, factionno)
                                            wrapline(fout,' '+outline+'\n')
                                        else:
                                            buildingunits[location].append(workunit)

                                wrapline(fout,'\n')
                            wrapline(fout,'\n')

        if settings['dotemplate']=='Yes':
            while len(template)>0:
                wrapline(fout,template.pop(0))
        fout.close()
        print "closed file "+filename
    except IOError:     # Failed to write/create a file for some reason
        print "Failed to write the file"+filename       # we'll ignore it for now and carry on
    return

# Create an archive for the old turns. eg turn 2 will be directory '2'
def createdir(dirname):
    if not os.path.exists(dirname):                           #  see if the directory already exists
        try:
            os.makedirs( dirname, 0700 )                 # Make all subdirs down to the required level
        except OSError:
            print "Failed to create the directory"+dirname
                                                         # some sort of error. Creation has failed for some reason
    return