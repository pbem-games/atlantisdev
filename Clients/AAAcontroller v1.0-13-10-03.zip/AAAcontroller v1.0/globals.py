#!/usr/local/bin/python

# REImports - A number of defined strings for use in regular expressions designed 
# to help the other Atlantis utilities
# Copyright (C) 2003 Rob McNeur
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at rob@caverock.net.nz
#
# This script is imported into other main scripts or executables
#
buildingbase=r'''\+\s+(.*)\s+\[(\d+)\]\s+\:\s+(.*)'''
              #  buildings are like "+ Building [1] : Tower."
              # so we look for a +, space, the name string, then [] brackets with the id number
              # followed by space, colon, space, and building type

buildingapattern = buildingbase+'\.'              # some buildings finish with a fullstop
buildingbpattern = buildingbase+'\,(.*)\.'        # some buildings finish with a comma and comment string
buildingcpattern = buildingbase+'\.(.*)\.\.'        # some buildings finish with a fullstop and comment string

             # the following regular expressions are to locate regions in the following format:
             # plain (40,2) in Rhihin, 501 peasants (high elves), $2004.
             # mountain (36,4) in Donnais, contains Ormgryte [town], 1722 peasants (orcs), $6888.

coords=r'''\((\d+),(\d+)\)'''                     # co-ord string is {} brackets holding x co-ord, y co-ord
coordsunder=r'''\((\d+),(\d+),underworld\)'''     # underworld co-ord string is {} brackets holding x co-ord, y co-ord
coordsnexus=r'''\((\d+),(\d+),nexus\)'''          # nexus co-ord string is {} brackets holding x co-ord, y co-ord
inregion=r'''\s+in\s+(.*?)'''
oceanstart=r'''ocean\s+'''
nexusstart=r'''nexus\s+'''
regionstart=r'''(\w+)\s+'''
peasantstr=r''',\s+(\d+)\s+peasants\s+\((.*)\),\s+\$(\d+)\.''' # No of peasants, racial type, max tax
citybits=r''',\s+contains\s+(.*)\s+\[(\w+)\]'''                # city details

xoceanpattern = oceanstart+coords+inregion+'\.'
xoceanunderpattern = oceanstart+coordsunder+inregion+'\.'
xnexusregionpattern = nexusstart+coordsnexus+inregion+'\.'

xregionunderpattern = regionstart+coordsunder+inregion+peasantstr
xregionpattern = regionstart+coords+inregion+peasantstr
xcitypattern = regionstart+coords+inregion+citybits+peasantstr
xcityunderpattern = regionstart+coordsunder+inregion+citybits+peasantstr

                 # the following regular expressions are to locate directions such as below:
                 # Exits:
                 #  North : jungle (29,81) in Chedaru.
                 #  Northeast : jungle (30,82) in Chedaru.
                 #  Southeast : jungle (30,84) in Chedaru, contains Vesler [town].

dirbase=r'''\s+(\w+)\s+\:\s+(\w+)\s+'''      # includes direction, terrain
inprovince=r'''\s+in\s+(\w+)\.'''            # province
dircity=r''',\s+contains\s+(\w+)'''
xdirpattern = dirbase+coords+inprovince+'\.'
xdirunderpattern = dirbase+coordsunder+inprovince+'\.'

xdircitypattern = dirbase+coords+inprovince+dircity
xdirundercitypattern = dirbase+coordsunder+inprovince+dircity

atlantisversion=''
