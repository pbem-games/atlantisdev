#!/usr/local/bin/python

# MergeUtils - A number of utility functions designed to help the Atlantis report merge facility
# Copyright (C) 2003 Rob McNeur
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at rob@caverock.net.nz
#
# This script is called from other main scripts or executables
#
import re, globals, string
from fileutils import getturnno

directions = ['n','s','se','sw','ne','nw']           # a list of the hex directions available in the report

directiondict = {'North':'n', 'Northeast':'ne', 'Northwest':'nw',
                 'South':'s', 'Southeast':'se', 'Southwest':'sw' }   # expansion of the directions

attitudelist = ['hostile', 'unfriendly', 'neutral', 'friendly', 'ally']
atlantisversion=''

def getreportfaction(infile):
    reportfaction=0
    for line in infile:
        if line.startswith('Atlantis Report'):
            lineindex = infile.index(line)
            workline=infile[lineindex+1]
            wibble=re.search('.*\((\d+)\)\s+\(.*', workline)
            if wibble != None:                                         # we found the faction number !
                reportfaction=wibble.groups()[0]                       # faction number
            break
    return reportfaction

def getversion(infile):
    atlantisversion=""
    for line in infile:
        if line.startswith('Atlantis Engine Version:'):
            lineindex = infile.index(line)
            wibble=re.search(r'.*\s+(\d+\.\d+\.\d+).*', line)
            if wibble != None:                                    # we found the atlantis version number !
                atlantisversion=str(wibble.groups()[0])
                print "Version num:"+atlantisversion
            break
    return atlantisversion

def is410(atlantisversion):
    output=False
    if atlantisversion=='4.0.10':
       output=True
    return output

def is409(atlantisversion):
    output=False
    if atlantisversion=='4.0.9':
       output=True
    return output

def is406(atlantisversion):
    output=False
    if atlantisversion=='4.0.6':
       output=True
    return output

def fixreport(inreport):                        # concatenates to a single line all those lines
                                                # that have been wrapped to fit the line length
    tempreport = []
    temp = ''
    for line in inreport:
        if line[:-1].isspace():
            line = ''
        if len(line) > 2 and (line[-2] == '.' or line[-2] == '-' or line[-2] == ':'): 
                                                                  # -2 since we'll have \n's at the end
            withoutspaces = re.sub('\s+',' ',temp+line)           # turn multiple spaces into single spaces
            tempreport.append(withoutspaces)                      # build up the new report
            temp=''
        else:
            temp += line[:-1] + ' '*(temp!='')
    tempreport.append('#end')
    #for x in range(len(tempreport)):
    #   print 'x:'+tempreport[x]
    return tempreport

def parsebuilding(inline):
    thisbuilding={}
    buildingbit = None
    buildingbit = re.compile(globals.buildingcpattern,re.VERBOSE).search(inline)
                                                               # search for a building plus comment
    if buildingbit == None:
        buildingbit = re.compile(globals.buildingbpattern,re.VERBOSE).search(inline)  
                                                               # search for building plus comment, format 2
    if buildingbit != None:
        # print "building:"+str(buildingbit.groups())
        thisbuilding['name'] = buildingbit.groups()[0]         # get the name
        thisbuilding['id'] = int(buildingbit.groups()[1])      # get the id
        thisbuilding['type'] = buildingbit.groups()[2]         # building type
        thisbuilding['comment'] = buildingbit.groups()[3]      # and any additional comments

    if buildingbit == None:
        buildingbit = re.compile(globals.buildingapattern,re.VERBOSE).search(inline) # search for a building
        if buildingbit != None:
            #print "building:"+str(buildingbit.groups())
            thisbuilding['name'] = buildingbit.groups()[0]     # get the name
            thisbuilding['id'] = int(buildingbit.groups()[1])  # get the id
            thisbuilding['type'] = buildingbit.groups()[2]     # building type
            thisbuilding['comment'] = ''                       # no additional comments

    return thisbuilding

def parseattitudes(inreport):
    inattitudes = 0
    attitudes = {}
    for line in inreport:
        if line.startswith('Declared Attitudes'):
            #print "Attitudes:"+line
            workline, ignored = line.split(')')
            ignored, workline = workline.split('(')
            ignored, attitudes['default'] = workline.split(' ')
            lineindex = inreport.index(line)
            inattitudes=1
            for x in range(5):
                attitudes[attitudelist[x]] = []
            for x in range(5):
                workline = inreport[lineindex+1+x]
                if workline.startswith('Unclaimed'):
                    break
                #print "line:"+workline
                foundattitude, workline = workline.split(':')
                holdline=''
                stpos=line.rfind('.',3,len(line))                  # find the last fullstop

                workline = workline[:stpos-1]
                #print "line:"+workline
                foundattitude=foundattitude.strip()
                for y in range(5):
                    if attitudelist[y].upper()==foundattitude.upper():
                         break
                itemlist=workline.split(',')
                #print "attitude:"+attitudelist[y]
                for faction in itemlist:
                    #print"   faction:"+faction
                    attitudes[attitudelist[y]].append(faction.strip())
            for x in range(5):
                if attitudes[attitudelist[x]] == []:
                    attitudes[attitudelist[x]].append('none')
            break
    return attitudes

def parseskills(inreport, skilllist):
    inskills = 0
    joinedup = 0
    for line in inreport:
        if line.startswith('Declared Attitudes'):
              break
        if line.startswith('Item reports'):
              break
        if line.startswith('Skill reports:'):
             inskills=1
             continue
        if joinedup:
            joinedup -= 1
            continue
        curindex = inreport.index(line)
        while (curindex<len(inreport)-1 and inreport[curindex+1].startswith(' ')) :
                line += inreport[curindex+1]
                curindex += 1
                joinedup +=1
        # print "Skill:"+line
        if inskills and (not (line.startswith('Skill reports:'))) and (line > ''):
            skill={}
            workline=line.strip()
            workbit, skill['skilldesc'] = workline.split(':')
            skill['skillname'], codepart = workbit.split('[')
            skill['code'], skill['level'] = workbit.split(']')
            skillcode = "["+codepart
            if not (skilllist.has_key(skillcode)):
                skilllist[skillcode] = skill

    return skilllist

def parseitems(inreport, allitems):
    initems = 0
    joinedup = 0
    for line in inreport:
        if line.startswith('Declared Attitudes'):
              break
        if line.startswith('Item reports'):
             initems=1
             continue
        if joinedup:
            joinedup -= 1
            continue
        curindex = inreport.index(line)
        while (curindex<len(inreport)-1 and inreport[curindex+1].startswith(' ')) :
                line += inreport[curindex+1]
                curindex += 1
                joinedup +=1
        if initems and (not (line.startswith('Item reports:'))) and (line > ''):
            #print "Item:"+line
            item={}
            workline=line.strip()
            workbit, item['itemdesc'] = workline.split(',',1)
            item['itemname'], codepart = workbit.split('[')
            item['code'], ignored = workbit.split(']')
            itemcode = "["+codepart
            #print "code:"+itemcode
            if not (allitems.has_key(itemcode)):
                allitems[itemcode] = item

    return allitems

def parsebattles(inreport, battles):
    inbattles = 0
    joinedup = 0
    for line in inreport:
        if line.startswith('Events during'):
              break
        if line.startswith('Battles during'):
             inbattles=1
             continue
        if joinedup:
            joinedup -= 1
            continue
        curindex = inreport.index(line)
        #print "battleline1:"+line
        while (curindex<len(inreport)-1 and inreport[curindex+1].startswith('  ')):
                line = line[:-1]+inreport[curindex+1]
                #print "battleline2:"+line
                curindex += 1
                joinedup +=1
        if inbattles and (not (line.startswith('Battles during'))):
            battles.append(line)
    return battles

def updateunit(oldunit, newunit):
    updatedunit = {}
    updatedunit = oldunit
    for x in ['main', 'spells', 'skillbit', 'combatspell', 'faction', 'items', \
           'skills', 'unitnum', 'building', 'weight', 'capacity', 'name', 'location']:
        if not oldunit.has_key(x):
            if newunit.has_key(x):
                updatedunit[x]=newunit[x]
        if oldunit.has_key(x)and newunit.has_key(x):
            #print "X:"+str(x)
            #print "old:"+str(oldunit[x])+"   new:"+str(newunit[x])
            if len(str(newunit[x])) > len(str(oldunit[x])):
                updatedunit[x] = newunit[x]
    return updatedunit

def parsemove (inreport, region):

                 # the following regular expressions are to locate directions such as below
                 # Exits:
                 #  North : jungle (29,81) in Chedaru.
                 #  Northeast : jungle (30,82) in Chedaru.
                 #  Southeast : jungle (30,84) in Chedaru, contains Vesler [town].

#    movepattern = re.compile(r'''\w+\sfrom\s+
#\w+\s+\(\d+,\d+\)\s+in\s+\w+\s+to(\w+)\s+\((\d+,\d+)\)\s+in\s+
#(\w+)\.
#''', re.VERBOSE)
    movepattern = re.compile(r'''\w+\sfrom\s+
\w+\s+\(\d+,\d+\)\s+in\s+\w+\s+to\s+(\w+)\s+\((\d+),(\d+)\)\s+in\s+
(\w+)\.
''', re.VERBOSE)
    for line in inreport:
        joinedup=0
        if line.startswith('Skill reports:'):
              break
        if line.startswith('Item reports'):
              break
        if line.startswith('Skill reports:'):
             inskills=1
             continue
        if joinedup:
            joinedup -= 1
            continue
        curindex = inreport.index(line)
        while (curindex<len(inreport)-1 and inreport[curindex+1].startswith(' ')) :
                line += inreport[curindex+1]
                curindex += 1
                joinedup +=1
        if (line.find(': ',1,len(line)) < 1):
            continue
        ignored, mainstring = line.split(': ',1)                           # break it into a list

        #print "testing :"+mainstring
        dictstring=None
        wibble = None

          # the following sections use the regular expressions defined above to search the report lines
          # to identify regions in the report. If they locate a region, each of the region portions will
          # have been extracted/parsed by the regular expression and can be separately grabbed
        if wibble == None:
            wibble = re.compile(movepattern, re.VERBOSE).search(mainstring.strip())
                                                                      # search for the region (nexus)
            if wibble != None:                                           # we found the nexus !
                thisregion = {}
                thisregion['terrain']=wibble.groups()[0]
                thisregion['x']=wibble.groups()[1]
                thisregion['y']=wibble.groups()[2]
                thisregion['underworld']='no'
                thisregion['province']=wibble.groups()[3]
                #print "region:"+thisregion['terrain']+"("+thisregion['x']+','+     \
                #          thisregion['y']+") - "+str(thisregion['province'])
                if thisregion['underworld']=="no":
                    dictstring = thisregion['x']+','+thisregion['y']
                else:
                    dictstring = thisregion['x']+','+thisregion['y']+',underworld'
                try:
                    if region.has_key(dictstring) and thisregion['underworld']!="nexus":
                        continue
                    else:
                        #print "saving region:"+dictstring
                        thisregion['settlename']=None                            
                        thisregion['settletype']=None
                        thisregion['pop']=0
                        thisregion['race']='Unknown'
                        thisregion['maxtax']=0
                        thisregion['lastweather'] = 'clear'
                        thisregion['weather'] = 'clear'
                        thisregion['wages'] = int(0)
                        thisregion['wagesmax'] = int(0)
                        thisregion['wanted'] = ['none']
                        thisregion['forsale'] = ['none']
                        thisregion['entertain'] = 0
                        thisregion['products'] = ['none']
                        thisregion['directions'] = {}
                        region[dictstring]=thisregion
                except KeyError:
                    region[dictstring]=thisregion

    return 

def parseregion(report, lineindex):

                 # the following regular expressions are to locate directions such as below
                 # Exits:
                 #  North : jungle (29,81) in Chedaru.
                 #  Northeast : jungle (30,82) in Chedaru.
                 #  Southeast : jungle (30,84) in Chedaru, contains Vesler [town].

    dirpattern = re.compile(r'''\s+                                # initial tab (for surface directions)
(\w+)                                                              # Direction
\s+\:\s+
(\w+)                                                              # Terrain
\s+\(
(\d+,\d+)                                                          # x,y loc
\)\s+in\s+
(\w+)\.                                                            # province
''', re.VERBOSE)

    dirunderpattern = re.compile(r'''\s+                           # initial tab (for underworld directions)
(\w+)                                                              # Direction
\s+\:\s+
(\w+)                                                              # Terrain
\s+\(
(\d+,\d+),underworld                                               # x,y loc in the underworld
\)\s+in\s+
(\w+)\.                                                            # province
''', re.VERBOSE)

    dircitypattern = re.compile(r'''\s+                            # (directions which include a city)
(\w+)                                                              # Direction
\s+\:\s+
(\w+)                                                              # Terrain
\s+\(
(\d+,\d+)                                                          # x,y loc
\)\s+in\s+
(\w+)                                                              # province
,\s+contains\s+
(\w+)
''', re.VERBOSE)

    dirundercitypattern = re.compile(r'''\s+                       # directions with a city in the underworld
(\w+)                                                              # Direction
\s+\:\s+
(\w+)                                                              # Terrain
\s+\(
(\d+,\d+),underworld                                               # x,y loc in the underworld
\)\s+in\s+
(\w+)                                                              # province
,\s+contains\s+
(\w+)
''', re.VERBOSE)

    dictstring=None
    wibble = None

          # the following sections use the regular expressions defined above to search the report lines
          # to identify regions in the report. If they locate a region, each of the region portions will
          # have been extracted/parsed by the regular expression and can be separately grabbed
    if wibble == None:
         wibble = re.compile(globals.xnexusregionpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                      # search for the region (nexus)
         if wibble != None:                                           # we found the nexus !
             thisregion = {}
             thisregion['terrain']='nexus'                            # Nexus terrain
             thisregion['x']=wibble.groups()[0]                       # x co-ord
             thisregion['y']=wibble.groups()[1]                       # y co-ord
             thisregion['underworld']='nexus'                         # the level it is on
             thisregion['province']=wibble.groups()[2]                # province name
             thisregion['settlename']=None                            
             thisregion['settletype']=None
             thisregion['pop']=0
             thisregion['race']=''
             thisregion['maxtax']=0

    if wibble == None:
         wibble = re.compile(globals.xoceanpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                      # search for the region (ocean)
         if wibble != None:                                           # we found an ocean region
             thisregion = {}
             thisregion['terrain']='ocean'                            # Nexus terrain
             thisregion['x']=wibble.groups()[0]                       # x co-ord
             thisregion['y']=wibble.groups()[1]                       # y co-ord
             thisregion['underworld']='no'                            # the level it is on
             thisregion['province']=wibble.groups()[2]                # province name
             thisregion['settlename']=None                            
             thisregion['settletype']=None
             thisregion['pop']=0
             thisregion['race']=''
             thisregion['maxtax']=0

    if wibble == None:
         wibble = re.compile(globals.xoceanunderpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                      # search for the region (ocean)
         if wibble != None:                                           # we found an ocean region in the underworld
             thisregion = {}
             thisregion['terrain']='ocean'                            # Nexus terrain
             thisregion['x']=wibble.groups()[0]                       # x co-ord
             thisregion['y']=wibble.groups()[1]                       # y co-ord
             thisregion['underworld']='yes'                           # the level it is on
             thisregion['province']=wibble.groups()[2]                # province name
             thisregion['settlename']=None                            
             thisregion['settletype']=None
             thisregion['pop']=0
             thisregion['race']=''
             thisregion['maxtax']=0

    if wibble == None:
         wibble = re.compile(globals.xcityunderpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                    # search for the region (city underworld)
         if wibble != None:                                         # we found an underworld city !
             thisregion = {}
             thisregion['terrain']=wibble.groups()[0]
             thisregion['x']=wibble.groups()[1]
             thisregion['y']=wibble.groups()[2]
             thisregion['underworld']='yes'
             thisregion['province']=wibble.groups()[3]
             thisregion['settlename']=wibble.groups()[4]
             thisregion['settletype']=wibble.groups()[5]
             thisregion['pop']=wibble.groups()[6]
             thisregion['race']=wibble.groups()[7]
             thisregion['maxtax']=wibble.groups()[8]

    if wibble == None:
         wibble = re.compile(globals.xcitypattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                     # search for a surface city region
         if wibble != None:
             thisregion = {}
             thisregion['terrain']=wibble.groups()[0]
             thisregion['x']=wibble.groups()[1]
             thisregion['y']=wibble.groups()[2]
             thisregion['underworld']='no'
             thisregion['province']=wibble.groups()[3]
             thisregion['settlename']=wibble.groups()[4]
             thisregion['settletype']=wibble.groups()[5]
             thisregion['pop']=wibble.groups()[6]
             thisregion['race']=wibble.groups()[7]
             thisregion['maxtax']=wibble.groups()[8]

    if wibble == None:
        wibble = re.compile(globals.xregionunderpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                      # search for a normal underworld region
        if wibble != None:
            thisregion = {}
            thisregion['terrain']=wibble.groups()[0]
            thisregion['x']=wibble.groups()[1]
            thisregion['y']=wibble.groups()[2]
            thisregion['underworld']='yes'
            thisregion['province']=wibble.groups()[3]
            thisregion['settlename']=None
            thisregion['settletype']=None
            thisregion['pop']=wibble.groups()[4]
            thisregion['race']=wibble.groups()[5]
            thisregion['maxtax']=wibble.groups()[6]
                
    if wibble == None:
         wibble = re.compile(globals.xregionpattern, re.VERBOSE).search(report[lineindex][:-1])
                                                                      # search for a normal surface region
         if wibble != None:
             thisregion = {}
             thisregion['terrain']=wibble.groups()[0]
             thisregion['x']=wibble.groups()[1]
             thisregion['y']=wibble.groups()[2]
             thisregion['underworld']='no'
             thisregion['province']=wibble.groups()[3]
             thisregion['settlename']=None
             thisregion['settletype']=None
             thisregion['pop']=wibble.groups()[4]
             thisregion['race']=wibble.groups()[5]
             thisregion['maxtax']=wibble.groups()[6]
            
    if wibble == None:                            # no regions found so go around and try again
        return None
    #print "region:("+thisregion['x']+','+thisregion['y']+") - "+str(thisregion['settlename'])
    #Weather
    #print 'weather:'+report[lineindex+2]         # get the weather, we are only interested in clear 
                                                  # or not clear, don't care about winter, monsoon etc
    weather = report[lineindex+2][:-1].split(';', 1)
    if (weather[0] == ' The weather was clear last month') or (weather[0] == 'The weather was clear last month'):
        thisregion['lastweather'] = 'clear'
    else:
        thisregion['lastweather'] = 'not clear'
    if (weather[1] == ' it will be clear next month.') or (weather[1] == 'it will be clear next month.'):
        thisregion['weather'] = 'clear'
    else:
        thisregion['weather'] = 'not clear'

    if thisregion['underworld']=='nexus':
        thisregion['comment']=report[lineindex+3][:-1]
        #print "nexus comment:",thisregion['comment']+"::"
        lineindex+=1
            
    #Wages
    #print 'Wages:'+report[lineindex+3]
    if report[lineindex+3][:-1] != 'Wages: $0.' and \
        report[lineindex+3][:-1] != ' Wages: $0.':             # separate out the wages
        wages = re.search('\$(\d+).*?\$(\d+)', report[lineindex+3])   # use regular expression to parse it
        if wages != None:                                      # if any wages are listed
            thisregion['wages'] = int(wages.groups()[0])       # then get the wage rate
            thisregion['wagesmax'] = int(wages.groups()[1])    # and the maximum that can be earned in the region
    else:
        #print "No Wages!"
        thisregion['wages'] = int(0)                           # otherwise set it to No wages
        thisregion['wagesmax'] = int(0)
                
    #Wanted and For Sale
    if thisregion['underworld']=='nexus':
        thisregion['wanted'] = 0                               # nothing is wanted in the Nexus
    else:
        ignored,stuff = report[lineindex+4].split(': ', 1) 
        stuff,ignored = stuff.split('.', 1)                    # separate all the wanted items strings
        itemlist = stuff.split(', ')                           # break it into a list
        thisregion['wanted'] = itemlist                        # store it in the region dictionary

    if thisregion['underworld']=='nexus':
        thisregion['forsale'] = 0                              # nothing for sale in the nexus
    else:
        ignored,stuff = report[lineindex+5].split(': ', 1)
        stuff,ignored = stuff.split('.', 1)                    # separate all the forsale items strings
        itemlist = stuff.split(', ')                           # break then into a list
        thisregion['forsale'] = itemlist                       # store it in the region dictionary
            
    #Entertainment
    if thisregion['underworld']=='nexus' or thisregion['terrain']=='ocean':
        thisregion['entertain'] = 0                            # no entertainment available in the nexus or ocean
    else:
        ente = re.search('\$(\d+)\.', report[lineindex+6])     # find the entertainment
        if ente != None:
            thisregion['entertain'] = int(ente.groups()[0])    # store it in the region

    if thisregion['terrain']=='ocean':                         # line layout between ocean and regions is different
        lineindex-=1                                           # so get the line counter back into sync again
            
    #Products
    if thisregion['underworld']=='nexus':
        thisregion['products'] = None                          # no products in the nexus
    else:
        ignored,stuff = report[lineindex+7].split(': ', 1)
        stuff,ignored = stuff.split('.', 1)                    # separate out all the products item strings
        itemlist = stuff.split(', ')                           # break them into a list
        thisregion['products'] = itemlist                      # store it in the region dictionary

    if thisregion['underworld']=='nexus':                      # line layout between nexus and regions is different
        lineindex-=2                                           # so get the line counter back into sync again
            
    #Exits
    #exitlist = ['North','Northeast','Southeast','South','Southwest','Northwest']
    hexdirections = {}                                         # setup blank list of exits from the region
    counter = lineindex+9                                      # jump to the right line
    while 1:                                                   # keep going until we run out of exits
        try:
            temp,rest = report[counter].split(' : ', 1)        # separate direction from destination region
            rest,ignored = rest.split('.', 1)                  # break out the directions details
            temp = temp.strip()                                # discard whitespace
            if temp in directiondict.keys():                   # if it matches a valid direction 
                #print "Found an exit!", temp
                                                               # NB: this assumes that terrain is one word...
                terrain, coord, ignored, regionname = rest.split(' ', 3)   # split out the details
                regionname = regionname.strip()                            # remove whitespace
                hexdirections[temp]=[terrain, coord, regionname]           # save in the directions dictionary
                #print coord," ",terrain," ",regionname
        except ValueError:                                     # No : found, so finished with exits now
            pass
                
        counter += 1                                      # increment linecounter
        if (counter==len(report)) or          \
            ((report[counter].startswith('*')) or (report[counter].startswith('------'))    \
            or (report[counter].startswith(';***') or (report[counter]=='#end'))):
                                                          # process directions until we get to the units or blanks
                thisregion['directions'] = hexdirections      # put all the directions into the region
                break

    return thisregion                                     # and pass back the completed, parsed region 

def mergeall(inreport, inmaster, repturn, mastturn, settings, fullmerge):
    """Given a report and a parsed master file, return a merged report as a dictionary."""
    """if 'fullmerge'= Y, it does a full merge, """
    """if 'fullmerge'=N it does a partial merge, specifically for multifaction reports"""

    firstunit = 'no'
    orders = ''
    maxfactionfound = 0
    buildno=0
    
    template=[]                                                  # set up blank template
    prelude=[]                                                   # and blank prelude sections
                           # Need to concatenate lines in the report if they don't have a . on the end!
    workreport = fixreport(inreport)
    reportfaction = getreportfaction(inreport)                   # find out the faction number for the report
    version = getversion(inreport)                       # find out the atlantis version number for the report
    #if is406(version):
    #   print "its 4.0.6"
    #if is409(version):
    #   print "its 4.0.9"
    #if is410(version):
    #   print "its 4.0.10"

    if mastturn == 0 or len(inmaster)==0:                        # if its the first time through the parser
        region = {}                                              # initialise all the holding dictionaries
        units={}
        buildings={}
        unitbynum={}
        skilllist= {}
        faction= {}
        allitems= {}
        battles= []
        print "reset battles:"+fullmerge
    else:                                                        # otherwise take dictionaries from the parsed master
        region = inmaster[1]    
        units = inmaster[2]    
        template = inmaster[3]    
        prelude = inmaster[4]
        buildings = inmaster[5]
        unitbynum = inmaster[6]
        skilllist = inmaster[7]
        faction = inmaster[8]
        allitems = inmaster[9]
        battles = inmaster[10]

    if settings['factionid']==0 or settings['factionid']==None:    # if we don't know what faction we are parsing for
        settings['factionid']==reportfaction                       # then default to the current report faction

    if not faction.has_key('factionid'):                           # if not already set up
        faction['factionid']=settings['factionid']                 # then set to the current settings faction

    report=inreport
    tempwork=workreport
    if repturn > mastturn and             \
        ((settings['doallfactions']=='Yes') or (reportfaction==settings['factionid'])):
                                              # only overwrite if is the most recent and either our faction 
                                              # or we are merging multiple factions together
        template=[]
        prelude=[]
        units={}                                                    #  clear out the units and start again
        unitbynum = {}
        print "resetting battles:"+fullmerge
        battles = []

    if repturn >= mastturn and \
              ((settings['doallfactions']=='Yes') or (reportfaction==settings['factionid'])):
                                                                    # only overwrite if is our faction and more recent
        inorders = 0
        for line in inreport:                                       # process all the orders template
            if line.startswith('Orders Template'):                  # into their own orders template list
                inorders=1                                          # used by autobots etc, 
            if inorders:                                            # and regenerating the merged super report
                template.append(line)
                if line.startswith('#end'):
                    break

        saveprelude = 0
        for line in report:                                          # collect all the battles and past actions
            if line.startswith('Atlantis Report'):                   # into its own separate list
                saveprelude=1                                        # currently only used to regenerate the
            if saveprelude:                                          # merged super report
                lineindex = report.index(line)
                if lineindex < len(report):
                    if (not line.startswith('Skill reports')) and (not line.startswith('Declared Attitudes')):
                        prelude.append(line)
                    else:
                        break

        faction['attitudes'] = parseattitudes(tempwork)              # collect all the factions friendly/ally setting
        test = parsemove(tempwork, region)
        #print faction['attitudes']

        settings['version'] = version                                # keep the most recent version number

        for line in report:
            if line.startswith('Unclaimed silver'):
                ignored, faction['unclaimedsilver'] = line[:-2].split(': ')  # store their unclaimed silver
                break
        if fullmerge=="Yes":
            battles = parsebattles(report, battles)                  # collect all the known items into a single list

    skilllist = parseskills(tempwork, skilllist)                     # collect all their known skills into a single list
    allitems = parseitems(tempwork, allitems)                        # collect all the known items into a single list

    # Here we parse the report and template lists to get out relevant info.
    # First, set up some regexps to get out relevant info.
    
    # Now, go through each region and pull out info
    # Might be easier to do with split/string stuff, too
    dictstring=None

    report=workreport
    for line in report:
        lineindex = report.index(line)
        if lineindex+1 < len(report) and report[lineindex+1].startswith('---'):
            #the current line must be the start of a region
            #print "Report. Found a region:",report[lineindex]
            thisregion = parseregion(report, lineindex)
            if thisregion == None:
                continue

            #   Now that we have all the info, commit it to 'memory'
            if thisregion['underworld']=="nexus":
                dictstring = thisregion['x']+','+thisregion['y']+',nexus'
            elif thisregion['underworld']=="no":
                dictstring = thisregion['x']+','+thisregion['y']
            else:
                dictstring = thisregion['x']+','+thisregion['y']+',underworld'
            # print "saving :"+dictstring
            itemlist = thisregion['products']
            try:
                if region.has_key(dictstring) and thisregion['underworld']!="nexus":
                    #print "just overwriting stuff in '"+dictstring+"'"

                    del region[dictstring]
                    region[dictstring]=thisregion
                    #newregion={}
                    #newregion[dictstring]=thisregion
                    #region.update(newregion)

                else:
                    region[dictstring]=thisregion
                    #print "not found. doing :'"+dictstring+"'"
            except KeyError:
                region[dictstring]=thisregion
                #print "keyerror. doing :'"+dictstring+"'"

            # and initialise the list of units
            if repturn >= mastturn and \
                ((settings['doallfactions']=='Yes') or (reportfaction==settings['factionid'])):
                                                                             # only overwrite if is our faction
                if not units.has_key(dictstring):
                    units[dictstring]=[]

            # and initialise the list of buildings
            buildings[dictstring]=[]
            buildno = 0

                           # Now lets pick up any buildings in the region
        thisbuilding={}
        if  line.startswith('+'):                        # marker for buildings
            thisbuilding=parsebuilding(line)             # so parse the line and return the building
            if len(thisbuilding)>0:                      # if we got a building back
                buildno=int(thisbuilding['id'])              # store the id for later units
                if dictstring not in buildings.keys():
                    buildings[dictstring]=[]
                if thisbuilding not in buildings[dictstring]:    # time 2
                    buildings[dictstring].append(thisbuilding)   # add the building to the list

                # We only want to overwrite if it is our faction and a more recent report file
        if repturn < mastturn:
            continue
        if (settings['doallfactions']!='Yes') and reportfaction!=settings['factionid']:
            continue

        # Now for the units...
        unitstarts2 = ['= ', ': ', '- ', '% ', '! ', '* ']
        unitstarts3 = [' * ', ' - ', ' : ', ' = ', ' % ', ' ! ']
        if  (line[:2] in unitstarts2) or (line[:3] in unitstarts3):
            #if line[:3] in unitstarts:
            #    print "indent:"+line
            unit = {}
            unit['skills']=[]
            unit['items']=[]
            
            if line.strip().startswith('*'):
                unit['mine']='yes'
            else:
                unit['mine']='no'
            
            # If the next line begins with two spaces, 
            # we know we've split a line at the wrong point
            lineindex = report.index(line)+1
            while (lineindex<len(report) and report[lineindex].startswith(' ')) and   \
                        (not report[lineindex][:3] in unitstarts3) :
                #print "joined up some lines:"+report[lineindex]
                line += report[lineindex]
                lineindex += 1
                
            #print "***MATCH***: found a unit:"
            #print line
            
            # what about comments? split the comment off first,
            # since we might have ., in the comment
            if ';' in line:
                line, ignored = line.split(';')
                line=line+'.'

                          # Some units have a fullstop in their unit or faction name. This breaks the parsing badly
            workline=line
            # print "Unit line:"+line
            holdline=''
            stpos=line.find('.',3,len(line))                  # find the first fullstop
            brpos=line.find('[',3,len(line))                  # find the first left square bracket (on an item)
            if (stpos > -1) and (stpos < brpos):              # if the fullstop occurs before the left bracket
                workline=line[brpos-1:]                       # grab from the unit number on
                holdline=line[:brpos-1]                       # store the name section (with the fullstop in it)
                #print 'hold:'+holdline+' work:'+workline

            temp = workline.split('.')                        # check how many separate componants are in here
            if is406(version) or is409(version):
                if len(temp)==3:                                  # Normal unit
                    unit['main'], unit['skillbit'], ignored = workline.split('.')
                    unit['combatspell']=unit['weight']=unit['capacity']=unit['spells']=None
                    #print "Found a normal unit!"
                elif len(temp)==2:                                # Not one of our units
                    unit['main'], ignored = workline.split('.')
                    unit['combatspell']=unit['spells']=unit['weight']=unit['capacity']=unit['skillbit']=None
                    #print "Found another faction's unit!"
                elif len(temp)==4:                                # Mage unit with no combat spell
                    unit['main'], unit['skillbit'], unit['spells'], ignored = workline.split('.')
                    unit['combatspell']=unit['weight']=unit['capacity'] = None
                    #print "Found a mage unit! (no combat spell)"
                elif len(temp)==5:                                # Mage unit
                    unit['main'], unit['skillbit'], unit['combatspell'], \
                             unit['spells'], ignored = workline.split('.')
                    unit['weight']=unit['capacity']=None
                    #print "Found a mage unit!"
                else:                                              # something unexpected
                    #print "Found a wacky unit, with "+str(len(temp))+" parts:",line
                    unit['main'], ignored = workline.split('.')
                    unit['combatspell']=unit['spells']=unit['weight']=unit['capacity']=unit['skillbit']=None
                    #continue
            elif is410(version):
                if len(temp)==5:                                  # Normal unit
                    unit['main'], unit['weight'], unit['capacity'], unit['skillbit'], ignored = line.split('.')
                    unit['combatspell']=unit['spells']=None
                    #print "Found a normal unit!"
                elif len(temp)==2:                                # Not one of our units
                    unit['main'], ignored = workline.split('.')
                    unit['combatspell']=unit['spells']=unit['weight']=unit['capacity']=unit['skillbit']=None
                    #print "Found another faction's unit!"
                elif len(temp)==6:  # Mage unit with no combat spell
                    unit['main'], unit['weight'], unit['capacity'], \
                                unit['skillbit'], unit['spells'], ignored = line.split('.')
                    unit['combatspell'] = None
                    #print "Found a mage unit! (no combat spell)"
                elif len(temp)==7:  # Mage unit
                    unit['main'], unit['weight'], unit['capacity'], unit['skillbit'], \
                           unit['combatspell'], unit['spells'], ignored = line.split('.')
                else:                                              # something unexpected
                    #print "Found a wacky unit, with "+str(len(temp))+" parts:",line
                    unit['main'], ignored = workline.split('.')
                    unit['combatspell']=unit['spells']=unit['weight']=unit['capacity']=unit['skillbit']=None
                    #continue

            if (holdline > ''):                                 # parsing over so we can join the string up again
                 unit['main'] = holdline + unit['main']         # since holdline has a fullstop somewhere in the name

            #Grab the unit number and faction number
            wibble = re.search('(.*)\((\d+)\).*\((\d+)\)', unit['main'])
            #print "main:"+unit['main']+"  skills:'"+str(unit['skillbit'])+"'"
            if wibble != None and len(wibble.groups()) == 3:
                unit['faction'] = int(wibble.groups()[2])
                unit['unitnum'] = int(wibble.groups()[1])
                tempname=wibble.groups()[0]
                if  (tempname[:2] in unitstarts2):
                    unit['name'] = tempname[2:]
                elif (tempname[:3] in unitstarts3):
                    unit['name'] = tempname[3:]
                #print "Merge : FN =="+str(unit['faction'])+" and UN =="+str(unit['unitnum'])+" name="+unit['name']
                if unit['faction'] > maxfactionfound:
                    maxfactionfound = unit['faction']
            
            else:
                wibble = re.search('(.*)\((\d+)\)', unit['main'])
                if wibble != None and len(wibble.groups()) == 2:
                    tempname=wibble.groups()[0]
                    if  (tempname[:2] in unitstarts2):
                        unit['name'] = tempname[2:]
                    elif (tempname[:3] in unitstarts3):
                        unit['name'] = tempname[3:]
                    unit['unitnum'] = int(wibble.groups()[1])
                    unit['faction'] = 0
            
            unit['building']=buildno
            itemlist=unit['main'].split(',')
            #print "item="+str(itemlist)
            for item in itemlist:
                if '[' in item:
                    #print item, "is an item!"
                    unit['items'].append(item)
            
            if unit['skillbit'] != None:
                if unit['skillbit'].startswith(' Skills:'):
                    unit['skillbit']=unit['skillbit'][8:]
                    #print "skill="+unit['skillbit']
                itemlist=unit['skillbit'].split(',')
                #print itemlist
                for skill in itemlist:
                    if '[' in skill:
                        #print skill, "is a skill!"
                        unit['skills'].append(skill)

            # record where the unit is located, in case we need it somewhere
            unit['location']=dictstring
            oldunit=unit

            # Add the unit to unitbynum if its not already there
            if unitbynum.has_key(unit['unitnum']):
                unit=updateunit(unitbynum[unit['unitnum']], unit)
                #print 'Deleting :'+str(unit['unitnum'])
                del unitbynum[unit['unitnum']]

            unitbynum[unit['unitnum']] = unit

            # Need the region dictstring at this point... should be ok
            #if dictstring==None: #we're in the nexus
            #    if 'nexus' not in units.keys():
            #        units['nexus']=[]
            #    units['nexus'].append(unit)
            #else:
            try:
                unitindex = units[dictstring].index(oldunit)
                #print "index="+str(unitindex)
            except:
                unitindex=-1
            if unitindex > 0:
                removedunit=units[dictstring].pop(unitindex)
                #print "removed:"+str(removedunit)
            #print "unit:"+str(unit)
            units[dictstring].append(unit)

    fullreport = {}
    fullreport[1] = region
    fullreport[2] = units
    fullreport[3] = template
    fullreport[4] = prelude
    fullreport[5] = buildings
    fullreport[6] = unitbynum
    fullreport[7] = skilllist
    fullreport[8] = faction
    fullreport[9] = allitems
    fullreport[10] = battles

    #print "unit keys:"+str(unitbynum.keys())
    #print "region keys:"+str(region.keys())

    return fullreport

def mergereport(inreport, inmaster, repturn, mastturn, settings):
    fullreport = mergeall(inreport,inmaster, repturn, mastturn, settings,"Yes")

    return fullreport

def parsereport(inreport, settings):
    fullreport = mergeall(inreport, {}, getturnno(inreport), 0, settings, "Yes")

    return fullreport

def partmerge(inreport, inmaster, repturn, mastturn, settings):
    fullreport = mergeall(inreport,inmaster, repturn, mastturn, settings,"No")

    return fullreport

