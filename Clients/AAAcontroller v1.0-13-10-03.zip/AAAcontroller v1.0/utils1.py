# 26-09-03

# utils 1 general functions and objects used by Fuzzyman




# Prints output to the screen and/or
# logs it to a file - depending on the settings.
#
# Prints output to the screen and/or
# logs it to a file - depending on the settings.
#
# To use this function you need to include verbose (yes if you want to print to screen), 'outputpath' (filename)
# ('' if you don't want to output to a file) and 'logmode'( (w)rite or (a)ppend )
#
class StandOut:
    "Creates an output object that will print *and/or* write to an output file if required."
    def __init__(self,verbose,outputpath,logmode):
        self.verbose=verbose.lower().strip()
        if logmode=='a' and outputpath !='':      # are we appending or creating a newfile ?
            self.outputfile=open(outputpath,'a')
            self.putout('\n\n')
        elif outputpath != '':
            self.outputfile=open(outputpath,'w')
        else:
            self.outputfile=''

    def putout(self,line):
        if self.verbose=='yes':
            print line,
        if self.outputfile != '':
            self.outputfile.write(line)
            
    def outclose(self):
        if self.outputfile != '':
            self.outputfile.close()


#x=StandOut('yes','hello.txt','w')
#x.putout('Hello Baby\n')
#x.putout('Hello Again\n')
#x.outclose()

#print x.outputfile


#############################################################################



# Given a long input line and a maximum line length,
# This function will break the line down into shorter lines, trying not to break any words if possible.
# (Like a wordwrap feature on word processor). It returns a list of line with no \n at the end.
#
def shortlist(inline,linelen):
    outline=[]
    while len(inline)>0:
        if len(inline)<linelen:
            outline.append(inline)
            return(outline)
        temp=inline[:linelen-1]
        if temp.rfind(' ')==-1:
            outline.append(temp)
            inline=inline[linelen:]
        else:
            outline.append(inline[:temp.rfind(' ')])
            inline=inline[temp.rfind(' ')+1:]
                                      
    return(outline)



#
# Given a line getdigits will extract the
# digits from the front of the string and return them as an integer.
# If the line doesn't start with a digit it returns -1
def getdigits(line):
    a=0
    digits=''
    while a<len(line):
        if line[a].isdigit()==1:
            digits=digits+line[a]
            a=a+1
        else:
            break
    if digits=='':
        digits='-1'
    return(int(digits))

#
# Given two dictionaries it will add them together
# (in case of duplicate keys the value in dict2 will prevail)
def adddict(dict1, dict2):
    for key in dict2:
        dict1[key]=dict2[key]
    return(dict1)

#
# Given two lists it merges them - only adding to list1 entries that aren't already there
def listmerge(list1,list2):
    if list1 != list2:
        for member in list2:
            if member not in list1:
                list1.append(member)
    return(list1)



# passed the attitudes from parsereport it
# adds your friends and allies (by faction number) together
# if doallylist and dofriends are set to 'yes'
def attitudelist(attitude,doallylist,dofriends):
    import re
    factiontest=re.compile(r"\(\d+\)")
    parsedlist=[]
    allies=attitude['ally']
    friends=attitude['friendly']
    doallylist=doallylist.strip().lower()

    if doallylist =='yes':
        if allies[0].strip().lower() !='none':
            for member in allies:
                parsedlist.append(factiontest.search(member).group()[1:-1])  

    dofriends=dofriends.strip().lower()
    if dofriends =='yes':
        if friends[0].strip().lower() !='none':
            for member in friends:
                parsedlist.append(factiontest.search(member).group()[1:-1])  

    
    return(parsedlist)



# Given a list of the parameters of a config
# file - it will build the 
# dictionary used by loadconfig and checkconfigfile.
# If the parameter passed to it ends in '[]' it will be made
# a list type.
#
def buildconfig(params):
    outparams={}
    for param in params:
        if param[-2:] !='[]':
            outparams[param]=''
        else:
            outparam[param:-2]="['','','']"
    return(outparams)

# This loads in a config file when passed a filename path.
def loadconfig(configfilename):
    from configutils import readfile
    configfilereader=readfile(configfilename)           # read the file in (if it exists)
    if configfilereader == '':                          # for some reason the returned file contents are blank
        raise Exception(configfilename + ' not found, or file is empty')       # so just close down and finish
                                     
    return configfilereader  


# Given a string it returns it as a list
# of single characters......
def stringtolist(instring):
    num=len(instring)
    a=0
    outlist=[]
    while a<num:
        outlist.append(instring[a])
        a+=1
    return outlist
