# 05-10-03

#from utils1 import StandOut
from utils1 import shortlist, listmerge, adddict
import sys, re
from fileutils import readfile


# object=OrderTemp(inordertemplate)
#
# Works from the order template of a report
# or an order file read in as a list.
#
# It will work out for itself whether or not the input is a map format, long format, short format or extreme short format
# and process accordingly.
#
# This object and it's associated method is used to read in an order file and parse it into it's component elements -
# these can then be added to (for example units given orders) and the file put together again for writing back out as a file.
# It can also be used to convert order files between the different types.
# (e.g. for writing back *into* a report to be loaded into a client...)
#
# Order File Types
# An order file is a file that contains the orders for an atlantis facton it will contain a '#atlantis' line that will
# have the faction number and password and it ought to end with '#end'.
# What extra information it has depends on what format it is.
# An order template is the same information - but it is appended onto the end of an atlantis report. Just cutting and
# pasting this into a text document makes it an order file !
#
# Long format is the normal way a template is sent at the bottom of the report.
# It starts with the line 'Orders Template (Long Format):' before the '#atlantis' line.
# It has a location line, in the following format, before the group of orders for the units *in* that location....
# ;*** mountain (32,0) in Donnais ***
# Each unit has it's description immediately after the unit line :
# ;Osguard (314), on guard, revealing faction, taxing, 143 sea elves
# ;  [SELF], 192 high elves [HELF], 20 nomads [NOMA], 119 horses [HORS],
# ;  46768 silver [SILV]. Skills: combat [COMB] 2 (90).
# That information is all extracted by this object. Any scripts that can work from just this information can use *just* a
# long format order file as their source of information. If this object is give nthe blank order template of a report and
# a short format order file it is capable of re-outputting the order file in long format.
#
# Map format is another one of the ways that a report can send the order template.
# It starts with the line 'Orders Template (Map Format):' before the '#atlantis' line.
# Instead of the location line it has ana scii map of the location with  description. If there is a town or city in the
# location this description can be even longer.
# ;-----------------------------------------------------------
# ;plain (24,0) in Awtorm
# ;         ____
# ; nw     /    \     ne  Next clear
# ;   ____/ #### \____    Tax   3858
# ;  /    \ #### /    \   Ente   192
# ; / #### \____/ #### \  Wage    16 (max 2057)
# ; \ #### /    \ #### /
# ;  \____/      \____/   Sell   128 NOMA @  64
# ;  /    \      /    \           25 LEAD @ 128
# ; /      \____/      \
# ; \      /    \      /  Prod    73 GRAI
# ;  \____/  ~ ~ \____/           20 HORS
# ;       \ ~ ~  /
# ; sw     \____/     se
# Although OrderTemp can read map format order files and rewrite them... it can't yet produce map format files from a report.
# They are reasonably unusual and I would only add this if there was demand !!
#
# Short format is the format used by Atlantis Helper and includes location lines, but not the unit description.
#
# Extreme short format would just be the orders for each unit - with no location line or unit descriptions.
# (I've not seen one of these in the wild though :-).
#
#
# What OrderTemp does
#
# object=OrderTemp(inordertemplate)
# It strips down the inordertemplate - stripping each line and only keeping lines between #atlantis (or the 'format' line)
# and #end(if #end exists) so you can pass it a whole report and it will handle it correctly.
# (extract the order template from the end and discard the rest).
#
# In the following list of results output - those marked '*' are blank for any short format order file.
# '**' will be blank for an 'extreme short format'
#
# object.relocation is a regular expression object for finding a location string (including the underworld if present)
# The location string is enclosed by '(' and ')'
#
# object.flags is a list of the 8 flag strings to search for
#
# object.parentlist is a list of units that have issued 'form' commands this turn
#
# object.ordertemplate is the stripped version of the order template passed to the object
# (or as (re)created by the buildordertemplate method)
#
# object.originalordertemplate always contains the original ordertemplate you passed it (in the stripped format) -
# even after merge and build have been run (which both may change object.ordertemplate)
#
# object.templateformat is the format of the object = -2 map, -1 long, 1 short, 2 extreme short
#
# object.atlline is the line starting #atlantis - with faction number and password
#
# object.preamble is any lines between #atlantis and the first location line - could be used for storing information.
#
# ** object.regiondict is a dictionary of region information (keyed by location string) -
# for every region we have a unit in this has a list -
# [0] = province, [1] = terrain type, [2] = list of unit numbers in this location
# [3] = the location line(s) for rebuilding the ordertemplate later (or the map if in map format)
#
# ** object.provincedict is a dictionary containing the provinces with a list of each location in that province
#
# object.ourunitbynum	Dictionary ourunitbynum containing - for each unit (accessed by number) giving (key shown in '') :
# 'orders' current orders (not including our @;# lines but including comments) 
# 'commands' list of our @;# commands 
# * 'name' 
# * 'flags' - [0]	Revealing Faction, [1]	Avoiding, [2]	Behind, [3]	Hold, [4]	Taxing
# [5]	Guarding, [6]	Receiving No-aid, [7]	Won't cross water. Each position in this list is set to '0' (string)
# for unset and '1' (string) for set.
# * 'mainbit' whole description 
# * 'items' - list of items the unit is holding
# * 'skills' - list of skills the unit has
# * 'canstudy' - if the unit is a mage (or potentially weaponsmith / armorcrafter) it may have skills that it 'can study'
# **'location' - returns the location string
# **'underworld' - 'Yes' or 'No' as to whether the unit is in the underworld
# **'province' - the name of the province the unit is in
#
# 'children' - any new units created by the unit go here (units created using the form command) - a dictionary keyed by the new unit number.
# ['children'][newunitnum] itself has the keys 'orders' and 'commands' for every new unit that exists.
#


###########################
#EXCEPTIONS
#
# Raises an exception if :
# There is no #atlantis line
# There are no 'unit ....' lines
# The same unit is given orders twice in an order template
#(If a unit forms two new units with the same number it will print an error message - but not raise an exception)
#


###########################
# METHODS
#

# object.merge(newordertemplateobject)

# Raises an exception if the #atlantis lines don't match
# Adds two ordertemplateobjects together -
# If they are the same format then newordertemplateobject takes precedence where there are different orders for a unit.
#
# If they are different then the 'shorter' format takes precedence for orders, the 'longer' for information (like name, location, skills etc....)
# Will normally be used to merge in the information from a report(long format) into a short format order file.
# it changes self.templateformat to reflect the new format.

# If the location details etc. contradict - then things might go very wappy. 
# Currently the new parentlist is just created by using the 'shortest' format parentlist - this isn't *garuanteed*
# to be correct - but the orders and children etc themselves will still be correct.
# merge isn't currently designed to combine orders together like this
# but if someone needs it I can sort it.
# (I would just rebuild parentlist as part of the merge mtethod - but it would only be useful if someone was using merge
# to combine part orders together - it will be more normal to use it to merge a report template into a short format
# file).
#

# newordertemplate=object.buildordertemplate(format=0)

# Format defaults to 0 meaning 'longest possible' (i.e. the same as object.templateformat)
# Raises an exception if you ask it to produce a format it is not capable of
# e.g. you ask it to build a long format template when all it has is the information for a short format one
# It puts the new template into object.ordertemplate
# format= -2 means build a map format
# format= -1 means build long format
# format = 1 means build a short format
# format = 2 means build an *extreme* short format
# format = 0 means build the longest we have information for
#
# This method rebuilds object.ordertemplate - which is a list of stripped line - from the unit data it holds
# It also *returns* the new order template as a list of lines terminated with a '\n'. 
#

#############################
# ISSUES  
#
# Having a comment (;) as the first line after the unit description will currently get it included in the 'mainbit'
# (description) for that unit. (and could possibly confuse the skill checking code).
# Does the bare minimum of checking as it goes.... so if the input is invalid it might produce some odd results.... - this one is up to the user :-)
# Doesn't extract from the locationline whether or not there is a town or city there... which it easily could do.
# Currently the lists of skills, items and can study is just raw text - including a leading space and the trailing ',' or '.'
# The flag section doesn't understand the REVEAL UNIT setting... a minor change if anyone wants it.
#

class OrderTemp:
    "The madness and methods of handling order template files."

# __init__ handles creating the 'object' from a raw template or file.

    def __init__(self,inordertemplate):


# Let's set up the variables we're going to use


        foundatlan=0
        foundlong=0
        foundmap=0
        foundunit=0
        self.ordertemplate=[]
        stopagain=0
        foundlocationstring=0
        loclinetest=re.compile(r";(\*\*\* )*[a-zA-Z]+ \(\d+,\d+(,underworld)*\) in [A-Z][a-z A-Z]+")
        
# This is the first pass of the order template - we'll strip it and check it's basically ok
# Has a #atlantis line and at least one 'unit' line 
        for line1 in inordertemplate:
            line=line1.strip()
            if line.lower().startswith('#atlantis')==1:
                if foundatlan==1:
                    raise Exception('Strangely formed order file - more than one #atlantis line.')
                self.atlline=line
                foundatlan=1
            elif line.startswith('Orders Template (Long Format):')==1:
                foundlong=1
            elif line.startswith('Orders Template (Map Format):')==1:
                foundmap=1

            elif line.lower().startswith('unit ')==1:
                foundunit=1
            if foundatlan+foundlong+foundmap>0:
                self.ordertemplate.append(line)
            if line.lower()=='#end':
                stopagain=1
                break
            if foundlocationstring==0:
                if loclinetest.match(line) != None:
                    foundlocationstring=1

        if foundlocationstring==0:        
            self.templateformat=2       # We don't have any location lines - this is a bare minimum order file - 'extreme short format'
        elif foundlong==1:              # This is a long format order file, we have location lines and unit descriptions (Like the order template in a report)
            self.templateformat=-1      
        elif foundmap==1:               # This is a map format order file / template                           
            self.templateformat=-2
        else:                           # This is a 'short format' order file - like the type used by ALH. We have location lines but no unit descriptions.
            self.templateformat=1

        if stopagain==0:
            self.ordertemplate.append('#end')           # This way we always know we have reached the end of the ordertemplate - we reach the '#end' line.
        self.originalordertemplate=self.ordertemplate        

        if foundatlan == 0 or foundunit==0:         # Either no units or no #atlantis line
            raise Exception('Invalid Atlantis Order Template passed to template_processor.\nEither no units or no #atlantis line')

# This tests for the presence of #atlantis and at least one 'unit' line - checks for long format, short format or *extreme* short format (absence even of location lines)


# Let's set up some more variables we're going to use

        numlines=len(self.ordertemplate)
        self.parentlist=[]
        
        self.relocation=re.compile(r"\(\d+,\d+(,underworld)*\)")    # This will extract the location string from a line - including ( )
        bigprovince=re.compile(r"\) in [A-Z a-z]+")                # This will extract the province name part of a location line
        miniprovince=re.compile(r"[A-Z][A-Z a-z]+")                     # This will extract the province name from the above fragment
        bigterrain=re.compile(r";(\*\*\* )*[a-zA-Z]+ \(")              # This will extract the terrain type part of a location line
        miniterrain=re.compile(r"[a-zA-Z]+")                        # This will extract the terrain type from the above fragment
        unitnumber=re.compile(r"\(\d+\),")                          # This will extract the unit number from the description
        self.flags=['revealing faction','avoiding','behind','holding','taxing','on guard','receiving no aid',"won't cross water"]
        finditems=re.compile(r"([0-9 ]*[a-z ]+ \[[A-Z][A-Z][A-Z][A-Z]\][,.])")            # From the unit description it will find items (or skills in the 'can study' portion) - will include the trailing ',' or '.'
        findskills=re.compile(r"([a-z ]+ \[[A-Z][A-Z][A-Z][A-Z]\] \d \(\d+\))")           # From the unit description it will find skills the unit has 

# ;*** cavern (6,16,underworld) in Sobabaho ***
# ;*** tundra (14,4) in Tiaougha ***
# ;*** mountain (32,2) in Donnais,


#;-----------------------------------------------------------
#;tundra (15,3) in Tiaougha
#;         ____
#; nw     /    \     ne  Next clear
#;   ____/  ~ ~ \____    Tax    350
#;  /    \ ~ ~  /    \   Ente    17
#; /  ~ ~ \____/  ' ' \  Wage    12 (max 420)
#; \ ~ ~  /    \ ' '  /
#;  \____/  ' ' \____/   Sell    35 SELF @  48
#;  /    \ ' '  /    \            7 LEAD @  96
#; /  ' ' \____/  ' ' \
#; \ ' '  /    \ ' '  /  Prod    17 GRAI
#;  \____/  ' ' \____/           13  FUR
#;       \ ' '  /                11 HERB
#; sw     \____/     se


#;-----------------------------------------------------------
#;underforest (10,2,underworld) in Githsoroth, contains Athbrod [city]
#;         ____
#; nw     /    \     ne  Next clear
#;   ____/ #### \____    Tax  12156
#;  /    \ #### /    \   Ente   607
#; / #### \____/  ^ ^ \  Wage    14 (max 8509)
#; \ #### /    \ ^ ^  /
#;  \____/Athbro\____/   Want   176 GRAI @  20
#;  /    \ ^ ^  /    \          172 LIVE @  26
#; /  ^ ^ \____/  ^ ^ \          51 HERB @  60
#; \ ^ ^  /    \ ^ ^  /          48 CARM @ 101
#;  \____/ #### \____/            9 DBOW @ 350
#;       \ #### /                34 LASS @ 101
#; sw     \____/     se          43 CLAR @  69
#;                               46 BAXE @ 158
#;                               37 IVOR @ 146
#;                               43 TRUF @ 135
#; 
#;                       Sell    36 IRON @  50
#;                               43 WAGO @ 178
#;                               57 PICK @  99
#;                               47 HAMM @ 105
#;                               44 LANC @ 193
#;                               30 VODK @  84
#;                               42 SILK @  85
#;                              607 UDWA @  56
#;                              121 LEAD @ 112
#; 
#;                       Prod    13 LIVE
#;                               12 WOOD
#;                               17 STON
#;                               14 IRON

#;-----------------------------------------------------------


        currentunit=0
        currentline=1       # We'll start at 1 because line 0 will always be the #atlantis line or format line
        currentloc=''
        currentterrain=''
        currentprovince=''
        self.regiondict={}
        self.ourunitbynum={}
        self.provincedict={}
        self.preamble=[]
        foundatlant=0
# This is the second pass that is actually going to parse the order template into the information we want

        while currentline < numlines:
            line = self.ordertemplate[currentline]
            if line=='':
                currentline+=1
                continue
            if line.lower().startswith('#atlantis')==1:
                currentline+=1
                continue
            if self.templateformat==-2 and line.startswith(';-------------------------')==1:
                currentline+=1
                continue

            loclinetestobject = loclinetest.match(line)
            if loclinetestobject != None:                  # This is a location line 
                locline=loclinetestobject.group()
                currentloc=self.relocation.search(locline).group()[1:-1]        # Extract the location string from it.
                currentprovince=miniprovince.search(bigprovince.search(locline).group()).group()    # Extract the province name
                currentterrain=miniterrain.search(bigterrain.search(locline).group()).group()    # Extract the terrain type
                if self.provincedict.has_key(currentprovince)==0:       # Is the current location in the province dictionary ?
                    self.provincedict[currentprovince]=[currentloc]
                else:
                    self.provincedict[currentprovince].append(currentloc)
                if self.templateformat != -2 :                                              # If we haven't got a map format
                    self.regiondict[currentloc]=[currentprovince,currentterrain,[],line]         # Add the region to the dictionary
                    currentline+=1
                else:
                    currentloclines=[]
                    currentline-=1
                    while self.ordertemplate[currentline].startswith(';')==1:
                        currentloclines.append(self.ordertemplate[currentline])
                        currentline+=1
                    self.regiondict[currentloc]=[currentprovince,currentterrain,[],currentloclines]
                
                continue

            if line.lower().startswith('unit ') !=1 and currentunit==0:
                if currentloc=='':
                    self.preamble.append(line)              # Save any data between the #atlantis line and the first unit line in preamble
                currentline+=1
                continue

            elif line.lower().startswith('unit ') == 1:
                currentunit=int(line[5:].strip())
                if self.ourunitbynum.has_key(currentunit)==1:
                    raise Exception('Unit '+str(currentunit)+ " appears more than once in the Order Template.\nVery odd - I'm confused.")

                self.ourunitbynum[currentunit]={}
                self.ourunitbynum[currentunit]['children']={}                   # Set up a blank dictionary for any children this unit may form
                self.ourunitbynum[currentunit]['terrain']=''                    # Set up the defaults as empty in case we have a short format or extreme short format
                self.ourunitbynum[currentunit]['province']=''
                self.ourunitbynum[currentunit]['location']=currentloc           # This will just be '' if we haven't found any location lines
                self.ourunitbynum[currentunit]['underworld']=''
                self.ourunitbynum[currentunit]['skills']=[]
                self.ourunitbynum[currentunit]['items']=[]
                self.ourunitbynum[currentunit]['flags']=[]
                self.ourunitbynum[currentunit]['canstudy']=[]
                self.ourunitbynum[currentunit]['name']=''
                self.ourunitbynum[currentunit]['mainbit']=''
                self.ourunitbynum[currentunit]['orders']=[]
                self.ourunitbynum[currentunit]['commands']=[]
                                               

                if currentloc != '':                                            # Fill in the location data
                    self.regiondict[currentloc][2].append(currentunit)
                    self.ourunitbynum[currentunit]['terrain']=currentterrain
                    self.ourunitbynum[currentunit]['province']=currentprovince

                    if currentloc.find('underworld')!=-1:
                        self.ourunitbynum[currentunit]['underworld']='Yes'
                    else:
                        self.ourunitbynum[currentunit]['underworld']='No'

                currentline +=1                        
                if self.templateformat > 0:                   #   It's not map or long format so we're not expecting unit description                    
                    continue
                else:                                           # This is map or long format - so we can extract names, skills, items etc.
                    currentunitdescription=''

#;Guardians (915), on guard, revealing faction, holding, taxing, 49 sea
#;  elves [SELF], caviar [CAVI], 15961 silver [SILV]. Skills: combat
#;  [COMB] 2 (90).                    
#
#;Estates Keeper (1303), behind, revealing faction, holding, 2628 silver
#;  [SILV], leader [LEAD]. Skills: observation [OBSE] 2 (90), combat
#;  [COMB] 1 (30).

                    while self.ordertemplate[currentline].startswith(';')==1:
                        temp=self.ordertemplate[currentline][1:].strip()+' '
                        currentunitdescription=currentunitdescription+temp
                        currentline+=1
                    self.ourunitbynum[currentunit]['mainbit']=currentunitdescription
                    self.ourunitbynum[currentunit]['name']=currentunitdescription[:unitnumber.search(currentunitdescription).start()-1]       # Up to the left of the unit number is the name
                    flagson=currentunitdescription[unitnumber.search(currentunitdescription).end():]                                 # From the right of it are the flags, items and skills.
                    if flagson.find(';') != -1:     #   If there's a comment at the end of the unit description then we'll chop it off
                        flagson=flagson[:flagson.find(';')]

                    self.ourunitbynum[currentunit]['flags']=['0','0','0','0','0','0','0','0']       # Lets' test for the flags
                    c=0
                    while c<8:
                        if flagson.find(self.flags[c])!=-1:
                            self.ourunitbynum[currentunit]['flags'][c]='1'
                        c=c+1
                    itemline=flagson[:flagson.find('Skills:')].strip()                  # Contains the flags and the items. (A unit *always* has at least one item !!)
                    skillline=flagson[flagson.find('Skills:')+8:].strip()               # Note - if this is a mage (or weaponsmith / armourcafter) it will include the 'can study' part....

#;Entish Cantor (74), avoiding, behind, holding, leader [LEAD], 564
#;  silver [SILV]. Skills: pattern [PATT] 2 (90), spirit [SPIR] 2 (150),
#;  gate lore [GATE] 2 (90), force [FORC] 3 (195), artifact lore [ARTI]
#;  2 (90), enchant swords [ESWO] 1 (30), enchant armor [EARM] 1 (60),
#;  earth lore [EART] 1 (30), necromancy [NECR] 1 (60), farsight [FARS]
#;  1 (30), demon lore [DEMO] 2 (90). Can Study: fire [FIRE], earthquake
#;  [EQUA], force shield [FSHI], energy shield [ESHI], spirit shield
#;  [SSHI], magical healing [MHEA], farsight [FARS], mind reading
#;  [MIND], weather lore [WEAT], earth lore [EART], wolf lore [WOLF],
#;  bird lore [BIRD], necromancy [NECR], summon skeletons [SUSK], create
#;  aura of fear [FEAR], banish undead [BUND], summon imps [SUIM],
#;  banish demons [BDEM], illusion [ILLU], enchant swords [ESWO],
#;  enchant armor [EARM].
                        

                    canstudy=[]
                    skilllist=[]
                    itemlist=finditems.findall(itemline)
                    if skillline!='none.':
                        if skillline.find('Can Study:')!=-1:
                            canstudyline=skillline[skillline.find('Can Study:')+11:].strip()
                            skillline=skillline[:skillline.find('Can Study:')].strip()
                            canstudy=finditems.findall(canstudyline)
                        skilllist=findskills.findall(skillline)

                    self.ourunitbynum[currentunit]['skills']=skilllist
                    self.ourunitbynum[currentunit]['items']=itemlist
                    self.ourunitbynum[currentunit]['canstudy']=canstudy
            
            elif line.lower().startswith('form ') ==1:                               # The line we are on doesn't start with 'unit'
                # Tricky one - we're onto a child unit
                if currentunit not in self.parentlist:
                    self.parentlist.append(currentunit)
                newunitnum=int(line[5:].strip())
                tempneworders=[]
                tempnewcommands=[]
                currentline+=1
                while self.ordertemplate[currentline].lower()!='end' and self.ordertemplate[currentline].lower().startswith('form ')!=1 and self.ordertemplate[currentline].lower() !='#end' and self.ordertemplate[currentline].lower().startswith('unit ') != 1 and loclinetest.match(self.ordertemplate[currentline]) == None:       # assuming a simple form/ end structure here     
                    if self.ordertemplate[currentline].startswith('@;#')!=1:
                        tempneworders.append(self.ordertemplate[currentline])
                        currentline+=1
                    else:
                        tempnewcommands.append(self.ordertemplate[currentline][3:].lstrip())
                        currentline+=1
                else:
                    if self.ordertemplate[currentline].lower()=='end':
                        currentline+=1


                if tempneworders !=[]:
                    while tempneworders[-1:]=='':                           # We'll remove the last blank lines of the ordersection, and add it back in when we write an order file.
                        tempneworders=tempneworders[:-1]

                if self.ourunitbynum[currentunit]['children'].has_key(newunitnum)==1:
                    print 'New unit number formed twice by the same unit. ' + 'NEW '+ str(newunitnum)
                    print 'In location : ' + currentloc
                    print 'The second one will be ignored... oops.... perhaps you should double check your orders'
                else:
                    self.ourunitbynum[currentunit]['children'][newunitnum]={'commands' : tempnewcommands}
                    self.ourunitbynum[currentunit]['children'][newunitnum]['orders']=tempneworders

            elif line.startswith('@;#')==1:
                self.ourunitbynum[currentunit]['commands'].append(line[3:].lstrip())
                currentline+=1
            elif line.startswith(';-------------------')==1:
                currentline+=1
            elif line.lower() != '#end':
                currentline+=1
                self.ourunitbynum[currentunit]['orders'].append(line)
            else:
                currentline+=1
            
            

    ################################################################################################




    def buildordertemplate(self,buildformat=0):
        
        if buildformat==0:
            buildformat=self.templateformat

        if self.templateformat>buildformat:
            raise Exception('We have tried to build an order template needing more information than we have.')
        if buildformat==-1:
            self.ordertemplate=['Orders Template (Long Format):','']
        elif buildformat==-2:
            self.ordertemplate=['Orders Template (Map Format):','']
        else:
            self.ordertemplate=[]
        
        self.ordertemplate.append(self.atlline)
        self.ordertemplate.append('')
        for line in self.preamble:              #   Add any preamble data 
            self.ordertemplate.append(line)

        if buildformat<2 :                  # This is a long format, map format or a short format file - we'll want location lines and can use self.regiondict
            for location in self.regiondict:
                self.ordertemplate.append('')
                if buildformat==-1 or buildformat==1:                     # long format or short foramt
                    if self.templateformat==-1 or self.templateformat==1:
                        self.ordertemplate.append(self.regiondict[location][3])
                    else:
                        self.ordertemplate.append(';*** ' + self.regiondict[location][3][1][1:])
                elif buildformat==-2:                   # map format
                    for line in self.regiondict[location][3]:
                        self.ordertemplate.append(line)

                for unit in self.regiondict[location][2]:
                    self.ordertemplate.append('')
                    self.ordertemplate.append('unit '+str(unit))
                    
                    if buildformat<0:
                        unitdesc=shortlist(self.ourunitbynum[unit]['mainbit'],72)
                        for line in unitdesc:
                            if unitdesc.index(line)==0:
                                self.ordertemplate.append(';'+line)
                            else:
                                self.ordertemplate.append(';  '+line)
                    if self.ourunitbynum[unit]['commands'] !=[]:
                        for line in self.ourunitbynum[unit]['commands']:
                            self.ordertemplate.append('@;# '+ line)
                    if self.ourunitbynum[unit]['orders']!=[]:
                        for line in self.ourunitbynum[unit]['orders']: 
                            self.ordertemplate.append(line)
                    if self.ourunitbynum[unit]['children'] !={}:
                        for child in self.ourunitbynum[unit]['children']:
                            self.ordertemplate.append('')
                            self.ordertemplate.append('FORM '+ str(child))
                            for line in self.ourunitbynum[unit]['children'][child]['commands']:
                                self.ordertemplate.append('@;# '+ line)
                            for line in self.ourunitbynum[unit]['children'][child]['orders']:
                                self.ordertemplate.append(line)
                            self.ordertemplate.append('END')
                            self.ordertemplate.append('')

        else:                                               # This is for an 'extreme short format' order file.
            for unit in self.ourunitbynum:
                self.ordertemplate.append('')
                self.ordertemplate.append('unit '+str(unit))

                if self.ourunitbynum[unit]['commands'] !=[]:
                    for line in self.ourunitbynum[unit]['commands']:
                        self.ordertemplate.append('@;# '+ line)
                if self.ourunitbynum[unit]['orders']!=[]:
                    for line in self.ourunitbynum[unit]['orders']: 
                        self.ordertemplate.append(line)
                if self.ourunitbynum[unit]['children'] !={}:
                    for child in self.ourunitbynum[unit]['children']:
                        self.ordertemplate.append('')
                        self.ordertemplate.append('FORM '+ str(child))
                        for line in self.ourunitbynum[unit]['children'][child]['commands']:
                            self.ordertemplate.append('@;# '+ line)
                        for line in self.ourunitbynum[unit]['children'][child]['orders']:
                            self.ordertemplate.append(line)
                        self.ordertemplate.append('END')
                        self.ordertemplate.append('')
                        


        self.ordertemplate.append('')                        
        self.ordertemplate.append('#end')

        outputtemplate=[]
        for line in self.ordertemplate:
            outputtemplate.append(line+'\n')
            
        return(outputtemplate)
  



    ################################################################################################

# object.merge(ordertemplateobject)

# Raises an exception if the #atlantis lines don't match
# Adds two ordertemplateobjects together -
# If they are the same format then the *new* object takes precedence where there are two clashing units.
# If they are different then the 'shorter' format takes precedence for orders, the 'longer' for information (like name, location, skills etc....)
# Will normally be used to merge in the information from a report into a short format order file.
# self.templateformat will reflect the new format. (self.ordertemplate will need rebuilding)
#

#
# We have the added difficulty that in ALH order files... if you have given the unit no orders... they simply don't appear
# in the order file. *So* we're going to have to create some blank entries for ones that don't exist already etc
# (including whole regions that may have been missed ?? ).... bugger.....
#


    def merge(self,newtemp):

        if self.atlline.lower() != newtemp.atlline.lower():
            raise Exception('Trying to merge two order templates from different factions.')

        if self.templateformat < newtemp.templateformat:               
            object1=self
            object2=newtemp
        elif self.templateformat >= newtemp.templateformat:
            object2=self
            object1=newtemp
            

        for unit in object1.ourunitbynum:
            if object2.ourunitbynum.has_key(unit)==0:
                object2.ourunitbynum[unit]={ 'commands' : [], 'orders' : [], 'children' : {} }
# 'orders' current orders (not including our @;# lines but including comments) 
# 'commands' list of our @;# commands 
# * 'name' 
# * 'flags' - [0]	Revealing Faction, [1]	Avoiding, [2]	Behind, [3]	Hold, [4]	Taxing
# [5]	Guarding, [6]	Receiving No-aid, [7]	Won't cross water. Each position in this list is set to '0' (string)
# for unset and '1' (string) for set.
# * 'mainbit' whole description 
# * 'items' - list of items the unit is holding
# * 'skills' - list of skills the unit has
# * 'canstudy' - if the unit is a mage (or potentially weaponsmith / armorcrafter) it may have skills that it 'can study'
# **'location' - returns the location string
# **'underworld' - 'Yes' or 'No' as to whether the unit is in the underworld
# **'province' - the name of the province the unit is in
#
# 'children' - any new units created by the unit go here (units created using the form command) - a dictionary keyed by the new unit number.

#            print unit, '  ', object1.ourunitbynum[unit]['flags'],'   ',   object2.ourunitbynum[unit]['flags']
            self.ourunitbynum[unit]['commands']=object2.ourunitbynum[unit]['commands']
            self.ourunitbynum[unit]['orders']=object2.ourunitbynum[unit]['orders']
            self.ourunitbynum[unit]['children']=object2.ourunitbynum[unit]['children']
            self.ourunitbynum[unit]['name']=object1.ourunitbynum[unit]['name']
            self.ourunitbynum[unit]['flags']=object1.ourunitbynum[unit]['flags']
            self.ourunitbynum[unit]['mainbit']=object1.ourunitbynum[unit]['mainbit']
            self.ourunitbynum[unit]['items']=object1.ourunitbynum[unit]['items']
            self.ourunitbynum[unit]['skills']=object1.ourunitbynum[unit]['skills']
            self.ourunitbynum[unit]['canstudy']=object1.ourunitbynum[unit]['canstudy']
            self.ourunitbynum[unit]['location']=object1.ourunitbynum[unit]['location']
            self.ourunitbynum[unit]['underworld']=object1.ourunitbynum[unit]['underworld']
            self.ourunitbynum[unit]['province']=object1.ourunitbynum[unit]['province']
#            print self.ourunitbynum[unit]['flags']

        for unit in object2.ourunitbynum:
            if self.ourunitbynum.has_key(unit)==0:
                self.ourunitbynum[unit]=object2.ourunitbynum[unit]
        

        self.parentlist=object2.parentlist
        self.originalordertemplate=object2.originalordertemplate
        self.ordertemplate=object2.ordertemplate
        self.templateformat=object1.templateformat
        self.regiondict=adddict(object2.regiondict,object1.regiondict)
        self.provincedict=adddict(object2.provincedict,object1.provincedict)
        self.preamble=object2.preamble


    ################################################################################################

if __name__ == "__main__":

    testfile=readfile('current.txt')
    newobject=OrderTemp(testfile)
    print newobject.templateformat

    unitlist1=[]
    unitlist2=[]
    unitlist3=[]
    unitlist4=[]
    unitlist5=[]
    unitlist6=[]
    unitlist7=[]

    for unit in newobject.ourunitbynum:
        unitlist1.append(unit)

    print " Length Ourunitbynum 1"
    print len(newobject.ourunitbynum)
    print "Length of Order Template before rebuilding"
    print len(newobject.ordertemplate)
    testtemplate=newobject.buildordertemplate()
    print "Length of Order Template after rebuilding"
    print len(newobject.ordertemplate)


    filehandle=open('current2.ord','w')

    for line in testtemplate:
        filehandle.write(line)
    filehandle.close() 

    #for line in newobject.ordertemplate:
    #    print line

    #print '\n\n\n\n\n\n\n'
    #print newobject.ordertemplate
    #print '\n\n\n\n\n\n\n'

    testfile=readfile('current2.ord')
    testobject=OrderTemp(testfile)

    # Rebuild

    print "Length of Order Template new object"
    print len(testobject.ordertemplate)


    print " Length Ourunitbynum 2"
    print len(testobject.ourunitbynum)


    for unit in testobject.ourunitbynum:
        unitlist4.append(unit)

    for unit in unitlist1:
        if unit not in unitlist4:
            unitlist5.append(unit)
    for unit in unitlist4:
        if unit not in unitlist1:
            unitlist5.append(unit)


    print "The New Object"
    print unitlist5


    #for unit in testobject.ourunitbynum:
    #    print unit, '   ', testobject.ourunitbynum[unit]['name']

    #for location in testobject.regiondict:
    #    print location, '   ', testobject.regiondict[location]

    #for province in testobject.provincedict:
    #    print province, '   ', testobject.provincedict[province]

    #if newobject.ourunitbynum != testobject.ourunitbynum:
    #    print "Oh Bugger"*50
    #

    #for unit in testobject.ourunitbynum:
    #    print unit, '   ', testobject.ourunitbynum[unit]['name']


    testobject.merge(newobject)

    #print '\n\n\n\n\n\n\n'
    for unit in testobject.ourunitbynum:
    #    print str(unit)
        unitlist6.append(unit)
    print '\n\n\n\n\n\n\n'

    for unit in unitlist6:
        if unit not in unitlist1:
            unitlist7.append(unit)

    for unit in unitlist1:
        if unit not in unitlist6:
            unitlist7.append(unit)



    print "Having run Merge"
    print unitlist7

    testtemplate=testobject.buildordertemplate(2)


    filehandle=open('current3.ord','w')

    for line in testtemplate:
        filehandle.write(line)
    filehandle.close() 


    testfile=readfile('current3.ord')
    test2object=OrderTemp(testfile)
    print 'Current order 3 - length of ourunitbynum'
    newobject.merge(test2object)
    print len (newobject.ourunitbynum)
#    for unit in testobject.ourunitbynum:
#        print testobject.ourunitbynum[unit]['name'], '    ',
#        print testobject.ourunitbynum[unit]['flags'], '    '

    thingy=newobject.buildordertemplate()


    filehandle=open('current4.ord','w')

    for line in thingy:
        filehandle.write(line)
    filehandle.close() 
