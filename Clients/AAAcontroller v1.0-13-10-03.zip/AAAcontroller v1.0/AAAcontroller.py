# 28-09-03
# This is the AAAcontroller program - Automated Atlantis Assistants
# This calls all the AAAs, so far, in sequence. *Then* it writes the order file.
# Yowser
#

import os, sys, string, os.path, re, time

from utils1 import StandOut, adddict
from mergeutils import parsereport, getturnno
from fileutils import readfile, writefile
from configutils import checkconfigname, checkconfigfile
from templateproc import OrderTemp
from sentrymonfun import sentry_mon
from order_procfun import order_proc
from flag_checkfun import flag_check
from diggerfun import roadmaintenance
#from loadmerge import loadandmerge 

# We're going to need a config file with *all* the options in. 

configspecs = { 'basedir'       : '',         # Directory where the scripts, config etc are
          'currentreportpath'    : '',    # Path to the report you want to check
          'factionid'     : '',               # Our faction id
          'dounder'       : '',                # Shall we include the underworld map ?
          'orderfile'     : '',               # The order file to load - in short or long format.
          'shortformat' : '',                  # Shall we write out the orders file in short format ? If '' we won't write out an orders file at all.
          'outputorderfile' : '',             # Path to the output order file. If '' then don't write an order file. 
          'outputreportpath'    : '',     # Shall we write back the order template as part of the report ?
          'verbose'               :  '' ,      # Should output be mirrored to the screen ?
          'outputpath'         :  '',         # Output logfile - if we want one.
          'logmode'            : '',        # start a new logfile ? ('w') or append to an old one ('a')
          'change_defaults'     : '',       # Do you want to override the default values for the report parsing ?


# The above are the general config options needed by the AAAcontroller engine *all* of these must be present.
#



# The following settings are switches - all of these must also be present - to tell it which of the scripts to run.
#

        'do_loadmerge'  :   '',          # Shall we run loadandmerge                
        'do_ordproc'       : '',         # Do you want me to run order_processor ?
        'do_dig'         : '',                   # Do we want diggers to run ?
        'do_sentry' : '',               # Do you want me to run sentry_monitor ?
        'do_flag'       : ''            # Do you want me to run flag_checker ?

            }

# The following values will only be loaded from the config files if change_defaults is set to yes.
# Otherwise default values will automatically be inserted.
# These values are used by the report parsing functions.

reportparsecon = {
    'donexus'       : '',                           # shall we include the nexus ?
    'dosurface'     : '',                           # shall we include the surface map ?
    'dounder'       : '',                           # shall we include the underworld map ?
    'printskills'   : '',                           # print the full skill list in the output report ?
    'dotemplate'    : '',                           # include the orders template ?
    'doevents'      : '',                           # include the events and battles
    'dofaction'     : '',                           # include all the faction details (attitudes, silver etc)
    'doallfactions' : ''                            # merge all units for all factions - i.e. produce ally reports.

                        }

# This next dictionary contains the default values that will be inserted if change_defaults is no.
#

reportparsedefaults = {
    'donexus'       : 'No',                           # shall we include the nexus ?
    'dosurface'     : 'Yes',                           # shall we include the surface map ?
    'dounder'       : 'Yes',                           # shall we include the underworld map ?
    'printskills'   : 'Yes',                           # print the full skill list in the output report ?
    'dotemplate'    : 'Yes',                           # include the orders template ?
    'doevents'      : 'Yes',                           # include the events and battles
    'dofaction'     : 'Yes',                           # include all the faction details (attitudes, silver etc)
    'doallfactions' : 'No'                            # merge all units for all factions - i.e. produce ally reports.

                        }


# Following are the config options for the individual AAAs.
# These values will be looked for in the main config file - but they only need to be present if that AAA
# is switched on (it's 'do' setting is yes).
#
# Each AAA must have a definition here unless it needs no extra values.

# Next are config options for loadandmerge
# If you're running the order_processor part then set 'do_proc' to 'No' and 
# following options can be '' as they won't be checked.
#

loadandmergecon = {

    'lmdoallfactions' : '',                            # merge all units for all factions - i.e. produce ally reports.
    'exitoninvalid' : '',                            # Exit programme if a file is invalid
    'turndir'       : '',                       # subdir where turn reports are dropped
    'turnarchive'   : '',               # subdir where turn reports are archived
    'masterfile'    : '',                               # name of the Master report to merge to

# The following settings affect the way loadandmerge produce reports and ally reports 
    'lmdosurface'     : '',                           # shall we include the surface map ?
    'lmdounder'       : '',                           # shall we include the underworld map ?
    'lmprintskills'   : '',                           # print the full skill list in the output report ?
    'lmdotemplate'    : '',                           # include the orders template ?
    'lmdoevents'      : '',                           # include the events and battles
    'lmdofaction'     : '',                           # include all the faction details (attitudes, silver etc)
    'lmjustmap'       : ''                            # Shall we output just map data ?   
                    }

# Next are config options for the order_processor AAA 
# If you're not running the order_processor part then set 'do_proc' to 'No' and 
# following options can be '' as they won't be checked.
#

ordproccon = {
                    'beforeproc' : '',		    # If 'Yes' it assumes you write your orders *before* running orderprocessor
                    'switch'     : ''               # if 'Yes' we are switching the value of 'beforeproc' this turn.
            }



# Next are config options for the sentry_monitor AAA 
# If you're not running the sentry_monitor part then set 'do_sentry' to 'No' and 
# following options can be '' as they won't be checked.
#

sentrycon = {
          'sentryname'       : '',            # the name fragment that indicate the unit is a sentry.
          'ignorefactionlist'       : ['', '', ''],        # the list of factions to ignore when reporting troops.
          'doallylist'   :   '',                    # shall we add our allies to the list of ignored factions ?
          'dofriends'   :  ''
          }                # shall we add our friends to the list of ignored factions ?

# Next are config options for the flag_checker AAA 
# If you're not running the flag_checker part then set 'do_flag' to 'No' and 
# following options can be '' as they won't be checked.
#

flagcon = {
          'flagname'       : '',            # The name fragment that indicate the unit is to have it's flags checked.
          'unittypes'       : ['','',''],        # The list of unit types to use
          'typefile'          : ''              # The file that contains the definitions of these types.
          }          


# Next are config options for the digegrs RFA 
# If you're not running diggers then set 'do_dig' to 'No' and the
# following options can be '' as they won't be checked.
#

digcon = {
           'default_dig'    : '',		    # The default order for diggers who don't have a default order set.
           'dig_flag'       : '',  		    # The flag that marks out a digger (set to ROAD usually)
           'ston_val'       : '',		    # If the unit has less than this amount of stone it will complain.
           'silv_val'       : ''		    # If the unit has less than this amount of silver it will complain.

          }


#############################

#first lets load in the config file.
configfilereader=checkconfigname()
settings={}
settings=checkconfigfile(configfilereader, configspecs)



# set up some of the parameters etc we need from the config file
basedir = settings['basedir']                       # root directory for everything else to be dependant on
logmode=settings['logmode'].lower().strip()
currentreportpath=settings['currentreportpath']     # pointer to the report we'll be working from
orderfile=settings['orderfile']


# Let's check which AAAs we'll be running - this determines which files we need to load.
# Each AAA myust have it's 'switch' extarcted here for testing.

do_loadmerge = settings['do_loadmerge'].lower().strip()
do_ordproc = settings['do_ordproc'].lower().strip()
do_dig = settings['do_dig'].lower().strip()
do_sentry = settings['do_sentry'].lower().strip()
do_flag = settings['do_flag'].lower().strip()
change_defaults = settings['change_defaults'].lower().strip()

needreport=0
needlong=0
needshort=0

# If an AAA needs a report we set needreport to 1,
# If it can work from a long format order file we set needlong to 1.
# If it needs at least a short format order file we set needshort to 1.
# otherwise we now we can work from just an extreme short format order file which is always the minimum.
#
# We'll also load all the extra keys used here and put them into settings
#
# Each AAA should have an entry here.
# This is also the place where we add the default values for report parsing... or load in the users values if he
# doesn't like my defaults. :-)
#

if change_defaults=='yes':
    newsettings=checkconfigfile(configfilereader, reportparsecon)
    settings=adddict(settings,newsettings)                          # adddict is a little function that adds two dictionaries together
else:
    settings=adddict(settings,reportparsedefaults)


if do_loadmerge == 'yes':                                           # loadandmerge doesn't need a report or order file already loaded in
    newsettings=checkconfigfile(configfilereader, loadandmergecon)
    settings=adddict(settings,newsettings)


if do_ordproc == 'yes':                                       #   Do we need to load and order_processor   
    newsettings=checkconfigfile(configfilereader, ordproccon)   #   We'll load in the config settings for order_processor
    settings=adddict(settings,newsettings)
                                                                #   We can cope with an extreme short format file so we don't need to change any variables

if do_dig == 'yes':
    needreport=1                                                  #   We need a report to tell if the road needs maintaining.
    newsettings=checkconfigfile(configfilereader, digcon)
    settings=adddict(settings,newsettings)

if do_sentry == 'yes':
    needreport=1                                                #   We need a report to check the sentries
    newsettings=checkconfigfile(configfilereader, sentrycon)
    settings=adddict(settings,newsettings)

if do_flag == 'yes':
    needlong=1                                                  #   We need at least a long format order file to check flag settigns
    newsettings=checkconfigfile(configfilereader, flagcon)
    settings=adddict(settings,newsettings)

# Have we been specified a report file.....
masterreader=[]
newmaster=[]
battles={}
ordertemplate=None
reportordertemplate=None
if currentreportpath != '':
    masterreader = readfile(basedir+currentreportpath)     # read it into a list
    # parse the report into the dictionary that holds all the data
    newmaster=parsereport(masterreader,settings)
    masterturnnumber=getturnno(masterreader)   # find what turn the master file is up to
    if (masterturnnumber <=0):
        print "Report File was invalid (or non-existent) so I'm afraid I'm going to have to die."
        sys.exit(1)                            # so just close down and finish
    reportordertemplate=OrderTemp(newmaster[3])

elif needreport==1:     #   One *wasn't* specified - do we need it.
    print "We need a report file for one of the scripts - but one wasn't specified."
    print "I'm afraid I'm going to have to die."
    sys.exit(1)
    
elif settings['outputreportpath'] != '':
    print "You asked me to output a report... but you didn't input one :-("
    print "Your faith is touching, but quite misplaced."
    sys.exit(1)


############################

neworderlist=[]
if orderfile!='':                                                   #   Have we been specified an order file ?
    neworderlist=readfile(basedir+settings['orderfile'])           # read the file in (if it exists)
    ordertemplate=OrderTemp(neworderlist)  
    if ordertemplate.templateformat>0:   # The file was a short format or extreme short format
        if needlong==1 and reportordertemplate==None:                       # Do we need a long format one ? (or a report obviously)
            print "We've been given a short format order file but haven't managed to load a valid report."
            print "Which isn't enough to work with I'm afraid."
            sys.exit(1)

        if needshort==1 and ordertemplate.templateformat==2 and reportordertemplate==None:                       # Do we need a long format one ? (or a report obviously)
            print "We've been given an extreme short format order file and haven't managed to load a valid report."
            print "Which isn't enough to work with I'm afraid."
            sys.exit(1)




# If we've loaded a report it's in newmaster and the template is in reportordertemplate
# If we've loaded an order file it's in ordertemplate

##############################


if ordertemplate== None and reportordertemplate== None:
    print "It doesn't look like we managed to load a report *or* an order file...."
    print "What exactly was it you wanted me to do ??"
    sys.exit(1)
elif reportordertemplate != None and ordertemplate == None:
    ordertemplate=reportordertemplate
elif reportordertemplate != None and ordertemplate != None:
    ordertemplate.merge(reportordertemplate)


if (settings['shortformat'].lower().strip() != 'yes' or settings['outputreportpath'] != '') and ordertemplate.templateformat>0:
    print "All we've loaded in is a short format order file."
    print "Yet you've asked for a long format order file or a report to be output."
    print "Which is beyond my capabilities I'm sorry to say."
    sys.exit(1)


# Now the ordertemplate object has been mered with the report if one was loaded.
# If no order file was loaded the template from the report has been used to form ordertemplate

################################################

# The next values relate to how we output the results

verbose=settings['verbose'].lower()
outputorderfile=settings['outputorderfile']
shortformat=settings['shortformat'].lower().strip()
outputreportpath=settings['outputreportpath']

#########################

# Let's setup the output object.

if settings['outputpath'] != '':
    outputpath= basedir + settings['outputpath']
else:
    outputpath=''


standard_out=StandOut(verbose,outputpath,logmode)       # Creating the output object

if logmode=='a':
    standard_out.putout('\n\n')
else:
    print
    print
    
standard_out.putout("Output from AAAcontroller.\n*THE* Automated Atlantis Assistant script from the atlantibot project.\nBy Fuzzyman\nSee www.atlantibots.org.uk\n")
standard_out.putout(time.strftime('%I:%M %p, %A %d %B, %Y')+'\n\n')   # Print the date...
standard_out.putout('\n\n')


##########################################################################    

# Following is the daisy chain that actually calls the functions in order.
# Note that if we want to edit the order template in these functions we ought to use ordertemplate
# rather than newmaster[3]which will be replaced later !!



# Let's check if the order_processor is needed - and if so we'll run it.
if do_loadmerge=='yes':
    standard_out.putout('Calling loadandmerge.........\n')
    newparams=loadandmerge(settings, newmaster, ordertemplate, standard_out)

    newmaster=newparams

#########################


# Let's check if the order_processor is needed - and if so we'll run it.
if do_ordproc=='yes':
    standard_out.putout('Calling order_processor.........\n')
    newparams=order_proc(settings, newmaster, ordertemplate, standard_out)

    newmaster=newparams

#########################

# Let's check if the sentry_monitor is needed - and if so we'll run it.
if do_sentry=='yes':
    standard_out.putout('Calling sentry_monitor.........\n')
    newparams=sentry_mon(settings, newmaster, ordertemplate, standard_out)

    newmaster=newparams

#########################

# Let's check if the flag_checker is needed - and if so we'll run it.
if do_flag=='yes':
    standard_out.putout('Calling flag_checker.........\n')
    newparams=flag_check(settings, newmaster, ordertemplate, standard_out)

    newmaster=newparams

#########################

# Let's check if diggers is needed - and if so we'll run it.
if do_dig=='yes':
    standard_out.putout('Calling the Diggers script.........\n')
    newparams=roadmaintenance(settings, newmaster, ordertemplate, standard_out)

    newmaster=newparams


##################################################

# Now we need to build and write out the new files

newordertemplate=[]
newordertemplate2=[]
if outputreportpath != '':
    newordertemplate2=ordertemplate.buildordertemplate(-1)

if outputorderfile!='' and shortformat != '':
    if shortformat=='yes':
        if ordertemplate.templateformat>0:                      # If the ordertemplate is already short or extreme short then reuild it using that format.
            newordertemplate=ordertemplate.buildordertemplate()
        else:                                                   # otherwise just produce a short format one.
            newordertemplate=ordertemplate.buildordertemplate(1)
    else:
        newordertemplate=newordertemplate2

# newordertemplate now contains whichever file we are going to use to form the output order file
        
    filehandle=open(basedir + outputorderfile,'w')
    standard_out.putout('Writing output order file : '+basedir+outputorderfile+'\n')
    if shortformat=='yes':
        standard_out.putout('Order file written in Short Format\n')

    for line in newordertemplate:
        filehandle.write(line)
    filehandle.close() 

if currentreportpath !='' and outputreportpath !='':     # if they specified an output report... but not an input one we can't write it......
    newmaster[3]=newordertemplate2    
    writefile(basedir + outputreportpath,newmaster, settings)
    standard_out.putout('Writing Output report : ' + basedir + outputreportpath+'\n')


standard_out.outclose()                 # Just closes the output object.


###############################

# That' all for now folks.
