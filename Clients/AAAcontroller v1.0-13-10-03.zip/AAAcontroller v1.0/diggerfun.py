# 13-10-03

from utils1 import getdigits

def roadmaintenance(settings, newmaster, ordertemplate, standard_out):

    standard_out.putout("\nOutput from Diggers - Automatic Road Maintenance Crews.\n(Tea breaks at no extra charge).\n\n")
    
    regions   = newmaster[1]
    units     = newmaster[2]
    template  = newmaster[3]
    prelude   = newmaster[4]
    buildings = newmaster[5]
    unitbynum = newmaster[6]
    skilllist = newmaster[7]
    faction   = newmaster[8]


    ##############################

    dig_flag=settings['dig_flag'].lower()
    default_dig=settings['default_dig']
    silv_val=int(settings['silv_val'])
    ston_val=int(settings['ston_val'])
        
                 

    ##############################




    diggers=[]
    for unit in ordertemplate.ourunitbynum:
        for line in ordertemplate.ourunitbynum[unit]['commands']:
            newline=line.lower()
            if newline.startswith('flag '+ dig_flag):
                diggers.append(unit)
                break
            
    # diggers is now a list of all our road maintainers, we're not checking newly formed units.
    
    if diggers !=[]:
        standard_out.putout('Following Road Maintainer Units Found :\n')
        a=0
        while a<(len(diggers)-1):
            standard_out.putout( str(diggers[a]) + ', ')
            a=a+1
        standard_out.putout( str(diggers[len(diggers)-1])+'\n\n')
    else:
        standard_out.putout('\nNo Road maintainers found.\nA lot of nothing is about to happen.\n\n')

    b=0
    for unit in diggers:
        def_order=default_dig
        for line in ordertemplate.ourunitbynum[unit]['commands']:    # First we'll check for those default orders
            newline=line.lower()
            if newline.startswith('dig '):
                def_order=line[4:].strip()
                break
    # def_order is now the default order for that unit *or* it is the default order set in the config file



#        print 'Skills'
#        print unitbynum[unit]['skills']
#        print 'Items'
#        print unitbynum[unit]['items']
#        print 'Location'
#        print unitbynum[unit]['location']
#        print buildings[unitbynum[unit]['location']]

        # First we'll check the unit has the requisite skill
        has_build=-1
        for line in unitbynum[unit]['skills']:
            newline=line.strip().lower()
            if newline.startswith('skills:')==1:
                newline=newline[7:].strip()
            if newline.startswith('building')==1:
                build_val=newline[newline.find(']')+1:newline.find('(')].strip()
#                print build_val
                if int(build_val)>=3:
                    has_build=1
                    break
                elif int(has_build)>0:
                    has_build=0
                    break
        outputmade=0
        if has_build<1:
            standard_out.putout( 'Unit ' + str(unit) + ' in location ' + ordertemplate.ourunitbynum[unit]['location'] +' has too low a skill in building.\n')
            outputmade=1

        actual_silv=0
        actual_ston=0
        if silv_val != 0 or ston_val != 0:          #   We'll check the unit has some stone and silver - unless the default values are set to 0 (meaning don't check)
            for line in unitbynum[unit]['items']:
                newline=line.strip()
                if newline.endswith('[SILV]')==1:
                    actual_silvs=getdigits(newline)
                    if actual_silvs=='':
                        actual_silv=1
                    else:
                        actual_silv=int(actual_silvs)

                if newline.endswith('[STON]')==1:
                    actual_stons=getdigits(newline)
                    if actual_stons=='':
                        actual_ston=1
                    else:
                        actual_ston=int(actual_stons)

#        print 'silv_val : ', silv_val, ' actual_silv : ', actual_silv
#        print 'ston_val : ', ston_val, ' actual_ston : ', actual_ston

        if silv_val != 0:
            if silv_val > actual_silv:
                standard_out.putout( 'Unit ' + str(unit) + ' in location ' + ordertemplate.ourunitbynum[unit]['location'] +' is running low on silver.\n')
                outputmade=1
                        
        if ston_val != 0:
            if ston_val > actual_ston and  actual_ston !=0:
                standard_out.putout( 'Unit ' + str(unit) + ' in location ' + ordertemplate.ourunitbynum[unit]['location'] +' is running low on stone.\n')
                outputmade=1
            elif actual_ston ==0:
                standard_out.putout( 'Unit ' + str(unit) + ' in location ' + ordertemplate.ourunitbynum[unit]['location'] +' is completely out of stone.\n')
                outputmade=1


        inbuildingtype=1
        inbuilding=''
        if unitbynum[unit]['building'] != 0:
            for building in buildings[unitbynum[unit]['location']]:
#                print int(building['id'])
#                print unitbynum[unit]['building']
                if unitbynum[unit]['building'] == int(building['id']):
                    inbuilding=building['type']
                    inbuildingcomment=building['comment']
                    break

#        print inbuilding
        if inbuilding.lower().strip().startswith('road') ==0 :
            inbuildingtype=0
            standard_out.putout('Unit ' + str(unit) + ' in location ' + ordertemplate.ourunitbynum[unit]['location'] + " isn't in a road.\n")
            outputmade=1
            
        a=0
#        print 'hello'
        if has_build==1 and inbuildingtype==1 and  actual_ston !=0:
#            print inbuildingcomment.lower()
            if inbuildingcomment.lower().find('needs')!=-1:
                standard_out.putout('Build order issued to unit ' + str(unit) +' in location ' + ordertemplate.ourunitbynum[unit]['location'] + '\n')
                ordertemplate.ourunitbynum[unit]['orders'].append('BUILD')
                outputmade=1
                a=1
                b=1
                
        if a==0:
            ordertemplate.ourunitbynum[unit]['orders'].append(def_order)
            
        if outputmade==1:
            standard_out.putout( '\n')

    if b==0:
        standard_out.putout( 'No roads were maintained this turn - very unusual.\n')
        



    ###############################
    standard_out.putout('\nAll units checked.\n\n')

    ##############################

    newordertemplate2=ordertemplate.buildordertemplate()

    newmaster[3]=newordertemplate2
    return newmaster 
