# 20-09-03

from utils1 import attitudelist,listmerge

def sentry_mon(settings, newmaster, ordertemplate, standard_out):
    
    # set up some of the parameters etc we need from the config file
    basedir = settings['basedir']                       # root directory for everything else to be dependant on
    sentryname = settings['sentryname'].lower()          # what's the sentryname (if there is one) ?

    regions   = newmaster[1]
    units     = newmaster[2]
    template  = newmaster[3]
    prelude   = newmaster[4]
    buildings = newmaster[5]
    unitbynum = newmaster[6]
    skilllist = newmaster[7]
    faction   = newmaster[8]
    allitems  = newmaster[9]
    battles   = newmaster[10]


    z=0
    #First lets check the battles
    if sentryname != '':
    # Now if there have been any battles, 
    # battlesection will contain that part of
    # the report.
        if battles !=[]:
            for line in battles:
                if line.find(sentryname)!=-1:
                    z=1
                    break
    # If the sentryname appears *anywhere*
    # in battles, z=1. We can print this
    # in the appropriate place later.


    # setup the list of factions we will ignore and whose factions we will check sentries from.
    ignorelist=[]
    a=attitudelist(faction['attitudes'],settings['doallylist'],settings['dofriends'])    # this is our allies and friends. It only adds them if the user has specified to in the config file.

    ignorelist=listmerge(a,settings['ignorefactionlist'])           # Also any other factions specifically added by the user.
    ignorelist.append(settings['factionid'])                # Not forgetting to always ignore our own troops.

# At his point we could automaticallu add factions 1 + 2 - guardsmen and creatures... but to be fair that's up to the user.. (?)

    ###############################################################

    print
    standard_out.putout("Output from sentry_monitor. Keeping an eye on your kingdom.\n\n")


    ##############################



    locationlist=[]
    for location in ordertemplate.regiondict:
            for unit in ordertemplate.regiondict[location][2]:
                if location not in locationlist:
                    if sentryname != '':
                        if ordertemplate.ourunitbynum[unit]['name'].lower().find(sentryname)!=-1:
                            locationlist.append(location)
                            break
                    for line in ordertemplate.ourunitbynum[unit]['commands']:
                        if line.lower().startswith('sentry')==1:
                            locationlist.append(location)
                            break

                    
#####################################

# locationlist has just checked all the locations of our units - we now have a list of all locations with sentries in.

    sentryname = settings['sentryname']
                     
    if sentryname !='':
        standard_out.putout( 'Sentries checked with the following name :\n')
        standard_out.putout( settings['sentryname'])
        standard_out.putout( '\n\n')


    if z==1:
        standard_out.putout( 'It appears at least one sentry was involved in a battle.\nCheck the battle reports carefully.\n\n')



    if locationlist != []:
        standard_out.putout( 'Sentries found in the following locations :\n')

        for entry in locationlist:
            standard_out.putout(entry + ' ')

        standard_out.putout( '\n\n')


        standard_out.putout( 'Ignoring units from the following factions :\n')
        a=0
        while a<(len(ignorelist)-1):
            standard_out.putout( ignorelist[a] + ', ')
            a=a+1
        standard_out.putout( ignorelist[len(ignorelist)-1]+'\n')

    else:
        standard_out.putout( "No sentries found.\nSo either there's a bug in my code, or you haven't set any sentries.\n")
        standard_out.putout( "Which means one of us is a weirdo :-)\nI hope it's not me (but if it is let me know).\n")




     
    for location in locationlist:
        newlist2=[]
        for unit in units[location]:
            if str(unit['faction']) not in  ignorelist:
                newlist2.append(unit)
        if newlist2 != []:
            standard_out.putout( '\n\n')

            standard_out.putout( 'Units found in : '+location + '\n')
            standard_out.putout( ordertemplate.regiondict[location][3][1:] + '\n')

            for unit2 in newlist2:
                     standard_out.putout( str(unit2['faction'])+' : ' + str(unit2['main']) + '\n')

    standard_out.putout('\n')

    return newmaster            # Which in fact is unchanged by this script      
