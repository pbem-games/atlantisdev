# Report merger script - by Elricz (elricz.m@gmail.com)
#
# The goal of this script is to merge the reports from all member of any alliance in a single report
# It uses all the report files (identified by ending in .rep), and creates a new .rep file with the name
#   of the alliance, set by the variable $filename. 
# To use it, just copy the script to the folder where the reports are, and execute the script
# The script has been tested in Windows XP with ActiveState Perl 5.8.6, and Tarmellion reports

use Text::Wrap;

my @files = <*>;
my ($flag, $line, $region, %attacks, %items, %regions);
my ($amount, $prod, %products);
my ($unit, $sequence, $len, %units, $i);
# Aggregations variables
my $alliance = "Your alliance (10001)"; my $filename = "Alliance";
my ($silver, $war, $trade, $magic, $date, $month, $year, %races, $races_st);
my ($war_cur, $war_pot, $trade_cur, $trade_pot, $magic_cur, $magic_pot);
my %months = ("January","01", "February","02", "March","03", "April","04", 
	"May","05", "June","06", "July","07", "August","08", "September","09", 
	"October","10", "November","11", "December","12");
# Arrays to store the data 
my @errors; $errors[0] = "\nErrors during turn:\n";
my @battles; $battles[0] = "\nBattles during turn:\n";
my @events; $events[0] = "\nEvents during turn:\n";
my @skills; $skills[0] = "\nSkill reports:\n";
my @items; $items[0] = "\nItem reports:\n";
my @objects; $objects[0] = "\nObject reports:\n";
my @orders; $orders[0] = "\nOrders Template (Short Format):\n";$orders[1] = "\n#atlantis\n";
my @region;
# Process each report file, identified by ending with .rep string. To change the extension,
#   change the if statament two lines below this one.
foreach (@files) {
	if (/rep$/) {
		my $section = "Start";
		my $file = $_;
		open REPORT, "< $file" or die "Can't open $file: $!\n";
		while (<REPORT>) {
			chomp;
			# Section control
			if (/^Errors during turn:$/) {
				$section = "Errors";
				next;
			} elsif (/^Battles during turn:$/) {
				$section = "Battles";
				next;
			} elsif (/^Events during turn:$/) {
				$section = "Events";
				next;
			} elsif (/^Skill reports:$/) {
				$section = "Skills";
				next;
			} elsif (/^Item reports:$/) {
				$section = "Items";
				next;
			} elsif	(/^Object reports:$/) {
				$section = "Objects";
				next;
			} elsif (/^Declared Attitudes /) {
				$section = "Attitudes";
				next;
			} elsif (/^Unclaimed silver: (\d+)/) {
				$section = "Regions";
				$silver += $1;
				next;
			} elsif (/^Orders Template/) {
				$section = "Orders";
				# Add the last region on the report
				$regions{$region} = [@region];
				next;
			}
			
			# Initial section
			if ($section eq "Start") {
				if (/\(War (\d), Trade (\d), Magic (\d)\)/) {
					$war += $1; $trade += $2; $magic += $3;
				} elsif (/(\w+), Year (\d+)/) {
					$date = $_; $month = $months{$1}; $year = (sprintf "%02d", $2);
				} elsif (/^Tax Regions: (\d+) \((\d+)\)/) {
					$war_cur += $1; $war_pot += $2;
				} elsif (/^Trade Regions: (\d+) \((\d+)\)/) {
					$trade_cur += $1; $trade_pot += $2;
				} elsif (/^Arcane Power Levels: (\d+) \((\d+)\)/) {
					$magic_cur += $1; $magic_pot += $2;
				} elsif (/^Race: (.+)/) {
					$races{$1}++;}
			}

			# Gather each line
			push(@errors, "$_\n") if ($section eq "Errors" and !/^\s*$/);
			# Battles section
			if ($section eq "Battles") {
				# Gather multilines in a single line
				$line = /^  ./ ? $line . "$_\n" : "$_\n";
				# Check the header of the battle, to eliminate duplicates
				if ($line =~ /attacks[\d\D]*!$/) {
					$flag = 0 if exists $attacks{$line};
					$attacks{$line} = 1; }
				# Print only complete lines and blank lines
				push(@battles, $line) if ($flag and $line =~ /[.:!]$/);
				push(@battles, "\n") if ($flag and $_ =~ /^\s*$/);
				# Activate the flag again, after the spoils
				$flag = 1 if $line =~ /^Spoils:[\d\D]*\.$/;
			}
			push(@events, "$_\n") if ($section eq "Events" and !/^\s*$/);
			# Skills section
			if ($section eq "Skills") {
				if (/^\w.*? (\[\w+\] \d):/) {
					$flag = (exists $items{$1}) ? 0 : 1;
					$items{$1} = 1; }
				push(@skills, "$_\n") if $flag; 
			}
			# Items section
			if ($section eq "Items") {
				if (/^\w.*?(\[\w+\]),/) {
					$flag = (exists $items{$1}) ? 0 : 1;
					$items{$1} = 1; }
				push(@items, "$_\n") if $flag; 
			}
			# Objects section
			if ($section eq "Objects") {
				if (/^(\w.*?):/) {
					$flag = (exists $items{$1}) ? 0 : 1;
					$items{$1} = 1; }
				push(@objects, "$_\n") if $flag; 
			}
			# Regions section
			if ($section eq "Regions") {
				# Check the region header, to process last region and mark a new one
				if (/^\w+ (\(\d+,\d+[,a-z ]*\))/) {
					$regions{$region} = [@region] if $region;
					$flag = 0; $line = "\n";
					$region = $1; @region = "";
				}  elsif (/^\s*[-\*\+] / and $flag == 0) { # Units are treated different
					$flag = 1; $line = "\n"; $i = 1;}
				$line .= "$_\n" unless $flag;
				if ($line =~ /^  Products:/ and $line =~ /\.$/) {
					# Clean new lines and double spaces
					$line =~ s/\n//g; 
					(1) while ($line =~ s/  / /g);
					foreach (split /,/ , $line) {
						($amount, $prod) = /(\d+) ([a-zA-Z ]*\[\w+\])/;
						$products{$region}{$prod} = $amount; }
				}
				# Create the array with the region description
				if ($line =~ /[\.-]$/ and $flag == 0) {
					push (@region, $line);
					$line = ""; }
				# Process the units
				if ($flag) {
					if (/^[\*\+-]/ or /^\s*$/ or (/\s\s[\*-]/ and $i >= 1000)) {
						if ($line =~ /([\[\(]\d+[\]\)])/) {
							$unit = $1; 
							# Add the region to the key if it is a building
							if ($unit =~ /\[/) {$line = "\n" . $line;}
							$len = length ($line); $sequence = $i;
							# Create or update the unit
							unless (exists $units{$region}{$unit} and $units{$region}{$unit}{len} > $len) {
								$units{$region}{$unit}{sequence} = $sequence unless (exists $units{$unit}{sequence} and $units{$unit}{sequence} > $sequence);
								$units{$region}{$unit}{unit} = $line;
								$units{$region}{$unit}{len} = $len;}
							$line = ""; $i++; $i += 1000 if $unit =~ /\[/;  # Units inside buildings
							}
					}
					$line = (/^[\*\+-]/ or /^\s*$/) ? "$_\n" : $line . "$_\n";
					$line = "$_\n" if (/\s\s[\*-]/ and $i >= 1000);
				}
			}
			push(@orders, "$_\n") if ($section eq "Orders" and $_ !~ /^[;#]/);
		}
		close REPORT;
	}
}

# Print the aggregated data
my $report = $filename . '_y' . $year . '_m' . $month . '.rep';
open DEST, "> $report" or die "Destination cannot be open: $!\n";

print DEST "Atlantis Report For:\n";
print DEST "$alliance (War $war, Trade $trade, Magic $magic)\n";
print DEST "$date\n\nFaction status:\n";
print DEST "Tax Regions: $war_cur ($war_pot)\n";
print DEST "Trade Regions: $trade_cur ($trade_pot)\n";
print DEST "Arcane Power Levels: $magic_cur ($magic_pot)\n";
# Races string
$races_st = "Race:";
foreach $race (sort keys %races) {
	$races_st .= " $race ($races{$race})";}
print DEST wrap ('','  ',"$races_st\n");
# print DEST the full report
print DEST @errors;
print DEST @battles;
print DEST @events;
print DEST @skills;
print DEST @items;
print DEST @objects;
print DEST "\nUnclaimed silver: $silver\n";
# Regions are stored in a hash, not an array
foreach (sort keys %regions) {
	$region = $_;
	foreach (@{$regions{$region} }) {
		if (/^ Products:/) {
			$line = "Products: ";
			$line .= "$products{$region}{$_} $_, " foreach (sort keys %{ $products{$region} });
			$line =~ s/, $/.\n\n/;
			print DEST wrap ('  ','    ',$line);
		} else { print DEST; }
	}
	print DEST "\n";
	# Print units
	foreach (sort {$units{$region}{$a}{sequence} <=> $units{$region}{$b}{sequence}} keys %{$units{$region}}) {
		print DEST $units{$region}{$_}{unit};}

}
print DEST @orders; print DEST "#end\n";

close DEST;