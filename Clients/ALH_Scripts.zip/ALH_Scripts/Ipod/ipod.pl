# Report splitter for Ipod script - by Elricz (elricz.m@gmail.com)
#
# The goal of this script is to split an Atlantis report in several files, suitable for the ipod
# It use a report file, named in the $file variable (turn.rep by default)
# The result of the script are a set of text files without extension, and some .linx files that 
#   contains links to them. There are text files for units and regions, and link files for 
#   skills and items related to units, and cities, shafts, resources and terrain types for regions.
# To use it, just copy the files ipod.pl to where the report is, and execute the script
# The script has been tested in Windows XP with ActiveState Perl 5.8.6, and a report from Tarmellion

use Text::Wrap;

my $section = "Start";
my ($name, $unit, $faction);
my ($line, $line_u, $event, $region, @errors, @events, %skills, %items, %names, $building);
my ($terrain, %regions, @region, %titles, %cities, %terrains, %products, @shafts);
my %levels = ("underdeep", 2, "underworld", 3, "deep underdeep", 4, "deep underworld", 5);

# Check the structure, creating it if not present
my @folders = qw| unit reg prod skill item terr |;
foreach (@folders) {
	system ("mkdir $_") if !-e;}

my $file = 'turn.rep';
# Open the files, to read and write, and print headers
open REPORT, "< $file" or die "Report cannot be open: $!\n";

while (<REPORT>) {
	chomp;
	# Mark the different sections that we want
	if (/^Errors during turn:$/) {
		$section = "Errors";
		next;
	} elsif (/^Battles during turn:$/) {
		$section = "Battles";
		next;
	} elsif (/^Events during turn:$/) {
		$section = "Events";
		next;
	} elsif (/^Skill reports:$/) {
		$section = "Skills";
		next;
	} elsif (/^Unclaimed silver/) {
		$section = "Regions";
		next;
	}

	# Gather errors and events in arrays
	if ($section eq "Errors") {
		$event .= $_;
		# Insert only complete lines (ended with a dot)
		if (/\.$/) {
			(1) while ($event =~ s/  / /g); # Trim double spaces
			push (@errors, $event);
			$event = "";
		}
	}
	if ($section eq "Events") {
		$event .= $_;
		# The summon spells don't have a dot at the end!
		if (/\.$/ or /(SKEL|IMP)\]$/) {
			(1) while ($event =~ s/  / /g);
			push (@events, $event);
			$event = "";
		}
	}

	# Get the own units from the regions
	if ($section eq "Regions") {
		# Check the start of a region
		if (/^(\w+) \((\d+,\d+[,a-z ]*)\)/) {
			if ($region) {
				$regions{$region} = [@region];}
			# Fill variables for the start of the region
			$terrain = $1; $region = $2; @region = ""; $in_unit = 0; $building = ""; $line = "";
			# Change level description for numbers
			$region .= ",1" unless $region =~ /[a-z]/;
			$region =~ s/(\d+,\d+,?)([a-z ]*)/$1$levels{$2}/ if ($region =~ /[a-z]/);
			# Feed the titles hash
			$title = "$terrain ($region)";
			$titles{$region} = $title; 
			push @{ $terrains{$terrain} }, $region; # Used for the terrains distribution
		}
		# Gather region information, before the units.
		unless ($in_unit) {
			$line .= $_ ;
			if (/^[\+\*-] /) {push (@region, "\nUnits:\n") unless $in_unit; $in_unit = 1;}
		}
		# Change some lines for the iPod presentation
		$line = "-" x 20 if /^-+$/;
		$line =~ s/available:/:/ if $line =~ /Entert/;
		$line =~ s/^Exits:/\nExits:/ if /^Exits:/;
		# Push every line in the region array
		if ($line && $line =~ /[\.:-]$/ && !$in_unit) {
			# Clean new lines and double spaces
			(1) while ($line =~ s/  / /g);
			push (@region, "$line\n");
			$line = ""; }
		# Unit section
		if ($line_u and (/^\s*$/ or /^\s*[\+\*-]/)) {
			 # Mark that we are in the units section
			(1) while ($line_u =~ s/  / /g); # Trim double spaces
			# Check for shafts and occupied buildings
			if ($line_u =~ /^\+/) {
				($building) = split /;/, $line_u;
				push (@region, "$line_u\n") if ($line_u =~ /^\+ Shaft /);}
			# Call the parse sub for each unit
			if ($line_u =~ /^\s*\*/) { 
				&parse_unit;
				push (@region, "$building\n") if $building; $building = "";
				push (@region, "<a href=\"/unit/$unit\">$name ($unit)</a>\n");}
			$line_u = ""; 
		}
		$line_u .= $_ if ($line_u and $in_unit);
		$line_u = $_ if (/^\s*[\*+]/);
	}
}
# Process the last region
$regions{$region} = [@region];

close REPORT;

# Generate skill list
foreach (sort keys %skills) {
	my $skill = $_;
	open LINKS, ">skill/$skill.linx" or die "Can't create file $skill: $!";
	print LINKS "<Title>$skill</Title>\n";
	foreach (sort {$skills{$skill}{$b} cmp $skills{$skill}{$a}} keys %{ $skills{$skill} }) {
		print LINKS "<a href=\"/unit/$_\">$skills{$skill}{$_} - $names{$_}</a>\n";}
	close LINKS;
}

# Generate item list
foreach (sort keys %items) {
	my $item = $_;
	open LINKS, ">item/$item.linx" or die "Can't create file $item: $!";
	print LINKS "<Title>$item</Title>\n";
	foreach (sort {$items{$item}{$b} cmp $items{$item}{$a}} keys %{ $items{$item} }) {
		print LINKS "<a href=\"/unit/$_\">$items{$item}{$_} - $names{$_}</a>\n";}
	close LINKS;
}

# Print the regions
foreach (keys %regions) {
	$region = $_;
	open REGION, ">reg/$region" or die "Can't create file $region: $!";
	foreach (@{$regions{$region} }) {
		if (/, contains (.*\]),/) {$cities{$1} = $region;} # Populating the cities hash
		push (@shafts, $region) if (/^\+ Shaft /); # Populating the shafts hash
		# Products hash
		if (/^ Products:/) {
			foreach (split /,/) {
				my ($amount, $prod) = /(\d+) ([a-zA-Z ]*\[\w+\])/;
				$products{$prod}{$region} = $amount; }
		}
		print REGION;
	}	
	close REGION;
}

# File with the shafts (Array)
open LINKS, ">shafts.linx" or die "Can't create file cities: $!";
print LINKS "<Title>Shafts</Title>\n";
print LINKS "<a href=\"reg/$_\">$titles{$_}</a>\n" foreach (@shafts);			
close LINKS;

# File with the cities (Hash)
open LINKS, ">cities.linx" or die "Can't create file cities: $!";
print LINKS "<Title>Cities</Title>\n";
print LINKS "<a href=\"reg/$cities{$_}\">$_</a>\n" foreach (sort keys %cities);
close LINKS;

# Files for the terrains (Hash of arrays)
foreach (sort keys %terrains) {
	$terrain = $_;
	open LINKS, ">terr/$terrain.linx" or die "Can't create file $terrain: $!";
	print LINKS "<Title>$terrain</Title>\n";
	print LINKS "<a href=\"/reg/$_\">$titles{$_}</a>\n" foreach (@{ $terrains{$terrain} });
	close LINKS;
}

# Files for the products (Hash of hashes)
foreach (sort keys %products) {
	my $prod = $_;
	open LINKS, ">prod/$prod.linx" or die "Can't create file $prod: $!";
	print LINKS "<Title>$prod</Title>\n";
	foreach (sort {$products{$prod}{$b} <=> $products{$prod}{$a}} keys %{ $products{$prod} }) {
		print LINKS "<a href=\"/reg/$_\">$products{$prod}{$_} - $titles{$_}</a>\n";}
	close LINKS;
}

# Sub to print the unit
sub parse_unit {
	# Get the name, unit and faction
	($name, $unit, $faction) = ($line_u =~ /^\s*\* ([^\(]+)\((\d+)\), ([^\(]+\(\d+\))/);
	$names{$unit} = $name;
	# Split in the , and search each piece for data about skills and objects
	my @items = split /,/, $line_u;
	foreach (@items) {
		if (/[a-zA-Z ]+\[(\w+)\] (\d) (\(\d+\))/) {	$skills{$1}{$unit} = "$2 $3";}
		if (/[a-zA-Z ]+ \[(\w+)\]$/) { $items{$1}{$unit} = "1 $1";}
		if (/ (\d*) [a-zA-Z ]+ \[(\w+)\]/) { $items{$2}{$unit} = "$1 $2";}
		last if /Can Study/;
	}
	open UNIT, ">unit/$unit" or die "Can't create $unit file: $!\n";
	print UNIT wrap('','  ',"$line_u\n----------\n");
	# Print the region, errors and events
	print UNIT "IN REGION: <a href=\"/reg/$region\">$titles{$region}</a>\n";
	foreach (@errors) {
		print UNIT wrap('','  ',"ERROR: $_\n") if (/\($unit\)/);}
	foreach (@events) {
		print UNIT wrap('','  ',"EVENT: $_\n") if (/\($unit\)/);}
	close UNIT;
}
