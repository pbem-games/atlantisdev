# Resource tracker script - by Elricz (elricz.m@gmail.com)
#
# The goal of this script is assist in the search for resources in the Tarmellion game
# It uses the configuration files from Atlantis Little Helper (ALH) and a text file
#   with the different patterns to search
# The result of the script is a set of ah.st.cfg files, each one with the minimum information
#   needed to track the search for resources: A tracking group with the units able to discover
#   the resource and two different flags for all the hexes visited by the units, showing the
#   the presence or absence of that resource
# To use it, just copy the files tracker.pl and searches.txt in the ALH folder, and execute the script
# The script has been tested in Windows XP with ActiveState Perl 5.8.6, and ALH 2.4.4

# Load the variables from the searches.txt file, and call the subroutine for each set
my (%vars, @tracking);
open SEARCHES, "< searches.txt" or die "Can't open searches.txt: $!\n";
while (<SEARCHES>) {
	chomp;
	if (/^\s*$/) {
		&process_product ($vars{skill},$vars{product},$vars{group},$vars{flag_0},$vars{flag_1},$vars{flag_2},$vars{terrain},$vars{cfg_file});
	} else {
		my ($key,$value) = split /\s*=\s*/;
		$vars{$key} = $value;
	}
}
close SEARCHES;
#print tracking groups
open DEST, "> tracking_groups.txt" or die "Can't open tracking_groups.txt: $!\n";
print DEST "[UNIT_TRACKING_GROUPS]\n\n";
print DEST foreach @tracking;
close DEST;
print "Tracking groups generated.\n";

# The process for gathering information is the following:
# - Open the ah.st.cfg file to get the report files list.
# - Open each report and identify units that are able to discover the resource
# - Identify the regions where the units are, and the ones visited that turn
# - Once this is made for all the turns, open the ah.his file to check the resources, and flag appropiately
# - Finally, write the ah.st.cfg file for that resource
sub process_product {
	my ($skill,$prod,$group,$land_flag_0,$land_flag_1,$land_flag_2,$terrain,$cfg_file) = @_;
	my ($line, $unit, $flag, $ship, $origin, $dest);
	my $moves = "Walks |Rides |Flies| Swims |sails"; # Identified ways of movement
	my (@events, @files, %regions,%units, %ships);
	
	print STDERR "Processing group $group"; # Showing progresses in the screen
	# Open the ah.st.cfg to identify the turns
	open CONF, "< ah.st.cfg" or die "Can't open ah.st.cfg: $!\n";
	while (<CONF>) {
		$flag = 0 if /^\[/; $flag = 1 if /^\[REPORT_FILES\]/;
		if ($flag and / = (.+)/) {
			push (@files, $1);}
	}
	close CONF;
	
	# Process each report file
	foreach (@files) {
		my $section = "Start"; my $file = $_; 
		print STDERR "."; # Showing one dot for each turn
		@events = ""; %units = (); %ships = (); # Reinicializing variables
		open REPORT, "< $file" or die "Can't open $file: $!\n";
		while (<REPORT>) {
			chomp;
			# Section control
			if (/^Events during turn:$/) {
				$section = "Events";
				next;
			} elsif (/^(Skill|Item|Object) reports:$/) {
				$section = "Skills";
				next;
			} elsif (/^Unclaimed silver: (\d+)/) {
				$section = "Regions";
				next;
			} elsif (/^Orders Template/) {
				last;
			}
			
			if ($section eq "Events" and !/^\s*$/) {
				# Gather multilines in a single line
				$line = /^  ./ ? $line . "$_" : "$_";
				push (@events, "$line\n") if (/\.$/ and $line =~ /$moves/);
			}
			
			# Get the units with the desired skills from the regions
			if ($section eq "Regions") {
				# Get the region coordinates, and initialize the $ship variable
				if (/^\w+ \((\d+,\d+[,a-z ]*)\)/) {$region = $1; $ship = "";} 
				$ship = $1 if /^\+ [a-zA-Z ]* (\[\d+\])/; # Store it for every building
				# Check the previous unit when we find the starting of one
				if ($line and (/^\s*[\*\+-] / or /^\s*$/)) {
					if ($line =~ /$skill/) {
						$ships{$ship} = 1 if $ship; # If inside a ship, record it
						($unit) = ($line =~ /\((\d+)\)/);
						$units{$unit} = 1; $regions{$region} = 1; # Fill the hashes keys
						$line = "";
					}
				}
				$line = (/^\s*[\*\+-] / or /^\s*$/) ? "$_\n" : $line . "$_\n"; # Gather multiline
			}
		}
		close REPORT;
		
		# Process the events for the turn, if related to movement
		foreach (@events) {
			if (/\((\d+)\)[^(]*?\((.+?)\)[^(]*?\((.+?)\)/) { 
				($unit,$origin,$dest) = ($1,$2,$3);
				($regions{$origin},$regions{$dest}) = (1,1) if (exists $units{$unit}); 
			}
			# Repeat for ships
			if (/(\[\d+\])[^(]*?\((.+?)\)[^(]*?\((.+?)\)/) { 
				($ship,$origin,$dest) = ($1,$2,$3);
				($regions{$origin},$regions{$dest}) = (1,1) if (exists $ships{$ship}); 
			}
		}
	}
	
	# Create tracking group
	$group .= " = ";
	$group .= "$_," foreach sort {$a <=> $b} keys %units;
	$group =~ s/,$//;
	push (@tracking, "$group\n");
	
	# Open the ah.his map, to search for resources
	open MAP, "< ah.his" or die "Can't open ah.his: $!\n";
	while (<MAP>) {
		chomp;
		$region = $1 if (/^\w+ \((\d+,\d+[,a-z ]*)\)/);
		if (/^\w/ and /$terrain/ and not exists $regions{$region}) {
			#my ($x,$y,$z) = ($region =~ /(\d+?),(\d+)(.*)/); Example on limitation of the results
			$regions{$region} = 2 ;#if (!$z && $x <= 60 && $y >= 40);
		}
		if (/^\s\s\w+? : (\w+) \((\d+,\d+[,a-z ]*)\)/) {
			my ($terrain_u, $region_u) = ($1, $2);
			$regions{$region_u} = 2 if ($terrain_u =~ /$terrain/ and not exists $regions{$region_u});
		}
		$flag = 1 if /^  Products:/; $flag = 0 if /^Exits:/;
		$regions{$region} = 0 if ($flag and /$prod/);
	}
	close MAP;
	
	# Print the results in the XXXX.txt file
	open DEST, "> $cfg_file" or die "Can't open $cfg_file: $!\n";
	print DEST "[LAND_FLAGS]\n\n";
	# Order by flag, then levels, then region numbers
	foreach (sort {$regions{$b} <=> $regions{$a} or index($a,"u") <=> index($b,"u") or index($a,",") <=> index($b,",")
			or substr($a,0,2) cmp substr($b,0,2) or length($a) <=> length($b) or $a cmp $b } keys %regions) {
		print DEST "$_ = $land_flag_0\n" if $regions{$_} == 1;
		print DEST "$_ = $land_flag_1\n" if $regions{$_} == 0;
		print DEST "$_ = $land_flag_2\n" if $regions{$_} == 2;
	}
	close DEST;
	print STDERR "\n";
}