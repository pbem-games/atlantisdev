# ALH configuration script - by Elricz (elricz.m@gmail.com)
#
# The goal of this script is to populate some of the ah.cfg file information used by
#    Atlantis Little Helper (ALH), based in the report.1 information from an Atlantis game.
# It uses the information about skills, items and objects from report.1, and it has been tested
#   with a file containing only that information (deleting the region reports).
# The name of the file is given as a parameter, and the result is given through the standard output,
#   so a way to use it from the command line in windows could be:
# perl ah_cfg.pl report.1 > results.txt
# The script has been tested in Windows XP with ActiveState Perl 5.8.6, and ALH 2.4.4

my $line = "";
# Property group variables
my ($skills, $mag_skills) = ("skills = ", "mag_skills = ");
my ($armament, $armor, $men, $mounts, $resources, $products, $tools, $trade, $mag_items) = 
	("armament = ", "armor = ", "men = ", "mounts = ", "resources = ", "products = ", "tools = ", "trade_items = ", "mag_items = ");

# Check the input
die "File name needed!\n" if ! @ARGV;

# Read from whatever file is passed in the command line
while (<>) {
	chomp;
	# Use the blank lines to check the data
	if (/^\s*$/) {
		(1) while ($line =~ s/(\S)  /$1 /g);
		# Headers
		print "[STUDYING_COST]\n\n" if $line =~ /^Skill reports:/;
		print "\n[WEIGHTS_CAPACITIES]\n\n" if $line =~ /^Item reports:/;
		print "\n[STRUCTURES]\n\n" if $line =~ /^Object reports:/;
		# Ships
		print "$1 = MOBILE\n" if $line =~ /^([a-zA-Z ]+): This is a ship/;
		# Skills
		if ($line =~ /^[a-z ]+ \[(\w+)\] \d:.* costs (\d+) silver/) {
			my ($skill, $cost) = ($1, $2);
			print "$skill = $cost\n";
			$skills .= $skill . "_, ";
			# Feeding property groups variables
			$mag_skills .= $skill . "_, " if $line=~/mage/;
		}
		# Items
		if ($line =~ /^[a-z ]+ \[(\w+)\], weight (\d+)/) {
			my ($item, $weight, $walk, $ride, $fly, $swim) = ($1, $2, 0, 0, 0, 0);
			$swim = $weight + $1 if $line =~ /swimming capacity (\d+)/;
			$walk = $weight + $1 if $line =~ /walking capacity (\d+)/;
			$ride = $weight + $1 if $line =~ /riding capacity (\d+)/;
			$fly = $weight + $1 if $line =~ /flying capacity (\d+)/;
			print "$item = $weight,$walk,$ride,$fly,$swim\n";
			# Feeding property groups variables
			$armament .= $item . ", " if $line=~/This is a .*? weapon/;
			$armor .= $item . ", " if $line=~/This is a type of armou?r/;
			$men .= $item . ", " if $line=~/This race may study/;
			$mounts .= $item . ", " if $line=~/This is a mount/;
			$resources .= $item . ", " if $line=~/may PRODUCE this item at a rate of/;
			$products .= $item . ", " if $line=~/may PRODUCE this item from/;
			$tools .= $item . ", " if $line=~/This is a tool/;
			$trade .= $item . ", " if $line=~/This is a trade good/;
			$mag_items .= $item . ", " if ($line=~/create this item via magic/ and $line!~/This is a monster/ and $line!~/may PRODUCE this/);
		}
	}
	# Gather multilines
	$line = /^\s*$/ ? "" : $line . "$_";
}
# Print the property group variables
print "\n[UNIT_PROPERTY_GROUPS]\n\n";
$armament =~ s/, $//; print "$armament\n";
$mag_items =~ s/, $//; print "$mag_items\n";
$armor =~ s/, $//; print "$armor\n";
$mag_skills =~ s/, $//; print "$mag_skills\n";
$men =~ s/, $//; print "$men\n";
$mounts =~ s/, $//; print "$mounts\n";
$skills =~ s/, $//; print "$skills\n";
$resources =~ s/, $//; print "$resources\n";
$products =~ s/, $//; print "$products\n";
$tools =~ s/, $//; print "$tools\n";
$trade =~ s/, $//; print "$trade\n";
