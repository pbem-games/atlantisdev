AtlantBot
version 1.0
Type: Random (Locust)

Usage: AtlaBot1 report.x
(where x is the player number)

Output: orders.txt is created by atlaBOT1 and should be renamed to orders.x

---------------------------------------------------------------------------

Notes:
The report must contain the order template from #atlantis to #end
including any password.

Run the atlantis host program in a batch file BEFORE an AtlantiBOT, that
way you can edit the orders an atlantiBOT creates before the next host run.

A sample Batch file should be included in this Archive, it assumes that the atlantiBOT and the atlantis host program are in your root directory of your
c drive. I also assumes that your game is in c:\atlantis\game1 and that you
wish factions 3,4,5 and 6 to be played by the atlantiBOT.

---------------------------------------------------------------------------

Future AtlantiBOTs may be found at http://www.nexus.bandits.org
email me bugs/suggestions at nexus@bandits.org

---------------------------------------------------------------------------

source code is included in pascal, I have not had time to sort
any bugs as I had intended before attaching it. Enjoy!