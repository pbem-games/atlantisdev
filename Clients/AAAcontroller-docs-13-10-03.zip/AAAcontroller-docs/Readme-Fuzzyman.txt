The Project
-----------

This script, program or package is released as part of the 'Atlantibots' project.

All scripts and documentation etc. are released under the GPL license - the appropriate copy of which *ought* to be in every distributed package.

For more details of the project as a whole, try the following locations :

Atlantibots message group 	- 	http://groups.yahoo.com/group/atlantis_talk/
Where we discuss the project and the code.

Sourceforge page			-	http://sourceforge.net/projects/atlantibot/
Where releases are made.

Project homepage			-	http://www.atlantibots.org.uk/



The Code
--------

The scripts are generally written in an interpreted language called 'Python'. This means that in order to run them 'as is' you will need a distribution of Python (Don't worry it's only a 9 meg install file). We reccomend the official one at http://www.python.org (but the activestate one is probably fine :-) If you want any help setting it up or using the scripts then post to the Atlantibots message group and several people will probably all try and help you at once and offer contradictory advice.

The scripts are currently run and tested under Python 2.3 

In the near future we may create binary versions (executable) of these scripts.... for windoze and Linux I guess. (Using py2exe)


Help Wanted !
-------------

We are interested in having people join the project and also welcome bug reports, comments and suggestions. There are plans for some of these 'functions' to be further developed in java and C++, so even if you're not a Python programmer feel free to join and make your contribution. Python is easy to learn though... so there's a gentle learning curve for those wanting to start from scratch. We'd also be interested in anyone willing to code a GUI front end to these scripts. As all this would have to do is build the config files and call the scripts (and perhaps display the data output by the script or integrate the orders generated) -  it could be in any language (OS dependent or not !) like Delphi or vb etc. We would also love to work on integrating these scripts into/with any of the existing Atlantis Clients - code and file formats can be tailored to make this possible. Playtesting and bug reports are an equally valid contribution however :-)



Atlantis Itself
---------------

About atlantis :

All the Atlantibot scripts are designed to run in conjuction with Atlantis  - the fantasy PBeM (Play by e-mail) game. Atlantis is an open-ended computer moderated fantasy game for any number of players. Players may attempt to carve out huge empires, become master magicians, intrepid explorers, rich traders or any other career that comes to mind. There is no declared winner of the game; players set their own objectives, and one can join at any time. 
If you are unfamiliar with it, here is the introduction from the rules...

It is a new world. An unclaimed world. Your mission? To claim what you can, and build your empire. It's as simple as that.
It is up to you to build up your armies, collect taxes from the peasants, build farms, castles, mines, lumber mills etc to provision your armies, and forge your empire. All the necessities of running an empire are at your fingertips. Are you capable? Do you have what it takes to be a Great Emporer? Can you build your armies, alliances, road networks, support economies to rule?

Useful Atlantis Links :
Atlantis Echelon, a good running game. 		-	http://www.geocities.com/dhadson/atlantis/index.html
A guide to playing Atlantis for beginners 	-	http://www.voidspace.org.uk/voidspace/intro_atlantis.shtml
The full ruleset for version 4.0.6			-	http://www.voidspace.org.uk/voidspace/atlantis_rules4.htm
All things Atlantis 					-	http://www.atlantis-pbem.org/
Atlantisdev, developers message group		-	http://groups.yahoo.com/group/atlantisdev/

Credits for Atlantis itself (taken from v4.0.6 rules) are as follows :

Atlantis was originally created and programmed by Russell Wallace. Russell Wallace created Atlantis 1.0, and partially designed Atlantis 2.0 and Atlantis 3.0.
Geoff Dunbar designed and programmed Atlantis 2.0 and 3.0, and created the Atlantis Project to freely release and maintain the Atlantis source code. See the Atlantis Project web page at http://www.prankster.com/project for more information, and more information on Credits.



Report Parsing
--------------

Robs functions :

Many of my functions are currently dependant of some of the functions of Rob McNeur, these are also released under the Atlantibot project (and the same GPL license).

These functions load in the config file and turn it into the appropriate values. They then load in the specified report and 'parse it' - turn it into a set of variables that can be worked with and modified (for example it extracts the order template and all the unit data which can be referenced by unit number). The functions I use are included in my distribution (unmodified) as seperate files. They are also available in full packages as distributed by Rob. See the web addresses mentioned above.

Those functions contain the following copyright notice :
Copyright (C) 2003 Rob McNeur
Rob may be contacted via email at rob@caverock.net.nz


The report parsing is currently optimised for Atlantis v4.0.6 reports. Efforts are being made to make them compatible with 4.0.10 reports and other potential Atlantis forks. Contact Rob for more details or if you have a 'fork' you want including in the report parsing functions.   



Project Description
-------------------

The Atlantibot project description :

An open source project for the development of Antlantibots and scripts. An Atlantibot automates part, or all of, the process of order generation in the 'Atlantis' fantasy, Play By eMail game (PBEM). e.g. Mapping and sentry monitoring bots.

This is a collaborative, open source project to produce scripts for the Atlantis PBeM game. We have several developers working in a few programming languages. The scripts will work together and also in conjunction with Atlantis Clients like 'Atlantis Helper' and Atlantis Crystal Ball. We are working towards fully automatic bots that can 'fight it out' in their own game (may the best bot win).... but along the way will develop various  tools ( RFAs - Robotic Faction Assistants) for players of Atlantis (version 4) who may want to automate part of running a faction - e.g. produce automated units for mapping the territory or maintain a network of sentries. 




Fuzzyman
--------

This particular script, program or package was released by Fuzzyman :

MSN and email		- 	fuzzyman@voidspace.org.uk
Yahoo id			-	dream_spinner2001
Homepage			-	http://www.voidspace.org.uk
Message group		-	http://groups.yahoo.com/group/Void-Shockz/

BTW - as I am in the UK all dates etc quoted in my scripts and docs follow the UK conventions......


All information correct on 4th September 2003 (04-09-03)



License
-------

All scripts, programs, docs etc are released (whether specifically stated or not) subject to the following conditions :

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA