Guide for Very Simple little bot...

If you are going to run this on an existing file it must be using the
MAP template....


The program will look for January, Year 1 and if it manages to find it
will move its leader in a random direction out of the Nexus, it will
also set the option template to MAP.

If the leader has no PATTERN skill it will study this on its second turn,
whilst also claiming enough silver to generate a 10 man unit...

On the third turn the leader will study EARTH, generate 6 scouts which all move
out and claim the rest of the gold.

After that
It will randomly study pattern/earth/force/fire or combat or tactics...
Or it will move, or it will generate a 10 man unit or another scout.

The normal men will either - work, study combat, generate a 10 man unit or
another scout...

Thats about it...

At some point I will make it more aware of the hex it is in.  Which should
allow it to start attacking, buying items (and also producing which is also
very easy to code)