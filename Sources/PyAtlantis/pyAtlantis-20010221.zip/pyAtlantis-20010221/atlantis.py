#!/usr/bin/python

##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################

"""
Usage:
atlantis.py run
    - run turn
atlantis.py check orders result
    - check orders and write result file
"""

from os import getcwd
import sys

from globals import *
from game.game import Game


print 'pyAtlantis - PBEM game server ' + ENGINE_VERSION
print COPYRIGHT
print

turndir = getcwd()


if len(sys.argv) < 2:
	print __doc__
	sys.exit()

command = sys.argv[1]
if command == 'run':
	turndir = getcwd()
	print 'atlantis: initialising game...'
	game = Game()
	game.initData()
	game.initReporter()
	game.loadWorld(turndir)
	game.parseOrders(turndir)
	game.runTurn()
	game.writeReports(turndir)
	game.saveWorld(turndir)
	sys.exit()
elif command == 'check':
	if len(sys.argv) < 4:
		# not enoug arguments
		print __doc__
		sys.exit()
	else:
		print 'atlantis: initialising game...'
		#game = Game()
		#game.initData()
		#game.initReporter()
		#game.loadWorld(turndir)
		#game.checkOrders(turndir + '/' + sys.argv[2], \
		#	turndir + '/' + sys.argv[3])
		orders = sys.argv[2]
		result = sys.argv[3]
		if orders[0] != '/':
			orders = turndir + '/' + orders
		if result[0] != '/':
			result = turndir + '/' + result
		of = open(orders, 'r')
		file = of.readlines()
		of.close()
		ch = open(result, 'w')
		for line in file:
			ch.write(line)
		ch.close()
		sys.exit()
else:
	print __doc__
	sys.exit()


def runTurn():
	turndir = getcwd()

	print 'atlantis: initialising game...'
	game = Game()

	game.initData()
	game.initReporter()
	game.loadWorld(turndir)
	game.parseOrders(turndir)
	game.runTurn()
	game.writeReports(turndir)
	game.saveWorld(turndir)

def checkOrders(orders, result):
	print 'atlantis: initialising game...'
	print 'checking', orders, result
	#game = Game()
	of = open(orders, 'r')
	file = of.readlines()
	of.close()
	ch = open(result, 'w')
	for line in file:
		ch.write(line)
	ch.close()
