##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from os.path import exists
from string import lower, replace, split, atoi
import re
from globals import *
from orders import Orders
from lib.string_utils import decodeText


class OrdersParser:
	"""Faction orders parser."""

	def __init__(self, game):
		"""Initialise parser."""
		self.game = game
		self.world = game.world
		self.reporter = game.reporter
		self.__tokens = {}
		self.__buildTokens()
		self.mode = ''
		#
		self.formedUnit = None  # formed Unit object

	def parseOrders(self, faction, filename):
		"""Parse faction's orders."""
		if not exists(filename):
			return
		file = open(filename, 'r')
		foundFaction = 0
		foundUnit = 0
		for line in file.readlines():
			line = line.strip()
			# ignore empty lines and comments
			if len(line) == 0 or line[:1] == ';':
				continue
			# end parsing, id #end found
			if re.search('^#end', line, re.I):
				# end found
				return
			if foundFaction:
				# faction already found, parse orders
				order = line.split(' ', 1)
				token = order[0]
				if len(order) > 1:
					arguments = order[1]
				else:
					arguments = ''
				if token == 'unit':
					result = re.search('^(\d+)', arguments, re.I)
					if result:
						foundUnit = int(result.group(1))
						continue
				if foundUnit:
					self.parseOrder(self.game.world.units[foundUnit], \
						token, arguments)
			else:
				# search for #atlantis line
				result = re.search('^#atlantis\s+(\d+)\s+(\S+)', line, re.I)
				if result:
					foundFaction = int(result.group(1))
					password = replace(result.group(2), '\"', '')
					if foundFaction != faction.id:
						# orders for wrong faction
						return
					if password != faction.password:
						# wrong password
						return
		file.close()

	def parseOrder(self, unit, token, args):
		"""Parse one order."""
		if token[:1] == '@':
			# default order for template
			unit.storedOrders.append(token + ' ' + args)
			token = token[1:]
		token = lower(token)
		if token == 'claim':
			self.parseClaimOrder(self.__unit(unit), args)
		elif token == 'describe':
			self.parseDescribeOrder(self.__unit(unit), args)
		elif token == 'end':
			self.parseEndOrder(unit, args)
		elif token == 'form':
			self.parseFormOrder(unit, args)
		elif token == 'move':
			self.parseMoveOrder(self.__unit(unit), args)
		elif token == 'name':
			self.parseNameOrder(self.__unit(unit), args)
		else:
			unit.error(self.reporter.returnTemplate('err_not_a_valid_order', \
				token))

	def parseMoveOrder(self, unit, args):
		"""Parse move order."""
		for dir in split(args):
			dir = lower(dir)
			if self.__tokens.has_key(('direction', dir)):
				unit.orders.add('move', self.__tokens[('direction', dir)])
			else:
				unit.error(self.game.data.error.move_bad_direction.message)
				return

	def parseNameOrder(self, unit, args):
		"""Parse NAME order."""
		if not args:
			unit.error(self.reporter.returnTemplate('err_name_no_argument'))
		else:
			list = split(args, ' ', 1)
			if len(list) < 2:
				unit.error(self.reporter.returnTemplate('err_name_no_name'))
			else:
				name = decodeText(list[1])
				if lower(list[0]) == 'faction':
					unit.orders.add('name', ('faction',name))
				elif lower(list[0]) == 'unit':
					unit.orders.add('name', ('unit',name))
				else:
					unit.error(self.reporter.returnTemplate('err_name_cant_name'))

	def parseDescribeOrder(self, unit, args):
		"""Parse DESCRIBE order."""
		if not args:
			unit.error(self.reporter.returnTemplate('err_describe_no_argument'))
		else:
			list = split(args, ' ', 1)
			if len(list) < 2:
				description = ''
			else:
				description = list[1]
			description = decodeText(description)
			if lower(list[0]) == 'unit':
				unit.orders.add('describe', ('unit',description))
			else:
				unit.error(self.reporter.returnTemplate('err_describe_cant_describe'))

	def parseFormOrder(self, unit, args):
		"""Parse FORM order."""
		result = re.search('^(\d+)$', args)
		if result:
			self.formedUnit = self.world.createUnit(unit.faction, \
				unit.structure.region)
		else:
			unit.error(self.reporter.returnTemplate('err_form_must_give_alias'))

	def parseEndOrder(self, unit, args):
		"""Parse END order."""
		if self.formedUnit:
			self.formedUnit = None
		else:
			unit.error(self.reporter.returnTemplate('err_end_without_form'))

	def parseClaimOrder(self, unit, args):
		"""Parse FORM order."""
		result = re.search('^(\d+)$', args)
		if result:
			unit.orders.add('claim', atoi(result.group(1)))
		else:
			unit.error(self.reporter.returnTemplate('err_claim_no_amount'))

	def __buildTokens(self):
		"""Build dictionary of possible tokens."""
		# directions
		for dir in self.game.data.direction.list():
			self.__tokens['direction', lower(dir.name)] = dir
			self.__tokens['direction', lower(dir.getRaw('abbr'))] = dir
			self.__tokens['direction', lower(dir.name_s)] = dir
			self.__tokens['direction', lower(dir.abbr)] = dir

	def __unit(self, unit):
		"""Return effective unit for orders.

		return formedUnit, if exists, or unit otherwise.
		"""
		if self.formedUnit:
			return self.formedUnit
		else:
			return unit