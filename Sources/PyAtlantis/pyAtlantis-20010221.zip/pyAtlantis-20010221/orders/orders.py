##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


class Orders:
	"""Holder object for all faction's or unit's orders.

	All orders are indexed by their name. Orders with identical names
	are grouped in list. Each order with multiple arguments is split
	in separate orders by parser, so each list element holds all arguments
	needed to run order once and only once. This feature when executing
	orders as result of get() is not checked for multiple orders.

	Content of order depends on order type and is set by parser and used
	by appropriate order runner; it has no meaning for Orders class.
	"""

	def __init__(self):
		"""Initialize orders."""
		self.__orders = {}

	def add(self, name, content):
		"""Add new order.

		Arguments:
		type -- order name, string
		content -- order arguments, type depends on order type
		"""
		order = self.__orders.setdefault(name, [])
		order.append(content)

	def get(self, name, default=None):
		"""Return content of one order.

		If order is defined, return content of first order and remove it
		from list, otherwise return default value.

		Arguments:
		name -- order name, string

		Returns: type depends on order type
		"""
		if self.__orders.has_key(name) and len(self.__orders[name]):
			content = self.__orders[name].pop(0)
			if len(self.__orders[name]) == 0:
				del self.__orders[name]
			return content
		else:
			return default

	def exists(self, name):
		"""Return true if order is defined, otherwise false.

		Arguments:
		name -- order name, string
		Returns: boolean
		"""
		return self.__orders.has_key(name) and len(self.__orders[name])

	def clear(self, name):
		"""Clear named orders.

		Arguments:
		name -- order name, string
		"""
		if self.__orders.has_key(name):
			del self.__orders[name]