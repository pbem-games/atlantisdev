##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


import re
from globals import *
from lib.fileio import TextFile


class Players:
	"""Version 4.0.4 players.in and players.out manipulation class."""

	def __init__(self, world):
		"""Initialise players."""
		self.world = world

	def readFile(self, filename):
		"""Read players.in file."""
		file = open(filename, 'r')
		contents = file.readlines()
		file.close()
		faction = ''
		for line in contents:
			line = line.strip()
			result = re.search('^Faction:\s+(.+)', line, re.I)
			if result:
				faction = result.group(1)
				continue
			result = re.search('^Name:\s+(.+)', line, re.I)
			if result:
				name = result.group(1)
				continue
			result = re.search('^Email:\s+(.+)', line, re.I)
			if result:
				address = result.group(1)
				continue
			result = re.search('^Password:\s+(.+)', line, re.I)
			if result:
				password = result.group(1)
			# for now ignore all factions but New
			if faction == 'New':
				self.world.createFaction(name, address, password)

	def writeFile(self, filename):
		"""Write players.out file."""
		file = TextFile()
		file.open(filename, 'w')
		file.writeln('Atlantis Player Status')
		file.writeln('Version ' + str(self.world.engineVersion))
		file.writeln('Turn number ' + str(self.world.turnNumber()))
		file.writeln('Status: Running')
		file.writeln('')
		for faction in self.world.listFactions():
			file.writeln('Faction: ' + str(faction.id))
			file.writeln('Name: ' + str(faction.name))
			file.writeln('Email: ' + str(faction.address))
			file.writeln('Password: ' + str(faction.password))
		file.close()