##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from globals import *
from lib.fileio import TextFile
from world.faction import Faction
from world.plane import Plane
from world.region import Region
from world.settlement import Settlement
from world.structure import Structure
from world.product import Product
from world.market import Market
from world.unit import Unit
from world.item import Item


class V4Reader:
	"""Version 4.0.4 compatible game.in file reader."""

	def __init__(self, world):
		"""Initialise file reader."""
		self.world = world
		self.game = world.game
		self.data = world.game.data
		self.directionCount = len(self.data.direction)

	def readFile(self, filename):
		"""Read game.in file."""
		self.file = file = TextFile()
		file.open(filename, 'r')
		world = self.world
		if file.str() != 'atlantis_game':
			raise Exception, 'Not a valid game.in file'
		world.engineVersion = file.str()
		world.name = file.str()
		world.rulesetVersion = file.str()
		world.year = file.int()
		world.month = file.int()
		world.randomSeed = file.int()
		world.nextFactionId = file.int()
		world.nextUnitId = file.int()
		world.nextShipId = file.int()
		world.guardFactionId = file.int()
		world.monsterFactionId = file.int()
		# read factions
		factionCount = file.int()
		factionIndex = 0
		while factionIndex < factionCount:
			faction = Faction(world)
			self.readFaction(faction)
			world.factions[faction.id] = faction
			factionIndex += 1
		# read planes and regions
		regionCount = file.int()
		planeCount = file.int()
		planeIndex = 0
		while planeIndex < planeCount:
			plane = Plane(world)
			plane.width = file.int()
			plane.height = file.int()
			plane.name = file.str()
			type = file.int()
			plane.type = self.game.data.plane.byId[type]
			world.planes[type] = plane
			planeIndex += 1
		world.gateCount = file.int()
		regionIndex = 0
		while regionIndex < regionCount:
			region = Region(world)
			self.readRegion(region)
			world.planes[region.plane.id].regions[region.coordinates] = region
			world.regions.append(region)
			regionIndex += 1
		if file.str() == 'Neighbors':
			regionIndex = 0
			while regionIndex < regionCount:
				directionIndex = 0
				while directionIndex < self.directionCount:
					regionId = file.int()
					if regionId > 0:
						world.regions[regionIndex].exits[directionIndex] = \
							world.regions[regionId]
					directionIndex += 1
				regionIndex += 1
		file.close()

	def readFaction(self, faction):
		"""Read faction data."""
		file = self.file
		faction.id = file.int()
		faction.warFP = file.int()
		faction.tradeFP = file.int()
		faction.magicFP = file.int()
		faction.lastChanges = file.int()
		faction.lastUpdates = file.int()
		faction.unclaimed = file.int()
		faction.name = file.str()
		faction.address = file.str()
		faction.password = file.str()
		faction.times = file.int()
		faction.report = file.int()
		# read faction skills
		skillCount = file.int()
		skillIndex = 0
		while skillIndex < skillCount:
			skillId = file.int()
			skillDays = file.int()
			faction.skills[skillId] = (self.game.data.skill.byId[skillId], \
				skillDays)
			skillIndex += 1
		# read faction attitudes
		faction.defaultAttitude = self.game.data.attitude.byId[file.int()]
		attitudeCount = file.int()
		attitudeIndex = 0
		while attitudeIndex < attitudeCount:
			factionId = file.int()
			attitude = self.game.data.attitude.byId[file.int()]
			faction.attitudes[factionId] = attitude
			attitudeIndex += 1


	def readRegion(self, region):
		"""Read region data."""
		file = self.file
		data = self.game.data
		region.province = file.str()
		region.id = file.int()
		region.terrain = data.terrain.byId[file.int()]
		region.nextStructureId = file.int()
		region.gate = file.int()
		race = file.int()
		if race > 0:
			region.race = data.item.byId[race]
		else:
			region.race = None
		region.population = file.int()
		region.basePopulation = file.int()
		region.wage = file.int()
		region.maxWage = file.int()
		region.tax = file.int()
		has_settlement = file.int()
		if has_settlement > 0:
			settlement = Settlement(region)
			settlement.name = file.str()
			settlement.population = file.int()
			settlement.basePopulation = file.int()
			region.settlement = settlement
		x = file.int()
		y = file.int()
		region.coordinates = (x,y)
		region.plane = data.plane.byId[file.int()]
		# read products
		productCount = file.int()
		productIndex = 0
		while productIndex < productCount:
			product = Product(region)
			item = file.int()
			product.item = data.item.byId[item]
			product.amount = file.int()
			product.baseAmount = file.int()
			skill = file.int()
			if skill > -1:
				product.skill = data.skill.byId[skill]
			product.level = file.int()
			product.productivity = file.int()
			region.production.append(product)
			productIndex += 1
		# read markets
		marketCount = file.int()
		marketIndex = 0
		while marketIndex < marketCount:
			market = Market(region)
			market.type = file.int()
			itemId = file.int()
			market.item = data.item.byId[itemId]
			market.price = file.int()
			market.amount = file.int()
			market.minPopulation = file.int()
			market.maxPopulation = file.int()
			market.minAmount = file.int()
			market.maxAmount = file.int()
			market.basePrice = file.int()
			region.markets.append(market)
			marketIndex += 1
		# read structures
		structureCount = file.int()
		structureIndex = 0
		while structureIndex < structureCount:
			structure = Structure(region)
			self.readStructure(structure)
			region.structures[structure.id] = structure
			structureIndex += 1

	def readStructure(self, structure):
		"""Read structure data."""
		file = self.file
		structure.id = file.int()
		structure.type = self.game.data.structure.byId[file.int()]
		structure.needed = file.int()
		structure.name = file.str()
		structure.description = file.str()
		structure.inner = file.int()
		structure.runes = file.int()
		# read units
		unitCount = file.int()
		unitIndex = 0
		while unitIndex < unitCount:
			unit = Unit(structure)
			self.readUnit(unit)
			structure.units.append(unit)
			self.world.units[unit.id] = unit
			unit.faction.units.append(unit)
			unit.faction.addPresence(structure.region)
			unitIndex += 1

	def readUnit(self, unit):
		"""Read unit data."""
		file = self.file
		data = self.game.data
		unit.name = file.str()
		unit.description = file.str()
		if unit.description == 'none':
			unit.description = ''
		unit.id = file.int()
		unit.type = file.int()
		unit.faction = self.world.factions[file.int()]
		unit.guard = file.int()
		unit.reveal = file.int()
		unit.flags = file.int()
		# read items
		itemCount = file.int()
		itemIndex = 0
		while itemIndex < itemCount:
			item = Item()
			item.owner = unit
			item.type = data.item.byId[file.int()]
			item.count = file.int()
			unit.items.append(item)
			itemIndex += 1
		# read skills
		skillCount = file.int()
		skillIndex = 0
		while skillIndex < skillCount:
			skillId = file.int()
			skillDays = file.int()
			unit.skills[skillId] = (data.skill.byId[skillId], skillDays)
			skillIndex += 1
		unit.combatSkill = file.int()


class V4Writer:
	"""Version 4.0.4 compatible game.out file writer."""

	def __init__(self, world):
		"""Initialise file writer."""
		self.world = world
		self.game = world.game
		self.data = world.game.data
		self.directionCount = len(self.data.direction)

	def writeFile(self, filename):
		"""Write game.out file."""
		self.file = file = TextFile()
		file.open(filename, 'w')
		world = self.world

		file.writeln("atlantis_game")
		file.writeln(world.engineVersion)
		file.writeln(world.name)
		file.writeln(world.rulesetVersion)
		file.writeln(world.year)
		file.writeln(world.month)
		file.writeln(world.randomSeed)
		file.writeln(world.nextFactionId)
		file.writeln(world.nextUnitId)
		file.writeln(world.nextShipId)
		file.writeln(world.guardFactionId)
		file.writeln(world.monsterFactionId)
		file.writeln(len(world.factions.keys()))
		# write factions
		factionIds = world.factions.keys()
		factionIds.sort()
		for id in factionIds:
			self.writeFaction(world.factions[id])
		# write planes and regions
		regionCount = len(world.regions)
		file.writeln(regionCount)
		file.writeln(len(world.planes.keys()))
		planeIds = world.planes.keys()
		planeIds.sort()
		for id in planeIds:
			file.writeln(world.planes[id].width)
			file.writeln(world.planes[id].height)
			file.writeln(world.planes[id].name)
			file.writeln(id)
		file.writeln(world.gateCount)
		regionIndex = 0
		while regionIndex < regionCount:
			self.writeRegion(world.regions[regionIndex])
			regionIndex += 1
		# write exits
		file.writeln('Neighbors')
		for region in world.regions:
			directionIndex = 0
			while directionIndex < self.directionCount:
				if region.exits.has_key(directionIndex):
					file.writeln(region.exits[directionIndex].id)
				else:
					file.writeln('-1')
				directionIndex += 1
		file.close()

	def writeFaction(self, faction):
		"""Write faction data."""
		file = self.file
		file.writeln(faction.id)
		file.writeln(faction.warFP)
		file.writeln(faction.tradeFP)
		file.writeln(faction.magicFP)
		file.writeln(faction.lastChanges)
		file.writeln(faction.lastUpdates)
		file.writeln(faction.unclaimed)
		file.writeln(faction.name)
		file.writeln(faction.address)
		file.writeln(faction.password)
		file.writeln(faction.times)
		file.writeln(faction.report)
		# write faction skills
		skillCount = len(faction.skills.keys())
		file.writeln(skillCount)
		skillIds = faction.skills.keys()
		skillIds.sort()
		for id in skillIds:
			skill,skillDays = faction.skills[id]
			file.writeln(id)
			file.writeln(skillDays)
		# write attitudes
		file.writeln(faction.defaultAttitude.id)
		attitudeCount = len(faction.attitudes.keys())
		file.writeln(attitudeCount)
		attitudeIds = faction.attitudes.keys()
		attitudeIds.sort()
		for id in attitudeIds:
			file.writeln(id)
			file.writeln(faction.attitudes[id].id)

	def writeRegion(self, region):
		"""Write region data."""
		file = self.file
		file.writeln(region.province)
		file.writeln(region.id)
		file.writeln(region.terrain.id)
		file.writeln(region.nextStructureId)
		file.writeln(region.gate)
		if region.race:
			file.writeln(region.race.id)
		else:
			file.writeln('-1')
		file.writeln(region.population)
		file.writeln(region.basePopulation)
		file.writeln(region.wage)
		file.writeln(region.maxWage)
		file.writeln(region.tax)
		if region.settlement:
			file.writeln('1')
			file.writeln(region.settlement.name)
			file.writeln(region.settlement.population)
			file.writeln(region.settlement.basePopulation)
		else:
			file.writeln('0')
		x,y = region.coordinates
		file.writeln(x)
		file.writeln(y)
		file.writeln(region.plane.id)
		# write production
		file.writeln(len(region.production))
		for product in region.production:
			file.writeln(product.item.id)
			file.writeln(product.amount)
			file.writeln(product.baseAmount)
			if product.skill:
				file.writeln(product.skill.id)
			else:
				file.writeln('-1')
			file.writeln(product.level)
			file.writeln(product.productivity)
		# write markets
		file.writeln(len(region.markets))
		for market in region.markets:
			file.writeln(market.type)
			file.writeln(market.item.id)
			file.writeln(market.price)
			file.writeln(market.amount)
			file.writeln(market.minPopulation)
			file.writeln(market.maxPopulation)
			file.writeln(market.minAmount)
			file.writeln(market.maxAmount)
			file.writeln(market.basePrice)
		# write structures
		file.writeln(len(region.structures.keys()))
		for structure in region.structures.values():
			self.writeStructure(structure)

	def writeStructure(self, structure):
		"""Write structure data."""
		file = self.file
		file.writeln(structure.id)
		file.writeln(structure.type.id)
		file.writeln(structure.needed)
		file.writeln(structure.name)
		file.writeln(structure.description)
		file.writeln(structure.inner)
		file.writeln(structure.runes)
		# write units
		file.writeln(len(structure.units))
		for unit in structure.units:
			self.writeUnit(unit)

	def writeUnit(self, unit):
		"""Write unit data."""
		file = self.file
		file.writeln(unit.name)
		if unit.description == '':
			file.writeln('none')
		else:
			file.writeln(unit.description)
		file.writeln(unit.id)
		file.writeln(unit.type)
		file.writeln(unit.faction.id)
		file.writeln(unit.guard)
		file.writeln(unit.reveal)
		file.writeln(unit.flags)
		# write items
		file.writeln(len(unit.items))
		for item in unit.items:
			file.writeln(item.type.id)
			file.writeln(item.count)
		# write skills
		file.writeln(len(unit.skills.keys()))
		skillIds = unit.skills.keys()
		for id in skillIds:
			skill,skillDays = unit.skills[id]
			file.writeln(id)
			file.writeln(skillDays)
		file.writeln(unit.combatSkill)
