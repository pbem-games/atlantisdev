##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from os import listdir
from string import lower
import re
from globals import *
from lib.atlantis_xml import AtlantisXMLParser
from data import GameData, DataXMLHandler
from reports.reporter_xml import TemplateXMLHandler
from world.world import World
from version4 import V4Reader, V4Writer
from players import Players
from orders.parser import OrdersParser
from reports.reporter import Reporter


class Game:
	"""Atlantis game class."""

	def __init__(self):
		self.data = None
		self.world = World(self)
		self.reporter = None
		self.players = Players(self.world)

	def initData(self):
		"""Initialise game data."""
		print 'game: initialising game data...'
		parser = AtlantisXMLParser()
		self.data = GameData(self)
		handler = DataXMLHandler(self.data)
		for file in listdir(BINARY_HOME + '/data'):
			if lower(file[-4:]) == '.xml':
				print 'game: parsing ' + file + '...'
				parser.parseFile(BINARY_HOME + '/data/' + file, handler)
		print 'game: initialising reporter...'
		self.reporter = Reporter(self.world)
		handler = TemplateXMLHandler(self.reporter)
		for file in listdir(BINARY_HOME + '/templates'):
			if lower(file[-4:]) == '.xml':
				print 'game: parsing ' + file + '...'
				parser.parseFile(BINARY_HOME + '/templates/' + file, handler)

	def initReporter(self):
		"""Initialise reporter."""
		print 'game: initialising reporter...'

	def loadWorld(self, dir):
		"""Load world data."""
		print 'game: loading game.in file...'
		reader = V4Reader(self.world)
		reader.readFile(dir + '/game.in')
		print 'game: loading players.in file...'
		self.players.readFile(dir + '/players.in')

	def saveWorld(self, dir):
		"""Save world data."""
		print 'game: saving game.out file...'
		writer = V4Writer(self.world)
		writer.writeFile(dir + '/game.out')
		print 'game: saving players.out file...'
		self.players.writeFile(dir + '/players.out')

	def parseOrders(self, dir):
		"""Parse turn orders."""
		print 'game: parsing orders...'
		parser = OrdersParser(self)
		parser.mode = 'run'
		for faction in self.world.listFactions():
			if faction.id > 2:
				# ignore guard and monster factions
				parser.parseOrders(faction, dir + '/orders.' \
					+ str(faction.id))

	def runTurn(self):
		"""Run turn sequence."""
		print 'game: running turn sequence...'
		self.runNameDescribeOrders()
		self.runClaimOrders()
		#self.runFindOrders()
		#self.runEnterOrders() #ENTER/LEAVE
		#self.runPromoteOrders()
		#self.runAttackOrders()
		#self.runAutoAttacks()
		#self.runStealOrders() #STEAL/ASSASINATE
		#self.runGiveOrders() #GIVE/PAY/TRANSFER
		#self.runDestroyOrders()
		#self.runPillageOrders()
		#self.runTaxOrders()
		#self.runGuard1Orders()
		#self.runCastOrders()
		#self.runSellOrders()
		#self.runBuyOrders()
		#self.runForgetOrders()
		#self.runQuitOrders()
		#self.runSailOrders()
		self.runMoveOrders()
		#self.runTeachOrders()
		#self.runMonthOrders()
		#self.runTeleportOrders()

	def writeReports(self, dir):
		"""Write turn reports."""
		print 'game: writing turn reports...'
		for faction in self.world.listFactions():
			if faction.id > 2:
				# ignore guard and monster factions
				self.reporter.renderTemplate('standard_report', faction, \
					dir + '/report.' + str(faction.id))

	def checkOrders(self, orders, result):
		"""Check orders."""
		print 'game: checking orders...'
		result = re.search('\.(\d+)$', orders, re.I)
		if result:
			faction = self.world.factions[int(result.group(1))]
			parser = OrdersParser(self)
			parser.mode = 'check'
			parser.parseOrders(faction, orders)

	def runMoveOrders(self):
		"""Run MOVE orders."""
		print 'game: running MOVE orders...'
		# TODO: change according to rules
		for unit in self.world.units.values():
			unit.movePoints = 100 # temporary hack
			while unit.orders.exists('move'):
				unit.runMoveOrder()

	def runNameDescribeOrders(self):
		"""Run NAME/DESCRIBE orders."""
		print 'game: running NAME/DESCRIBE orders...'
		# name/describe factions
		for unit in self.world.units.values():
			while unit.orders.exists('name'):
				unit.runNameOrder()
			while unit.orders.exists('describe'):
				unit.runDescribeOrder()

	def runClaimOrders(self):
		"""Run CLAIM orders."""
		print 'game: running CLAIM orders...'
		for unit in self.world.units.values():
			while unit.orders.exists('claim'):
				unit.runClaimOrder()
