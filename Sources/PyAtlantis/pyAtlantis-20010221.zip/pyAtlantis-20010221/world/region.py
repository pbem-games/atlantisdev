##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from globals import *


class Region:
	"""Region definition."""

	def __init__(self, world):
		"""Initialise region."""
		self.world = world
		self.game = world.game
		self.data = world.game.data
		#
		self.id = 0
		self.plane = None
		self.coordinates = (0,0)
		self.terrain = None
		self.province = ''
		self.settlement = None
		self.gate = None
		self.race = None
		self.exits = {}
		self.population = 0
		self.production = []
		self.markets = []
		self.structures = {}

	def listExits(self):
		"""Return list of (direction,region) for existing exits."""
		exits = []
		for dir in self.data.direction.keys():
			if self.exits.has_key(dir):
				exits.append((self.data.direction.byId[dir], \
					self.exits[dir]))
		return exits

	def listUnits(self, faction=None):
		"""Return list of faction's units or all units, if none faction."""
		units = []
		for structure in self.structures.values():
			for unit in structure.units:
				if faction == None or unit.faction == faction:
					units.append(unit)
		return units

	def getExit(self, direction):
		"""Return region in direction from this region or None."""
		return self.exits.get(direction.id, None)

	def getPopulation(self):
		"""Return region population."""
		if self.settlement:
			return self.population + self.settlement.population
		else:
			return self.population

	def getMoney(self):
		"""Return amount of money available in region."""
		return 0

	def getDummyStructure(self):
		"""Return region's dummy structure."""
		return self.structures[0]
