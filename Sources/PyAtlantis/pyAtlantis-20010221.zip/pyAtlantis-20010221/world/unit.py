##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from orders.orders import Orders


class Unit:
	"""Unit definition."""

	def __init__(self, structure):
		"""Initialise unit."""
		self.structure = structure
		self.game = structure.game
		self.data = structure.data
		self.reporter = self.game.reporter
		#
		self.faction = None
		self.id = 0
		self.name = ''
		self.description = ''
		self.type = 0
		self.guard = 0
		self.reveal = 0
		self.flags = 0
		self.items = []
		self.skills = {}
		self.combatSkill = 0
		self.movePoints = 0
		self.storedOrders = []
		self.orders = Orders()
		self.monthOrder = ''

	def moveInStructure(self, region, structure=None):
		"""Move unit into structure in region or into dummy structure."""
		if self.structure:
			# we are inside another structure
			self.structure.units.remove(self)
			self.faction.removePresence(self.structure.region)
		if not structure:
			# no structure defined, find dummy structure
			structure = region.getDummyStructure()
		self.structure = structure
		structure.units.append(self)
		self.faction.addPresence(region)

	def moveInDirection(self, direction):
		"""Move in given direction."""
		region = self.structure.region.getExit(direction)
		if not region:
			# no exit
			self.error(self.reporter.returnTemplate( \
				'err_move_bad_direction'))
			return 0
		if region.terrain.id == self.data.terrain.ocean.id:
			# found ocean
			# TODO: check swimming units
			self.error(self.reporter.returnTemplate( \
				'err_move_found_ocean', region))
			return 0
		requiredMovePoints = region.terrain.movepoints
		if self.movePoints < requiredMovePoints:
			# not enough movepoints
			self.error(self.reporter.returnTemplate( \
				'err_move_not_enough_movepoints'))
			return 0
		else:
			self.event(self.reporter.returnTemplate('msg_move_from_to_region', \
				(0,self.structure.region,region)))
			self.moveInStructure(region)
			self.movePoints -= requiredMovePoints
		return 1

	def error(self, message):
		"""Add error message for unit."""
		self.faction.errors.append(self.name + ': ' + message)

	def event(self, message):
		"""Add event message for unit."""
		self.faction.events.append(self.name + ': ' + message)

	def runMoveOrder(self):
		"""Run one MOVE order."""
		direction = self.orders.get('move')
		if direction:
			moved = self.moveInDirection(direction)
			if not moved:
				self.orders.clear('move')

	def runNameOrder(self):
		"""Run one NAME order."""
		object,name = self.orders.get('name')
		if object == 'faction':
			# name faction
			self.faction.name = name + ' (' + str(self.faction.id) + ')'
		elif object == 'unit':
			# name unit
			self.name = name + ' (' + str(self.id) + ')'

	def runDescribeOrder(self):
		"""Run one DESCRIBE order."""
		object,description = self.orders.get('describe')
		if object == 'unit':
			# describe unit
			self.description = description

	def runClaimOrder(self):
		"""Run one CLAIM order."""
		sum = self.orders.get('claim')
		if sum <= self.faction.unclaimed:
			# faction has enough money
			self.changeMoney(sum)
			self.faction.unclaimed -= sum
		else:
			# not enough money
			self.error(self.reporter.returnTemplate('err_claim_dont_have'))
			self.changeMoney(self.faction.unclaimed)
			self.faction.unclaimed = 0

	def changeMoney(self, diff):
		"""Change amount of unit's money."""
		self.event(self.reporter.returnTemplate('msg_claims', diff))
		print 'changed', diff
		pass