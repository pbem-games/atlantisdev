##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from string import rfind
from globals import *
from lib.fileio import FormattedFile


class Reporter:
	"""Player report writing engine."""

	def __init__(self, world):
		"""Initialise reporter."""
		self.world = world
		self.game = world.game
		self.data = self.game.data
		#
		self.faction = None
		self.file = None
		self.__templates = {}
		self.separator = ''

	def renderTemplate(self, template, faction, filename):
		"""Render template contents and write to file."""
		self.faction = faction
		self.file = FormattedFile()
		self.file.open(filename, 'w')
		self._processTemplate(template, faction)
		self.file.close()

	def returnTemplate(self, template, object=None):
		"""Return rendered template as string."""
		# TODO: size limitations!!!!!
		self.file = _TextBuffer()
		self._processTemplate(template, object)
		text = self.file.text
		self.file = None
		return text

	def _processTemplate(self, name, object=None):
		"""Process template contents."""
		for element in self._getTemplate(name, ENGINE_LANGUAGE):
			action = element['type']
			# object
			if element.has_key('object'):
				# new object defined
				elementObject = eval(element['object'])
			else:
				elementObject = object
			# check condition
			if not element.has_key('condition') or eval(element['condition']):
				# no condition defined or condition is true
				value = element['value']
			elif element.has_key('else_type') \
					and element.has_key('else_value'):
				# else_type and else_value defined
				action = element['else_type']
				value = element['else_value']
			elif element.has_key('else'):
				# else defined
				value = element['else']
			else:
				# condition false, do not parse element
				continue
			# check sequence
			if element.has_key('sequence'):
				# sequence defined
				sequence = eval(element['sequence'])
				if len(sequence):
					# sequence is not zero length
					for item in sequence:
						self._processElement(action, value, item)
				elif element.has_key('alternative_type') and \
						element.has_key('alternative_value'):
					# alternative_type and alternative_value defined
					self._processElement(element['alternative_type'], \
						element['alternative_value'], elementObject)
				elif element.has_key('alternative'):
					# alternative defined
					self._processElement(action, element['alternative'], elementObject)
			else:
				# no sequence, do once
				self._processElement(action, value, elementObject)

	def _processElement(self, action, value, object):
		"""Process single template element."""
		if action == 'include':
			self._processTemplate(value, object)
		elif action == 'eval':
			self.file.format(eval(value))
		elif action == 'exec':
			exec(value)
		elif action == 'text':
			self.file.format(value)
		elif action == 'line':
			self.file.format(value = '\n')

	def t_separatorOn(self, string=', '):
		"""Activate item separator."""
		self.separator = string

	def t_separatorOff(self):
		"""Deactivate item separator."""
		self.separator = ''

	def t_newline(self):
		"""Template callable method: add new line."""
		self.file.format('\n')

	def t_space(self):
		"""Template callable method: add space."""
		self.file.format(' ')

	def t_indent(self, count=1):
		"""Template callable method: add or remove indents."""
		self.file.addIndent(count)

	def t_commentOn(self):
		"""Switch output to comment mode."""
		# NOTE: contents of buffer is lost
		self.file.setPrefix(';')

	def t_commentOff(self):
		"""Switch output to normal (uncommented) mode."""
		# Note: contents of buffer is lost
		self.file.setPrefix('')

	def t_set_width(self, width):
		"""Set max width for formatted output."""
		self.file.setWidth(width)

	def t_set_indent(self, width):
		"""Set indent width fot wrapped lines of formatted output."""
		self.file.setIndent(width)

	def t_set_prefix(self, string):
		"""Set prefix string for lines of formatted output."""
		self.file.setPrefix(string)

	def _addElement(self, name, language, contents):
		"""Add no element definition to the template."""
		template = self.__templates.setdefault((name,language), [])
		template.append(contents)

	def _getTemplate(self, name, language='en'):
		"""
		Return template definition for language or default language.

		Returns list of template elements.
		"""
		return self.__templates.get((name, language), \
			self.__templates[(name, 'en')])


class _TextBuffer:
	"""Text buffer to imitate file output."""

	def __init__(self):
		"""Initialise buffer."""
		self.text = ''

	def write(self, data):
		"""Append data to buffer."""
		self.text += str(data)

	def writeln(self, data):
		"""Append data and new line."""
		self.text += str(data)
		self.text += '\n'

	def format(self, data):
		"""Append data to buffer."""
		self.text += str(data)