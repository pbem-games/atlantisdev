##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from string import strip, find, rfind, split
from globals import *


class TextFile:
	"""Atlantis text file manipulation class."""

	def __init__(self):
		"""Initialise file."""
		self.__file = None

	def open(self, filename, mode='r'):
		"""Open file."""
		self.__file = open(filename, mode)

	def close(self):
		"""Close file."""
		self.__file.close()

	def write(self, data):
		"""Write data to file."""
		self.__file.write(str(data))

	def writeln(self, data):
		"""Write data and add new line."""
		self.__file.write(str(data))
		self.__file.write('\n')

	def int(self):
		"""Read line as integer value."""
		return int(self.__file.readline())

	def str(self):
		"""Read line as string value."""
		return self.__file.readline().strip()


class FormattedFile(TextFile):
	"""Formatted text file manipulation class.

	Output can be formatted to wrap lines, indent text of wrapped lines
	and to prepend lines with arbitrary string.
	"""

	def __init__(self):
		"""Initialise formatted file."""
		TextFile.__init__(self)
		self.__buffer = ''
		self.__width = 0 # max length of output line, 0 is unlimited
		self.__indent = 0 # indent in chars for wrapped lines
		self.__prefix = '' # prefix string to be added before each line

	def format(self, data):
		"""Split data to lines and format each line."""
		# if empty buffer, insert needed prefix and indent
		if not self.__buffer:
			self.__buffer = self.__prefix
		# split data in lines at \n's
		data = str(data)
		while data:
			splitter = find(data, '\n')
			if splitter > -1:
				# new line found
				self._formatLine(data[:splitter])
				self.writeln(self.__buffer)
				self.__buffer = ''
				data = data[splitter+1:]
			else:
				self._formatLine(data)
				data = ''

	def _formatLine(self, line):
		"""Format one line."""
		self.__buffer += line
		while self.__width and len(self.__buffer) > self.__width:
			splitter = rfind(self.__buffer, ' ', 0, self.__width)
			self.writeln(self.__buffer[:splitter])
			self.__buffer = self.__prefix + ' ' * self.__indent \
				+ self.__buffer[splitter+1:]

	def close(self):
		"""Flush output buffer and close file."""
		self.write(self.__buffer)
		TextFile.close(self)

	def setWidth(self, width):
		"""Set max width of formatted output."""
		if width > 0:
			self.__width = width
		else:
			self.__width = 0

	def setIndent(self, width):
		"""Set width of indent for wrapped lines."""
		if width > 0:
			self.__indent = width
		else:
			self.__indent = 0

	def setPrefix(self, string):
		"""Set prefix string for output lines."""
		self.__prefix = string
		if string and self.__buffer == '':
			self.__buffer = string

	def addIndent(self, count):
		"""Add indent to prefix."""
		if count > 0:
			# add indent
			self.__prefix += ' ' * self.__indent * count
		elif count < 0:
			# remove indent
			self.__prefix = self.__prefix[:self.__indent * count]