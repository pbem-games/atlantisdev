##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from globals import *

class Faction:
	"""Faction definition."""

	def __init__(self, world):
		"""Initialise faction."""
		self.world = world
		self.game = world.game
		self.data = world.game.data
		self.reporter = world.game.reporter
		#
		self.id = 0
		self.warFP = 0
		self.tradeFP = 0
		self.magicFP = 0
		self.lastChanges = 0
		self.lastUpdates = 0
		self.unclaimed = 0
		self.name = ''
		self.address = ''
		self.password = ''
		self.times = 0
		self.report = 0
		self.skills = {}
		self.defaultAttitude = None
		self.attitudes = {}
		self.units = []
		self.presentRegions = []
		self.errors = []
		self.events = []

	def addPresence(self, region):
		"""Add region to faction's region presence list."""
		if region not in self.presentRegions:
			self.presentRegions.append(region)

	def removePresence(self, region):
		"""If no units, remove region from faction's region presence list."""
		if not region.listUnits(self):
			self.presentRegions.remove(region)

	def startGame(self):
		"""Setup faction for game."""
		# TODO: values from global data
		self.defaultAttitude = self.data.attitude.neutral
		self.warFP = 1
		self.tradeFP = 1
		self.magicFP = 1
		self.unclaimed = 5020 + self.world.turnNumber() * 50
		# TODO: more flexible way to get starting region
		nexus = self.world.regions[0]
		unit = self.world.createUnit(self, nexus)
		self.units.append(unit)

	def allowedMages(self):
		"""Return number of allowed mages."""
		return self.data.globals.allowed_mages.value[self.magicFP]

	def allowedTaxes(self):
		"""Return number of allowed tax regions."""
		return self.data.globals.allowed_taxes.value[self.warFP]

	def allowedTrades(self):
		"""Return number of allowed trade regions."""
		return self.data.globals.allowed_trades.value[self.tradeFP]

	def magesCount(self):
		"""Return number of mages."""
		return 0

	def taxRegions(self):
		"""Return number of tax regions."""
		return 0

	def tradeRegions(self):
		"""Return number of trade regions."""
		return 0

	def reportBattles(self):
		"""Return list of report battles."""
		return []

	def reportSkills(self):
		"""Return list of report skills."""
		return []

	def reportItems(self):
		"""Return list of report items."""
		return []

	def getAttitudeFactions(self, attitude):
		"""Return list of factions for declared attitude."""
		factions = []
		for factionId,att in self.attitudes.items():
			if att.id == attitude.id:
				factions.append(self.world.factions[factionId])
		return factions

	def event(self, message):
		"""Add event message for faction."""
		self.events.append(message)

	def timesReward(self):
		"""Pay Times Reward."""
		reward = self.data.globals.times_reward.int
		if reward:
			self.event(self.reporter.returnTemplate('msg_times_reward', reward))
			self.unclaimed += reward