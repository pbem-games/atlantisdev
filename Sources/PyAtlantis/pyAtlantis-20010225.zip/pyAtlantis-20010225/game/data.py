##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from string import lower
from globals import *
from lib.atlantis_xml import AtlantisXMLHandler


class GameData:
	"""Game data storage class."""

	def __init__(self, game):
		"""Initialise game data."""
		self.game = game
		self.__categories = {}

	def _addCategory(self, name):
		"""Add and return data category or return existing category."""
		return self.__categories.setdefault(name, _DataCategory())

	def __getattr__(self, name):
		"""Return DataCategory instance."""
		return self.__categories[name]


class _DataCategory:
	"""Data category definition."""

	def __init__(self):
		"""Initialise data category."""
		self.__exemplars = {}
		self.__attributes = {}
		self.__indices = {}
		# add mandatory attributes
		self._addAttribute('id', 'integer', 'true')
		self._addAttribute('name', 'string', 'true')

	def _addAttribute(self, name, type, index):
		"""Add attribute definition."""
		self.__attributes[name] = type
		if index == 'true':
			self.__indices[name] = {}

	def _addExemplar(self, name, attrs):
		"""Add or update data exemplar definition."""
		exemplar = self.__dict__.setdefault(name, _DataExemplar(name, self))
		for attribute,rawValue in attrs.items():
			type = self.__attributes.get(attribute, 'integer')
			if type == 'integer':
				value = int(rawValue)
			elif type == 'string':
				value = rawValue
			elif type == 'eval':
				value = eval(rawValue)
			else:
				raise Error, 'Wrong attribute type'
			exemplar._addAttribute(attribute, value)
			# update indices
			if attribute in self.__indices.keys():
				self.__indices[attribute][value] = exemplar
		return exemplar

	def __getattr__(self, name):
		"""Return attribute value."""
		# try to find index
		if name[:2] == 'by':
			return self.__indices[lower(name[2:])]
		else:
			raise AttributeError, 'Wrong exemplar index name'

	def __len__(self):
		"""Return number of category exemplars."""
		return len(self.__indices['id'])

	def keys(self):
		"""Return sorted list of exemplar keys (ids)."""
		keys = self.__indices['id'].keys()
		keys.sort()
		return keys

	def list(self):
		"""Return list of exemplars sorted by keys."""
		return map(self.__getById, self.keys())

	def __getById(self, id):
		"""Return exemplar by it's id."""
		return self.__indices['id'][id]


class _DataExemplar:
	"""Data exemplar definition."""

	def __init__(self, name, category):
		"""Initialise data exemplar."""
		self.name = name
		self.category = category
		self.__attributes = {}
		self.__modifiers = {}
		self.__translations = {}

	def _addAttribute(self, name, value):
		"""Add attribute value."""
		self.__attributes[name] = value

	def _addModifier(self, attrs):
		"""Add modifier definition."""
		modifier = self.__modifiers.setdefault((attrs['category'] ,\
			attrs['exemplar']), {})
		for name,value in attrs.items():
			if name != 'category' and name != 'exemplar':
				modifier[name] = value

	def _addTranslation(self, attrs):
		"""Add modifier translation."""
		for name, value in attrs.items():
			if name != 'language':
				self.__translations[attrs['language'], name] = value

	def __getattr__(self, name):
		"""Return translated attribute value."""
		# TODO: implement modifiers here
		# NOTE: if used instead of get() to allow translations for
		# undefined English attributes
		if self.__translations.has_key((ENGINE_LANGUAGE,name)):
			return self.__translations[(ENGINE_LANGUAGE, name)]
		else:
			return self.__attributes[name]

	def getRaw(self, name):
		"""Return unmodified and untranslated attribute value."""
		return self.__attributes[name]


class DataXMLHandler(AtlantisXMLHandler):
	"""Game data XML handler."""

	def __init__(self, data):
		"""Initialise data handler."""
		self.data = data
		AtlantisXMLHandler.__init__(self)
		self.category = None
		self.exemplar = None

	def handleStartTag(self, tag, attrs):
		"""Handle XML start tag."""
		if tag == 'category':
			# category definition
			name = attrs.get('name', '')
			if name:
				self.category = self.data._addCategory(name)
		elif tag == 'attribute' and self.currentTag() == 'category':
			# category attribute definition
			self.category._addAttribute(attrs['name'], attrs['type'], \
				attrs.get('index', 'false'))
		elif tag == 'exemplar' and self.currentTag() == 'category':
			# exemplar definition
			name = attrs.get('name', '')
			if name:
				self.exemplar = self.category._addExemplar(name, attrs)
		elif tag == 'modifier' and self.currentTag() == 'exemplar':
			# exemplar modifier definition
			if attrs.has_key('category') and attrs.has_key('exemplar'):
				self.exemplar._addModifier(attrs)
		elif tag == 'translation' and self.currentTag() == 'exemplar':
			# exemplar translation definition
			if attrs.has_key('language'):
				self.exemplar._addTranslation(attrs)

	def handleEndTag(self, tag):
		"""Handle XML end tag."""
		if tag != self.currentTag():
			# closing non-open tag, error
			return
		if tag == 'category':
			# close category definition
			self.category = None
			self.exemplar = None
		elif tag == 'exemplar':
			# close exemplar definition
			self.exemplar = None



	