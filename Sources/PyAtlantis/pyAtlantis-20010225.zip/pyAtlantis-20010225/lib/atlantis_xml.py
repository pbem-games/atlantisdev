##############################################################################
#
# pyAtlantis - PBEM game server inspired by Geoff Dunbar's Atlantis
#
# Copyright (C) 2001 Vitauts Stochka
#
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation; either version 2 of the License, or (at your option)
# any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
#
##############################################################################


from xmllib import *


class AtlantisXMLHandler:
	"""Atlantis XML data handler base class."""

	def __init__(self):
		"""Initialise data handler."""
		self.__stack = []

	def handleData(self, data):
		"""Handle tag data.
		This must be overrided in subclass.
		"""
		pass

	def handleStartTag(self, tag, attrs):
		"""Handle start tag.
		This must be overrided in subclass.
		"""
		pass

	def handleEndTag(self, tag, attrs):
		"""Handle end tag.
		This must be overrided in subclass.
		"""
		pass

	def currentTag(self):
		"""Return name of current tag from tag stack."""
		if len(self.__stack):
			return self.__stack[-1]
		else:
			return ''

	def openTag(self, tag, attrs):
		"""Invoke handler and add tag name to the stack."""
		self.handleStartTag(tag, attrs)
		self.__stack.append(tag)

	def closeTag(self, tag):
		"""Invoke handler and remove tag name from the stack."""
		self.handleEndTag(tag)
		if self.currentTag() == tag:
			self.__stack.pop()


class AtlantisXMLParser(XMLParser):
	"""Atlantis XML file parser."""

	def __init__(self):
		"""Initialise file parser."""
		XMLParser.__init__(self)
		self.handler = None
		self.__buffer = ''

	def parseFile(self, filename, handler):
		"""Parse XML file using handler."""
		self.reset()
		self.handler = handler
		file = open(filename, 'r')
		data = file.read()
		for char in data:
			self.feed(char)
		self.handler = None

	def unknown_starttag(self, tag, attrs):
		"""Handler for all start tags."""
		self.flush()
		self.handler.openTag(tag, attrs)

	def unknown_endtag(self, tag):
		"""Handler for all end tags."""
		self.flush()
		self.handler.closeTag(tag)

	def flush(self):
		"""Flush data buffer."""
		data = self.__buffer.strip()
		if data:
			self.handler.handleData(data)
		self.__buffer = ''

	def handle_data(self, data):
		"""Handle tag data."""
		# ignore leading spaces
		if data != ' ' or self.__buffer != '':
			self.__buffer += data
