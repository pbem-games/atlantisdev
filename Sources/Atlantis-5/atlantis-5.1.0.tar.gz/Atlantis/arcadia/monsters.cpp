// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
// MODIFICATIONS
// Date        Person            Comments
// ----        ------            --------
// 2001/Mar/03 Joseph Traub      Moved some of the monster stuff here
//
#include "gamedata.h"
#include "game.h"

void Game::CreateVMons()
{
	if(!Globals->LAIR_MONSTERS_EXIST) return;

	forlist(&regions) {
		ARegion * r = (ARegion *) elem;
		forlist(&r->objects) {
			Object * obj = (Object *) elem;
			if(obj->type != O_BKEEP) continue;
			Faction *monfac = GetFaction( &factions, 2 );
			Unit *u = GetNewUnit( monfac, 0 );
			u->MakeWMon( "Arch Dragons", I_DRAGON, 6);
			u->MoveUnit(obj);
		}
	}
}

void Game::GrowVMons()
{
	if(!Globals->LAIR_MONSTERS_EXIST) return;

	forlist(&regions) {
		ARegion *r = (ARegion *)elem;
		forlist(&r->objects) {
			Object *obj = (Object *)elem;
			if(obj->type != O_BKEEP) continue;
			forlist(&obj->units) {
				Unit *u = (Unit *)elem;
				int men = u->GetMen(I_DRAGON);
				if(men > 0) men += 2;
				if(men > 4) men = 4;
				u->items.SetNum(I_DRAGON, men);
			}
		}
	}
}
