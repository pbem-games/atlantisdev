// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
/*
------------------------------------------------------------------------------
Standard definitions and types, Bob Jenkins
------------------------------------------------------------------------------
*/
#ifndef STANDARD
#	define STANDARD
#	ifndef STDIO
#		include <stdio.h>
#		define STDIO
#	endif
#	ifndef STDDEF
#		include <stddef.h>
#		define STDDEF
#	endif

typedef	unsigned long int	ub4;   /* unsigned 4-byte quantities */
#define	UB4MAXVAL 0xffffffff
typedef	signed long int		sb4;
#define	SB4MAXVAL 0x7fffffff
typedef	unsigned short int	ub2;
#define	UB2MAXVAL 0xffff
typedef	signed short int	sb2;
#define	SB2MAXVAL 0x7fff
typedef	unsigned char		ub1;
#define	UB1MAXVAL 0xff
typedef	signed char		sb1;   /* signed 1-byte quantities */
#define	SB1MAXVAL 0x7f
typedef	int			word;  /* fastest type available */

#define bis(target,mask)  ((target) |=  (mask))
#define bic(target,mask)  ((target) &= ~(mask))
#define bit(target,mask)  ((target) &   (mask))
#ifndef min
#	define min(a,b) (((a)<(b)) ? (a) : (b))
#endif /* min */
#ifndef max
#	define max(a,b) (((a)<(b)) ? (b) : (a))
#endif /* max */
#ifndef align
#	define align(a) (((ub4)a+(sizeof(void *)-1))&(~(sizeof(void *)-1)))
#endif /* align */
#ifndef abs
#	define abs(a)   (((a)>0) ? (a) : -(a))
#endif
#define TRUE  1
#define FALSE 0
#define SUCCESS 0  /* 1 on VAX */

#endif /* STANDARD */
