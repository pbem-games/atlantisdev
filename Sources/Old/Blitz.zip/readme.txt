Atlantis Source Code README

Copyright 1998-1999 Geoff Dunbar

This distribution of the Atlantis source code purposefully comes with
only this file as documentation. Please visit the Atlantis Project Home
Page (http://www.prankster.com/project) for full documentation.

The Atlantis source code is released under the terms of the file
LICENSE.txt, which should be in the same directory as this file. If the
license is not present, please delete the source code, and retrieve the
official release from the Atlantis Project Page.
