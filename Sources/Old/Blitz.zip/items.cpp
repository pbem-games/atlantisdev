// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#include "items.h"
#include "skills.h"
#include "rules.h"
#include "army.h"

int ParseItem(AString * token)
{
    for (int i=0; i<NITEMS; i++)
    {
        if (ItemDefs[i].type & IT_MONSTER &&
            ItemDefs[i].index == MONSTER_ILLUSION)
        { 
            if (*token == AString("i") + ItemDefs[i].name) return i;
            if (*token == AString("i") + ItemDefs[i].names) return i;
            if (*token == AString("i") + ItemDefs[i].abr) return i;
        } 
        else
        {
            if (*token == ItemDefs[i].name) return i;
            if (*token == ItemDefs[i].names) return i;
            if (*token == ItemDefs[i].abr) return i;
        }
    }
    return -1;
}

int ParseBattleItem(int item)
{
	for(int i = 0; i < NUMBATTLEITEMS; i++) {
		if(item == BattleItemDefs[i].itemNum) return i;
	}
	return -1;
}

AString ItemString(int type, int num) {
  AString temp;
  if (num == 1) {
    temp += AString(ItemDefs[type].name) + " [" + ItemDefs[type].abr + "]";
  } else {
    if (num == -1) {
      temp += AString("unlimited ") + ItemDefs[type].names + " [" +
      ItemDefs[type].abr + "]";
    } else {
      temp += AString(num) + " " + ItemDefs[type].names + " [" +
	ItemDefs[type].abr + "]";
    }
  }
  return temp;
}	

static AString ItemSpecial(int special, int level)
{
	AString temp;
	switch(special) {
		case SPECIAL_FIREBALL: temp = "Can cast fireballs"; break;
		case SPECIAL_HELLFIRE: temp = "Can blast hellfire"; break;
		case SPECIAL_CAUSEFEAR: temp = "Can strike fear"; break;
		case SPECIAL_LSTRIKE: temp = "Can summon lightning strikes"; break;
		case SPECIAL_MINDBLAST: temp = "Can a blast minds"; break;
		case SPECIAL_EARTHQUAKE: temp = "Can create earthquakes"; break;
		case SPECIAL_FORCE_SHIELD: temp = "Can cast a force shield"; break;
		case SPECIAL_ENERGY_SHIELD: temp = "Can cast an energy shield"; break;
		case SPECIAL_SPIRIT_SHIELD: temp = "Can cast a spirit shield"; break;
		case SPECIAL_DISPEL_ILLUSIONS: temp = "Can dispel illusions"; break;
		case SPECIAL_SUMMON_STORM: temp = "Can summon a storm"; break;
		case SPECIAL_TORNADO: temp = "Can summon a tornado"; break;
		case SPECIAL_CLEAR_SKIES: temp = "Can cast clear skies"; break;
		case SPECIAL_BLACK_WIND: temp = "Can summon the black wind"; break;
		case SPECIAL_BANISH_UNDEAD: temp = "Can dispel undead"; break;
		case SPECIAL_BANISH_DEMONS: temp = "Can banish demons"; break;
		case SPECIAL_FIREBREATH: temp = "Can breathe fire"; break;
		default: temp = "Has an unknown attack"; break;
	}
	temp += AString(" in battle at level ") + level + ".";
	return temp;
}

static AString MonResist(int type, int val, int full)
{
	AString temp = "This monster ";
	if(full) {
		temp += AString("has a resistance of ") + val;
	} else {
		temp += "is ";
		if(val < 1) temp += "very susceptible";
		else if(val == 1) temp += "susceptible";
		else if(val == 2) temp += "slightly resistant";
		else if(val == 3) temp += "resistant";
		else temp += "very resistant";
	}
	temp += " to ";
	switch(type) {
		case ATTACK_COMBAT: temp += "physical"; break;
		case ATTACK_ENERGY: temp += "energy"; break;
		case ATTACK_SPIRIT: temp += "spirit"; break;
		case ATTACK_WEATHER: temp += "weather"; break;
		case ATTACK_RIDING: temp += "riding"; break;
		case ATTACK_RANGED: temp += "ranged"; break;
		default: temp += "unknown";
	}
	temp += " attacks.";
    return temp;
}

static AString WeapClass(int wclass) 
{
	switch(wclass) {
		default: 
		case AT_SLASHING: return AString("slashing");
		case AT_PIERCING: return AString("piercing");
		case AT_CRUSHING: return AString("crushing");
		case AT_CLEAVING: return AString("cleaving");
		case AT_ARMORPIERCING: return AString("armor-piercing");
		case AT_ENERGY: return AString("energy");
		case AT_SPIRIT: return AString("spirit");
		case AT_WEATHER: return AString("weather");
	}
}

static AString WeapType(int flags, int wclass) 
{
	AString type;
	if (flags & WeaponType::RANGED) type = AString("ranged ");
	else if (flags & WeaponType::LONG) type = AString("long ");
	else if (flags & WeaponType::SHORT) type = AString("short ");
	type += WeapClass(wclass);
	return type;
}

static AString AttType(int atype)
{
	switch(atype) {
		case ATTACK_COMBAT: return AString("melee");
		case ATTACK_ENERGY: return AString("energy");
		case ATTACK_SPIRIT: return AString("spirit");
		case ATTACK_WEATHER: return AString("weather");
		case ATTACK_RIDING: return AString("riding");
		case ATTACK_RANGED: return AString("ranged");
		case NUM_ATTACK_TYPES: return AString("all");
		default: return AString("unknown");
	}
}

AString *ItemDescription(int item, int full)
{
	AString *temp = new AString;
	int illusion = ((ItemDefs[item].type & IT_MONSTER) &&
			(ItemDefs[item].index == MONSTER_ILLUSION));

	*temp += AString(illusion?"illusory ":"")+ ItemDefs[item].name + " [" +
		(illusion?"I":"") + ItemDefs[item].abr + "], weight " +
		ItemDefs[item].weight;

	if (ItemDefs[item].walk) {
		int cap = ItemDefs[item].walk - ItemDefs[item].weight;
		if(cap) {
			*temp += AString(", walking capacity ") + cap;
		} else {
			*temp += ", can walk";
		}
	}
	if (item == I_WAGON) {
		*temp += AString(", walking capacity ") + Globals->WAGON_CAPACITY +
			" when pulled by a " + ItemDefs[I_HORSE].name;
	}
	if (ItemDefs[item].ride) {
		int cap = ItemDefs[item].ride - ItemDefs[item].weight;
		if(cap) {
			*temp += AString(", riding capacity ") + cap;
		} else {
			*temp += ", can ride";
		}
	}
	if (ItemDefs[item].swim) {
		int cap = ItemDefs[item].swim - ItemDefs[item].weight;
		if(cap) {
			*temp += AString(", swimming capacity ") + cap;
		} else {
			*temp += ", can swim";
		}
	}
	if (ItemDefs[item].fly) {
		int cap = ItemDefs[item].fly - ItemDefs[item].weight;
		if(cap) {
			*temp += AString(", flying capacity ") + cap;
		} else {
			*temp += ", can fly";
		}
	}
	*temp += ".";

	if(ItemDefs[item].type & IT_MAN) {
		int man = ItemDefs[item].index;
		int found = 0;
		*temp += " This race may study ";
		unsigned int c;
		unsigned int len = sizeof(ManDefs[man].skills)/sizeof(int);
		for(c = 0; c < len; c++) {
			if(ManDefs[man].skills[c] != -1) {
				if(found) *temp += ", ";
				if(found && c == len - 1) *temp += "and ";
				found = 1;
				*temp += SkillStrs(ManDefs[man].skills[c]);
			}
		}
		if(found) {
			*temp += AString(" to level ") + ManDefs[man].speciallevel +
			   	" and all others to level " + ManDefs[man].defaultlevel;
		} else {
			*temp += AString("all skills to level ") +
				ManDefs[man].defaultlevel;
		}
		*temp += ".";
	}
	if(ItemDefs[item].type & IT_MONSTER) {
		*temp += " This is a monster.";
		int mon = ItemDefs[item].index;
		*temp += AString(" This monster attacks with a combat skill of ") +
			MonDefs[mon].attackLevel + ".";
		for(int c = 0; c < NUM_ATTACK_TYPES; c++) {
			*temp += AString(" ") + MonResist(c,MonDefs[mon].defense[c], full);
		}
		if(MonDefs[mon].special && MonDefs[mon].special != -1) {
			*temp += AString(" ") +
				ItemSpecial(MonDefs[mon].special, MonDefs[mon].specialLevel);
		}
		if(full) {
			int hits = MonDefs[mon].hits;
			int atts = MonDefs[mon].numAttacks;
			int regen = MonDefs[mon].regen;
			if(hits < 1) hits = 1;
			if(!atts) atts = 1;
			*temp += AString(" This monster has ") + atts + " " +
				((atts == 1)?"attack":"attacks") + " per round and takes " +
				hits + " " + ((hits > 1)?"hits":"hit") + " to kill.";
			if (regen > 0) *temp += AString(" This monster has regenerates ") + regen + " hits per round.";
			*temp += AString(" This monster has a tactics score of ") +
				MonDefs[mon].tactics + ", a stealth score of " +
				MonDefs[mon].stealth + ", and an observation score of " +
				MonDefs[mon].obs + ".";
		}
		*temp += " This monster has ";
		if(MonDefs[mon].spoiltype != -1) {
			if(MonDefs[mon].spoiltype & IT_MAGIC) {
				*temp += "magic items and ";
			} else if(MonDefs[mon].spoiltype & IT_ADVANCED) {
				*temp += "advanced items and ";
			} else if(MonDefs[mon].spoiltype & IT_NORMAL) {
				*temp += "normal or trade items and ";
			}
		}
		*temp += "silver as treasure.";
	}
	if(ItemDefs[item].type & IT_WEAPON) {
		int wep = ItemDefs[item].index;
		WeaponType *pW = &WeaponDefs[wep];
		if (pW) {
			*temp += AString(" This is a ");
			*temp += WeapType(pW->flags, pW->weapClass) + " weapon.";
			if(pW->flags & WeaponType::NEEDSKILL) {
				*temp += AString(" Knowledge of ") + SkillStrs(pW->baseSkill);
				if(pW->orSkill != -1) {
					*temp += AString(" or ") + SkillStrs(pW->orSkill);
				}
				*temp += " is needed to wield this weapon.";
			} else {
				if(pW->baseSkill == -1 && pW->orSkill == -1) {
					*temp += " No skill is needed to wield this weapon.";
				}
			}
			int flag = 0;
			if (pW->attackBonus != 0) {	
				*temp += AString(" This weapon grants a ");
				if (pW->attackBonus > 0) {
					*temp += AString("bonus of ") + pW->attackBonus;
				} else {
					*temp += AString("penalty of ") + (-pW->attackBonus);
				}
				*temp += AString(" on attack");
				flag = 1;
			}
			if (pW->defenseBonus != 0) {
				if (flag) {
					if (pW->attackBonus == pW->defenseBonus) {
						*temp += AString(" and defense.");
						flag = 0;
					} else {
						*temp += AString(" and a ");
						flag = 1;
					}
				} else {
					*temp += AString(" This weapon grants a ");
					flag = 1;
				}
				if (flag) {
					if (pW->defenseBonus > 0) {
						*temp += AString("bonus of ") + pW->defenseBonus;
					} else {
						*temp += AString("penalty of ") + (-pW->defenseBonus);
					}
					*temp += AString(" on defense.");
					flag = 0;
				}
			}
			if (flag) *temp += AString(".");
			if (pW->mountBonus) {
				*temp += AString(" This weapon ");
				if ((pW->attackBonus != 0) || (pW->defenseBonus != 0))
					*temp += AString("also ");
				*temp += AString("grants a ");
				if (pW->mountBonus > 0) *temp += AString("bonus of ") + pW->mountBonus;
				else  *temp += AString("penalty of ") + (-pW->mountBonus);
				*temp += " against mounted opponents.";
			}
			if(pW->flags & WeaponType::NOFOOT) {
				*temp += " Only mounted troops may use this weapon.";
			} else if(pW->flags & WeaponType::NOMOUNT) {
				*temp += " Only foot soldiers may use this weapon.";
			}
			if(pW->flags & WeaponType::RIDINGBONUS) {
				*temp += " Wielders of this weapon, if mounted, get their riding skill bonus "
					"on combat attack and defense.";
			} else if(pW->flags & WeaponType::RIDINGBONUSDEFENSE) {
				*temp += " Wielders of this weapon, if mounted, get their riding skill bonus "
					"on combat defense.";
			}
			if(pW->flags & WeaponType::NODEFENSE) {
				*temp += " Defenders are treated as if they have an no combat skill.";
			}
			if(pW->flags & WeaponType::NOATTACKERDEFENSE) {
				*temp += " Wielders of this weapon cannot use their combat skill on defense.";
			}
			if(pW->flags & WeaponType::USEINASSASSINATE) {
				*temp += " This weapon may be used in assassination attempts.";
			}
			if(pW->flags & WeaponType::NEVERMISS) {
				*temp += " Wielders of this weapon always get a chance to hit.";
			}
			else {
				*temp += " There is a 50% chance that wielder of this weapon gets a chance to hit.";
			}
		
			int atts = pW->numAttacks;
			*temp += AString(" This weapon attacks versus the target's ") +
				"defense against " + AttType(pW->attackType) + " attacks.";
			*temp += AString(" This weapon allows ");
			if(atts > 0) {
				// Note: ASSERT(WeaponType::NUM_ATTACKS_HALF_SKILL < WeaponType::NUM_ATTACKS_SKILL);
				if (atts >= WeaponType::NUM_ATTACKS_HALF_SKILL) {
					int val = 0;
					if (atts >= WeaponType::NUM_ATTACKS_SKILL) {
						*temp += " a number of attacks equal to skill level";
						if (atts > WeaponType::NUM_ATTACKS_SKILL) {
							val = atts - WeaponType::NUM_ATTACKS_SKILL;
						} else {
							*temp += " a number of attacks equal to half the skill level (rounded up)";
							if (atts > WeaponType::NUM_ATTACKS_HALF_SKILL) {
								val = atts - WeaponType::NUM_ATTACKS_HALF_SKILL;
							}
						}
					}
					if (val > 0) *temp += AString(" plus ") + val;

				} else {
					*temp += AString(atts) + ((atts == 1)?" attack":" attacks");
				}
				*temp += " per round.";
			} else {
				atts =- atts;
				*temp += AString("1 attack every ");
				if (atts == 1) *temp += "round.";
				else *temp += atts + " rounds.";
			}

		} else {
			*temp += " This is a weapon.";
		}
	}
	if(ItemDefs[item].type & IT_ARMOR) {
		*temp += " This is a type of armor.";
		int arm = ItemDefs[item].index;
		ArmorType *pA = &ArmorDefs[arm];
		*temp += " This armor will protect its wearer ";
		for(int i = 0; i < NUM_WEAPON_CLASSES; i++) {
			if(i == NUM_WEAPON_CLASSES - 1) {
				*temp += ", and ";
			} else if(i > 0) {
				*temp += ", ";
			}
			int percent = (int)(((float)pA->saves[i] * 100.0)/(float)pA->from + 0.5);
			*temp += AString(percent) + "% of the time versus " + WeapClass(i) + " attacks";
		}
		*temp += ".";
		if(pA->flags & ArmorType::USEINASSASSINATE) {
			*temp += " This armor may be worn during assassination attempts.";
		}
	}

	if(ItemDefs[item].type & IT_TRADE) {
		*temp += " This is a trade good.";
		if(full) {
			if(Globals->RANDOM_ECONOMY) {
				int maxbuy, minbuy, maxsell, minsell;
				minsell = (ItemDefs[item].baseprice*150)/100;
				maxsell = (ItemDefs[item].baseprice*200)/100;
				minbuy = (ItemDefs[item].baseprice*100)/100;
				maxbuy = (ItemDefs[item].baseprice*150)/100;
				*temp += AString(" This item can be bought for between ") +
					minbuy + " and " + maxbuy + " silver.";
				*temp += AString(" This item can be sold for between ") +
					minsell+ " and " + maxsell+ " silver.";
			} else {
				*temp += AString(" This item can be bought and sold for ") +
					ItemDefs[item].baseprice + " silver.";
			}
		}
	}

	if(ItemDefs[item].type & IT_MOUNT) {
		*temp += " This is a mount.";
		int mnt = ItemDefs[item].index;
		MountType *pM = &MountDefs[mnt];
		if(pM->skill == -1) {
			*temp += " No skill is required to use this mount.";
		} else {
			*temp += AString(" This mount requires ") + SkillStrs(pM->skill) +
				" of at least level " + pM->minBonus + " to ride in combat.";
		}
		*temp += AString(" This mount gives a minimum bonus of +") +
			pM->minBonus + " when ridden into combat.";
		*temp += AString(" This mount gives a maximum bonus of +") +
			pM->maxBonus + " when ridden into combat.";
		if(full) {
			if(ItemDefs[item].fly) {
				*temp += AString(" This mount gives a maximum bonus of +") +
					pM->maxHamperedBonus + " when ridden into combat in " +
					"terrain which allows ridden mounts but not flying "+
					"mounts.";
			}
		}
	}

	if(ItemDefs[item].skill != -1) {
		*temp += AString(" Units with ") + SkillStrs(ItemDefs[item].skill) +
			" " + ItemDefs[item].level + " may PRODUCE this item";
		if (ItemDefs[item].input != -1) {
			*temp += AString(" from ") + AString(ItemDefs[item].number) + " ";
			if (ItemDefs[item].input == I_WOOD_OR_STONE) *temp += "wood or stone";
			else {
				if (ItemDefs[item].number == 1) *temp += ItemDefs[ItemDefs[item].input].name;
				else *temp += ItemDefs[item].names;
			}
		}
		*temp += ".";
	}
	if((ItemDefs[item].type & IT_MAGIC) && full) {
		*temp += " This is a magic item.";
	}
	if((ItemDefs[item].type & IT_ADVANCED) && full) {
		*temp += " This is an advanced item.";
	}
	if((ItemDefs[item].type & IT_BATTLE) && full) {
		*temp += " This is a miscellaneous combat item.";
		for(int i = 0; i < NUMBATTLEITEMS; i++) {
			if(BattleItemDefs[i].itemNum == item) {
				if(BattleItemDefs[i].flags & BattleItemType::MAGEONLY) {
					*temp += " This item may only be used by a mage.";
				}
				if(BattleItemDefs[i].flags & BattleItemType::SPECIAL) {
					*temp += AString(" ") +
						ItemSpecial(BattleItemDefs[i].index,
								BattleItemDefs[i].skillLevel);
				} else if(BattleItemDefs[i].flags & BattleItemType::SHIELD) {
					*temp += AString("Can cast a shield against ") +
						AttType(BattleItemDefs[i].index) +
						" attacks at level " + BattleItemDefs[i].skillLevel +
						".";
				}
			}
		}
	}
	if((ItemDefs[item].flags & ItemType::CANTGIVE) && full) {
		*temp += " This item cannot be given to other units.";
	}

	return temp;
}

int IsSoldier(int item)
{
	if (ItemDefs[item].type & IT_MAN || ItemDefs[item].type & IT_MONSTER)
		return 1;
	return 0;
}


Item::Item() {
}

Item::~Item() {
}

AString Item::Report(int seeillusions)
{
    AString ret = ItemString(type,num);
    if (seeillusions && ItemDefs[type].type & IT_MONSTER &&
        ItemDefs[type].index == MONSTER_ILLUSION)
    {
        ret = ret + " (illusion)";
    }
    return ret;
}

void Item::Writeout(Aoutfile * f) {
#ifdef DEBUG_GAME
  f->PutStr("Item");
#endif
  f->PutInt(type);
  f->PutInt(num);
}

void Item::Readin(Ainfile * f) {
#ifdef DEBUG_GAME
  delete f->GetStr();
#endif
  type = f->GetInt();
  num = f->GetInt();
}

void ItemList::Writeout(Aoutfile * f) {
#ifdef DEBUG_GAME
  f->PutStr("Number of Items");
#endif
  f->PutInt(Num());
  forlist (this)
    ((Item *) elem)->Writeout(f);
}

void ItemList::Readin(Ainfile * f) {
#ifdef DEBUG_GAME
  delete f->GetStr();
#endif
  int i = f->GetInt();
  for (int j=0; j<i; j++) {
    Item * temp = new Item;
    temp->Readin(f);
    if (temp->num < 1) {
      delete temp;
    } else {
      Add(temp);
    }
  }
}

int ItemList::GetNum(int t) {
  forlist(this) {
    Item * i = (Item *) elem;
    if (i->type == t) return i->num;
  }
  return 0;
}

int ItemList::Weight() {
  int wt = 0;
  forlist(this) {
    Item * i = (Item *) elem;
    wt += ItemDefs[i->type].weight * i->num;
  }
  return wt;
}

AString ItemList::Report(int obs,int seeillusions,int nofirstcomma)
{
    AString temp;
    forlist(this) {
        Item * i = (Item *) elem;
        if (obs == 2)
        {
            if (nofirstcomma)
            {
                nofirstcomma = 0;
            } 
            else
            {
                temp += ", ";
            }
            temp += i->Report(seeillusions);
        } 
        else 
        {
            if (ItemDefs[i->type].weight)
            {
                if (nofirstcomma) 
                {
                    nofirstcomma = 0;
                } 
                else
                {
                    temp += ", ";
                }
                temp += i->Report(seeillusions);
            }
        }
    }
    return temp;
}

AString ItemList::BattleReport()
{
    AString temp;
    forlist(this) {
        Item * i = (Item *) elem;
        if (ItemDefs[i->type].combat)
        {
            temp += ", ";
            temp += i->Report(0);
            if (ItemDefs[i->type].type & IT_MONSTER)
            {
                MonType & mondef = MonDefs[ItemDefs[i->type].index];
                temp += AString(" (Combat ") + mondef.attackLevel + "," + mondef.defense[ATTACK_COMBAT] + 
					", Attacks " + mondef.numAttacks + ", Hits " + mondef.hits +
					", Tactics " + mondef.tactics + ")";
            }
        }
    }
    return temp;
}


void ItemList::SetNum(int t,int n)
{
    if (n)
    {
        forlist(this) {
            Item * i = (Item *) elem;
            if (i->type == t)
            {
                i->num = n;
                return;
            }
        }
        Item * i = new Item;
        i->type = t;
        i->num = n;
        Add(i);
    } 
    else
    {
        forlist(this) {
            Item * i = (Item *) elem;
            if (i->type == t)
            {
                Remove(i);
                delete i;
                return;
            }
        }
    }
}
