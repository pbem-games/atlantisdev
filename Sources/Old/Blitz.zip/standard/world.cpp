// START A3HEADER
//
// This source file is part of the Atlantis PBM game program.
// Copyright (C) 1995-1999 Geoff Dunbar
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program, in the file license.txt. If not, write
// to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
// Boston, MA 02111-1307, USA.
//
// See the Atlantis Project web page for details:
// http://www.prankster.com/project
//
// END A3HEADER
#include "game.h"
#include "rules.h"

static char *regionnames[] =
{	// Town names (450)
	"Aathon",
	"Aberaeron",
	"Aberdaron",
	"Abernecht",
	"Abersoch",
	"Abrantes",
	"Abrenton",
	"Adigia",
	"Aisfor",
	"Akbou",
	"Alabrin-a-dum",
	"Alabrin-ungol",
	"Aldan",
	"Almerkun",
	"Altenten",
	"Aman-a-for",
	"Aman-a-karak",
	"Ambleston",
	"Ancroft",
	"Anshun",
	"Anstruther",
	"Antor",
	"Arbroath",
	"Arlon",
	"Ashgoth",
	"Askul-a-for",
	"Askul-a-luk",
	"Athinost",
	"Athrolost",
	"Avanos",
	"Badalona",
	"Baechahoela",
	"Baku",
	"Bal-dum",
	"Bal-tor",
	"Ballindine",
	"Balta",
	"Banlar",
	"Bastak",
	"Beigen",
	"Belgrad",
	"Belten",
	"Bemedjaba",
	"Benlech",
	"Beragh",
	"Berjus",
	"Betize",
	"Binhai",
	"Bjornholm",
	"Blackstone",
	"Bocholt",
	"Bogburg",
	"Bogshakoth",
	"Bogthangar",
	"Brechlin",
	"Brimforost",
	"Brimrolost",
	"Brok-a-grim",
	"Brok-a-thol",
	"Brok-dum",
	"Brok-ungol",
	"Buggothoth",
	"Bugungol",
	"Bugwazar",
	"Buk-a-grim",
	"Burholm",
	"Burmund",
	"Burstad",
	"Carbost",
	"Carnforth",
	"Carrigaline",
	"Catrianchi",
	"Cheboks",
	"Chrag",
	"Cirthanoth",
	"Coilaco",
	"Congolath",
	"Coninath",
	"Conrolnost",
	"Coraisle",
	"Cordorf",
	"Corinth",
	"Cornon",
	"Corofin",
	"Corvoltan",
	"Crucible",
	"Cumbraes",
	"Darburg",
	"Dargrad",
	"Darm",
	"Darshai",
	"Darvoltan",
	"Decca",
	"Deuois",
	"Deveron",
	"Dezhou",
	"Dhakbadnost",
	"Donnois",
	"Dorin",
	"Dormardon",
	"Dornoch",
	"Downwind",
	"Drimnin",
	"Drumcollogher",
	"Drummore",
	"Dryck",
	"Dun-a-luk",
	"Dun-krag",
	"Dunburg",
	"Dunburgten",
	"Duncansby",
	"Dunfanaghy",
	"Dunmanus",
	"Dur-a-dum",
	"Dur-tor",
	"Durnest",
	"Durthgothtor",
	"Dwor-killuk",
	"Eindotn",
	"Einhowe",
	"Einmund",
	"Einvoltan",
	"Elathnost",
	"Elbroddon",
	"Eldiauen",
	"Elengost",
	"Elkhatib",
	"Ellon",
	"Elofordon",
	"Elomarton",
	"Elothanuen",
	"Enddorath",
	"Endenost",
	"Endmaroth",
	"Enfar",
	"Eresham",
	"Esgaroth",
	"Eskerfan",
	"Ethilagost",
	"Ethilannost",
	"Ethilator",
	"Ethilforin",
	"Ethilthannost",
	"Ethilthielost",
	"Ettrick",
	"Etzelbrucke",
	"Faringstoke",
	"Ferbane",
	"Fetlar",
	"Flogmuck",
	"Forbrin-a-dol",
	"Forbrin-a-luk",
	"Forbrin-killuk",
	"Forbrin-tor",
	"Formby",
	"Fort Battle",
	"Fort Ger",
	"Fort Ska",
	"Fort Southway",
	"Forthielnost",
	"Frainberg",
	"Freinten",
	"Gaald Marches",
	"Gallow's Hill",
	"Gifford",
	"Githanost",
	"Githatgost",
	"Githdorar",
	"Githfinund",
	"Githlornost",
	"Githost",
	"Githroldon",
	"Glenagallagh",
	"Glenanane",
	"Glordorost",
	"Gluggby",
	"Glumbu",
	"Gon-a-luk",
	"Gon-a-thol",
	"Gorbadin",
	"Gorbul",
	"Gorthang",
	"Gourock",
	"Graevbygd",
	"Granfor",
	"Grangrad",
	"Granhowe",
	"Granstad",
	"Granvoltan",
	"Grenquel",
	"Gresberg",
	"Greverre",
	"Grimswill",
	"Grisbygd",
	"Grokstein",
	"Grueskinsk",
	"Haiu Menshir",
	"Halkirk",
	"Handan",
	"Helbruk",
	"Helburg",
	"Heldotn",
	"Helmsley",
	"Helsicke",
	"Hirfinnost",
	"Hirgoltor",
	"Hirthielath",
	"Hoisfor",
	"Hoisquel",
	"Icklestone Keep",
	"Illbury",
	"Illizbuah",
	"Inan",
	"Inanost",
	"Inber",
	"Ingoldon",
	"Inverie",
	"Ithrag-dum",
	"Jaca",
	"Jahrom",
	"Jeormel",
	"Jervbygd",
	"Jining",
	"Jotel",
	"Kaddervar",
	"Kalaap",
	"Kalogria",
	"Kar-a-thol",
	"Karaz-killuk",
	"Kargshakin",
	"Kazodburgost",
	"Keswick",
	"Kielder",
	"Killorglin",
	"Kinblatte",
	"Kirriemuir",
	"Knesekt",
	"Kobbe",
	"Kovel",
	"Kresh",
	"Krminsk",
	"Krod",
	"Kruymen",
	"Kul-a-for",
	"Kursk",
	"Lambertstoke",
	"Langholm",
	"Larache",
	"Larkanth",
	"Leighlin",
	"Lervir",
	"Leven",
	"Licata",
	"Lilbur",
	"Lindorf",
	"Linmund",
	"Lintan",
	"Linten",
	"Lochalsh",
	"Lochcarron",
	"Lochinver",
	"Lochmaben",
	"Loragost",
	"Lorenoth",
	"Lorsornost",
	"Lorthalm",
	"Lothdorgost",
	"Lothsornost",
	"Loththandon",
	"Lybster",
	"Lynton",
	"Macaskill",
	"Magdenbruk",
	"Magdengrad",
	"Magdenheim",
	"Magdenmund",
	"Magdenport",
	"Mallaig",
	"Manoon",
	"Marbruk",
	"Mardotn",
	"Marhowe",
	"Marport",
	"Mataro",
	"Melfi",
	"Melvaig",
	"Menter",
	"Midori",
	"Minas Azrash",
	"Minas Dorgul",
	"Minas Emyn",
	"Minas Fangol",
	"Minas Gimnazg",
	"Minas Rathlin",
	"Minas Zodforthud",
	"Moffat",
	"Monamolin",
	"Morella",
	"Morgel",
	"Morghul",
	"Morrotost",
	"Mortenford",
	"Morthang",
	"Morthangor",
	"Morwazdon",
	"Mugbottom",
	"Mullaghcarn",
	"Mun-a-grim",
	"Mun-a-karak",
	"Mundbruk",
	"Mundburg",
	"Mundgrad",
	"Nai Pert",
	"Namcush",
	"Narga-a-dol",
	"Nargabab",
	"Nargghuloth",
	"Narslagor",
	"Naryshkiv",
	"Navenby",
	"Nazbadar",
	"Nazslagtor",
	"Nebelstein",
	"Nellas",
	"Nephin Beg",
	"Nestrigrad",
	"Neudotn",
	"Neustadt",
	"Nimandon",
	"Nimatost",
	"Nimfinoth",
	"Nimfintor",
	"Nimmarund",
	"Nimthandon",
	"Niskby",
	"Norbruk",
	"Nork",
	"Normund",
	"Norvoltan",
	"Olenek",
	"Ollo-a-for",
	"Ollo-ungol",
	"Orrebygd",
	"Palmora",
	"Pargris",
	"Parsinspike",
	"Pauvestry",
	"Penz",
	"Perski",
	"Plainston",
	"Planken",
	"Pogelveir",
	"Porthcawl",
	"Portimao",
	"Potenza",
	"Pottersham",
	"Praestbygd",
	"Prattstone",
	"Presu",
	"Quantor",
	"Raathtor",
	"Raeschku",
	"Rappbygd",
	"Rarolgost",
	"Rasornost",
	"Rath Luire",
	"Rathiel",
	"Rator",
	"Regensburg",
	"Retchmaw",
	"Reve",
	"Riechowe",
	"Riggenthorpe",
	"Roin",
	"Roptille",
	"Roskat",
	"Rotscum",
	"Rueve",
	"Salen",
	"Sarab",
	"Sarkanvale",
	"Scarinish",
	"Selov",
	"Senlaw",
	"Serov",
	"Shanyin",
	"Siegen",
	"Siengris",
	"Sinestra",
	"Skottskog",
	"Skretch",
	"Sorbrodnost",
	"Sordorost",
	"Sorisdale",
	"Spaw",
	"Stackforth",
	"Staklesse",
	"Stinchar",
	"Stoerski",
	"Stonefort Keep",
	"Stoneham",
	"Stugslett",
	"Sur la plage",
	"Surgrois",
	"Surmais",
	"Tabuk",
	"Talitsa",
	"Tarraspan",
	"Tatterfield",
	"Tebrias",
	"Thanlortor",
	"Thor-a-grim",
	"Thor-killuk",
	"Thorbad",
	"Thorgognost",
	"Tiemcen",
	"Tiksi",
	"Tolsta",
	"Tor Ench",
	"Torridon",
	"Trapani",
	"Tromeforth",
	"Tuzgolu",
	"Uxelberg",
	"Uzbad",
	"Uzshakund",
	"Uzshakund",
	"Uzslag",
	"Valga",
	"Verdotn",
	"Verguin",
	"Vernlund",
	"Volbruk",
	"Volgrad",
	"Waidmeir",
	"Waidten",
	"Waimer",
	"Wastenholm",
	"Whai",
	"Withrington",
	"Worsingstoke",
	"Yakleks",
	"Yelvington",
	"Yuci",
	"Zaalsehuur",
	"Zapulla",
	"Zodbad",
	"Zoddhak",
	"Zoddornost",
	"Zogrotost",
	// More Towns (150)
	"Achech",
	"Achuntes",
	"Agekler",
	"Ale'kime",
	"Aletoryer",
	"Ardcerqueingurn",
	"Arperach",
	"Arrothusk",
	"Arskeltiatortur",
	"Aselm",
	"Ashsay",
	"Ashuk",
	"Ataugh",
	"Atlye",
	"Aughange",
	"Awengtantoran",
	"Betanest",
	"Beunt",
	"Bleuss",
	"Blodban",
	"Buril",
	"Cerdraight",
	"Chaite",
	"Chedel",
	"Cheildroth",
	"Coyan",
	"Crealtton",
	"Danchaornykim",
	"Dantanend",
	"Darcertur",
	"Daringtontanis",
	"Del'an",
	"Delm",
	"Denroth",
	"Drakelum",
	"Echathroth",
	"Eldoldkal",
	"Em'ari",
	"Enthast-wor",
	"Enthrodatril",
	"Enthtai",
	"Enthustlerrad",
	"Essorm",
	"Et'ighte",
	"Fivor",
	"Gaultale",
	"Godusk",
	"Hatril",
	"Hineld",
	"Honraye",
	"Iaengtin",
	"Ightemwargaru",
	"Ightoen",
	"Imdanradess",
	"Inaiess",
	"Ingrothhatvera",
	"Irb",
	"Isswarom",
	"Isylt",
	"Jaightald",
	"Kalachshyackton",
	"Kalkimormghao",
	"Kelbald",
	"Keliq",
	"Keltinchauskban",
	"Kodan",
	"Lasryn",
	"Lerhdar",
	"Lor'shy",
	"Lotor",
	"Lyeashskeloughorm",
	"Maundlye",
	"Meur",
	"Morwar",
	"Mosrilo",
	"Nacop",
	"Nahiy",
	"Neid",
	"Nuor",
	"Nuxyt",
	"Nyas",
	"Nyhuti",
	"Nys'nya",
	"Om'agey",
	"Onementhskeli",
	"Oragh",
	"Orashu",
	"Ormitan",
	"Orrvor",
	"Osage",
	"Osov",
	"Oughechon",
	"Perick",
	"Polkinurn",
	"Que'lor",
	"Radum",
	"Radunti",
	"Rak'qua",
	"Rayit",
	"Rayquaechisvor",
	"Rheinage",
	"Rilauc'i",
	"Rodsulitashon",
	"Rothkel",
	"Ruwige",
	"Rynnyswarerad",
	"Samack",
	"Samquegaromash",
	"Sayon",
	"Sedej",
	"Serim",
	"Sewic",
	"Shyec",
	"Shyesstin",
	"Skel-ach",
	"Slitan",
	"Stroormtas",
	"Stuadack",
	"Suvig",
	"Swasaytan",
	"Sytherem",
	"Taesath",
	"Taien",
	"Taisam",
	"Tan'tina",
	"Tannmor",
	"Tav",
	"Ther'kin",
	"Theris",
	"Thrieck",
	"Throibves",
	"Thrydum",
	"Tia'nysi",
	"Tryough",
	"Tursh",
	"Umhonomoldight",
	"Umper",
	"Undemves",
	"Unduntuskadang",
	"Ustisray",
	"Veryst",
	"Wapolnys",
	"Warurncheentha",
	"Weynnund",
	"Wordmos",
	"Yaoldit",
	"Yerend",
	"Ytiai",
	"Zhotas",
	"Zuenth",
	// Total Towns : 600
	
	// Region Names (400)
	"Aberdovey",
	"Abernethy",
	"Adrano",
	"Aenir",
	"Aghleam",
	"Aisdel",
	"Aisgris",
	"Alabrin-a-lin",
	"Alfaro",
	"Alghero",
	"Almeria",
	"Altenfeld",
	"Altenmar",
	"Altnaharra",
	"Altskaenmeir",
	"Aman-mun",
	"Amberiand",
	"Arcila",
	"Ardfert",
	"Ardvale",
	"Arezzo",
	"Ariano",
	"Arko",
	"Arnor",
	"Ashdor",
	"Askarwaith",
	"Askul-a-grim",
	"Askul-dor",
	"Athatdon",
	"Athfinanfel",
	"Atholund",
	"Athorien",
	"Athrolanwe",
	"Athroldor",
	"Aththandel",
	"Aveiro",
	"Baiaisle",
	"Baihma",
	"Baiois",
	"Bal-a-menak",
	"Bal-krag",
	"Barika",
	"Belerien",
	"Beleror",
	"Belestonia",
	"Bergland",
	"Berneray",
	"Berriedale",
	"Bogdor",
	"Bograntia",
	"Bogwazia",
	"Bragaria",
	"Brandor",
	"Brimbroduen",
	"Brimdiaath",
	"Brimlorrond",
	"Brimmardel",
	"Brimrolor",
	"Brok-dor",
	"Brok-killuk",
	"Bugblod",
	"Buggababdor",
	"Buk-a-lin",
	"Buk-a-menak",
	"Buk-kai",
	"Burburgfelt",
	"Burmark",
	"Burveld",
	"Calpio",
	"Canna",
	"Capodocia",
	"Capperwaith",
	"Capreria",
	"Caserta",
	"Chespek",
	"Cimbricus",
	"Cipru",
	"Ciraath",
	"Ciranrond",
	"Cirathdor",
	"Cirdel",
	"Cirroldon",
	"Cirthanund",
	"Cirthiel",
	"Cirthielor",
	"Clatstonia",
	"Clenaghan",
	"Conanwe",
	"Condiador",
	"Conforor",
	"Congoldel",
	"Conmarlun",
	"Conmarrond",
	"Conthielanwe",
	"Corfeld",
	"Corrantia",
	"Corwaithe",
	"Cralador",
	"Daingea",
	"Dalwah",
	"Damscauer",
	"Derronia",
	"Derwaithe",
	"Devereaux",
	"Dhakblodlun",
	"Dhakburgia",
	"Dhakgababdel",
	"Dhakungolia",
	"Dorolrond",
	"Drammestein",
	"Drensa",
	"Drogthangia",
	"Dryforth",
	"Drymenwaith",
	"Dun-a-gun",
	"Dun-a-menak",
	"Dun-killuk",
	"Dunbeath",
	"Dunkeld",
	"Dunstonia",
	"Dur-a-grim",
	"Dur-a-lin",
	"Durthghulia",
	"Dwarshire",
	"Dwor-dor",
	"Dwor-mun",
	"Elanlun",
	"Elathund",
	"Elatin",
	"Elfinar",
	"Elgomaar",
	"Ellesmere",
	"Elmaranfel",
	"Eloanath",
	"Elodiaar",
	"Eloenath",
	"Elofinanwe",
	"Elofinrond",
	"Elomardor",
	"Elosorrond",
	"Emynwraith",
	"Endaund",
	"Endenanfel",
	"Endendor",
	"Endforund",
	"Endroldor",
	"Endthieluen",
	"Eredwaith",
	"Eriador",
	"Erstedor",
	"Esaria",
	"Fanders",
	"Farstanbra",
	"Fehinna",
	"Florina",
	"Forananfel",
	"Foratanwe",
	"Forbrin-a-grim",
	"Forbrin-a-karak",
	"Forenath",
	"Forendor",
	"Forfinor",
	"Forlaria",
	"Forodwaith",
	"Foroluen",
	"Freiand",
	"Frogmorshire",
	"Gaelund",
	"Ganzhou",
	"Geronras",
	"Girvanen",
	"Githfinanwe",
	"Githfinuen",
	"Githmardor",
	"Glomera",
	"Gloramar",
	"Glorananwe",
	"Glordia",
	"Glorenund",
	"Glorfinanfel",
	"Glorgoldon",
	"Glormandia",
	"Golsenda",
	"Gon-a-lin",
	"Gondaur",
	"Gontharien",
	"Gormonwaith",
	"Gorslagia",
	"Gorwazia",
	"Gragblod",
	"Gragghulia",
	"Graggogrond",
	"Gragthangia",
	"Granarchen",
	"Grennuon",
	"Grimdor",
	"Grimgrodia",
	"Groddland",
	"Guldor",
	"Gurkacre",
	"Haikou",
	"Haradaur",
	"Hasmerr",
	"Helmsdale",
	"Helvetia",
	"Hirandel",
	"Hirinrond",
	"Hiroldor",
	"Hirop",
	"Hirrolar",
	"Hullevalaia",
	"Hyerne",
	"Idrees",
	"Ilanwaithe",
	"Inmarrond",
	"Inolar",
	"Inthananfel",
	"Inthielor",
	"Irsa Marches",
	"Ithrag-a-menak",
	"Ithrag-ban",
	"Kaailun",
	"Kaina",
	"Kalina",
	"Kar-a-gun",
	"Kar-a-menak",
	"Karand",
	"Karaz-a-lin",
	"Karaz-a-menak",
	"Kargrunor",
	"Kargthanganfel",
	"Kargwaz",
	"Karothea",
	"Kashmar",
	"Kinshore",
	"Klenreddoria",
	"Komarken",
	"Kreyen",
	"Krim",
	"Kul-a-grim",
	"Kul-lum",
	"Kulmatycki",
	"Kurkania",
	"Kyuba",
	"Lagos",
	"Lakaz",
	"Lamlash",
	"Larmet",
	"Lautaro",
	"Limavady",
	"Linuvien",
	"Liscannor",
	"Lithuien",
	"Locarno",
	"Lom",
	"Lorbrodanwe",
	"Lordialun",
	"Lorlordel",
	"Lothenor",
	"Lothfindon",
	"Lothfinmar",
	"Lothgimiel",
	"Lotholund",
	"Louer",
	"Lurkobia",
	"Luthiir",
	"Maailun",
	"Magdenvelt",
	"Mahachkala",
	"Malungu",
	"Marmark",
	"Marsennor",
	"Marsnuon",
	"Menefee",
	"Methven",
	"Midretshire",
	"Minhiaur",
	"Mobayen",
	"Moghiur",
	"Monzon",
	"Mordorrond",
	"Morthangia",
	"Mrinah",
	"Muckshire",
	"Mukhapadhyay",
	"Mulle",
	"Mun-a-menak",
	"Mun-ungol",
	"Mundicia",
	"Murom",
	"Naiglun",
	"Nairn",
	"Nargaforskraw",
	"Nazgothia",
	"Nazshakanfel",
	"Nazwaz",
	"Nekrasovskaia",
	"Newfai",
	"Nimaar",
	"Nimdordel",
	"Nimsoranwe",
	"Nimsordor",
	"Nimthananfel",
	"Nolle",
	"Norarchen",
	"Norheim",
	"Norsendaur",
	"Oksana",
	"Oloron",
	"Oranmore",
	"Ormgryte",
	"Ostbognor",
	"Palarch",
	"Panyu",
	"Perskelia",
	"Plattland",
	"Pleagne",
	"Pretsomia",
	"Quinones",
	"Radiador",
	"Radonstan",
	"Rafinmar",
	"Ramaror",
	"Rathanor",
	"Rathfindien",
	"Rathielor",
	"Rethel",
	"Rhudaur",
	"Rochfort",
	"Roddendor",
	"Sagunto",
	"Sainclem",
	"Saklebille",
	"Sanfrick",
	"Scandamia",
	"Scouria",
	"Serckland",
	"Sinantai",
	"Sinapland",
	"Skokveld",
	"Skomer",
	"Sledmere",
	"Sorbrod",
	"Sorindon",
	"Sormarch",
	"Spakker",
	"Sria",
	"Strichen",
	"Stroma",
	"Suide",
	"Tetuan",
	"Thana",
	"Thanananwe",
	"Thanatmar",
	"Thandoror",
	"Thanforlun",
	"Thanrollun",
	"Thanthanmar",
	"Thanthielund",
	"Thor-a-karak",
	"Thorblodanfel",
	"Thorgothanwe",
	"Thorgrod",
	"Thurso",
	"Toppola",
	"Toriand",
	"Trottershire",
	"Tudela",
	"Tukan",
	"Turia",
	"Uthgothmar",
	"Uthslagia",
	"Uzgogia",
	"Uzslagia",
	"Uzslagia",
	"Uzwazia",
	"Vaila",
	"Vandenborre",
	"Vardi",
	"Verfelt",
	"Versnuon",
	"Vestenaur",
	"Victoria",
	"Vyksa",
	"Waidmark",
	"Wastenarchen",
	"Wastenfeld",
	"Wastenmar",
	"Wesmarch",
	"Xontormia",
	"Yawac",
	"Yeola-e",
	"Yiantelis",
	"Yudhvir",
	"Zamora",
	"Zientko",
	"Zodungolia",
	"Zogthangia",
	"Zumwalt",
	"Zweischlokkaur",
	// More Regions (140)
	"Acheri",
	"Ackakel",
	"Ackormmosighti",
	"Ageingtor",
	"Aldys",
	"Anadisackia",
	"Anden",
	"Ardenth",
	"Ardmlor",
	"Aryno",
	"Asrhon",
	"Awormuskis",
	"Belesskel",
	"Blaaring",
	"Blihina",
	"Breen",
	"Burhatdaneny",
	"Burildissny",
	"Cereldonia",
	"Cerrody",
	"Cheeld",
	"Chekimald",
	"Cidar",
	"Cluroden",
	"Dangha",
	"Delann",
	"Delquaem",
	"Deptia",
	"Doath",
	"Drirayny",
	"Dyntia",
	"Echingonquai",
	"Echquaomenia",
	"Engkalaur",
	"Enin",
	"Enthina",
	"Enthonrayryn",
	"Erawdynlere",
	"Essbel",
	"Etoughinahonu",
	"Feylem",
	"Fonoxy",
	"Garonurnvesa",
	"Ghainebanildy",
	"Heann",
	"Henal",
	"Hineno",
	"Hiorm",
	"Hybagy",
	"Ighttorhonchawar",
	"Irdan",
	"Isimryntina",
	"Itser",
	"Kaldaratdaru",
	"Kelenatash",
	"Kelop",
	"Kelsden",
	"Kineshia",
	"Krondovia",
	"Leras",
	"Lorona",
	"Lyever",
	"Meldra",
	"Naest",
	"Nalirden",
	"Neightsam",
	"Nikel",
	"Nobanack",
	"Nydray",
	"Nysdradar",
	"Oldend",
	"Ombania",
	"Omnalstein",
	"Orad",
	"Ordyn",
	"Oreng",
	"Ormementh",
	"Orms",
	"Ortiaightatyer",
	"Osys",
	"Oughia",
	"Ozsay",
	"Purdra",
	"Putas",
	"Quaum",
	"Quetche",
	"Rak-ineas",
	"Rayray",
	"Rhequa",
	"Riluskir",
	"Riskelardwar",
	"Rodserechghagar",
	"Rony",
	"Rudenen",
	"Rupobia",
	"Ruimom",
	"Rynath",
	"Rynstas",
	"Samph",
	"Satela",
	"Scheenthsay",
	"Seldach",
	"Serostia",
	"Shaenkimonia",
	"Shyetingmora",
	"Smytinis",
	"Sneust",
	"Sokihy",
	"Sulsulwar",
	"Swelorgonia",
	"Taasor",
	"Taiati",
	"Taiustturvorenth",
	"Taixina",
	"Talirackia",
	"Taslerdra",
	"Therashtinsule",
	"Thien",
	"Thrauntough",
	"Throisselm",
	"Thukimqua",
	"Tiaserompolorm",
	"Tiavoretage",
	"Tinlera",
	"Tunyurania",
	"Tuirdryn",
	"Turoldlerturia",
	"Tyren",
	"Umena",
	"Untgararpola",
	"Usks",
	"Vesem",
	"Vesnalcheena",
	"Vesworon",
	"Vorenaleburia",
	"Whesh",
	"Wolkenstein",
	"Xylito",
	"Yerrothe",
	"Zywosa"
	// Totals Regions : 540
};

//
// The following stuff is just for in this file, to setup the names during
// world setup
//

#define numberoftowns 600 // Note: This must match the division between town and regions above

static int nnames;
static int * nameused;
static int ntowns;
static int nregions;

void SetupNames()
{
    nnames = sizeof regionnames / sizeof (char *);
    nameused = new int[nnames];
    
    for (int i=0; i<nnames; i++) nameused[i] = 0;
	ntowns = 0;
	nregions = 0;
}

void CountNames()
{	Awrite(AString("Towns ") + ntowns);
	Awrite(AString("Regions ") + nregions);
}


int AGetName( ARegion *pReg, int town )
{
	int offset, number;
	if (town)
	{	offset = 0;
		number = numberoftowns;
	}
	else
	{	offset = numberoftowns;
		number = nnames-numberoftowns;
	}
	int i = getrandom(number);
	int j;
    for(int count=0; count < number; count++)
    {	j = i+offset;
		if (nameused[j] == 0)
        {   nameused[j] = 1;
			if (town) ntowns++;
			else nregions++;
            return j;
        }
		if (++i >= number) i=0;
    }
    for (i=0; i<number; i++) nameused[i+offset] = 0;
    i = getrandom(number);
	j = i+offset;
    nameused[j] = 1;
	if (town) ntowns++;
	else nregions++;
    return j;
}

char *AGetNameString( int name )
{
    return( regionnames[ name ] );
}

char Game::GetRChar(ARegion * r)
{
    int t = r->type;
    char c;
    switch (t) {
    case R_OCEAN:
        return '-';

    case R_PLAIN:
        c = 'p';
        break;
    case R_FOREST:
        c = 'f';
        break;
    case R_MOUNTAIN:
        c = 'm';
        break;
    case R_SWAMP:
        c = 's';
        break;
    case R_JUNGLE:
        c = 'j';
        break;
    case R_DESERT:
        c = 'd';
        break;
    case R_TUNDRA:
        c = 't';
        break;
    case R_CAVERN:
        c = 'c';
        break;
    case R_UFOREST:
        c = 'f';
        break;
    case R_TUNNELS:
        c = 't';
        break;
    default:
        return '?';

    }
    
    if (r->town) {
        c = (c - 'a') + 'A';
    }
    return c;
}

void Game::CreateWorld()
{
    int xx = 0;
    while (xx <= 0)
    {
        Awrite("How wide should the map be? ");
        xx = Agetint();
        if( xx % 8 )
        {
            xx -= (xx % 8);
            Awrite( AString("Width set to ") + xx);
        }
    }
    int yy = 0;
    while (yy <= 0)
    {
        Awrite("How tall should the map be? ");
        yy = Agetint();
        if( yy % 8 )
        {
            yy -= (yy % 8);
            Awrite( AString("Height set to ") + yy);
        }
    }
	int seapercent = 0;
    while (seapercent <= 0)
    {
        Awrite("What percentage of the world should be ocean? (60% recommended)");
        seapercent = Agetint();
        if (seapercent < 10)
		{	seapercent = 10;
			Awrite("Ocean set to 10%");
		}
		else if (seapercent > 90)
		{	seapercent = 90;
			Awrite("Ocean set to 90%");
		}
    }

    regions.CreateLevels( 3 );

    SetupNames();

    regions.CreateNexusLevel( 0, "nexus" );
    regions.CreateSurfaceLevel( 1, xx, yy, seapercent, 16, 0 );
    regions.CreateUnderworldLevel( 2, xx / 2, yy / 2, "underworld" );

    regions.MakeShaftLinks( 2, 1, 8 );

    regions.SetACNeighbors( 0, 1, xx, yy );

    regions.InitSetupGates( 1 );
    regions.InitSetupGates( 2 );
    regions.FinalSetupGates();

    regions.CalcDensities();
	CountNames();
}

void Game::CreateNPCFactions()
{
    guardfaction = factionseq;
    Faction * f = new Faction(factionseq++);
    AString * temp = new AString("The Guardsmen");
    f->SetName(temp);
    f->SetNPC();
    factions.Add(f);
  
    f = new Faction(factionseq++);
    monfaction = f->num;
    temp = new AString("Creatures");
    f->SetName(temp);
    f->SetNPC();
    factions.Add(f);
}

void Game::CreateCityMon( ARegion *pReg, int percent )
{
    int skilllevel;
    int AC = 0;
    if( pReg->type == R_NEXUS || pReg->IsStartingCity() )
    {
        skilllevel = 5;
        AC = 1;
    }
    else
    {
        skilllevel = pReg->town->TownType() + 1;
    }
    int num = Globals->CITY_GUARD * skilllevel;
    num = num * percent / 100;

    Faction *pFac = GetFaction( &factions, 1 );

    Unit *u = GetNewUnit( pFac );
    AString *s = new AString("City Guard");
    u->SetName( s );
    u->type = U_GUARD;
    u->guard = GUARD_GUARD;

    u->SetMen(I_LEADERS,num);
    if (AC)
    {
        u->SetSkill(S_OBSERVATION,10);
		#ifdef _SUPER_WEAPONS
		u->items.SetNum(I_ADAXE,num);
		u->items.SetNum(I_ADARMOR,num);
		#else
		u->items.SetNum(I_MSWORD,num);
		#endif
		u->items.SetNum(I_AMULETOFI,num);
    }
    else
    {
        u->SetSkill(S_OBSERVATION,skilllevel);
		u->items.SetNum(I_SWORD,num);
    }
    u->SetMoney(num * Globals->GUARD_MONEY);	
    u->SetSkill(S_COMBAT,skilllevel);
    u->SetFlag(FLAG_HOLDING,1);
    
    u->MoveUnit( pReg->GetDummy() );

	if (AC)
	{	u = GetNewUnit( pFac );
		AString *s = new AString("City Guard Archers");
		u->SetName( s );
		u->type = U_GUARD;
		u->guard = GUARD_GUARD;
		u->SetMen(I_LEADERS,num);
        u->SetSkill(S_OBSERVATION,10);
		u->SetSkill(S_COMBAT,skilllevel);
		#ifdef _SUPER_WEAPONS
		u->items.SetNum(I_SUPERBOW,num);
		#else
		u->items.SetNum(I_DBOW,num);
		#endif
		u->items.SetNum(I_AMULETOFI,num);
	    u->SetMoney(num * Globals->GUARD_MONEY);	
		u->SetSkill(S_LONGBOW,skilllevel);
		u->SetFlag(FLAG_HOLDING,1);
		u->SetFlag(FLAG_BEHIND,1);
		u->MoveUnit( pReg->GetDummy() );
		
		u = GetNewUnit( pFac );
		s = new AString("City Guard Captains");
		u->SetName( s );
		u->type = U_GUARD;
		u->guard = GUARD_GUARD;
		u->SetMen(I_LEADERS,num / 10);
        u->SetSkill(S_OBSERVATION,10);
		u->SetSkill(S_COMBAT,skilllevel);
		#ifdef _SUPER_WEAPONS
		u->items.SetNum(I_SUPERBOW,num);
		#else
		u->items.SetNum(I_DBOW,num);
		#endif
		u->items.SetNum(I_CLOAKOFI,num);
		u->items.SetNum(I_AMULETOFI,num);
	    u->SetMoney(num * Globals->GUARD_MONEY);	
		u->SetSkill(S_LONGBOW,skilllevel);
		u->SetSkill(S_TACTICS,skilllevel);
		u->SetFlag(FLAG_HOLDING,1);
		u->SetFlag(FLAG_BEHIND,1);
		u->MoveUnit( pReg->GetDummy() );
	}
}

void Game::AdjustCityMons( ARegion *r )
{
    int guard = 0;
    forlist(&r->objects) {
        Object * o = (Object *) elem;
        forlist(&o->units) {
            Unit * u = (Unit *) elem;
            if (u->type == U_GUARD)
            {
                AdjustCityMon( r, u );
                return;
            }
            if (u->guard == GUARD_GUARD) {
                guard = 1;
            }
        }
    }

    if (!guard && getrandom(100) < Globals->GUARD_REGEN)
    {
        CreateCityMon( r, 10 );
    }
}

void Game::AdjustCityMon( ARegion *r, Unit *u )
{
    int towntype,skilllevel;
    int AC = 0;
    if( r->type == R_NEXUS || r->IsStartingCity() )
    {
        towntype = TOWN_CITY;
		skilllevel = 5;
        AC = 1;
    }
    else
    {
        towntype = r->town->TownType();
		skilllevel = towntype + 1;
    }

    int men = u->GetMen() + (Globals->CITY_GUARD / 10) * (skilllevel + 1);
    if (men > Globals->CITY_GUARD * skilllevel)
        men = Globals->CITY_GUARD * skilllevel;
    u->SetMen(I_LEADERS,men);

    u->SetMoney(men * Globals->GUARD_MONEY);
    u->SetSkill(S_COMBAT,skilllevel);
    if (AC)
    {
        u->SetSkill(S_OBSERVATION,10);
		if (u->GetSkill(S_LONGBOW) > 0)
		{	
			#ifdef _SUPER_WEAPONS
			u->items.SetNum(I_SUPERBOW,men);
			#else
			u->items.SetNum(I_DBOW,men);
			#endif
			if (u->GetSkill(S_TACTICS) > 0)
			{	u->items.SetNum(I_CLOAKOFI,men);
			}
		}
		else
		{
			#ifdef _SUPER_WEAPONS
			u->items.SetNum(I_ADAXE,men);
			u->items.SetNum(I_ADARMOR,men);
			#else
			u->items.SetNum(I_MSWORD,men);
			#endif
		}
		u->items.SetNum(I_AMULETOFI,men);
    }
    else
    {
        u->SetSkill(S_OBSERVATION,skilllevel);
		u->items.SetNum(I_SWORD,men);
    }
}

int Game::MakeWMon( ARegion *pReg )
{
    if (TerrainDefs[pReg->type].wmonfreq == 0)
    {
        return 0;
    }

    int montype = TerrainDefs[ pReg->type ].smallmon;
    if (getrandom(2))
        montype = TerrainDefs[ pReg->type ].humanoid;
    if (TerrainDefs[ pReg->type ].bigmon != -1 && !getrandom(8)) {
        montype = TerrainDefs[ pReg->type ].bigmon;
    }
    
    int mondef = ItemDefs[montype].index;
    
    Faction *monfac = GetFaction( &factions, 2 );

    Unit *u = GetNewUnit( monfac, 0 );
    u->MakeWMon( MonDefs[mondef].name, montype,
                 (MonDefs[mondef].number +
                  getrandom(MonDefs[mondef].number) + 1) / 2);
    u->MoveUnit( pReg->GetDummy() );
    return( 1 );
}

void Game::MakeLMon( Object *pObj )
{
    int montype = ObjectDefs[ pObj->type ].monster;
    if (montype == I_TRENT)
    {
        montype = TerrainDefs[ pObj->region->type].bigmon;
    }
    if (montype == I_CENTAUR)
    {
        montype = TerrainDefs[ pObj->region->type ].humanoid;
    }

    int mondef = ItemDefs[montype].index;
    Faction *monfac = GetFaction( &factions, 2 );
    Unit *u = GetNewUnit( monfac, 0 );
	int dodefault = 0;
	switch(montype)
	{	case I_IMP:
			u->MakeWMon( "Demons",
						 I_IMP,
						 getrandom( MonDefs[MONSTER_IMP].number + 1 ));
			u->items.SetNum( I_DEMON,
							 getrandom( MonDefs[MONSTER_DEMON].number + 1 ));
			u->items.SetNum( I_BALROG,
							 getrandom( MonDefs[MONSTER_BALROG].number + 1 ));
			break;
		case I_SKELETON:
			u->MakeWMon( "Undead",
						 I_SKELETON,
						 getrandom( MonDefs[MONSTER_SKELETON].number + 1 ));
			u->items.SetNum( I_UNDEAD,
							 getrandom( MonDefs[MONSTER_UNDEAD].number + 1 ));
			u->items.SetNum( I_LICH,
							 getrandom( MonDefs[MONSTER_LICH].number + 1 ));
			break;
		case I_TRENT: // i.e. forest
			if (getrandom(2) < 1) {
				dodefault = 1;
			} else {
				u->MakeWMon( "Wolves",
                     I_WOLF,
					 getrandom( MonDefs[MONSTER_WOLF].number + 1 ));
				u->items.SetNum( I_WEREWOLF,
					             getrandom( MonDefs[I_WEREWOLF].number + 1 ));
			}
			break;
		case I_TROLL: // i.e. underforest
			dodefault = 1;
			if (getrandom(2) < 1) {
				montype = I_WEREWOLF;
				mondef = ItemDefs[montype].index;
			}
			break;
			
		
		#ifdef _NEW_MONSTERS
		case I_MAGICIANS:
			u->MakeWMon( MonDefs[MONSTER_WARRIORS].name,
                     I_WARRIORS,
                     ( MonDefs[MONSTER_WARRIORS].number +
                       getrandom( MonDefs[MONSTER_WARRIORS].number ) + 1) / 2);
			u->MoveUnit( pObj );
			u = GetNewUnit( monfac, 0 );
			u->MakeWMon( "Evil Mages",
                     I_MAGICIANS,
                     ( MonDefs[MONSTER_MAGICIANS].number +
                       getrandom( MonDefs[MONSTER_MAGICIANS].number ) + 1) / 2);
			u->items.SetNum( I_SORCERERS,
							 getrandom( MonDefs[MONSTER_SORCERERS].number + 1 ));
			u->SetFlag(FLAG_BEHIND, 1);
			break;
		case I_DARKMAGE:
			u->MakeWMon( MonDefs[MONSTER_DROW].name,
                     I_DROW,
                     ( MonDefs[MONSTER_DROW].number +
                       getrandom( MonDefs[MONSTER_DROW].number ) + 1) / 2);
			u->MoveUnit( pObj );
			u = GetNewUnit( monfac, 0 );
			u->MakeWMon( "Dark Mages",
                     I_MAGICIANS,
                     ( MonDefs[MONSTER_MAGICIANS].number +
                       getrandom( MonDefs[MONSTER_MAGICIANS].number ) + 1) / 2);
			u->items.SetNum( I_SORCERERS,
							 getrandom( MonDefs[MONSTER_SORCERERS].number + 1 ));
			u->items.SetNum( I_DARKMAGE,
							 getrandom( MonDefs[MONSTER_DARKMAGE].number + 1 ));
			u->SetFlag(FLAG_BEHIND, 1);
			break;
		case I_ILLYRTHID:
			u->MakeWMon( "Undead",
						 I_SKELETON,
						 getrandom( MonDefs[MONSTER_SKELETON].number + 1 ));
			u->items.SetNum( I_UNDEAD,
							 getrandom( MonDefs[MONSTER_UNDEAD].number + 1 ));
			u->MoveUnit( pObj );
			u = GetNewUnit( monfac, 0 );
			u->MakeWMon( MonDefs[MONSTER_ILLYRTHID].name,
                     I_ILLYRTHID,
                     ( MonDefs[MONSTER_ILLYRTHID].number +
                       getrandom( MonDefs[MONSTER_ILLYRTHID].number ) + 1) / 2);
			u->SetFlag(FLAG_BEHIND, 1);
			break;
		case I_STORMGIANT:
			if (getrandom(3) < 1)
			{	mondef = MONSTER_CLOUDGIANT;
				montype = I_CLOUDGIANT;
			}
			u->MakeWMon( MonDefs[mondef].name,
                     montype,
                     ( MonDefs[mondef].number +
                       getrandom( MonDefs[mondef].number ) + 1) / 2);
			break;
		#endif

		default:
			dodefault = 1;
			break;
    }

	if (dodefault) {
		u->MakeWMon( MonDefs[mondef].name,
                     montype,
                     ( MonDefs[mondef].number +
                       getrandom( MonDefs[mondef].number ) + 1) / 2);
	}

    u->MoveUnit( pObj );
}

int ARegionList::GetRegType( ARegion *pReg )
{
    //
    // Figure out the distance from the equator, from 0 to 3.
    //
    int lat = ( pReg->yloc * 8 ) / ( pRegionArrays[ pReg->zloc ]->y );
    if (lat > 3) 
    {
        lat = (7 - lat);
    }

    if( pReg->zloc == 2 )
    {
        int r = getrandom(4);
        switch (r)
        {
        case 0:
            return R_OCEAN;
        case 1:
            return R_CAVERN;
        case 2:
            return R_UFOREST;
        case 3:
            return R_TUNNELS;
        default:
            return( 0 );
        }
    }

    if( pReg->zloc == 1 )
    {
        int r = getrandom(64);
        switch (lat)
        {
        case 0: /* Arctic regions */
            if (r < 24) return R_TUNDRA;
            if (r < 32) return R_MOUNTAIN;
            if (r < 40) return R_FOREST;
            return R_PLAIN;
        case 1: /* Colder regions */
            if (r < 16) return R_PLAIN;
            if (r < 40) return R_FOREST;
            if (r < 48) return R_MOUNTAIN;
            return R_SWAMP;
        case 2: /* Warmer regions */
            if (r < 20) return R_PLAIN;
            if (r < 28) return R_FOREST;
            if (r < 36) return R_MOUNTAIN;
            if (r < 44) return R_SWAMP;
            if (r < 52) return R_JUNGLE;
            return R_DESERT;
        case 3: /* tropical */
            if (r < 16) return R_PLAIN;
            if (r < 24) return R_MOUNTAIN;
            if (r < 36) return R_SWAMP;
            if (r < 48) return R_JUNGLE;
            return R_DESERT;
        }
        return R_OCEAN;
    }

    if( pReg->zloc == 0 )
    {
        //
        // This really shouldn't ever get called.
        //
        return( R_NEXUS );
    }

    //
    // This really shouldn't get called either
    //
    return( R_OCEAN );
}

int ARegionList::CheckRegionExit( int nDir, ARegion *pFrom, ARegion *pTo )
{
    if( pFrom->zloc != 2 )
    {
        return( 1 );
    }

    int chance = 0;
    if( pFrom->type == R_CAVERN || pFrom->type == R_UFOREST ||
        pTo->type == R_CAVERN || pTo->type == R_UFOREST )
    {
        chance = 25;
    }
    if( pFrom->type == R_TUNNELS || pTo->type == R_TUNNELS)
    {
        chance = 50;
    }
    if (getrandom(100) < chance)
    {
        return( 0 );
    }
    return( 1 );
}

int ARegionList::GetWeather( ARegion *pReg, int month )
{
    if (pReg->zloc == 0)
    {
        return W_NORMAL;
    }

    if( pReg->zloc == 2 )
    {
        return( W_NORMAL );
    }
  
    int ysize = pRegionArrays[ 1 ]->y;

    if ((3*( pReg->yloc+1))/ysize == 0)
    {
        /* Northern third of the world */
        if (month > 9 || month < 2)
        {
            return W_WINTER;
        } 
        else
        {
            return W_NORMAL;
        }
    }
  
    if ((3*( pReg->yloc+1))/ysize == 1)
    {
        /* Middle third of the world */
        if (month == 11 || month == 0 || month == 5 || month == 6)
        {
            return W_MONSOON;
        } 
        else
        {
            return W_NORMAL;
        }
    }
  
    if (month > 3 && month < 8)
    {
        /* Southern third of the world */
        return W_WINTER;
    } 
    else
    {
        return W_NORMAL;
    }
}

int ARegion::CanBeStartingCity( ARegionArray *pRA )
{
    if (!town) return 0;
    if (!IsCoastal()) return 0;
    if (town->pop == 5000) return 0;

    int regs = 0;
    AList inlist;
    AList donelist;
  
    ARegionPtr * temp = new ARegionPtr;
    temp->ptr = this;
    inlist.Add(temp);

    while(inlist.Num())
    {
        ARegionPtr * reg = (ARegionPtr *) inlist.First();
        for (int i=0; i<NDIRS; i++)
        {
            ARegion * r2 = reg->ptr->neighbors[i];
            if (!r2) continue;
            if (r2->type == R_OCEAN) continue;
            if (GetRegion(&inlist,r2->num)) continue;
            if (GetRegion(&donelist,r2->num)) continue;
            regs++;
            if (regs>20) return 1;
            ARegionPtr * temp = new ARegionPtr;
            temp->ptr = r2;
            inlist.Add(temp);
        }
        inlist.Remove(reg);
        donelist.Add(reg);
    }
    return 0;
}

void ARegion::MakeStartingCity() 
{
    gate = -1;
    if( !town )
    {
        AddTown();
    }

    town->pop = 5000;
    town->basepop = 5000;

    markets.DeleteAll();
    for (int i=0; i<NITEMS; i++) {
        if( ItemDefs[ i ].type & IT_NORMAL )
        {
            if (i==I_SILVER || i==I_LIVESTOCK || i==I_FISH || i==I_GRAIN) 
            {
                continue;
            }
            Market * m = new Market(M_BUY,i,(ItemDefs[i].baseprice * 5 / 2),-1,
                                    5000,5000,-1,-1);
            markets.Add(m);
        }
    }

    Market * m = new Market(M_BUY,race,Wages()*4,-1,5000,5000,-1,-1);
    markets.Add(m);
    m = new Market(M_BUY,I_LEADERS,Wages()*8,-1,5000,5000,-1,-1);
    markets.Add(m);
}

int ARegion::IsStartingCity() {
    if (town && town->pop == 5000) return 1;
    return 0;
}

int ARegion::IsSafeRegion()
{
    return( IsStartingCity() );
}

ARegion *ARegionList::GetStartingCity( ARegion *AC,
                                       int i,
                                       int level,
                                       int maxX,
                                       int maxY )
{
    ARegionArray *pArr = pRegionArrays[ level ];
    ARegion * reg = 0;

    if( pArr->x < maxX )
    {
        maxX = pArr->x;
    }
    if( pArr->y < maxY )
    {
        maxY = pArr->y;
    }

    while (!reg)
    {
        //
        // We'll just let AC exits be all over the map.
        //
        int x = getrandom( maxX );
        int y = 2 * getrandom( maxY / 2 ) + x % 2;

        reg = GetRegion( x, y, level );
        
        if( !reg->CanBeStartingCity( pArr ))
        {
            reg = 0;
            continue;
        }

        for (int j=0; j<i; j++)
        {
            if (GetDistance(reg,AC->neighbors[j]) < maxY / 10 + 2 )
            {
                reg = 0;
                break;
            }
        }
    }
    return reg;
}

