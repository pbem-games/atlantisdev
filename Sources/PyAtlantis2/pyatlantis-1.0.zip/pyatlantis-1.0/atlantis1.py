#!/usr/bin/env python

"""

Atlantis v1.0 -- The Python Remix
(C) 2007 Anthony Briggs, based on the original C version by Russel Wallace:

/*    Atlantis v1.0  13 September 1993
    Copyright 1993 by Russell Wallace

    This program may be freely used, modified and distributed.  It may not be
    sold or used commercially without prior written permission from the author.
*/

UPDATE: Geoff Dunbar has released the Atlantis source code under the GPL. 
        See the license/announcement at http://www.prankster.com/project/license.htm

v0.1alpha -- This is pretty much a direct translation - not much effort has 
             been made to 'pythonify' the code except where absolutely
             necessary (eg. input, removing globals (in places) and file
             handling). Getting the game working first takes top priority.

             Bugs fixed so far in the original code:
              - you can now have more RINGs than men and still be invisible
              - you can't create a continent on top of another continent
"""
import os
import random
import sys


NAMESIZE = 81
DISPLAYSIZE = 161
ORDERGAP = 4
BLOCKSIZE = 7
BLOCKBORDER = 1
MAINTENANCE = 10
STARTMONEY = 5000
RECRUITCOST = 50
RECRUITFRACTION = 4
ENTERTAININCOME = 20
ENTERTAINFRACTION = 20
TAXINCOME = 200
COMBATEXP = 10
PRODUCEEXP = 10
TEACHNUMBER = 10
STUDYCOST = 200
POPGROWTH = 5
PEASANTMOVE = 5


for value, item in enumerate([ 
    "T_OCEAN",
    "T_PLAIN",
    "T_MOUNTAIN",
    "T_FOREST",
    "T_SWAMP",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SH_LONGBOAT",
    "SH_CLIPPER",
    "SH_GALLEON",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SK_MINING",
    "SK_LUMBERJACK",
    "SK_QUARRYING",
    "SK_HORSE_TRAINING",
    "SK_WEAPONSMITH",
    "SK_ARMORER",
    "SK_BUILDING",
    "SK_SHIPBUILDING",
    "SK_ENTERTAINMENT",
    "SK_STEALTH",
    "SK_OBSERVATION",
    "SK_TACTICS",
    "SK_RIDING",
    "SK_SWORD",
    "SK_CROSSBOW",
    "SK_LONGBOW",
    "SK_MAGIC",
    "MAXSKILLS",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "I_IRON",
    "I_WOOD",
    "I_STONE",
    "I_HORSE",
    "I_SWORD",
    "I_CROSSBOW",
    "I_LONGBOW",
    "I_CHAIN_MAIL",
    "I_PLATE_ARMOR",
    "I_AMULET_OF_DARKNESS",
    "I_AMULET_OF_DEATH",
    "I_AMULET_OF_HEALING",
    "I_AMULET_OF_TRUE_SEEING",
    "I_CLOAK_OF_INVULNERABILITY",
    "I_RING_OF_INVISIBILITY",
    "I_RING_OF_POWER",
    "I_RUNESWORD",
    "I_SHIELDSTONE",
    "I_STAFF_OF_FIRE",
    "I_STAFF_OF_LIGHTNING",
    "I_WAND_OF_TELEPORTATION",
    "MAXITEMS",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SP_BLACK_WIND",
    "SP_CAUSE_FEAR",
    "SP_CONTAMINATE_WATER",
    "SP_DAZZLING_LIGHT",
    "SP_FIREBALL",
    "SP_HAND_OF_DEATH",
    "SP_HEAL",
    "SP_INSPIRE_COURAGE",
    "SP_LIGHTNING_BOLT",
    "SP_MAKE_AMULET_OF_DARKNESS",
    "SP_MAKE_AMULET_OF_DEATH",
    "SP_MAKE_AMULET_OF_HEALING",
    "SP_MAKE_AMULET_OF_TRUE_SEEING",
    "SP_MAKE_CLOAK_OF_INVULNERABILITY",
    "SP_MAKE_RING_OF_INVISIBILITY",
    "SP_MAKE_RING_OF_POWER",
    "SP_MAKE_RUNESWORD",
    "SP_MAKE_SHIELDSTONE",
    "SP_MAKE_STAFF_OF_FIRE",
    "SP_MAKE_STAFF_OF_LIGHTNING",
    "SP_MAKE_WAND_OF_TELEPORTATION",
    "SP_SHIELD",
    "SP_SUNFIRE",
    "SP_TELEPORT",
    "MAXSPELLS", ]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "K_ACCEPT",
    "K_ADDRESS",
    "K_ADMIT",
    "K_ALLY",
    "K_ATTACK",
    "K_BEHIND",
    "K_BOARD",
    "K_BUILD",
    "K_BUILDING",
    "K_CAST",
    "K_CLIPPER",
    "K_COMBAT",
    "K_DEMOLISH",
    "K_DISPLAY",
    "K_EAST",
    "K_END",
    "K_ENTER",
    "K_ENTERTAIN",
    "K_FACTION",
    "K_FIND",
    "K_FORM",
    "K_GALLEON",
    "K_GIVE",
    "K_GUARD",
    "K_LEAVE",
    "K_LONGBOAT",
    "K_MOVE",
    "K_NAME",
    "K_NORTH",
    "K_PAY",
    "K_PRODUCE",
    "K_PROMOTE",
    "K_QUIT",
    "K_RECRUIT",
    "K_RESEARCH",
    "K_RESHOW",
    "K_SAIL",
    "K_SHIP",
    "K_SINK",
    "K_SOUTH",
    "K_STUDY",
    "K_TAX",
    "K_TEACH",
    "K_TRANSFER",
    "K_UNIT",
    "K_WEST",
    "K_WORK",
    "MAXKEYWORDS",]):
    exec("%s = %s" % (item, value))


"""
typedef struct building
{
    struct building *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    int size;
    int sizeleft;
} building;
"""

class Building:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.size = 0
        self.sizeleft = 0

"""
typedef struct ship
{
    struct ship *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    char type;
    int left;
} ship;
"""

class Ship:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.type = ""
        self.left = 0

"""
typedef struct region
{
    struct region *next;
    int x,y;
    char name[NAMESIZE];
    struct region *connect[4];
    char terrain;
    int peasants;
    int money;
    building *buildings;
    ship *ships;
    unit *units;
    int immigrants;
} region;
"""

class Region:
    def __init__(self):
        self.next = None
        self.x = 0
        self.y = 0
        self.name = "void"
        self.connect = [None, None, None, None]
        self.terrain = 0
        self.peasants = 0
        self.money = 0
        self.buildings = []
        self.ships = []
        self.units = []
        self.immigrants = 0

"""
struct faction;

typedef struct rfaction
{
    struct rfaction *next;
    struct faction *faction;
    int factionno;
} rfaction;
"""

class RFaction:
    def __init__(self):
        self.next = None
        self.faction = None
        self.factionno = 0

"""
typedef struct faction
{
    struct faction *next;
    int no;
    char name[NAMESIZE];
    char addr[NAMESIZE];
    int lastorders;
    char seendata[MAXSPELLS];
    char showdata[MAXSPELLS];
    rfaction *accept;
    rfaction *admit;
    rfaction *allies;
    strlist *mistakes;
    strlist *messages;
    strlist *battles;
    strlist *events;
    char alive;
    char attacking;
    char seesbattle;
    char dh;
    int nunits;
    int number;
    int money;
} faction;
"""

class Faction:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.addr = ""
        self.password = ""
        self.lastorders = 0
        self.seendata = [0] * MAXSPELLS
        self.showdata = [0] * MAXSPELLS
        self.accept = []
        self.admit = []
        self.allies = []
        self.mistakes = []
        self.messages = []
        self.battles = []
        self.events = []
        self.alive = ""
        self.attacking = ""
        self.seesbattle = ""
        self.dh = ""
        self.nunits = 0
        self.number = 0
        self.money = 0

"""
struct unit
{
    struct unit *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    
    # number of men
    int number;
    int money;
    faction *faction;
    building *building;
    ship *ship;
    char owner;
    char behind;
    char guard;
    char thisorder[NAMESIZE];
    char lastorder[NAMESIZE];
    char combatspell;
    int skills[MAXSKILLS];
    int items[MAXITEMS];
    char spells[MAXSPELLS];
    strlist *orders;
    int alias;
    int dead;
    int learning;
    int n;
    int *litems;
    char side;
    char isnew;
};
"""

class Unit:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.number = 0
        self.money = 0
        self.faction = None
        self.building = None
        self.ship = None
        self.owner = 0
        self.behind = 0
        self.guard = 0
        self.thisorder = ""
        self.lastorder = ""
        self.combatspell = ""
        self.skills = [0] * MAXSKILLS
        self.items = [0] * MAXITEMS
        self.spells = [0] * MAXSPELLS
        self.orders = []
        self.alias = 0
        self.dead = 0
        self.learning = 0
        self.n = 0
        self.litems = []
        self.side = ""
        self.isnew = ""
 
"""
typedef struct order
{
    struct order *next;
    unit *unit;
    int qty;
} order;
"""

class Order:
    def __init__(self):
        self.next = None
        self.unit = None
        self.qty = 0

"""
typedef struct troop
{
    struct troop *next;
    unit *unit;
    int lmoney;
    char status;
    char side;
    char attacked;
    char weapon;
    char missile;
    char skill;
    char armor;
    char behind;
    char inside;
    char reload;
    char canheal;
    char runesword;
    char invulnerable;
    char power;
    char shieldstone;
    char demoralized;
    char dazzled;
} troop;
"""

class Troop:
    def __init__(self):
        self.next = None
        self.unit = None
        self.lmoney = 0
        self.status = ""
        self.side = ""
        self.attacked = ""
        self.weapon = ""
        self.missile = ""
        self.skill = ""
        self.armor = ""
        self.behind = ""
        self.inside = ""
        self.reload = ""
        self.canheal = ""
        self.runesword = ""
        self.invulnerable = ""
        self.power = ""
        self.shieldstone = ""
        self.demoralized = ""
        self.dazzled = ""


turn = 0
regions = []
factions = []


keywords = [
    "accept",
    "address",
    "admit",
    "ally",
    "attack",
    "behind",
    "board",
    "build",
    "building",
    "cast",
    "clipper",
    "combat",
    "demolish",
    "display",
    "east",
    "end",
    "enter",
    "entertain",
    "faction",
    "find",
    "form",
    "galleon",
    "give",
    "guard",
    "leave",
    "longboat",
    "move",
    "name",
    "north",
    "pay",
    "produce",
    "promote",
    "quit",
    "recruit",
    "research",
    "reshow",
    "sail",
    "ship",
    "sink",
    "south",
    "study",
    "tax",
    "teach",
    "transfer",
    "unit",
    "west",
    "work",
]

terrainnames = [
    "ocean",
    "plain",
    "mountain",
    "forest",
    "swamp",
]

regionnames = [
    "Aberaeron",
    "Aberdaron",
    "Aberdovey",
    "Abernethy",
    "Abersoch",
    "Abrantes",
    "Adrano",
    "AeBrey",
    "Aghleam",
    "Akbou",
    "Aldan",
    "Alfaro",
    "Alghero",
    "Almeria",
    "Altnaharra",
    "Ancroft",
    "Anshun",
    "Anstruther",
    "Antor",
    "Arbroath",
    "Arcila",
    "Ardfert",
    "Ardvale",
    "Arezzo",
    "Ariano",
    "Arlon",
    "Avanos",
    "Aveiro",
    "Badalona",
    "Baechahoela",
    "Ballindine",
    "Balta",
    "Banlar",
    "Barika",
    "Bastak",
    "Bayonne",
    "Bejaia",
    "Benlech",
    "Beragh",
    "Bergland",
    "Berneray",
    "Berriedale",
    "Binhai",
    "Birde",
    "Bocholt",
    "Bogmadie",
    "Braga",
    "Brechlin",
    "Brodick",
    "Burscough",
    "Calpio",
    "Canna",
    "Capperwe",
    "Caprera",
    "Carahue",
    "Carbost",
    "Carnforth",
    "Carrigaline",
    "Caserta",
    "Catrianchi",
    "Clatter",
    "Coilaco",
    "Corinth",
    "Corofin",
    "Corran",
    "Corwen",
    "Crail",
    "Cremona",
    "Crieff",
    "Cromarty",
    "Cumbraes",
    "Daingean",
    "Darm",
    "Decca",
    "Derron",
    "Derwent",
    "Deveron",
    "Dezhou",
    "Doedbygd",
    "Doramed",
    "Dornoch",
    "Drammes",
    "Dremmer",
    "Drense",
    "Drimnin",
    "Drumcollogher",
    "Drummore",
    "Dryck",
    "Drymen",
    "Dunbeath",
    "Duncansby",
    "Dunfanaghy",
    "Dunkeld",
    "Dunmanus",
    "Dunster",
    "Durness",
    "Duucshire",
    "Elgomaar",
    "Ellesmere",
    "Ellon",
    "Enfar",
    "Erisort",
    "Eskerfan",
    "Ettrick",
    "Fanders",
    "Farafra",
    "Ferbane",
    "Fetlar",
    "Flock",
    "Florina",
    "Formby",
    "Frainberg",
    "Galloway",
    "Ganzhou",
    "Geal Charn",
    "Gerr",
    "Gifford",
    "Girvan",
    "Glenagallagh",
    "Glenanane",
    "Glin",
    "Glomera",
    "Glormandia",
    "Gluggby",
    "Gnackstein",
    "Gnoelhaala",
    "Golconda",
    "Gourock",
    "Graevbygd",
    "Grandola",
    "Gresberg",
    "Gresir",
    "Greverre",
    "Griminish",
    "Grisbygd",
    "Groddland",
    "Grue",
    "Gurkacre",
    "Haikou",
    "Halkirk",
    "Handan",
    "Hasmerr",
    "Helmsdale",
    "Helmsley",
    "Helsicke",
    "Helvete",
    "Hoersalsveg",
    "Hullevala",
    "Ickellund",
    "Inber",
    "Inverie",
    "Jaca",
    "Jahrom",
    "Jeormel",
    "Jervbygd",
    "Jining",
    "Jotel",
    "Kaddervar",
    "Karand",
    "Karothea",
    "Kashmar",
    "Keswick",
    "Kielder",
    "Killorglin",
    "Kinbrace",
    "Kintore",
    "Kirriemuir",
    "Klen",
    "Knesekt",
    "Kobbe",
    "Komarken",
    "Kovel",
    "Krod",
    "Kursk",
    "Lagos",
    "Lamlash",
    "Langholm",
    "Larache",
    "Larkanth",
    "Larmet",
    "Lautaro",
    "Leighlin",
    "Lervir",
    "Leven",
    "Licata",
    "Limavady",
    "Lingen",
    "Lintan",
    "Liscannor",
    "Locarno",
    "Lochalsh",
    "Lochcarron",
    "Lochinver",
    "Lochmaben",
    "Lom",
    "Lorthalm",
    "Louer",
    "Lurkabo",
    "Luthiir",
    "Lybster",
    "Lynton",
    "Mallaig",
    "Mataro",
    "Melfi",
    "Melvaig",
    "Menter",
    "Methven",
    "Moffat",
    "Monamolin",
    "Monzon",
    "Morella",
    "Morgel",
    "Mortenford",
    "Mullaghcarn",
    "Mulle",
    "Murom",
    "Nairn",
    "Navenby",
    "Nephin Beg",
    "Niskby",
    "Nolle",
    "Nork",
    "Olenek",
    "Oloron",
    "Oranmore",
    "Ormgryte",
    "Orrebygd",
    "Palmi",
    "Panyu",
    "Partry",
    "Pauer",
    "Penhalolen",
    "Perkel",
    "Perski",
    "Planken",
    "Plattland",
    "Pleagne",
    "Pogelveir",
    "Porthcawl",
    "Portimao",
    "Potenza",
    "Praestbygd",
    "Preetsome",
    "Presu",
    "Prettstern",
    "Rantlu",
    "Rappbygd",
    "Rath Luire",
    "Rethel",
    "Riggenthorpe",
    "Rochfort",
    "Roddendor",
    "Roin",
    "Roptille",
    "Roter",
    "Rueve",
    "Sagunto",
    "Saklebille",
    "Salen",
    "Sandwick",
    "Sarab",
    "Sarkanvale",
    "Scandamia",
    "Scarinish",
    "Scourie",
    "Serov",
    "Shanyin",
    "Siegen",
    "Sinan",
    "Sines",
    "Skim",
    "Skokholm",
    "Skomer",
    "Skottskog",
    "Sledmere",
    "Sorisdale",
    "Spakker",
    "Stackforth",
    "Staklesse",
    "Stinchar",
    "Stoer",
    "Strichen",
    "Stroma",
    "Stugslett",
    "Suide",
    "Tabuk",
    "Tarraspan",
    "Tetuan",
    "Thurso",
    "Tiemcen",
    "Tiksi",
    "Tolsta",
    "Toppola",
    "Torridon",
    "Trapani",
    "Tromeforth",
    "Tudela",
    "Turia",
    "Uxelberg",
    "Vaila",
    "Valga",
    "Verguin",
    "Vernlund",
    "Victoria",
    "Waimer",
    "Wett",
    "Xontormia",
    "Yakleks",
    "Yuci",
    "Zaalsehuur",
    "Zamora",
    "Zapulla",
]

foodproductivity = [
    0,
    15,
    12,
    12,
    12,
]

maxfoodoutput = [
    0,
    100000,
    20000,
    20000,
    10000,
]

# I think these next ones are multiple-dimension arrays...
productivity = [
    [0,0,0,0,],
    [0,0,0,1,],
    [1,0,1,0,],
    [0,1,0,0,],
    [0,1,0,0,],
]

maxoutput = [
    [  0,  0,  0,  0,],
    [  0,  0,  0,200,],
    [200,  0,200,  0,],
    [  0,200,  0,  0,],
    [  0,100,  0,  0,],
]

shiptypenames = [
    "longboat",
    "clipper",
    "galleon",
]

shipcapacity = [
    200,
    800,
    1800,
]

shipcost = [
    100,
    200,
    300,
]

skillnames = [
    "mining",
    "lumberjack",
    "quarrying",
    "horse training",
    "weaponsmith",
    "armorer",
    "building",
    "shipbuilding",
    "entertainment",
    "stealth",
    "observation",
    "tactics",
    "riding",
    "sword",
    "crossbow",
    "longbow",
    "magic",
]

itemnames = [ [
    "iron",
    "wood",
    "stone",
    "horse",
    "sword",
    "crossbow",
    "longbow",
    "chain mail",
    "plate armor",
    "Amulet of Darkness",
    "Amulet of Death",
    "Amulet of Healing",
    "Amulet of True Seeing",
    "Cloak of Invulnerability",
    "Ring of Invisibility",
    "Ring of Power",
    "Runesword",
    "Shieldstone",
    "Staff of Fire",
    "Staff of Lightning",
    "Wand of Teleportation",],

    [
    "iron",
    "wood",
    "stone",
    "horses",
    "swords",
    "crossbows",
    "longbows",
    "chain mail",
    "plate armor",
    "Amulets of Darkness",
    "Amulets of Death",
    "Amulets of Healing",
    "Amulets of True Seeing",
    "Cloaks of Invulnerability",
    "Rings of Invisibility",
    "Rings of Power",
    "Runeswords",
    "Shieldstones",
    "Staffs of Fire",
    "Staffs of Lightning",
    "Wands of Teleportation",],
]


itemskill = [
    SK_MINING,
    SK_LUMBERJACK,
    SK_QUARRYING,
    SK_HORSE_TRAINING,
    SK_WEAPONSMITH,
    SK_WEAPONSMITH,
    SK_WEAPONSMITH,
    SK_ARMORER,
    SK_ARMORER,
]

rawmaterial = [
    0,
    0,
    0,
    0,
    I_IRON,
    I_WOOD,
    I_WOOD,
    I_IRON,
    I_IRON,
]

spellnames = [
    "Black Wind",
    "Cause Fear",
    "Contaminate Water",
    "Dazzling Light",
    "Fireball",
    "Hand of Death",
    "Heal",
    "Inspire Courage",
    "Lightning Bolt",
    "Make Amulet of Darkness",
    "Make Amulet of Death",
    "Make Amulet of Healing",
    "Make Amulet of True Seeing",
    "Make Cloak of Invulnerability",
    "Make Ring of Invisibility",
    "Make Ring of Power",
    "Make Runesword",
    "Make Shieldstone",
    "Make Staff of Fire",
    "Make Staff of Lightning",
    "Make Wand of Teleportation",
    "Shield",
    "Sunfire",
    "Teleport",
]

spelllevel = [
    4,
    2,
    1,
    1,
    2,
    3,
    2,
    2,
    1,
    5,
    4,
    3,
    3,
    3,
    3,
    4,
    3,
    4,
    3,
    2,
    4,
    3,
    5,
    3,
]

iscombatspell = [
    1,
    1,
    0,
    1,
    1,
    1,
    0,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    0,
]

spelldata = [
    "This spell creates a black whirlwind of energy which destroys all life, "
    "leaving frozen corpses with faces twisted into expressions of horror. Cast "
    "in battle, it kills from 2 to 1250 enemies.",

    "This spell creates an aura of fear which causes enemy troops in battle to "
    "panic. Each time it is cast, it demoralizes between 2 and 100 troops for "
    "the duration of the battle. Demoralized troops are at a -1 to their "
    "effective skill.",

    "This ritual spell causes pestilence to contaminate the water supply of the "
    "region in which it is cast. It causes from 2 to 50 peasants to die from "
    "drinking the contaminated water. Any units which end the month in the "
    "affected region will know about the deaths, however only units which have "
    "Observation skill higher than the caster's Stealth skill will know who "
    "was responsible. The spell costs $50 to cast.",

    "This spell, cast in battle, creates a flash of light which dazzles from 2 "
    "to 50 enemy troops. Dazzled troops are at a -1 to their effective skill "
    "for their next attack.",

    "This spell enables the caster to hurl balls of fire. Each time it is cast "
    "in battle, it will incinerate between 2 and 50 enemy troops.",

    "This spell disrupts the metabolism of living organisms, sending an "
    "invisible wave of death across a battlefield. Each time it is cast, it "
    "will kill between 2 and 250 enemy troops.",

    "This spell enables the caster to attempt to heal the injured after a "
    "battle. It is used automatically, and does not require use of either the "
    "COMBAT or CAST command. If one's side wins a battle, a number of  "
    "casualties on one's side, between 2 and 50, will be healed. (If this "
    "results in all the casualties on the winning side being healed, the winner "
    "is still eligible for combat experience.)",

    "This spell boosts the morale of one's troops in battle. Each time it is "
    "cast, it cancels the effect of the Cause Fear spell on a number of one's "
    "own troops ranging from 2 to 100.",

    "This spell enables the caster to throw bolts of lightning to strike down "
    "enemies in battle. It kills from 2 to 10 enemies.",

    "This spell allows one to create an Amulet of Darkness. This amulet allows "
    "its possessor to cast the Black Wind spell in combat, without having to "
    "know the spell; the only requirement is that the user must have the Magic "
    "skill at 1 or higher. The Black Wind spell creates a black whirlwind of "
    "energy which destroys all life. Cast in battle, it kills from 2 to 1250 "
    "people. The amulet costs $1000 to make.",

    "This spell allows one to create an Amulet of Death. This amulet allows its "
    "possessor to cast the Hand of Death spell in combat, without having to "
    "know the spell; the only requirement is that the user must have the Magic "
    "skill at 1 or higher. The Hand of Death spell disrupts the metabolism of "
    "living organisms, sending an invisible wave of death across a battlefield. "
    "Each time it is cast, it will kill between 2 and 250 enemy troops. The "
    "amulet costs $800 to make.",

    "This spell allows one to create an Amulet of Healing. This amulet allows "
    "its possessor to attempt to heal the injured after a battle. It is used "
    "automatically, and does not require the use of either the COMBAT or CAST "
    "command; the only requirement is that the user must have the Magic skill "
    "at 1 or higher. If the user's side wins a battle, a number of casualties "
    "on that side, between 2 and 50, will be healed. (If this results in all "
    "the casualties on the winning side being healed, the winner is still "
    "eligible for combat experience.) The amulet costs $600 to make.",

    "This spell allows one to create an Amulet of True Seeing. This allows its "
    "possessor to see units which are hidden by Rings of Invisibility. (It has "
    "no effect against units which are hidden by the Stealth skill.) The amulet "
    "costs $600 to make.",

    "This spell allows one to create a Cloak of Invulnerability. This cloak "
    "protects its wearer from injury in battle; any attack with a normal weapon "
    "which hits the wearer has a 99.99% chance of being deflected. This benefit "
    "is gained instead of, rather than as well as, the protection of any armor "
    "worn; and the cloak confers no protection against magical attacks. The "
    "cloak costs $600 to make.",

    "This spell allows one to create a Ring of Invisibility. This ring renders "
    "its wearer invisible to all units not in the same faction, regardless of "
    "Observation skill. For a unit of many people to remain invisible, it must "
    "possess a Ring of Invisibility for each person. The ring costs $600 to "
    "make.",

    "This spell allows one to create a Ring of Power. This ring doubles the "
    "effectiveness of any spell the wearer casts in combat, or any magic item "
    "the wearer uses in combat. The ring costs $800 to make.",

    "This spell allows one to create a Runesword. This is a black sword with "
    "magical runes etched along the blade. To use it, one must have both the "
    "Sword and Magic skills at 1 or higher. It confers a bonus of 2 to the "
    "user's Sword skill in battle, and also projects an aura of power that has "
    "a 50% chance of cancelling any Fear spells cast by an enemy magician. The "
    "sword costs $600 to make.",

    "This spell allows one to create a Shieldstone. This is a small black "
    "stone, engraved with magical runes, that creates an invisible shield of "
    "energy that deflects hostile magic in battle. The stone is used "
    "automatically, and does not require the use of either the COMBAT or CAST "
    "commands; the only requirement is that the user must have the Magic skill "
    "at 1 or higher. Each round of combat, it adds one layer to the shielding "
    "around one's own side. When a hostile magician casts a spell, provided "
    "there is at least one layer of shielding present, there is a 50% chance of "
    "the spell being deflected. If the spell is deflected, nothing happens. If "
    "it is not, then it has full effect, and one layer of shielding is removed. "
    "The stone costs $800 to make.",

    "This spell allows one to create a Staff of Fire. This staff allows its "
    "possessor to cast the Fireball spell in combat, without having to know the "
    "spell; the only requirement is that the user must have the Magic skill at "
    "1 or higher. The Fireball spell enables the caster to hurl balls of fire. "
    "Each time it is cast in battle, it will incinerate between 2 and 50 enemy "
    "troops. The staff costs $600 to make.",

    "This spell allows one to create a Staff of Lightning. This staff allows "
    "its possessor to cast the Lightning Bolt spell in combat, without having "
    "to know the spell; the only requirement is that the user must have the "
    "Magic skill at 1 or higher. The Lightning Bolt spell enables the caster to "
    "throw bolts of lightning to strike down enemies. It kills from 2 to 10 "
    "enemies. The staff costs $400 to make.",

    "This spell allows one to create a Wand of Teleportation. This wand allows "
    "its possessor to cast the Teleport spell, without having to know the "
    "spell; the only requirement is that the user must have the Magic skill at "
    "1 or higher. The Teleport spell allows the caster to move himself and "
    "others across vast distances without traversing the intervening space. The "
    "command to use it is CAST TELEPORT target-unit unit-no ... The target unit "
    "is a unit in the region to which the teleport is to occur. If the target "
    "unit is not in your faction, it must be in a faction which has issued an "
    "ADMIT command for you that month. After the target unit comes a list of "
    "one or more units to be teleported into the target unit's region (this may "
    "optionally include the caster). Any units to be teleported, not in your "
    "faction, must be in a faction which has issued an ACCEPT command for you "
    "that month. The total weight of all units to be teleported (including "
    "people, equipment and horses) must not exceed 10000. If the target unit is "
    "in a building or on a ship, the teleported units will emerge there, "
    "regardless of who owns the building or ship. The caster spends the month "
    "preparing the spell and the teleport occurs at the end of the month, so "
    "any other units to be transported can spend the month doing something "
    "else. The wand costs $800 to make, and $50 to use.",

    "This spell creates an invisible shield of energy that deflects hostile "
    "magic. Each round that it is cast in battle, it adds one layer to the "
    "shielding around one's own side. When a hostile magician casts a spell, "
    "provided there is at least one layer of shielding present, there is a 50% "
    "chance of the spell being deflected. If the spell is deflected, nothing "
    "happens. If it is not, then it has full effect, and one layer of shielding "
    "is removed.",

    "This spell allows the caster to incinerate whole armies with fire brighter "
    "than the sun. Each round it is cast, it kills from 2 to 6250 enemies.",

    "This spell allows the caster to move himself and others across vast "
    "distances without traversing the intervening space. The command to use it "
    "is CAST TELEPORT target-unit unit-no ... The target unit is a unit in the "
    "region to which the teleport is to occur. If the target unit is not in "
    "your faction, it must be in a faction which has issued an ADMIT command "
    "for you that month. After the target unit comes a list of one or more "
    "units to be teleported into the target unit's region (this may optionally "
    "include the caster). Any units to be teleported, not in your faction, must "
    "be in a faction which has issued an ACCEPT command for you that month. The "
    "total weight of all units to be teleported (including people, equipment "
    "and horses) must not exceed 10000. If the target unit is in a building or "
    "on a ship, the teleported units will emerge there, regardless of who owns "
    "the building or ship. The caster spends the month preparing the spell and "
    "the teleport occurs at the end of the month, so any other units to be "
    "transported can spend the month doing something else. The spell costs $50 "
    "to cast.",
]


# TODO: Hmm, weird C functions. I'll skip over these for now, and work them out from context as I go
# ascii to integer - positive
# atoip (char *s)
def atoip(s):
    """ Convert a string into a positive integer.
        Slight detour from the original, in that if you try and convert 'a' (not an integer),
        you'll get 0 instead of an error."""
    try:
        number = int(s.strip())
        if number < 0:
            number = 0
    except:
        number = 0
    return number

# ascii to integer - positive
def atoi(s):
    """ Convert a string into an integer, with detour as per atoip """
    try:
        number = int(s.strip())
    except:
        number = 0
    return number


# string cat? Slap a string on the end of buf
def scat(s):
    """ Scat .... uhuhuhuhuhu uhuhhuuuuhuhuhuh :) """
    raise NotImplementedError("scat uses evil global variables and has been disabled")

def icat(n):
    raise NotImplementedError("icat uses evil global variables and has been disabled")


def rnd():
    """ Return a big-ass random number """
    return random.randint(-sys.maxint,sys.maxint)


def effskill(unit, i):
    """ Determine the effective skill of a unit, dividing the total 
        number of days training by the number of men, and then 
        splitting into groups of 30 days, etc."""
    n = 0
    if unit.number:
        n = unit.skills[i] / unit.number
    j = 30
    result = 0
    
    while j <= n:
        n -= j;
        j += 30;
        result += 1
    
    return result


def ispresent(faction, region):
    """ Is the faction present in the region? """
    for unit in region.units:
        if unit.faction == faction:
            return True
    return False


def cansee(faction, region, unit):
    """ Can the faction see the unit in the region? """
    if unit.faction == faction:
        return 2

    cansee = 0
    if unit.guard or unit.building or unit.ship:
        return 1

    n = effskill(unit, SK_STEALTH)

    for unit2 in region.units:
        if unit2.faction != faction:
            continue
        
        # BUG: in the original C version, you had to have the exact i
        #      number of RING (ie. = unit.number, not >=)
        if (unit.items[I_RING_OF_INVISIBILITY] and
            unit.items[I_RING_OF_INVISIBILITY] >= unit.number and
            not unit2.items[I_AMULET_OF_TRUE_SEEING]):
               continue

        o = effskill(unit2, SK_OBSERVATION)
        if (o > n):
            return 2
        if (o >= n):
            cansee = 1

    return cansee


### These functions (geti, igetstr, getstr) all rely on evil global variables,
### and it's easier to convert the functions which call them to use something
### more sensible/less bug prone.

def geti():
    """ Get an integer from the user
        UPDATE: actually gets the next integer from buf via getstr..."""
    raise NotImplementedError, "The function you are using should not be calling geti!"
    
def igetstr():
    """ seed the buf global with a string and read the first string out """
    raise NotImplementedError, "The function you are using should not be calling igetstr!"
 
def getstr():
    """ get the next string from the global buf """
    raise NotImplementedError, "The function you are using should not be calling getstr!"


def findfaction(number):
    """ Find the faction with a certain number """
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for faction in factions:
        if faction.no == number:
            return faction
    return 0

def getfaction():
    raise NotImplementedError, "You should use findfaction instead!"


def findregion(x, y):
    """ Find the region with coordinates x,y """
    for region in regions:
        if region.x == x and region.y == y:
            return region
    return 0


def findbuilding(number):
    """ Given the number of a building, return the building """
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for region in regions:
        building = findbuildingregion(number, region)
        if building:
            return building
    return 0

def findbuildingregion(number, region):
    """ Find a building in a particular region """
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for building in region.buildings:
        if building.no == number:
            return building
    return 0

def getbuilding(region):
    """ Get a building, given input from the keyboard (?) """
    raise NotImplementedError, "You should use findbuilding or findbuildingregion instead!"


def findship(number):
    """ Return the ship with a particular number """
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for region in regions:
        for ship in region.ships:
            if ship.no == number:
                return ship
    return 0

def findshipregion(number, region):
    """ Return the ship with a particular number from a region """
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for ship in region.ships:
        if ship.no == number:
            return ship
    return 0

def getship(region):
    """ Find a ship, given a number entered by the user """
    raise NotImplementedError, "You should use findship or findshipregion instead!"

#TODO: make other finding functions check whether their input is an integer
def findunitg(number):
    """ Find a unit by unit number (find unit global?)"""
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)
    for region in regions:
        for unit in region.units:
            if unit.no == number:
                return unit
    return 0

def getnewunit(region, unit, number):
    """ Get a newly created unit, given the unit number in buf
        ie. the unit is referenced as 'new 1'
        
        This function requires an extra variable, 'number', 
        in order to work effectively. The previous C version 
        just pulled it from a global"""
    
    if type(number) == type("") and not number.isdigit:
        return 0
    number = int(number)

    for unit2 in region.units:
        if unit2.faction == unit.faction and unit2.alias == number:
            return unit2
    return 0

def getunitg(region, unit):
    """ Get a unit from the region, given it's alias in buf"""
    raise NotImplementedError, "You should use findunitg, getunit or getnewunit instead!"

# TODO: remove these globals - they're used to return multiple values from getunit
getunit0 = 0
getunitpeasants = 0

def getunit(region, unit, unitNumber):
    """ Get a unit, given it's number, provided that the unit given can see it"""
    global getunitpeasants
    global getunit0

    getunit0 = 0
    getunitpeasants = 0
    
    if unitNumber.startswith("new "):
        # updated getnewunit, since raw_input() has eaten the input... :(
        # getnewunit now has an optional string input?
        return getnewunit(region, unit, unitNumber[4:])

    if region.terrain != T_OCEAN and unitNumber.startswith("peasants"):
        #getunitpeasants = 1
        #return 0
        return "peasants"

    n = atoi(unitNumber)
    if n == 0:
        #getunit0 = 1
        #return 0
        return "no unit"

    for unit2 in region.units:
        if unit2.no == n and cansee(unit.faction, region, unit2) and not unit2.isnew:
            return unit2

    return 0


def findkeyword(string):
    """ Find a keyword in a string, 
        returning the index of the keyword in keywords """
    string = string.lower()
    if string == "":
        return -1

    if string == "describe":
        return K_DISPLAY
    if string == "n":
        return K_NORTH
    if string == "s":
        return K_SOUTH
    if string == "e":
        return K_EAST
    if string == "w":
        return K_WEST
    
    if string.split()[0] not in keywords:
        return -1
    return keywords.index(string.split()[0])

def igetkeyword(string):
    """ Return the integer representation of the string? """
    raise NotImplementedError, "You should use findkeyword instead!"

def getkeyword(string):
    """ Is the next word in buf a keyword? """
    raise NotImplementedError, "You should use findkeyword instead!"


def findstr(string1, string2, n):
    try:
        pos = string1.index(string2)
        if pos > n:
            return -1
    except:
        return -1


def findskill(string):
    if string.startswith("horse"):
        return skillnames.index("horse training")
    if string.startswith("entertain"):
        return skillnames.index("entertainment")
    
    if string in skillnames:
        return skillnames.index(string)
    return -1

def getskill():
    """ Find the skill from the next word in buf """
    raise NotImplementedError("You should use findskill instead!")


def finditem(string):
    if string.startswith("chain"):
        return I_CHAIN_MAIL
    if string.startswith("plate"):
        return I_PLATE_ARMOR

    i = findstr(itemnames[0], string, MAXITEMS)
    if (i >= 0):
        return i

    return findstr(itemnames[1], string, MAXITEMS)

def getitem():
    """ Find the item from the next word in buf """
    raise NotImplementedError("You should use finditem instead!")


def findspell(string):
    return findstr(spellnames, string, MAXSPELLS)

def getspell():
    """ Find the spell from the next word in buf """
    raise NotImplementedError("You should use findspell instead!")


def createunit(region):
    """ Create a new unit? """
    unit = Unit()
    unit.lastorder = "work"
    unit.combatspell = -1
    
    # TODO: not sure what the hell the C version is up to...
    # LATER: it's creating players from the players.in file...?
    #        players file is read in a different function
    #        1000 chars per unit?
    # UPDATE: I'm pretty sure now that it's just looking for 
    #         a free unit number
    n = 0
    v = [0] * 1000
    while 1:
        if n == 0:
            v[0] = 1

        for region2 in regions:
            for unit2 in region2.units:
                if unit2.no >= n and unit2.no < n + 1000:
                    v[unit2.no - n] = 1
        
        for i in range(1000):
            if v[i] == 0:
                unit.no = n + i
                unit.name = "Unit %s" % unit.no
                region.units.append(unit)
                return unit
        
        n += 1000
        v = [0] * 1000


def inputregion():
    """ Interrogate the GM to get a region """
    while 1:
        x = raw_input("X? ")
        if not x.isdigit():
            return 0
        x = atoi(x)
        
        y = raw_input("Y? ")
        if not y.isdigit():
            return 0
        y = atoi(y)

        region = findregion(x,y)
        if not region:
            print "No such region."
            return None
        else:
            return region


def addplayers():
    """ Add new players from a file? """
    region = inputregion()
    if not region:
        return
    
    # The players file is just a list of email addresses... I think ;)
    print "Name of players file?"
    fileName = raw_input()
    
    playersFile = open(fileName, 'r')
    
    for line in playersFile.readlines():
        faction = Faction()
        faction.addr = line.strip()
        faction.lastorders = turn
        faction.alive = True
        
        # f->no++ : increment the faction number.
        # C reuses the old f number from last go around the loop!
        # TODO: we need a function which returns the max faction number
        # ...easy (I think):
        if len(factions) == 0:
            faction.no = 1
        else:
            faction.no = factions[-1].no + 1

        faction.name = "Faction %s" % faction.no

        factions.append(faction)
        
        unit = createunit(region)
        unit.number = 1
        unit.money = STARTMONEY
        unit.faction = faction
        unit.isnew = True
        
        print "Added player '%s'" % faction.addr


def randomregion():
    """ HACK: return a random non-ocean region """
    regioncopy = regions[:]
    while regioncopy:
        region = random.choice(regioncopy)
        if region.terrain != T_OCEAN:
            return region
        else:
            regioncopy.remove(region)

def addplayer(name, addr, password):
    """ Create a player """
    region = randomregion()
    if not region:
        raise ValueError("No non-ocean regions to put a faction in!")

    faction = Faction()
    faction.name = name
    faction.addr = addr.strip()
    faction.password = password
    faction.lastorders = turn
    faction.alive = True
    if len(factions) == 0:
        faction.no = 1
    else:
        # TODO: this assumes that factions are sorted by number...
        faction.no = factions[-1].no + 1

    factions.append(faction)
    
    unit = createunit(region)
    unit.number = 1
    unit.money = STARTMONEY
    unit.faction = faction
    unit.isnew = True
    
    print "Added player '%s'" % faction.addr


    
def connecttothis(region, x, y, fromRegion, toRegion):
    """ Define a neighbor for a region """
    # from and to are integers from 0..3
    region2 = findregion(x,y)
    if region2:
        region.connect[fromRegion] = region2
        region2.connect[toRegion] = region

def connectregions():
    """ Connect up all the regions? """
    for region in regions:
        if not region.connect[0]:
            connecttothis(region, region.x, region.y-1, 0, 1)
        if not region.connect[1]:
            connecttothis(region, region.x, region.y+1, 1, 0)
        if not region.connect[2]:
            connecttothis(region, region.x+1, region.y, 2, 3)
        if not region.connect[3]:
            connecttothis(region, region.x-1, region.y, 3, 2)


#char newblock[BLOCKSIZE][BLOCKSIZE];
# TODO: transmute is dodgy -- I have no idea what it does...
# UPDATE: I think it spreads region types around, 
# eg. start with one plain and smear it across the block
newblock = [[0 for item in range(BLOCKSIZE)] for item2 in range(BLOCKSIZE)]

# TODO: this is buggy -- it shouldn't put anything but ocean on the borders
# UPDATE: it wasn't checking whether the region was already there, so if
# you did two transmutes in the same location, it would double up, and you'd
# get what appeared to be an extra-wide continent
def transmute(fromRegion, toRegion, n, count):
    """ Change some of the regions in newblock from fromRegion to toRegion """
    global newblock
    while 1:
        i = 0

        while 1:
            x = rnd() % BLOCKSIZE
            y = rnd() % BLOCKSIZE
            i += count
            
            here = newblock[x][y] == fromRegion
            west = (x != 0 and newblock[x - 1][y] == toRegion)
            east = (x != BLOCKSIZE - 1 and newblock[x + 1][y] == toRegion)
            north = (y != 0 and newblock[x][y - 1] == toRegion)
            south = (y != BLOCKSIZE - 1 and newblock[x][y + 1] == toRegion)
            
            if i <= 10 and not (here and (west or east or north or south)):
                
                if 0:
                    print toRegion, fromRegion, "-", 
                    if x != 0: print newblock[x - 1][y], 
                    if x != BLOCKSIZE - 1: print newblock[x + 1][y], 
                    if y != 0: print newblock[x][y - 1],
                    if y != BLOCKSIZE - 1: print newblock[x][y + 1],
                    print
                    print i, "-", x, y, "-", here, "-", west, east, north, south
                
                continue
            

            if i > 10:
                break
            
            newblock[x][y] = toRegion
            #printblock()
            if 0:
                print
                print "newblock[%s][%s] is now %s" % (x, y, newblock[x][y])
                printblock()
                print

        n = n - 1
        if not n:
            break


def seed(to, n):
    global newblock
    while 1:
        x = rnd() % BLOCKSIZE
        y = rnd() % BLOCKSIZE

        if newblock[x][y] == T_PLAIN:
            break

    newblock[x][y] = to
    transmute(T_PLAIN, to, n, 1)

def regionnameinuse(string):
    for region in regions:
        if region.name == string:
            return 1
    return 0

def blockcoord(x):
    """ Map x onto a block border """
    return (x / (BLOCKSIZE + BLOCKBORDER*2)) * (BLOCKSIZE + BLOCKBORDER*2)

def printblock():
    print
    for line in newblock:
        for char in line:
            if char:
                print char,
            else:
                print ".",
        print
    print

def makeblock(x1, y1):
    global newblock
    if x1 < 0:
        while x1 != blockcoord(x1):
            print "x1 is now", x1
            x1 -= 1

    if y1 < 0:
        while y1 != blockcoord(y1):
            print "y1 is now", y1
            y1 -= 1

    #print "x1, y1 are now", x1, y1
    
    x1 = blockcoord(x1)
    y1 = blockcoord(y1)
    
    #print "x1, y1 are", x1, y1, "after blockcoord"
    
    if findregion(x1, y1):
        print "There's already a region with that coordinate!"
        return

    # Regenerate newblock and slap a plains hex in the middle
    newblock = [[0 for item in range(BLOCKSIZE)] for item2 in range(BLOCKSIZE)]
    newblock[BLOCKSIZE/2][BLOCKSIZE/2] = T_PLAIN
    if 0:
        print BLOCKSIZE/2, T_PLAIN, newblock[BLOCKSIZE/2], newblock[BLOCKSIZE/2][BLOCKSIZE/2]
        printblock()
    
    transmute (T_OCEAN, T_PLAIN, 31, 1)
    seed (T_MOUNTAIN,1);
    seed (T_MOUNTAIN,1);
    seed (T_FOREST,1);
    seed (T_FOREST,1);
    seed (T_SWAMP,1);
    seed (T_SWAMP,1);
    if 0:
        printblock()

    for x in range(BLOCKSIZE + BLOCKBORDER*2):
        for y in range(BLOCKSIZE + BLOCKBORDER*2):
            region = Region()
            region.x = x1 + x
            region.y = y1 + y

            if (x >= BLOCKBORDER and x < BLOCKBORDER + BLOCKSIZE and
                y >= BLOCKBORDER and y < BLOCKBORDER + BLOCKSIZE):
                region.terrain = newblock[x - BLOCKBORDER][y - BLOCKBORDER]
                if region.terrain != T_OCEAN:
                    n = 0
                    for region2 in regions:
                        if region2.name:
                            n += 1
                    
                    i = rnd() % len(regionnames)
                    if n < len(regionnames):
                        while regionnameinuse(regionnames[i]):
                            i = rnd() % len(regionnames)

                    region.name = regionnames[i]
                    # TODO: will the C / operator cast to float or int?
                    region.peasants = maxfoodoutput[region.terrain] / 50

            regions.append(region)

    connectregions()


def gamedate():
    monthnames = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    if turn == 0:
        return "In the Beginning"
    else:
        return "%s, Year %d" % (monthnames[(turn-1)%12], ((turn-1)/12)+1)
    
    
def factionid(faction):
    return "%s (%d)" % (faction.name, faction.no)
    
def regionid(region):
    if region.terrain == T_OCEAN:
        return "(%d,%d)" % (region.x, region.y)
    else:
        return "%s (%d,%d)" % (region.name, region.x, region.y)

def buildingid(building):
    return "%s (%d)" % (building.name, building.no)

def shipid(ship):
    return "%s (%d)" % (ship.name, ship.no)

def unitid(unit):
    return "%s (%d)" % (unit.name, unit.no)


def spskill(unit, i, days):
    """ return a printed representation of one of a unit's skills """
    if not unit.skills[i]:
        return ""
    output = "%s %d" % (skillnames[i], effskill(unit,i))
    if days:
        output += " [%s]" % (unit.skills[i]/unit.number)
    return output

def unitReport(faction, region, unit, indent, battle):
    """ return a printed representation of a unit """
    output = unitid(unit)

    if cansee(faction, region, unit) == 2:
        output += ", faction %s" % factionid(unit.faction)

    if unit.number != 1:
        output += ", number: %d" % unit.number
    
    if unit.behind and (unit.faction == faction or battle):
        output += ", behind"

    if unit.guard:
        output += ", on guard"

    if unit.faction == faction and not battle and unit.money:
        output += ", $%s" % unit.money
    
    if battle:
        battleSkills = []
        for i in range(SK_TACTICS, SK_LONGBOW+1):
            if unit.skills[i]:
                battleSkills.append(spskill(unit, i, True))
        if battleSkills:
            output += ", skills: %s" % (", ".join(battleSkills))

    elif unit.faction == faction:
        normalSkills = []
        for i in range(MAXSKILLS):
            if unit.skills[i]:
                normalSkills.append(spskill(unit, i, True))
        if normalSkills:
            output += ", skills: %s" % (", ".join(normalSkills))

    for i in range(MAXITEMS):
        itemList = []
        if unit.items[i]:
            if unit.items[i] == 1:
                itemList.append(itemnames[0][i])
            else:
                itemList.append("%d %s" % (unit.items[i], itemnames[1][i]))
        if itemList:
            output += ", items: %s" % (", ".join(itemList))
    
    if unit.faction == faction:
        spellList = []
        for i in range(MAXSPELLS):
            if unit.spells[i]:
                spellList.append(spellnames[i])
        if spellList:
            output += ", spells: %s" % (", ".join(spellList))
        
        if not battle:
            output += ", default: '%s'" % unit.lastorder

        if unit.combatspell >= 0:
            output += ", combat spell: %s" % spellnames[unit.combatspell]

    if unit.display:
        output += "; %s" % unit.display
    
    if output[-1] not in ["!", "?"]:
        output += ".\n"
    
    bullet = ['-', '*'][(unit.faction == faction)]
    return wrap(output, indent, 80-indent, bullet)


def mistake(faction, string, comment):
    mistakestring = "%s: %s." % (string, comment)
    faction.mistakes.append(mistakestring)

def mistake2(unit, string, comment):
    mistakestring = "unit %s: '%s' %s" % (unit.no, string, comment)
    unit.faction.mistakes.append(mistakestring)

def mistakeu(unit, comment):
    mistakestring = "unit %s: %s" % (unit.no, comment)
    unit.faction.mistakes.append(mistakestring)

def addevent(faction, string):
    #sparagraph(faction.events, string, 0, 0)
    faction.events.append(string)

def addbattle(faction, string):
    #sparagraph(faction.battles, s, 0, 0)
    faction.battles.append(string)

def reportevent(region, string):
    for faction in factions:
        for unit in region.units:
            if unit.faction == faction and unit.number:
                addevent(faction, string)
                break


def leave(region, unit):
    """ The unit wants to leave the boat/building """
    
    if unit.building:
        building = unit.building
        unit.building = None

        if unit.owner:
            unit.owner = 0
            for unit2 in region.units:
                if unit2.faction == unit.faction and unit2.building == building:
                    unit2.owner = 1
                    return
            for unit2 in region.units:
                if unit2.building == building:
                    unit2.owner = 1
                    return

    if unit.ship:
        ship = unit.ship
        unit.ship = None

        if unit.owner:
            unit.owner = 0
            for unit2 in region.units:
                if unit2.faction == unit.faction and unit2.ship == ship:
                    unit2.owner = 1
                    return
            for unit2 in region.units:
                if unit2.ship == ship:
                    unit2.owner = 1
                    return
            
def removeempty():
    """ Remove empty units and ships """
    for region in regions:

        # Remove empty units
        for unit in region.units:
            if not unit.number:
                leave(region, unit)
                for unit2 in region.units:
                    if unit2 == unit:
                        continue
                    if unit2.faction == unit.faction:
                        unit2.money += unit.money
                        unit.money = 0
                        for i in range(MAXITEMS):
                            unit2.items[i] += unit.items[i]
                        break
                    if region.terrain != T_OCEAN:
                        region.money += unit.money
                region.units.remove(unit)
        
        if region.terrain == T_OCEAN:
            for ship in region.ships:
                for unit in region.units:
                    if unit.ship == ship:
                        break

                if not unit:
                    region.ships.remove(ship)


def destroyfaction(faction):
    """ Remove a faction and all of its units from the game """

    for region in regions:
        for unit in region.units:
            if unit.faction == faction:
                if region.terrain != T_OCEAN:
                    region.peasants += unit.number
                unit.number = 0
    faction.alive = 0

# TODO: not sure I've got this one right...
def togglerf(unit, faction, factionList):
    """ Toggle faction's attitude to the faction which is in rfactions (? - not sure I've got this one right...) """
    if type(faction) == str:
        faction = findfaction(faction)
    if not faction:
        mistake2(unit, "Faction %s not found." % faction)

    if faction != unit.faction:
        for rf in factionList:
            if rf.faction == faction:
                break
        if rf:
            factionList.remove(rf)
        else:
            factionList.append(rf)


def iscoast(region):
    """ Is a region on the coast? """
    for i in range(4):
        if region.connect[i].terrain == T_OCEAN:
            return 1
    return 0

def distribute(old, new, n):
    """ Used to distribute money/skills from spoils amongst the victors """
    assert new <= old

    if old == 0:
        return 0

    t = (n / old) * new
    for i in range(n % old):
        if rnd() % old < new:
            t += 1
    return t

def armedmen(unit):
    """ How many armed men does the unit have? """
    n = 0
    if effskill(unit, SK_SWORD):
        n += unit.items[I_SWORD]
    if effskill(unit, SK_CROSSBOW):
        n += unit.items[I_CROSSBOW]
    if effskill(unit, SK_LONGBOW):
        n += unit.items[I_LONGBOW]
    return min(n, unit.number)

def getmoney(region, unit, n):
    """ Pull money from other units -- used for upkeep """
    n -= unit.money
    for unit2 in region.units:
        if n < 0:
            break
        if unit2.faction == unit.faction and unit2 != unit:
            i = min(unit2.money,n)
            unit2.money -= i
            unit.money += i
            n -= i


### TODO: evil, evil, evil - if you declare a list here, functions can access
###       it as if it were a global, but without declaring globals everywhere.
###       This is purely to match the behaviour of the C version, and in no 
###       way indicative of the 'right' way to do it. At some point, combat
###       will get a good refactoring...

troops = [] # was 'ta'
attacker = None
defender = None
initial = [0,0]
left = [0,0]
infront = [0,0]
toattack = [0,0]
shields = [0,0]
runeswords = [0,0]

def doshot(troops):
    ##TODO: evil global variables here, and functions which rely on them
    ##      we need some sort of Battle class which we can pass around,
    ##      or which encapsulates all of the battle stuff...
    ##      shields, infront, docombatspell, terminate

    # select attacker
    attackingTroops = [t for t in troops if not t.attacked]
    if not attackingTroops:
        return
    attacker = random.choice(attackingTroops)
    
    # housekeeping
    attacker.attacked = 1
    toattack[attacker.side] -= 1
    defender.side = 1 - attacker.side
    attacker.dazzled = 0
    if attacker.unit:
        if (attacker.behind and
            infront[attacker.side] and
            not attacker.missile):
            return
        if attacker.shieldstone:
            shields[attacker.side] += 1 + attacker.power
        if attacker.unit.combatspell >= 0:
            docombatspell(attacker)
            return
        if attacker.reload:
            attacker.reload -= 1
            return
        if attacker.weapon == I_CROSSBOW:
            attacker.reload = 2

    # Select defender
    defender = selecttarget()
    assert defender.side == 1 - attacker.side

    # attack!
    if hits():
        terminate(defender)
    
def selecttarget():
    targets = [t for t in troops if validtarget(t)]
    if not targets:
        return 
    return random.choice(targets)

def validtarget(troop):
    isBehind = troop.behind and infront[defender.side]
    return (not troop.status and
            troop.side == defender.side and
            not isBehind)

def terminate(troop):
    if not troop.attacked:
        troop.attacked = 1
        toattack[defender.side] -= 1
    troop.status = 1
    left[defender.side] -= 1
    if infront[defender.side]:
        infront[defender.side] -= 1
    if troop.runesword:
        runeswords[defender.side] -= 1

def maketroops(unit, terrain):
    skills = [0] * MAXSKILLS
    items = [0] * MAXITEMS
    for i in range(MAXSKILLS):
        skills[i] = effskill(unit, i)
    
    left[unit.side] += unit.number
    if not unit.behind:
        infront[unit.side] += unit.number
    
    for i in range(unit.number):
        t = Troop()
        t.unit = unit
        t.side = unit.side
        t.skill = -2
        t.behind = unit.behind

        if unit.combatspell >= 0:
            t.missile = 1

        elif items[I_RUNESWORD] and skills[SK_SWORD]:
            t.weapon = I_SWORD
            t.skill = skills[SK_SWORD] + 2
            t.runesword = 1
            items[I_RUNESWORD] -= 1
            runeswords[unit.side] += 1

            if items[I_HORSE] and skills[SK_RIDING] >= 2 and terrain == T_PLAIN:
                t.skill += 2;
                items[I_HORSE] -= 1

        elif items[I_LONGBOW] and skills[SK_LONGBOW]:
            t.weapon = I_LONGBOW
            t.missile = 1
            t.skill = skills[SK_LONGBOW]
            items[I_LONGBOW] -= 1

        elif items[I_CROSSBOW] and skills[SK_CROSSBOW]:
            t.weapon = I_CROSSBOW
            t.missile = 1
            t.skill = skills[SK_CROSSBOW]
            items[I_CROSSBOW] -= 1

        elif items[I_SWORD] and skills[SK_SWORD]:
            t.weapon = I_SWORD
            t.skill = skills[SK_SWORD]
            items[I_SWORD] -= 1
            if items[I_HORSE] and skills[SK_RIDING] >= 2 and terrain == T_PLAIN:
                t.skill += 2
                items[I_HORSE] -= 1

        if unit.spells[SP_HEAL] or items[I_AMULET_OF_HEALING] > 0:
            t.canheal = 1
            items[I_AMULET_OF_HEALING] -= 1

        if items[I_RING_OF_POWER]:
            t.power = 1
            items[I_RING_OF_POWER] -= 1

        if items[I_SHIELDSTONE]:
            t.shieldstone = 1
            items[I_SHIELDSTONE] -= 1

        if items[I_CLOAK_OF_INVULNERABILITY]:
            t.invulnerable = 1
            items[I_CLOAK_OF_INVULNERABILITY] -= 1
        elif items[I_PLATE_ARMOR]:
            t.armor = 2
            items[I_PLATE_ARMOR] -= 1
        elif items[I_CHAIN_MAIL]:
            t.armor = 1
            items[I_CHAIN_MAIL] -= 1

        if unit.building and unit.building.sizeleft:
            t.inside = 2
            unit.building.sizeleft -= 1

        troops.append(t)

def battlerecord(eventString):
    for faction in factions:
        if faction.seesbattle:
            faction.battles.append(eventString)

def battlepunit(region, unit):
    for faction in factions:
        if faction.seesbattle:
            faction.battles += unitReport(faction, region, unit, 4, 1)

def contest(a, d):
    table = [10, 25, 40]
    i = a - d + 1
    if i < 0:
        return rnd() % 100 < 1
    if i < 2:
        return rnd() % 100 < 49
    return rnd() % 100 < table[i]

def hits():
    if defender.weapon == I_CROSSBOW or defender.weapon == I_LONGBOW:
        defender.skill = -2
    defender.skill += defender.inside
    attacker.skill -= (attacker.demoralized + attacker.dazzled)
    defender.skill -= (defender.demoralized + defender.dazzled)

    if attacker.weapon == I_SWORD or attacker.weapon == 0:
        k = contest(attacker.skill, defender.skill)
    elif attacker.weapon == I_CROSSBOW:
        k = contest(attacker.skill, 0)
    elif attacker.weapon == I_LONGBOW:
        k = contest(attacker.skill, 2)

    if defender.invulnerable and rnd() % 10000:
        k = 0
    if rnd() % 3 < defender.armor:
        k = 0

    return k

def canbedemoralized(troop):
    return validtarget(troop) and not troop.demoralized

def canbedazzled(troop):
    return validtarget(troop) and not troop.dazzled

def canberemoralized(troop):
    return (not troop.status and
            troop.side == attacker.side and 
            troop.demoralized)

def dozap(n):
    n = lovar(n * (1 + attacker.power))
    n = min(n, left[defender.side])
    for i in range(n):
        terminate(selecttarget())
    eventString = ", inflicting %d %s" % (n, ["casualties", "casualty"][n == 1])
    return eventString

def docombatspell(troop):
    
    z = troop.unit.combatspell
    eventString = "%s casts %s" % (unitid(troop.unit), spellnames[z])

    if shields[defender.side]:
        if rnd() % 1:
            eventString += ", and gets through the shield"
            shields[defender.side] -= 1 + attacker.power
        else:
            eventString += ", but the spell is deflected by the shield!"
            battlerecord(eventString)
            return

    if z == SP_BLACK_WIND:
        eventString += dozap(1250)

    elif z == SP_CAUSE_FEAR:
        if runeswords[defender.side] and (rnd() % 1):
            pass
        else:
            n = lovar(50 * (1 + attacker.power))
            happyTroops = [t for t in troops if canbedemoralized(t)]
            n = min(n,len(happyTroops))
            eventString += ", affecting %d %s" % (n, ["people", "person"][n == 1])
            random.shuffle(happyTroops)
            for troop in happyTroops[:n]:
                troop.demoralized = 1

    elif z == SP_DAZZLING_LIGHT:
        n = lovar(50 * (1 + attacker.power))
        undazzledTroops = [t for t in troops if canbedazzled(t)]
        n = min(n,len(undazzledTroops))
        eventString += ", dazzling %d %s" % (n, ["people", "person"][n == 1])
        random.shuffle(undazzledTroops)
        for troop in undazzledTroops[:n]:
            troop.dazzled = 1

    elif z == SP_FIREBALL:
        eventString += dozap(50)

    elif z == SP_HAND_OF_DEATH:
        eventString += dozap(250)

    elif z == SP_INSPIRE_COURAGE:
        n = lovar(100 * (1 + attacker.power))
        unhappyTroops = [t for t in troops if canberemoralized(t)]
        n = min(n, len(unhappyTroops))
        eventString += ", affecting %d %s" % (n, ["people", "person"][n == 1])
        random.shuffle(undazzledTroops)
        for troop in undazzledTroops[:n]:
            troop.demoralized = 0
    
    elif z == SP_LIGHTNING_BOLT:
        eventString += dozap(10)

    elif z == SP_SHIELD:
        shields[attacker.side] += 1 + attacker.power

    elif z == SP_SUNFIRE:
        eventString += dozap(6250)

    else:
        raise ValueError("Unknown spell number %s" % z)

    battlerecord(eventString + "!")

        
def lovar(n):
    n /= 2
    return (rnd() % n + 1) + (rnd() % n + 1)

def isallied (unit, unit2):
    """ Has unit's faction declared unit2's faction as ally? """
    if not unit2:
        return unit.guard
    if unit.faction == unit2.faction:
        return 1
    for rf in unit.faction.allies:
        if rf.faction == unit2.faction:
            return 1
    return 0

def accepts (unit, unit2):
    """ Will unit accept goodies from unit2? """
    if isallied(unit, unit2):
        return 1
    for rf in unit.faction.accept:
        if rf.faction == unit2.faction:
            return 1
    return 0

def admits(unit, unit2):
    """ Will unit let unit2 into the building/ship? """
    if isallied(unit, unit2):
        return 1
    for rf in unit.faction.admit:
        if rf.faction == unit2.faction:
            return 1
    return 0

def buildingowner(region, building):
    for unit in region.units:
        if unit.building == building and unit.owner:
            return unit
    return 0

def shipowner(region, ship):
    for unit in region.units:
        if unit.ship == ship and unit.owner:
            return unit
    return 0

def mayenter(region, unit, building):
    unit2 = buildingowner(region, building)
    return unit2 == 0 or admits(unit2, unit)

def mayboard(region, unit, ship):
    unit2 = shipowner(region, ship)
    return unit2 == 0 or admits(unit2, unit)

def isHashLine(line):
    return line.lstrip().startswith('#')

def readorders():
    """ Fuck it, I'll do this the new fangled way...
        It's a rough translation, but I'm ignoring a lot of the C silliness"""
    
    for faction in factions:
        # Clear out old orders
        for region in regions:
            for unit in region.units:
                if unit.faction == faction:
                    unit.orders = []

        # Read in new ones...
        fileName = "orders.%s"%faction.no
        if not os.access(fileName, os.F_OK) == 1:
            print "Can't find orders for %s!" % factionid(faction)
            continue
        orderFile = open("orders.%s"%faction.no, "r")
        
        # chop out the bits between #atlantis... and #end (inclusive)
        orders = [line.strip() for line in orderFile.readlines()]
        orders = [chunk for chunk in splitList(orders, isHashLine) if chunk and isHashLine(chunk[0])]
        if not orders:
            # #atl or #end not in file!
            faction.mistakes.append("You missed an #atlantis line in your orders!") 
            continue
        # chop out the #atlantis line (for now)
        orders = orders[0][1:]
        #print "orders for faction %s are:" % faction.no
        #print orders

        # slap the orders into the units
        unit = None
        for line in orders:
            #print "checking line", line

            if line.lstrip().lower().startswith("unit"):
                unitnum = line.split()[1]
                #print "unitnum is", unitnum
                if unitnum.isdigit():
                    unit = findunitg(unitnum)
                else:
                    unit = None
                    continue
                if unit and unit.faction == faction:
                    unit.lastorders = turn
                else:
                    faction.mistakes.append("Unit %s is not one of your units." % unitnum) 
                continue
            
            if unit and line != "":
                # TODO: not sure what all of the "_" shenanigans are in the C version...
                # TODO: perhaps parsing timber_yard type buildings?
                unit.orders.append(line)
                #print "unit %s orders are now: %s" % (unit.no, unit.orders)
                #for orderLine in unit.orders:
                #    print "%s -- %s" % (orderLine, findkeyword(orderLine))
        
        #if unit:
        #    print "Old unit is: ", unitid(unit)
        #    print "Orders are:", unit.orders
        #else:
        #    print "Unit is None!"

        del unitnum
        unit = None


def writemap(fileObject):
    """ Write the map out to a file? """    
    minx = sys.maxint
    maxx = -sys.maxint
    miny = sys.maxint
    maxy = -sys.maxint
    
    for r in regions:
        minx = min(minx, r.x)
        maxx = max(maxx, r.x)
        miny = min(miny, r.y)
        maxy = max(maxy, r.y)
    
    # TODO: this might be fairly efficient in C, but it's going to suck in Python
    for y in range(miny, maxy+1):
        for x in range(minx, maxx+1):
            r = findregion(x, y)
            if r:
                fileObject.write(" %s" % r.terrain)
            else:
                fileObject.write(" ?")
        fileObject.write("\n")


def writesummary():
    """ Print stuff about the game (or write it into F) """
    summaryFile = open("summary", "w")
    print "Writing summary file..."

    inhabitedregions = 0;
    peasants = 0;
    peasantmoney = 0;
    nunits = 0;
    playerpop = 0;
    playermoney = 0;
    
    for r in regions:
        if r.peasants or r.units:
            inhabitedregions += 1
            peasants += r.peasants
            peasantmoney += r.money

            for u in r.units:
                nunits += 1
                playerpop += u.number
                playermoney += u.money

                u.faction.nunits += 1
                u.faction.number += u.number
                u.faction.money += u.money

    summaryFile.write("Summary file for Atlantis, %s\n\n" % gamedate())
    summaryFile.write("Regions:            %d\n" % len(regions))
    summaryFile.write("Inhabited Regions:  %d\n\n" % inhabitedregions)
    summaryFile.write("Factions:           %d\n" % len(factions))
    summaryFile.write("Units:              %d\n\n" % nunits)
    summaryFile.write("Player Population:  %d\n" % playerpop)
    summaryFile.write("Peasants:           %d\n" % peasants)
    summaryFile.write("Total Population:   %d\n\n" % (playerpop + peasants))
    summaryFile.write("Player Wealth:      $%d\n" % playermoney)
    summaryFile.write("Peasant Wealth:     $%d\n" % peasantmoney)
    summaryFile.write("Total Wealth:       $%d\n\n" % (playermoney + peasantmoney))
    
    writemap(summaryFile)

    if factions:
        summaryFile.write('\n')

    for f in factions:
        summaryFile.write("%s, units: %d, number: %d, $%d, address: %s\n" % 
                            (factionid(f), f.nunits,f.number,f.money,f.addr))

    summaryFile.close()


def wrap(string, indent=2, width=80, bullet="*"):
    bits = string.split()
    output = []
    
    if indent == 0:
        line = bits[0]
    elif indent == 1:
        line = bullet + bits[0]
    else:
        line = (bullet+" ").rjust(indent) + bits[0]
    
    for bit in bits[1:]:
        if len(line) + len(bit) + 1 >= width:
            output.append(line)
            line = " "*indent + bit
        else:
            line = "%s %s" % (line, bit)
    output.append(line)
    return '\n'.join(output) + "\n"

def centre(string, width=80):
    lines = wrap(string, indent=0, width=width, bullet="").rstrip().split("\n")
    return '\n'.join( [line.center(width) for line in lines] ) + "\n"

def sparagraph(strlist, s, indent, mark):
    """ Break a string into a paragraph with \n's and store it in the evil buf global.
        Optionally indent it and stick a 'mark' at the front (ie. |  * Unit (123), ...)"""
    raise NotImplementedError("sparagraph is broken - your function should be returning a string instead")


def regionReport(region):
    regionReport = "%s (%s,%s) in %s" % (terrainnames[region.terrain], region.x, region.y, region.name)
    if region.peasants:
        regionReport += ", %d peasants (peasants)" % region.peasants
        if region.money:
            regionReport += ", $%d" % region.money
    regionReport += "."
    
    output = wrap(regionReport, 0, 80, "").split("\n")[:-1]
    output.append( '-' * min(len(regionReport), 80) )
    
    # Information about the region...
    output.append("  The weather was clear last month; it will be clear next month.")
    if region.peasants:
        output.append("  Wages: $%s, (Max: $%s)." % (foodproductivity[region.terrain], maxfoodoutput[region.terrain]) )
        output.append("  Wanted: none.")
        output.append("  For Sale: %d peasants at $%s." % (region.peasants/RECRUITFRACTION, RECRUITCOST) )
        output.append("  Entertainment available: $%d." % (region.peasants/ENTERTAINFRACTION))
    else:
        output.append("  Wages: none.")
        output.append("  Wanted: none.")
        output.append("  For Sale: none.")
        output.append("  Entertainment available: none.")
    
    products = []
    for itemnum in range(I_HORSE):
        if productivity[region.terrain][itemnum]:
            products.append("%d %s" % (maxoutput[region.terrain][itemnum], itemnames[1][itemnum]) )
    if products:
        output.append("  Products: %s." % ", ".join(products))
    else:
        output.append("  Products: none.")
        
    # Neighbors
    directions = ['North', 'South', 'East', 'West']
    neighbors = [(directions[dir], region.connect[dir]) for dir in range(4) if region.connect[dir]]
    if neighbors:
        output.append("")
        output.append("Neighbors:")
        for direction, neighbor in neighbors:
            output.append("  %s: %s (%s,%s) in %s." % (direction, terrainnames[neighbor.terrain], neighbor.x, neighbor.y, region.name) )
        output.append("")
    return output

def factionTemplate(faction):
    output = ["Order Template:\n", "#atlantis %s \"%s\"" % (faction.no, faction.password), ""]
    for region in regions:
        ourUnits = [u for u in region.units if u.faction == faction]
        if ourUnits:
            output.append("; *** %s ***" % regionid(region))
            for unit in ourUnits:
                output.append("unit %s\n%s\n" % (unit.no, unit.thisorder or 'work'))
    output.append("#end")
    return output
    
def report(faction):
    """
    Write out the report for faction
    """
    reportFile = open("report.%d" % faction.no, "w")

    print "Writing report for %s..." % factionid (faction)
    
    reportFile.write( "Atlantis Turn Report\n" )
    reportFile.write( factionid(faction) + "\n" )
    reportFile.write( gamedate() + "\n" )

    if faction.mistakes:
        reportFile.write("\n")
        reportFile.write( "Errors during turn:\n" )
        reportFile.write( "".join( [wrap(line, 2, 80, "") for line in faction.mistakes] ) )

    if faction.messages:
        reportFile.write("\n")
        reportFile.write( "Messages during turn:\n" )
        reportFile.write( "".join( [wrap(line, 2, 80, "") for line in faction.messages] ) )
        
    if faction.battles:
        reportFile.write("\n")
        reportFile.write( centre("Battles during turn\n") )
        reportFile.write("\n")
        for battle in faction.battles:
            reportFile.write(battle)
            reportFile.write("\n")

    if faction.events:
        reportFile.write("\n")
        reportFile.write("Events during turn:\n")
        reportFile.write( "".join( [wrap(line, 2, 80, "") for line in faction.events] ) )
    
    Title = False
    for i in range(MAXSPELLS):
        if faction.showdata[i]:
            if not Title:
                reportFile.write("\n")
                reportFile.write( centre("Spells acquired:") )
            
            reportFile.write("\n")
            reportFile.write( centre(spellnames[i]) )
            reportFile.write( centre("Level %d" % spelllevel[i]) )
            reportFile.write("\n")
            reportFile.write( wrap(spelldata[i], 0, 80, "") )
    
    reportFile.write("\n")
    reportFile.write("Current Status:\n")
    reportFile.write("\n")
    
    if faction.allies:
        reportFile.write("\n")
        allyString = ', '.join( [factionid(f) for f in faction.allies] )
        output = "You are allied to %s." % allyString
        reportFile.write( wrap(output, 0, 80, "") )
    
    anyunits = False
    for region in regions:
        factionUnits = [u for u in region.units if u.faction == faction]
        if not factionUnits:
            continue
        anyunits = True
        
        reportFile.write( "\n".join( regionReport(region) ) )

        for building in region.buildings:
            reportFile.write("\n")
            
            buildingReport = "%s, size %d" % (buildingid(building), building.size)
            if building.display:
                buildingreport += "; %s" % building.display
            buildingReport += "."
            reportFile.write( wrap(buildingReport, 4, 80, "") )
            
            for unit in region.units:
                if unit.building == building and unit.owner:
                    reportFile.write( unitReport(faction, region, unit, 8, False) )
                    break

            for unit in region.units:
                if unit.building == building and not unit.owner:
                    reportFile.write( unitReport(faction, region, unit, 8, False) )
            
        for ship in region.ships:
            reportFile.write("\n")
            shipReport = "%s, %s" % (shipid(ship), shiptypenames[ship.type])
            if ship.left:
                shipReport += ", under construction"
            if ship.display:
                shipReport += "; %s" % ship.display
            shipReport += "."
            reportFile.write( wrap(buildingReport, 4, 80, "") )

            for unit in region.units:
                if unit.ship == ship and unit.owner:
                    reportFile.write( unitReport(faction, region, unit, 8, False) )
                    break

            for unit in region.units:
                if unit.ship == ship and not unit.owner:
                    reportFile.write( unitReport(faction, region, unit, 8, False) )
        
        regionUnits = [unit for unit in region.units \
                           if not unit.building and not unit.ship \
                           and cansee(faction, region, unit)]
        if regionUnits:
            reportFile.write("\n")
        for unit in regionUnits:
            reportFile.write( unitReport(faction, region, unit, 2, False) )
    
        reportFile.write("\n\n")
    
    reportFile.write("\n".join( factionTemplate(faction) ))

    if not anyunits:
        reportFile.write( wrap("Unfortunately your faction has been wiped out. Please "
                               "contact the moderator if you wish to play again.",
                               0, 80) )

    reportFile.close()


def reports():
    """ Generate reports for players """
    for faction in factions:
        report(faction)
    
    
def reportsold():
    """ Generate reports for players """

    # TODO: make this less destructive...
    # will be done when converting to the new Atlantis' interface
    if os.access("reports", os.F_OK):
        os.removedirs("reports")
    if os.access("nreports", os.F_OK):
        os.removedirs("nreports")
    os.mkdir("reports")
    os.mkdir("nreports")
    
    for faction in factions:
        report(faction)

    sendfile = open("send", "w")
    print "Writing send file..."
    for faction in factions:
        if faction.addr.lower != "n/a":
            sendfile.write("mail %d.r\n" % faction.no)
            sendfile.write("in '%s'\n" % faction.addr)
            sendfile.write("Atlantis Report for %s\n" % gamedate())
    sendfile.close()
    
    mailfile = open("maillist", "w")
    print "Writing maillist file..."
    for faction in factions:
        if faction.addr.lower() != "n/a":
            mailfile.write("%s\n" % faction.addr)
    mailfile.close()


reportcasualtiesdh = 0

def reportcasualties(unit):
    """ Report the number of casualties that a unit has taken """
    if not unit.dead:
        return
    if not reportcasualtiesdh:
        battlerecord("")
        reportcasualtiesdh = 1

    if unit.number == 1:
        battlerecord("%s is dead." % unitid(unit))
    else:
        if unit.dead == unit.number:
            battlerecord("%s is wiped out." % unitid(unit))
        else:
            battlerecord("%s loses %d." % (unitid(unit), unit.dead))
    

def expandorders(region, orders):
    """ Function used for distributing stuff, eg. silver to entertainers """
    for unit in region.units:
        # unit.n appears to be a generic 'count something in a unit' variable
        unit.n = -1
    norders = 0
    for order in orders:
        norders += order.qty
    
    oa = []
    i = 0
    for order in orders:
        for j in range(order.qty, 0, -1):
            taxorder = Order()
            taxorder.unit = order.unit
            taxorder.unit.n = 0
            oa.append(taxorder)
    random.shuffle(oa)
    return oa

def removenullfactions():
    """ Remove factions which are no longer active """
    for f in factions:
        if not f.alive:
            print ("Removing faction %s." % f.name)
            for f3 in factions:
                for rf in f3.allies:
                    if rf.faction == f:
                        f3.allies.remove(f)
            factions.remove(f)

def itemweight(unit):
    n = 0
    for i in range(MAXITEMS):
        if i == I_STONE:
            n += unit.items[i] * 50
        elif i == I_HORSE:
            pass
        else:
            n += unit.items[i]
    return n

def horseweight(unit):
    return unit.items[I_HORSE] * 50

def canmove(unit):
    return itemweight(unit) - horseweight(unit) - unit.number*5 <= 0

def canride(unit):
    if unit.items[I_HORSE] == 0:
        return False
    return itemweight(unit) - horseweight(unit) - unit.number*10 <= 0

def cansail(region, ship):
    n = 0
    for unit in region.units:
        if unit.ship == ship:
            n += itemweight(unit) + horseweight(unit) + unit.number*10
    return n <= shipcapacity[ship.type]

def spellitem(item):
    if item < SP_MAKE_AMULET_OF_DARKNESS or item > SP_MAKE_WAND_OF_TELEPORTATION:
        return -1
    return item - SP_MAKE_AMULET_OF_DARKNESS + I_AMULET_OF_DARKNESS

def cancast(unit, i):
    """ Can the unit cast the spell? """
    if unit.spells[i]:
        return unit.number

    if not effskill(unit, SK_MAGIC):
        return 0
    
    # Hmm, if we don't know the spell, but have an item, we're still good
    if i == SP_BLACK_WIND:
        return unit.items[I_AMULET_OF_DARKNESS]
    if i == SP_FIREBALL:
        return unit.items[I_STAFF_OF_FIRE]
    if i == SP_HAND_OF_DEATH:
        return unit.items[I_AMULET_OF_DEATH]
    if i == SP_LIGHTNING_BOLT:
        return unit.items[I_STAFF_OF_LIGHTNING]
    if i == SP_TELEPORT:
        return min(unit.number, unit.items[I_WAND_OF_TELEPORTATION])
    return 0

def magicians(faction):
    """ How many magicians does the faction have? """
    n = 0
    for region in regions:
        for unit in region.units:
            if unit.skills[SK_MAGIC] and unit.faction == faction:
                n += unit.number
    return n

def movewhere(region, direction):
    """ Which region will we end up in if we go a certain direction. 
        Also creates a new block if we run off the edge of the world? """
    
    # Not sure that we need this assignment
    if direction == K_NORTH:
        if not region.connect[0]:
            makeblock(region.x, region.y - 1)
        region2 = region.connect[0]

    elif direction == K_SOUTH:
        if not region.connect[1]:
            makeblock(region.x, region.y + 1)
        region2 = region.connect[1]

    elif direction == K_EAST:
        if not region.connect[2]:
            makeblock(region.x + 1, region.y)
        region2 = region.connect[2]

    elif direction == K_WEST:
        if not region.connect[3]:
            makeblock(region.x - 1, region.y)
        region2 = region.connect[3]
    
    else:
        region2 = None
    return region2


def createship(unit, shiptype):
    """
    Create a new ship with the unit and do some building on it
    """
    if not effskill(unit, SK_SHIPBUILDING):
        mistakeu(unit, "You don't have the skill")
        return
    ship = Ship()
    ship.type = shiptype
    ship.left = shipcost[shiptype]

    shipno = 1
    while 1:
        ship = findship(shipno)
        if not ship:
            break
        shipno += 1
    ship.no = shipno
    regions.ships.append(ship)
    
    leave(region, unit)
    unit.ship = ship
    unit.owner = 1

    n = unit.number * effskill(unit, SK_SHIPBUILDING)
    n = min(n, ship.left, unit.items[I_WOOD])
    ship.left -= n
    unit.items[I_WOOD] -= n
    unit.skills[SK_SHIPBUILDING] += n*10

    eventString = "%s adds %d to %s." % (unitid(unit), n, shipid(ship))
    addevent(unit.faction, eventString)


def processorders():
    """ Process the orders """

    print "Processing FORM orders..."
    #unit2 = None
    for region in regions:
        for unit in region.units:
            inNewUnit = False
            parentStrippedOrders = []
            for orderString in unit.orders:
                if inNewUnit:
                    ordernum = findkeyword(orderString)
                    #if ordernum in (K_END, K_FORM) and unit2:
                    #    print "New unit:", unitid(unit2), "orders are", unit2.orders
                    if ordernum == K_END:
                        inNewUnit = False
                        continue
                    elif ordernum == K_FORM:
                        mistake2(unit, orderString, "missing an end from your form order")
                        inNewUnit = False
                    else:
                        unit2.orders.append(orderString)
                        continue
                        
                if not inNewUnit:
                    ordernum = findkeyword(orderString)
                    if ordernum == K_FORM:
                        unit2 = createunit(region)
                        unit2.alias = atoip(orderString.split()[1])
                        
                        unit2.faction = unit.faction
                        unit2.building = unit.building
                        unit2.ship = unit.ship
                        unit2.behind = unit.behind
                        unit2.guard = unit.guard

                        inNewUnit = True
                    else:
                        parentStrippedOrders.append(orderString)

            unit.orders = parentStrippedOrders

    print "Processing instant orders..."
    for region in regions:
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == -1:
                    mistake2(unit, orderString, "Order not recognised")
                
                elif ordernum == K_ACCEPT:
                    # ACCEPT <faction-no>
                    togglerf(unit, orderString, unit.faction.accept)
                
                elif ordernum == K_ADDRESS:
                    # ADDRESS <email-address>
                    addressBits = orderString.split()
                    if len(addressBits) < 2:
                        mistake2(unit, orderString, "No address given")
                    else:
                        unit.faction.addr = addressBits[1]
                        print "%s is changing address to %s." % \
                                (unit.faction.name, unit.faction.addr)
                
                elif ordernum == K_ADMIT:
                    # ADMIT <faction-no>
                    togglerf (unit, orderString, unit.faction.admit)
                
                elif ordernum == K_ALLY:
                    # ALLY <faction no> <flag>
                    allyBits = orderString.split()
                    if len(allyBits) == 1:
                        mistake2(unit, orderString, "You need to specify the faction that you're allying with")
                        continue
                    elif len(allyBits) == 2:
                        mistake2(unit, orderString, "You need to include a flag (0 or 1) in an ally order")
                        
                    f = findfaction(allyBits[1])
                    if f == 0:
                        mistake2(unit, orderString, "Faction not found")
                    elif f == unit.faction:
                        mistake2(unit, orderString, "Can't ally with yourself")
                    else:
                        flag = allyBits[2]
                        if flag == "1":
                            if f not in unit.faction.allies:
                                unit.faction.allies.append(f)
                        elif flag == "0":
                            while f in unit.faction.allies:
                                unit.faction.allies.remove(f)

                elif ordernum == K_BEHIND:
                    bits = orderString.split()
                    if len(bits) < 2:
                        mistake2(unit, orderString, "Need to specify the flag for the behind order")
                        continue
                    if bits[1] == '1':
                        unit.behind = 1
                    else:
                        unit.behind = 0

                elif ordernum == K_COMBAT:
                    bits = orderString.split()
                    if len(bits) == 1:
                        unit.combatspell = -1
                        continue
                    spellnum = findspell(bits[1])
                    if spellnum < 0 or not cancast(unit, spellnum):
                        mistake2(unit, orderString, "Spell not found")
                    elif not iscombatspell(spellnum):
                        mistake2(unit, orderString, "Not a combat spell")
                    else:
                        unit.combatspell = spellnum

                elif ordernum == K_DISPLAY:
                    bits = orderString.split()
                    if len(bits) < 3:
                        mistake2(unit, orderString, "Need to specify what to set the display to")
                        continue
                    keyword = findkeyword(bits[1])
                    changeTo = ' '.join(bits[2:])
                    if keyword == K_BUILDING:
                        if not unit.building:
                            mistake2(unit, orderString, "Not in a building")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Building not owned by you")
                        else:
                            unit.building.display = changeTo
                    elif keyword == K_SHIP:
                        if not unit.ship:
                            mistake2(unit, orderString, "Not in a ship")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Ship not owned by you")
                        else:
                            unit.ship.display = changeTo
                    elif keyword == K_UNIT:
                        unit.display = changeTo
                    else:
                        mistake2(unit, orderString, "Order not recognized")

                elif ordernum == K_GUARD:
                    bits = orderString.split()
                    if len(bits) < 2:
                        mistake2(unit, orderString, "Need to specify the flag for the guard order")
                        continue
                    if bits[1] != '1':
                        unit.guard = 0

                elif ordernum == K_NAME:
                    bits = orderString.split()
                    if len(bits) < 3:
                        mistake2(unit, orderString, "Need to specify what to set the name to")
                        continue
                    if len(bits) == 2:
                        mistake2(unit, orderString, "No name given")
                        continue
                    keyword = findkeyword(bits[1])
                    changeTo = ' '.join(bits[2:])
                    if '(' in changeTo or ')' in changeTo:
                        mistake2(unit, orderString, "Names cannot contain brackets")
                        continue
                    if keyword == K_BUILDING:
                        if not unit.building:
                            mistake2(unit, orderString, "Not in a building")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Building not owned by you")
                        else:
                            unit.building.name = changeTo
                    elif keyword == K_SHIP:
                        if not unit.ship:
                            mistake2(unit, orderString, "Not in a ship")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Ship not owned by you")
                        else:
                            unit.ship.name = changeTo
                    elif keyword == K_UNIT:
                        unit.name = changeTo
                    elif keyword == K_FACTION:
                        unit.faction.name = changeTo
                    else:
                        mistake2(unit, orderString, "Order not recognized")

                elif ordernum == K_RESHOW:
                    # TODO: I assume that the spell gets reshown at some point later on...
                    bits = orderString.split()
                    if len(bits) == 1:
                        spellnum = -1
                    else:
                        spellnum = findspell(bits[1])
                    if spellnum < 0 or not unit.faction.seendata[spellnum]:
                        mistake2(unit, orderString, "Spell not found")
                    else:
                        unit.faction.showdata[spellnum] = 1


    print "Processing FIND orders..."
    for region in regions:
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_FIND:
                    print "Found a FIND order in unit %s: %s" % (unitid(unit), orderString)
                    bits = orderString.split()
                    if len(bits) == 1:
                        mistake2(unit, orderString, "Faction not specified")
                    else:
                        foundfaction = findfaction(bits[1])
                        print "Trying to find faction %s ... %s" % (bits[1], foundfaction)
                        if foundfaction:
                            unit.faction.messages.append("The address of %s is %s." % (factionid(foundfaction), foundfaction.addr))

    print "Processing leaving and entering orders..."
    for region in regions:
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_BOARD:
                    bits = orderString.split()
                    if len(bits) == 1:
                        mistake2(unit, orderString, "Ship not specified")
                        continue
                    ship = findshipregion(bits[1], region)
                    if not ship:
                        mistake2(unit, orderString, "Ship not found")
                        continue
                    if not mayboard(region, unit, ship):
                        mistake2(unit, orderString, "Not permitted to board")
                        continue

                    leave(region, unit)
                    unit.ship = ship
                    unit.owner = 0
                    if shipowner(region, ship) == 0:
                        unit.owner = 1
                        
                elif ordernum == K_ENTER:
                    bits = orderString.split()
                    if len(bits) == 1:
                        mistake2(unit, orderString, "Building not specified")
                        continue
                    building = findbuilding(region, bits[1])
                    if not building:
                        mistake2(unit, orderString, "Building not found")
                        continue
                    if not mayenter(region, unit, building):
                        mistake2(unit, orderString, "Not permitted to enter")
                        continue

                    leave(region, unit)
                    unit.building = building
                    unit.owner = 0
                    if buildingowner(region, building) == 0:
                        unit.owner = 1

                elif ordernum == K_LEAVE:
                    if region.terrain == T_OCEAN:
                        mistake2(unit, orderString, "Ship is at sea")
                    else:
                        leave(region, unit)

                elif ordernum == K_PROMOTE:
                    bits = orderString.split()
                    if len(bits) == 1:
                        mistake2(unit, orderString, "Unit not specified")
                        continue
                    unit2 = getunit(region, unit, bits[1])
                    if not unit2:
                        mistake2(unit, orderString, "Unit not found")
                        continue
                    if not unit.building and not unit.ship:
                        mistake2(unit, orderString, "No building or ship to transfer ownership of")
                        continue
                    if not unit.owner:
                        mistake2(unit, orderString, "Not owned by you")
                        continue
                    if not accepts(unit2, unit):
                        mistake2(unit, orderString, "Unit does not accept ownership")
                        continue
                    if unit.building:
                        if unit2.building != unit.building:
                            mistake2(unit, orderString, "Unit not in same building")
                            continue
                    else:
                        if unit2.ship != unit.ship:
                            mistake2(unit, orderString, "Unit not on same ship")
                            continue

                    unit.owner = 0
                    unit2.owner = 1
                    
   
    print "Processing ATTACK orders..."
    for region in regions:
        # Create randomly sorted list of factions
        randomFactions = factions[:]
        random.shuffle(randomFactions)
        
        # Handle each faction's attack orders
        for faction in randomFactions:
            for unit in region.units:
                if unit.faction == faction:
                    for orderString in unit.orders:
                        ordernum = findkeyword(orderString)
                        if ordernum == K_ATTACK:
                            bits = orderString.split()
                            if len(bits) == 1:
                                mistake2(unit, orderString, "Need to specify who to attack")
                                continue
                            unit2 = getunit(region, unit, bits[1])
                            if not unit2 and not getunitpeasants:
                                mistake2(unit, orderString, "Unit not found")
                                continue
                            if unit2 and unit2.faction == faction:
                                mistake2(unit, orderString, "Can't attack one of your own units")
                                continue
                            if isallied(unit, unit2):
                                mistake2(unit, orderString, "Can't attack allied units")
                                continue

                            # Draw up troops for the battle
                            for building in region.buildings:
                                building.sizeleft = building.size
                            
                            global troops, left, infront
                            troops = []
                            left = [0, 0]
                            infront = [0, 0]
                            
                            if not unit2:
                                for i in range(region.peasants):
                                    t = Troop()
                                    troops.append(t)
                                left[0] = region.peasants
                                infront[0] = region.peasants

                            # What units are involved?
                            for faction2 in factions:
                                faction2.attacking = 0

                            for unit3 in region.units:
                                for orderString2 in unit3.orders:
                                    if findkeyword(orderString2) == K_ATTACK:
                                        unitNum = orderString2.split()[1]
                                        unit4 = getunit(region, unit3, unitNum)
                                        if (getunitpeasants and not unit2) or \
                                            (unit4 and unit4.faction == unit2.faction and \
                                             not isallied(unit3, unit4)):
                                            unit3.faction.attacking = 1
                                            break
                            
                            for unit3 in region.units:
                                unit3.side = -1
                                if not unit3.number:
                                    continue
                                if unit3.faction.attacking:
                                    unit3.side = 1
                                    maketroops(unit3, region.terrain)
                                elif isallied(unit3, unit2):
                                    unit3.side = 0
                                    maketroops(unit3, region.terrain)
                                
                            # If only one side shows up, cancel
                            # TODO: but we haven't modified left[1] yet, so it's probably a dodgy global variable
                            if not left[0] or not left[1]:
                                continue

                            # Set up array of troops
                            global shields, runeswords, initial
                            initial = [left[0], left[1]]
                            shields = [0, 0]
                            runeswords = [0, 0]
                            lmoney = 0
                            litems = []
                            random.shuffle(troops)

                            # Initial attack message
                            for faction2 in factions:
                                faction2.seesbattle = ispresent(faction2, region)
                                if faction2.seesbattle and faction2.battle:
                                    faction2.battles.append("")

                            if unit2:
                                battleReport = ["%s attacks %s in %s!" % \
                                               (unitid(unit), unitid(unit2), regionid(region))]
                            else:
                                battleReport = ["%s attacks the peasants in %s!" % \
                                               (unitid(unit), regionid(region))]
                            
                            # List sides
                            battleReport.append("")
                            battleReport.append(battlepunit(region, unit))
                            for unit3 in region.units:
                                if unit3.side == 1 and unit3 != unit:
                                    battleReport.append(battlepunit(region, unit3))

                            battleReport.append("")
                            if unit2:
                                battleReport.append(battlepunit(region, unit2))
                            else:
                                battleReport.append("Peasants, number: %d" % region.peasants)
                            for unit3 in region.units:
                                if unit3.side == 0 and unit3 != unit2:
                                    battleReport.append(battlepunit(region, unit3))

                            battleReport.append("")

                            # Does one side have an advantage in tactics? 
                            maxtactics = [0, 0]
                            leader = [0, 0]
                            for troop in troops:
                                if troop.unit:
                                    j = effskill(troop.unit, SK_TACTICS)
                                    side = troop.unit.side
                                    if maxtactics[side] < j:
                                        # TODO: leader? where's that coming from?
                                        leader[side] = troop
                                        maxtactics[side] = j
                            
                            attacker.side = -1
                            if maxtactics[0] > maxtactics[1]:
                                attacker.side = 0
                            elif maxtactics[1] > maxtactics[0]:
                                attacker.side = 1
                            
                            # Better leader gets free round of attacks
                            if attacker.side >= 0:
                                if attacker.side:
                                    battleReport.append("%s gets a free round of attacks!" % unitid(unit))
                                else:
                                    if unit2:
                                        battleReport.append("%s gets a free round of attacks!" % unitid(unit2))
                                    else:
                                        battleReport.append("The peasants get a free round of attacks!")

                                toattack[attacker.side] = 0
                                for troop in troops:
                                    troop.attacked = True
                                    if troop.side == attacker.side:
                                        troop.attacked = False
                                        toattack[attacker.side] += 1

                                while 1:
                                    doshot()
                                    if not(toattack[attacker.side] and left[defender.side]):
                                        break

                            # Handle main body of battle
                            toattack[0] = 0
                            toattack[1] = 0

                            while 1:
                                # End of a round
                                if (toattack[0] == 0 and toattack[1] == 0):
                                    for troop in troops:
                                        troop.attacked = 1
                                        if not troop.status:
                                            troop.attacked = 0
                                            toattack[troop.side] += 1
                                doshot()
                                if not left[defender.side]:
                                    break

                            # Report on winner
                            if attacker.side:
                                battleReport.append("%s wins the battle!" % unitid(unit))
                            else:
                                if unit2:
                                    battlereport.append("%s wins the battle!" % unitid(unit2))
                                else:
                                    battlereport.append("The peasants win the battle!")

                            # Has the winner suffered any casualties?
                            winnercasualties = 0
                            for troop in troops:
                                if troop.side == attacker.side and troop.status:
                                    winnercasualties = 1
                                    break

                            # Can wounded be healed?
                            n = 0
                            for index, troop in enumerate(troops):
                                leftToHeal = initial[attacker.side] - left[attacker.side] - n
                                if leftToHeal <= 0:
                                    break
                                if not troop.status and troop.canheal:
                                    k = lovar(50 * (1+troop.power))
                                    k = min(k, initial[attacker.side] - left[attacker.side] - n)
                                    battleReport.append("%s heals %d wounded." % (unitid(troop.unit), k))
                                    n += k

                            # Heal the wounded
                            while n > 0:
                                patient = random.choice(troops)
                                if not patient.status and troop.side == attacker.side:
                                    troop.status = 0
                                    n = n - 1
                            
                            # Count the casualties
                            deadpeasants = 0
                            for unit3 in region.units:
                                unit3.dead = 0

                            for troop in troops:
                                if troop.status:
                                    if troop.unit:
                                        troop.unit.dead += 1
                                    else:
                                        deadpeasants += 1

                            # Report the casualties

                            ### TODO: remove this evil global?
                            reportcasualtiesdh = 0
                            if attacker.side:
                                reportcasualties(unit)
                                for unit3 in region.units:
                                    if unit3.side == 1 and unit3 != unit:
                                        reportcasualties(unit3)
                            else:
                                if unit2:
                                    reportcasualties(unit2)
                                else:
                                    if deadpeasants:
                                        battleReport.append("")
                                        reportcasualtiesdh = 1
                                        battleReport.append("The peasants lose %d." % deadpeasants)

                                # TODO: do we need to do this if we've attacked the peasants?
                                for unit3 in region.units:
                                    if unit3.side == 0 and unit3 != unit2:
                                        reportcasualties(unit3)
                            
                            # Dead peasants
                            k = region.peasants - deadpeasants
                            j = distribute(region.peasants, k, region.money)
                            lmoney += region.money - j
                            region.money = j
                            region.peasants = k

                            # Adjust units
                            for unit3 in region.units:
                                k = unit3.number - unit3.dead

                                # Redistribute items and money
                                if unit3.side == defender.side:
                                    j = distribute(unit3.number, k, unit3.money)
                                    lmoney += unit3.money - j
                                    unit3.money = j
                                    for i in range(MAXITEMS):
                                        j = distribute(unit3.number, k, unit3.items[i])
                                        litems[i] += unit3.items[i] - j
                                        unit3.items[i] = j

                                # Redistribute skills
                                for i in range(MAXSKILLS):
                                    unit3.skills[i] = distribute(unit3.number, k, unit3.skills[i])
                            
                                # adjust unit numbers
                                unit3.number = k

                                # need this flag cleared for reporting of loot
                                unit3.n = 0

                            # Distribute loot
                            n = lmoney
                            while n > 0:
                                troop = random.choice(troops)
                                if not troop.status and troop.side == attacker.side:
                                    troop.unit.money += 1
                                    troop.unit.n += 1
                                # TODO: theres also a region.money += 1 here in
                                # the original code, but I don't think it'll
                                # ever be called.  we might want to check that
                                # there are attacking troops left, but I don't
                                # know that that situation will ever happen
                                # (unless monsters win the battle for you after
                                # your mage is dead?)
                            
                            # distribute items
                            for i in range(MAXITEMS):
                                n = litems[i]
                                while n > 0:
                                    if i <= I_STONE or rnd() % 2 != 0:
                                        troop = random.choice(troops)
                                        if troop.status or troop.side != attacker.side:
                                            continue
                                        if troop.unit:
                                            if not troop.unit.litems:
                                                troop.unit.litems = [0] * MAXITEMS
                                            troop.unit.items[i] += 1
                                            troop.unit.litems[i] += 1
                            
                            # Report loot
                            for faction2 in factions:
                                faction2.dh = 0

                            for unit3 in region.units:
                                if unit3.n or unit3.litems:
                                    lootString = "%s finds " % unitid(unit3)
                                    dh = 0
                                    
                                    if unit3.n:
                                        lootString += "$%d" % unit3.n
                                        dh = 1
                                    
                                    if unit3.litems:
                                        for i in range(MAXITEMS):
                                            if unit3.litems[i]:
                                                if dh:
                                                    lootString += ", "
                                                dh = 1

                                                if unit3.litems[i] == 1:
                                                    itemName = itemnames[0][i]
                                                else:
                                                    itemName = itemnames[1][i]
                                                    
                                                lootString += "%s %s" % (unit3.litems[i], itemName)
                                        
                                        unit3.litems = []
                                    
                                    if not unit3.faction.dh:
                                        addbattle(unit3.faction, "")
                                        unit3.faction.dh = 1
                                    
                                    lootString += "."
                                    addbattle(unit3.faction, lootString)

                            # Does the winner get combat experience?
                            if winnercasualties:
                                if (maxtactics[attacker.side] and
                                    leader[attacker.side] and
                                    not leader[attacker.side].status):
                                    leader[attacker.side].unit.skills[SK_TACTICS] += COMBATEXP

                                for troop in troops:
                                    if (troop.unit and
                                        not troop.status and
                                        troop.side == attacker.side):

                                        if troop.weapon == I_SWORD:
                                            troop.unit.skills[SK_SWORD] += COMBATEXP
                                        elif troop.weapon == I_CROSSBOW:
                                            troop.unit.skills[SK_CROSSBOW] += COMBATEXP
                                        elif troop.weapon == I_LONGBOW:
                                            troop.unit.skills[SK_LONGBOW] += COMBATEXP

                            troops = []
    randomFactions = []
    

    print "Processing economic orders..."
    for region in regions:
        taxorders = []
        recruitorders = []

        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_DEMOLISH:
                    if not unit.building: 
                        mistake2(unit, orderString, "Not in a building")
                        continue
                    if not unit.owner:
                        mistake2(unit, orderString, "Building not owned by you")
                        continue
                    building = unit.building
                    for unit2 in region.units:
                        if unit2.building == building:
                            unit2.building = 0
                            unit2.owner = 0
                    reportevent(region, "%s demolishes %s." % (unitid(unit), buildingid(building)))
                    region.buildings.remove(building)

                elif ordernum == K_GIVE:
                    bits = orderString.split()
                    if len(bits) == 1:
                         mistake2(unit, orderString, "Need to specify the unit number")
                         continue

                    if bits[1] == "new":
                        if len(bits) == 2:
                            mistake2(unit, orderString, "Need to specify the new unit's alias")
                            continue
                        bits[1] = bits[1] + " " + bits[2]
                        del bits[2]
                    
                    unit2 = getunit(region, unit, bits[1])
                    if not unit2 and not getunit0:
                        mistake2(unit, orderString, "Unit not found")
                        continue
                    if unit2 and not accepts(unit2, unit):
                        mistake2(unit, orderString, "Unit does not accept your gift")
                        continue
                    
                    if len(bits) == 2:
                        mistake2(unit, orderString, "Need to specify what you're giving")
                        continue

                    i = findspell(orderString[2])
                    if i >= 0:
                        # a spell
                        if not unit.spells[i]:
                            mistake2(unit, orderString, "Spell not found")
                            continue
                        if spelllevel[i] > (effskill(unit2, SK_MAGIC) + 1) / 2:
                            mistake2(unit, orderString, "Recipient is not able to learn that spell")
                            continue
                        unit2.spells[i] = 1
                        eventString = "%s gives %s the %s spell." % (unitid(unit), unitid(unit2), spellnames[i])
                        addevent(unit.faction, eventString)
                        if unit.faction != unit2.faction:
                            addevent(unit2.faction, eventString)
                        if not unit2.faction.seendata[i]:
                            unit2.faction.seendata[i] = 1
                            unit2.faction.showdata[i] = 1

                    else:
                        # an item
                        if not bits[2].isdigit:
                            mistake2(unit, orderString, "Not a number of items")
                            continue
                        n = atoip(bits[2])
                        itemnum = finditem(bits[3])
                        if itemnum < 0:
                            mistake2(unit, orderString, "Item not recognized")
                            continue

                        if n > unit.items[i]:
                            n = unit.items[i]
                        if n == 0:
                            mistake2(unit, orderString, "Item not available")
                            continue
                        if not unit2 and bits[1] == "0":
                            if n == 1:
                                eventstring = "%s discards 1 %s." % (unitid(u), itemnames[0][i])
                            else:
                                eventstring = "%s discards %d %s." % (unitid(u), n, itemnames[1][i])
                            addevent(unit.faction, eventstring)
                            continue

                        unit2.items[i] += n
                        if n == 1:
                            eventstring = "%s gives %s 1 %s." % (unitid(unit), unitid(unit2), itemnames[0][i])
                        else:
                            eventstring = "%s gives %s %s %s." % (unitid(unit), unitid(unit2), n, itemnames[0][i])
                        addevent(unit.faction, eventString)
                        if unit.faction != unit2.faction:
                            addevent(unit2.faction)

                elif ordernum == K_PAY:
                    bits = orderString.split()
                    print "Processing PAY order for %s: %s" % (unitid(unit), orderString)
                    if len(bits) == 1:
                         mistake2(unit, orderString, "Need to specify the unit number")
                         continue

                    if bits[1].lower() == "new":
                        if len(bits) == 2:
                            mistake2(unit, orderString, "Need to specify the new unit's alias")
                            continue
                        bits[1] = bits[1].lower() + " " + bits[2]
                        del bits[2]
                        print "Found a new unit alias for faction %s: %s" % (unit.faction.no, bits[1])

                    if len(bits) == 2:
                        mistake2(unit, orderString, "Need to specify how much to pay")
                        continue
                    unit2 = getunit(region, unit, bits[1])
                    if not unit2 and not getunit0 and not getunitpeasants:
                        mistake2(unit, orderString, "Unit not found")
                        continue
                    
                    n = atoip(bits[2])
                    if n > unit.money:
                        n = unit.money
                    if n == 0:
                        mistake2(unit, orderString, "No money available")
                        continue

                    unit.money -= n
                    if unit2:
                        unit2.money += n
                        if unit.faction != unit2.faction:
                            eventString = "%s pays %s $%d." % (unitid(unit), unitid(unit2), n)
                            addevent(unit2.faction, eventString)
                    else:
                        if getunitpeasants:
                            region.money += n
                            eventString = "%s pays the peasants $%d." % (unitid(unit), n)
                        elif bits[1] == "0":
                            eventString = "%s discards $%d" % (unitid(unit), n)
                        addevent(unit.faction, eventString)
                
                elif ordernum == K_SINK:
                    if not unit.ship:
                        mistake2(unit, orderString, "Not on a ship")
                        continue
                    if not unit.owner:
                        mistake2(unit, orderString, "Ship not owned by you")
                        continue
                    if region.terrain == T_OCEAN:
                        mistake2(unit, orderString, "Ship is at sea")

                    ship = unit.ship
                    for unit2 in region.units:
                        if unit2.ship == ship:
                            unit2.ship = 0
                            unit2.owner = 0
                    eventString = "%s sinks %s." % (unitid(unit), shipid(ship))
                    reportEvent(region, eventString)
                    region.ships.remove(ship)

        # Transfer orders
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_TRANSFER:
                    bits = orderString.split()
                    if len(bits) == 1:
                        mistake2(unit, orderString, "Need to specify the unit number")
                        continue

                    if bits[1] == "new":
                        if len(bits) == 2:
                            mistake2(unit, orderString, "Need to specify the new unit's alias")
                            continue
                        bits[1] = bits[1] + " " + bits[2]
                        del bits[2]

                    unit2 = getunit(region, unit, bits[1])
                    if unit2:
                        if not accepts(unit2, unit):
                            mistake2 (unit, orderString, "Unit does not accept your gift")
                            continue
                    elif not getunitpeasants:
                        mistake2(unit, orderString, "Unit not found")
                        continue
                    
                    if len(bits) == 2:
                        mistake2(unit, orderString, "Need to specify how many men to transfer")
                        continue

                    n = atoip(bits[2])
                    if n > unit.number:
                        n = unit.number
                    if n == 0:
                        mistake2(unit, orderString, "No people available")
                        continue

                    if unit.skills[SK_MAGIC] and unit2:
                        k = magicians(unit2.faction)
                        if unit2.faction != unit.faction:
                            k += n
                        if not unit2.skills[SK_MAGIC]:
                            k += unit2.number
                        if k > 3:
                            mistake2(unit, unit.thisorder, "Only 3 magicians per faction")
                            continue

                    k = unit.number - n
                    for i in range(MAXSKILLS):
                        j = distribute(unit.number,k,unit.skills[i])
                        if unit2:
                            unit2.skills[i] += unit.skills[i] - j
                        unit.skills[i] = j

                    unit.number = k
                    if unit2:
                        unit2.number += n
                        if i in range(MAXSPELLS):
                            if unit.spells[i] and effskill(unit2, SK_MAGIC)/2 >= spelllevel[i]:
                                unit2.spells[i] = 1
                        if unit.faction != unit2.faction:
                            eventString = "%s transfers %d to %s" % (unitid(unit), n, unitid(unit2))
                            addevent(unit2.faction, eventString)
                    
                    else:
                        region.peasants += n
                        if k:
                            eventString = "%s disbands %d." % (unitid(unit), n)
                        else:
                            eventString = "%s disbands." % unitid(unit)
                        addevent(unit.faction, eventString)

        # TAX orders
        for unit in region.units:
            taxed = 0
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_TAX:
                    if taxed:
                        continue
                    n = armedmen(unit)
                    if not n:
                        mistake2(unit, orderString, "Unit is not armed and combat trained")
                        continue
                    for unit2 in region.units:
                        if unit2.guard and unit2.number and not admits(unit2, unit):
                            mistake2(unit, orderString, "%s is on guard" % unit2.name)
                            unit2 = "guard"
                            continue
                    if unit2 == "guard":
                        continue

                    order = Order()
                    order.qty = n * TAXINCOME
                    order.unit = unit
                    taxorders.append(order)
                    taxed = 1
        
        # Do taxation
        for unit in region.units:
            # unit.n appears to be a generic 'count something in a unit' variable
            unit.n = -1
        
        # calculate the number of tax 'orders' in $10 chunks
        norders = 0
        for order in taxorders:
            norders += o.qty / 10
        
        oa = []
        i = 0
        for order in taxorders:
            for j in range(order.qty/10, 0, -1):
                taxorder = Order()
                taxorder.unit = order.unit
                taxorder.unit.n = 0
                oa.append(taxorder)
        random.shuffle(oa)
        
        chop = min(region.money / 10, norders)
        for order in oa[:chop]:
            order.unit.money += 10
            order.unit.n += 10
        
        for unit in region.units:
            if unit.n >= 0:
                eventString = "%s collects $%d in taxes." % (unitid(unit), unit.n)
                addevent(unit.faction, eventString)
        
        # Guard and recruiting
        for unit in region.units:
            availmoney = unit.money
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_GUARD:
                    bits = orderString.split()
                    if len(bits) < 2:
                        #The player will have already seen this
                        #mistake2(unit, orderString, "Need to specify the flag for the guard order")
                        continue
                    if bits[1] == '1':
                        unit.guard = 1
                
                elif ordernum == K_RECRUIT:
                    if availmoney < RECRUITCOST:
                        continue
                    print "Unit %s (new %s) is recruiting with $%s: %s" % (unit.no, unit.alias, availmoney, orderString)
                    bits = orderString.split()
                    if len(bits) < 2:
                        mistake2(unit, orderString, "Need to specify the number of men to recruit")
                        continue
                    if not bits[1].isdigit:
                        mistake2(unit, orderString, "Need to specify a *number* of men to recruit")
                        continue
                    n = int(bits[1])
                    if unit.skills[SK_MAGIC] and magicians(unit.faction)+n > 3:
                        mistake2(unit, orderString, "Only 3 magicians per faction")
                        continue
                    n = min(n, availmoney/RECRUITCOST)
                    
                    print " ... recruiting %s men" % (n)
                    
                    order = Order()
                    order.qty = n
                    order.unit = unit
                    recruitorders.append(order)
                    
                    print "Order n is %s" % order.qty
                    availmoney -= order.qty * RECRUITCOST

        # Do recruiting
        orders = expandorders(region, recruitorders)

        numrecruit = min( region.peasants/RECRUITFRACTION, len(orders) )
        #if orders:
        #    print "Recruiting in %s:" % regionid(region)
        #for order in orders:
        #    print unitid(order.unit), order.qty, order.unit.n
        
        for order in orders[:numrecruit]:
            #print order.qty,
            order.unit.number += 1
            region.peasants -= 1
            order.unit.money -= RECRUITCOST
            region.money += RECRUITCOST
            order.unit.n += 1
        #if orders[:numrecruit]:
        #    print
        
           
        for unit in region.units:
            if unit.n >= 0:
                eventString = "%s recruits %d." % (unitid(unit), unit.n)
                addevent(unit.faction, eventString)
        
        missedout = []
        for order in orders[numrecruit:]:
            if order.unit not in missedout:
                missedout.append(order.unit)
                mistakeu(unit, "Unit %s (new %s) missed out on recruitment!" % (order.unit.no, order.unit.alias))
            

    print "Processing QUIT orders..."
    for region in regions:
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum == K_QUIT:
                    bits = orderString.split()
                    if len(bits) >= 2 and str(unit.faction.no) == bits[1]:
                        destroyfaction(unit.faction)
                    else:
                        mistake2(unit, orderString, "Correct faction number not given")

    # Remove players who haven't sent in orders
    for faction in factions:
        if turn - int(faction.lastorders) > ORDERGAP:
            destroyfaction(faction)

    # Remove debris of destroyed factions
    removeempty()
    removenullfactions()

    print "Setting production (month long) orders..."
    for region in regions:
        for unit in region.units:
            unit.thisorder = unit.lastorder
            for orderString in unit.orders:
                ordernum = findkeyword(orderString)
                if ordernum in [K_BUILD, K_CAST, K_ENTERTAIN, K_MOVE, 
                                K_PRODUCE, K_RESEARCH, K_SAIL, K_STUDY,
                                K_TEACH, K_WORK]:
                    unit.thisorder = orderString

            ordernum = findkeyword(unit.thisorder)
            if ordernum not in [K_MOVE, K_SAIL]:
                unit.lastorder = unit.thisorder.lower()
            
            print "Unit %s month long orders are now %s (was %s)" % (unitid(unit), unit.thisorder, unit.lastorder)

    print "Processing MOVE orders..."
    for region in regions:
        for unit in region.units:
            unit.moveto = None
            ordernum = findkeyword(unit.thisorder)
            if ordernum == K_MOVE:
                #print "Processing move order for unit %s: %s" % (unitid(unit), unit.thisorder)
                bits = unit.thisorder.split()
                #print "bits are", bits
                if len(bits) == 1:
                    mistake2(unit, unit.thisorder, "Need to give a direction for move")
                    continue
                #print findkeyword(bits[1]), K_NORTH, K_EAST, K_SOUTH, K_WEST
                region2 = movewhere(region, findkeyword(bits[1]))
                if not region2:
                    mistake2(unit, unit.thisorder, "Direction not recognised")
                    continue
                
                #print "region 2 is", regionid(region2)
                
                if region.terrain == T_OCEAN:
                    mistakeu(unit, "Currently at sea")
                    continue
                if region2.terrain == T_OCEAN:
                    eventString = "%s discovers that (%d,%d) is ocean." % (unitid(unit), region2.x, region2.y)
                    addevent(unit.faction, eventString)
                    continue
                if not canmove(unit):
                    mistakeu(unit, "Carrying too much weight to move")
                    continue
                
                #print "Made it through!"

                # BAD, BAD! - we're modifying the list that we're iterating over
                #leave(region, unit)
                #region.units.remove(unit)
                #region2.units.append(unit)

                # set a flag instead
                unit.moveto = region2
                unit.thisorder = ""

                if canride(unit):
                    moveType = "rides"
                else:
                    moveType = "walks"
                eventString = "%s %s from %s to %s." % \
                    (unitid(unit), moveType, regionid(region), regionid(region2))
                addevent(unit.faction, eventString)
                #print factionid(unit.faction), eventString
                #print
                #print "faction events are now:", unit.faction.events
    
        #print "Cleaning up move orders..."
        for unit in region.units:
            if unit.moveto:
                leave(unit.moveto, unit)
                region.units.remove(unit)
                unit.moveto.units.append(unit)
                unit.moveto = None
                
    
    print "Processing SAIL orders..."
    for region in regions:
        for ship in region.ships:
            ship.moveto = None
        for unit in region.units:
            ordernum = findkeyword(unit.thisorder)
            if ordernum == K_SAIL:
                bits = unit.thisorder.split()
                if len(bits) == 1:
                    mistake2(unit, unit.thisorder, "Need to give a direction for sail")
                    continue
                region2 = movewhere(region, direction)
                if not region2:
                    mistake2(unit, unit.thisorder, "Direction not recognised")
                    continue
                if not unit.ship:
                    mistakeu(unit, "Not on a ship")
                    continue
                if not unit.owner:
                    mistakeu(unit, "Ship not owned by you")
                    continue
                if region2.terrain != T_OCEAN and not iscoast(region2):
                    eventString = "%s discovers that (%d,%d) is inland." % (unitid(unit), region2.x, region2.y)
                    addevent(unit.faction, eventString)
                    continue
                if unit.ship.left > 0:
                    mistakeu(unit, "Ship still under construction")
                    continue
                if not cansail(region, unit.ship):
                    mistakeu(unit, "Too heavily loaded to sail")
                    continue

                unit.ship.moveto = region2

        #print "Cleaning up ship movement..."
        for ship in region.ships:
            if ship.moveto:
                region.ships.remove(unit.ship)
                ship.moveto.ships.append(unit.ship)

                for unit2 in region.units:
                    if unit2.ship == unit.ship:
                        region.units.remove(unit2)
                        ship.moveto.units.append(unit2)
                        unit2.thisorder = ""
                unit.thisorder = ""


    print "Processing production orders..."
    for region in regions:
        if region.terrain == T_OCEAN:
            continue

        entertainorders = []
        workorders = []
        produceorders = [[] for i in range(MAXITEMS)]

        for unit in region.units:
            ordernum = findkeyword(unit.thisorder)
            if ordernum == K_BUILD:
                bits = unit.thisorder.split()
                if len(bits) == 1:
                    mistakeu(unit, "You need to specify what you're going to build")
                    continue
                buildtype = findkeyword(bits[1])
                if buildtype == K_BUILDING:
                    if not effskill(unit, SK_BUILDING):
                        mistake(unit, "You don't have the skill")
                        continue
                    if not unit.items[I_STONE]:
                        mistakeu(unit, "No stone available")
                        continue
                    if len(bits) == 2:
                        building = Building()
                        buildingno = 1
                        while 1:
                            building2 = findbuilding(buildingno, region)
                            if not building2:
                                building.no = buildingno
                                break
                            buildingno += 1
                        region.buildings.append(building)
                        leave(region, unit)
                        unit.building = building
                        unit.owner = 1
                    else:
                        building = getbuilding(bits[2], region)
                    
                    n = unit.number * effskill(unit, SK_BUILDING)
                    n = min(n, unit.items[I_STONE])
                    building.size += n
                    unit.items[I_STONE] -= n
                    unit.skills[SK_BUILDING] += n*10

                    eventString = "%s adds %d to %s." % (unitid(unit), n, buildingid(building))
                    addevent(unit.faction, eventString)

                elif buildtype == K_SHIP:
                    if not effskill(unit, SK_SHIPBUILDING):
                        mistakeu(unit, "You don't have the skill")
                        continue
                    if not unit.items[I_WOOD]:
                        mistakeu(unit, "No wood available")
                        continue
                    bits = unit.thisorder.split()
                    if len(bits) == 2:
                        mistakeu(unit, "You need to specify what ship you're going to work on")
                        continue

                    ship = findshipregion(bits[1], region)
                    if ship == 0:
                        mistakeu(unit, "Ship not found")
                        continue
                    if not ship.left:
                        mistakeu(unit, "Ship is already complete")
                        continue

                    n = unit.number * effskill(unit, SK_SHIPBUILDING)
                    n = min(n, ship.left, unit.items[I_WOOD])
                    ship.left -= n
                    unit.items[I_WOOD] -= n
                    unit.skills[SK_SHIPBUILDING] += n*10

                    eventString = "%s adds %d to %s." % (unitid(unit), n, shipid(ship))
                    addevent(unit.faction, eventString)
                    continue

                elif buildtype == K_LONGBOAT:
                    createship(unit, SH_LONGBOAT)
                    
                elif buildtype == K_CLIPPER:
                    createship(unit, SH_CLIPPER)

                elif buildtype == K_GALLEON:
                    createship(unit, SH_GALLEON)
                
                else:
                    mistakeu(unit, "Order not recognised")

            elif ordernum == K_ENTERTAIN:
                order = Order()
                order.unit = unit
                order.qty = unit.number * effskill(unit, SK_ENTERTAINER) * ENTERTAININCOME
                entertainorders.append(order)
                
            elif ordernum == K_PRODUCE:
                bits = orderString.split()
                if len(bits) == 1:
                    mistakeu(unit, "Need to specify what to produce")
                    continue
                itemnum = finditem(bits[1])
                if itemnum < 0 or itemnum > I_PLATE_ARMOR:
                    mistakeu(unit, "Item not recognised")
                    continue
                n = effskill(unit, itemskill[i])
                if n == 0:
                    mistakeu(unit, "You don't have the skill")
                    continue
                if itemnum == I_PLATE_ARMOR:
                    n = n / 3
                n = n * unit.number
                if itemnum < 4:
                    order = Order()
                    order.unit = unit
                    order.qty = n * productivity[region.terrain][itemnum]
                    produceorders[itemnum].append(order)
                else:
                    n = min(n, unit.items[rawmaterial[itemnum]])
                    if n == 0:
                        mistakeu(unit, "No material available")
                        continue
                    unit.items[itemnum] += n
                    unit.items[rawmaterial[itemnum]] -= n
                    if n == 1:
                        eventString = "%s produces 1 %s." % (unitid(unit), itemnames[0][itemnum])
                    else:
                        eventString = "%s produces %d %s." % (unitid(unit), n, itemnames[1][itemnum])
                    addevent(unit.faction, eventString)

                unit.skills[itemskill[itemnum]] += unit.number * PRODUCEEXP

            elif ordernum == K_TEACH:
                teaching = unit.number * 30 * TEACHNUMBER
                m = 0
                bits = orderString.split()
                if len(bits) == 1:
                    mistakeu(unit, "You need to specify who to teach")
                    continue
                
                unitList = []
                for unitNum in bits[1:]:
                    student = getunit(region, unit, unitNum)
                    if getunit0:
                        continue
                    if unit == 0:
                        mistakeu(unit, "Unit not found")
                        continue
                    if not accepts(student, unit):
                        mistakeu(unit, "Unit %s does not accept teaching" % unitNum)
                        continue
                    
                    studentOrder = igetkeyword(student.thisorder)
                    studentSkill = findskill(unitTaught.thisorder.split()[1])
                    if studentOrder != K_STUDY or studentSkill < 0:
                        mistakeu(unit, "Unit %s not studying" % unitNum)
                        continue
                    if effskill(unit, studentSkill) <= effskill(student, studentSkill):
                        mistakeu(unit, "Unit is not studying a skill you can teach it")
                        continue

                    n = student.number * 30 - student.learning
                    n = min(n, teaching)
                    if n == 0:
                        continue

                    student.learning += n
                    # TODO: Hmm, students knock a teacher down full, even if
                    # they only get a couple of days training...
                    teaching -= unit.number * 30

                    eventString = "%s teaches %s to %s." % (unitid(unit), skillnames[studentSkill], unitid(student))
                    addevent(unit.faction, eventString)
                    if student.faction != unit.faction:
                        addevent(student.faction, eventString)

            elif ordernum == K_RESEARCH:
                bits = orderString.split()
                if effskill(unit, SK_MAGIC) < 2:
                    mistakeu(unit, "Magic skill of at least 2 required")
                    continue

                level = bits[1]
                if not level.isdigit():
                    mistakeu(unit, "There is no level %s" % bits[1])
                    continue
                level = int(level)
                if level > effskill(unit, SK_MAGIC) / 2:
                    mistakeu(unit, "Insufficient Magic skill - highest available level researched")
                    level = effskill(unit, SK_MAGIC) / 2
                
                # pick a random spell that we can learn
                k = 0 
                for j in range(MAXSPELLS):
                    if spelllevel[j] == i and not unit.spells[j]:
                        k = 1

                if k == 0:
                    if unit.money < 200:
                        mistakeu(unit, "Insufficient funds")
                        continue
                    for n in range(unit.number):
                        if unit.money >= 200:
                            unit.money -= 200
                            unit.skills[SK_MAGIC] += 10

                    event = "%s discovers that no more level %d spells exist." % (unitid(unit), level)
                    addevent(unit.faction, event)
                    continue

                else:
                    # TODO: this is a direct conversion, but seems to be "buggy"
                    # no money is ever spent, and you seem to be able to research multiple spells?!
                    for n in range(unit.number):
                        if unit.money < 200:
                            mistakeu(unit, "Insufficient funds")
                            continue
                        
                        while 1:
                            j = rnd() % MAXSPELLS
                            if spelllevel[j] == i and unit.spells[j] != 1:
                                break
                        
                        if not unit.faction.seendata[j]:
                            unit.faction.seendata[j] = 1
                            unit.faction.showdata[j] = 1

                        if unit.spells[j] == 0:
                            event = "%s discovers the %s spell." % (unitid(u), spellnames[j])
                            addevent(unit.faction, event)

                        unit.spells[j] = 2
                        unit.skills[SK_MAGIC] += 10
                    
                    # Clean up spells. 2 => learned this turn
                    for j in range(MAXSPELLS):
                        if unit.spells[i] == 2:
                            unit.spells[i] = 1

            elif ordernum == K_WORK:
                order = Order()
                order.unit = unit
                order.qty = unit.number * foodproductivity[region.terrain]
                workorders.append(order)

        # Entertainment
        entOrders = expandorders(region, entertainorders)
        entEarned = 0
        maxEnt = region.money / ENTERTAINFRACTION
        for order in entOrders:
            order.unit.money += 1
            order.unit.n += 1
            entEarned += 1
            if entEarned >= maxEnt:
                break

        for unit in region.units:
            if unit.n >= 0:
                eventString = "%s earns $%d entertaining." % (unitid(unit), unit.n)
                addevent(unit.faction, eventString)
                unit.skills[SK_ENTERTAINMENT] += 10 * unit.number

        
        # Food production (work)
        workOrders = expandorders(region, workorders)
        maxWork = maxfoodoutput[region.terrain]
        workEarned = 0
        for order in workOrders:
            order.unit.money += 1
            order.unit.n += 1
            workEarned += 1
            if workEarned >= maxWork:
                break
        
        if workEarned < maxWork:
            region.money += min(maxWork-workEarned, 
                                region.peasants * foodproductivity[region.terrain])

        for unit in region.units:
            if unit.n >= 0:
                eventString = "%s earns $%d performing manual labour." % (unitid(unit), unit.n)
                addevent(unit.faction, eventString)

        # Production of other primary commodities
        for i in range(4):
            prodOrders = expandorders(region, produceorders[i])
            maxProd = maxoutput[region.terrain][i]
            prodSoFar = 0
            for order in prodOrders:
                order.unit.items[i] += 1
                order.unit.n += 1
                prodSoFar += 1
                if prodSoFar >= maxProd:
                    break

        for unit in region.units:
            if unit.n >= 0:
                if unit.n == 1:
                    eventString = "%s produces 1 %s." % (unitid(unit), itemnames[0][i])
                else:
                    eventString = "%s produces %d %s." % (unitid(unit), itemnames[1][i])
                addevent(unit.faction, eventString)

    print "Processing STUDY orders..."
    for region in regions:
        if region.terrain != T_OCEAN:
            for unit in region.units:
                ordernum = findkeyword(unit.thisorder)
                if ordernum == K_STUDY:
                    orderBits = unit.thisorder.split()
                    print "Processing study order for %s: %s" % (unitid(unit), unit.thisorder)
                    if len(orderBits) == 1:
                        mistake2(unit, orderString, "Need to specify what skill to study")
                        continue

                    skillnum = findskill(orderBits[1])
                    if skillnum < 0:
                        mistake2(unit, unit.thisorder, "Skill '%s' not recognised" % orderBits[1])
                        continue
                    
                    if skillnum == SK_TACTICS or skillnum == SK_MAGIC:
                        if unit.money < STUDYCOST * unit.number:
                            mistake2(unit, orderString, "Insufficient funds")
                            continue
                        if skillnum == SK_MAGIC and not unit.skills[SK_MAGIC] and \
                            magicians(unit.faction) + unit.number > 3:
                            mistake2(unit, orderString, "Only 3 magicians per faction")
                            continue
                        unit.money -= STUDYCOST * unit.number

                    eventString = "%s studies %s." % (unitid(unit), skillnames[skillnum])
                    addevent(unit.faction, eventString)

                    unit.skills[skillnum] += (unit.number * 30) + unit.learning

    print "Processing CAST orders..."
    for region in regions:
        for unit in region.units:
            for i in range(MAXSPELLS):
                if unit.spells[i] and spelllevel[i] > (effskill(unit, SK_MAGIC) + 1) / 2:
                    unit.spells[i] = 0
            if unit.combatspell >= 0 and not cancast(unit, unit.combatspells):
                unit.combatspell = -1
        
        if region.terrain != T_OCEAN:
            for unit in region.units:
                unit.teleportto = None
                ordernum = findkeyword(unit.thisorder)
                if ordernum == K_CAST:
                    orderBits = unit.thisorder.split()
                    if len(orderBits) == 1:
                        mistakeu(unit, "Need to specify what spell to cast")
                        continue
                    i = findspell(bits[1])
                    if i < 0 or not cancast(unit, i):
                        mistakeu(unit, "Spell not found")
                        continue

                    j = spellitem(i)
                    if j >= 0:
                        if unit.money < 200 * spelllevel[i]:
                            mistakeu(unit, "Insufficient funds")
                            continue

                        n = min(unit.number, unit.money / (200 * spelllevel[i]))
                        unit.items[j] += n
                        unit.money -= n * 200 * spelllevel[i]
                        unit.skills[SK_MAGIC] += n * 10

                        eventString = "%s casts %s." % (unitid(unit), spellnames[i])
                        addevent(unit.faction, eventString)
                        continue

                    if unit.money < 50:
                        mistakeu(unit, "Insufficient funds")
                        continue

                    if i == SP_CONTAMINATE_WATER:
                        n = cancast(unit, SP_CONTAMINATE_WATER)
                        n = min(n, unit.money/50)

                        unit.money -= n * 50
                        unit.skills[SK_MAGIC] += n * 10

                        n = lovar(n*50)
                        n = min(n, region.peasants)
                        if not n:
                            break

                        region.peasants -= n

                        for faction in factions:
                            j = cansee(faction, region, unit)
                            if j:
                                if j == 2:
                                    eventString = ("%s contaminates the water supply "
                                                   " in %s, causing %d peasants to die.") % \
                                                   (unitid(unit), regionid(region), n)
                                else:
                                    eventString = ("%d peasants die in %s from "
                                                   "drinking contaminated water.") % \
                                                   (n, regionid(region))
                                addevent(faction, eventString)
                    
                    elif i == SP_TELEPORT:
                        if len(orderBits) < 3:
                            mistakeu(unit, "You need to specify a unit to teleport to.")
                            continue
                        if len(orderBits) < 4:
                            mistakeu(unit, "You need to specify units to teleport!")
                            continue
                        unitnum = orderBits[2]
                        unit2 = findunitg(region, unitnum)
                        if not unit2:
                            mistakeu(unit, "Unit not found")
                            continue
                        if not admits(unit2, unit):
                            mistakeu(unit, "Target unit does not provide vector")
                            continue
                        region2 = unit2.region
                        
                        n = cancast(unit, SP_TELEPORT)
                        n = min(n, unit.money/50)
                        unit.money -= n * 50
                        unit.skills[SK_MAGIC] += n * 10

                        n *= 10000
                        for unitString in orderBits[3:]:
                            unit3 = getunit(region, unit, unitString)

                            # TODO: remove evil global
                            if getunit0:
                                break

                            if not unit3:
                                mistakeu(unit, "Unit %s not found" % unitString)
                                continue

                            if not accepts(unit3, unit):
                                mistakeu(unit, "Unit does not accept teleportation")
                                continue

                            i = itemweight(unit3) + horseweight(unit3) + (unit.number * 10)
                            if i > n:
                                mistakeu(unit, "Unit %s is too heavy" % unitString)
                                continue

                            leave(region, unit3)
                            n -= i
                            unit.moveto = region2
                            #region.units.remove(unit3)
                            #region2.units.append(unit3)
                            unit3.building = unit2.building
                            unit3.ship = unit2.ship

                        eventString = "%s casts Teleport." % unitid(unit)
                        addevent(unit.faction, eventString)
                        continue

                    else:
                        mistakeu(unit, "Spell %s not usable with CAST command")
            
            #print "Cleaning up teleporting units..."
            for unit in region.units:
                if unit.moveto:
                    region.units.remove(unit)
                    unit.moveto.units.append(unit)
                    unit.moveto = None
                    

    print "Processing demographics..."
    for region in regions:
        if region.terrain != T_OCEAN:
            peasantGrowth = region.peasants * POPGROWTH/100.0
            peasantGrowthMod = ((rnd() % 100) / 20.0) - 2.0
            region.peasants += int( peasantGrowth * (1 + peasantGrowthMod))
            
            n = region.money / MAINTENANCE
            region.peasants = min(region.peasants, n)
            region.money -= region.peasants * MAINTENANCE

            peasantMove = int( region.peasants * (PEASANTMOVE / 100.0) )
            peasantMove = peasantMove / 4
            for dir in range(4):
                if region.connect[dir].terrain != T_OCEAN:
                    region.peasants -= peasantMove
                    region.connect[dir].immigrants += peasantMove
       
        for unit in region.units:
            getmoney(region, unit, unit.number*MAINTENANCE)
            n = unit.money/MAINTENANCE

            if unit.number > n:
                if n:
                    eventString = "%s loses %d to starvation." % (unitid(unit), unit.number - n)
                else:
                    eventString = "%s starves to death." % unitid(unit)
                addevent(unit.faction, eventString)
                for i in range(MAXSKILLS):
                    unit.skills[i] = distribute(unit.number, n, unit.skills[i])
                unit.number = n

            unit.money -= unit.number * MAINTENANCE
    
    removeempty()

    for region in regions:
        region.peasants += region.immigrants

    for faction in factions:
        if turn - int(faction.lastorders) == ORDERGAP:
            faction.messages.append("Please send orders next turn if you wish to continue playing.")


def splitList(theList, function):
    """ If function returns True for a particular item in the list,
        then that item is the start of a new split. """
    output = []
    temp = []
    for item in theList:
        if function(item):
            if temp != []:
                output.append(temp)
            temp = []
        temp.append(item)
    # catch the last parts if necessary
    if temp != []:
        output.append(temp)
    return output


def isPlayerLine(line):
    return line.startswith("Faction:")

# A mapping of players.in values to faction values
playersLookup = {
    'Faction' : 'no',
    'Name' : 'name',
    'Email' : 'addr',
    'Password' : 'password',
    'LastOrders' : 'lastorders',
    # These two don't seem to be used by v1...
    #'SendTimes' : '',
    #'Template' : '',
}

def readplayers(fileName):
    """ Read the players.in file (and create player classes?)"""
    # Read in the players file, split it up and drop the first bit
    playerList = splitList(open(fileName).readlines(), isPlayerLine)[1:]
    
    for chunk in playerList:
        # First, we read the info from the chunk into a dict for ease of access
        playerDict = {}
        for line in chunk:
            if ':' not in line:
                print "Can't parse", line
                continue
            key, value = line.split(':')
            if key in playersLookup.keys():
                attrib = playersLookup[key]
                playerDict[attrib] = value.strip()
        print "playerDict is now:", playerDict

        # Find the player
        factionNo =  playerDict['no']
        if factionNo == 'new':
            addplayer(playerDict['name'], playerDict['addr'], playerDict['password'])
        else:
            print "Looking for faction %s ..." % factionNo
            faction = findfaction(factionNo)
            if not faction:
                print "Error! Can't find faction %s!", factionNo
                # Testing: create new faction
                #addplayer(playerDict['name'], playerDict['addr'], playerDict['password'])
                continue
            
            # we've found the player - now we just need to update their info
            for attrib in ['name', 'addr', 'password', 'lastorders']:
                if attrib not in playerDict.keys():
                    print "Error! Possible corrupted players.in file for faction", faction.no
                playersvalue = playerDict[attrib].strip()
                setattr(faction, attrib, playersvalue)

def writeplayers(fileName):
    """ write the players file out """
    output = ("AtlantisPlayerStatus|Version: 327680|TurnNumber: %d|GameStatus: Running|"%turn).split('|')
    for faction in factions:
        output.append("Faction: %s" % faction.no)
        for attrib in ['Name', 'Email', 'Password', 'LastOrders']:
            if attrib == 'Faction':
                continue
            output.append("%s: %s" % (attrib, getattr(faction, playersLookup[attrib])))
    
    playersFile = open(fileName, 'w')
    for line in output:
        playersFile.write(line + '\n')
    playersFile.close()


def rstrlist(fileObject, list, debug):
    """ Read strings into the list, one per line """
    numStrings = int(fileObject.readline().strip())
    if debug: print "", numStrings, "strings"
    for i in range(numStrings):
        list.append(fileObject.readline().strip())
        if debug:
            print " read: ", list[-1]

def readgame(fileName, debug=False):
    """ Read the game state in from a file """
    global turn

    gameFile = open(fileName)
    if debug: print "Reading %s..." % fileName

    turn = int(gameFile.readline().strip())
    if debug: print "turn", turn
    
    numFacs = int(gameFile.readline().strip())
    if debug: print "%s factions" % numFacs

    for n in range(numFacs):
        f = Faction()
        
        line = gameFile.readline().strip().split("|")
        if debug: print " ",line

        f.no = int(line[0])
        f.name = line[1]
        f.addr = line[2]
        f.lastorders = int(line[3])

        for i in range(MAXSPELLS):
            f.showdata[i] = int(line[i+4])

        numAllies = int(gameFile.readline().strip())
        if debug: print "", numAllies, "allies"
        if numAllies:
            allies = gameFile.readline().strip().split("|")
            if debug: print " ",allies
            for n2 in range(numAllies):
                rf = RFaction()
                rf.factionno = int(allies[n2])
                f.allies.append(rf)
        
        rstrlist(gameFile, f.mistakes, debug)
        rstrlist(gameFile, f.messages, debug)
        rstrlist(gameFile, f.battles, debug)
        rstrlist(gameFile, f.events, debug)

        factions.append(f)

    # Read regions

    numRegions = int(gameFile.readline().strip())
    if debug: print "numRegions:", numRegions

    for n in range(numRegions):
        r = Region()
        line = gameFile.readline().strip().split("|")
        if debug: print line

        r.x = int(line[0])
        r.y = int(line[1])
        r.name = line[2]
        r.terrain = int(line[3])
        r.peasants = int(line[4])
        r.money = int(line[5])
        r.units = []

        regions.append(r)

        numBuildings = int(gameFile.readline().strip())
        if debug: print "numBuildings:", numBuildings,
        for n2 in range(numBuildings):
            b = Building()

            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            b.no = int(line[0])
            b.name = line[1]
            b.display = line[2]
            b.size = int(line[3])
            r.buildings.append(b)

        numShips = int(gameFile.readline().strip())
        if debug: print "numShips:", numShips,
        for n2 in range(numShips):
            sh = Ship()
            
            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            sh.no = int(line[0])
            sh.name = line[1]
            sh.display = line[2]
            sh.type = int(line[3])
            sh.left = int(line[4])
            
            region.ships.append(sh)

        numUnits = int(gameFile.readline().strip())
        if debug: print "numUnits:", numUnits
        for n2 in range(numUnits):
            u = Unit()

            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            u.no = int(line[0])
            u.name = line[1]
            u.display = line[2]
            u.number = int(line[3])
            u.money = int(line[4])
            if debug: print "*** unit %s money is $%s" % (u.no, u.money)
            u.faction = findfaction( int(line[5]) )
            u.building = findbuilding( int(line[6]) )
            u.ship = findship( int(line[7]) )
            u.owner = int(line[8])
            u.behind = int(line[9])
            u.guard = int(line[10])
            u.lastorder = line[11]
            u.combatspell = int(line[12])

            for i in range(MAXSKILLS):
                u.skills[i] = int(line[13+i])

            for i in range(MAXITEMS):
                u.items[i] = int(line[13+MAXSKILLS+i])

            for i in range(MAXSPELLS):
                u.spells[i] = int(line[13+MAXSKILLS+MAXITEMS+i])

            r.units.append(u)

    # Get rid of stuff that was only relevant last turn
    for f in factions:
        f.showdata = [0] * MAXSPELLS
        
        f.mistakes = []
        f.messages = []
        f.battles = []
        f.events = []

    # link rfaction structures
    for f in factions:
        for rf in f.allies:
            rf.faction = findfaction(rf.factionno)

    for r in regions:
        # Initialize faction seendata values
        for u in r.units:
            if u.spells[i]:
                u.faction.seendata[i] = 1

            # Check for alive factions
            u.faction.alive = 1

    connectregions()
    gameFile.close()



def wstrlist(fileObject, S):
    """ Write the list of strings out to the fileObject, one per line """
    fileObject.write( str(len(S)) )
    fileObject.write("\n")
    for item in S:
        fileObject.write(item)
        fileObject.write("\n")


def writegame(fileName):
    """ Write the game state out to a data file """
    global turn
    gameFile = open(fileName, "w")
    print "Writing turn %d" % turn

    write = gameFile.write
    
    write(str(turn))
    write('\n')
    
    # write factions

    write(str(len(factions)))
    write('\n')

    for f in factions:
        write(str(f.no))
        write("|")
        write(f.name)
        write("|")
        write(f.addr)
        write("|")
        write(str(f.lastorders))

        for i in range(MAXSPELLS):
            write("|")
            write(str(f.showdata[i]))
        write("\n")

        write(str(len(f.allies)))
        write("\n")
        for rf in f.allies:
            write(str(rf.faction.no))
            write("\n")
        
        wstrlist(gameFile, f.mistakes)
        wstrlist(gameFile, f.messages)
        wstrlist(gameFile, f.battles)
        wstrlist(gameFile, f.events)

    # Write regions

    write(str(len(regions)))
    write("\n")
    for r in regions:
        write(str(r.x))
        write("|")
        write(str(r.y))
        write("|")
        write(r.name)
        write("|")
        write(str(r.terrain))
        write("|")
        write(str(r.peasants))
        write("|")
        write(str(r.money))
        write("\n")

        write(str(len(r.buildings)))
        write("\n")

        for b in r.buildings:
            write(str(b.no))
            write("|")
            write(b.name)
            write("|")
            write(b.display)
            write("|")
            write(str(b.size))
            write("\n")

        write(str(len(r.ships)))
        write("\n")

        for sh in r.ships:
            write(str(sh.no))
            write("|")
            write(sh.name)
            write("|")
            write(sh.display)
            write("|")
            write(str(sh.type))
            write("|")
            write(str(sh.left))
            write("\n")
        
        write(str(len(r.units)))
        write("\n")

        for u in r.units:
            write(str(u.no))
            write("|")
            write(u.name)
            write("|")
            write(u.display)
            write("|")
            write(str(u.number))
            write("|")
            write(str(u.money))
            write("|")
            write(str(u.faction.no))
            write("|")
            if u.building:
                write(str(u.building.no))
            else:
                write("0")
            write("|")
            if u.ship:
                write(str(u.ship.no))
            else:
                write("0")
            write("|")
            write(str(u.owner))
            write("|")
            write(str(u.behind))
            write("|")
            write(str(u.guard))
            write("|")
            write(u.lastorder)
            write("|")
            write(str(u.combatspell))

            for i in range(MAXSKILLS):
                write("|")
                write(str(u.skills[i]))

            for i in range(MAXITEMS):
                write("|")
                write(str(u.items[i]))

            for i in range(MAXSPELLS):
                write("|")
                write(str(u.spells[i]))

            write("\n")


def addunits():
    region = inputregion()
    if not region:
        return

    unitsFileName = raw_input("Name of units file? ")
    if not unitsFileName:
        return

    unitsFile = open(unitsFileName)

    while 1:
        line = unitsFile.readline().strip()
        if line.endswith("end"):
            return

        u = createunit(r)
        bits = line.split()
        u.name = bits[0]
        u.display = bits[1]
        u.number = int(bits[2])
        u.money = int(bits[3])
        u.faction = findfaction( int(bits[4]) )

        line = unitsFile.readline().strip()
        if line.endswith("end"):
            return
        line = line.split()
        while 1:
            try:
                j = line.pop(0)
                thingyName = line.pop(0)
            except IndexError:
                break
            
            if thingyName in skillnames:
                i = skillnames.index(thingyName)
                u.skills[i] = j
            elif thingyName in itemnames[0]:
                i = itemnames[0].index(thingyName)
                u.items[i] = j
            elif thingyName in spellnames:
                i = spellnames.index(thingyName)
                u.spells[i] = j
            else:
                print "Attribute %s not recognised" % thingyName


def initgame():
    """ Initialise the game
        NB: this is an old, deprecated function """
    global turn
    
    files = os.listdir('.')
    
    if 'data' not in files:
        print "No data files found, creating game..."
        os.mkdir("data")
        makeblock(0,0)
        writesummary()
        writegame('data/0')
    else:
        turn = 0
        
        # TODO: not sure about this bit - the files might be (eg.) 1.txt
        #       and still work with atoi
        files = [fileName for fileName in os.listdir('data') if fileName.isdigit()]
        files.sort()
        latest = files[-1]
        readgame(latest) #, debug=True)


def missingGameFiles():
    files = os.listdir('.')
    missingFiles = [fileName for fileName in ['players.in', 'game.in'] if fileName not in files]
    return missingFiles

def existingOutputFiles():
    files = os.listdir('.')
    existingFiles = [fileName for fileName in ['players.out', 'game.out'] if fileName in files]
    existingReports = [fileName for fileName in files if fileName.startswith('report.')]
    return existingFiles + existingReports

def loadgame():
    """ Read an existing game """
    # First, check for missing files, and that there's nothing going to block our output
    # TODO: Perhaps output should be on actual output, but then the game might take a while to run...
    files = os.listdir('.')
    missing = missingGameFiles()
    if missing:
        raise ValueError("Input files not found: %s" % ', '.join(missing))
    existing = existingOutputFiles()
    if existing:
        raise ValueError("Old output files blocking me: %s" % ', '.join(existing))

    # now we can do stuff
    readgame('game.in')
    readplayers('players.in')

def newgame():
    """ Create a new game """
    global turn
    turn = 0
    existing = existingOutputFiles()
    if existing:
        raise ValueError("Old output files blocking me: %s" % ', '.join(existing))
    makeblock(0,0)

    
def processturn():
    """ Run a turn """
    global turn
    turn += 1
    readorders()
    processorders()
    reports()
    #writesummary()
    #writegame('game.out')
    #writeplayers('players.out')


# TODO: createcontinent seems broken - it's meant to create separate continents,
#       but they all seem to be smooshed together with old ones.
#       (see halfway down http://www.prankster.com/project/docs/history.htm for how it should look)

# UPDATE: it seems to work ok, provided that there isn't already a continent already there,
#         so the bug is in makeblock, rather than createcontinent

# UPDATE2: The bug was that it was possible to create a continent on top of another one;
#          the smooshed together continent was actually two together. 
#          Now we check for an existing one and deny if it exists...

def createcontinent():
    """ Make a continent """
    
    writemap(sys.stdout)

    while 1:
        temp = raw_input("X? ")
        if temp == "":
            return
        x = atoi(temp)

        temp = raw_input("Y? ")
        if temp == "":
            return
        y = atoi(temp)
        
        makeblock(x, y)
        
        # TODO: this was writing to F, but should write to stdout or a file,
        #       and it should be fed the relevant object
        writemap(sys.stdout)


def printhelp():
    print ("n - Create a new game.\n"
           "r - read an existing game.\n"
           "c - Create New Continent.\n"
           "a - Add New Players.\n"
           "u - Add New Units.\n"
           "m - Show map.\n"
           "p - Process Game Turn.\n"
           "s - Save Game.\n"
           "q - Quit.\n"
           "\n"
           "Debug:\n"
           "l - list regions")


def main():
    """ The main loop - lets the GM control the game """
    random.seed()
    print ("PyAtlantis v0.1 by Anthony Briggs\n"
           "based on the original Atlantis v1.0,\n"
           "which is Copyright 1993 by Russell Wallace.\n"
           "Type ? for list of commands.")
    
    while 1:
        input = raw_input(">").lower()
        if input == 'c':
            createcontinent()
        elif input == 'a':
            addplayers()
        elif input == 'u':
            addunits()
        elif input == 'p':
            processturn()
        elif input == 'n':
            newgame()
        elif input == 'r':
            loadgame()

        # These are debugging functions
        elif input == 's':
            writesummary()
            writegame('game.out')
            writeplayers('players.out')
        elif input == 'm':
            writemap(sys.stdout)
        elif input == 'l':
            print regions
        elif input == 'f':
            print '\n'.join(['%s\t%s\t%s'%(f.no,f.name.rjust(30),f.addr) for f in factions])

        elif input == 'q':
            break
        else:
            printhelp()


def main2():
    """ Another main loop - this one's meant to be compatible with the 
        Atlantis v4 interface:
    
    void usage()
    {
        Awrite("atlantis new");
        Awrite("atlantis run");
        Awrite("atlantis edit");
        Awrite("");
        Awrite("atlantis map <type> <mapfile>");
        Awrite("atlantis mapunits");
        Awrite("atlantis genrules <introfile> <cssfile> <rules-outputfile>");
        Awrite("");
        Awrite("atlantis check <orderfile> <checkfile>");
    }
    """
    args = sys.argv
    
    if len(args) == 1:
        # assume interactive mode?
        main()
        
    elif args[1] == 'interactive':
        main()

    elif args[1] == 'new':
        random.seed()
        newgame()
        writesummary()
        writegame('game.out')
        writeplayers('players.out')

    elif args[1] == 'run':
        random.seed()
        loadgame()
        processturn()
        writesummary()
        writegame('game.out')
        writeplayers('players.out')

    elif args[1] == 'check':
        if len(args) != 4:
            print "Check needs report file and check file specified!"
        checkFile = open(args[3], 'w')
        checkFile.write("Sorry, order checking is not yet implemented\n")
        checkFile.close()
    
    elif args[1] == 'map':
        loadgame()
        sys.stdout.write("Map:\n\n")
        writemap(sys.stdout)
    
    elif args[1] == 'edit':
        print "Edit not yet implemented"

        
if __name__ == '__main__':
    main2()

