#!/usr/bin/env python

"""

Atlantis v1.0 -- The Python Remix
(C) 2007 Anthony Briggs, based on the original C version by Russel Wallace:

/*    Atlantis v1.0  13 September 1993
    Copyright 1993 by Russell Wallace

    This program may be freely used, modified and distributed.  It may not be
    sold or used commercially without prior written permission from the author.
*/

UPDATE: Geoff Dunbar has released the Atlantis source code under the GPL. 
        See the license/announcement at http://www.prankster.com/project/license.htm

v0.1alpha -- This is pretty much a direct translation - not much effort has 
             been made to 'pythonify' the code except where absolutely
             necessary (eg. input, removing globals (in places) and file
             handling). Getting the game working first takes top priority.

             Bugs fixed so far in the original code:
              - you can now have more RINGs than men and still be invisible
              - you can't create a continent on top of another continent
"""
import os
import random
import sys


#define    NAMESIZE                    81
#define    DISPLAYSIZE                161
NAMESIZE = 81
DISPLAYSIZE = 161

# Simple C functions - TODO: convert these later
#define    addlist2(l,p)            (*l = p, l = &p->next)
#define    min(a,b)                    ((a) < (b) ? (a) : (b))
#define    max(a,b)                    ((a) > (b) ? (a) : (b))
#define    xisdigit(c)                ((c) == '-' || ((c) >= '0' && (c) <= '9'))
#define    addptr(p,i)                ((void *)(((char *)p) + i))

ORDERGAP = 4
BLOCKSIZE = 7
BLOCKBORDER = 1
MAINTENANCE = 10
STARTMONEY = 5000
RECRUITCOST = 50
RECRUITFRACTION = 4
ENTERTAININCOME = 20
ENTERTAINFRACTION = 20
TAXINCOME = 200
COMBATEXP = 10
PRODUCEEXP = 10
TEACHNUMBER = 10
STUDYCOST = 200
POPGROWTH = 5
PEASANTMOVE = 5


for value, item in enumerate([ 
    "T_OCEAN",
    "T_PLAIN",
    "T_MOUNTAIN",
    "T_FOREST",
    "T_SWAMP",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SH_LONGBOAT",
    "SH_CLIPPER",
    "SH_GALLEON",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SK_MINING",
    "SK_LUMBERJACK",
    "SK_QUARRYING",
    "SK_HORSE_TRAINING",
    "SK_WEAPONSMITH",
    "SK_ARMORER",
    "SK_BUILDING",
    "SK_SHIPBUILDING",
    "SK_ENTERTAINMENT",
    "SK_STEALTH",
    "SK_OBSERVATION",
    "SK_TACTICS",
    "SK_RIDING",
    "SK_SWORD",
    "SK_CROSSBOW",
    "SK_LONGBOW",
    "SK_MAGIC",
    "MAXSKILLS",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "I_IRON",
    "I_WOOD",
    "I_STONE",
    "I_HORSE",
    "I_SWORD",
    "I_CROSSBOW",
    "I_LONGBOW",
    "I_CHAIN_MAIL",
    "I_PLATE_ARMOR",
    "I_AMULET_OF_DARKNESS",
    "I_AMULET_OF_DEATH",
    "I_AMULET_OF_HEALING",
    "I_AMULET_OF_TRUE_SEEING",
    "I_CLOAK_OF_INVULNERABILITY",
    "I_RING_OF_INVISIBILITY",
    "I_RING_OF_POWER",
    "I_RUNESWORD",
    "I_SHIELDSTONE",
    "I_STAFF_OF_FIRE",
    "I_STAFF_OF_LIGHTNING",
    "I_WAND_OF_TELEPORTATION",
    "MAXITEMS",]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "SP_BLACK_WIND",
    "SP_CAUSE_FEAR",
    "SP_CONTAMINATE_WATER",
    "SP_DAZZLING_LIGHT",
    "SP_FIREBALL",
    "SP_HAND_OF_DEATH",
    "SP_HEAL",
    "SP_INSPIRE_COURAGE",
    "SP_LIGHTNING_BOLT",
    "SP_MAKE_AMULET_OF_DARKNESS",
    "SP_MAKE_AMULET_OF_DEATH",
    "SP_MAKE_AMULET_OF_HEALING",
    "SP_MAKE_AMULET_OF_TRUE_SEEING",
    "SP_MAKE_CLOAK_OF_INVULNERABILITY",
    "SP_MAKE_RING_OF_INVISIBILITY",
    "SP_MAKE_RING_OF_POWER",
    "SP_MAKE_RUNESWORD",
    "SP_MAKE_SHIELDSTONE",
    "SP_MAKE_STAFF_OF_FIRE",
    "SP_MAKE_STAFF_OF_LIGHTNING",
    "SP_MAKE_WAND_OF_TELEPORTATION",
    "SP_SHIELD",
    "SP_SUNFIRE",
    "SP_TELEPORT",
    "MAXSPELLS", ]):
    exec("%s = %s" % (item, value))

for value, item in enumerate([ 
    "K_ACCEPT",
    "K_ADDRESS",
    "K_ADMIT",
    "K_ALLY",
    "K_ATTACK",
    "K_BEHIND",
    "K_BOARD",
    "K_BUILD",
    "K_BUILDING",
    "K_CAST",
    "K_CLIPPER",
    "K_COMBAT",
    "K_DEMOLISH",
    "K_DISPLAY",
    "K_EAST",
    "K_END",
    "K_ENTER",
    "K_ENTERTAIN",
    "K_FACTION",
    "K_FIND",
    "K_FORM",
    "K_GALLEON",
    "K_GIVE",
    "K_GUARD",
    "K_LEAVE",
    "K_LONGBOAT",
    "K_MOVE",
    "K_NAME",
    "K_NORTH",
    "K_PAY",
    "K_PRODUCE",
    "K_PROMOTE",
    "K_QUIT",
    "K_RECRUIT",
    "K_RESEARCH",
    "K_RESHOW",
    "K_SAIL",
    "K_SHIP",
    "K_SINK",
    "K_SOUTH",
    "K_STUDY",
    "K_TAX",
    "K_TEACH",
    "K_TRANSFER",
    "K_UNIT",
    "K_WEST",
    "K_WORK",
    "MAXKEYWORDS",]):
    exec("%s = %s" % (item, value))


"""
typedef struct building
{
    struct building *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    int size;
    int sizeleft;
} building;
"""

class Building:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.size = 0
        self.sizeleft = 0

"""
typedef struct ship
{
    struct ship *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    char type;
    int left;
} ship;
"""

class Ship:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.type = ""
        self.left = 0

"""
typedef struct region
{
    struct region *next;
    int x,y;
    char name[NAMESIZE];
    struct region *connect[4];
    char terrain;
    int peasants;
    int money;
    building *buildings;
    ship *ships;
    unit *units;
    int immigrants;
} region;
"""

class Region:
    def __init__(self):
        self.next = None
        self.x = 0
        self.y = 0
        self.name = "void"
        self.connect = [None, None, None, None]
        self.terrain = 0
        self.peasants = 0
        self.money = 0
        self.buildings = []
        self.ships = []
        self.units = []
        self.immigrants = 0

"""
struct faction;

typedef struct rfaction
{
    struct rfaction *next;
    struct faction *faction;
    int factionno;
} rfaction;
"""

class RFaction:
    def __init__(self):
        self.next = None
        self.faction = None
        self.factionno = 0

"""
typedef struct faction
{
    struct faction *next;
    int no;
    char name[NAMESIZE];
    char addr[NAMESIZE];
    int lastorders;
    char seendata[MAXSPELLS];
    char showdata[MAXSPELLS];
    rfaction *accept;
    rfaction *admit;
    rfaction *allies;
    strlist *mistakes;
    strlist *messages;
    strlist *battles;
    strlist *events;
    char alive;
    char attacking;
    char seesbattle;
    char dh;
    int nunits;
    int number;
    int money;
} faction;
"""

class Faction:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.addr = ""
        self.lastorders = 0
        self.seendata = [0] * MAXSPELLS
        self.showdata = [0] * MAXSPELLS
        self.accept = []
        self.admit = []
        self.allies = []
        self.mistakes = []
        self.messages = []
        self.battles = []
        self.events = []
        self.alive = ""
        self.attacking = ""
        self.seesbattle = ""
        self.dh = ""
        self.nunits = 0
        self.number = 0
        self.money = 0

"""
struct unit
{
    struct unit *next;
    int no;
    char name[NAMESIZE];
    char display[DISPLAYSIZE];
    
    # number of men
    int number;
    int money;
    faction *faction;
    building *building;
    ship *ship;
    char owner;
    char behind;
    char guard;
    char thisorder[NAMESIZE];
    char lastorder[NAMESIZE];
    char combatspell;
    int skills[MAXSKILLS];
    int items[MAXITEMS];
    char spells[MAXSPELLS];
    strlist *orders;
    int alias;
    int dead;
    int learning;
    int n;
    int *litems;
    char side;
    char isnew;
};
"""

class Unit:
    def __init__(self):
        self.next = None
        self.no = 0
        self.name = ""
        self.display = ""
        self.number = 0
        self.money = 0
        self.faction = None
        self.building = None
        self.ship = None
        self.owner = 0
        self.behind = 0
        self.guard = 0
        self.thisorder = ""
        self.lastorder = ""
        self.combatspell = ""
        self.skills = [0] * MAXSKILLS
        self.items = [0] * MAXITEMS
        self.spells = [0] * MAXSPELLS
        self.orders = []
        self.alias = 0
        self.dead = 0
        self.learning = 0
        self.n = 0
        self.litems = []
        self.side = ""
        self.isnew = ""
 
"""
typedef struct order
{
    struct order *next;
    unit *unit;
    int qty;
} order;
"""

class Order:
    def __init__(self):
        self.next = None
        self.unit = None
        self.qty = 0

"""
typedef struct troop
{
    struct troop *next;
    unit *unit;
    int lmoney;
    char status;
    char side;
    char attacked;
    char weapon;
    char missile;
    char skill;
    char armor;
    char behind;
    char inside;
    char reload;
    char canheal;
    char runesword;
    char invulnerable;
    char power;
    char shieldstone;
    char demoralized;
    char dazzled;
} troop;
"""

class Troop:
    def __init__(self):
        self.next = None
        self.unit = None
        self.lmoney = 0
        self.status = ""
        self.side = ""
        self.attacked = ""
        self.weapon = ""
        self.missile = ""
        self.skill = ""
        self.armor = ""
        self.behind = ""
        self.inside = ""
        self.reload = ""
        self.canheal = ""
        self.runesword = ""
        self.invulnerable = ""
        self.power = ""
        self.shieldstone = ""
        self.demoralized = ""
        self.dazzled = ""


rndno = 0
# buf and buf2 seem to be used for string operations...
# Not sure, but they might be string arrays, rather than strings...
buf = ""
buf2 = ""
F = None

turn = 0
regions = []
factions = []


keywords = [
    "accept",
    "address",
    "admit",
    "ally",
    "attack",
    "behind",
    "board",
    "build",
    "building",
    "cast",
    "clipper",
    "combat",
    "demolish",
    "display",
    "east",
    "end",
    "enter",
    "entertain",
    "faction",
    "find",
    "form",
    "galleon",
    "give",
    "guard",
    "leave",
    "longboat",
    "move",
    "name",
    "north",
    "pay",
    "produce",
    "promote",
    "quit",
    "recruit",
    "research",
    "reshow",
    "sail",
    "ship",
    "sink",
    "south",
    "study",
    "tax",
    "teach",
    "transfer",
    "unit",
    "west",
    "work",
]

terrainnames = [
    "ocean",
    "plain",
    "mountain",
    "forest",
    "swamp",
]

regionnames = [
    "Aberaeron",
    "Aberdaron",
    "Aberdovey",
    "Abernethy",
    "Abersoch",
    "Abrantes",
    "Adrano",
    "AeBrey",
    "Aghleam",
    "Akbou",
    "Aldan",
    "Alfaro",
    "Alghero",
    "Almeria",
    "Altnaharra",
    "Ancroft",
    "Anshun",
    "Anstruther",
    "Antor",
    "Arbroath",
    "Arcila",
    "Ardfert",
    "Ardvale",
    "Arezzo",
    "Ariano",
    "Arlon",
    "Avanos",
    "Aveiro",
    "Badalona",
    "Baechahoela",
    "Ballindine",
    "Balta",
    "Banlar",
    "Barika",
    "Bastak",
    "Bayonne",
    "Bejaia",
    "Benlech",
    "Beragh",
    "Bergland",
    "Berneray",
    "Berriedale",
    "Binhai",
    "Birde",
    "Bocholt",
    "Bogmadie",
    "Braga",
    "Brechlin",
    "Brodick",
    "Burscough",
    "Calpio",
    "Canna",
    "Capperwe",
    "Caprera",
    "Carahue",
    "Carbost",
    "Carnforth",
    "Carrigaline",
    "Caserta",
    "Catrianchi",
    "Clatter",
    "Coilaco",
    "Corinth",
    "Corofin",
    "Corran",
    "Corwen",
    "Crail",
    "Cremona",
    "Crieff",
    "Cromarty",
    "Cumbraes",
    "Daingean",
    "Darm",
    "Decca",
    "Derron",
    "Derwent",
    "Deveron",
    "Dezhou",
    "Doedbygd",
    "Doramed",
    "Dornoch",
    "Drammes",
    "Dremmer",
    "Drense",
    "Drimnin",
    "Drumcollogher",
    "Drummore",
    "Dryck",
    "Drymen",
    "Dunbeath",
    "Duncansby",
    "Dunfanaghy",
    "Dunkeld",
    "Dunmanus",
    "Dunster",
    "Durness",
    "Duucshire",
    "Elgomaar",
    "Ellesmere",
    "Ellon",
    "Enfar",
    "Erisort",
    "Eskerfan",
    "Ettrick",
    "Fanders",
    "Farafra",
    "Ferbane",
    "Fetlar",
    "Flock",
    "Florina",
    "Formby",
    "Frainberg",
    "Galloway",
    "Ganzhou",
    "Geal Charn",
    "Gerr",
    "Gifford",
    "Girvan",
    "Glenagallagh",
    "Glenanane",
    "Glin",
    "Glomera",
    "Glormandia",
    "Gluggby",
    "Gnackstein",
    "Gnoelhaala",
    "Golconda",
    "Gourock",
    "Graevbygd",
    "Grandola",
    "Gresberg",
    "Gresir",
    "Greverre",
    "Griminish",
    "Grisbygd",
    "Groddland",
    "Grue",
    "Gurkacre",
    "Haikou",
    "Halkirk",
    "Handan",
    "Hasmerr",
    "Helmsdale",
    "Helmsley",
    "Helsicke",
    "Helvete",
    "Hoersalsveg",
    "Hullevala",
    "Ickellund",
    "Inber",
    "Inverie",
    "Jaca",
    "Jahrom",
    "Jeormel",
    "Jervbygd",
    "Jining",
    "Jotel",
    "Kaddervar",
    "Karand",
    "Karothea",
    "Kashmar",
    "Keswick",
    "Kielder",
    "Killorglin",
    "Kinbrace",
    "Kintore",
    "Kirriemuir",
    "Klen",
    "Knesekt",
    "Kobbe",
    "Komarken",
    "Kovel",
    "Krod",
    "Kursk",
    "Lagos",
    "Lamlash",
    "Langholm",
    "Larache",
    "Larkanth",
    "Larmet",
    "Lautaro",
    "Leighlin",
    "Lervir",
    "Leven",
    "Licata",
    "Limavady",
    "Lingen",
    "Lintan",
    "Liscannor",
    "Locarno",
    "Lochalsh",
    "Lochcarron",
    "Lochinver",
    "Lochmaben",
    "Lom",
    "Lorthalm",
    "Louer",
    "Lurkabo",
    "Luthiir",
    "Lybster",
    "Lynton",
    "Mallaig",
    "Mataro",
    "Melfi",
    "Melvaig",
    "Menter",
    "Methven",
    "Moffat",
    "Monamolin",
    "Monzon",
    "Morella",
    "Morgel",
    "Mortenford",
    "Mullaghcarn",
    "Mulle",
    "Murom",
    "Nairn",
    "Navenby",
    "Nephin Beg",
    "Niskby",
    "Nolle",
    "Nork",
    "Olenek",
    "Oloron",
    "Oranmore",
    "Ormgryte",
    "Orrebygd",
    "Palmi",
    "Panyu",
    "Partry",
    "Pauer",
    "Penhalolen",
    "Perkel",
    "Perski",
    "Planken",
    "Plattland",
    "Pleagne",
    "Pogelveir",
    "Porthcawl",
    "Portimao",
    "Potenza",
    "Praestbygd",
    "Preetsome",
    "Presu",
    "Prettstern",
    "Rantlu",
    "Rappbygd",
    "Rath Luire",
    "Rethel",
    "Riggenthorpe",
    "Rochfort",
    "Roddendor",
    "Roin",
    "Roptille",
    "Roter",
    "Rueve",
    "Sagunto",
    "Saklebille",
    "Salen",
    "Sandwick",
    "Sarab",
    "Sarkanvale",
    "Scandamia",
    "Scarinish",
    "Scourie",
    "Serov",
    "Shanyin",
    "Siegen",
    "Sinan",
    "Sines",
    "Skim",
    "Skokholm",
    "Skomer",
    "Skottskog",
    "Sledmere",
    "Sorisdale",
    "Spakker",
    "Stackforth",
    "Staklesse",
    "Stinchar",
    "Stoer",
    "Strichen",
    "Stroma",
    "Stugslett",
    "Suide",
    "Tabuk",
    "Tarraspan",
    "Tetuan",
    "Thurso",
    "Tiemcen",
    "Tiksi",
    "Tolsta",
    "Toppola",
    "Torridon",
    "Trapani",
    "Tromeforth",
    "Tudela",
    "Turia",
    "Uxelberg",
    "Vaila",
    "Valga",
    "Verguin",
    "Vernlund",
    "Victoria",
    "Waimer",
    "Wett",
    "Xontormia",
    "Yakleks",
    "Yuci",
    "Zaalsehuur",
    "Zamora",
    "Zapulla",
]

foodproductivity = [
    0,
    15,
    12,
    12,
    12,
]

maxfoodoutput = [
    0,
    100000,
    20000,
    20000,
    10000,
]

# I think these next ones are multiple-dimension arrays...
productivity = [
    [0,0,0,0,],
    [0,0,0,1,],
    [1,0,1,0,],
    [0,1,0,0,],
    [0,1,0,0,],
]

maxoutput = [
    [  0,  0,  0,  0,],
    [  0,  0,  0,200,],
    [200,  0,200,  0,],
    [  0,200,  0,  0,],
    [  0,100,  0,  0,],
]

shiptypenames = [
    "longboat",
    "clipper",
    "galleon",
]

shipcapacity = [
    200,
    800,
    1800,
]

shipcost = [
    100,
    200,
    300,
]

skillnames = [
    "mining",
    "lumberjack",
    "quarrying",
    "horse training",
    "weaponsmith",
    "armorer",
    "building",
    "shipbuilding",
    "entertainment",
    "stealth",
    "observation",
    "tactics",
    "riding",
    "sword",
    "crossbow",
    "longbow",
    "magic",
]

# TODO: not sure whether this one is right...
itemnames = [ [
    "iron",
    "wood",
    "stone",
    "horse",
    "sword",
    "crossbow",
    "longbow",
    "chain mail",
    "plate armor",
    "Amulet of Darkness",
    "Amulet of Death",
    "Amulet of Healing",
    "Amulet of True Seeing",
    "Cloak of Invulnerability",
    "Ring of Invisibility",
    "Ring of Power",
    "Runesword",
    "Shieldstone",
    "Staff of Fire",
    "Staff of Lightning",
    "Wand of Teleportation",],

    [
    "iron",
    "wood",
    "stone",
    "horses",
    "swords",
    "crossbows",
    "longbows",
    "chain mail",
    "plate armor",
    "Amulets of Darkness",
    "Amulets of Death",
    "Amulets of Healing",
    "Amulets of True Seeing",
    "Cloaks of Invulnerability",
    "Rings of Invisibility",
    "Rings of Power",
    "Runeswords",
    "Shieldstones",
    "Staffs of Fire",
    "Staffs of Lightning",
    "Wands of Teleportation",],
]


itemskill = [
    SK_MINING,
    SK_LUMBERJACK,
    SK_QUARRYING,
    SK_HORSE_TRAINING,
    SK_WEAPONSMITH,
    SK_WEAPONSMITH,
    SK_WEAPONSMITH,
    SK_ARMORER,
    SK_ARMORER,
]

rawmaterial = [
    0,
    0,
    0,
    0,
    I_IRON,
    I_WOOD,
    I_WOOD,
    I_IRON,
    I_IRON,
]

spellnames = [
    "Black Wind",
    "Cause Fear",
    "Contaminate Water",
    "Dazzling Light",
    "Fireball",
    "Hand of Death",
    "Heal",
    "Inspire Courage",
    "Lightning Bolt",
    "Make Amulet of Darkness",
    "Make Amulet of Death",
    "Make Amulet of Healing",
    "Make Amulet of True Seeing",
    "Make Cloak of Invulnerability",
    "Make Ring of Invisibility",
    "Make Ring of Power",
    "Make Runesword",
    "Make Shieldstone",
    "Make Staff of Fire",
    "Make Staff of Lightning",
    "Make Wand of Teleportation",
    "Shield",
    "Sunfire",
    "Teleport",
]

spelllevel = [
    4,
    2,
    1,
    1,
    2,
    3,
    2,
    2,
    1,
    5,
    4,
    3,
    3,
    3,
    3,
    4,
    3,
    4,
    3,
    2,
    4,
    3,
    5,
    3,
]

iscombatspell = [
    1,
    1,
    0,
    1,
    1,
    1,
    0,
    1,
    1,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    0,
]

spelldata = [
    "This spell creates a black whirlwind of energy which destroys all life, "
    "leaving frozen corpses with faces twisted into expressions of horror. Cast "
    "in battle, it kills from 2 to 1250 enemies.",

    "This spell creates an aura of fear which causes enemy troops in battle to "
    "panic. Each time it is cast, it demoralizes between 2 and 100 troops for "
    "the duration of the battle. Demoralized troops are at a -1 to their "
    "effective skill.",

    "This ritual spell causes pestilence to contaminate the water supply of the "
    "region in which it is cast. It causes from 2 to 50 peasants to die from "
    "drinking the contaminated water. Any units which end the month in the "
    "affected region will know about the deaths, however only units which have "
    "Observation skill higher than the caster's Stealth skill will know who "
    "was responsible. The spell costs $50 to cast.",

    "This spell, cast in battle, creates a flash of light which dazzles from 2 "
    "to 50 enemy troops. Dazzled troops are at a -1 to their effective skill "
    "for their next attack.",

    "This spell enables the caster to hurl balls of fire. Each time it is cast "
    "in battle, it will incinerate between 2 and 50 enemy troops.",

    "This spell disrupts the metabolism of living organisms, sending an "
    "invisible wave of death across a battlefield. Each time it is cast, it "
    "will kill between 2 and 250 enemy troops.",

    "This spell enables the caster to attempt to heal the injured after a "
    "battle. It is used automatically, and does not require use of either the "
    "COMBAT or CAST command. If one's side wins a battle, a number of  "
    "casualties on one's side, between 2 and 50, will be healed. (If this "
    "results in all the casualties on the winning side being healed, the winner "
    "is still eligible for combat experience.)",

    "This spell boosts the morale of one's troops in battle. Each time it is "
    "cast, it cancels the effect of the Cause Fear spell on a number of one's "
    "own troops ranging from 2 to 100.",

    "This spell enables the caster to throw bolts of lightning to strike down "
    "enemies in battle. It kills from 2 to 10 enemies.",

    "This spell allows one to create an Amulet of Darkness. This amulet allows "
    "its possessor to cast the Black Wind spell in combat, without having to "
    "know the spell; the only requirement is that the user must have the Magic "
    "skill at 1 or higher. The Black Wind spell creates a black whirlwind of "
    "energy which destroys all life. Cast in battle, it kills from 2 to 1250 "
    "people. The amulet costs $1000 to make.",

    "This spell allows one to create an Amulet of Death. This amulet allows its "
    "possessor to cast the Hand of Death spell in combat, without having to "
    "know the spell; the only requirement is that the user must have the Magic "
    "skill at 1 or higher. The Hand of Death spell disrupts the metabolism of "
    "living organisms, sending an invisible wave of death across a battlefield. "
    "Each time it is cast, it will kill between 2 and 250 enemy troops. The "
    "amulet costs $800 to make.",

    "This spell allows one to create an Amulet of Healing. This amulet allows "
    "its possessor to attempt to heal the injured after a battle. It is used "
    "automatically, and does not require the use of either the COMBAT or CAST "
    "command; the only requirement is that the user must have the Magic skill "
    "at 1 or higher. If the user's side wins a battle, a number of casualties "
    "on that side, between 2 and 50, will be healed. (If this results in all "
    "the casualties on the winning side being healed, the winner is still "
    "eligible for combat experience.) The amulet costs $600 to make.",

    "This spell allows one to create an Amulet of True Seeing. This allows its "
    "possessor to see units which are hidden by Rings of Invisibility. (It has "
    "no effect against units which are hidden by the Stealth skill.) The amulet "
    "costs $600 to make.",

    "This spell allows one to create a Cloak of Invulnerability. This cloak "
    "protects its wearer from injury in battle; any attack with a normal weapon "
    "which hits the wearer has a 99.99% chance of being deflected. This benefit "
    "is gained instead of, rather than as well as, the protection of any armor "
    "worn; and the cloak confers no protection against magical attacks. The "
    "cloak costs $600 to make.",

    "This spell allows one to create a Ring of Invisibility. This ring renders "
    "its wearer invisible to all units not in the same faction, regardless of "
    "Observation skill. For a unit of many people to remain invisible, it must "
    "possess a Ring of Invisibility for each person. The ring costs $600 to "
    "make.",

    "This spell allows one to create a Ring of Power. This ring doubles the "
    "effectiveness of any spell the wearer casts in combat, or any magic item "
    "the wearer uses in combat. The ring costs $800 to make.",

    "This spell allows one to create a Runesword. This is a black sword with "
    "magical runes etched along the blade. To use it, one must have both the "
    "Sword and Magic skills at 1 or higher. It confers a bonus of 2 to the "
    "user's Sword skill in battle, and also projects an aura of power that has "
    "a 50% chance of cancelling any Fear spells cast by an enemy magician. The "
    "sword costs $600 to make.",

    "This spell allows one to create a Shieldstone. This is a small black "
    "stone, engraved with magical runes, that creates an invisible shield of "
    "energy that deflects hostile magic in battle. The stone is used "
    "automatically, and does not require the use of either the COMBAT or CAST "
    "commands; the only requirement is that the user must have the Magic skill "
    "at 1 or higher. Each round of combat, it adds one layer to the shielding "
    "around one's own side. When a hostile magician casts a spell, provided "
    "there is at least one layer of shielding present, there is a 50% chance of "
    "the spell being deflected. If the spell is deflected, nothing happens. If "
    "it is not, then it has full effect, and one layer of shielding is removed. "
    "The stone costs $800 to make.",

    "This spell allows one to create a Staff of Fire. This staff allows its "
    "possessor to cast the Fireball spell in combat, without having to know the "
    "spell; the only requirement is that the user must have the Magic skill at "
    "1 or higher. The Fireball spell enables the caster to hurl balls of fire. "
    "Each time it is cast in battle, it will incinerate between 2 and 50 enemy "
    "troops. The staff costs $600 to make.",

    "This spell allows one to create a Staff of Lightning. This staff allows "
    "its possessor to cast the Lightning Bolt spell in combat, without having "
    "to know the spell; the only requirement is that the user must have the "
    "Magic skill at 1 or higher. The Lightning Bolt spell enables the caster to "
    "throw bolts of lightning to strike down enemies. It kills from 2 to 10 "
    "enemies. The staff costs $400 to make.",

    "This spell allows one to create a Wand of Teleportation. This wand allows "
    "its possessor to cast the Teleport spell, without having to know the "
    "spell; the only requirement is that the user must have the Magic skill at "
    "1 or higher. The Teleport spell allows the caster to move himself and "
    "others across vast distances without traversing the intervening space. The "
    "command to use it is CAST TELEPORT target-unit unit-no ... The target unit "
    "is a unit in the region to which the teleport is to occur. If the target "
    "unit is not in your faction, it must be in a faction which has issued an "
    "ADMIT command for you that month. After the target unit comes a list of "
    "one or more units to be teleported into the target unit's region (this may "
    "optionally include the caster). Any units to be teleported, not in your "
    "faction, must be in a faction which has issued an ACCEPT command for you "
    "that month. The total weight of all units to be teleported (including "
    "people, equipment and horses) must not exceed 10000. If the target unit is "
    "in a building or on a ship, the teleported units will emerge there, "
    "regardless of who owns the building or ship. The caster spends the month "
    "preparing the spell and the teleport occurs at the end of the month, so "
    "any other units to be transported can spend the month doing something "
    "else. The wand costs $800 to make, and $50 to use.",

    "This spell creates an invisible shield of energy that deflects hostile "
    "magic. Each round that it is cast in battle, it adds one layer to the "
    "shielding around one's own side. When a hostile magician casts a spell, "
    "provided there is at least one layer of shielding present, there is a 50% "
    "chance of the spell being deflected. If the spell is deflected, nothing "
    "happens. If it is not, then it has full effect, and one layer of shielding "
    "is removed.",

    "This spell allows the caster to incinerate whole armies with fire brighter "
    "than the sun. Each round it is cast, it kills from 2 to 6250 enemies.",

    "This spell allows the caster to move himself and others across vast "
    "distances without traversing the intervening space. The command to use it "
    "is CAST TELEPORT target-unit unit-no ... The target unit is a unit in the "
    "region to which the teleport is to occur. If the target unit is not in "
    "your faction, it must be in a faction which has issued an ADMIT command "
    "for you that month. After the target unit comes a list of one or more "
    "units to be teleported into the target unit's region (this may optionally "
    "include the caster). Any units to be teleported, not in your faction, must "
    "be in a faction which has issued an ACCEPT command for you that month. The "
    "total weight of all units to be teleported (including people, equipment "
    "and horses) must not exceed 10000. If the target unit is in a building or "
    "on a ship, the teleported units will emerge there, regardless of who owns "
    "the building or ship. The caster spends the month preparing the spell and "
    "the teleport occurs at the end of the month, so any other units to be "
    "transported can spend the month doing something else. The spell costs $50 "
    "to cast.",
]


# TODO: Hmm, weird C functions. I'll skip over these for now, and work them out from context as I go
# ascii to integer - positive
# atoip (char *s)
def atoip(s):
    """ Convert a string into a positive integer.
        Slight detour from the original, in that if you try and convert 'a' (not an integer),
        you'll get 0 instead of an error."""
    try:
        number = int(s.strip())
        if n < 0:
            number = 0
    except:
        number = 0
    return number

# ascii to integer - positive
def atoi(s):
    """ Convert a string into an integer, with detour as per atoip """
    try:
        number = int(s.strip())
    except:
        number = 0
    return number


# string cat? Slap a string on the end of buf
def scat(s):
    """ Scat .... uhuhuhuhuhu uhuhhuuuuhuhuhuh :) """
    global buf
    buf = buf + s

def icat(n):
    scat(str(n))


def rnd():
    """ Return a big-ass random number """
    return random.randint(-sys.maxint,sys.maxint)


def effskill(unit, i):
    """ Determine the effective skill of a unit, dividing the total 
        number of days training by the number of men, and then 
        splitting into groups of 30 days, etc."""
    n = 0
    if unit.number:
        n = unit.skills[i] / unit.number
    j = 30
    result = 0
    
    while j <= n:
        n -= j;
        j += 30;
        result += 1
    
    return result


def ispresent(faction, region):
    """ Is the faction present in the region? """
    for unit in region.units:
        if unit.faction == faction:
            return True
    return False


def cansee(faction, region, unit):
    """ Can the faction see the unit in the region? """
    if unit.faction == faction:
        return 2

    cansee = 0
    if unit.guard or unit.building or unit.ship:
        return 1

    n = effskill(unit, SK_STEALTH)

    for unit2 in region.units:
        if unit2.faction != faction:
            continue
        
        # BUG: in the original C version, you had to have the exact i
        #      number of RING (ie. = unit.number, not >=)
        if (unit.items[I_RING_OF_INVISIBILITY] and
            unit.items[I_RING_OF_INVISIBILITY] >= unit.number and
            not unit2.items[I_AMULET_OF_TRUE_SEEING]):
               continue

        o = effskill(unit2, SK_OBSERVATION)
        if (o > n):
            return 2
        if (o >= n):
            cansee = 1

    return cansee


# TODO: more weird C functions?
# UPDATE: easier to modify the code which calls these functions (to use split, strip, etc.)
"""
# initial getstr (?) -- primes the s buffer (I think) and reads from buf
char *igetstr (char *s1)
{
    int i;
    static char *s;
    static char buf[256];

    if (s1)
        s = s1;
    while (*s == ' ')
        s++;
    i = 0;

    while (*s && *s != ' ')
    {
        buf[i] = *s;
        if (*s == '_')
            buf[i] = ' ';
        s++;
        i++;
    }

    buf[i] = 0;
    return buf;
}

# other getstr -- used once s1 haas already been primed
char *getstr (void)
{
    return igetstr (0);
}
"""

### These functions (geti, igetstr, getstr) all rely on evil global variables,
### and it's easier to convert the functions which call them to use something
### more sensible/less bug prone.

def geti():
    """ Get an integer from the user
        UPDATE: actually gets the next integer from buf via getstr..."""
    raise NotImplementedError, "The function you are using should not be calling geti!"
    
def igetstr():
    """ seed the buf global with a string and read the first string out """
    raise NotImplementedError, "The function you are using should not be calling igetstr!"
 
def getstr():
    """ get the next string from the global buf """
    raise NotImplementedError, "The function you are using should not be calling getstr!"


def findfaction(number):
    """ Find the faction with a certain number """
    for faction in factions:
        if faction.no == number:
            return faction
    return 0

def getfaction():
    raise NotImplementedError, "You should use findfaction instead!"


def findregion(x, y):
    """ Find the region with coordinates x,y """
    for region in regions:
        if region.x == x and region.y == y:
            return region
    return 0


def findbuilding(number):
    """ Given the number of a building, return the building """
    for region in regions:
        building = findbuildingregion(number, region)
        if building:
            return building
    return 0

def findbuildingregion(number, region):
    """ Find a building in a particular region """
    for building in region.buildings:
        if building.no == number:
            return building
    return 0

def getbuilding(region):
    """ Get a building, given input from the keyboard (?) """
    raise NotImplementedError, "You should use findbuilding or findbuildingregion instead!"


def findship(number):
    """ Return the ship with a particular number """
    for region in regions:
        for ship in region.ships:
            if ship.no == number:
                return ship
    return 0

def findshipregion(number, region):
    """ Return the ship with a particular number from a region """
    for ship in region.ships:
        if ship.no == number:
            return ship
    return 0

def getship(region):
    """ Find a ship, given a number entered by the user """
    raise NotImplementedError, "You should use findship or findshipregion instead!"


def findunitg(number):
    """ Find a unit by unit number (find unit global?)"""
    for region in regions:
        for unit in region.units:
            if unit.no == number:
                return unit
    return 0

def getnewunit(region, unit, number):
    """ Get a newly created unit, given the unit number in buf
        ie. the unit is referenced as 'new 1'
        
        This function requires an extra variable, 'number', 
        in order to work effectively. The previous C version 
        just pulled it from a global"""
    
    # TODO: is this bit going to hide bugs?
    if not number or not number.isdigit():
        return 0
    number = int(number)

    for unit2 in region.units:
        if unit2.faction == unit.faction and unit2.alias == number:
            return unit2
    return 0

def getunitg(region, unit):
    """ Get a unit from the region, given it's alias in buf"""
    raise NotImplementedError, "You should use findunitg, getunit or getnewunit instead!"

# TODO: remove these globals - they're used to return multiple values from getunit
getunit0 = 0
getunitpeasants = 0

def getunit(region, unit, unitNumber):
    """ Get a unit, given it's number, provided that the unit given can see it"""
    global getunitpeasants
    global getunit0

    getunit0 = 0
    getunitpeasants = 0
    
    if unitNumber.startswith("new "):
        # updated getnewunit, since raw_input() has eaten the input... :(
        # getnewunit now has an optional string input?
        return getnewunit(region, unit, s[4:])

    if region.terrain != T_OCEAN and not unitNumber.startswith("peasants"):
        getunitpeasants = 1
        return 0

    n = atoi(unitNumber)
    if n == 0:
        getunit0 = 1
        return 0

    for unit2 in region.units:
        if unit2.no == n and cansee(unit.faction, region, unit2) and not unit2.isnew:
            return unit2

    return 0


def findkeyword(string):
    """ Find a keyword in a string, 
        returning the index of the keyword in keywords """
    string = string.lower()
    if string == "describe":
        return K_DISPLAY
    if string == "n":
        return K_NORTH
    if string == "s":
        return K_SOUTH
    if string == "e":
        return K_EAST
    if string == "w":
        return K_WEST
    
    if string not in keywords:
        return -1
    return keywords.index(string)

def igetkeyword(string):
    """ Return the integer representation of the string? """
    raise NotImplementedError, "You should use findkeyword instead!"

def getkeyword(string):
    """ Is the next word in buf a keyword? """
    raise NotImplementedError, "You should use findkeyword instead!"


def findstr(string1, string2, n):
    try:
        pos = string1.index(string2)
        if pos > n:
            return -1
    except:
        return -1


def findskill(string):
    if string.startswith("horse"):
        return SK_HORSE_TRAINING
    if string.startswith("entertain"):
        return SK_ENTERTAINMENT

    return findstr(skillnames, string, MAXSKILLS)

def getskill():
    """ Find the skill from the next word in buf """
    raise NotImplementedError("You should use findskill instead!")


def finditem(string):
    if string.startswith("chain"):
        return I_CHAIN_MAIL
    if string.startswith("plate"):
        return I_PLATE_ARMOR

    i = findstr(itemnames[0], string, MAXITEMS)
    if (i >= 0):
        return i

    return findstr(itemnames[1], string, MAXITEMS)

def getitem():
    """ Find the item from the next word in buf """
    raise NotImplementedError("You should use finditem instead!")


def findspell(string):
    return findstr(spellnames, string, MAXSPELLS)

def getspell():
    """ Find the spell from the next word in buf """
    raise NotImplementedError("You should use findspell instead!")


def createunit(region):
    """ Create a new unit? """
    unit = Unit()
    unit.lastorder = "work"
    unit.combatspell = -1
    
    # TODO: not sure what the hell the C version is up to...
    # LATER: it's creating players from the players.in file...?
    #        players file is read in a different function
    #        1000 chars per unit?
    # UPDATE: I'm pretty sure now that it's just looking for 
    #         a free unit number
    n = 0
    v = [[]] * 1000
    while 1:
        if n == 0:
            v[0] = 1

        for r in regions:
            for unit2 in region.units:
                if unit2.no >= n and unit2.no < n + 1000:
                    v[unit2.no - n] = 1
        
        for i in range(1000):
            if not v[i]:
                unit.no = n + i
                unit.name = "Unit %s" % unit.no
                region.units.append(unit)
                return unit
        
        n += 1000


# TODO: scramble? Does this randomise a list?
"""
_cdecl scramblecmp (void *p1,void *p2)
{
    return *((long *)p1) - *((long *)p2);
}

void scramble (void *v1,int n,int width)
{
    int i;
    void *v;

    v = cmalloc (n * (width + 4));

    for (i = 0; i != n; i++)
    {
        *(long *)addptr (v,i * (width + 4)) = rnd ();
        memcpy (addptr (v,i * (width + 4) + 4),addptr (v1,i * width),width);
    }

    qsort (v,n,width + 4,scramblecmp);

    for (i = 0; i != n; i++)
        memcpy (addptr (v1,i * width),addptr (v,i * (width + 4) + 4),width);

    free (v);
}
"""


def inputregion():
    """ Interrogate the GM to get a region """
    while 1:
        x = raw_input("X? ")
        if not x.isdigit():
            return 0
        x = atoi(x)
        
        y = raw_input("Y? ")
        if not y.isdigit():
            return 0
        y = atoi(y)

        region = findregion(x,y)
        if not region:
            print "No such region."
            return None
        else:
            return region


def addplayers():
    """ Add new players from a file? """

    region = inputregion()
    if not region:
        return
    
    # The players file is just a list of email addresses... I think ;)
    print "Name of players file?"
    fileName = raw_input()
    
    playersFile = open(fileName, 'r')
    
    for line in playersFile.readlines():
        faction = Faction()
        faction.addr = line.strip()
        faction.lastorders = turn
        faction.alive = True
        
        # f->no++ : increment the faction number.
        # C reuses the old f number from last go around the loop!
        # TODO: we need a function which returns the max faction number
        # ...easy (I think):
        if len(factions) == 0:
            faction.no = 1
        else:
            faction.no = factions[-1].no + 1

        faction.name = "Faction %s" % faction.no

        factions.append(faction)
        
        unit = createunit(region)
        unit.number = 1
        unit.money = STARTMONEY
        unit.faction = faction
        unit.isnew = True
        
        print "Added player '%s'" % faction.addr


def connecttothis(region, x, y, fromRegion, toRegion):
    """ Define a neighbor for a region """
    # from and to are integers from 0..3
    region2 = findregion(x,y)
    if region2:
        region.connect[fromRegion] = region2
        region2.connect[toRegion] = region

def connectregions():
    """ Connect up all the regions? """
    for region in regions:
        if not region.connect[0]:
            connecttothis(region, region.x, region.y-1, 0, 1)
        if not region.connect[1]:
            connecttothis(region, region.x, region.y+1, 1, 0)
        if not region.connect[2]:
            connecttothis(region, region.x+1, region.y, 2, 3)
        if not region.connect[3]:
            connecttothis(region, region.x-1, region.y, 3, 2)


#char newblock[BLOCKSIZE][BLOCKSIZE];
# TODO: transmute is dodgy -- I have no idea what it does...
# UPDATE: I think it spreads region types around, 
# eg. start with one plain and smear it across the block
#newblock = [[0] * BLOCKSIZE] * BLOCKSIZE
newblock = [[0 for item in range(BLOCKSIZE)] for item2 in range(BLOCKSIZE)]

# TODO: this is buggy -- it shouldn't put anything but ocean on the borders
# UPDATE: it wasn't checking whether the region was already there, so if
# you did two transmutes in the same location, it would double up, and you'd
# get what appeared to be an extra-wide continent
def transmute(fromRegion, toRegion, n, count):
    """ Change some of the regions in newblock from fromRegion to toRegion """
    global newblock
    while 1:
        i = 0

        while 1:
            x = rnd() % BLOCKSIZE
            y = rnd() % BLOCKSIZE
            i += count
            
            here = newblock[x][y] == fromRegion
            west = (x != 0 and newblock[x - 1][y] == toRegion)
            east = (x != BLOCKSIZE - 1 and newblock[x + 1][y] == toRegion)
            north = (y != 0 and newblock[x][y - 1] == toRegion)
            south = (y != BLOCKSIZE - 1 and newblock[x][y + 1] == toRegion)
            
            if i <= 10 and not (here and (west or east or north or south)):
                
                if 0:
                    print toRegion, fromRegion, "-", 
                    if x != 0: print newblock[x - 1][y], 
                    if x != BLOCKSIZE - 1: print newblock[x + 1][y], 
                    if y != 0: print newblock[x][y - 1],
                    if y != BLOCKSIZE - 1: print newblock[x][y + 1],
                    print
                    print i, "-", x, y, "-", here, "-", west, east, north, south
                
                continue
            

            if i > 10:
                break
            
            newblock[x][y] = toRegion
            #printblock()
            if 0:
                print
                print "newblock[%s][%s] is now %s" % (x, y, newblock[x][y])
                printblock()
                print

        n = n - 1
        if not n:
            break


def seed(to, n):
    global newblock
    while 1:
        x = rnd() % BLOCKSIZE
        y = rnd() % BLOCKSIZE

        if newblock[x][y] == T_PLAIN:
            break

    newblock[x][y] = to
    transmute(T_PLAIN, to, n, 1)


def regionnameinuse(string):
    for region in regions:
        if region.name == string:
            return 1
    return 0


def blockcoord(x):
    """ Map x onto a block border """
    return (x / (BLOCKSIZE + BLOCKBORDER*2)) * (BLOCKSIZE + BLOCKBORDER*2)


def printblock():
    print
    for line in newblock:
        for char in line:
            if char:
                print char,
            else:
                print ".",
        print
    print

def makeblock(x1, y1):
    global newblock
    if x1 < 0:
        while x1 != blockcoord(x1):
            print "x1 is now", x1
            x1 -= 1

    if y1 < 0:
        while y1 != blockcoord(y1):
            print "y1 is now", y1
            y1 -= 1

    print "x1, y1 are now", x1, y1
    
    x1 = blockcoord(x1)
    y1 = blockcoord(y1)
    
    print "x1, y1 are", x1, y1, "after blockcoord"
    
    if findregion(x1, y1):
        print "There's already a region with that coordinate!"
        return

    # Regenerate newblock and slap a plains hex in the middle
    #newblock = [[0] * BLOCKSIZE] * BLOCKSIZE
    newblock = [[0 for item in range(BLOCKSIZE)] for item2 in range(BLOCKSIZE)]
    newblock[BLOCKSIZE/2][BLOCKSIZE/2] = T_PLAIN
    if 0:
        print BLOCKSIZE/2, T_PLAIN, newblock[BLOCKSIZE/2], newblock[BLOCKSIZE/2][BLOCKSIZE/2]
        printblock()
    
    transmute (T_OCEAN, T_PLAIN, 31, 1)
    seed (T_MOUNTAIN,1);
    seed (T_MOUNTAIN,1);
    seed (T_FOREST,1);
    seed (T_FOREST,1);
    seed (T_SWAMP,1);
    seed (T_SWAMP,1);
    if 0:
        printblock()

    for x in range(BLOCKSIZE + BLOCKBORDER*2):
        for y in range(BLOCKSIZE + BLOCKBORDER*2):
            region = Region()
            region.x = x1 + x
            region.y = y1 + y

            if (x >= BLOCKBORDER and x < BLOCKBORDER + BLOCKSIZE and
                y >= BLOCKBORDER and y < BLOCKBORDER + BLOCKSIZE):
                region.terrain = newblock[x - BLOCKBORDER][y - BLOCKBORDER]
                if region.terrain != T_OCEAN:
                    n = 0
                    for region2 in regions:
                        if region2.name:
                            n += 1
                    
                    i = rnd() % len(regionnames)
                    if n < len(regionnames):
                        while regionnameinuse(regionnames[i]):
                            i = rnd() % len(regionnames)

                    region.name = regionnames[i]
                    # TODO: will the C / operator cast to float or int?
                    region.peasants = maxfoodoutput[region.terrain] / 50

            regions.append(region)

    connectregions()


def gamedate():
    monthnames = [
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December",
    ]
    if turn == 0:
        return "In the Beginning"
    else:
        return "%s, Year %d" % (monthnames[(turn-1)%12], ((turn-1)/12)+1)
    
    
def factionid(faction):
    return "%s (%d)" % (faction.name, faction.no)
    
def regionid(region):
    if region.terrain == T_OCEAN:
        return "(%d,%d)" % (region.x, region.y)

def buildingid(building):
    return "%s (%d)" % (building.name, building.no)

def shipid(ship):
    return "%s (%d)" % (ship.name, ship.no)

def unitid(unit):
    return "%s (%d)" % (unit.name, unit.no)


# I don't think we need all these string list bits, but I'll keep 'em around for now...
"""
strlist *makestrlist (char *s)
{
    strlist *S;

    S = cmalloc (sizeof (strlist) + strlen (s));
    strcpy (S->s,s);
    return S;
}

void addstrlist (strlist **SP,char *s)
{
    addlist (SP,makestrlist (s));
}

void catstrlist (strlist **SP,strlist *S)
{
    strlist *S2;

    while (*SP)
        SP = &((*SP)->next);

    while (S)
    {
        S2 = makestrlist (S->s);
        addlist2 (SP,S2);
        S = S->next;
    }

    *SP = 0;
}
"""

def wrap(string, indent=2, width=80, bullet="*"):
    bits = string.split()
    output = []
    
    if indent == 0:
        line = bits[0]
    elif indent == 1:
        line = bullet + bits[0]
    else:
        line = (bullet+" ").rjust(indent) + bits[0]
    
    for bit in bits[1:]:
        if len(line) + len(bit) + 1 >= width:
            output.append(line)
            line = " "*indent + bit
        else:
            line = "%s %s" % (line, bit)
    output.append(line)
    return output

def centre(string, width=80):
    return [line.center(width) for line in wrap(string, indent=0, width=width, bullet="")]


# TODO: I think sparagraph is right, but hard to tell until I actually use in in anger.
# Also, it'll probably be a lot clearer if I rewrite in python, but that can wait...

# UPDATE: Actually, see wrap and centre above

def sparagraph(strlist, s, indent, mark):
    """ Break a string into a paragraph with \n's and store it in the evil buf global.
        Optionally indent it and stick a 'mark' at the front (ie. |  * Unit (123), ...)"""
    width = 79 - indent
    firstline = 1

    while 1:
        i = 0
        
        while 1:
            j = i
            while x[j] and s[j] != ' ':
                j += 1
            if j > width:
                break
            i = j + 1
            
            if j > len(s):
                break

        for j in range(indent):
            buf[j] = ' '

        if (firstline and mark):
            buf[indent - 2] = mark

        for j in range(i-1):
            buf[indent + j] = s[j]
        buf[indent + j] = 0
        
        addstrlist(SP, buf)

        if s[i - 1] == 0:
            break

        s += i
        firstline = 0


### TODO: these spblah functions should really, *really* be returning strings...
def spskill(unit, i, dh, days):
    
    if not unit.skills[i]:
        return

    scat(", ")

    if not dh:
        scat("skills: ")
        dh = 1

    scat(skillnames[i] + " " + str(effskill(unit,i)))
    
    if (days):
        assert unit.number
        scat(" [%s]" + str(unit.skills[i]/unit.number))


def spunit(SP, faction, region, unit, indent, battle):
    global buf

    buf += unitid(u)
    if cansee(faction, region, unit) == 2:
        scat(", faction ")
        scat(factionid(unit.faction))

    if unit.number != 1:
        scat(", number: ")
        scat(str(unit.number))
    
    if unit.behind and (unit.faction == faction or battle):
        scat(", behind")

    if unit.guard:
        scat(", on guard")

    if unit.faction == faction and not battle and unit.money:
        scat(", $%s" % unit.money)
    
    # TODO: Hmm, this dh is fed in as an address and reused.
    #       The python equivalent is to return a value...
    dh = 0
    if battle:
        for i in range(SK_TACTICS, SK_LONGBOW+1):
            spskill(unit, i, dh, 1)
    elif unit.faction == faction:
        for i in range(MAXSKILLS):
            spskill(unit, i, dh, 1)

    # TODO: As per above.
    dh = 0
    for i in range(MAXITEMS):
        if unit.items[i]:
            scat(", ")

            if not dh:
                scat("has: ")
                dh = 1
            if unit.items[i] == 1:
                scat(itemnames[0][i])
            else:
                scat("%d %s" % (unit.items[i], itemnames[1][i]))

    if unit.faction == faction:
        dh = 0
        for i in range(MAXSPELLS):
            if unit.spells[i]:
                scat(", ")
                if not dh:
                    scat("spells: ")
                    dh = 1
                scat(spellnames[i])
        
        if not battle:
            scat(", default: \"")
            scat(u.lastorder)
            scat("\"")

        if unit.combatspell >= 0:
            scat(", combat spell: ")
            scat(spellnames[unit.combatspell])

    i = 0
    if unit.display:
        scat("; ")
        scat(unit.display)
        i = unit.display[len(unit.display)-1]
    if (i != '!' and i != '?'):
        scat(".")

    sparagraph(SP, buf, indent, ['-', '*'][(unit.faction == faction)] )


def mistake(faction, string, comment):
    mistakestring = "%s: %s." % (string, comment)
    sparagraph (f.mistakes, buf, 0, 0)

def mistake2(unit, string, comment):
    mistake(unit.faction, string, comment)

def mistakeu(unit, comment):
    mistake(unit.faction, unit.thisorder, comment)

def addevent(faction, string):
    sparagraph(faction.events, string, 0, 0)

def addbattle(faction, string):
    sparagraph(faction.battles, s, 0, 0)

def reportevent(region, string):
    for faction in factions:
        for unit in region.units:
            if unit.faction == faction and unit.number:
                addevent(faction, string)
                break


def leave(region, unit):
    """ The unit wants to leave the boat/building """
    
    if unit.building:
        building = unit.building
        unit.building = None

        if unit.owner:
            unit.owner = 0
            for unit2 in region.units:
                if unit2.faction == unit.faction and unit2.building == building:
                    unit2.owner = 1
                    return
            for unit2 in region.units:
                if unit2.building == building:
                    unit2.owner = 1
                    return

    if unit.ship:
        ship = unit.ship
        unit.ship = None

        if unit.owner:
            unit.owner = 0
            for unit2 in region.units:
                if unit2.faction == unit.faction and unit2.ship == ship:
                    unit2.owner = 1
                    return
            for unit2 in region.units:
                if unit2.ship == ship:
                    unit2.owner = 1
                    return
            
def removeempty():
    """ Remove empty units and ships """
    for region in regions:

        # Remove empty units
        for unit in region.units:
            if not unit.number:
                leave(region, unit)
                for unit2 in region.units:
                    if unit2 == unit:
                        continue
                    if unit2.faction == unit.faction:
                        unit2.money += unit.money
                        unit.money = 0
                        for i in range(MAXITEMS):
                            unit2.items[i] += unit.items[i]
                        break
                    if region.terrain != T_OCEAN:
                        region.money += unit.money
                region.units.remove(unit)
        
        if region.terrain == T_OCEAN:
            for ship in region.ships:
                for unit in region.units:
                    if unit.ship == ship:
                        break

                if not unit:
                    region.ships.remove(ship)


def destroyfaction(faction):
    """ Remove a faction and all of its units from the game """

    for region in regions:
        for unit in region.units:
            if unit.faction == faction:
                if region.terrain != T_OCEAN:
                    region.peasants += unit.number
                unit.number = 0
    faction.alive = 0

# TODO: not sure I've got this one right...
def togglerf(unit, faction, factionList):
    """ Toggle faction's attitude to the faction which is in rfactions (? - not sure I've got this one right...) """
    if type(faction) == str:
        faction = findfaction(faction)
    if not faction:
        mistake2(unit, "Faction %s not found." % faction)

    if faction != unit.faction:
        for rf in factionList:
            if rf.faction == faction:
                break
        if rf:
            factionList.remove(rf)
        else:
            factionList.append(rf)


def iscoast(region):
    """ Is a region on the coast? """
    for i in range(4):
        if region.connect[i].terrain == T_OCEAN:
            return 1
    return 0

def distribute(old, new, n):
    """ Used to distribute money/skills from spoils amongst the victors """
    assert new <= old

    if old == 0:
        return 0

    t = (n / old) * new
    for i in range(n % old):
        if rnd() % old < new:
            t += 1
    return t

def armedmen(unit):
    """ How many armed men does the unit have? """
    n = 0
    if effskill(unit, SK_SWORD):
        n += unit.items[I_SWORD]
    if effskill(unit, SK_CROSSBOW):
        n += unit.items[I_CROSSBOW]
    if effskill(unit, SK_LONGBOW):
        n += unit.items[I_LONGBOW]
    return min(n, unit.number)

def getmoney(region, unit, n):
    """ Pull money from other units -- used for upkeep """
    n -= unit.money
    for unit2 in region.units:
        if n < 0:
            break
        if unit2.faction == unit.faction and unit2 != unit:
            i = min(unit2.money,n)
            unit2.money -= i
            unit.money += i
            n -= i

# TODO: combat stuff...
"""
int ntroops;
troop *ta;
troop attacker,defender;
int initial[2];
int left[2];
int infront[2];
int toattack[2];
int shields[2];
int runeswords[2];

troop **maketroops (troop **tp,unit *u,int terrain)
{
    int i;
    troop *t;
    static skills[MAXSKILLS];
    static items[MAXITEMS];

    for (i = 0; i != MAXSKILLS; i++)
        skills[i] = effskill (u,i);
    memcpy (items,u->items,sizeof items);

    left[u->side] += u->number;
    if (!u->behind)
        infront[u->side] += u->number;

    for (i = u->number; i; i--)
    {
        t = cmalloc (sizeof (troop));
        memset (t,0,sizeof (troop));

        t->unit = u;
        t->side = u->side;
        t->skill = -2;
        t->behind = u->behind;

        if (u->combatspell >= 0)
            t->missile = 1;
        else if (items[I_RUNESWORD] && skills[SK_SWORD])
        {
            t->weapon = I_SWORD;
            t->skill = skills[SK_SWORD] + 2;
            t->runesword = 1;
            items[I_RUNESWORD]--;
            runeswords[u->side]++;

            if (items[I_HORSE] && skills[SK_RIDING] >= 2 && terrain == T_PLAIN)
            {
                t->skill += 2;
                items[I_HORSE]--;
            }
        }
        else if (items[I_LONGBOW] && skills[SK_LONGBOW])
        {
            t->weapon = I_LONGBOW;
            t->missile = 1;
            t->skill = skills[SK_LONGBOW];
            items[I_LONGBOW]--;
        }
        else if (items[I_CROSSBOW] && skills[SK_CROSSBOW])
        {
            t->weapon = I_CROSSBOW;
            t->missile = 1;
            t->skill = skills[SK_CROSSBOW];
            items[I_CROSSBOW]--;
        }
        else if (items[I_SWORD] && skills[SK_SWORD])
        {
            t->weapon = I_SWORD;
            t->skill = skills[SK_SWORD];
            items[I_SWORD]--;

            if (items[I_HORSE] && skills[SK_RIDING] >= 2 && terrain == T_PLAIN)
            {
                t->skill += 2;
                items[I_HORSE]--;
            }
        }

        if (u->spells[SP_HEAL] || items[I_AMULET_OF_HEALING] > 0)
        {
            t->canheal = 1;
            items[I_AMULET_OF_HEALING]--;
        }

        if (items[I_RING_OF_POWER])
        {
            t->power = 1;
            items[I_RING_OF_POWER]--;
        }

        if (items[I_SHIELDSTONE])
        {
            t->shieldstone = 1;
            items[I_SHIELDSTONE]--;
        }

        if (items[I_CLOAK_OF_INVULNERABILITY])
        {
            t->invulnerable = 1;
            items[I_CLOAK_OF_INVULNERABILITY]--;
        }
        else if (items[I_PLATE_ARMOR])
        {
            t->armor = 2;
            items[I_PLATE_ARMOR]--;
        }
        else if (items[I_CHAIN_MAIL])
        {
            t->armor = 1;
            items[I_CHAIN_MAIL]--;
        }

        if (u->building && u->building->sizeleft)
        {
            t->inside = 2;
            u->building->sizeleft--;
        }

        addlist2 (tp,t);
    }

    return tp;
}

void battlerecord (char *s)
{
    faction *f;

    for (f = factions; f; f = f->next)
        if (f->seesbattle)
            sparagraph (&f->battles,s,0,0);

    if (s[0])
        puts (s);
}

void battlepunit (region *r,unit *u)
{
    faction *f;

    for (f = factions; f; f = f->next)
        if (f->seesbattle)
            spunit (&f->battles,f,r,u,4,1);
}

contest (int a,int d)
{
    int i;
    static char table[] = { 10,25,40 };

    i = a - d + 1;
    if (i < 0)
        return rnd () % 100 < 1;
    if (i > 2)
        return rnd () % 100 < 49;
    return rnd () % 100 < table[i];
}

hits (void)
{
    int k;

    if (defender.weapon == I_CROSSBOW || defender.weapon == I_LONGBOW)
        defender.skill = -2;
    defender.skill += defender.inside;
    attacker.skill -= (attacker.demoralized + attacker.dazzled);
    defender.skill -= (defender.demoralized + defender.dazzled);

    switch (attacker.weapon)
    {
        case 0:
        case I_SWORD:
            k = contest (attacker.skill,defender.skill);
            break;

        case I_CROSSBOW:
            k = contest (attacker.skill,0);
            break;

        case I_LONGBOW:
            k = contest (attacker.skill,2);
            break;
    }

    if (defender.invulnerable && rnd () % 10000)
        k = 0;

    if (rnd () % 3 < defender.armor)
        k = 0;

    return k;
}

validtarget (int i)
{
    return !ta[i].status &&
             ta[i].side == defender.side &&
             (!ta[i].behind || !infront[defender.side]);
}

canbedemoralized (int i)
{
    return validtarget (i) && !ta[i].demoralized;
}

canbedazzled (int i)
{
    return validtarget (i) && !ta[i].dazzled;
}

canberemoralized (int i)
{
    return !ta[i].status &&
             ta[i].side == attacker.side &&
             ta[i].demoralized;
}

selecttarget (void)
{
    int i;

    do
        i = rnd () % ntroops;
    while (!validtarget (i));

    return i;
}

void terminate (int i)
{
    if (!ta[i].attacked)
    {
        ta[i].attacked = 1;
        toattack[defender.side]--;
    }

    ta[i].status = 1;
    left[defender.side]--;
    if (infront[defender.side])
        infront[defender.side]--;
    if (ta[i].runesword)
        runeswords[defender.side]--;
}

lovar (int n)
{
    n /= 2;
    return (rnd () % n + 1) + (rnd () % n + 1);
}

void dozap (int n)
{
    static char buf2[40];

    n = lovar (n * (1 + attacker.power));
    n = min (n,left[defender.side]);

    sprintf (buf2,", inflicting %d %s",n,(n == 1) ? "casualty" : "casualties");
    scat (buf2);

    while (--n >= 0)
        terminate (selecttarget ());
}

void docombatspell (int i)
{
    int j;
    int z;
    int n,m;

    z = ta[i].unit->combatspell;
    sprintf (buf,"%s casts %s",unitid (ta[i].unit),spellnames[z]);

    if (shields[defender.side])
        if (rnd () & 1)
        {
            scat (", and gets through the shield");
            shields[defender.side] -= 1 + attacker.power;
        }
        else
        {
            scat (", but the spell is deflected by the shield!");
            battlerecord (buf);
            return;
        }

    switch (z)
    {
        case SP_BLACK_WIND:
            dozap (1250);
            break;

        case SP_CAUSE_FEAR:
            if (runeswords[defender.side] && (rnd () & 1))
                break;

            n = lovar (100 * (1 + attacker.power));

            m = 0;
            for (j = 0; j != ntroops; j++)
                if (canbedemoralized (j))
                    m++;

            n = min (n,m);

            sprintf (buf2,", affecting %d %s",n,(n == 1) ? "person" : "people");
            scat (buf2);

            while (--n >= 0)
            {
                do
                    j = rnd () % ntroops;
                while (!canbedemoralized (j));

                ta[j].demoralized = 1;
            }

            break;

        case SP_DAZZLING_LIGHT:
            n = lovar (50 * (1 + attacker.power));

            m = 0;
            for (j = 0; j != ntroops; j++)
                if (canbedazzled (j))
                    m++;

            n = min (n,m);

            sprintf (buf2,", dazzling %d %s",n,(n == 1) ? "person" : "people");
            scat (buf2);

            while (--n >= 0)
            {
                do
                    j = rnd () % ntroops;
                while (!canbedazzled (j));

                ta[j].dazzled = 1;
            }

            break;

        case SP_FIREBALL:
            dozap (50);
            break;

        case SP_HAND_OF_DEATH:
            dozap (250);
            break;

        case SP_INSPIRE_COURAGE:
            n = lovar (100 * (1 + attacker.power));

            m = 0;
            for (j = 0; j != ntroops; j++)
                if (canberemoralized (j))
                    m++;

            n = min (n,m);

            sprintf (buf2,", affecting %d %s",n,(n == 1) ? "person" : "people");
            scat (buf2);

            while (--n >= 0)
            {
                do
                    j = rnd () % ntroops;
                while (!canberemoralized (j));

                ta[j].demoralized = 0;
            }

            break;

        case SP_LIGHTNING_BOLT:
            dozap (10);
            break;

        case SP_SHIELD:
            shields[attacker.side] += 1 + attacker.power;
            break;

        case SP_SUNFIRE:
            dozap (6250);
            break;

        default:
            assert (0);
    }

    scat ("!");
    battlerecord (buf);
}

void doshot (void)
{
    int ai,di;

            /* Select attacker */

    do
        ai = rnd () % ntroops;
    while (ta[ai].attacked);

    attacker = ta[ai];
    ta[ai].attacked = 1;
    toattack[attacker.side]--;
    defender.side = 1 - attacker.side;

    ta[ai].dazzled = 0;

    if (attacker.unit)
    {
        if (attacker.behind &&
             infront[attacker.side] &&
             !attacker.missile)
            return;

        if (attacker.shieldstone)
            shields[attacker.side] += 1 + attacker.power;

        if (attacker.unit->combatspell >= 0)
        {
            docombatspell (ai);
            return;
        }

        if (attacker.reload)
        {
            ta[ai].reload--;
            return;
        }

        if (attacker.weapon == I_CROSSBOW)
            ta[ai].reload = 2;
    }

            /* Select defender */

    di = selecttarget ();
    defender = ta[di];
    assert (defender.side == 1 - attacker.side);

            /* If attack succeeds */

    if (hits ())
        terminate (di);
}
"""

def isallied (unit, unit2):
    """ Has unit's faction declared unit2's faction as ally? """
    if not unit2:
        return unit.guard
    if unit.faction == unit2.faction:
        return 1
    for rf in unit.faction.allies:
        if rf.faction == unit2.faction:
            return 1
    return 0

def accepts (unit, unit2):
    """ Will unit accept goodies from unit2? """
    if isallied(unit, unit2):
        return 1
    for rf in unit.faction.accept:
        if rf.faction == unit2.faction:
            return 1
    return 0

def admits(unit, unit2):
    """ Will unit let unit2 into the building/ship? """
    if isallied(unit, unit2):
        return 1
    for rf in unit.faction.admit:
        if rf.faction == unit2.faction:
            return 1
    return 0

def buildingowner(region, building):
    for unit in region.units:
        if unit.building == building and unit.owner:
            return unit
    return 0

def shipowner(region, ship):
    for unit in region.units:
        if unit.ship == ship and unit.owner:
            return unit
    return 0

def mayenter(region, unit, building):
    unit2 = buildingowner(region, building)
    return unit2 == 0 or admits(unit2, unit)

def mayboard(region, unit, ship):
    unit2 = shipowner(region, ship)
    return unit2 == 0 or admits(unit2, unit)


def readorders():
    """ Fuck it, I'll do this the new fangled way...
        It's a rough translation, but I'm ignoring a lot of the C silliness"""
    
    for faction in factions:
        # Clear out old orders
        for region in regions:
            for unit in region.units:
                if unit.faction == faction:
                    unit.orders = []

        # Read in new ones...
        fileName = "orders.%s"%faction.no
        if not os.access(fileName, os.F_OK) == 1:
            continue
        orderFile = open("orders.%s"%faction.no, "r")
        
        # chop out the bits between #atlantis... and #end (inclusive)
        orders = [line.rstrip() for line in orderFile.readlines()]
        try:
            atlLine = orders.index("#atlantis")
            endLine = orders.index("#end")+1
        except ValueError:
            # #atl or #end not in file!
            faction.mistakes.append("You missed an #atlantis or #end in your orders!") 
            continue
        orders = orders[atlLine:endLine]
        
        # slap the orders into the units
        unit = None
        for line in orders:
            if line.startswith("unit"):
                unitnum = line.split(1)
                if not line.isdigit():
                    unit = None
                    continue
                else:
                    unit = findunitg(unitnum)
                if unit and unit.faction == faction:
                    unit.lastorders = turn
                else:
                    faction.mistakes.append("Unit %s is not one of your units." % unitnum) 
                continue
            
            if unit and line != "":
                # TODO: not sure what all of the "_" shenanigans are in the C version...
                unit.orders.append(line)
            

def writemap(fileObject):
    """ Write the map out to a file? """    
    minx = sys.maxint
    maxx = -sys.maxint - 1
    miny = sys.maxint
    maxy = -sys.maxint - 1
    
    for r in regions:
        minx = min(minx, r.x)
        maxx = max(maxx, r.x)
        miny = min(miny, r.y)
        maxy = max(maxy, r.y)
    
    # TODO: this might be fairly efficient in C, but it's going to suck in Python
    for y in range(miny, maxy+1):
        for x in range(minx, maxx+1):
            r = findregion(x, y)
            if r:
                fileObject.write(" %s" % r.terrain)
            else:
                fileObject.write(" ?")
        fileObject.write("\n")


def writesummary():
    """ Print stuff about the game (or write it into F) """
    summaryFile = open("summary", "w")
    print "Writing summary file..."

    inhabitedregions = 0;
    peasants = 0;
    peasantmoney = 0;
    nunits = 0;
    playerpop = 0;
    playermoney = 0;
    
    for r in regions:
        if r.peasants or r.units:
            inhabitedregions += 1
            peasants += r.peasants
            peasantmoney += r.money

            for u in r.units:
                nunits += 1
                playerpop += u.number
                playermoney += u.money

                u.faction.nunits += 1
                u.faction.number += u.number
                u.faction.money += u.money

    summaryFile.write("Summary file for Atlantis, %s\n\n" % gamedate())
    summaryFile.write("Regions:            %d\n" % len(regions))
    summaryFile.write("Inhabited Regions:  %d\n\n" % inhabitedregions)
    summaryFile.write("Factions:           %d\n" % len(factions))
    summaryFile.write("Units:              %d\n\n" % nunits)
    summaryFile.write("Player Population:  %d\n" % playerpop)
    summaryFile.write("Peasants:           %d\n" % peasants)
    summaryFile.write("Total Population:   %d\n\n" % (playerpop + peasants))
    summaryFile.write("Player Wealth:      $%d\n" % playermoney)
    summaryFile.write("Peasant Wealth:     $%d\n" % peasantmoney)
    summaryFile.write("Total Wealth:       $%d\n\n" % (playermoney + peasantmoney))
    
    writemap(summaryFile)

    if factions:
        summaryFile.write('\n')

    for f in factions:
        summaryFile.write("%s, units: %d, number: %d, $%d, address: %s\n" % 
                            (factionid(f), f.nunits,f.number,f.money,f.addr))

    summaryFile.close()


### TODO: this is all to do with formatting reports, I think...
"""
int outi;
char outbuf[256];

void rnl (void)
{
    int i;
    int rc,vc;

    i = outi;
    while (i && isspace (outbuf[i - 1]))
        i--;
    outbuf[i] = 0;

    i = 0;
    rc = 0;
    vc = 0;

    while (outbuf[i])
    {
        switch (outbuf[i])
        {
            case ' ':
                vc++;
                break;

            case '\t':
                vc = (vc & ~7) + 8;
                break;

            default:
                while (rc / 8 != vc / 8)
                {
                    if ((rc & 7) == 7)
                        fputc (' ',F);
                    else
                        fputc ('\t',F);
                    rc = (rc & ~7) + 8;
                }

                while (rc != vc)
                {
                    fputc (' ',F);
                    rc++;
                }

                fputc (outbuf[i],F);
                rc++;
                vc++;
        }

        i++;
    }

    fputc ('\n',F);
    outi = 0;
}

void rpc (int c)
{
    outbuf[outi++] = c;
    assert (outi < sizeof outbuf);
}

void rps (char *s)
{
    while (*s)
        rpc (*s++);
}

void centre (char *s)
{
    int i;

    for (i = (79 - strlen (s)) / 2; i; i--)
        rpc (' ');
    rps (s);
    rnl ();
}

void rpstrlist (strlist *S)
{
    while (S)
    {
        rps (S->s);
        rnl ();
        S = S->next;
    }
}

void centrestrlist (char *s,strlist *S)
{
    if (S)
    {
        rnl ();
        centre (s);
        rnl ();

        rpstrlist (S);
    }
}

void rparagraph (char *s,int indent,int mark)
{
    strlist *S;

    S = 0;
    sparagraph (&S,s,indent,mark);
    rpstrlist (S);
    freelist (S);
}

void rpunit (faction *f,region *r,unit *u,int indent,int battle)
{
    strlist *S;

    S = 0;
    spunit (&S,f,r,u,indent,battle);
    rpstrlist (S);
    freelist (S);
}

void report (faction *f)
{
    int i;
    int dh;
    int anyunits;
    rfaction *rf;
    region *r;
    building *b;
    ship *sh;
    unit *u;
    strlist *S;

    if (strcmpl (f->addr,"n/a"))
        sprintf (buf,"reports/%d.r",f->no);
    else
        sprintf (buf,"nreports/%d.r",f->no);
    cfopen (buf,"w");

    printf ("Writing report for %s...\n",factionid (f));

    centre ("Atlantis Turn Report");
    centre (factionid (f));
    centre (gamedate ());

    centrestrlist ("Mistakes",f->mistakes);
    centrestrlist ("Messages",f->messages);

    if (f->battles || f->events)
    {
        rnl ();
        centre ("Events During Turn");
        rnl ();

        for (S = f->battles; S; S = S->next)
        {
            rps (S->s);
            rnl ();
        }

        if (f->battles && f->events)
            rnl ();

        for (S = f->events; S; S = S->next)
        {
            rps (S->s);
            rnl ();
        }
    }

    for (i = 0; i != MAXSPELLS; i++)
        if (f->showdata[i])
            break;

    if (i != MAXSPELLS)
    {
        rnl ();
        centre ("Spells Acquired");

        for (i = 0; i != MAXSPELLS; i++)
            if (f->showdata[i])
            {
                rnl ();
                centre (spellnames[i]);
                sprintf (buf,"Level %d",spelllevel[i]);
                centre (buf);
                rnl ();

                rparagraph (spelldata[i],0,0);
            }
    }

    rnl ();
    centre ("Current Status");

    if (f->allies)
    {
        dh = 0;
        strcpy (buf,"You are allied to ");

        for (rf = f->allies; rf; rf = rf->next)
        {
            if (dh)
                scat (", ");
            dh = 1;
            scat (factionid (rf->faction));
        }

        scat (".");
        rnl ();
        rparagraph (buf,0,0);
    }

    anyunits = 0;

    for (r = regions; r; r = r->next)
    {
        for (u = r->units; u; u = u->next)
            if (u->faction == f)
                break;
        if (!u)
            continue;

        anyunits = 1;

        sprintf (buf,"%s, %s",regionid (r),terrainnames[r->terrain]);

        if (r->peasants)
        {
            scat (", peasants: ");
            icat (r->peasants);

            if (r->money)
            {
                scat (", $");
                icat (r->money);
            }
        }

        scat (".");
        rnl ();
        rparagraph (buf,0,0);

        dh = 0;

        for (b = r->buildings; b; b = b->next)
        {
            sprintf (buf,"%s, size %d",buildingid (b),b->size);

            if (b->display[0])
            {
                scat ("; ");
                scat (b->display);
            }

            scat (".");

            if (dh)
                rnl ();

            dh = 1;

            rparagraph (buf,4,0);

            for (u = r->units; u; u = u->next)
                if (u->building == b && u->owner)
                {
                    rpunit (f,r,u,8,0);
                    break;
                }

            for (u = r->units; u; u = u->next)
                if (u->building == b && !u->owner)
                    rpunit (f,r,u,8,0);
        }

        for (sh = r->ships; sh; sh = sh->next)
        {
            sprintf (buf,"%s, %s",shipid (sh),shiptypenames[sh->type]);
            if (sh->left)
                scat (", under construction");

            if (sh->display[0])
            {
                scat ("; ");
                scat (sh->display);
            }

            scat (".");

            if (dh)
                rnl ();

            dh = 1;

            rparagraph (buf,4,0);

            for (u = r->units; u; u = u->next)
                if (u->ship == sh && u->owner)
                {
                    rpunit (f,r,u,8,0);
                    break;
                }

            for (u = r->units; u; u = u->next)
                if (u->ship == sh && !u->owner)
                    rpunit (f,r,u,8,0);
        }

        dh = 0;

        for (u = r->units; u; u = u->next)
            if (!u->building && !u->ship && cansee (f,r,u))
            {
                if (!dh && (r->buildings || r->ships))
                {
                    rnl ();
                    dh = 1;
                }

                rpunit (f,r,u,4,0);
            }
    }

    if (!anyunits)
    {
        rnl ();
        rparagraph ("Unfortunately your faction has been wiped out. Please "
                        "contact the moderator if you wish to play again.",0,0);
    }

    fclose (F);
}

void reports (void)
{
    struct FIND *fd;
    faction *f;

    mkdir ("reports");
    mkdir ("nreports");

    fd = findfirst ("reports/*.*",0);

    while (fd)
    {
        sprintf (buf,"reports/%s",fd->name);
        unlink (buf);
        fd = findnext ();
    }

    fd = findfirst ("nreports/*.*",0);

    while (fd)
    {
        sprintf (buf,"nreports/%s",fd->name);
        unlink (buf);
        fd = findnext ();
    }

    for (f = factions; f; f = f->next)
        report (f);

    cfopen ("send","w");
    puts ("Writing send file...");

    for (f = factions; f; f = f->next)
        if (strcmpl (f->addr,"n/a"))
        {
            fprintf (F,"mail %d.r\n",f->no);
            fprintf (F,"in%%\"%s\"\n",f->addr);
            fprintf (F,"Atlantis Report for %s\n",gamedate ());
        }

    fclose (F);

    cfopen ("maillist","w");
    puts ("Writing maillist file...");

    for (f = factions; f; f = f->next)
        if (strcmpl (f->addr,"n/a"))
            fprintf (F,"%s\n",f->addr);

    fclose (F);
}

int reportcasualtiesdh;

void reportcasualties (unit *u)
{
    if (!u->dead)
        return;

    if (!reportcasualtiesdh)
    {
        battlerecord ("");
        reportcasualtiesdh = 1;
    }

    if (u->number == 1)
        sprintf (buf,"%s is dead.",unitid (u));
    else
        if (u->dead == u->number)
            sprintf (buf,"%s is wiped out.",unitid (u));
        else
            sprintf (buf,"%s loses %d.",unitid (u),u->dead);
    battlerecord (buf);
}

int norders;
order *oa;

void expandorders (region *r,order *orders)
{
    int i,j;
    unit *u;
    order *o;

    for (u = r->units; u; u = u->next)
        u->n = -1;

    norders = 0;

    for (o = orders; o; o = o->next)
        norders += o->qty;

    oa = cmalloc (norders * sizeof (order));

    i = 0;

    for (o = orders; o; o = o->next)
        for (j = o->qty; j; j--)
        {
            oa[i].unit = o->unit;
            oa[i].unit->n = 0;
            i++;
        }

    freelist (orders);

    scramble (oa,norders,sizeof (order));
}
"""

def removenullfactions():
    """ Remove factions which are no longer active """
    for f in factions:
        if not f.alive:
            print ("Removing faction %s." % f.name)
            for f3 in factions:
                for rf in f3.allies:
                    if rf.faction == f:
                        f3.allies.remove(f)
            factions.remove(f)

def itemweight(unit):
    n = 0
    for i in range(MAXITEMS):
        if i == I_STONE:
            n += u.items[i] * 50
        elif i == I_HORSE:
            pass
        else:
            n += u.items[i]
    return n

def horseweight(unit):
    return u.items[I_HORSE] * 50

def canmove(unit):
    return itemweight(unit) - horseweight(unit) - unit.number*5 <= 0

def canride(unit):
    return itemweight(unit) - horseweight(unit) - unit.number*10 <= 0

def cansail(region, ship):
    n = 0
    for unit in region.units:
        if unit.ship == ship:
            n += itemweight(unit) + horseweight(unit) + unit.number*10
    return n <= shipcapacity[ship.type]

def spellitem(item):
    if item < SP_MAKE_AMULET_OF_DARKNESS or item > SP_MAKE_WAND_OF_TELEPORTATION:
        return -1
    return item - SP_MAKE_AMULET_OF_DARKNESS + I_AMULET_OF_DARKNESS

def cancast(unit, i):
    """ Can the unit cast the spell? """
    if unit.spells[i]:
        return unit.number

    if not effskill(unit, SK_MAGIC):
        return 0
    
    # Hmm, if we don't know the spell, but have an item, we're still good
    if i == SP_BLACK_WIND:
        return unit.items[I_AMULET_OF_DARKNESS]
    if i == SP_FIREBALL:
        return unit.items[I_STAFF_OF_FIRE]
    if i == SP_HAND_OF_DEATH:
        return unit.items[I_AMULET_OF_DEATH]
    if i == SP_LIGHTNING_BOLT:
        return unit.items[I_STAFF_OF_LIGHTNING]
    if i == SP_TELEPORT:
        return min(u.number, u.items[I_WAND_OF_TELEPORTATION])
    return 0

def magicians(faction):
    """ How many magicians does the faction have? """
    n = 0
    for region in regions:
        for unit in region.units:
            if unit.skills[SK_MAGIC] and unit.faction == faction:
                n += unit.number
    return n

def movewhere(region, direction):
    """ Which region will we end up in if we go a certain direction. 
        Also creates a new block if we run off the edge of the world? """
    
    # Not sure that we need this assignment
    region2 = 0
    
    if direction == K_NORTH:
        if not region.connect[0]:
            makeblock(region.x, region.y - 1)
        region2 = region.connect[0]

    elif direction == K_SOUTH:
        if not region.connect[1]:
            makeblock(region.x, region.y + 1)
        region2 = region.connect[1]

    elif direction == K_EAST:
        if not region.connect[2]:
            makeblock(region.x + 1, region.y)
        region2 = region.connect[2]

    elif direction == K_WEST:
        if not region.connect[3]:
            makeblock(region.x - 1, region.y)
        region2 = region.connect[3]

    return region2


def processorders():
    """ Process the orders """

    print "Processing FORM orders..."
    for region in regions:
        for unit in region.units:
            inNewUnit = False
            for orderString in unit.orders:
                if inNewUnit:
                    ordernum = getkeyword(orderString)
                    if ordernum == K_END:
                        inNewUnit = False
                        continue
                    elif ordernum == K_FORM:
                        mistake2(unit, orderString, "missing an end from your form order")
                        inNewUnit = False
                    else:
                        unit2.append(orderString)
                        
                if not inNewUnit:
                    ordernum = getkeyword(orderString)
                    if ordernum == K_FORM:
                        unit2 = createunit(region)
                        unit2.alias = atoip(orderString.split()[1])
                        if unit2.alias == 0:
                            unit2.alias = atoip(orderString.split()[2])
                        
                        unit2.faction = unit.faction
                        unit2.building = unit.building
                        unit2.ship = unit.ship
                        unit2.behind = unit.behind
                        unit2.guard = unit.guard


    print "Processing instant orders..."
    for region in regions:
        for unit in region.units:
            for orderString in unit.orders:
                ordernum = getkeyword(orderString)
                if ordernum == -1:
                    mistake2(unit, orderString, "Order not recognised")
                
                elif ordernum == K_ACCEPT:
                    # ACCEPT <faction-no>
                    togglerf(unit, orderString, unit.faction.accept)
                
                elif ordernum == K_ADDRESS:
                    # ADDRESS <email-address>
                    addressBits = orderString.split()
                    if len(addressBits) < 2:
                        mistake2(unit, orderString, "No address given")
                    else:
                        unit.faction.addr = addressBits[1]
                        print "%s is changing address to %s." % \
                                (unit.faction.name, unit.faction.addr)
                
                elif ordernum == K_ADMIT:
                    # ADMIT <faction-no>
                    togglerf (unit, orderString, unit.faction.admit)
                
                elif ordernum == K_ALLY:
                    # ALLY <faction no> <flag>
                    allyBits = orderString.split()
                    if len(allyBits) == 1:
                        mistake2(unit, orderString, "You need to specify the faction that you're allying with")
                        continue
                    elif len(allyBits) == 2:
                        mistake2(unit, orderString, "You need to include a flag (0 or 1) in an ally order")
                        
                    f = findfaction(allyBits[1])
                    if f == 0:
                        mistake2(unit, orderString, "Faction not found")
                    elif f == unit.faction:
                        mistake2(unit, orderString, "Can't ally with yourself")
                    else:
                        flag = allyBits[2]
                        if flag == "1":
                            if f not in unit.faction.allies:
                                unit.faction.allies.append(f)
                        elif flag == "0":
                            while f in unit.faction.allies:
                                unit.faction.allies.remove(f)

                elif ordernum == K_BEHIND:
                    bits = orderString.split()
                    if len(bits) < 2:
                        mistake2(unit, orderString, "Need to specify the flag for the behind order")
                        continue
                    if bits[1] == '1':
                        unit.behind = 1
                    else:
                        unit.behind = 0

                elif ordernum == K_COMBAT:
                    bits = orderString.split()
                    if len(bits) == 1:
                        unit.combatspell = -1
                        continue
                    spellnum = findspell(bits[1])
                    if spellnum < 0 or not cancast(unit, spellnum):
                        mistake2(unit, orderString, "Spell not found")
                    elif not iscombatspell(spellnum):
                        mistake2(unit, orderString, "Not a combat spell")
                    else:
                        unit.combatspell = spellnum

                elif ordernum == K_DISPLAY:
                    bits = orderString.split()
                    if len(bits) < 3:
                        mistake2(unit, orderString, "Need to specify what to set the display to")
                        continue
                    keyword = findkeyword(bits[1])
                    changeTo = ' '.join(bits[2:])
                    if keyword == K_BUILDING:
                        if not unit.building:
                            mistake2(unit, orderString, "Not in a building")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Building not owned by you")
                        else:
                            unit.building.display = changeTo
                    elif keyword == K_SHIP:
                        if not unit.ship:
                            mistake2(unit, orderString, "Not in a ship")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Ship not owned by you")
                        else:
                            unit.ship.display = changeTo
                    elif keyword == K_UNIT:
                        unit.display = changeTo
                    else:
                        mistake2(unit, orderString, "Order not recognized")

                elif ordernum == K_GUARD:
                    bits = orderString.split()
                    if len(bits) < 2:
                        mistake2(unit, orderString, "Need to specify the flag for the guard order")
                        continue
                    if bits[1] == '1':
                        unit.guard = 1
                    else:
                        unit.guard = 0

                elif ordernum == K_NAME:
                    bits = orderString.split()
                    if len(bits) < 3:
                        mistake2(unit, orderString, "Need to specify what to set the name to")
                        continue
                    if len(bits) == 2:
                        mistake2(unit, orderString, "No name given")
                        continue
                    keyword = findkeyword(bits[1])
                    changeTo = ' '.join(bits[2:])
                    if '(' in changeTo or ')' in changeTo:
                        mistake2(unit, orderString, "Names cannot contain brackets")
                        continue
                    if keyword == K_BUILDING:
                        if not unit.building:
                            mistake2(unit, orderString, "Not in a building")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Building not owned by you")
                        else:
                            unit.building.name = changeTo
                    elif keyword == K_SHIP:
                        if not unit.ship:
                            mistake2(unit, orderString, "Not in a ship")
                        elif not unit.owner:
                            mistake2(unit, orderString, "Ship not owned by you")
                        else:
                            unit.ship.name = changeTo
                    elif keyword == K_UNIT:
                        unit.name = changeTo
                    elif keyword == K_FACTION:
                        unit.faction.name = changeTo
                    else:
                        mistake2(unit, orderString, "Order not recognized")

                elif ordernum == K_RESHOW:
                    # TODO: I assume that the spell gets reshown at some point later on...
                    bits = orderString.split()
                    if len(bits) == 1:
                        spellnum = -1
                    else:
                        spellnum = findspell(bits[1])
                    if spellnum < 0 or not unit.faction.seendata[spellnum]:
                        mistake2(unit, orderString, "Spell not found")
                    else:
                        unit.faction.showdata[spellnum] = 1


### BOOKMARK

"""
            /* FIND orders */

    puts ("Processing FIND orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u; u = u->next)
            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_FIND:
                        f = getfaction ();

                        if (f == 0)
                        {
                            mistake2 (u,S,"Faction not found");
                            break;
                        }

                        sprintf (buf,"The address of %s is %s.",factionid (f),f->addr);
                        sparagraph (&u->faction->messages,buf,0,0);
                        break;
                }

            /* Leaving and entering buildings and ships */

    puts ("Processing leaving and entering orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u; u = u->next)
            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_BOARD:
                        sh = getship (r);

                        if (!sh)
                        {
                            mistake2 (u,S,"Ship not found");
                            break;
                        }

                        if (!mayboard (r,u,sh))
                        {
                            mistake2 (u,S,"Not permitted to board");
                            break;
                        }

                        leave (r,u);
                        u->ship = sh;
                        u->owner = 0;
                        if (shipowner (r,sh) == 0)
                            u->owner = 1;
                        break;

                    case K_ENTER:
                        b = getbuilding (r);

                        if (!b)
                        {
                            mistake2 (u,S,"Building not found");
                            break;
                        }

                        if (!mayenter (r,u,b))
                        {
                            mistake2 (u,S,"Not permitted to enter");
                            break;
                        }

                        leave (r,u);
                        u->building = b;
                        u->owner = 0;
                        if (buildingowner (r,b) == 0)
                            u->owner = 1;
                        break;

                    case K_LEAVE:
                        if (r->terrain == T_OCEAN)
                        {
                            mistake2 (u,S,"Ship is at sea");
                            break;
                        }

                        leave (r,u);
                        break;

                    case K_PROMOTE:
                        u2 = getunit (r,u);

                        if (!u2)
                        {
                            mistake2 (u,S,"Unit not found");
                            break;
                        }

                        if (!u->building && !u->ship)
                        {
                            mistake2 (u,S,"No building or ship to transfer ownership of");
                            break;
                        }

                        if (!u->owner)
                        {
                            mistake2 (u,S,"Not owned by you");
                            break;
                        }

                        if (!accepts (u2,u))
                        {
                            mistake2 (u,S,"Unit does not accept ownership");
                            break;
                        }

                        if (u->building)
                        {
                            if (u2->building != u->building)
                            {
                                mistake2 (u,S,"Unit not in same building");
                                break;
                            }
                        }
                        else
                            if (u2->ship != u->ship)
                            {
                                mistake2 (u,S,"Unit not on same ship");
                                break;
                            }

                        u->owner = 0;
                        u2->owner = 1;
                        break;
                }

            /* Combat */

    puts ("Processing ATTACK orders...");

    nfactions = listlen (factions);
    fa = cmalloc (nfactions * sizeof (faction *));

    for (r = regions; r; r = r->next)
    {
                /* Create randomly sorted list of factions */

        for (f = factions, i = 0; f; f = f->next, i++)
            fa[i] = f;
        scramble (fa,nfactions,sizeof (faction *));

                /* Handle each faction's attack orders */

        for (fno = 0; fno != nfactions; fno++)
        {
            f = fa[fno];

            for (u = r->units; u; u = u->next)
                if (u->faction == f)
                    for (S = u->orders; S; S = S->next)
                        if (igetkeyword (S->s) == K_ATTACK)
                        {
                            u2 = getunit (r,u);

                            if (!u2 && !getunitpeasants)
                            {
                                mistake2 (u,S,"Unit not found");
                                continue;
                            }

                            if (u2 && u2->faction == f)
                            {
                                mistake2 (u,S,"One of your units");
                                continue;
                            }

                            if (isallied (u,u2))
                            {
                                mistake2 (u,S,"An allied unit");
                                continue;
                            }

                                    /* Draw up troops for the battle */

                            for (b = r->buildings; b; b = b->next)
                                b->sizeleft = b->size;

                            troops = 0;
                            tp = &troops;
                            left[0] = left[1] = 0;
                            infront[0] = infront[1] = 0;

                                    /* If peasants are defenders */

                            if (!u2)
                            {
                                for (i = r->peasants; i; i--)
                                {
                                    t = cmalloc (sizeof (troop));
                                    memset (t,0,sizeof (troop));
                                    addlist2 (tp,t);
                                }

                                left[0] = r->peasants;
                                infront[0] = r->peasants;
                            }

                                    /* What units are involved? */

                            for (f2 = factions; f2; f2 = f2->next)
                                f2->attacking = 0;

                            for (u3 = r->units; u3; u3 = u3->next)
                                for (S2 = u3->orders; S2; S2 = S2->next)
                                    if (igetkeyword (S2->s) == K_ATTACK)
                                    {
                                        u4 = getunit (r,u3);

                                        if ((getunitpeasants && !u2) ||
                                             (u4 && u4->faction == u2->faction &&
                                              !isallied (u3,u4)))
                                        {
                                            u3->faction->attacking = 1;
                                            S2->s[0] = 0;
                                            break;
                                        }
                                    }

                            for (u3 = r->units; u3; u3 = u3->next)
                            {
                                u3->side = -1;

                                if (!u3->number)
                                    continue;

                                if (u3->faction->attacking)
                                {
                                    u3->side = 1;
                                    tp = maketroops (tp,u3,r->terrain);
                                }
                                else if (isallied (u3,u2))
                                {
                                    u3->side = 0;
                                    tp = maketroops (tp,u3,r->terrain);
                                }
                            }

                            *tp = 0;

                                    /* If only one side shows up, cancel */

                            if (!left[0] || !left[1])
                            {
                                freelist (troops);
                                continue;
                            }

                                    /* Set up array of troops */

                            ntroops = listlen (troops);
                            ta = cmalloc (ntroops * sizeof (troop));
                            for (t = troops, i = 0; t; t = t->next, i++)
                                ta[i] = *t;
                            freelist (troops);
                            scramble (ta,ntroops,sizeof (troop));

                            initial[0] = left[0];
                            initial[1] = left[1];
                            shields[0] = 0;
                            shields[1] = 0;
                            runeswords[0] = 0;
                            runeswords[1] = 0;

                            lmoney = 0;
                            memset (litems,0,sizeof litems);

                                    /* Initial attack message */

                            for (f2 = factions; f2; f2 = f2->next)
                            {
                                f2->seesbattle = ispresent (f2,r);
                                if (f2->seesbattle && f2->battles)
                                    addstrlist (&f2->battles,"");
                            }

                            if (u2)
                                strcpy (buf2,unitid (u2));
                            else
                                strcpy (buf2,"the peasants");
                            sprintf (buf,"%s attacks %s in %s!",unitid (u),buf2,regionid (r));
                            battlerecord (buf);

                                    /* List sides */

                            battlerecord ("");

                            battlepunit (r,u);

                            for (u3 = r->units; u3; u3 = u3->next)
                                if (u3->side == 1 && u3 != u)
                                    battlepunit (r,u3);

                            battlerecord ("");

                            if (u2)
                                battlepunit (r,u2);
                            else
                            {
                                sprintf (buf,"Peasants, number: %d",r->peasants);
                                for (f2 = factions; f2; f2 = f2->next)
                                    if (f2->seesbattle)
                                        sparagraph (&f2->battles,buf,4,'-');
                            }

                            for (u3 = r->units; u3; u3 = u3->next)
                                if (u3->side == 0 && u3 != u2)
                                    battlepunit (r,u3);

                            battlerecord ("");

                                    /* Does one side have an advantage in tactics? */

                            maxtactics[0] = 0;
                            maxtactics[1] = 0;

                            for (i = 0; i != ntroops; i++)
                                if (ta[i].unit)
                                {
                                    j = effskill (ta[i].unit,SK_TACTICS);

                                    if (maxtactics[ta[i].side] < j)
                                    {
                                        leader[ta[i].side] = i;
                                        maxtactics[ta[i].side] = j;
                                    }
                                }

                            attacker.side = -1;
                            if (maxtactics[0] > maxtactics[1])
                                attacker.side = 0;
                            if (maxtactics[1] > maxtactics[0])
                                attacker.side = 1;

                                    /* Better leader gets free round of attacks */

                            if (attacker.side >= 0)
                            {
                                        /* Note the fact in the battle report */

                                if (attacker.side)
                                    sprintf (buf,"%s gets a free round of attacks!",unitid (u));
                                else
                                    if (u2)
                                        sprintf (buf,"%s gets a free round of attacks!",unitid (u2));
                                    else
                                        sprintf (buf,"The peasants get a free round of attacks!");
                                battlerecord (buf);

                                        /* Number of troops to attack */

                                toattack[attacker.side] = 0;

                                for (i = 0; i != ntroops; i++)
                                {
                                    ta[i].attacked = 1;

                                    if (ta[i].side == attacker.side)
                                    {
                                        ta[i].attacked = 0;
                                        toattack[attacker.side]++;
                                    }
                                }

                                        /* Do round of attacks */

                                do
                                    doshot ();
                                while (toattack[attacker.side] && left[defender.side]);
                            }

                                    /* Handle main body of battle */

                            toattack[0] = 0;
                            toattack[1] = 0;

                            while (left[defender.side])
                            {
                                        /* End of a round */

                                if (toattack[0] == 0 && toattack[1] == 0)
                                    for (i = 0; i != ntroops; i++)
                                    {
                                        ta[i].attacked = 1;

                                        if (!ta[i].status)
                                        {
                                            ta[i].attacked = 0;
                                            toattack[ta[i].side]++;
                                        }
                                    }

                                doshot ();
                            }

                                    /* Report on winner */

                            if (attacker.side)
                                sprintf (buf,"%s wins the battle!",unitid (u));
                            else
                                if (u2)
                                    sprintf (buf,"%s wins the battle!",unitid (u2));
                                else
                                    sprintf (buf,"The peasants win the battle!");
                            battlerecord (buf);

                                    /* Has winner suffered any casualties? */

                            winnercasualties = 0;

                            for (i = 0; i != ntroops; i++)
                                if (ta[i].side == attacker.side && ta[i].status)
                                {
                                    winnercasualties = 1;
                                    break;
                                }

                                    /* Can wounded be healed? */

                            n = 0;

                            for (i = 0; i != ntroops &&
                                            n != initial[attacker.side] -
                                                  left[attacker.side]; i++)
                                if (!ta[i].status && ta[i].canheal)
                                {
                                    k = lovar (50 * (1 + ta[i].power));
                                    k = min (k,initial[attacker.side] -
                                                      left[attacker.side] - n);

                                    sprintf (buf,"%s heals %d wounded.",
                                                unitid (ta[i].unit),k);
                                    battlerecord (buf);

                                    n += k;
                                }

                            while (--n >= 0)
                            {
                                do
                                    i = rnd () % ntroops;
                                while (!ta[i].status || ta[i].side != attacker.side);

                                ta[i].status = 0;
                            }

                                    /* Count the casualties */

                            deadpeasants = 0;

                            for (u3 = r->units; u3; u3 = u3->next)
                                u3->dead = 0;

                            for (i = 0; i != ntroops; i++)
                                if (ta[i].unit)
                                    ta[i].unit->dead += ta[i].status;
                                else
                                    deadpeasants += ta[i].status;

                                    /* Report the casualties */

                            reportcasualtiesdh = 0;

                            if (attacker.side)
                            {
                                reportcasualties (u);

                                for (u3 = r->units; u3; u3 = u3->next)
                                    if (u3->side == 1 && u3 != u)
                                        reportcasualties (u3);
                            }
                            else
                            {
                                if (u2)
                                    reportcasualties (u2);
                                else
                                    if (deadpeasants)
                                    {
                                        battlerecord ("");
                                        reportcasualtiesdh = 1;
                                        sprintf (buf,"The peasants lose %d.",deadpeasants);
                                        battlerecord (buf);
                                    }

                                for (u3 = r->units; u3; u3 = u3->next)
                                    if (u3->side == 0 && u3 != u2)
                                        reportcasualties (u3);
                            }

                                    /* Dead peasants */

                            k = r->peasants - deadpeasants;

                            j = distribute (r->peasants,k,r->money);
                            lmoney += r->money - j;
                            r->money = j;

                            r->peasants = k;

                                    /* Adjust units */

                            for (u3 = r->units; u3; u3 = u3->next)
                            {
                                k = u3->number - u3->dead;

                                        /* Redistribute items and skills */

                                if (u3->side == defender.side)
                                {
                                    j = distribute (u3->number,k,u3->money);
                                    lmoney += u3->money - j;
                                    u3->money = j;

                                    for (i = 0; i != MAXITEMS; i++)
                                    {
                                        j = distribute (u3->number,k,u3->items[i]);
                                        litems[i] += u3->items[i] - j;
                                        u3->items[i] = j;
                                    }
                                }

                                for (i = 0; i != MAXSKILLS; i++)
                                    u3->skills[i] = distribute (u3->number,k,u3->skills[i]);

                                        /* Adjust unit numbers */

                                u3->number = k;

                                        /* Need this flag cleared for reporting of loot */

                                u3->n = 0;
                            }

                                    /* Distribute loot */

                            for (n = lmoney; n; n--)
                            {
                                do
                                    j = rnd () % ntroops;
                                while (ta[j].status || ta[j].side != attacker.side);

                                if (ta[j].unit)
                                {
                                    ta[j].unit->money++;
                                    ta[j].unit->n++;
                                }
                                else
                                    r->money++;
                            }

                            for (i = 0; i != MAXITEMS; i++)
                                for (n = litems[i]; n; n--)
                                    if (i <= I_STONE || rnd () & 1)
                                    {
                                        do
                                            j = rnd () % ntroops;
                                        while (ta[j].status || ta[j].side != attacker.side);

                                        if (ta[j].unit)
                                        {
                                            if (!ta[j].unit->litems)
                                            {
                                                ta[j].unit->litems = cmalloc (MAXITEMS *
                                                                                        sizeof (int));
                                                memset (ta[j].unit->litems,0,
                                                          MAXITEMS * sizeof (int));
                                            }

                                            ta[j].unit->items[i]++;
                                            ta[j].unit->litems[i]++;
                                        }
                                    }

                                    /* Report loot */

                            for (f2 = factions; f2; f2 = f2->next)
                                f2->dh = 0;

                            for (u3 = r->units; u3; u3 = u3->next)
                                if (u3->n || u3->litems)
                                {
                                    sprintf (buf,"%s finds ",unitid (u3));
                                    dh = 0;

                                    if (u3->n)
                                    {
                                        scat ("$");
                                        icat (u3->n);
                                        dh = 1;
                                    }

                                    if (u3->litems)
                                    {
                                        for (i = 0; i != MAXITEMS; i++)
                                            if (u3->litems[i])
                                            {
                                                if (dh)
                                                    scat (", ");
                                                dh = 1;

                                                icat (u3->litems[i]);
                                                scat (" ");

                                                if (u3->litems[i] == 1)
                                                    scat (itemnames[0][i]);
                                                else
                                                    scat (itemnames[1][i]);
                                            }

                                        free (u3->litems);
                                        u3->litems = 0;
                                    }

                                    if (!u3->faction->dh)
                                    {
                                        addbattle (u3->faction,"");
                                        u3->faction->dh = 1;
                                    }

                                    scat (".");
                                    addbattle (u3->faction,buf);
                                }

                                    /* Does winner get combat experience? */

                            if (winnercasualties)
                            {
                                if (maxtactics[attacker.side] &&
                                     !ta[leader[attacker.side]].status)
                                    ta[leader[attacker.side]].unit->
                                            skills[SK_TACTICS] += COMBATEXP;

                                for (i = 0; i != ntroops; i++)
                                    if (ta[i].unit &&
                                         !ta[i].status &&
                                         ta[i].side == attacker.side)
                                        switch (ta[i].weapon)
                                        {
                                            case I_SWORD:
                                                ta[i].unit->skills[SK_SWORD] += COMBATEXP;
                                                break;

                                            case I_CROSSBOW:
                                                ta[i].unit->skills[SK_CROSSBOW] += COMBATEXP;
                                                break;

                                            case I_LONGBOW:
                                                ta[i].unit->skills[SK_LONGBOW] += COMBATEXP;
                                                break;
                                        }
                            }

                            free (ta);
                        }
        }
    }

    free (fa);

            /* Economic orders */

    puts ("Processing economic orders...");

    for (r = regions; r; r = r->next)
    {
        taxorders = 0;
        recruitorders = 0;

                /* DEMOLISH, GIVE, PAY, SINK orders */

        for (u = r->units; u; u = u->next)
            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_DEMOLISH:
                        if (!u->building)
                        {
                            mistake2 (u,S,"Not in a building");
                            break;
                        }

                        if (!u->owner)
                        {
                            mistake2 (u,S,"Building not owned by you");
                            break;
                        }

                        b = u->building;

                        for (u2 = r->units; u2; u2 = u2->next)
                            if (u2->building == b)
                            {
                                u2->building = 0;
                                u2->owner = 0;
                            }

                        sprintf (buf,"%s demolishes %s.",unitid (u),buildingid (b));
                        reportevent (r,buf);

                        removelist (&r->buildings,b);
                        break;

                    case K_GIVE:
                        u2 = getunit (r,u);

                        if (!u2 && !getunit0)
                        {
                            mistake2 (u,S,"Unit not found");
                            break;
                        }

                        if (u2 && !accepts (u2,u))
                        {
                            mistake2 (u,S,"Unit does not accept your gift");
                            break;
                        }

                        s = getstr ();
                        i = findspell (s);

                        if (i >= 0)
                        {
                            if (!u2)
                            {
                                mistake2 (u,S,"Unit not found");
                                break;
                            }

                            if (!u->spells[i])
                            {
                                mistake2 (u,S,"Spell not found");
                                break;
                            }

                            if (spelllevel[i] > (effskill (u2,SK_MAGIC) + 1) / 2)
                            {
                                mistake2 (u,S,"Recipient is not able to learn that spell");
                                break;
                            }

                            u2->spells[i] = 1;

                            sprintf (buf,"%s gives ",unitid (u));
                            scat (unitid (u2));
                            scat (" the ");
                            scat (spellnames[i]);
                            scat (" spell.");
                            addevent (u->faction,buf);
                            if (u->faction != u2->faction)
                                addevent (u2->faction,buf);

                            if (!u2->faction->seendata[i])
                            {
                                u2->faction->seendata[i] = 1;
                                u2->faction->showdata[i] = 1;
                            }
                        }
                        else
                        {
                            n = atoip (s);
                            i = getitem ();

                            if (i < 0)
                            {
                                mistake2 (u,S,"Item not recognized");
                                break;
                            }

                            if (n > u->items[i])
                                n = u->items[i];

                            if (n == 0)
                            {
                                mistake2 (u,S,"Item not available");
                                break;
                            }

                            u->items[i] -= n;

                            if (!u2)
                            {
                                if (n == 1)
                                    sprintf (buf,"%s discards 1 %s.",
                                                unitid (u),itemnames[0][i]);
                                else
                                    sprintf (buf,"%s discards %d %s.",
                                                unitid (u),n,itemnames[1][i]);
                                addevent (u->faction,buf);
                                break;
                            }

                            u2->items[i] += n;

                            sprintf (buf,"%s gives ",unitid (u));
                            scat (unitid (u2));
                            scat (" ");
                            if (n == 1)
                            {
                                scat ("1 ");
                                scat (itemnames[0][i]);
                            }
                            else
                            {
                                icat (n);
                                scat (" ");
                                scat (itemnames[1][i]);
                            }
                            scat (".");
                            addevent (u->faction,buf);
                            if (u->faction != u2->faction)
                                addevent (u2->faction,buf);
                        }

                        break;

                    case K_PAY:
                        u2 = getunit (r,u);

                        if (!u2 && !getunit0 && !getunitpeasants)
                        {
                            mistake2 (u,S,"Unit not found");
                            break;
                        }

                        n = geti ();

                        if (n > u->money)
                            n = u->money;

                        if (n == 0)
                        {
                            mistake2 (u,S,"No money available");
                            break;
                        }

                        u->money -= n;

                        if (u2)
                        {
                            u2->money += n;

                            sprintf (buf,"%s pays ",unitid (u));
                            scat (unitid (u2));
                            scat (" $");
                            icat (n);
                            scat (".");
                            if (u->faction != u2->faction)
                                addevent (u2->faction,buf);
                        }
                        else
                            if (getunitpeasants)
                            {
                                r->money += n;

                                sprintf (buf,"%s pays the peasants $%d.",unitid (u),n);
                            }
                            else
                                sprintf (buf,"%s discards $%d.",unitid (u),n);

                        addevent (u->faction,buf);
                        break;

                    case K_SINK:
                        if (!u->ship)
                        {
                            mistake2 (u,S,"Not on a ship");
                            break;
                        }

                        if (!u->owner)
                        {
                            mistake2 (u,S,"Ship not owned by you");
                            break;
                        }

                        if (r->terrain == T_OCEAN)
                        {
                            mistake2 (u,S,"Ship is at sea");
                            break;
                        }

                        sh = u->ship;

                        for (u2 = r->units; u2; u2 = u2->next)
                            if (u2->ship == sh)
                            {
                                u2->ship = 0;
                                u2->owner = 0;
                            }

                        sprintf (buf,"%s sinks %s.",unitid (u),shipid (sh));
                        reportevent (r,buf);

                        removelist (&r->ships,sh);
                        break;
                }

                /* TRANSFER orders */

        for (u = r->units; u; u = u->next)
            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_TRANSFER:
                        u2 = getunit (r,u);

                        if (u2)
                        {
                            if (!accepts (u2,u))
                            {
                                mistake2 (u,S,"Unit does not accept your gift");
                                break;
                            }
                        }
                        else if (!getunitpeasants)
                        {
                            mistake2 (u,S,"Unit not found");
                            break;
                        }

                        n = atoip (getstr ());

                        if (n > u->number)
                            n = u->number;

                        if (n == 0)
                        {
                            mistake2 (u,S,"No people available");
                            break;
                        }

                        if (u->skills[SK_MAGIC] && u2)
                        {
                            k = magicians (u2->faction);
                            if (u2->faction != u->faction)
                                k += n;
                            if (!u2->skills[SK_MAGIC])
                                k += u2->number;

                            if (k > 3)
                            {
                                mistake2 (u,S,"Only 3 magicians per faction");
                                break;
                            }
                        }

                        k = u->number - n;

                        for (i = 0; i != MAXSKILLS; i++)
                        {
                            j = distribute (u->number,k,u->skills[i]);
                            if (u2)
                                u2->skills[i] += u->skills[i] - j;
                            u->skills[i] = j;
                        }

                        u->number = k;

                        if (u2)
                        {
                            u2->number += n;

                            for (i = 0; i != MAXSPELLS; i++)
                                if (u->spells[i] && effskill (u2,SK_MAGIC) / 2 >= spelllevel[i])
                                    u2->spells[i] = 1;

                            sprintf (buf,"%s transfers ",unitid (u));
                            if (k)
                            {
                                icat (n);
                                scat (" ");
                            }
                            scat ("to ");
                            scat (unitid (u2));
                            if (u->faction != u2->faction)
                                addevent (u2->faction,buf);
                        }
                        else
                        {
                            r->peasants += n;

                            if (k)
                                sprintf (buf,"%s disbands %d.",unitid (u),n);
                            else
                                sprintf (buf,"%s disbands.",unitid (u));
                        }

                        addevent (u->faction,buf);
                        break;
                }

                /* TAX orders */

        for (u = r->units; u; u = u->next)
        {
            taxed = 0;

            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_TAX:
                        if (taxed)
                            break;

                        n = armedmen (u);

                        if (!n)
                        {
                            mistake2 (u,S,"Unit is not armed and combat trained");
                            break;
                        }

                        for (u2 = r->units; u2; u2 = u2->next)
                            if (u2->guard && u2->number && !admits (u2,u))
                            {
                                sprintf (buf,"%s is on guard",u2->name);
                                mistake2 (u,S,buf);
                                break;
                            }

                        if (u2)
                            break;

                        o = cmalloc (sizeof (order));
                        o->qty = n * TAXINCOME;
                        o->unit = u;
                        addlist (&taxorders,o);
                        taxed = 1;
                        break;
                }
        }

                /* Do taxation */

        for (u = r->units; u; u = u->next)
            u->n = -1;

        norders = 0;

        for (o = taxorders; o; o = o->next)
            norders += o->qty / 10;

        oa = cmalloc (norders * sizeof (order));

        i = 0;

        for (o = taxorders; o; o = o->next)
            for (j = o->qty / 10; j; j--)
            {
                oa[i].unit = o->unit;
                oa[i].unit->n = 0;
                i++;
            }

        freelist (taxorders);

        scramble (oa,norders,sizeof (order));

        for (i = 0; i != norders && r->money > 10; i++, r->money -= 10)
        {
            oa[i].unit->money += 10;
            oa[i].unit->n += 10;
        }

        free (oa);

        for (u = r->units; u; u = u->next)
            if (u->n >= 0)
            {
                sprintf (buf,"%s collects $%d in taxes.",unitid (u),u->n);
                addevent (u->faction,buf);
            }

                /* GUARD 1, RECRUIT orders */

        for (u = r->units; u; u = u->next)
        {
            availmoney = u->money;

            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_GUARD:
                        if (geti ())
                            u->guard = 1;
                        break;

                    case K_RECRUIT:
                        if (availmoney < RECRUITCOST)
                            break;

                        n = geti ();

                        if (u->skills[SK_MAGIC] && magicians (u->faction) + n > 3)
                        {
                            mistake2 (u,S,"Only 3 magicians per faction");
                            break;
                        }

                        n = min (n,availmoney / RECRUITCOST);

                        o = cmalloc (sizeof (order));
                        o->qty = n;
                        o->unit = u;
                        addlist (&recruitorders,o);

                        availmoney -= o->qty * RECRUITCOST;
                        break;
                }
        }

                /* Do recruiting */

        expandorders (r,recruitorders);

        for (i = 0, n = r->peasants / RECRUITFRACTION; i != norders && n; i++, n--)
        {
            oa[i].unit->number++;
            r->peasants--;
            oa[i].unit->money -= RECRUITCOST;
            r->money += RECRUITCOST;
            oa[i].unit->n++;
        }

        free (oa);

        for (u = r->units; u; u = u->next)
            if (u->n >= 0)
            {
                sprintf (buf,"%s recruits %d.",unitid (u),u->n);
                addevent (u->faction,buf);
            }
    }

            /* QUIT orders */

    puts ("Processing QUIT orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u; u = u->next)
            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_QUIT:
                        if (geti () != u->faction->no)
                        {
                            mistake2 (u,S,"Correct faction number not given");
                            break;
                        }

                        destroyfaction (u->faction);
                        break;
                }

            /* Remove players who haven't sent in orders */

    for (f = factions; f; f = f->next)
        if (turn - f->lastorders > ORDERGAP)
            destroyfaction (f);

            /* Clear away debris of destroyed factions */

    removeempty ();
    removenullfactions ();

            /* Set production orders */

    puts ("Setting production orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u; u = u->next)
        {
            strcpy (u->thisorder,u->lastorder);

            for (S = u->orders; S; S = S->next)
                switch (igetkeyword (S->s))
                {
                    case K_BUILD:
                    case K_CAST:
                    case K_ENTERTAIN:
                    case K_MOVE:
                    case K_PRODUCE:
                    case K_RESEARCH:
                    case K_SAIL:
                    case K_STUDY:
                    case K_TEACH:
                    case K_WORK:
                        nstrcpy (u->thisorder,S->s,sizeof u->thisorder);
                        break;
                }

            switch (igetkeyword (u->thisorder))
            {
                case K_MOVE:
                case K_SAIL:
                    break;

                default:
                    strcpy (u->lastorder,u->thisorder);
                    strlwr (u->lastorder);
            }
        }

            /* MOVE orders */

    puts ("Processing MOVE orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u;)
        {
            u2 = u->next;

            switch (igetkeyword (u->thisorder))
            {
                case K_MOVE:
                    r2 = movewhere (r);

                    if (!r2)
                    {
                        mistakeu (u,"Direction not recognized");
                        break;
                    }

                    if (r->terrain == T_OCEAN)
                    {
                        mistakeu (u,"Currently at sea");
                        break;
                    }

                    if (r2->terrain == T_OCEAN)
                    {
                        sprintf (buf,"%s discovers that (%d,%d) is ocean.",
                                    unitid (u),r2->x,r2->y);
                        addevent (u->faction,buf);
                        break;
                    }

                    if (!canmove (u))
                    {
                        mistakeu (u,"Carrying too much weight to move");
                        break;
                    }

                    leave (r,u);
                    translist (&r->units,&r2->units,u);
                    u->thisorder[0] = 0;

                    sprintf (buf,"%s ",unitid (u));
                    if (canride (u))
                        scat ("rides");
                    else
                        scat ("walks");
                    scat (" from ");
                    scat (regionid (r));
                    scat (" to ");
                    scat (regionid (r2));
                    scat (".");
                    addevent (u->faction,buf);
                    break;
            }

            u = u2;
        }

            /* SAIL orders */

    puts ("Processing SAIL orders...");

    for (r = regions; r; r = r->next)
        for (u = r->units; u;)
        {
            u2 = u->next;

            switch (igetkeyword (u->thisorder))
            {
                case K_SAIL:
                    r2 = movewhere (r);

                    if (!r2)
                    {
                        mistakeu (u,"Direction not recognized");
                        break;
                    }

                    if (!u->ship)
                    {
                        mistakeu (u,"Not on a ship");
                        break;
                    }

                    if (!u->owner)
                    {
                        mistakeu (u,"Ship not owned by you");
                        break;
                    }

                    if (r2->terrain != T_OCEAN && !iscoast (r2))
                    {
                        sprintf (buf,"%s discovers that (%d,%d) is inland.",
                                    unitid (u),r2->x,r2->y);
                        addevent (u->faction,buf);
                        break;
                    }

                    if (u->ship->left)
                    {
                        mistakeu (u,"Ship still under construction");
                        break;
                    }

                    if (!cansail (r,u->ship))
                    {
                        mistakeu (u,"Too heavily loaded to sail");
                        break;
                    }

                    translist (&r->ships,&r2->ships,u->ship);

                    for (u2 = r->units; u2;)
                    {
                        u3 = u2->next;

                        if (u2->ship == u->ship)
                        {
                            translist (&r->units,&r2->units,u2);
                            u2->thisorder[0] = 0;
                        }

                        u2 = u3;
                    }

                    u->thisorder[0] = 0;
                    break;
            }

            u = u2;
        }

            /* Do production orders */

    puts ("Processing production orders...");

    for (r = regions; r; r = r->next)
    {
        if (r->terrain == T_OCEAN)
            continue;

        entertainorders = 0;
        workorders = 0;
        memset (produceorders,0,sizeof produceorders);

        for (u = r->units; u; u = u->next)
            switch (igetkeyword (u->thisorder))
            {
                case K_BUILD:
                    switch (i = getkeyword ())
                    {
                        case K_BUILDING:
                            if (!effskill (u,SK_BUILDING))
                            {
                                mistakeu (u,"You don't have the skill");
                                break;
                            }

                            if (!u->items[I_STONE])
                            {
                                mistakeu (u,"No stone available");
                                break;
                            }

                            b = getbuilding (r);

                            if (!b)
                            {
                                b = cmalloc (sizeof (building));
                                memset (b,0,sizeof (building));

                                do
                                {
                                    b->no++;
                                    sprintf (b->name,"Building %d",b->no);
                                }
                                while (findbuilding (b->no));

                                addlist (&r->buildings,b);

                                leave (r,u);
                                u->building = b;
                                u->owner = 1;
                            }

                            n = u->number * effskill (u,SK_BUILDING);
                            n = min (n,u->items[I_STONE]);
                            b->size += n;
                            u->items[I_STONE] -= n;

                            u->skills[SK_BUILDING] += n * 10;

                            sprintf (buf,"%s adds %d to %s.",unitid (u),n,buildingid (b));
                            addevent (u->faction,buf);
                            break;

                        case K_SHIP:
                            if (!effskill (u,SK_SHIPBUILDING))
                            {
                                mistakeu (u,"You don't have the skill");
                                break;
                            }

                            if (!u->items[I_WOOD])
                            {
                                mistakeu (u,"No wood available");
                                break;
                            }

                            sh = getship (r);

                            if (sh == 0)
                            {
                                mistakeu (u,"Ship not found");
                                break;
                            }

                            if (!sh->left)
                            {
                                mistakeu (u,"Ship is already complete");
                                break;
                            }

BUILDSHIP:
                            n = u->number * effskill (u,SK_SHIPBUILDING);
                            n = min (n,sh->left);
                            n = min (n,u->items[I_WOOD]);
                            sh->left -= n;
                            u->items[I_WOOD] -= n;

                            u->skills[SK_SHIPBUILDING] += n * 10;

                            sprintf (buf,"%s adds %d to %s.",unitid (u),n,shipid (sh));
                            addevent (u->faction,buf);
                            break;

                        case K_LONGBOAT:
                            i = SH_LONGBOAT;
                            goto CREATESHIP;

                        case K_CLIPPER:
                            i = SH_CLIPPER;
                            goto CREATESHIP;

                        case K_GALLEON:
                            i = SH_GALLEON;
                            goto CREATESHIP;

CREATESHIP:
                            if (!effskill (u,SK_SHIPBUILDING))
                            {
                                mistakeu (u,"You don't have the skill");
                                break;
                            }

                            sh = cmalloc (sizeof (ship));
                            memset (sh,0,sizeof (ship));

                            sh->type = i;
                            sh->left = shipcost[i];

                            do
                            {
                                sh->no++;
                                sprintf (sh->name,"Ship %d",sh->no);
                            }
                            while (findship (sh->no));

                            addlist (&r->ships,sh);

                            leave (r,u);
                            u->ship = sh;
                            u->owner = 1;
                            goto BUILDSHIP;

                        default:
                            mistakeu (u,"Order not recognized");
                    }

                    break;

                case K_ENTERTAIN:
                    o = cmalloc (sizeof (order));
                    o->unit = u;
                    o->qty = u->number * effskill (u,SK_ENTERTAINMENT) * ENTERTAININCOME;
                    addlist (&entertainorders,o);
                    break;

                case K_PRODUCE:
                    i = getitem ();

                    if (i < 0 || i > I_PLATE_ARMOR)
                    {
                        mistakeu (u,"Item not recognized");
                        break;
                    }

                    n = effskill (u,itemskill[i]);

                    if (n == 0)
                    {
                        mistakeu (u,"You don't have the skill");
                        break;
                    }

                    if (i == I_PLATE_ARMOR)
                        n /= 3;

                    n *= u->number;

                    if (i < 4)
                    {
                        o = cmalloc (sizeof (order));
                        o->unit = u;
                        o->qty = n * productivity[r->terrain][i];
                        addlist (&produceorders[i],o);
                    }
                    else
                    {
                        n = min (n,u->items[rawmaterial[i]]);

                        if (n == 0)
                        {
                            mistakeu (u,"No material available");
                            break;
                        }

                        u->items[i] += n;
                        u->items[rawmaterial[i]] -= n;

                        if (n == 1)
                            sprintf (buf,"%s produces 1 %s.",unitid (u),itemnames[0][i]);
                        else
                            sprintf (buf,"%s produces %d %s.",unitid (u),n,itemnames[1][i]);
                        addevent (u->faction,buf);
                    }

                    u->skills[itemskill[i]] += u->number * PRODUCEEXP;
                    break;

                case K_RESEARCH:
                    if (effskill (u,SK_MAGIC) < 2)
                    {
                        mistakeu (u,"Magic skill of at least 2 required");
                        break;
                    }

                    i = geti ();

                    if (i > effskill (u,SK_MAGIC) / 2)
                    {
                        mistakeu (u,"Insufficient Magic skill - highest available level researched");
                        i = 0;
                    }

                    if (i == 0)
                        i = effskill (u,SK_MAGIC) / 2;

                    k = 0;

                    for (j = 0; j != MAXSPELLS; j++)
                        if (spelllevel[j] == i && !u->spells[j])
                            k = 1;

                    if (k == 0)
                    {
                        if (u->money < 200)
                        {
                            mistakeu (u,"Insufficient funds");
                            break;
                        }

                        for (n = u->number; n; n--)
                            if (u->money >= 200)
                            {
                                u->money -= 200;
                                u->skills[SK_MAGIC] += 10;
                            }

                        sprintf (buf,"%s discovers that no more level %d spells exist.",
                                    unitid (u),i);
                        addevent (u->faction,buf);
                        break;
                    }

                    for (n = u->number; n; n--)
                    {
                        if (u->money < 200)
                        {
                            mistakeu (u,"Insufficient funds");
                            break;
                        }

                        do
                            j = rnd () % MAXSPELLS;
                        while (spelllevel[j] != i || u->spells[j] == 1);

                        if (!u->faction->seendata[j])
                        {
                            u->faction->seendata[j] = 1;
                            u->faction->showdata[j] = 1;
                        }

                        if (u->spells[j] == 0)
                        {
                            sprintf (buf,"%s discovers the %s spell.",
                                        unitid (u),spellnames[j]);
                            addevent (u->faction,buf);
                        }

                        u->spells[j] = 2;
                        u->skills[SK_MAGIC] += 10;
                    }

                    for (j = 0; j != MAXSPELLS; j++)
                        if (u->spells[j] == 2)
                            u->spells[j] = 1;
                    break;

                case K_TEACH:
                    teaching = u->number * 30 * TEACHNUMBER;
                    m = 0;

                    do
                        uv[m++] = getunit (r,u);
                    while (!getunit0 && m != 100);

                    m--;

                    for (j = 0; j != m; j++)
                    {
                        u2 = uv[j];

                        if (!u2)
                        {
                            mistakeu (u,"Unit not found");
                            continue;
                        }

                        if (!accepts (u2,u))
                        {
                            mistakeu (u,"Unit does not accept teaching");
                            continue;
                        }

                        i = igetkeyword (u2->thisorder);

                        if (i != K_STUDY || (i = getskill ()) < 0)
                        {
                            mistakeu (u,"Unit not studying");
                            continue;
                        }

                        if (effskill (u,i) <= effskill (u2,i))
                        {
                            mistakeu (u,"Unit not studying a skill you can teach it");
                            continue;
                        }

                        n = (u2->number * 30) - u2->learning;
                        n = min (n,teaching);

                        if (n == 0)
                            continue;

                        u2->learning += n;
                        teaching -= u->number * 30;

                        strcpy (buf,unitid (u));
                        scat (" teaches ");
                        scat (unitid (u2));
                        scat (" ");
                        scat (skillnames[i]);
                        scat (".");

                        addevent (u->faction,buf);
                        if (u2->faction != u->faction)
                            addevent (u2->faction,buf);
                    }

                    break;

                case K_WORK:
                    o = cmalloc (sizeof (order));
                    o->unit = u;
                    o->qty = u->number * foodproductivity[r->terrain];
                    addlist (&workorders,o);
                    break;
            }

                /* Entertainment */

        expandorders (r,entertainorders);

        for (i = 0, n = r->money / ENTERTAINFRACTION; i != norders && n; i++, n--)
        {
            oa[i].unit->money++;
            r->money--;
            oa[i].unit->n++;
        }

        free (oa);

        for (u = r->units; u; u = u->next)
            if (u->n >= 0)
            {
                sprintf (buf,"%s earns $%d entertaining.",unitid (u),u->n);
                addevent (u->faction,buf);

                u->skills[SK_ENTERTAINMENT] += 10 * u->number;
            }

                /* Food production */

        expandorders (r,workorders);

        for (i = 0, n = maxfoodoutput[r->terrain]; i != norders && n; i++, n--)
        {
            oa[i].unit->money++;
            oa[i].unit->n++;
        }

        free (oa);

        r->money += min (n,r->peasants * foodproductivity[r->terrain]);

        for (u = r->units; u; u = u->next)
            if (u->n >= 0)
            {
                sprintf (buf,"%s earns $%d performing manual labor.",unitid (u),u->n);
                addevent (u->faction,buf);
            }

                /* Production of other primary commodities */

        for (i = 0; i != 4; i++)
        {
            expandorders (r,produceorders[i]);

            for (j = 0, n = maxoutput[r->terrain][i]; j != norders && n; j++, n--)
            {
                oa[j].unit->items[i]++;
                oa[j].unit->n++;
            }

            free (oa);

            for (u = r->units; u; u = u->next)
                if (u->n >= 0)
                {
                    if (u->n == 1)
                        sprintf (buf,"%s produces 1 %s.",unitid (u),itemnames[0][i]);
                    else
                        sprintf (buf,"%s produces %d %s.",unitid (u),u->n,itemnames[1][i]);
                    addevent (u->faction,buf);
                }
        }
    }

            /* Study skills */

    puts ("Processing STUDY orders...");

    for (r = regions; r; r = r->next)
        if (r->terrain != T_OCEAN)
            for (u = r->units; u; u = u->next)
                switch (igetkeyword (u->thisorder))
                {
                    case K_STUDY:
                        i = getskill ();

                        if (i < 0)
                        {
                            mistakeu (u,"Skill not recognized");
                            break;
                        }

                        if (i == SK_TACTICS || i == SK_MAGIC)
                        {
                            if (u->money < STUDYCOST * u->number)
                            {
                                mistakeu (u,"Insufficient funds");
                                break;
                            }

                            if (i == SK_MAGIC && !u->skills[SK_MAGIC] &&
                                 magicians (u->faction) + u->number > 3)
                            {
                                mistakeu (u,"Only 3 magicians per faction");
                                break;
                            }

                            u->money -= STUDYCOST * u->number;
                        }

                        sprintf (buf,"%s studies %s.",unitid (u),skillnames[i]);
                        addevent (u->faction,buf);

                        u->skills[i] += (u->number * 30) + u->learning;
                        break;
                }

            /* Ritual spells, and loss of spells where required */

    puts ("Processing CAST orders...");

    for (r = regions; r; r = r->next)
    {
        for (u = r->units; u; u = u->next)
        {
            for (i = 0; i != MAXSPELLS; i++)
                if (u->spells[i] && spelllevel[i] > (effskill (u,SK_MAGIC) + 1) / 2)
                    u->spells[i] = 0;

            if (u->combatspell >= 0 && !cancast (u,u->combatspell))
                u->combatspell = -1;
        }

        if (r->terrain != T_OCEAN)
            for (u = r->units; u; u = u->next)
                switch (igetkeyword (u->thisorder))
                {
                    case K_CAST:
                        i = getspell ();

                        if (i < 0 || !cancast (u,i))
                        {
                            mistakeu (u,"Spell not found");
                            break;
                        }

                        j = spellitem (i);

                        if (j >= 0)
                        {
                            if (u->money < 200 * spelllevel[i])
                            {
                                mistakeu (u,"Insufficient funds");
                                break;
                            }

                            n = min (u->number,u->money / (200 * spelllevel[i]));
                            u->items[j] += n;
                            u->money -= n * 200 * spelllevel[i];
                            u->skills[SK_MAGIC] += n * 10;

                            sprintf (buf,"%s casts %s.",unitid (u),spellnames[i]);
                            addevent (u->faction,buf);
                            break;
                        }

                        if (u->money < 50)
                        {
                            mistakeu (u,"Insufficient funds");
                            break;
                        }

                        switch (i)
                        {
                            case SP_CONTAMINATE_WATER:
                                n = cancast (u,SP_CONTAMINATE_WATER);
                                n = min (n,u->money / 50);

                                u->money -= n * 50;
                                u->skills[SK_MAGIC] += n * 10;

                                n = lovar (n * 50);
                                n = min (n,r->peasants);

                                if (!n)
                                    break;

                                r->peasants -= n;

                                for (f = factions; f; f = f->next)
                                {
                                    j = cansee (f,r,u);

                                    if (j)
                                    {
                                        if (j == 2)
                                            sprintf (buf,"%s contaminates the water supply "
                                                        "in %s, causing %d peasants to die.",
                                                        unitid (u),regionid (r),n);
                                        else
                                            sprintf (buf,"%d peasants die in %s from "
                                                        "drinking contaminated water.",
                                                        n,regionid (r));
                                        addevent (f,buf);
                                    }
                                }

                                break;

                            case SP_TELEPORT:
                                u2 = getunitg (r,u);

                                if (!u2)
                                {
                                    mistakeu (u,"Unit not found");
                                    break;
                                }

                                if (!admits (u2,u))
                                {
                                    mistakeu (u,"Target unit does not provide vector");
                                    break;
                                }

                                for (r2 = regions;; r2 = r2->next)
                                {
                                    for (u3 = r2->units; u3; u3 = u3->next)
                                        if (u3 == u2)
                                            break;

                                    if (u3)
                                        break;
                                }

                                n = cancast (u,SP_TELEPORT);
                                n = min (n,u->money / 50);

                                u->money -= n * 50;
                                u->skills[SK_MAGIC] += n * 10;

                                n *= 10000;

                                for (;;)
                                {
                                    u3 = getunit (r,u);

                                    if (getunit0)
                                        break;

                                    if (!u3)
                                    {
                                        mistakeu (u,"Unit not found");
                                        continue;
                                    }

                                    if (!accepts (u3,u))
                                    {
                                        mistakeu (u,"Unit does not accept teleportation");
                                        continue;
                                    }

                                    i = itemweight (u3) + horseweight (u3) + (u->number * 10);

                                    if (i > n)
                                    {
                                        mistakeu (u,"Unit too heavy");
                                        continue;
                                    }

                                    leave (r,u3);
                                    n -= i;
                                    translist (&r->units,&r2->units,u3);
                                    u3->building = u2->building;
                                    u3->ship = u2->ship;
                                }

                                sprintf (buf,"%s casts Teleport.",unitid (u));
                                addevent (u->faction,buf);
                                break;

                            default:
                                mistakeu (u,"Spell not usable with CAST command");
                        }

                        break;
                }
    }

            /* Population growth, dispersal and food consumption */

    puts ("Processing demographics...");

    for (r = regions; r; r = r->next)
    {
        if (r->terrain != T_OCEAN)
        {
            for (n = r->peasants; n; n--)
                if (rnd () % 100 < POPGROWTH)
                    r->peasants++;

            n = r->money / MAINTENANCE;
            r->peasants = min (r->peasants,n);
            r->money -= r->peasants * MAINTENANCE;

            for (n = r->peasants; n; n--)
                if (rnd () % 100 < PEASANTMOVE)
                {
                    i = rnd () % 4;

                    if (r->connect[i]->terrain != T_OCEAN)
                    {
                        r->peasants--;
                        r->connect[i]->immigrants++;
                    }
                }
        }

        for (u = r->units; u; u = u->next)
        {
            getmoney (r,u,u->number * MAINTENANCE);
            n = u->money / MAINTENANCE;

            if (u->number > n)
            {
                if (n)
                    sprintf (buf,"%s loses %d to starvation.",unitid (u),u->number - n);
                else
                    sprintf (buf,"%s starves to death.",unitid (u));
                addevent (u->faction,buf);

                for (i = 0; i != MAXSKILLS; i++)
                    u->skills[i] = distribute (u->number,n,u->skills[i]);

                u->number = n;
            }

            u->money -= u->number * MAINTENANCE;
        }
    }

    removeempty ();

    for (r = regions; r; r = r->next)
        r->peasants += r->immigrants;

            /* Warn players who haven't sent in orders */

    for (f = factions; f; f = f->next)
        if (turn - f->lastorders == ORDERGAP)
            addstrlist (&f->messages,"Please send orders next turn if you wish to continue playing.");
}

"""

def rstrlist(fileObject, list, debug):
    """ Read strings into the list, one per line """
    numStrings = int(fileObject.readline().strip())
    if debug: print "", numStrings, "strings"
    for i in range(numStrings):
        list.append(fileObject.readline().strip())
        if debug:
            print " read: ", list[-1]


def readgame(debug=False):
    """ Read the game state in from a file """
    global turn
    gameFile = open("data/%d" % turn)
    if debug: print "Reading turn %d..." % turn

    turn = int(gameFile.readline().strip())
    if debug: print "turn", turn
    
    numFacs = int(gameFile.readline().strip())
    if debug: print "%s factions" % numFacs

    for n in range(numFacs):
        f = Faction()
        
        line = gameFile.readline().strip().split("|")
        if debug: print " ",line

        f.no = int(line[0])
        f.name = line[1]
        f.addr = line[2]
        f.lastorders = int(line[3])

        for i in range(MAXSPELLS):
            f.showdata[i] = int(line[i+4])

        numAllies = int(gameFile.readline().strip())
        if debug: print "", numAllies, "allies"
        if numAllies:
            allies = gameFile.readline().strip().split("|")
            if debug: print " ",allies
            for n2 in range(numAllies):
                rf = RFaction()
                rf.factionno = int(allies[n2])
                f.allies.append(rf)
        
        rstrlist(gameFile, f.mistakes, debug)
        rstrlist(gameFile, f.messages, debug)
        rstrlist(gameFile, f.battles, debug)
        rstrlist(gameFile, f.events, debug)

        factions.append(f)

    # Read regions

    numRegions = int(gameFile.readline().strip())
    if debug: print "numRegions:", numRegions

    for n in range(numRegions):
        r = Region()
        line = gameFile.readline().strip().split("|")
        if debug: print line

        r.x = int(line[0])
        r.y = int(line[1])
        r.name = line[2]
        r.terrain = int(line[3])
        r.peasants = int(line[4])
        r.money = int(line[5])
        r.units = []

        regions.append(r)

        numBuildings = int(gameFile.readline().strip())
        if debug: print "numBuildings:", numBuildings
        for n2 in range(numBuildings):
            b = Building()

            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            b.no = int(line[0])
            b.name = line[1]
            b.display = line[2]
            b.size = int(line[3])
            r.buildings.append(b)

        numShips = int(gameFile.readline().strip())
        if debug: print "numShips:", numShips
        for n2 in range(numShips):
            sh = Ship()
            
            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            sh.no = int(line[0])
            sh.name = line[1]
            sh.display = line[2]
            sh.type = int(line[3])
            sh.left = int(line[4])
            
            region.ships.append(sh)

        numUnits = int(gameFile.readline().strip())
        if debug: print "numUnits:", numUnits
        for n2 in range(numUnits):
            u = Unit()

            line = gameFile.readline().strip().split("|")
            if debug: print " ",line
            u.no = int(line[0])
            u.name = line[1]
            u.display = line[2]
            u.number = int(line[3])
            u.money = int(line[4])
            u.faction = findfaction( int(line[5]) )
            u.building = findbuilding( int(line[6]) )
            u.ship = findship( int(line[7]) )
            u.owner = int(line[8])
            u.behind = int(line[9])
            u.guard = int(line[10])
            u.lastorder = line[11]
            u.combatspell = int(line[12])

            for i in range(MAXSKILLS):
                u.skills[i] = int(line[13+i])

            for i in range(MAXITEMS):
                u.items[i] = int(line[13+MAXSKILLS+i])

            for i in range(MAXSPELLS):
                u.spells[i] = int(line[13+MAXSKILLS+MAXITEMS+i])

            r.units.append(u)

    # Get rid of stuff that was only relevant last turn
    for f in factions:
        f.showdata = [0] * MAXSPELLS
        
        f.mistakes = []
        f.messages = []
        f.battles = []
        f.events = []

    # link rfaction structures
    for f in factions:
        for rf in f.allies:
            rf.faction = findfaction(rf.factionno)

    for r in regions:
        # Initialize faction seendata values
        for u in r.units:
            if u.spells[i]:
                u.faction.seendata[i] = 1

            # Check for alive factions
            u.faction.alive = 1

    connectregions()
    gameFile.close()


def wstrlist(fileObject, S):
    """ Write the list of strings out to the fileObject, one per line """
    fileObject.write( str(len(S)) )
    fileObject.write("\n")
    for item in S:
        fileObject.write(item)
        fileObject.write("\n")


def writegame():
    """ Write the game state out to a data file """
    global turn
    gameFile = open("data/%d" % turn, "w")
    print "Writing turn %d" % turn

    write = gameFile.write
    
    write(str(turn))
    write('\n')
    
    # write factions

    write(str(len(factions)))
    write('\n')

    for f in factions:
        write(str(f.no))
        write("|")
        write(f.name)
        write("|")
        write(f.addr)
        write("|")
        write(str(f.lastorders))

        for i in range(MAXSPELLS):
            write("|")
            write(str(f.showdata[i]))
        write("\n")

        write(str(len(f.allies)))
        write("\n")
        for rf in f.allies:
            write(str(rf.faction.no))
            write("\n")
        
        wstrlist(gameFile, f.mistakes)
        wstrlist(gameFile, f.messages)
        wstrlist(gameFile, f.battles)
        wstrlist(gameFile, f.events)

    # Write regions

    write(str(len(regions)))
    write("\n")
    for r in regions:
        write(str(r.x))
        write("|")
        write(str(r.y))
        write("|")
        write(r.name)
        write("|")
        write(str(r.terrain))
        write("|")
        write(str(r.peasants))
        write("|")
        write(str(r.money))
        write("\n")

        write(str(len(r.buildings)))
        write("\n")

        for b in r.buildings:
            write(str(b.no))
            write("|")
            write(b.name)
            write("|")
            write(b.display)
            write("|")
            write(str(b.size))
            write("\n")

        write(str(len(r.ships)))
        write("\n")

        for sh in r.ships:
            write(str(sh.no))
            write("|")
            write(sh.name)
            write("|")
            write(sh.display)
            write("|")
            write(str(sh.type))
            write("|")
            write(str(sh.left))
            write("\n")
        
        write(str(len(r.units)))
        write("\n")

        for u in r.units:
            write(str(u.no))
            write("|")
            write(u.name)
            write("|")
            write(u.display)
            write("|")
            write(str(u.number))
            write("|")
            write(str(u.money))
            write("|")
            write(str(u.faction.no))
            write("|")
            if u.building:
                write(str(u.building.no))
            else:
                write("0")
            write("|")
            if u.ship:
                write(str(u.ship.no))
            else:
                write("0")
            write("|")
            write(str(u.owner))
            write("|")
            write(str(u.behind))
            write("|")
            write(str(u.guard))
            write("|")
            write(u.lastorder)
            write("|")
            write(str(u.combatspell))

            for i in range(MAXSKILLS):
                write("|")
                write(str(u.skills[i]))

            for i in range(MAXITEMS):
                write("|")
                write(str(u.items[i]))

            for i in range(MAXSPELLS):
                write("|")
                write(str(u.spells[i]))

            write("\n")


def addunits():
    region = inputregion()
    if not region:
        return

    unitsFileName = raw_input("Name of units file? ")
    if not unitsFileName:
        return

    unitsFile = open(unitsFileName)

    while 1:
        line = unitsFile.readline().strip()
        if line.endswith("end"):
            return

        u = createunit(r)
        bits = line.split()
        u.name = bits[0]
        u.display = bits[1]
        u.number = int(bits[2])
        u.money = int(bits[3])
        u.faction = findfaction( int(bits[4]) )

        line = unitsFile.readline().strip()
        if line.endswith("end"):
            return
        line = line.split()
        while 1:
            try:
                j = line.pop(0)
                thingyName = line.pop(0)
            except IndexError:
                break
            
            if thingyName in skillnames:
                i = skillnames.index(thingyName)
                u.skills[i] = j
            elif thingyName in itemnames[0]:
                i = itemnames[0].index(thingyName)
                u.items[i] = j
            elif thingyName in spellnames:
                i = spellnames.index(thingyName)
                u.spells[i] = j
            else:
                print "Attribute %s not recognised" % thingyName


def initgame():
    """ Initialise the game """
    global turn
    
    files = os.listdir('.')
    
    if 'data' not in files:
        print "No data files found, creating game..."
        os.mkdir("data")
        makeblock(0,0)
        writesummary()
        writegame()
    else:
        turn = 0
        
        # TODO: not sure about this bit - the files might be (eg.) 1.txt
        #       and still work with atoi
        files = [fileName for fileName in os.listdir('data') if fileName.isdigit()]
        files.sort()
        latest = files[-1]
        readgame()


def processturn():
    """ Run a turn """
    global turn
    turn += 1
    readorders()
    processorders()
    reports()
    writesummary()
    writegame()


# TODO: createcontinent seems broken - it's meant to create separate continents,
#       but they all seem to be smooshed together with old ones.
#       (see halfway down http://www.prankster.com/project/docs/history.htm for how it should look)

# UPDATE: it seems to work ok, provided that there isn't already a continent already there,
#         so the bug is in makeblock, rather than createcontinent

def createcontinent():
    """ Make a continent """
    
    writemap(sys.stdout)

    while 1:
        temp = raw_input("X? ")
        if temp == "":
            return
        x = atoi(temp)

        temp = raw_input("Y? ")
        if temp == "":
            return
        y = atoi(temp)
        
        makeblock(x, y)
        
        # TODO: this was writing to F, but should write to stdout or a file,
        #       and it should be fed the relevant object
        writemap(sys.stdout)


def printhelp():
    print ("c - Create New Continent.\n"
           "a - Add New Players.\n"
           "u - Add New Units.\n"
           "m - Show map.\n"
           "p - Process Game Turn.\n"
           "s - Save Game.\n"
           "q - Quit.\n"
           "\n"
           "Debug:\n"
           "r - list regions")


def main():
    """ The main loop - lets the GM control the game """
    random.seed()
    print ("PyAtlantis v0.1 by Anthony Briggs\n"
           "based on the original Atlantis v1.0,\n"
           "which is Copyright 1993 by Russell Wallace.\n"
           "Type ? for list of commands.")
    
    initgame()
    
    while 1:
        input = raw_input(">").lower()
        if input == 'c':
            createcontinent()
        elif input == 'a':
            addplayers()
        elif input == 'u':
            addunits()
        elif input == 'p':
            processturn()

        # These are debugging functions
        elif input == 's':
            writesummary()
            writegame()
        elif input == 'm':
            writemap(sys.stdout)
        elif input == 'r':
            print regions
        
        elif input == 'q':
            break
        else:
            printhelp()


if __name__ == '__main__':
    main()

