#!/usr/local/bin/python

# A mail 'server' for thera, really just a program that looks over
# a directory and sends everything in it, retrying at intervals
# as specified in a crontab.

import sys, os, smtplib
from config import server, game

# Get the arguments that we're passed and check them
try:
    gamename = sys.argv[1]
except IndexError:
    gamename = ''

try:
    if gamename == '':
        # Run the email for the server...
        logfile = server['logfile']
        gamedir = server['basedir']
        maildir = server['maildir']
    else:
        thisgame = game[gamename]
        logfile = thisgame['logfile']
        gamedir = thisgame['basedir']
        maildir = thisgame['maildir']
except KeyError:
    print "I can't find game " + gamename
    sys.exit(1)


# Right, check the mail directory, and send out any files that we find there!
# The format of them will be
# them, me, then the rest of the message, 
# with the server being derived from the config file, 
# and the subject in the mailouttext

mailserver = smtplib.SMTP(server['smtpserver'])

if os.access(maildir, os.F_OK) != 1:
    os.mkdir(maildir)
gamefiles = os.listdir(maildir)

for eachfile in gamefiles:
    file = open(maildir+eachfile, 'r')
    them = file.readline()
    me   = file.readline()
    mailouttext = file.readlines()
    file.close()
    
    temp = ""
    for eachline in mailouttext:
        temp = temp + eachline
    mailouttext = temp
    
    #Now send the mail
    try:    
        mailserver.sendmail(me, them, mailouttext)
    except:
        pass  # Bugger!  Oh well, we'll get them next time...
    else:
        os.remove(maildir+eachfile) # Or could move them into a 'sent' folder

mailserver.quit()
