# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


# Routine to add a new player to the players.in file.

import mymail, re, fcntl
from mylog import log
from checkpassword import getnameandpass
from config import server, game

def create(mail, item):

    # Check that the game exists...
    try:
        thisgame = game[mail['gamename']]
    except KeyError:
        mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'], 
                        gamename+'? Haven\'t heard of that game. Are you sure '+
                        'you\'re on the right server?', 
                        server['maildir'] )
        return
        
    # parse the arguments in item
    (factionname, password) = getnameandpass(item[2])
    if (factionname, password) == (None, None):    # Nup, can't find the name & password!
        mymail.mailout( mail['them'],
                        mail['me'],
                        'Re: '+mail['subject'],
                        'Sorry, but you need to specify a #create order as:\n'+
                        '#create <faction name> <password>',
                        thisgame['maildir'] )
        return
    
    if factionname[0] == '"' or factionname[0] == '\'':
        factionname = factionname[1:-1] #Strip quotes
        
    if password[0] == '"' or password[0] == '\'':
        password = password[1:-1]       #Strip quotes
        
    # Now we can read players.in, which should be in the game directory
    
    playersfile = open(thisgame['basedir']+'players.in', 'r')

    # get the turn number from players.in
    ignored = playersfile.readline()
    ignored = playersfile.readline()
    turnnumber = int( playersfile.readline()[12:] )
    
    found = 'maybe'
    while 1:
        tempstring = playersfile.readline()
        if tempstring == '':
            found = 'no'
            break
            
        if re.search( factionname, tempstring) != None:
            found = 'factionname'
            break
            
        if re.search( mail['them'], tempstring) != None:
            found = 'email'
            break
    
    playersfile.close()
        
    # Check both that the player hasn't registered another faction,
    # and that the faction name isn't already taken.
    
    if found == 'email':
        mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'], 
                        'Bad, bad '+mail['them']+'. You\'ve already got '+
                        'a faction in this game! You just wait until the GM '+
                        'hears about this!', 
                        thisgame['maildir'] )
        #Let the GM know about it ;)
        log( thisgame['logfile'], mail['them']+
                                  ' tried to register *two* factions!')
        return
        
    if found == 'factionname':
        mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'], 
                        'Sorry, someone\'s already taken '+factionname+
                        ' as a faction name.', 
                        thisgame['maildir'] )
        return
        
    # Right, now we know that their choice is OK to add to the system.
    # Unless of course I've missed something...
    
    playersfile = open(thisgame['basedir'] + 'players.in', 'a')
    
    playersfile.write('Faction: new\n')
    playersfile.write('Name: '+factionname+'\n')
    playersfile.write('Email: '+mail['them']+'\n')
    playersfile.write('Password: '+password+'\n')
    playersfile.write('Lastorders: '+str(turnnumber)+'\nSendTimes: 1\nReady: 1\n')
    
    playersfile.close()
    
    # Now send them a welcome message, so they know they've joined properly.
    message = """Alrighty, I've added you to the players.in file. When the turn
is next run, you should get your first turn report. If you need help with 
submitting orders, you should send a #help command to the same email address 
that you sent your previous email to. That should give you a quick introduction
and a few pointers on using this interface. 

Thera, your friendly Atlantis Script"""
    
    mymail.mailout( mail['them'], 
                    mail['me'], 
                    'Welcome to '+thisgame['name']+', the Atlantis game.', 
                    message, 
                    thisgame['maildir'] )
    
    log(thisgame['logfile'], 'Created faction and sent email to player. '+
                             'Now exiting...')
    return