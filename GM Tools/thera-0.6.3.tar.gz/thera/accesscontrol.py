# Functions to assist in limiting access to thera
# ie. whitelists, blacklists, paidlists

import string, os
from config import server

def checklist(listname, email):
    """Given an email address, check whether it exists in a particular file."""
    
    email = email.lower()

    if os.access(listname, os.F_OK) != 1: 
        return 'nofile'
        
    file = open(listname, 'r')
    for line in file.readlines():
        if line.startswith(email):
            return 'yes'
        else:
            if ' ' in line: # must be a paidlist
                turns, line2 = string.split(line, ' ', 1)
                if line2.startswith(email):
                    if int(turns) <= 0:
                        return 'no' # Not up to date!
                    else:
                        return 'yes'
    file.close()
    return 'no'


def decrpaidlist(listname):
    """Decrement each account in the paidlist by 1 turn."""
    output = []
    
    file = open(listname, 'r')
    for line in file.readlines():
        if ' ' not in line or line.startswith('#'):
            continue # ignore it...
        turns, email = string.split(line, ' ', 1)
        if int(turns) <= 0:
            output.append(line) #Won't go below zero?
        else:
            turns = int(turns) - 1
            temp = str(turns)+" "+email
            output.append(temp)
    file.close()
    
    file = open(listname, 'w')
    for line in output:
        file.write(line)
    file.close()
    
    return

# Need a function to return a player's account status...
