#!/usr/local/bin/python

# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


## This is a script to run an atlantis turn, doing all the usual things,
# like:
# 1. compiling the times and rumour sections
# 2. running the turn
# 3. Mailing turn reports out to all of the players
# 4. Archiving and compressing all of the turns, gamefiles and orders
# 4. Renaming players.out and game.out
#
# The directory structure will be as follows:
# 1. All of the current game files will be in the base directory:
#     players.in, game.in, orders.*, times.*, rumour.* and log.txt
# 2. Archived directories will consist of all of these, plus report.*, and
#    will be numbered after the turn, eg. 0 1 2 ... up to the current turn

import os, sys, re, time, mymail, random, shutil
from mylog import log
from checkpassword import getplayerinfo, setplayerinfo
from config import server, game
from accesscontrol import decrpaidlist, checklist
from locking import lock_file, LOCK_EX, LOCK_UN

### Some simple functions ###

def readfile(filename):
    mystring = ''
    input = open(filename, 'r')
    mystring = input.readlines()
    input.close()
    return mystring     #will be list of strings

#This one's used to randomise the rumours
def randcmp(list1, list2):
    """ Completely ignore the input functions, and return -1,0 or 1 randomly """
    return int(random.random()*3) - 1

#############################

# Get the arguments that we're passed and check them
try:
    gamename = sys.argv[1]
except IndexError:
    print "You need to specify which game you want to run!"
    sys.exit(1)
    
try:
    thisgame = game[gamename]
except KeyError:
    print "I can't find game " + gamename
    sys.exit(1)


logfile = thisgame['logfile']
gamedir = game[gamename]['basedir']

# Now get the lockfile and attempt to lock it...
lock_file( thisgame['lockfile'], LOCK_EX )
# If we got here, we have lockage!

# get the turn number from players.in
tempfile = open( gamedir+'players.in', 'r')
ignored = tempfile.readline()
ignored = tempfile.readline()
turnnumber = int( tempfile.readline()[12:] ) + 1
tempfile.close()

# Create an archive for the old turns. eg turn 2 will be directory '2'
try:
    os.mkdir( gamedir+str(turnnumber), 0700 )
except OSError:
    pass # directory must already exist

# Move all of last turn's report files and template files
gamefiles = os.listdir( gamedir )
for file in gamefiles:
    if file[:7] == 'report.' or file[:9] == 'template.':
        shutil.move ( gamedir+file, os.path.join(gamedir+str(turnnumber), file) )
        
# Read in all of the times and rumour sections, and shuffle the rumours
times = []; rumours = []; timesout = []; theheader = []
gamefiles = os.listdir( gamedir )
for file in gamefiles:
    if file[:7] == 'rumour.':
        rumours.append(readfile(gamedir+file))
    elif file[:6] == 'times.':
        times.append(readfile(gamedir+file))

# Randomise the rumours
rumours.sort(randcmp)

# Read in a times header, if it exists
if 'header.times' in gamefiles:
    timesheader = open(gamedir+'header.times', 'r')
    theheader = timesheader.readlines()
    timesheader.close()
    for line in theheader:
        timesout.append(line)

# Now put the times and rumours in...
if timesout != [] and not timesout[-1].endswith('\n'): 
    timesout.append('\n')
timesout.append('='*70)
timesout.append('\n')

for entry in times:
    for line in entry:
        timesout.append(line)
    if timesout[-1][-1] != '\n': timesout.append('\n')
    timesout.append('-'*70)   # spacer between times reports
    timesout.append('\n')
    
if times == []:
    timesout.append('There were no times reports this turn.\n')
        
timesout.append('='*70)
timesout.append('\n')

for entry in rumours:
    for line in entry:
        timesout.append(line)
    if timesout[-1][-1] != '\n': timesout.append('\n')
    timesout.append('-'*70)   # spacer between rumours
    timesout.append('\n')
    
if rumours == []:
    timesout.append('There were no rumours this turn.\n')

timesout.append('='*70)
timesout.append('\n')

# timesout is now the complete set of times & rumours, 
# we'll send it at the same time as the reports


### Run the atlantis turn
if os.access(thisgame['basedir']+'*.out', os.F_OK) == 1:
    log( logfile, 'Game execution stopped since there are output'+
                  'files still in the game directory.' )
    sys.exit(1)

os.chdir( gamedir )
thingo = os.popen( game[gamename]['exec']+' run')

ignored = thingo.readlines() # Seem to need this so that the executable
                             # doesn't go into the background.

# move all of game.in, players.in, times.*, rumour.*, orders.* and email.* 
# into the archive directory. 

gamefiles = os.listdir( gamedir )
moveablefiles = [ 'times.', 'rumour', 'orders', 'check.', 'email.']
for file in gamefiles:
    if file == 'players.in' or file == 'game.in' or file[:6] in moveablefiles:
        shutil.move(gamedir+file, os.path.join(gamedir+str(turnnumber), file))
        
# Save the complete times to a file now that we've moved the old times files, 
# so that we can resend it again if necessary
timesfile = open(gamedir+'times.all', 'w+')
for line in timesout:
    timesfile.write(line)
timesfile.close()

### rename players.out and game.out
# If we do this bit now, we can use our existing functions to get player 
# names and emails, instead of writing new ones to read *.out.
# Also, if we try and get faction names before this, (ie. from the old 
# players.in) we don't send reports out to new factions, since they're still 
# listed as 'Faction: new'

try:  #might be turn 0
    os.rename( gamedir+'players.out', gamedir+'players.in' )
    os.rename( gamedir+'game.out', gamedir+'game.in' )
except OSError:
    pass

# All we should have left is the logfile, players.in, game.in, 
# the lock file, times.all and the report.* files
# Now we can mail turn reports out to all of the players.
gamefiles = os.listdir(gamedir)

for file in gamefiles:
    if file[:7] == 'report.':
        factionnumber = re.search('\.(\d+)', file).group(1)
        if int(factionnumber) < 3:
            continue    #guards & monsters don't get email ;)
            
        player = getplayerinfo(gamename, factionnumber)
        if player['name'] == 'unknown':
            log( logfile, 'Found '+file+', but faction ('+factionnumber+
                          ') doesn\'t have any details in the players.in file.')
            continue # skip this one, since we don't know what to do with it
        
        
        ### Check that the player is allowed to submit orders
        whitelist = checklist(thisgame['basedir']+'whitelist', player['email'])
        blacklist = checklist(thisgame['basedir']+'blacklist', player['email'])
        paidlist  = checklist(thisgame['basedir']+'paidlist',  player['email'])

        if blacklist == 'yes':
            #They're on the naughty list!
            log (logfile, player['email']+" is blacklisted!" )
            continue
        if whitelist != 'yes' and paidlist == 'no':
            log (logfile, player['email']+" is not in the whitelist and not paid up!" )
            continue
        
        # Read in the turn report for that player
        # (as a string, so we can search it for the orders template later)
        theturnreport = ''
        turnfile = open(gamedir+file, 'r')
        while 1:
            fileinput = turnfile.readline()
            if fileinput == '':
                break
            theturnreport = theturnreport + fileinput
        turnfile.close()
        
        # Grab the template file too, if there is one
        if os.access(thisgame['basedir']+'template.'+str(factionnumber), os.F_OK) == 1:
            templatefile = open(gamedir+'template.'+str(factionnumber), 'r')
            while 1:
                fileinput = templatefile.readline()
                if fileinput == '':
                    break
                theturnreport = theturnreport + fileinput
            templatefile.close()
        
        # And mail it out
        mymail.mailout(player['email'], 
                       thisgame['email'], 
                       'Atlantis Game <'+gamename+'> Turn '+
                       str(turnnumber)+' Report for '+player['name'],
                       theturnreport, 
                       thisgame['maildir'])
        log (logfile, 'Mailed turn report to '+player['email'] )
        
        # If they want the times, mail that out, too.
        if getplayerinfo(gamename, factionnumber)['sendtimes'] == '1':
            mymail.mailout(player['email'], 
                           thisgame['email'], 
                           'Atlantis Times for <'+gamename+
                           '> Turn '+str(turnnumber),
                           timesout, 
                           thisgame['maildir'])
            log (logfile, 'Mailed the times to '+player['email'] )
        
        # Grab the template off the end of the report and save it as orders.??
        # just in case they haven't submitted orders by next turn.
        # This is left in so that Thera is still compatible with version 4
        # otherwise we could just copy template.?? to orders.??
        wibble = re.search('(?s)(#atlantis.*\n#end)', theturnreport)
        if wibble != None:
            nextturnsorders = open(gamedir+'orders.'+str(factionnumber), 'w')
            nextturnsorders.write(wibble.group(1))
            nextturnsorders.close()
            
## We leave this turn's reports in the directory, so that #resend will work ;)

## Now decrement the paid list, since we've run the turn
if os.access(thisgame['basedir']+"paidlist", os.F_OK) == 1:
    decrpaidlist(thisgame['basedir']+"paidlist")

## TODO: Check and warn them if their account is getting low?

## Compress the turn files
# Compress individual turn folders into their own zip files within
# the game directory, and add a salt/version number to the
# end if we're re-running the turn.

turnfolder = thisgame['basedir'] + str(turnnumber)
turntarfile = turnfolder + '.tar'
turnzipfile = turnfolder + '.tar' + server['zipsuffix']

# if the zip file already exists, try again with a salt number
# added to the end, incrementing it until a free filename is found.
salt = 1
while os.access(turnzipfile, os.F_OK) == 1:
    turnfolder = thisgame['basedir'] + str(turnnumber)+'.'+str(salt)
    turntarfile = turnfolder+'.tar'
    turnzipfile = turnfolder+'.tar'+server['zipsuffix']
    salt += 1

log(logfile, 'The turn folder is: '+turnfolder)
log(logfile, 'The turn zip file will be: '+turnzipfile)

commandstr = server['tar']+' -cf '+turntarfile+' '+turnfolder
os.system(commandstr)

commandstr = server['zip']+' '+turntarfile
os.system(commandstr)

# Uncomment these lines if you want to delete the old turn folder
# when the turn's finished running. I'm a bit too much of a 
# wussy sysadmin to enable this option, plus I have a fairly 
# large hard drive, but if you're running a large game, you 
# might want to save some space.
#commandstr = '/bin/rm -rf '+turnfolder
#os.system(commandstr)
# under windows, you might need to do:
# shutil.rmtree(turnfolder) # this is untested!


log( logfile, 'Finished processing turn '+str(turnnumber)+
              ' for game '+gamename+'.' )
lock_file( thisgame['lockfile'], LOCK_UN )
