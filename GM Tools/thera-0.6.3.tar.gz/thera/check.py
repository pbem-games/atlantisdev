# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


# Script to process incoming orders, check them, and email the results back

# Called as: check.checkturn(mail, turn), where:
# turn is a list of all of the orders, from '#atlantis ...' to '#end'
# mail is a dictionary of all of the associated stuff, such as gamename
# and user email, faction and password.

# Here's a canonical list:
# mail['me']  
# mail['them']  
# mail['replyto'] 
# mail['subject']
# mail['body']   
# mail['gamename'] 
# mail['factionnumber'] 
# mail['password'] 

import mymail, fcntl, os, re, time
from mylog import log
from config import server, game
from checkpassword import checkpassword, setplayerinfo

# Here's the main procedure. It's meant to get the parsed info from atlantis.py,
# run the turn checker, and email the result back, all on it's lonesome ;)
# At some point, it should also update the lastorders bit in players.in

def checkturn(mail, turn):
    """ Check an atlantis turn, and mail the results back to the player. """
    
    thisgame = game[mail['gamename']]
    
    # Call checkpassword to make sure that the password and faction number
    # from mail[''] are ok.
    
    if checkpassword(thisgame['name'], mail['factionnumber'], mail['password']) != 'ok':
        mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'],
                        'Faction '+mail['factionnumber']+"? Haven't heard of "+
                        'that one.  Are you sure you got the password right?', 
                        thisgame['maildir'] )
        return
    
    # Now start doing that checking thang
    ordersfile = thisgame['basedir'] + 'orders.' + mail['factionnumber']
    checkfile  = thisgame['basedir'] + 'check.'  + mail['factionnumber']
    
    # Save the orders into orders.fn
    output = open(ordersfile, 'w')
    for line in turn:
        output.write(line + '\n')
    output.close()

    # Atlantis fails if check.<fn> already exists, so delete it.
    if os.access(checkfile, os.F_OK) == 1:
        os.remove(checkfile)  
    
    # Now check the turn with the Atlantis program
    command = thisgame['exec']+' check '+ordersfile+' '+checkfile
    checkprog = os.popen(command)
    ignored = checkprog.readlines() # Need this to stop the script until 
                                    # the turn checker's finished
    
    # Check for the existence of checkfile before we open it
    if os.access(checkfile, os.F_OK) != 1:
        # Log the command we just tried to run
        log(thisgame['logfile'], 'There was a problem checking the orders for '+
                     'faction '+mail['factionnumber']+'.  I ran '+command+
                     ', but there was no check file afterwards.')
        
        # And mail the player, to let them know what happened
        mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'],
                        'There was an error checking your turn.  Please contact '+
                        'the GM to find out what\'s up with the server', 
                        thisgame['maildir'] )
        return
    
    #read in checkfile
    check = open(checkfile, 'r')
    turncheck = check.readlines()
    check.close()
    
    # get the turn number from players.in
    tempfile = open( thisgame['basedir']+'players.in', 'r')
    ignored = tempfile.readline()
    ignored = tempfile.readline()
    turnnumber = int( tempfile.readline()[12:] )
    tempfile.close()
    
    # mail it to the person who sent it
    mailto = mail['them']
    subject = 'Atlantis game <'+mail['gamename']+'> orders check for faction '
    subject = subject + mail['factionnumber']+', turn '+str(turnnumber)
                  
    mymail.mailout(mail['them'], mail['me'], subject, 
                   turncheck, thisgame['maildir'])
                   
    # Set the LastOrders field
    setplayerinfo(mail['gamename'], mail['factionnumber'], 'lastorders', str(turnnumber))
    
    # Finish up...
    log(thisgame['logfile'], 'Received orders for faction ' +
                              mail['factionnumber'])
    return
