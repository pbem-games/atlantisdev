# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


### Defines some common functions that I use with email
### 1) mailout sends an email to a given address
### 2) getheadersand body splits a text email into headers and body
### 3) mailin pulls the from, to, replyto, subject and body out of a
###    received email
### 4) Frob 'frobs' the email address (ie blah@blah.net) out of
###    email line.

import smtplib, socket, re, types, os, random


def filename(directory, nameprefix = "test", namesuffix=".txt"):
    """Create a random filename that doesn"t appear in the directory.
    It"ll consist of nameprefix, then six random characters."""

    alphalist = []
    for index in range(48,48+10)+range(97,97+26):
        #print index,"-",chr(index),"\t"
        alphalist.append(chr(index))
    while 1:
        filename = directory+nameprefix
        for i in range(0,6):
            filename = filename + random.choice(alphalist)
        if os.access(filename+namesuffix, os.F_OK) != 1:
            return filename+namesuffix


def mailout(them, me, subject, message, maildir):
    """ Formats and writes an email to the maildir for the game.
    Actually sending the email is now done from a separate process."""
    
    mailouttext = 'From: ' + me + '\nTo: ' + them + '\n'
    mailouttext = mailouttext + 'Sender: ' + me + '\n'
    mailouttext = mailouttext + 'Reply-To: ' + me + '\n'
    mailouttext = mailouttext + 'Subject: ' + subject + '\n\n'
    
    if type(message) == types.StringType:
        mailouttext = mailouttext + message + '\n'
    
    if os.access(maildir, os.F_OK) != 1:
        os.mkdir(maildir)

    file = open(filename(maildir,'mail',''), 'w+')
    file.write(them+'\n')
    file.write(me+'\n')
    file.write(mailouttext)
    if type(message) == types.ListType:
        file.writelines(message)
    file.write('\n')
    file.close()
    


def getheadersandbody(message):
    """ Splits an email into header and body sections, by looking for the
    content-?? line (usually just before the body) """
    
    headers = []; body = []
    inheaders = 'yes'
    
    ### Now get the headers
    for line in message:
        if inheaders == 'yes':
            if line == '\n' or line == '':
                inheaders = 'no'
            headers.append(line)
        else:
            body.append(line)
    return (headers,body) # as lists...

def unfold(headers):
    """Unfolds a set of headers, hopefully in accordance with
    RFC 822, section 3.1.1."""
    
    wrapstarts = ['  ', ' \t', '\t ', '\t\t']
    
    output = []
    for index in range(len(headers)):
        if headers[index][:2] in wrapstarts and len(output)>=1:
            output[-1] += headers[index]
        else:
            output.append(headers[index])
    return output
    
def mailin(message):
    """ Returns To:, From:, Reply-To:, Subject: and Body from 
    a text email (in a list) """
    
    headers, body = getheadersandbody(message)
    headers = unfold(headers)
    toline = ''; fromline = ''; subjectline = ''; replytoline = None;

    for line in headers:

        tolinesearch = re.search('^To: (.*)', line)
        if tolinesearch != None and toline == '':
            toline = tolinesearch.group(1)
            continue

        fromlinesearch = re.search('^From: (.*)', line)
        if fromlinesearch != None and fromline == '':
            fromline = fromlinesearch.group(1)
            continue

        subjectlinesearch = re.search('^Subject: (.*)', line)
        if subjectlinesearch != None and subjectline == '':
            subjectline = subjectlinesearch.group(1)
            continue

        # Reply-To may not always exist
        replytosearch = re.search('^Reply-To: (.*)', line)
        if replytosearch != None and replytoline == None:
            replytoline = replytosearch.group(1)
    
    return (toline, fromline, replytoline, subjectline, body)


def frob(email):
    """ Frob out the email from a string -- needed for players.in """
    
    # emails are generally in the following formats:
    # 1) blah@blah.net, blah@blah.blah.com.au, 
    # 2) blah blah <blah@blah.net>, "blah blah" <blah@blah.net>, (with <>'s)
    # 2b) This can also be blah@blah.net (blah blah)
    # any others?
    # 3) Damn tootin!  What about server email addresses, such as
    #    blah-gamename@blah.net or blah-gamename@blah.net? dang it!
         
    #Old version
    #matchstring = '((\w*[-+]*){0,1}?\w+@\w+(\.\w+)+)'

    # New version to catch emails with hyphens in (d'oh!)
    # and full stops in names (double d'oh!)
    words = '(\w+[+-\.]{0,1})+'              # words with hyphens, pluses or dots
    matchstring = '('+words+'@'+words+')'   # stitch it all together

    frob = re.search(matchstring, email)  # second type
    
    if frob != None:
        return frob.group(1)
#    elif re.search(matchstring,email) != None:
#        return email
    else:
        return None
