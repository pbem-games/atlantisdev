# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


# This is where all of the local configuration stuff is stored.
# It'll be imported, not run, so there's no #! thingo.
#
# There are two dictionaries: 
# o server, where all of the server specific stuff is kept, and
# o game, where all of the game stuff is.

server = { 'smtpserver' : 'beastie.house',
           'adminemail' : 'abriggs@westnet.com.au',
           'basedir'    : '/home/anthony/atlantis/',
           'baseemail'  : 'anthony@beastie.house',
           'emailsep'   : '-',
           'logfile'    : '/home/anthony/atlantis/log.txt',
           'scriptdir'  : '/home/anthony/atlantis/thera/',
           'maildir'    : '/home/anthony/atlantis/maildir/',
           'tar'    : '/usr/bin/tar',
           'zip'    : '/usr/bin/bzip2',
           'unzip'  : '/usr/bin/bunzip2',
           'zipsuffix'  : '.bz2',
           }

game = {}

game['wyreth'] = { 'name'     : 'wyreth',
                   'email'    : 'anthony-wyreth@beastie.house',
                   'basedir'  : server['basedir'] + 'games/wyreth/',     
                   'logfile'  : server['basedir'] + 'games/wyreth/log.txt',     
                   'lockfile' : server['basedir'] + 'games/wyreth/wyreth.lock',  
                   'zip'      : server['basedir'] + 'games/wyreth',
                   'mailindex': server['basedir'] + 'games/wyreth/mailindex',
                   'maildir'  : server['basedir'] + 'games/wyreth/maildir/',
                   'exec'     : server['basedir'] + 'wyreth5.0',
                   'timesrwd' : 'yes',
                   }

game['fracas'] = { 'name'     : 'fracas',
                   'email'    : 'anthony-fracas@beastie.house',
                   'basedir'  : server['basedir'] + 'games/fracas/',
                   'logfile'  : server['basedir'] + 'games/fracas/log.txt',
                   'lockfile' : server['basedir'] + 'games/fracas/fracas.lock',
                   'zip'      : server['basedir'] + 'games/fracas',
                   'mailindex': server['basedir'] + 'games/fracas/mailindex',
                   'maildir'  : server['basedir'] + 'games/fracas/maildir/',
                   'exec'     : server['basedir'] + 'fracas5.0i',
                   'timesrwd' : 'yes',
                   }

game['betatest'] = { 'name'     : 'betatest',
                   'email'    : 'anthony-betatest@beastie.house',
                   'basedir'  : server['basedir'] + 'games/betatest/',
                   'logfile'  : server['basedir'] + 'games/betatest/log.txt',
                   'lockfile' : server['basedir'] + 'games/betatest/fracas.lock',
                   'zip'      : server['basedir'] + 'games/betatest',
                   'mailindex': server['basedir'] + 'games/betatest/mailindex',
                   'maildir'  : server['basedir'] + 'games/betatest/maildir/',
                   'exec'     : server['basedir'] + 'betatest',
                   'timesrwd' : 'yes',
                   }

game['boojum'] = { 'name'     : 'boojum',
                   'email'    : 'anthony-boojum@beastie.house',
                   'basedir'  : server['basedir'] + 'games/boojum/',
                   'logfile'  : server['basedir'] + 'games/boojum/log.txt',
                   'lockfile' : server['basedir'] + 'games/boojum/fracas.lock',
                   'zip'      : server['basedir'] + 'games/boojum',
                   'mailindex': server['basedir'] + 'games/boojum/mailindex',
                   'maildir'  : server['basedir'] + 'games/boojum/maildir/',
                   'exec'     : '/usr/home/anthony/share/mycvs/boojum/world.py',
                   'timesrwd' : 'yes',
                   }

