# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au

# This script contains two functions, 
# 1. sendhelp, to send some help/instructions to the player,
# 2. resend, to send a player their last turn.

from config import game, server
from mymail import mailout
from mylog import log
from checkpassword import getnameandpass, checkpassword, getplayerinfo
import os

    
def sendhelp(mail):
    """ Send a helpful message back to the player. """
    
    thisgame = game[mail['gamename']]
    
    # First, read in help.txt from the base dir of the game
    helpfile = open(thisgame['basedir']+'help.txt', 'r')
    thehelp = helpfile.readlines()
    helpfile.close()
    
    # Then mail it back to the player.
    mailout(mail['them'], thisgame['email'], 
            're: '+mail['subject'], thehelp, 
            thisgame['maildir'])
    log(thisgame['logfile'], 'Sent help to '+mail['them'] )
    return


def sendtimes(mail):
    """ Send the most recent times back to the player. """
    
    thisgame = game[mail['gamename']]
    
    # First, read in times.all from the base dir of the game
    timesfile = open(thisgame['basedir']+'times.all', 'r')
    thetimes = timesfile.readlines()
    timesfile.close()
    
    # Then mail it back to the player.
    mailout(mail['them'], thisgame['email'], 
            're: '+mail['subject'], thehelp, 
            thisgame['maildir'])
    log(thisgame['logfile'], 'Sent help to '+mail['them'] )
    return


def playerinfo(mail,item):
    """ Provided they get their password right, 
    send the player their current orders or their last turn report.
    Format is? #send [orders|report|times(?)] <fn> password"""
    
    thisgame = game[mail['gamename']]

    (factionnumber, password) = getnameandpass(item[2])
    if factionnumber == None:  
        # they just got the order wrong, no need to panic ;)
        mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                 'Sorry, you need to specify an '+item[1]+' order as:\n'+
                 item[1]+' <faction number> <password>', 
                 thisgame['maildir'] )
        return
    
    if checkpassword(thisgame['name'], factionnumber, password) == 'no':
        # someone got their password wrong! Better log it, just in case!
        mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                 'Sorry, that faction number and password are invalid.', 
                 thisgame['maildir'] )
        log( thisgame['logfile'], 'I just received a bad '+item[1]+' attempt '+
             'for faction '+str(factionnumber)+' from this email address: '+
             str(mail['them']) )
        return
    
    # If we got here, we must be ok.
    # First, read in the orders from the base dir of the game
    basedir = thisgame['basedir']
    factionstr = str(factionnumber)
    badfile = None

    if item[1] == '#orders':
        if os.access(basedir+'orders.'+factionstr, os.F_OK) != 1:
            orders = None
            if os.access(basedir+'template.'+factionstr, os.F_OK) != 1:
                template = None
            else:
                file = open(basedir+'template.'+factionstr, 'r')
                template = file.readlines()
                file.close()
        else:
            file = open(basedir+'orders.'+factionstr, 'r')
            orders = file.readlines()
            file.close()

        if orders == None:
            if template == None:
                output = "I couldn't find your orders or a template! You'd better let the GM know!"
                subject = "I couldn't find your orders or a template!"  #! is required
                badfile = "template"
            else:
                output = template
                subject = "template"
        else:
            output = orders
            subject = "orders"

    if item[1] == "#resend":
        
        if os.access(basedir+'report.'+factionstr, os.F_OK) != 1:
            report = None
        else:
            file = open(basedir+'report.'+factionstr, 'r')
            report = file.readlines()
            file.close()

        if report == None:
            output = "I couldn't find your report! You'd better let the GM know!"
            subject = "I couldn't find your report!"  #! is required
            badfile = "report"
        else:
            output = report
            subject = "report"
            if orders == None:
                if template == None:
                    pass
                else:
                    output = output + template
            else:
                output = output + [ 'Current Orders:\n','\n' ]
                output = output + orders
            
    if item[1] == '#template':
        if os.access(basedir+'template.'+factionstr, os.F_OK) != 1:
            template = None
        else:
            file = open(basedir+'template.'+factionstr, 'r')
            template = file.readlines()
            file.close()

        if template == None:
            output = "I couldn't find your orders or a template! You'd better let the GM know!"
            subject = "I couldn't find your orders or a template!"  #! is required == error
            badfile = "template"
        else:
            output = template
            subject = "template"
    
    # get the turn number from players.in
    tempfile = open( thisgame['basedir']+'players.in', 'r')
    ignored = tempfile.readline()
    ignored = tempfile.readline()
    turnnumber = int( tempfile.readline()[12:] )

    # get some player info and set the subject
    player = getplayerinfo(thisgame['name'], factionnumber)        
    if subject[-1] != '!':
        logtext = 'Sent '+subject+' for faction '+factionstr+' to '+mail['them'] 
        tempsubject = 'Atlantis Game <'+thisgame['name']+'> Turn '
        subject = tempsubject + str(turnnumber)+' '+subject+' for '+player['name']
    else:
        logtext = 'Failed to find '+badfile+' when processing a '
        logtext = logtext+item[1]+' order from '+player['name']

    # mail results back to the player.
    mailout(mail['them'], mail['me'], 
            subject, output, 
            thisgame['maildir'])
            
    log(thisgame['logfile'], logtext)
    return


def playerinfo2(mail,item):
    """ Provided they get their password right, 
    send the player their current orders or their last turn report.
    Format: #[send|resend] [orders|report|times|template] <fn> password"""
    
    thisgame = game[mail['gamename']]
    ordertype, nameandpass = item[2].strip().split(' ',1)

    (factionnumber, password) = getnameandpass(nameandpass)
    if factionnumber == None:  
        # they just got the order wrong, no need to panic ;)
        mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                 'Sorry, you need to specify an '+item[1]+' order as:\n'+
                 item[1]+' <faction number> <password>', 
                 thisgame['maildir'] )
        return
    
    if checkpassword(thisgame['name'], factionnumber, password) == 'no':
        # someone got their password wrong! Better log it, just in case!
        mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                 'Sorry, that faction number and password are invalid.', 
                 thisgame['maildir'] )
        log( thisgame['logfile'], 'I just received a bad '+item[1]+' attempt '+
             'for faction '+str(factionnumber)+' from this email address: '+
             str(mail['them']) )
        return
    
    if ordertype not in ['report', 'orders', 'template', 'times']:
        mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                 'Sorry, you need to specify the '+item[1]+' order as:\n'+
                 item[1]+' report|template|times|orders <faction number> <password>', 
                 thisgame['maildir'] )
        return

    # If we got here, we must be ok.
    # First, read in the orders from the base dir of the game
    basedir = thisgame['basedir']
    factionstr = str(factionnumber)
    badfile = None
    filewanted = None

    if ordertype == 'times':
        filewanted = 'times.all'
    else:
        filewanted = ordertype+"."+factionstring
    
    if os.access(basedir+filewanted, os.F_OK) != 1:
        output = "I couldn't find the "+ordertype+"! You'd better let the GM know!"
        subject = "I couldn't find the "+ordertype+"!"  #! is required
    else:
        subject = ""
        temp=open(basedir+filewanted, 'r')
        output=temp.readlines()
        temp.close()

    # get the turn number from players.in
    temp = open( thisgame['basedir']+'players.in', 'r')
    ignored = temp.readline()
    ignored = temp.readline()
    turnnumber = int( temp.readline()[12:] )
    temp.close()
    
    # get some player info and set the subject
    player = getplayerinfo(thisgame['name'], factionnumber)        
    if subject[-1] != '!':
        logtext = 'Sent '+ordertype+' for faction '+factionstr+' to '+mail['them'] 
        subject = 'Atlantis Game <'+thisgame['name']+'> Turn '
        subject = subject + str(turnnumber)+' '+subject+' for '+player['name']
    else:
        logtext = 'Failed to find '+filewanted+' when processing a '
        logtext = logtext+item[1]+' '+ordertype+' order from '+player['name']

    # mail results back to the player.
    mailout(mail['them'], mail['me'], 
            subject, output, 
            thisgame['maildir'])
            
    log(thisgame['logfile'], logtext)
    return