#!/usr/local/bin/python


# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


import sys, re, os, time, random
import mymail, check, create, communicate, myhelp
from mylog import log
from config import server, game
from accesscontrol import checklist
from locking import lock_file, LOCK_EX, LOCK_UN


### Read in the email... piped into stdin
allthelines = []
while 1:
    try:
        allthelines.append(raw_input())
    except EOFError:
        break

### Now feed that to mymail.mailin to get the headers out
mailbits = mymail.mailin(allthelines)
mail = {}
mail['me']    = mymail.frob(mailbits[0])
mail['them']    = mymail.frob(mailbits[1])
mail['replyto'] = mailbits[2]
mail['subject'] = mailbits[3]
mail['body']    = mailbits[4]

# Try and get the game name
gamenamesearch = '\w+\\'+server['emailsep']+'(\w+)@' # ie address-gamename@whatever...
gamenametemp = re.search(gamenamesearch, mail['me'])
if gamenametemp == None:
    mail['gamename'] = None
    mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
               'Couldn\'t find the game name in the address: '+mail['me'], 
               server['maildir'])
    log(logfile, mail['them']+" doesn't know the game address!")
    sys.exit(0)
else:
    mail['gamename'] = gamenametemp.group(1)
    thisgame = game[mail['gamename']]

logfile = thisgame['logfile']

# Now log the email to a file...
if thisgame['mailindex'] != None:
    # Read in the current email log number,
    # but make sure that the file exists first
    if os.access(thisgame['mailindex'], os.F_OK) != 1:
        mailindex = 1
    else:
        file = open(thisgame['mailindex'], 'r')
        mailindex = int(file.readline())
        file.close()
    # And write the file to email.<mailindex>
    file = open(thisgame['basedir']+'email.'+str(mailindex), 'w+')
    logstring = time.strftime("%Y %b %d (%a) %H:%M:%S", time.localtime(time.time()))
    file.write('Received on '+logstring+'\n')
    file.write('From: '+mail['them']+'\n')
    for line in allthelines:
        file.write(line+'\n')
    file.close()
    # then log the receipt
    log(logfile, 'Recieved email number '+str(mailindex)+' from '+
                 mail['them']+' for '+mail['gamename']+'.')
else:
    log(logfile, 'Recieved email from '+mail['them']+
                 ' for '+mail['gamename']+'.')

# Update the mail index ...
if thisgame['mailindex'] != None:
    # Now overwrite it with the next number
    file = open(thisgame['mailindex'], 'w+')
    file.write(str(mailindex+1)+'\n')
    file.close()

# If the message comes from a mailer daemon, then we ignore it
if mail['them'].startswith('MAILER-DAEMON'):
    log(logfile, 'Ignored, since it was from MAILER-DAEMON.')
    sys.exit(0)

# Make sure that the reply-to for the player isn't set to anything
# stupid that'll cause a mail-loop
if mail['them'].startswith(thisgame['email']):
    log(logfile, 'Ignored, since it was from us?!.')
    log(logfile, mail['them']+"   "+thisgame['email'])
    sys.exit(0)
    
if mail['replyto'] == server['baseemail']:
    mail['replyto'] = None
if mail['replyto'] == thisgame['email']:
    mail['replyto'] = None

### Check that the player is allowed to submit orders
whitelist = checklist(thisgame['basedir']+'whitelist', mail['them'])
blacklist = checklist(thisgame['basedir']+'blacklist', mail['them'])
paidlist  = checklist(thisgame['basedir']+'paidlist',  mail['them'])

if blacklist == 'yes':
    #They're on the naughty list!
    mymail.mailout(mail['them'], mail['me'],'re:'+mail['subject'], 
               "Sorry, but you're on our blacklist, and are not "+
               "allowed to submit orders!\n"+
               "Please contact the GM if you wish to play:\n\n"+
               "  "+server['adminemail'],
               thisgame['maildir'])
    log(logfile, mail['them']+' is in the blacklist!')
    sys.exit(0)

if whitelist == 'yes':
    log(logfile, mail['them']+" is in the whitelist, so they're ok.")

elif whitelist == 'nofile':
    # There's no whitelist, so we need to see if they're in the other files

    if paidlist == 'no': 
        #They're not an up to date player!
        mymail.mailout(mail['them'], mail['me'],'re:'+mail['subject'], 
                   "Sorry, but your account is not up to date, and so "
                   "you're not allowed to submit orders!\n"+
                   "Please contact the GM as soon as possible:\n\n"+
                   "  "+server['adminemail'],
                   thisgame['maildir'])
        log(logfile, mail['them']+' is out of funds!')
        sys.exit(0)

else:
    mymail.mailout(mail['them'], mail['me'],'re:'+mail['subject'], 
               "Sorry, but this is an invite only game, and so "
               "you're not allowed to submit orders!\n"+
               "Please contact the GM if you want to play:\n\n"+
               "  "+server['adminemail'],
               thisgame['maildir'])
    log(logfile, mail['them']+' is not on the whitelist!')
    sys.exit(0)

### Look for the beginning and end of a turn...

beginline = '^#atlantis (\d+) (.*)'
endline   = '^#end'
turn = []; notturn = []
gotstart = 'no'; gotend = 'no'; ordersbody = 'no'

# parsing for orders - basically putting everything between #atlantis
# and #end into turn, (so as not to confuse the atlantis check program)
# and feeding everything else into notturn (we'll look for meta-orders
# after we've determined whether there's a turn or not)

for line in mail['body']:
    if ordersbody == 'yes':
        turn.append(line)
        if re.search(endline, line.lstrip(), re.IGNORECASE) != None:
            gotend = 'yes'
            ordersbody = 'done'
    else:
        if ordersbody == 'no':
            getinfo = re.search(beginline, line.lstrip(), re.IGNORECASE)
            if getinfo != None:
                turn.append(line)
                mail['factionnumber'] = getinfo.group(1)
                mail['password'] = getinfo.group(2).rstrip()
                if mail['password'][0] == '"' or mail['password'][0] == "'":  #"
                    mail['password'] = mail['password'][1:-1] #Strip quotes
                ordersbody = 'yes'; gotstart = 'yes'
            else:
                notturn.append(line)
        else:  # ordersbody must == 'done'
            notturn.append(line)
            
            
# Right, now we do the checking to make sure that we've got all the bits
# that we need, and it doesn't look like the submitter has missed anything

# Make sure we actually have some orders
if len(mail['body']) == 0:
    message = 'There was nothing in the body of your email'
    mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
               message, mymail.mailout )
    log(logfile, "There was an error: "+message)
    sys.exit(0)
               
# Fail nicely if we found the start of the turn, but not the end,
# or vice-versa. If we find neither, that's ok, since they might
# be submitting meta-orders...
if (gotstart == 'yes') != (gotend == 'yes'):
    if gotend == 'yes':
        message = "Couldn't find the #atlantis line in your orders"
        mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
                       message, thisgame['maildir'])
        log(logfile, "There was an error: "+message)
        sys.exit(0)
    else:
        message = "Couldn't find the #end line in your orders"
        mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
                   message, thisgame['maildir'])
        log(logfile, "There was an error: "+message)
        sys.exit(0)

# If we got here, we've got everything we need to submit a turn,
# and send a turn check back.

# So get a lock, already!
lock_file( game[mail['gamename']]['lockfile'], LOCK_EX )

# If we got here, we're good to go!


# Call the turn checker script.  This script does all of the saving, 
# and mailing out, but will return after it's done
if gotstart == 'yes':
    check.checkturn(mail, turn)

# Look for meta-orders. They should all start with a '#', eg. #ready
# map, ready and unready should be fine, but #times #rumour and #message
# will be a little tricky, since they need the lines underneath that, too.

metaorders = []
metasearchstring = '(^#\w+)(.*)'

# Turning times on and off is handled by the game engine.
# These orders handle sending times and rumo(u)rs. Times & Rumours will only
# be sent if times is switched on in players.in
multilineorders  = ['#times','#rumour','#rumor','#message']
singlelineorders = ['#help','#create','#join','#resend','#resendtimes','#report','#orders','#template']
nullorders       = ['#endtimes','#endmessage','#endrumour','#endrumor']

# Run through all of notturn, and get the locations of potential meta-orders
# We store each potential meta-order in a list, and with it store it's location,
# followed by the order's name, and then any arguments it had.
for index in range(len(notturn)):
    metasearch = re.search( metasearchstring, notturn[index].lstrip() )
    if metasearch != None:
        #found some meta-orders
        order = metasearch.group(1).lower()
        args  = metasearch.group(2)
        metaorders.append([index, order, args])

# Jump ship if there weren't any meta-orders
if metaorders == []:
    # If there weren't any meta-orders, and there weren't any real orders,
    # then we should log an error...
    if ordersbody != 'done':
        mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
                   "I couldn't find any sort of orders at all!\n\n"+ 
                   "If you're having trouble, send a message with #help "+
                   "by itself on a line, or email the gamemaster directly.\n",
                   thisgame['maildir'])
        log(logfile, "Couldn't find any orders at all!")
    sys.exit(0)
    
# Now using our list of meta-orders, parse!
badmetaorders = []
for index in range(len(metaorders)):
    item = metaorders[index]
    
    if item[1] in singlelineorders:
        if   item[1] == '#create' or item[1] == '#join':
            create.create(mail, item)
            
        elif item[1] == '#help':
            myhelp.sendhelp(mail)

        elif item[1] == '#resendtimes':
            myhelp.sendtimes(mail)
                        
        elif item[1] in ['#report', '#orders', '#template']:
            myhelp.playerinfo(mail, item)
        
        elif item[1] in ['#resend', '#send']:
            myhelp.playerinfo2(mail, item)
            
    elif item[1] in multilineorders:        
        # For multi-line orders, we need to get all of the lines up to
        # the next order. We're helped by the fact that the list of
        # metaorders should be the same as in the turn,
        # ie. sorted/ordered
        
        multistart = item[0] + 1
        try:
            multifinish = metaorders[index+1][0]
            lines = notturn[multistart:multifinish]
        except IndexError, KeyError: # Reached the end of the orders?
            lines = notturn[multistart:]
        
        # Now do the relevant one...
        if   item[1] == '#times':
            communicate.dotimes(mail, item, lines)
        elif item[1] == '#rumour' or item[1] == '#rumor':
            communicate.dorumour(mail, item, lines)
        elif item[1] == '#message':
            communicate.domessage(mail, item, lines)
    else:
        if item[1] not in nullorders:
            badmetaorders.append(item[1]+item[2])

if badmetaorders != []:
    message = "I had trouble with some of the orders that you sent:\n\n"
    log(logfile, "Couldn't parse all of the meta-orders...")
    for meta in badmetaorders:
        message = message + "  " + meta + "\n"
        log(logfile, "  "+meta)
    mymail.mailout(mail['them'], mail['me'], 're:'+mail['subject'], 
                   message,thisgame['maildir'])

lock_file( game[mail['gamename']]['lockfile'], LOCK_UN )

