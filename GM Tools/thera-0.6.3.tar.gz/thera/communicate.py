# Thera - A series of tools to run an atlantis game.
# Copyright (C) 2001 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@sourceforge.net.au


# This is the communicate script, which handles all of the communication bits
# between players -- times, rumours and messages
# the times is sent to all players in the game when the turn is run. 
#  it has your faction name on it, so it's not anonymous
# The rumours are sent in the same manner as the times, but they're anonymous
# messages are not anonymous, and are sent on by the script immediately 
#  although it'll be as an email from the script, so you won't know the person
#  just the faction.

# A fair bit of stuff is duplicated in here -- we should try and roll up the
# duplicate bits in more functions. Oh well, at least we're not duplicating
# password checking any more...

import mymail, re, fcntl
from mylog import log
from config import server, game
from checkpassword import checkpassword, getplayerinfo, getnameandpass, setplayerinfo


def dotimes(mail, item, message):
    """ Pretty simple. Just check their password, if it's ok then
    save their article, mail them a preview and log it.
    It also will give them a times reward, by setting RewardTimes
    in the players.in file"""
    
    gamename = mail['gamename']
    thisgame = game[gamename]

    (factionnumber, password) = getnameandpass(item[2])
    if factionnumber == None:  # no name and password! It might be in mail
        if 'factionnumber' in mail.keys() and mail['factionnumber'] != None:
            factionnumber = mail['factionnumber']
            password = mail['password']
        else:
            mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                            'Sorry, you need to specify a #times entry as:\n'+
                            '#times <faction number> <password>\n<body of '+
                            'your times message>', thisgame['maildir'] )
            return
    
    #make sure there's something in the body of the message, too.
    if message == []:
        mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                        'Sorry, you need to put something in the body of your '+
                        'message, like this:\n\n#times <faction number> '+
                        '<password>\n<body of your times message>', 
                        thisgame['maildir'] )
        return
    
    # Check passwords match...
    if checkpassword(gamename, factionnumber, password) != 'ok':
        mymail.mailout( mail['them'], thisgame['email'], 'Re: '+mail['subject'],
                        'Faction '+factionnumber+'? Haven\'t heard of '+
                        'that one. Are you sure you got your password right?', 
                        thisgame['maildir'] )
        return
    
    #password's ok -- write the times into times.factionnumber
    timesfile = thisgame['basedir'] + 'times.' + factionnumber

    factionname = getplayerinfo(gamename, factionnumber)['name']
    mailmessage = 'I\'ve submitted your times entry. '
    mailmessage = mailmessage + 'It will appear as follows:\n\n'
    message.append('\n')
    message.append(factionname+'\n')

    output = open( timesfile, 'w' ) # Write over whatever was already there.
    for line in message:
        mailmessage = mailmessage + line
        output.write(line)
        if line == '' or line[-1] != '\n':
            output.write('\n')
            mailmessage = mailmessage + '\n'
    output.close()
    
    mymail.mailout( mail['them'], thisgame['email'], 
                    'Game <'+thisgame['name']+'>: Times entry submitted',
                    mailmessage, thisgame['maildir'] )
                    
    log(thisgame['logfile'], 
        'Submitted a new times entry for '+factionname )
    
    if thisgame['timesrwd'] == 'yes':
        setplayerinfo(thisgame['name'], factionnumber, 
                      'timesreward', '1')
        log( thisgame['logfile'], 'Gave a times reward to faction '+str(factionnumber) )
        
    return
    

def dorumour(mail,item, message):
    """ Pretty simple. Just check whether the faction has previously submitted 
    times reports to this script. If they have, then overwrite them. Oh yeah, 
    and we need to check their password, too."""
    
    gamename = mail['gamename']
    thisgame = game[gamename]

    (factionnumber, password) = getnameandpass(item[2])
    if factionnumber == None:  # no name and password! It might be in mail
        if 'factionnumber' in mail.keys() and mail['factionnumber'] != None:
            factionnumber = mail['factionnumber']
            password = mail['password']
        else:
            mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                            'Sorry, you need to specify a #rumour entry as:\n'+
                            '#rumour <faction number> <password>\n<body of '+
                            'your rumour>', thisgame['maildir'] )
            return
    
    #make sure there's something in the body of the message, too.
    if message == []:
        mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'], 
                        'Sorry, you need to put something in the body of your '+
                        'message, like this:\n\n#rumour <faction number> '+
                        '<password>\n<body of your times message>', 
                        thisgame['maildir'] )
        return
    
    # Check passwords match...
    if checkpassword(gamename, factionnumber, password) != 'ok':
        mymail.mailout( mail['them'], thisgame['email'], 'Re: '+mail['subject'],
                        'Faction '+factionnumber+'? Haven\'t heard of '+
                        'that one. Are you sure you got your password right?', 
                        thisgame['maildir'] )
        return
    
    #password's ok -- write the rumour into rumour.factionnumber
    rumourfile = thisgame['basedir'] + 'rumour.' + factionnumber

    factionname = getplayerinfo(gamename, factionnumber)['name']
    mailmessage = "I've submitted your rumour. It will appear as follows:\n\n"

    output = open( rumourfile, 'w' ) # Write over whatever was already there.
    for line in message:
        mailmessage = mailmessage + line
        output.write(line)
        if line == '' or line[-1] != '\n':
            output.write('\n')
            mailmessage = mailmessage + '\n'
    output.close()
    
    mymail.mailout( mail['them'], mail['me'], 
                    'Game <'+thisgame['name']+'>: Rumour submitted',
                    mailmessage, thisgame['maildir'] )
                    
    log(thisgame['logfile'], 'Submitted a new rumour for '+factionname )

    return


def domessage(mail, item, message):
    """ Even more simple. Just check the faction's password. If it's good, then
    send a message from the game server to the recipient with the message."""

    gamename = mail['gamename']
    thisgame = game[gamename]
    
    # parse the arguments in item[2]
    (targetfaction, wibble) = item[2].strip().split(' ',1)
    (factionnumber, password) = getnameandpass(wibble)
    
    if factionnumber == None:  # no name and password! It might be in mail
        if mail['factionnumber'] != None:
            factionnumber = mail['factionnumber']
            password = mail['password']
        else:
            mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'], 
                        'Sorry, you need to specify a #message entry as:\n'+
                        '#message <target faction> <faction number> '+ 
                        '<password>\n<body of your message>', 
                        thisgame['maildir'] )
            return
    
    # Check passwords match...
    if checkpassword(gamename, factionnumber, password) != 'ok':
        mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'],
                        'Faction '+factionnumber+'? Haven\'t heard of '+
                        'you. Are you sure you got your password right?', 
                        thisgame['maildir'] )
        return
    
    #make sure there's something in the body of the message.
    if message == []:
        mymail.mailout( mail['them'], 
                        mail['me'], 
                        'Re: '+mail['subject'], 
                        'Sorry, you need to put something in the body of your '+
                        'message, like this:\n\n'+
                        '#message <target faction> <faction number> '+
                        '<password>\n<body of your times message>', 
                        thisgame['maildir'] )
        return
    
    # Also check that the target faction exists...
    target = getplayerinfo(gamename, targetfaction)

    if target['name'] == 'unknown':
        mymail.mailout( mail['them'], mail['me'], 'Re: '+mail['subject'],
                        'Faction '+target['faction']+'? Haven\'t heard of '+
                        'that one. Are you sure you got their number right?', 
                        thisgame['maildir'] )
    
    # password's ok, and we've got all the stuff -- send the message

    factionname = getplayerinfo(gamename, factionnumber)['name']
    sendermessage = "I've sent your message to "+target['name']+'. '
    sendermessage = sendermessage + 'It will appear as follows:\n\n'

    rcptmessage = 'You\'ve received a message from '+factionname+':\n\n'
    
    for line in message:
        sendermessage = sendermessage + line
        rcptmessage = rcptmessage + line
        if line == '' or line[-1] != '\n':
            sendermessage = sendermessage + '\n'
            rcptmessage = rcptmessage + '\n'

    # First, send the message to the recipient
    mymail.mailout( target['email'], 
                    thisgame['email'], 
                    'Game <'+thisgame['name']+'>: Message from '+factionname,
                    rcptmessage, 
                    thisgame['maildir'] )
                    
    # Then to the original sender
    mymail.mailout( mail['them'], thisgame['email'], 
                    'Game <'+thisgame['name']+'>: Message sent to '+
                    target['name'], sendermessage, thisgame['maildir'] )
                    
    log(thisgame['logfile'], 'Message sent from '+factionname+' to '+
                             target['name']+'.' )
    return