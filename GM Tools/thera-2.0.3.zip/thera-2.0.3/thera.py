#!/usr/bin/env python

# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

import os
import shlex
import sys

from config import *
from locking import *
from lib import splitList, log
from mail import getEmails, sendEmail

# Order handlers
from create import create
from check import check
from communicate import times, rumour, message
from resend import resendtimes, resendreport, resendorders, resendtemplate, genericresend

### Order/Email processing

def isMetaOrderLine(line):
    return line.lstrip().startswith('#') and \
           not isMetaOrderEndLine(line)

def isMetaOrderEndLine(line):
    return line.lstrip().lower().startswith('#end')

def help(mail, orderline, body):
    """ Read in help.txt and return that """
    return ''.join( file('help.txt').readlines() )

def unknownCommand(mail, orderline, body):
    """ Command returned when we don't know WTF the player is talking about """
    return ("I'm sorry, but I don't know what the '%s' command is."
            " You can send a #help command to me and I'll respond"
            " with a list of the commands that I know.\n\nThera") % orderline[0]

functionLookup = {
    '#help' : help,
    '#create' : create,
    '#join' : create,
    '#atlantis' : check,
    '#times' : times,
    '#rumour' : rumour,
    '#rumor' : rumour,
    '#message' : message,
    '#unitmessage' : message,
    '#resendtimes' : resendtimes,
    '#report' : resendreport,
    '#orders' : resendorders,
    '#template' : resendtemplate,
    '#resend' : genericresend,
}

def processMail(mail):
    """
    The meat of Thera - process an email and take the necessary action
    Players specify actions by including one or more 'meta-orders'
    within the body of an email. Meta-order sections are all of two forms:
    
    Single line:
       #order <arg1> <arg2> ... <argn>

    or Multi line:
       #order <arg1> <arg2> ... <argn>
       <multiline include>
       #endorder
    
    The final #end isn't really significant, the only thing that matters
    is that it starts with '#end', so '#end', #endtimes, etc. are all valid.

    Arguments are all either naked single words (foobar, foo_bar) or
    multiple words delimited by quotes ('foo bar', "baz humbug"
    """
    # find the first text part 
    mailContents = mail.get_payload()
    if type(mailContents) == list:
	for thing in mailContents:
            if thing.get_content_type() == 'text/plain':
		log('Found a text/plain section in multi-part email...')
                mailContents = thing.get_payload()
                break
        #sys.exit(0)

    # use splitlist to break the email body up into meta-order chunks
    mailBody = [line.rstrip() for line in mailContents.split('\n')]
    if '--' in mailBody:
        lastLine = mailBody.index('--')
    else:
        lastLine = -1
    mailBody = mailBody[:lastLine]
    metaOrders = splitList(mailBody, isMetaOrderLine)
    
    # check each meta-order, and handle with the appropriate function
    for metaOrder in metaOrders:
        if not metaOrder or not metaOrder[0].lstrip().startswith('#'):
            # blank string, or non-hash first line
            log("Error: found no meta-orders in the message!")
            continue
        log('Found a meta order line: %s' % metaOrder[0])
        
        # parse the meta order into orderName, orderline and body
        orderline = shlex.split(metaOrder[0].lstrip())
        orderName = orderline[0].lower()
        body = splitList(metaOrder[1:], isMetaOrderEndLine)
        if body:
            body = body[0]
        
        # Add the first line back in, to make it easier for the order checker
        body = [metaOrder[0]] + body

        function = functionLookup.get(orderName, unknownCommand)
        result = function(mail, orderline, body)

        # email the result to the player
        sendEmail(mail['From'], 
                  scriptemail, 
                  "Results for command '%s'" % metaOrder[0], #orderName,
                  result)
    return


def main():
    """
    Read our mbox file, then process each new email within it
    """
    # first, chdir into our game directory
    path, filename = os.path.split(sys.argv[0])
    os.chdir(path)
    print "Running Turn from", os.getcwd()

    # get a lock on the mbox file
    if os.access('orders.mbox', os.F_OK) != 1:
        newOrders = file('orders.mbox', 'w')
        newOrders.write("")
        newOrders.close()
    fd = file('orders.mbox', 'rb')
    lock_file(fd, LOCK_EX)

    for eachEmail in getEmails(fd):
        #print eachEmail['From']
        try:
            processMail(eachEmail)
            log("Processed msgID %s" % eachEmail['Message-ID'])
        except Exception, message:
            log("There was an error when processing msgID %s:" % eachEmail['Message-ID'])
            #log(message)
            #log("---")
            #for item in sys.exc_info():
            #    log(str(item))
            import traceback
            for line in traceback.format_exc().split('\n'):
                log(line)

    # now we can unlock
    lock_file(fd, LOCK_UN)


if __name__ == '__main__':
    main()

