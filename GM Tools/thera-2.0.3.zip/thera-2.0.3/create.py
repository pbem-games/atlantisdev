
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

from lib import splitList, log
from checkpassword import getplayerinfo, saveplayerinfo

def create(mail, orderline, body):
    """
    Add a new player to the players.in file
    """
    ### check the arguments
    if len(orderline) != 3:
        return ("#create takes the following form: \n\n"
                "  #create <faction name> <password>\n\n"
                "If your faction name contains spaces, you should wrap it within quotes, ie. \n\n"
                "  #create 'faction name with spaces' 'secret password'\n\n"
                "Thera")
    
    # check the faction name and email
    (factionName, password) = orderline[1:3]
    factionEmail = [item for item in mail['From'].split() if '@' in item]
    if factionEmail:
        # -1 since evil people may have an '@' in their name
        factionEmail = factionEmail[-1].replace('<','').replace('>','')

    factionList = getplayerinfo()
    
    sameEmail = [f for f in factionList[1:] if f['Email'] == factionEmail]
    if sameEmail:
        error = ('Bad, bad '+mail['From']+'!\n\nYou\'ve already got '
                 'a faction in this game! You just wait until the GM '
                 'hears about this!')
        # Let the GM hear about it ;)
        log(mail['From']+ ' tried to register *two* factions!')
        return error

    sameName = [f for f in factionList[1:] if f['Name'].strip() == factionName.strip()]
    if sameName:
        return ('Sorry, someone\'s already taken '+factionName+
                ' as a faction name.')

    # Right, now we know that their choice is OK to add to the system.
    thisTurn = factionList[0][2].split()[-1]
    newFactionDict = {
        'Faction' : 'new',
        'Name' : factionName,
        'Email' : factionEmail,
        'Password' : orderline[2],
        'LastOrders' : thisTurn,
    }
    factionList.append(newFactionDict)
    saveplayerinfo(factionList)
    log('Created faction and sent email to player.')

    # Now send them a welcome message, so they know they've joined properly.
    return """\
Alrighty, I've added you to the players.in file. When the turn is next run, you
should get your first turn report. If you need help with submitting orders,
send a #help command to this email address.  That should give you a quick
introduction and a few pointers on using this interface. 

Thera, your friendly Atlantis Script"""
    
