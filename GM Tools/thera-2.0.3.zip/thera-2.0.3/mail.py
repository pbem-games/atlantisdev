
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

import os
import email.Parser
import mailbox

from lib import log
from config import *

def getEmails(fd):
    """
    Read in and return new player emails from our mbox file
    """
    #if os.access('orders.mbox', os.F_OK) != 1:
    #    # no mailbox exists, so create it
    #    file('orders.mbox', 'w').write("")
    ordersMailbox = mailbox.UnixMailbox(
                        fd, #file('orders.mbox','rb'), 
                        email.Parser.Parser().parse)
    
    if os.access('previousMailIDs.txt', os.F_OK) != 1:
        # no previous ids file exists either
        file('previousMailIDs.txt', 'w').write("")
    previousIDs = [id.rstrip() for id in file('previousMailIDs.txt').readlines()]
    newMail = [m for m in ordersMailbox if m['Message-ID'].rstrip() not in previousIDs]

    # write new mail ids to previousMailIDs.txt
    newIDs = '\n'.join( [m['Message-ID'] for m in newMail] )
    if newIDs:
        newIDs += '\n'
    print "New IDs:"
    print newIDs
    file('previousMailIDs.txt', 'a+').write(newIDs)

    ### filter out stupid emails
    nonStupidEmails = []
    for mail in newMail:
        # If the message comes from a mailer daemon, then we ignore it
        if 'MAILER-DAEMON' in mail['from']:
            log('Ignored msgID %s, since it was from MAILER-DAEMON.' % mail['Message-ID'])
            continue

        # Make sure that the reply-to for the player isn't set to anything
        # stupid that'll cause a mail-loop
        if scriptemail in mail['from']:
            log('Ignored msgID %s, since it was from us?!' % mail['Message-ID'])
            continue
        
        # Ignore reply-to for now...
        #if mail['replyto'] == server['baseemail']:
        #    mail['replyto'] = None
        #if mail['replyto'] == thisgame['email']:
        #    mail['replyto'] = None
        
        log('Received non-stupid email from %s' % (mail['from']))
        nonStupidEmails.append(mail)

    return nonStupidEmails


def sendEmail(them, me, subject, message):
    """ Formats and writes an email to the maildir for the game.
    Actually sending the email via SMTP is done from a separate process."""
    
    mailouttext = 'From: ' + me + '\nTo: ' + them + '\n'
    mailouttext = mailouttext + 'Sender: ' + me + '\n'
    mailouttext = mailouttext + 'Reply-To: ' + me + '\n'
    mailouttext = mailouttext + 'Subject: ' + subject + '\n\n'
    
    if type(message) == str:
        mailouttext = mailouttext + message + '\n'
    elif type(message) == list:
        mailouttext = mailouttext + '\n'.join(message) + '\n'

    if os.access('maildir', os.F_OK) != 1:
        os.mkdir('maildir')
    fileName = os.tempnam('maildir', 'mail')
    file = open(fileName, 'w+').write( '\n'.join([them, me, mailouttext]) )


# Very slightly modified from Alex Martelli's news post 
# <9cpm4202cv1 at news1.newsguy.com> of May 2, 2001,
# Subject: Stripping HTML tags from a string
# Thanks, Alex

import sgmllib

class Cleaner(sgmllib.SGMLParser):
  entitydefs={"nbsp": " "} # I'll break if I want to

  def __init__(self):
    sgmllib.SGMLParser.__init__(self)
    self.result = []
  def do_p(self, *junk):
    self.result.append('\n')
  def do_br(self, *junk):
    self.result.append('\n')
  def handle_data(self, data):
    self.result.append(data)
  def cleaned_text(self):
    return ''.join(self.result)

def stripHTML(text):
  c=Cleaner()
  try:
    c.feed(text)
  except sgmllib.SGMLParseError:
    raise ValueError,"Unable to parse HTML"
  else:
    t=c.cleaned_text()
    return t

