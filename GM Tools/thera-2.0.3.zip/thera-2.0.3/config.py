
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net


### CONFIGURATION OPTIONS

# This is the SMTP server that you'll use to send turns
# normally it'll be whatever your ISP tells you
smtpserver = 'mail.westnet.com.au'

# The GM's email address
adminemail = 'abriggs@westnet.com.au'

# The email address of the game, which you should set up an account for,
# using getmail, thunderbird or similar
scriptemail = 'elderlands@westnet.com.au'

# What your game's called
gamename = 'Elderlands'

# The binary file/executable which you run to make the game go.
# This should conform to the standard Atlantis 'interface',
# otherwise checking, etc. will break.
gamebinary = './atlantis.py'

### END CONFIGURATION OPTIONS

