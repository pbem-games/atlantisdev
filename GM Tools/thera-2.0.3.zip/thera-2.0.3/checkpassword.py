
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

# TODO: once this is committed, svn mv to players.py

from lib import splitList

def getFaction(factionnumber):
    """ Get the dict representing of the faction.
        Returns None if no player is found. """
    factionList = getplayerinfo()
    player = [f for f in factionList[1:] if f['Faction'] == str(factionnumber)]
    if player:
        return player[0]
    
def checkpassword(factionnumber, password):
    """ Check whether a particular faction/password combination exists.
        Returns None if no faction, otherwise True or False if the
        password is right or wrong."""
    
    player = getFaction(factionnumber)
    if player:
        if player['Password'] == password:
            return True
        else:
            return False


def updatefactioninfo(faction, newinfo):
    """ Update a faction's information """

    factionList = getplayerinfo()
    player = [f for f in factionList[1:] if f['Faction'] == faction]
    if not player:
        raise ValueError("%s: no faction with that number!" % faction)
    else:
        player[0].update(newinfo)
    saveplayerinfo(factionList)


### Even newer, shinier functions for manipulating players.in
### (Nothing like replacing a couple hundred lines of code with about 40
### that work better than the original :) )

# All players will have these attributes - any others will be pasted on the end
# I'm using this to ensure that the attributes go in the 'right' order
playerAttributes = "Faction Name Email Password LastOrders".split()

def isFactionLine(line):
    return line.startswith('Faction: ')

def getplayerinfo():
    """
    Return the players.in as a list of factions and their info as dicts.
    (ie. so you can do "faction['Name']")

    NB: The first item is just the 'preamble', not a player
    """
    playersFile = file('players.in').readlines()
    factions = splitList(playersFile, isFactionLine)
    readable = [[line.rstrip() for line in factions[0]]]
    for faction in factions[1:]:
        newBits = []
        for line in faction:
            if line.startswith('RewardTimes'):
                newBits.append( ('RewardTimes', 1) )
            else:
                newBits.append( line.rstrip().split(': ', 1) )
        readable.append( dict(newBits) )
    return readable

def saveplayerinfo(factionList):
    """
    Save an updated faction list from getplayerinfo back to players.in
    """
    saveable = factionList[0]
    for faction in factionList[1:]:
        toFile = []
        for key in playerAttributes:
            toFile.append( '%s: %s' % (key, faction[key]) )
        for key in faction.keys():
            if key in playerAttributes:
                continue
            if key == 'RewardTimes':
                toFile.append( 'RewardTimes' )
            else:
                toFile.append( '%s: %s' % (key, faction[key]) )
        saveable += toFile
    file('players.in', 'w').writelines( [line+'\n' for line in saveable] )

