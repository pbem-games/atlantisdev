#!/usr/bin/env python

# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net


## This is a script to run an atlantis turn, doing all the usual things,
# like:
# 1. compiling the times and rumour sections
# 2. running the turn
# 3. Mailing turn reports out to all of the players
# 4. Archiving and compressing all of the turns, gamefiles and orders
# 4. Renaming players.out and game.out
#
# The directory structure will be as follows:
# 1. All of the current game files will be in the base directory:
#     players.in, game.in, orders.*, times.*, rumour.* and log.txt
# 2. Archived directories will consist of all of these, plus report.*, and
#    will be numbered after the turn, eg. 0 1 2 ... up to the current turn

import os
import shutil
import sys
import random

from lib import log, splitList
from thera import isMetaOrderLine
from config import *
from checkpassword import getplayerinfo, getFaction
from locking import *
import mail


# chdir into our game directory
path, filename = os.path.split(sys.argv[0])
os.chdir(path)
print "Running Thera from", os.getcwd()

# get a lock on the mbox file
if os.access('orders.mbox', os.F_OK) != 1:
    newOrders = file('orders.mbox', 'w')
    newOrders.write("")
    newOrders.close()
fd = file('orders.mbox', 'rb')
lock_file(fd, LOCK_EX)

# If we got here, we have lockage!

# get the turn number from players.in
tempfile = open( 'players.in', 'r')
ignored = tempfile.readline()
ignored = tempfile.readline()
turnnumber = int( tempfile.readline()[12:] ) + 1
tempfile.close()

# Create an archive for the old turns. eg turn 2 will be directory '2'
if not os.access(str(turnnumber), os.F_OK):
    os.mkdir( str(turnnumber), 0700 )

# Move all of last turn's report files and template files into the game directory
gamefiles = os.listdir('.')
for eachFile in gamefiles:
    if (eachFile[:7] == 'report.' or 
        eachFile[:9] == 'template.' or 
        eachFile=='times.all'):
        shutil.move ( eachFile, str(turnnumber) + os.path.sep + eachFile )
        
# Read in all of the times and rumour sections, and shuffle the rumours
times = []
rumours = []
gamefiles = os.listdir('.')
for eachFile in gamefiles:
    if eachFile[:7] == 'rumour.':
        rumours.append(file(eachFile))
    elif eachFile[:6] == 'times.':
        times.append(file(eachFile))

# Randomise the rumours
def randcmp(list1, list2):
    """ Completely ignore the input functions, and return -1,0 or 1 randomly """
    return int(random.random()*3) - 1
rumours.sort(randcmp)

timesout = []
# Read in the times header, if it exists
if 'header.times' in gamefiles:
    timesheader = file('header.times').readlines()
    for line in timesheader:
        timesout.append(line)
timesout.append('='*70)
timesout.append('\n')


# Now put the times and rumours in...
for entry in times:
    timesout += entry
    # spacer between times reports
    timesout.append('\n')
    timesout.append('-'*70)
    timesout.append('\n')
    
if times == []:
    timesout.append('There were no times reports this turn.\n')
        
timesout.append('='*70)
timesout.append('\n')

for entry in rumours:
    timesout += entry
    # spacer between rumours
    timesout.append('\n')
    timesout.append('-'*70)
    timesout.append('\n')
    
if rumours == []:
    timesout.append('There were no rumours this turn.\n')

timesout.append('='*70)
timesout.append('\n')
timesout = [l.rstrip() for l in timesout]

# timesout is now the complete set of times & rumours, 
# we'll send it at the same time as the reports


### Run the atlantis turn
if os.access('*.out', os.F_OK) == 1:
    error = ('Game execution stopped since there are output'
             'files still in the game directory.')
    log(error)
    print error
    sys.exit(1)

print "Running:", gamebinary + ' run'
result = os.popen(gamebinary+' run').readlines()
if os.access('game.out', os.F_OK) != 1:
    error = ("There was an error when running the binary game file '%s'" % gamebinary)
    log(error)
    print error
    print
    print "The output from the binary was:"
    for line in result:
        print line.rstrip()
    sys.exit(1)

log(''.join(result), 'gamelog.txt')

# move all of game.in, players.in, times.*, rumour.*, orders.* and email.* 
# into the archive directory. 
gamefiles = os.listdir('.')
moveablefiles = [ 'times.', 'rumour', 'orders', 'check.', 'email.']
for eachFile in gamefiles:
    if (eachFile == 'players.in' or 
        eachFile == 'game.in' or 
        eachFile[:6] in moveablefiles and
        not eachFile.startswith('check.py')):
        shutil.move(eachFile, str(turnnumber) + os.path.sep + eachFile)
        
# Save the complete times to a file now that we've moved the old times files, 
# so that we can resend it again if necessary
file('times.all', 'w+').write('\n'.join(timesout))

### rename players.out and game.out
# If we do this bit now, we can use our existing functions to get player 
# names and emails, instead of writing new ones to read *.out.
# Also, if we try and get faction names before this, (ie. from the old 
# players.in) we don't send reports out to new factions, since they're still 
# listed as 'Faction: new'
os.rename( 'players.out', 'players.in' )
os.rename( 'game.out', 'game.in' )

# All we should have left is the logfile, players.in, game.in, 
# the lock file, times.all and the report.* files
# Now we can mail turn reports out to all of the players.
factionList = getplayerinfo()

gamefiles = os.listdir('.')
for eachFile in gamefiles:
    if eachFile[:7] == 'report.':
        factionnumber = eachFile.split('.')[-1]
        # guards & monsters don't get email ;)
        if int(factionnumber) < 3:
            continue
            
        player = getFaction(factionnumber)
        if not player:
            log('Found '+eachFile+', but faction '+factionnumber+
                ' doesn\'t have any details in the players.in file.')
            continue
        
        # Read in the turn report for that player
        turnfile = file(eachFile).readlines()
        
        # Grab the template file too, if there is one
        if os.access('template.'+str(factionnumber), os.F_OK):
            templatefile = open('template.'+str(factionnumber)).readlines()
            turnfile = turnfile + templatefile
        turnfile = [l.rstrip() for l in turnfile]

        # And mail it out
        mail.sendEmail(player['Email'], 
                       scriptemail, 
                       'Atlantis Game <%s> Turn %s Report for %s' % (gamename, turnnumber, player['Name']),
                       turnfile)
        log ('Mailed turn report to '+player['Email'])
        
        # If they want the times, mail that out, too.
        if player.get('SendTimes', '0') == '1':
            mail.sendEmail(player['Email'], 
                           scriptemail, 
                           'Atlantis Times for <%s> Turn %s' % (gamename, turnnumber),
                           timesout)
            log('Mailed the times to '+player['Email'] )
        
        # Grab the template off the end of the report and save it as orders.n
        # just in case they haven't submitted their orders by next turn.
        # This is left in so that Thera is still compatible with version 4
        # otherwise we could just copy template.?? to orders.??
        report, template = splitList(turnfile, isMetaOrderLine)
        template = [line+'\n' for line in template]
        file('orders.'+str(factionnumber), 'w').writelines(template)
        
## We leave this turn's reports in the directory, so that #resend will work ;)

log('Finished processing turn %s for game %s.' % (turnnumber, gamename) )
lock_file(fd, LOCK_UN)

