### These lockfile routines 'stolen' from html template, 
### by Tomas Styblo, tripie@cpan.org, http://htmltmpl.sourceforge.net/

# Find a way to lock files under UNIX or windows.
try:
    import fcntl
    platform = 'unix'
except:
    try:
        import msvcrt
        platform = 'windows'
    except:
        raise EnvironmentError, "This platform doesn't seem to support lockfiles!"
        
LOCK_EX = 1
LOCK_SH = 2
LOCK_UN = 3

def lock_file(file, lock):
    """ Provide platform independent file locking.
        @hidden
    """
    fd = file.fileno()
    if platform == 'unix':
        if lock == LOCK_SH:
            fcntl.flock(fd, fcntl.LOCK_SH)
        elif lock == LOCK_EX:
            fcntl.flock(fd, fcntl.LOCK_EX)
        elif lock == LOCK_UN:
            fcntl.flock(fd, fcntl.LOCK_UN)
        else:
            raise TemplateError, "BUG: bad lock in lock_file"
    elif platform == 'windows':
        if lock == LOCK_SH:
            # msvcrt does not support shared locks :-(
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
        elif lock == LOCK_EX:
            msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
        elif lock == LOCK_UN:
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            raise TemplateError, "BUG: bad lock in lock_file"
    else:
        raise TemplateError, "BUG: bad locktype in lock_file"
