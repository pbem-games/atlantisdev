#!/usr/bin/env python

# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

# A mail 'server' for thera, really just a program that looks over
# the maildir directory and sends everything in it, retrying at intervals
# as specified in a crontab.

import os
import smtplib
import sys

from config import smtpserver

# chdir into our game directory
path, filename = os.path.split(sys.argv[0])
os.chdir(path)
print "Running Mail Sender from", os.getcwd()
 

# Check the mail directory, and send out any files that we find there!
# The format of the file is:
#     them
#     me
#     the rest of the message (including from, to, subject, etc.)

mailserver = smtplib.SMTP(smtpserver)

if os.access('maildir', os.F_OK) != 1:
    os.mkdir('maildir')
gamefiles = os.listdir('maildir')

for eachfile in gamefiles:
    file = open('maildir'+os.path.sep+eachfile, 'r')
    them = file.readline()
    me   = file.readline()
    mailouttext = ''.join( file.readlines() )
    file.close()
    
    #Now send the mail
    try:    
        mailserver.sendmail(me, them, mailouttext)
    except:
        pass  # Oh well, we'll get them next time...
    else:
        os.remove('maildir'+os.path.sep+eachfile)

mailserver.quit()
