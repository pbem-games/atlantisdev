
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net

# Script to process incoming orders, and check them

import os

from lib import log
from config import *
from checkpassword import checkpassword, updatefactioninfo, getplayerinfo


def check(mail, orderline, body):
    """ Check an atlantis turn and store the orders. """
    
    if len(orderline) != 3:
        return("Sorry, but your orders need to be submitted in the following format:\n"
               "  #atlantis <faction number> <password>\n"
               "    ...orders go here ...\n"
               "  #end\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #atlantis 42 'secret password'\n\n"
               "Thera")

    nonBlankOrders = [line for line in body if line.strip()]
    if not nonBlankOrders:
        return("Hmm, I can't see any orders in that email. Your orders need to be submitted"
               " in the following format:\n"
               "  #atlantis <faction number> <password>\n"
               "    ...orders go here ...\n"
               "  #end\n\n"
               "Thera")

        
    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")
    
    # Sanitise the orders a bit
    endLine = [line for line in body if '#end' in line and line.strip() == '#end']
    if not endLine:
        body.append('#end')
        endLine = len(body)
    else:
        endLine = body.index(endline[0])
    body = body[:endLine+1]

    # Now start doing that checking thang
    ordersfile = 'orders.' + orderline[1]
    checkfile  = 'check.'  + orderline[1]
    
    # Save the orders into orders.<faction>
    output = file(ordersfile, 'w').writelines( [line+'\n' for line in body] )

    # Atlantis fails if check.<faction> already exists, so delete it.
    if os.access(checkfile, os.F_OK) == 1:
        os.remove(checkfile)  
    
    # Now check the turn with the Atlantis program
    command = './%s check %s %s' % (gamebinary, ordersfile, checkfile)
    log("Running system command: %s" % command)
    os.system(command)

    # Look for the checkfile and barf if we don't have it
    if os.access(checkfile, os.F_OK) != 1:
        # Log the command we just tried to run
        log('There was a problem checking the orders for '
            'faction '+orderline[1]+'.  I ran \''+command+'\', '
            'but there was no check file afterwards.')
        
        # And mail the player, to let them know what happened
        return('There was an error checking your turn.  Please contact '
               'the GM to find out what\'s up with the server') 
    
    # Set the LastOrders field
    factionList = getplayerinfo()
    thisTurn = factionList[0][2].split()[-1]
    updatefactioninfo(orderline[1], {'LastOrders':thisTurn}) 
   
    # Finish up...
    log('Received orders for faction '+orderline[1])
    return ''.join( file(checkfile).readlines() )

