#!/bin/sh

echo "Packaging Thera into $1"

mkdir $1
cp  CHANGELOG communicate.py GPL INSTALL mail.py resend.py thera.py \
    checkpassword.py config.py header.times lib.py mailsender.py \
    runturn.py check.py create.py help.txt locking.py README THERA \
    $1
zip -r $1.zip $1


