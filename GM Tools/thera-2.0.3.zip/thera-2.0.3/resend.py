
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net


# This script contains functions to send a player their last turn, times,
# report, etc. if for some reason (usually due to mail issues) they missed them
# the first time around.

import os

from checkpassword import checkpassword
from lib import log

def resendtimes(mail, orderline, body):
    """ Read in times.all and return that """
    if os.access('times.all', os.F_OK):
        return ''.join( file('times.all').readlines() )
    else:
        return "Sorry, no Times is available yet.\n\nThera"


def resendreport(mail, orderline, body):
    """ Return the faction's report """
    if len(orderline) != 3:
        return("Sorry, but #report needs to be submitted in the following format:\n"
               "  #report <faction number> <password>\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #report 42 'secret password'\n\n"
               "Thera")

    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        log('I just received a bad #report attempt for faction '+orderline[1]+
            ' from this email address: ' + str(mail['From']) )
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")
    
    fNo = orderline[1]
    if os.access("report."+fNo, os.F_OK):
        return ''.join( file('report.'+fNo).readlines() )
    else:
        return ("Sorry, there doesn't appear to be a report file for you.")


def resendorders(mail, orderline, body):
    """ Return the faction's orders """

    if len(orderline) != 3:
        return("Sorry, but #orders needs to be submitted in the following format:\n"
               "  #orders <faction number> <password>\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #orders 42 'secret password'\n\n"
               "Thera")

    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        log('I just received a bad #orders attempt for faction '+orderline[1]+
            ' from this email address: '+str(mail['From']) )
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")

    fNo = orderline[1]
    if os.access("orders."+fNo, os.F_OK):
        return ''.join( file('orders.'+fNo).readlines() )
    else:
        return ("Sorry, there doesn't appear to be an orders file for you.")


def resendtemplate(mail, orderline, body):
    """ Return the faction's template, if one exists """

    if len(orderline) != 3:
        return("Sorry, but #template needs to be submitted in the following format:\n"
               "  #template <faction number> <password>\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #template 42 'secret password'\n\n"
               "Thera")

    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        log('I just received a bad #template attempt for faction '+orderline[1]+
            ' from this email address: '+str(mail['From']) )
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")

    fNo = orderline[1]
    if os.access("template."+fNo, os.F_OK):
        return ''.join( file('template.'+fNo).readlines() )
    else:
        return ("Sorry, there doesn't appear to be a template file for you.")


def genericresend(mail, orderline, body):
    """ Return the faction's report, template or orders """

    if not( 4 <= len(orderline) <= 6):
        return("Sorry, but #resend needs to be submitted in the following format:\n"
               "  #resend [report] [orders] [template] <faction number> <password>\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #resend report orders 42 'secret password'\n\n"
               "Thera")

    checked = checkpassword(orderline[-2], orderline[-1])
    if not checked:
        log('I just received a bad #resend attempt for faction '+orderline[1]+
            ' from this email address: '+str(mail['From']) )
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")
    
    output = []
    for fileType in ['report', 'orders', 'template']:
        if fileType in orderline:
            fileName = '%s.%s' % (fileType, orderline[-2])
            if os.access(fileName, os.F_OK):
                fileContent = ''.join( file(fileName).readlines() )
                output.append( fileContent )
            else:
                output.append("Sorry, the %s file doesn't appear to exist." % fileName)

    return '\n\n===\n\n'.join(output)


