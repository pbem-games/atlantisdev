#!/usr/bin/env python

"""
Dead simple test suite:
 * one file in test_cases per test, plus a sample players.in and a dummy atlantis.py
 * each file is split into two parts - orders.mbox input and the expected output
 * copy the input out to orders.mbox, and run thera
 * if the expected output is found in maildir, the test passes
 * delete the maildir files

You'll need py.test to run these tests:
http://codespeak.net/py/dist/test.html
"""

import glob
import os
import shutil
import sys
from stat import S_ISDIR, ST_MODE

from lib import splitList
from checkpassword import getplayerinfo

def is_dir(path):
    return S_ISDIR( os.stat(path)[ST_MODE] )


class TestThera(object):

    def isDelimiter(self, line):
        return line.strip().startswith("=== THERA") and line.strip().endswith(" ===")

    def teardown_method(self, method):
        """ Delete our sample players.in, orders.mbox, dummy atlantis.py, etc. """
        file_names = ['maildir', 'players.in', 'atlantis.py', 'orders.mbox',
                      'previousMailIDs.txt', 'log.txt', 
                      'check.3', 'orders.3', 'check.4', 'orders.4']
        for each_file in file_names:
            if os.access(each_file, os.F_OK):
                if is_dir(each_file):
                    shutil.rmtree(each_file)
                else:
                    os.unlink(each_file)

    def setup_method(self, method):
        """ Copy our sample players.in and dummy atlantis.py out to
            the main directory, and set atlantis.py executable """
        players = os.path.join("test_cases", "players.in")
        shutil.copy(players, ".")
        game = os.path.join("test_cases", "atlantis.py")
        shutil.copy(game, ".")
        os.chmod('atlantis.py', 493)    # 755, believe it or not...
        os.mkdir('maildir')

    def get_test_case(self, each_file):
        """ Get an individual test case, and break it into the order email
            and the expected result
        """
        # read the whole file into memory
        file_name = os.path.join("test_cases", each_file)
        test_data = splitList(open(file_name).readlines(), self.isDelimiter)

        # split the test file into orders.mbox part, expected output and other tests
        if len(test_data) == 2:
            # order + expected with no code part
            order_part = test_data[0]
            expected = [test_data[1][1:]]
            other_tests = []
        elif len(test_data) > 2:
            # order, at least one expected, and a code part on the end
            order_part = test_data[0]
            expected = [t[1:] for t in test_data[1:-1]]
            other_tests = test_data[-1][1:]
        else:
            raise ValueError("Invalid test file '%s'!" % each_file)
        
        assert order_part != [], order_part
        assert expected != [], expected

        expected = map(self.trim_list, expected)
        return (order_part, expected, other_tests)

    def get_mail_files(self):
        """ Return a list with the contents of the mail files in 'maildir'.
            The file names will be random so we just get one after the other.
        """
        mail_files = os.listdir('maildir')
        output = []
        for each_file in mail_files:
            file_name = os.path.join("maildir", each_file)
            mail_content = list(open(file_name).readlines())
            output.append( self.trim_list(mail_content) )
        return output

    def trim_list(self, list):
        """ Trim leading and trailing whitespace from a list.
            This is to make our tests more robust against trailing blank lines"""
        while not list[0].strip():
            list = list[1:]
        while not list[-1].strip():
            list = list[:-1]
        return list

    def run_test(self, file_name):
        """ Run one test from our test_cases directory """
        order_part, expected, other_tests = self.get_test_case(file_name)

        # write the order part out to our orders.mbox
        mbox_file = open('orders.mbox', 'w')
        for line in order_part:
            mbox_file.write(line)
        mbox_file.close()

        # run thera
        foo = list(os.popen('./thera.py').readlines())
        
        # verify that the file in maildir matches our expected
        results = self.get_mail_files()
        results.sort()
        expected.sort()

        # if the result isn't what we expected, save it out so that we can
        # add/edit the expected part if necessary
        # (this is also v. useful when building new tests)
        all_results = sum(results, [])
        all_expected = sum(expected, [])
        if all_results != all_expected:
            failed = open('fail_'+file_name, 'w')

            for index, line in enumerate(all_results):
                failed.write("%s: %s" % (index, line))
            failed.write('===\n')

            for index, line in enumerate(all_expected):
                failed.write("%s: %s" % (index, line))
            failed.write('===\n')
            
            for line1, line2 in zip(all_results, all_expected):
                if line1 != line2:
                    failed.write("%s\n!=\n%s" % (line1, line2))

            failed.close()

        assert expected == results
        
        # read in the players.in file, so that we can assert things about it...
        players_in = getplayerinfo()

        if other_tests:
            for line in other_tests:
                exec(line)


    # The 'actual' test cases
    # They're done this way (rather than iterating over a list of names)
    # so that you can see which test failed
    def test_help(self):
        self.run_test('theratest_help.txt')

    def test_create(self):
        self.run_test('theratest_create.txt')

    def test_createexisting(self):
        self.run_test('theratest_createexisting.txt')

    def test_checkorders(self):
        self.run_test('theratest_checkorders.txt')

    def test_checkbadpassword(self):
        self.run_test('theratest_checkbadpassword.txt')

    def test_checkbadfaction(self):
        self.run_test('theratest_checkbadfaction.txt')

    def test_checkexisting(self):
        self.run_test('theratest_createexisting.txt')

    def test_sendfactionmessage(self):
        self.run_test('theratest_sendfactionmessage.txt')

