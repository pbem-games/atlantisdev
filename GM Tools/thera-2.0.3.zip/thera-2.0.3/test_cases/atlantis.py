#!/usr/bin/env python

import sys

if 'check' in sys.argv:
    # This is sort of a stub - just return the orders
    # not too far from what happens normally (orders + errors)
    infile = open(sys.argv[2]).readlines()
    outfile = open(sys.argv[3], 'w')
    for line in infile:
        outfile.write(line)
    outfile.close()

else:
    print "Hello World!"

