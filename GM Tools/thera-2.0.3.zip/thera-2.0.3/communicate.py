
# Thera 2 - A new series of tools to run an atlantis game.
# Copyright (C) 2007 Anthony Briggs
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# The author may be contacted via email at abriggs@users.sourceforge.net


# This is the communicate script, which handles all of the communication bits
# between players -- times, rumours and messages
#
# The Times is sent to all players in the game when the turn is run. 
#  it has your faction name on it, so it's not anonymous
#
# Rumours are sent in the same manner as the times, but they're anonymous
#
# Messages are not anonymous, and are sent on by the script immediately 
#  although it'll be as an email from the script, so you won't know the person
#  who sent it, just the faction.

import os

from lib import log
from checkpassword import checkpassword, updatefactioninfo, getFaction
from mail import sendEmail
from config import *

def times(mail, orderline, body):
    """ Pretty simple. Just check their password, if it's ok then
    save their article, mail them a preview and log it.
    It also will give them a times reward, by setting RewardTimes
    in the players.in file"""
    
    if len(orderline) != 3:
        return("Sorry, but your Times article needs to be submitted in the following format:\n"
               "  #times <faction number> <password>\n"
               "    ...article goes here ...\n"
               "  #end\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #times 42 'secret password'\n\n"
               "Thera")

    nonBlankArticle = [line for line in body[1:] if line.strip()]
    if not nonBlankArticle:
        return("Hmm, I can't see any article in that email. Your article needs to be submitted"
               " in the following format:\n"
               "  #times <faction number> <password>\n"
               "    ...orders go here ...\n"
               "  #end\n\n"
               "Thera")
        
    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")

    # password's ok -- write the times into times.factionnumber
    timesfile = 'times.' + orderline[1]
    faction = getFaction(orderline[1])
    message = '\n'.join( body[1:] + ['', faction['Name']])
    file(timesfile, 'w').write(message)
    log('Submitted a new times entry for '+faction['Name'])
    
    # Issue a Times reward
    faction['RewardTimes'] = '1'
    updatefactioninfo(orderline[1], faction)
    log('Gave a times reward to faction '+str(orderline[1]) )

    return ("I've submitted your times entry. It will appear as follows:\n\n"
            "%s\n\nThera") % message
    

def rumour(mail, orderline, body):
    """ Pretty simple. Just check whether the faction has previously submitted 
    times reports to this script. If they have, then overwrite them. Oh yeah, 
    and we need to check their password, too."""
    
    if len(orderline) != 3:
        return("Sorry, but your rumour needs to be submitted in the following format:\n"
               "  #rumour <faction number> <password>\n"
               "    ...article goes here ...\n"
               "  #end\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #rumour 42 'secret password'\n\n"
               "Thera")

    nonBlankArticle = [line for line in body[1:] if line.strip()]
    if not nonBlankArticle:
        return("Hmm, I can't see any rumour in that email. Your article needs to be submitted"
               " in the following format:\n"
               "  #rumour <faction number> <password>\n"
               "    ...orders go here ...\n"
               "  #end\n\n"
               "Thera")
        
    # check the player's password
    checked = checkpassword(orderline[1], orderline[2])
    if not checked:
        return ("Faction "+orderline[1]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")

    # password's ok -- write the rumour into rumour.factionnumber
    rumourfile = 'rumour.' + orderline[1]
    faction = getFaction(orderline[1])
    message = '\n'.join(body[1:])
    file(rumourfile, 'w').write(message)
    log('Submitted a new times entry for '+faction['Name'])
    
    return ("I've submitted your rumour. It will appear as follows:\n\n"
            "%s\n\nThera") % message


def message(mail, orderline, body):
    """ Check the faction's password. If it's good, then
        send a message from the game server to the recipient with the message."""

    if len(orderline) != 4:
        return("Sorry, but your message needs to be submitted in the following format:\n"
               "  #message <recipient faction number> <faction number> <password>\n"
               "    ...message goes here ...\n"
               "  #end\n\n"
               "If your password contains spaces, you should wrap it within quotes, ie. \n\n"
               "  #message 12 42 'secret password'\n\n"
               "Thera")

    nonBlankMessage = [line for line in body[1:] if line.strip()]
    if not nonBlankMessage:
        return("Hmm, I can't see any message in that email. Your message needs to be submitted"
               " in the following format:\n"
               "  #message <faction number> <password>\n"
               "    ...message goes here ...\n"
               "  #end\n\n"
               "Thera")
        
    # check the player's password
    checked = checkpassword(orderline[2], orderline[3])
    if not checked:
        return ("Faction "+orderline[2]+"? Haven't heard of that one.\n\n"
                "Are you sure you got the password right?\n\n"
                "Thera")

    commandName = orderline[0]
    if commandName == '#unitmessage':
        # we need to search for the owner of the unit.
        # NB: I'm using grep here, but I doubt that'll work under Windows
        # unless someone's installed UnixUtils or similar
        unitNumber = orderline[1]
        results = os.popen("grep '^unit %s' report.*" % unitNumber, "r").readlines()
        if results:
            reportName = results[0].split(':')[0]
            recipient = reportName.split('.')[-1]
        else:
            return ("No unit exists with that number.")
    else:
        recipient = orderline[1]
    
    recipientFaction = getFaction(recipient)
    sendingFaction = getFaction(orderline[2])

    # We have a faction, so send the message
    message = '\n'.join( body[1:] + ['===', sendingFaction['Name'], '==='])
    sendEmail( recipientFaction['Email'],
               scriptemail,
               "Player email from %s" % (sendingFaction['Name']),
               message )
    
    if commandName == '#unitmessage':
        log("Sent a player email from %s to unit %s (faction %s)" % 
                (sendingFaction['Faction'], orderline[1], recipientFaction['Faction']))
        return ("I sent an email to unit " + orderline[1] + 
                " with the following message:\n\n" + message + "\n\nThera")
    else:
        log("Sent a player email from %s to %s" % 
                (sendingFaction['Faction'], recipientFaction['Faction']))
        return ("I sent an email to faction " + recipientFaction['Faction'] + 
                " with the following message:\n\n" + message + "\n\nThera")


