package checker;
use strict;

my $server_game_path = "/usr/games/atlantis/";
my $server_tmp_path = "/tmp/";
my $server_address = "Robot <pbm\@brestrw.by>";

sub new {
  my $class = shift;
  my $self = bless {}, $class;
  
  return $self;
}

sub log( $;@ ) {
  my $item;
  
  if ( open( LOG, ">>".$server_game_path."log" )) {
    print LOG $_[1]."\n";
    for ( $item=2; $item<=$#_; $item++ ) {
      print LOG " > ".$_[$item];
    }
    close( LOG );
  }
}

sub sendMessage( $$$@ ) {
 
  my $self = $_[0];
  my $from = $_[1];
  my $to = $_[2];
  my $subject = $_[3];
 
  my $item;
  my $mailer = "/usr/games/atlantis/sendfile ".$server_tmp_path."message"." ".$to;
    
  # create message
  if ( open( MESSAGE, ">".$server_tmp_path."message" )) {

    print MESSAGE "To: ".$to."\n";
    print MESSAGE "From: ".$from."\n";
    print MESSAGE "Subject: ".$subject."\n";
    print MESSAGE "X-Priority: 3 (Normal)\n";
    print MESSAGE "MIME-Version: 1.0\n";
    print MESSAGE "Content-Type: text/plain; charset=us-ascii\n";
    print MESSAGE "Content-Transfer-Encoding: 7bit\n\n";
    
    for ( $item=4; $item<=$#_; $item++ ) {
      print MESSAGE $_[$item];
    }
    close( MESSAGE );
    
    # send message
    system $mailer;
    
    unlink $server_tmp_path."message";
  }
}

sub sendFile( $$$$ ) {
  my $self = $_[0];
  my @body;

  if ( open( SOURCE, "<".$_[4] )) {
    @body = <SOURCE>;
    close( SOURCE );
    $self->sendMessage( $_[1], $_[2], $_[3], @body );
  }
}


sub getFactionProperty( $$ ) {
  
  my $faction = "";
  my $value = "";
  my $line;
  my $empty;
  
  if ( open( PLAYERS, "<".$server_game_path."players.out")) {
    foreach $line ( <PLAYERS> ) {
      if ( $line =~  m/faction:*/i ) {
	($empty,$faction) = split /\s+/, $line;
      }
      if ( $line =~  m/$_[2]:*/i && $faction eq $_[1] ) {
	($empty,$value) = split /\s+/, $line;
	$faction = "";
      }
    }
    close( PLAYERS );
  }
  
  return $value;
}

sub getTurnNumber {

  my $line;
  my $empty;
  my $turn = "0";
  
  if ( open( PLAYERS, "<".$server_game_path."players.out")) {
    foreach $line ( <PLAYERS> ) {
      if ( $line =~  m/turn.*/i ) {
	($empty,$turn) = split /\s+/, $line;
      }
    }
    close( PLAYERS );
  }
  
  return $turn; 
}

sub sendMessageAll( $$@ ) {

  my $self = $_[0];
  my $from = $_[1];
  my $subject = $_[2];
  my @message = ();
  my @players;
  my $item;
  my $line;
  my $playersFile = $server_game_path."players.out";
  my $empty;
  my $to;

  for ( $item=3; $item<=$#_; $item++ ) {
    push( @message, $_[$item] );
  }
  
  if ( open( PLAYERS, "<".$playersFile )) {
    @players = <PLAYERS>;
    foreach $line (@players) {
      if ( $line =~ m/email.*/i ) {
	($empty,$to) = split /\s+/, $line;
	if ( $to !~ m/noaddress.*/i ) {
		$self->sendMessage( $from, $to, $subject, @message );
	}
      }
    }
    close( PLAYERS ); 
  }
}

sub processWall( @ ) {
  my $self = $_[0];
  my $allow = 0;
  my $item;
  my @message = ();
  
  $self->log( "found wall" );
  
  for ( $item=1; $item<=$#_; $item++ ) {
    if ( $_[$item] =~ m/#end.*/i ) {
      $allow = 0;
    }
    if ($allow == 1 ) {
      push( @message, $_[$item] );
    }
    if ( $_[$item] =~ m/#wall.*/i ) {
      $allow = 1;
    }
  }
  
  $self->sendMessageAll( $server_address, "Broadcast from ".$self->getFactionProperty( $self->{FACTION}, "name")."(".$self->{FACTION}.")", @message );
}

sub processTimes ( @ ) {

  my $self = $_[0];
  my $allow = 0;
  my $item;
  my $timesPath = $server_game_path."turn".$self->{TURN}."/times";
  
  $self->log( "found times" );
  
  # create turn directory if it doesn`t exist
  if ( opendir( CAT, $server_game_path."turn".$self->{TURN})) {
    closedir( CAT );
  } else {
    mkdir $server_game_path."turn".$self->{TURN}, 0777;
  }
  
  if ( open( TIMES, ">>".$timesPath )) {
  
    print TIMES $self->getFactionProperty( $self->{FACTION}, "name" )."(".$self->{FACTION}.") wrote:\n";
    
    for ( $item=1; $item<=$#_; $item++ ) {

      if ( $_[$item] =~ m/#end.*/i ) {
	$allow = 0;
      }
      
      if ($allow == 1 ) {
	print TIMES $_[$item];
      }
	
      if ( $_[$item] =~ m/#times.*/i ) {
	$allow = 1;
      }
    }

    print TIMES "-------------------------------------\n";

    close( TIMES ); 
  }
}

sub processRumor ( @ ) {

  my $self = $_[0];
  my $allow = 0;
  my $item;
  my $timesPath = $server_game_path."turn".$self->{TURN}."/times";
  
  $self->log( "found times" );
  
  # todo create turn catalog
  
  if ( open( TIMES, ">>".$timesPath )) {
  
    print TIMES "Unknown wrote:\n";
    
    for ( $item=1; $item<=$#_; $item++ ) {

      if ( $_[$item] =~ m/#end.*/i ) {
	$allow = 0;
      }
      
      if ($allow == 1 ) {
	print TIMES $_[$item];
      }
	
      if ( $_[$item] =~ m/#rumor.*/i ) {
	$allow = 1;
      }
    }

    print TIMES "-------------------------------------\n";

    close( TIMES ); 
  }
}

  
sub getMessageType( @ ) {
  my $self = $_[0];
  my $item;
  my $mode = "#unknown";
  
  for ( $item=0; $item<=$#_; $item++ ) {
    if ( $_[$item] =~ m/#atlantis.*/i ) {
      ($mode,$self->{FACTION},$self->{PASSWORD}) = split /\s*[\"\s]/, $_[$item];
    }
    if ( $_[$item] =~ m/#times.*/i ) {
      ($mode,$self->{FACTION},$self->{PASSWORD}) = split /\s*[\"\s]/, $_[$item];
    }
    if ( $_[$item] =~ m/#mail.*/i ) {
      ($mode,$self->{SOURCEFACTION},$self->{FACTION},$self->{PASSWORD}) = split /\s*[\"\s]/, $_[$item];
    }
    if ( $_[$item] =~ m/#rumor.*/i ) {
      ($mode,$self->{FACTION},$self->{PASSWORD}) = split /\s*[\"\s]/, $_[$item];
    }
    if ( $_[$item] =~ m/#wall.*/i ) {
      ($mode,$self->{FACTION},$self->{PASSWORD}) = split /\s*[\"\s]/, $_[$item];
    }
    if ( $_[$item] =~ m/#request.*/i ) {
      $mode = "#request";
    }
  }

  if ( $self->{PASSWORD} eq "none" ) {
    $self->{PASSWORD} = "";
  }
  
  return $mode;
}

sub processRequest( $ ) {

  my $self = $_[0];
  my $from = $_[1];
  my $playersFile = $server_game_path."players.out";
  
  if ( open( PLAYERS, ">>".$playersFile )) {
    print PLAYERS "Faction: new\n";
    print PLAYERS "Email: ".$from."\n";
    close( PLAYERS ); 
  }
  
  my @message = ("Your request accepted.\n", "Wait next turn please.\n");
  $self->sendMessage( $server_address, $from, "Request processing", @message );
}

sub processMail( @ ) {
  my $self = $_[0];
  my $item;
  my @message = ();
  my $allow = 0;
  
  for ( $item=1; $item<=$#_; $item++ ) {
    if ( $_[$item] =~ m/#end.*/i ) {
      $allow = 0;
    }
    if ($allow == 1 ) {
      push( @message, $_[$item] );
    }
    if ( $_[$item] =~ m/#mail.*/i ) {
      $allow = 1;
    }
  }
  
  my $factionSource = $self->getFactionProperty( $self->{SOURCEFACTION}, "name" )."(".$self->{SOURCEFACTION}.")";
  my $faction = $self->getFactionProperty( $self->{FACTION}, "name" )."(".$self->{FACTION}.")";
  $self->sendMessage( $server_address, $self->getFactionProperty( $self->{SOURCEFACTION}, "email" ), "Private message from ".$faction, @message );
  $self->sendMessage( $server_address, $self->getFactionProperty( $self->{FACTION}, "email" ), "Private message to faction ".$factionSource." accepted", ());
}

sub processOrders( $@ ) {
  
  my $self = $_[0];
  my $from = $_[1];
  my @message = ();
  my $item;
  my $allow = 0;
  
  for ( $item=2; $item<=$#_; $item++ ) {
    if ( $_[$item] =~ m/#atlantis.*/i ) {
      $allow = 1;
    }
    if ($allow == 1 ) {
      push( @message, $_[$item] );
    }
    if ( $_[$item] =~ m/#end.*/i ) {
      $allow = 0;
    }
  }
  
  # create turn directory if it doesn`t exist
  if ( opendir( CAT, $server_game_path."turn".$self->{TURN})) {
    closedir( CAT );
  } else {
    mkdir $server_game_path."turn".$self->{TURN}, 0777;
  }
  
  # store message
  my $ordersPath = $server_game_path."turn".$self->{TURN}."/orders.".$self->{FACTION};
  my $line;
  if ( open( ORDERS, ">".$ordersPath )) {
    foreach $line ( @message ) {
      print ORDERS $line;
    }
    close( ORDERS );
  }
  
  # run checker
  my $checkPath = $server_game_path."turn".$self->{TURN}."/checker.".$self->{FACTION};
  system $server_game_path."standard check"." ".$ordersPath." ".$checkPath." > /dev/null";
  $self->sendFile( $server_address, $from, "Order checker", $checkPath );
}

sub checkMessage( $$ ) {
  my $self = $_[0];
  my $message_source = $_[1];
  my $message_from = $_[2];
  my @body;
 
  my $mode;
 
  # $self->log( "Incoming message from ".$message_from );
 
  if ( open( SOURCE, "<".$message_source )) {
  
  @body = <SOURCE>;

  # identify script mode  
  $mode = $_[0]->getMessageType( @body );
  $self->{TURN} = $self->getTurnNumber();
  
  # process orders
  if ( $mode eq "#atlantis" ) {
    if ( $self->getFactionProperty( $self->{FACTION}, "password" ) eq $self->{PASSWORD} ) {
      $self->processOrders( $message_from, @body );
    } else {
      $self->sendMessage( $server_address, $message_from, "Bad password", ());
    }
  }
  
  if ( $mode eq "#times" ) {
    if ( $self->getFactionProperty( $self->{FACTION}, "password" ) eq $self->{PASSWORD} ) {
      $self->processTimes( @body );
    } else {
      $self->sendMessage( $server_address, $message_from, "Bad password", ());
    }
  }

  if ( $mode eq "#mail" ) {
    if ( $self->getFactionProperty( $self->{FACTION}, "password" ) eq $self->{PASSWORD} ) {
      $self->processMail( @body );
    } else {
      $self->sendMessage( $server_address, $message_from, "Bad password", ());
    }
  }
  
  if ( $mode eq "#rumor" ) {
    if ( $self->getFactionProperty( $self->{FACTION}, "password" ) eq $self->{PASSWORD} ) {
      $self->processRumor( @body );
    } else {
      $self->sendMessage( $server_address, $message_from, "Bad password", ());
    }
  }
  
  if ( $mode eq "#wall" ) {
    if ( $self->getFactionProperty( $self->{FACTION}, "password" ) eq $self->{PASSWORD} ) {
      $self->processWall( @body );
    } else {
      $self->sendMessage( $server_address, $message_from, "Bad password", ());
    }
  }

  if ( $mode eq "#request" ) {
    $self->processRequest( $message_from );
  }
  
  if ( $mode eq "#unknown" ) {
    $self->log( "bad message format" );
    $self->sendMessage( $server_address, $message_from, "Unknown message format", @body );
  }
  }
}

sub sendReport( $$$$ ) {

  my $self = $_[0];
  my $from = $_[1];
  my $to = $_[2];
  my $subject = $_[3];
  my $source = $_[4];
  
  # uue   
  my $mime = "mimencode -b -o ".$server_tmp_path."mime ".$source;
  system $mime;

  my $boundary = sprintf("--------%0X%0X", rand(0xFFFFFFFF), rand(0xFFFFFFFF));

  if ( open( MESSAGE, ">".$server_tmp_path."message" )) {

    print MESSAGE "To: ".$to."\n";
    print MESSAGE "From: ".$from."\n";
    print MESSAGE "Subject: ".$subject."\n";
    print MESSAGE "X-Priority: 3 (Normal)\n";
    print MESSAGE "MIME-Version: 1.0\n";
    print MESSAGE "Content-Type: multipart/mixed; boundary=\"".$boundary."\"\n\n";

    print MESSAGE "--".$boundary."\n";
    print MESSAGE "Content-Type: text/plain; charset=\"koi8-r\"\n";
    print MESSAGE "Content-Transfer-Encoding: 7bit\n\n";
    
    print MESSAGE "See attachment please.\n";
    print MESSAGE "--".$boundary."\n";
    print MESSAGE "Content-Type: application/octet-stream; name=\"report.zip\"\n";
    print MESSAGE "Content-Transfer-Encoding: base64\n";
    print MESSAGE "Content-Disposition: attachment; filename=\"report.zip\"\n\n";

    if ( open( REPORT, "<".$server_tmp_path."mime")) {
      my @body = <REPORT>;
      my $line;
      foreach $line (@body) {
	print MESSAGE $line;
      }
      close( REPORT );
    }
  print MESSAGE "\n--".$boundary."--\n";

    close( MESSAGE );
  }
  
  unlink $server_tmp_path."mime";

  # send message
  system $server_game_path."sendfile ".$server_tmp_path."message"." ".$to;
  unlink $server_tmp_path."message";
}

sub createFactionsList {
  my $self;
  my @list = ();

  if ( open( PLAYERS, "<".$server_game_path."players.out" )) {
    my @players = <PLAYERS>;
    my $line;
    my $empty;
    my $faction;
    foreach $line (@players) {
      if ( $line =~ m/faction:.*/i ) {
	($empty,$faction) = split /\s+/, $line;
	push( @list, $faction );
      }
    }
    close( PLAYERS ); 
  }
  
  $self->{FACTIONSLIST} = @list;
}

sub fileCopy( $$ ) {
  my $self = $_[0];
  my $source = $_[1];
  my $desctination = $_[1];
  
  if ( open( SOURCE, "<".$source )) {
    my @body = <SOURCE>;
    my $line;
    if ( open( DST, ">".$desctination )) {
      foreach $line ( @body ) {
	print DST $line;
      }
      close( DST ); 
    }
    close( SOURCE ); 
  }
}

sub fileMove( $$ ) {
  my $self = $_[0];
  $self->fileCopy( $_[1], $_[2] );
  unlink $_[2];
}

sub processTurn() {
  my $self = $_[0];
 
  # read turn number
  my $turn = $self->getTurnNumber();
  $self->createFactionsList();

  my $item;
  # cleanup previous data
  foreach $item ($self->{FACTIONSLIST}) {
    unlink $server_game_path."orders.".$item;
    unlink $server_game_path."report.".$item;
  }
 
  # backup data files
  $self->fileCopy( $server_game_path."game.out", $server_game_path."turn".$turn."/game.in" );
  $self->fileCopy( $server_game_path."players.out", $server_game_path."turn".$turn."/players.in" );
  
  # prepare orders
  foreach $item ($self->{FACTIONSLIST}) {
    $self->fileCopy( $server_game_path."turn".$turn."/orders.".$item, $server_game_path."orders.".$item)
  }

  # prepare game data
  $self->fileMove( $server_game_path."game.out", $server_game_path."game.in" );
  $self->fileMove( $server_game_path."players.out", $server_game_path."players.in" );
 
  # run server
  chdir $server_game_path;
  system $server_game_path."standard run";

  my $prevturn = $turn;
  $turn = $self->getTurnNumber();
  mkdir $server_game_path."turn".$turn, 0777;

  # create last orders, backup and pack reports
  foreach $item ($self->{FACTIONSLIST}) {
    $self->fileCopy( $server_game_path."report.".$item, $server_game_path."turn".$turn."/orders.".$item );
    $self->fileMove( $server_game_path."report.".$item, $server_game_path."turn".$turn."/report.".$item );
    system "gzip -q -9 ".$server_game_path."turn".$turn."/report.".$item;
  }
  
  # send reports
  my @players;
  my $line;
  my $faction = "0";
  my $empty;
  my $mail;
 
  if ( open( PLAYERS, "<".$server_game_path."players.out" )) {
    @players = <PLAYERS>;
    foreach $line (@players) {
      if ( $line =~ m/faction:.*/i ) {
	($empty,$faction) = split /\s+/, $line;
      }
      if ( $line =~ m/email:.*/i ) {
	($empty,$mail) = split /\s+/, $line;
	if ( $mail !~ m/noaddress.*/i ) {
	  $self->sendReport( $server_address, $mail, "Turn #".$turn." report for faction #".$faction, $server_game_path."turn".$turn."/report.".$faction.".gz" );
	}
      }
    }
    close( PLAYERS ); 
  }
  
  # send times
  foreach $item ($self->{FACTIONSLIST}) {
    if ( $self->getFactionProperty( $item, "sendtimes" ) eq "1" ) {
      $self->sendFile( $server_address, $self->getFactionProperty( $item, "email" ), "Times for turn #".$turn, $server_game_path."turn".$prevturn."/times" );
    }
  }
}

1;