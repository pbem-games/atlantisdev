/*
	version.h	Version number header.
	Copyright (c) 1996-2003 by Christopher Heng. All rights reserved.

	$Id: version.h 1.11 2003/11/26 15:20:40 chris Exp $
*/

#if !defined(VERSION_H_INCLUDED)
#define	VERSION_H_INCLUDED

/* macros */
#define	VERSN_MAJOR	1
#define	VERSN_MINOR	7

#define	VERSN_PROGNAME	"tofrodos"

#endif
